package com.capgemini.smartoffice.pwa.back.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.capgemini.smartoffice.pwa.back.model.Meeting;
import com.capgemini.smartoffice.pwa.back.model.MeetingOrganizerDetail;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.smartoffice.pwa.back.repository.MeetingOrganizerDetailRepository;
import com.capgemini.smartoffice.pwa.back.repository.MeetingRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class MeetingServiceCancelTest {

    @Mock
    private MeetingRepository meetingRepository;

    @Mock
    private MeetingOrganizerDetailRepository meetingOrganizerDetailRepository;

    @Mock
    private ActionableMessageService actionableMessageService;

    private MeetingService meetingService;

    @BeforeEach
    void setUp() {
        meetingService = new MeetingService();
        ReflectionTestUtils.setField(meetingService, "meetingRepository", meetingRepository);
        ReflectionTestUtils.setField(meetingService, "meetingOrganizerDetailRepository", meetingOrganizerDetailRepository);
        ReflectionTestUtils.setField(meetingService, "actionableMessageService", actionableMessageService);
    }

    @Test
    void shouldMarkMeetingAsCancelled() {
        Meeting meeting = new Meeting();
        meeting.setId("booking-1");
        meeting.setCheckStatus(EnumMeetingStatus.CREATED);

        when(meetingRepository.findByCustomId("booking-1")).thenReturn(Optional.of(meeting));
        when(meetingRepository.save(meeting)).thenReturn(meeting);

        Meeting cancelledMeeting = meetingService.cancelMeeting("booking-1");

        assertThat(cancelledMeeting.getCheckStatus()).isEqualTo(EnumMeetingStatus.CANCELLED);
        verify(meetingRepository).save(meeting);
    }

    @Test
    void shouldMarkMeetingAsCheckedIn() {
        Meeting meeting = new Meeting();
        meeting.setId("booking-1");
        meeting.setCheckStatus(EnumMeetingStatus.CREATED);

        when(meetingRepository.findByCustomId("booking-1")).thenReturn(Optional.of(meeting));
        when(meetingRepository.save(meeting)).thenReturn(meeting);

        Meeting checkedInMeeting = meetingService.checkInMeeting("booking-1");

        assertThat(checkedInMeeting.getCheckStatus()).isEqualTo(EnumMeetingStatus.CHECKED_IN);
        verify(meetingRepository).save(meeting);
    }

    @Test
    void shouldReturnOrganizerEmail() {
        MeetingOrganizerDetail organizerDetail = new MeetingOrganizerDetail();
        organizerDetail.setOrganizerEmail("user@example.com");

        when(meetingOrganizerDetailRepository.findByMeetingId("booking-1")).thenReturn(Optional.of(organizerDetail));

        assertThat(meetingService.getOrganizerEmail("booking-1")).isEqualTo("user@example.com");
    }
}