package com.capgemini.smartoffice.pwa.back.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.model.ActionTokenUsage;
import com.capgemini.smartoffice.pwa.back.repository.ActionTokenUsageRepository;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tech.jhipster.config.JHipsterProperties;

@ExtendWith(MockitoExtension.class)
class ActionTokenServiceTest {

    @Mock
    private ActionTokenUsageRepository actionTokenUsageRepository;

    @Captor
    private ArgumentCaptor<ActionTokenUsage> actionTokenUsageCaptor;

    private ActionTokenService actionTokenService;

    @BeforeEach
    void setUp() {
        ApplicationProperties applicationProperties = new ApplicationProperties();
        applicationProperties.getActionableMessage().setTokenValidityDays(7);

        JHipsterProperties jHipsterProperties = new JHipsterProperties();
        jHipsterProperties
            .getSecurity()
            .getAuthentication()
            .getJwt()
            .setBase64Secret(Encoders.BASE64.encode(Keys.secretKeyFor(io.jsonwebtoken.SignatureAlgorithm.HS512).getEncoded()));

        actionTokenService = new ActionTokenService(applicationProperties, jHipsterProperties, actionTokenUsageRepository);
    }

    @Test
    void shouldConsumeValidCancellationToken() {
        when(actionTokenUsageRepository.existsById(any())).thenReturn(false);

        String token = actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        actionTokenService.consumeActionToken(token, "booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        verify(actionTokenUsageRepository).save(actionTokenUsageCaptor.capture());
        ActionTokenUsage usage = actionTokenUsageCaptor.getValue();
        org.assertj.core.api.Assertions.assertThat(usage.getBookingId()).isEqualTo("booking-1");
        org.assertj.core.api.Assertions.assertThat(usage.getOrganizerEmail()).isEqualTo("user@example.com");
        org.assertj.core.api.Assertions.assertThat(usage.getActionName()).isEqualTo("cancel-meeting");
    }

    @Test
    void shouldRejectReplay() {
        when(actionTokenUsageRepository.existsById(any())).thenReturn(true);

        String token = actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        assertThatThrownBy(() -> actionTokenService.consumeActionToken(token, "booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("already been used");

        verify(actionTokenUsageRepository, never()).save(any());
    }

    @Test
    void shouldRejectBookingMismatch() {
        String token = actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        assertThatThrownBy(() -> actionTokenService.consumeActionToken(token, "booking-2", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("bookingId");
    }

    @Test
    void shouldRejectPurposeMismatch() {
        String token = actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        assertThatThrownBy(() -> actionTokenService.consumeActionToken(token, "booking-1", "user@example.com", ActionTokenService.CHECK_IN_PURPOSE))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("token purpose");
    }
}