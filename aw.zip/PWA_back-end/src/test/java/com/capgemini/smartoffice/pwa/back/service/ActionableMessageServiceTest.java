// package com.capgemini.smartoffice.pwa.back.service;

// import static org.assertj.core.api.Assertions.assertThat;
// import static org.mockito.ArgumentMatchers.contains;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
// import com.capgemini.smartoffice.pwa.back.config.GraphHelper;
// import com.capgemini.smartoffice.pwa.back.model.Meeting;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.ArgumentCaptor;
// import org.mockito.Captor;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class ActionableMessageServiceTest {

//     @Mock
//     private GraphHelper graphHelper;

//     @Mock
//     private ActionTokenService actionTokenService;

//     @Mock
//     private ActionableMessageAuthenticationService actionableMessageAuthenticationService;

//     @Captor
//     private ArgumentCaptor<String> emailBodyCaptor;

//     private ApplicationProperties applicationProperties;
//     private ActionableMessageService actionableMessageService;

//     @BeforeEach
//     void setUp() {
//         applicationProperties = new ApplicationProperties();
//         applicationProperties.getActionableMessage().setEnabled(true);
//         applicationProperties.getActionableMessage().setOriginatorId("originator-id");
//         applicationProperties.getActionableMessage().setSenderEmail("smartoffice@example.com");
//         applicationProperties.getActionableMessage().setCheckInMeetingUrl("https://smartoffice-api.example.com/api/checkin");
//         applicationProperties.getActionableMessage().setCancelMeetingUrl("https://smartoffice-api.example.com/api/cancel");

//         actionableMessageService = new ActionableMessageService(
//             graphHelper,
//             actionTokenService,
//             actionableMessageAuthenticationService,
//             applicationProperties
//         );
//     }

//     @Test
//     void shouldBuildAndSendAdaptiveCardEmail() {
//         Meeting meeting = new Meeting();
//         meeting.setId("booking-1");
//         meeting.setPoiName("Board Room 1");

//         when(actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CHECK_IN_PURPOSE)).thenReturn("checkin-token");
//         when(actionTokenService.generateActionToken("booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE)).thenReturn("cancel-token");

//         actionableMessageService.sendMeetingActionMessage(meeting, "user@example.com", "Alex");

//         verify(actionableMessageAuthenticationService).validatePingIdAuthenticatedOrganizer("user@example.com");
//         verify(graphHelper).sendMail(
//             eq("smartoffice@example.com"),
//             eq("user@example.com"),
//             contains("Board Room 1"),
//             emailBodyCaptor.capture()
//         );
//         String emailBody = emailBodyCaptor.getValue();
//         assertThat(emailBody).contains("application/adaptivecard+json");
//         assertThat(emailBody).contains("originator-id");
//         assertThat(emailBody).contains("https://smartoffice-api.example.com/api/checkin");
//         assertThat(emailBody).contains("https://smartoffice-api.example.com/api/cancel");
//         assertThat(emailBody).contains("booking-1");
//         assertThat(emailBody).contains("checkin-token");
//         assertThat(emailBody).contains("cancel-token");
//     }

//     @Test
//     void shouldSkipSendWhenFeatureDisabled() {
//         applicationProperties.getActionableMessage().setEnabled(false);

//         actionableMessageService.sendMeetingActionMessage(new Meeting(), "user@example.com", "Alex");

//         verify(graphHelper, never()).sendMail(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
//     }
// }