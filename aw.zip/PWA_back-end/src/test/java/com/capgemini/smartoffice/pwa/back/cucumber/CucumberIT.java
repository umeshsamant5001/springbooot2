package com.capgemini.smartoffice.pwa.back.cucumber;

import com.capgemini.smartoffice.pwa.back.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
