package com.capgemini.smartoffice.pwa.back.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import java.util.Collections;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

class ActionableMessageAuthenticationServiceTest {

    private ActionableMessageAuthenticationService actionableMessageAuthenticationService;

    @BeforeEach
    void setUp() {
        ApplicationProperties applicationProperties = new ApplicationProperties();
        applicationProperties.getAzure().setTenantId("tenant-id");
        applicationProperties.getAzure().getGraphApi().setClientId("client-id");
        applicationProperties.getAzure().getGraphApi().setClientSecret("client-secret");
        applicationProperties.getAzure().getGraphApi().setScopeUrl("https://graph.microsoft.com/.default");
        actionableMessageAuthenticationService = new ActionableMessageAuthenticationService(applicationProperties);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldRejectWhenPingIdUserIsMissing() {
        assertThatThrownBy(() -> actionableMessageAuthenticationService.validatePingIdAuthenticatedOrganizer("user@example.com"))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("PingID authentication is required");
    }

    @Test
    void shouldRejectWhenPingIdUserDoesNotMatchOrganizer() {
        SecurityContextHolder
            .getContext()
            .setAuthentication(new UsernamePasswordAuthenticationToken(new UserInformation("other@example.com"), "token", Collections.emptyList()));

        assertThatThrownBy(() -> actionableMessageAuthenticationService.validatePingIdAuthenticatedOrganizer("user@example.com"))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("does not match");
    }
}