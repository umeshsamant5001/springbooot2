package com.capgemini.smartoffice.pwa.back.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.capgemini.smartoffice.pwa.back.model.Meeting;
import com.capgemini.smartoffice.pwa.back.model.MeetingActionRequest;
import com.capgemini.smartoffice.pwa.back.service.ActionTokenService;
import com.capgemini.smartoffice.pwa.back.service.MeetingService;
import com.capgemini.smartoffice.pwa.back.web.rest.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class MeetingActionControllerTest {

    @Mock
    private ActionTokenService actionTokenService;

    @Mock
    private MeetingService meetingService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(new MeetingActionController(actionTokenService, meetingService)).build();
    }

    @Test
    void shouldCancelMeetingWhenTokenIsValid() throws Exception {
        MeetingActionRequest request = new MeetingActionRequest();
        request.setBookingId("booking-1");
        request.setActionToken("token-123");

        when(meetingService.getOrganizerEmail("booking-1")).thenReturn("user@example.com");
        doNothing().when(actionTokenService).consumeActionToken("token-123", "booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);
        when(meetingService.cancelMeeting("booking-1")).thenReturn(new Meeting());

        mockMvc
            .perform(post("/api/cancel").contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(request)))
            .andExpect(status().isOk());

        verify(meetingService).cancelMeeting("booking-1");
    }

    @Test
    void shouldCheckInMeetingWhenTokenIsValid() throws Exception {
        MeetingActionRequest request = new MeetingActionRequest();
        request.setBookingId("booking-1");
        request.setActionToken("token-123");

        when(meetingService.getOrganizerEmail("booking-1")).thenReturn("user@example.com");
        doNothing().when(actionTokenService).consumeActionToken("token-123", "booking-1", "user@example.com", ActionTokenService.CHECK_IN_PURPOSE);
        when(meetingService.checkInMeeting("booking-1")).thenReturn(new Meeting());

        mockMvc
            .perform(post("/api/checkin").contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(request)))
            .andExpect(status().isOk());

        verify(meetingService).checkInMeeting("booking-1");
    }

    @Test
    void shouldRejectReplay() throws Exception {
        MeetingActionRequest request = new MeetingActionRequest();
        request.setBookingId("booking-1");
        request.setActionToken("token-123");

        when(meetingService.getOrganizerEmail("booking-1")).thenReturn("user@example.com");
        doThrow(new IllegalStateException("Action token has already been used."))
            .when(actionTokenService)
            .consumeActionToken("token-123", "booking-1", "user@example.com", ActionTokenService.CANCEL_MEETING_PURPOSE);

        mockMvc
            .perform(post("/api/cancel").contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(request)))
            .andExpect(status().isConflict());
    }
}