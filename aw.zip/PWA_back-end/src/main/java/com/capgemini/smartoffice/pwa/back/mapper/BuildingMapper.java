package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.FloorDTO;
import com.capgemini.smartoffice.pwa.back.model.SiteDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.Site;
import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.BuildingInformation;

import java.util.Map;
import java.util.Objects;

@Named("BuildingMapper")
@Mapper(config = DtoMapperConfig.class)
public interface BuildingMapper {

	BuildingMapper INSTANCE = Mappers.getMapper(BuildingMapper.class);

    @Named("mapUnderConstruction")
        default Boolean mapUnderConstruction(Map<String, String> attributes) {
        if (attributes != null) {
            String hiddenValue = attributes.get("hidden");
            return "true".equalsIgnoreCase(hiddenValue);
        }
        return false;
    }

    /**
     * <p>Function to use to map a Building to a BuildingDTO.<p>
     *
     * <p>The function map all children object and parent ones. But don't map children of the parents and
     * parents of the children to avoid a loop in the mapping.</p>
     *
     * @param in The Building to map.
     * @param language The current language (use for the title)
     * @return A new Building DTO.
     */
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
        @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
        @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay"),
        @Mapping(source = "attributes", target = "underConstruction", qualifiedByName = "mapUnderConstruction")
    })
	BuildingDTO buildingToBuildingDTO(Building in, @Context String language);

	Building buildingDTOToBuilding(BuildingDTO in);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
        @Mapping(target = "floors", ignore = true),
        @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay")
    })
    BuildingDTO buildingToBuildingDTONoFloors(Building in, @Context String language);

    @Named("siteToSiteDTOWithoutChildren")
    default SiteDTO _siteToSiteDTOWithoutChildren(Site site, @Context String language) {
        return Mappers.getMapper(SiteMapper.class)._siteToSiteDTOWithoutChildren(site, language);
    }

    @Named("floorToFloorDTOWithoutParent")
    default FloorDTO _floorToFloorDTOWithoutParent(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class)._floorToFloorDTOWithoutParent(floor, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>The function map a Building to a Building DTO but without mapping the parent (Site).</p>
     */
    @Named("buildingToBuildingDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "site", ignore = true),
        @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
        @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay")
    })
    BuildingDTO _buildingToBuildingDTOWithoutParent(Building in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>The function map a Building to a Building DTO but without mapping the ;children (Floor).</p>
     */
    @Named("buildingToBuildingDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
        @Mapping(target = "floors", ignore = true),
        @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay")
    })
    BuildingDTO _buildingToBuildingDTOWithoutChildren(Building in, @Context String language);

    @Named("limitInDay")
    public static BuildingInformation limitInDay(BuildingInformation information) {
        if(Objects.nonNull(information) && Objects.isNull(information.getLimitInDay())) {
            information.setLimitInDay(15L);
        }
        return information;
    }
}
