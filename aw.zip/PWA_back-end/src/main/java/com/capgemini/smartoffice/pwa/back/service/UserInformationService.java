package com.capgemini.smartoffice.pwa.back.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;

@Service
public class UserInformationService {

    /**
     * Return information about the current user connected
     * @return And object with information about the user
     */
    public UserInformation getCurrent() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (UserInformation) authentication.getPrincipal();
    }

}
