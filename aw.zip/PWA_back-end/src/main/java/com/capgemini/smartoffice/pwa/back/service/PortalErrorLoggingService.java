package com.capgemini.smartoffice.pwa.back.service;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.smartoffice.pwa.back.mapper.PortalErrorLoggingMapper;
import com.capgemini.smartoffice.pwa.back.model.PortalErrorLogging;
import com.capgemini.smartoffice.pwa.back.model.PortalErrorLoggingDTO;
import com.capgemini.smartoffice.pwa.back.repository.PortalErrorLoggingRepository;

@Service
public class PortalErrorLoggingService {

    @Autowired
    private  PortalErrorLoggingRepository portalErrorLoggingRepository;

    @Transactional
    public PortalErrorLoggingDTO createPortalErrorLogging(PortalErrorLoggingDTO portalErrorLoggingDTO) {

        if (portalErrorLoggingDTO == null) {
            throw new IllegalArgumentException("Portal error logging payload is required");
        }

        String validatedClassName = safeString(portalErrorLoggingDTO.getClassName());
        String validatedModule = safeString(portalErrorLoggingDTO.getModule());
        Long validatedLineNumber = safeLong(portalErrorLoggingDTO.getLineNumber());
        String validatedDescription = safeString(portalErrorLoggingDTO.getDescription());
        String validatedState = safeString(portalErrorLoggingDTO.getState());
        String validatedErrorType = safeString(portalErrorLoggingDTO.getErrorType());
        String validatedData = safeString(portalErrorLoggingDTO.getData());
        Long validatedLoggingDate = safeLong(portalErrorLoggingDTO.getLoggingDate());
        String validatedErrorLoggingType = safeString(portalErrorLoggingDTO.getErrorLoggingType());
        String validatedUserEmail = safeString(portalErrorLoggingDTO.getUserEmail());
        String validatedHttpMethod = safeString(portalErrorLoggingDTO.getHttpMethod());
        String validatedRequestUrl = safeString(portalErrorLoggingDTO.getRequestUrl());
        String validatedRequestPayload = safeString(portalErrorLoggingDTO.getRequestPayload());
        Long validatedResponseStatus = safeLong(portalErrorLoggingDTO.getResponseStatus());
        String validatedResponseBody = safeString(portalErrorLoggingDTO.getResponseBody());
        String validatedStackTrace = safeString(portalErrorLoggingDTO.getStackTrace());
        String validatedBrowserInfo = safeString(portalErrorLoggingDTO.getBrowserInfo());
        String validatedApplicationPortal = safeString(portalErrorLoggingDTO.getApplicationPortal());

        PortalErrorLogging entity = new PortalErrorLogging();

        entity.setClassName(validatedClassName == null ? null : new String(validatedClassName));
        entity.setModule(validatedModule == null ? null : new String(validatedModule));
        entity.setLineNumber(validatedLineNumber == null ? null : Long.valueOf(validatedLineNumber));
        entity.setDescription(validatedDescription == null ? null : new String(validatedDescription));
        entity.setState(validatedState == null ? null : new String(validatedState));
        entity.setErrorType(validatedErrorType == null ? null : new String(validatedErrorType));
        entity.setData(validatedData == null ? null : new String(validatedData));
        entity.setLoggingDate(validatedLoggingDate == null ? null : Long.valueOf(validatedLoggingDate));
        entity.setErrorLoggingType(validatedErrorLoggingType == null ? null : new String(validatedErrorLoggingType));
        entity.setUserEmail(validatedUserEmail == null ? null : new String(validatedUserEmail));
        entity.setHttpMethod(validatedHttpMethod == null ? null : new String(validatedHttpMethod));
        entity.setRequestUrl(validatedRequestUrl == null ? null : new String(validatedRequestUrl));
        entity.setRequestPayload(validatedRequestPayload == null ? null : new String(validatedRequestPayload));
        entity.setResponseStatus(validatedResponseStatus == null ? null : Long.valueOf(validatedResponseStatus));
        entity.setResponseBody(validatedResponseBody == null ? null : new String(validatedResponseBody));
        entity.setStackTrace(validatedStackTrace == null ? null : new String(validatedStackTrace));
        entity.setBrowserInfo(validatedBrowserInfo == null ? null : new String(validatedBrowserInfo));
        entity.setApplicationPortal(validatedApplicationPortal == null ? null : new String(validatedApplicationPortal));


        // Server-side audit field
        entity.setCreatedDate(Instant.now().getEpochSecond());

        PortalErrorLogging savedEntity = portalErrorLoggingRepository.save(entity);

        PortalErrorLoggingDTO responseDTO = PortalErrorLoggingMapper.INSTANCE.portalErrorLoggingToDTO(savedEntity);

        return responseDTO;
    }

    private String safeString(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();

        if (trimmed.isEmpty()) {
            return null;
        }

        return new String(trimmed);
    }

    private Long safeLong(Long value) {
        if (value == null) {
            return null;
        }

        if (value < 0L) {
            throw new IllegalArgumentException("Numeric values must be positive or zero");
        }

        return Long.valueOf(value);
    }
}