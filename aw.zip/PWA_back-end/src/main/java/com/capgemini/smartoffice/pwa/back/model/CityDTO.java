package com.capgemini.smartoffice.pwa.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class CityDTO implements WithTitleDTO {
    private Long id;
    private Long modifiedAt;
    private String titleFr;
    private String titleEn;
    private String title;
    private List<SiteDTO> sites;
    private CountryDTO country;
    private Long cdmKeyId;
    private Long cdmStateId;
    private Map<String, String> attributes = new HashMap<String, String>();
}
