package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.ServiceUser;
import com.capgemini.smartoffice.pwa.back.model.ServiceUserId;

@Repository
public interface ServiceUserRepository extends JpaRepository<ServiceUser, ServiceUserId> {

    List<ServiceUser> findAllByUserId(@Param("userId") Long userId);

}
