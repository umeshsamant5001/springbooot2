package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class FrontLabelDTO {

	private Long id;
    private String fieldKey;
    private String languageText;
    private String languageCode;
}
