package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class ServiceTranslationDTO {
    private Long id;
    private String key;
    private String value;
    private String locale;
    private Long serviceId;
}
