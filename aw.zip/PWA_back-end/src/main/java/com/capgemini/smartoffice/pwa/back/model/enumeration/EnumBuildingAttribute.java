package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum EnumBuildingAttribute {

    LAT("lat"), LON("lon");

    private final String text;

    EnumBuildingAttribute(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

}
