package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.repository.ServiceRepository;
import com.capgemini.smartoffice.pwa.utils.LanguageUtils;

@org.springframework.stereotype.Service
public class ServiceService {

    @Autowired
    private ServiceRepository serviceRepository;

    public List<Service> findAll(boolean onlyNonBeta) {
        List<Service> services = this.serviceRepository.findAll();

        if (onlyNonBeta) {
            services = this.filterBeta(services);
        }
        
        return services;
    }

    public Service findById(Long id) {
        return this.serviceRepository.findById(id).orElse(null);
    }

    public List<Service> findByLevel(Long buildingCdmKeyId, Long siteCdmKeyId, Long cityCdmKeyId, Long countryCdmKeyId, boolean onlyNonBeta) {
        List<Service> services = this.serviceRepository.findByLevel(buildingCdmKeyId, siteCdmKeyId, cityCdmKeyId, countryCdmKeyId);
        if (onlyNonBeta) {
            services = this.filterBeta(services);
        }

        return services;
    }

    //For Mobile service for QR scan code
    public List<Service> findByLevelForMobileQRScan(Long buildingCdmKeyId, Long siteCdmKeyId, Long cityCdmKeyId, Long countryCdmKeyId, boolean onlyNonBeta) {
        List<Service> services = this.serviceRepository.findByLevelForMobileQRScan(buildingCdmKeyId, siteCdmKeyId, cityCdmKeyId, countryCdmKeyId);
        if (onlyNonBeta) {
            services = this.filterBeta(services);
        }

        return services;
    }

    /**
     * Return the title of a service, based on a language
     * @param service The service
     * @param language The language of the title
     * @return
     */
    public String getTitle(Service service, String language) {
        return service.getTranslations()
            .stream()
            .filter((translation) -> "title".equals(translation.getKey()) && language.equals(translation.getLocale()))
            .map(translation -> translation.getValue())
            .findFirst()
            .orElseGet(() -> {
                if (LanguageUtils.DEFAULT_LANGUAGE.equals(language)) {
                    return "";
                }

                return this.getTitle(service, LanguageUtils.DEFAULT_LANGUAGE);
            });
    }

    /**
     * Remove all Beta services
     * @param services The services list to filter
     * @return A list of services without the Beta ones
     */
    public List<Service> filterBeta(List<Service> services) {
        return services.stream()
            .filter(service -> {
                if (!service.getAttributes().containsKey("beta")) {
                    return true;
                }

                return "No".equals(service.getAttributes().get("beta"));
            })
            .collect(Collectors.toList());
    }

}
