package com.capgemini.smartoffice.pwa.back.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.UserFeedback;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

@Repository
public interface UserFeedbackRepository extends JpaRepository<UserFeedback, Long> {
    boolean existsByEmailIdAndRatingFrom(String emailId, RatingFrom ratingFrom);
    Optional<UserFeedback> findByEmailIdAndRatingFrom(
        String emailId,
        RatingFrom ratingFrom);
}
