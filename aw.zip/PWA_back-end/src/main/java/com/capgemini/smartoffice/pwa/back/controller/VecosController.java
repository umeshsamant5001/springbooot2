package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.vecos.VecosClient;

@RestController
@RequestMapping(value = VecosController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class VecosController {

    static final String ROOT_API = "api/vecos";

    @Autowired
    private VecosClient vecosClient;

    @PutMapping()
    public ResponseEntity<Object> launchVecosBatch() {
        this.vecosClient.retrieveAllVecosLockerBankStatus();

        return ResponseEntity.noContent().build();
    }
}
