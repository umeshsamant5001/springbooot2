package com.capgemini.smartoffice.pwa.back.model;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

import lombok.Data;

@Data
public class UserFeedbackDTO {

    private Long id;

    private String emailId;

    private Long createdDate;

    private Long modifiedDate;

    private Rating rating;

    private RatingFrom ratingFrom;

    private String comment;
}
