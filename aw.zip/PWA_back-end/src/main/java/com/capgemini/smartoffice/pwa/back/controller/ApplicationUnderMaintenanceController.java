package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenanceDTO;
import com.capgemini.smartoffice.pwa.back.model.Platform;
import com.capgemini.smartoffice.pwa.back.service.ApplicationUnderMaintenanceService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = ApplicationUnderMaintenanceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ApplicationUnderMaintenanceController {

    public static final String ROOT_API = "api/maintenance";

    @Autowired
    private ApplicationUnderMaintenanceService applicationUnderMaintenanceService;


    @GetMapping
    public ResponseEntity<List<ApplicationUnderMaintenanceDTO>> getAllApplicationUnderMaintenance(
            @RequestParam(value = "platform", required = false) Platform platform) {
        log.info("Fetching applications under maintenance for platform: {}", platform);

        List<ApplicationUnderMaintenanceDTO> applicationUnderMaintenanceDTOs =
                this.applicationUnderMaintenanceService.getAllApplicationUnderMaintenance(platform);

        return ResponseEntity.ok(applicationUnderMaintenanceDTOs);
    }

}
