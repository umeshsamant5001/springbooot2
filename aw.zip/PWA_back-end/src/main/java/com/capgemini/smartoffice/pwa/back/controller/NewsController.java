package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.model.NewsDTO;

import com.capgemini.smartoffice.pwa.back.service.NewsService;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = NewsController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class NewsController {

    static final String ROOT_API = "api/news";

    @Autowired
    private NewsService newsService;

    @GetMapping
    public ResponseEntity<List<NewsDTO>> getAllNewsIsActive(){
        List<NewsDTO> newsDTOs = new ArrayList<>();
        newsDTOs = this.newsService.findAllNewsIsActive();
        return ResponseEntity.ok(newsDTOs);
    }
}
