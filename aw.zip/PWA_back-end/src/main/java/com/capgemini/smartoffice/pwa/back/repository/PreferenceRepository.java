package com.capgemini.smartoffice.pwa.back.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.smartoffice.pwa.back.model.Preference;

@Repository
public interface PreferenceRepository extends JpaRepository<Preference, Long> {    
    
    @Query("SELECT DISTINCT p FROM Preference p WHERE p.userEmail = :userEmail")
    Optional<Preference> findByUserEmail(@Param("userEmail") String userEmail);

}
