package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumUserAnalytics;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class UserAnalyticsCreateRequest {

    @Positive
    private Long id;

    @Positive
    private Long parentId;

    @Size(max = 255)
    private String appUser;

    @Size(max = 255)
    private String moduleName;

    @Size(max = 255)
    private String activity;

    @PositiveOrZero
    private Long activityDate;

    @Size(max = 255)
    private String platform;

    @NotNull
    private EnumUserAnalytics userAnalytics;

    @NotNull
    @Size(max = 320)
    private String email;

    @NotNull
    @Size(max = 255)
    private String country;
}
