package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.mapper.BuildingMapper;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.capgemini.smartoffice.pwa.back.mapper.PreferenceMapper;
import com.capgemini.smartoffice.pwa.back.model.Preference;
import com.capgemini.smartoffice.pwa.back.model.PreferenceDTO;
import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.Floor;


import com.capgemini.smartoffice.pwa.back.repository.BuildingRepository;
import com.capgemini.smartoffice.pwa.back.repository.PreferenceRepository;
import com.capgemini.smartoffice.pwa.back.repository.ServiceRepository;
import com.capgemini.smartoffice.pwa.back.repository.UserRepository;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;


@org.springframework.stereotype.Service
@Slf4j
public class PreferenceService {

    @Autowired
    private PreferenceRepository preferenceRepository;

    @Autowired
    private BuildingRepository buildingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private ServiceRepository serviceRepository;


    @Autowired
    private ApplicationProperties applicationProperties;

    public PreferenceDTO updateBuildingPreference(Long buildingId, Long favoriteFloorId, String userEmail,
            String language) throws Exception {

        if (Objects.isNull(buildingId)
                || Objects.isNull(favoriteFloorId)
                || Objects.isNull(userEmail)) {
            throw new IllegalArgumentException("Building preference payload is incomplete");
        }

        Long requestedBuildingId = Long.valueOf(String.valueOf(buildingId));
        Long requestedFavoriteFloorId = Long.valueOf(String.valueOf(favoriteFloorId));
        String validatedUserEmail = new String(String.valueOf(userEmail));

        Floor validatedFloor = floorService.getFloor(requestedFavoriteFloorId, requestedBuildingId);


        if (Objects.isNull(validatedFloor) || Objects.isNull(validatedFloor.getBuildingId())) {
            throw new IllegalArgumentException("favoriteFloorId not found");
        }

        Long trustedFavoriteFloorId = validatedFloor.getId() == null ? null
                : Long.valueOf(String.valueOf(validatedFloor.getId()));
        Long trustedBuildingId = validatedFloor.getBuildingId() == null ? null
                : Long.valueOf(String.valueOf(validatedFloor.getBuildingId()));

        if (!Objects.equals(trustedBuildingId, requestedBuildingId)) {
            throw new IllegalArgumentException("favoriteFloorId does not belong to buildingId");
        }

        Building trustedBuilding = buildingRepository.findByBuildingIdWithParent(trustedBuildingId);
        if (Objects.isNull(trustedBuilding)) {
            throw new IllegalArgumentException("buildingId not found");
        }

        String trustedCityName = Objects.isNull(trustedBuilding.getSite())
                || Objects.isNull(trustedBuilding.getSite().getCity())
                || Objects.isNull(trustedBuilding.getSite().getCity().getTitleEn())
                        ? null
                        : new String(String.valueOf(trustedBuilding.getSite().getCity().getTitleEn()));

        User user = userService.createOrUpdateUser(validatedUserEmail, null, null);

        Optional<Preference> userPreferenceOpt = preferenceRepository.findByUserEmail(validatedUserEmail);


        if (userPreferenceOpt.isPresent()) {
            Preference userPref = userPreferenceOpt.get();

            boolean sameBuilding = Objects.equals(userPref.getCurrentBuildingId(), trustedBuildingId);
            boolean floorChanged = !Objects.equals(userPref.getCurrentFloorId(), trustedFavoriteFloorId);

            if (sameBuilding && floorChanged) {
                userPref.setCurrentFloorId(trustedFavoriteFloorId);
            } else if (!sameBuilding) {
                userPref.addVisitedBuildingId(trustedBuildingId, trustedBuildingId);
                userPref.setCurrentBuildingId(trustedBuildingId);
                userPref.setCurrentFloorId(trustedFavoriteFloorId);
                userPref.setCurrentCityName(trustedCityName == null ? null : new String(String.valueOf(trustedCityName)));
            }



            preferenceRepository.save(userPref);
            return preferenceToPreferenceDto(userPref, language);
        }

        // Create new preference
        Preference newUserPreference = new Preference();
        newUserPreference.setUserEmail(validatedUserEmail);
        newUserPreference.setCurrentBuildingId(trustedBuildingId);
        newUserPreference.setCurrentFloorId(trustedFavoriteFloorId);
        newUserPreference.setCurrentCityName(trustedCityName == null ? null : new String(String.valueOf(trustedCityName)));
        newUserPreference.addVisitedBuildingId(trustedBuildingId, trustedBuildingId);


        newUserPreference.setUser(user);
        user.setPreference(newUserPreference);
        userRepository.save(user);
        return preferenceToPreferenceDto(newUserPreference, language);
    }

    private PreferenceDTO preferenceToPreferenceDto(Preference userPreference, String language) {
        Hibernate.initialize(userPreference.getFavoriteServices());
        PreferenceDTO prefDTO = PreferenceMapper.INSTANCE.preferenceToPreferenceDTO(userPreference, language);
        List<Long> visitedBuildingIds = userPreference.getVisitedBuildingsIds();
        List<BuildingDTO> buildingDTOs = this.buildingRepository.findByIdIn(visitedBuildingIds)
                .stream()
                .map(building -> BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language))
                .collect(Collectors.toList());
        prefDTO.setVisitedBuildings(buildingDTOs);
        return prefDTO;
    }

    public PreferenceDTO getUserPreference(String userEmail, String language) {
        Optional<Preference> userPreferenceOpt = this.preferenceRepository.findByUserEmail(userEmail);
        if (userPreferenceOpt.isPresent()) {
            Preference userPref = userPreferenceOpt.get();
            List<Service> serviceList = userPref.getFavoriteServices()
                    .stream()
                    .filter(service -> service.getAttributes().containsKey("status")
                            && !"Disabled".equals(service.getAttributes().get("status")))
                    .collect(Collectors.toList());

            userPref.setFavoriteServices(serviceList);
            return preferenceToPreferenceDto(userPref, language);
        } else {
            return null;
        }
    }

    public boolean addFavoriteService(String email, Long serviceId) {
        Preference preference = this.preferenceRepository.findByUserEmail(email).orElse(null);

        if (Objects.isNull(preference)) {
            return false;
        }

        Service service = this.serviceRepository.findById(serviceId).orElse(null);

        if (Objects.isNull(service)) {
            return false;
        }

        boolean isPresent = preference.getFavoriteServices()
                .stream()
                .anyMatch(srv -> Objects.equals(srv.getId(), serviceId));

        if (!isPresent) {
            preference.getFavoriteServices().add(service);

            this.preferenceRepository.save(preference);
        }

        return true;
    }

    public boolean removeFavoriteService(String email, Long serviceId) {
        Preference preference = this.preferenceRepository.findByUserEmail(email).orElse(null);

        if (Objects.isNull(preference)) {
            return false;
        }

        boolean serviceExists = this.serviceRepository.existsById(serviceId);

        if (!serviceExists) {
            return false;
        }

        Service service = preference.getFavoriteServices()
                .stream()
                .filter(srv -> Objects.equals(srv.getId(), serviceId))
                .findFirst()
                .orElse(null);

        if (Objects.nonNull(service)) {
            preference.getFavoriteServices().remove(service);

            this.preferenceRepository.save(preference);
        }

        return true;
    }

    
    public String getToken() {

        String tenantId = applicationProperties.getAzure().getTenantId();
        String url = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        // Form parameters
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "client_credentials");
        form.add("client_id", applicationProperties.getAzure().getGraphApi().getClientId());
        form.add("client_secret",applicationProperties.getAzure().getGraphApi().getClientSecret());
        form.add("scope", applicationProperties.getAzure().getGraphApi().getScopeUrl());

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(form, headers);

        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);

        return response.getBody();
    }

}
