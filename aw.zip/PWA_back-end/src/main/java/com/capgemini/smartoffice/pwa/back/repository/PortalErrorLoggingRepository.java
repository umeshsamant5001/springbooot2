package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.PortalErrorLogging;

@Repository
public interface PortalErrorLoggingRepository extends JpaRepository<PortalErrorLogging, Long> {

}