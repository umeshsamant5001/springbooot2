package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.mapper.FrontLabelMapper;
import com.capgemini.smartoffice.pwa.back.model.FrontLabel;
import com.capgemini.smartoffice.pwa.back.model.FrontLabelDTO;
import com.capgemini.smartoffice.pwa.back.repository.FrontLabelRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = FrontLabelController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class FrontLabelController {

    static final String ROOT_API = "api/label";

    @Autowired
    private FrontLabelRepository frontLabelRepository;

    @GetMapping
    public List<FrontLabelDTO> getFrontLabels() {
        List<FrontLabel> frontLabels = frontLabelRepository.findAll();

                List<FrontLabelDTO> frontLabelsDTO = frontLabels.stream()
                .map(frontLabel -> {
                    FrontLabelDTO frontLabelDTO = FrontLabelMapper.INSTANCE.frontLabelTofrontLabelDTO(frontLabel);
                    return frontLabelDTO;
                }).collect(Collectors.toList());
        return frontLabelsDTO;
    }
}

