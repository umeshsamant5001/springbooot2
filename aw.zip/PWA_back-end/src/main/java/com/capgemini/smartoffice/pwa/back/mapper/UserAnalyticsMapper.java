package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.UserAnalytics;
import com.capgemini.smartoffice.pwa.back.model.UserAnalyticsDTO;

@Mapper
public interface UserAnalyticsMapper {
    
    UserAnalyticsMapper INSTANCE = Mappers.getMapper(UserAnalyticsMapper.class);

    UserAnalyticsDTO useranalyticsToUserAnalyticsDTO(UserAnalytics in);

    UserAnalytics useranalyticsDTOToUserAnalytics(UserAnalyticsDTO in);

}
