package com.capgemini.smartoffice.pwa.back.model.errorcodes;

public final class ErrorCodes {

	public static final Integer USER_NOT_FOUND = 1;

	public static final Integer POI_NOT_FOUND = 2;

	public static final Integer AUTHENTICATION_FAILED = 3;

	// Prevent instantiation
	private ErrorCodes() {
		throw new IllegalAccessError();
	}
}
