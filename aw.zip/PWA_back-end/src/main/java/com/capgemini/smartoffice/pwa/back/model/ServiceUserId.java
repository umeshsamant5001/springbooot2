package com.capgemini.smartoffice.pwa.back.model;

import java.io.Serializable;

import javax.persistence.JoinColumn;

import lombok.Data;

@Data
public class ServiceUserId implements Serializable {

    @JoinColumn(name = "service_id", insertable = true)
    private Long service;

    @JoinColumn(name = "user_id", insertable = true)
    private Long user;

    public ServiceUserId() {
    }

    public ServiceUserId(Long serviceId, Long userId) {
        this.service = serviceId;
        this.user = userId;
    }

}
