package com.capgemini.smartoffice.pwa.back.model;

import java.util.Date;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumMeetingStatus;

import lombok.Data;

@Data
public class EventDTO {
    private String id;

    private Long from;

    private Long to;

    private EnumMeetingStatus checkStatus;

    private String room;

    private Floor floor;

    private Long floorId;

    private String poiName;

    private Long created;

    private Long modifiedAt = (new Date()).getTime() / 1000;

    private String eventStartTime;

    private String eventEndTime;

    private String eventTimeZone;
    
    private String organizerEmail;
    private String organizerName;
}
