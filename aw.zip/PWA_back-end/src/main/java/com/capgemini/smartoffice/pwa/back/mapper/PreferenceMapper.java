package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.Preference;
import com.capgemini.smartoffice.pwa.back.model.PreferenceDTO;
import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.model.ServiceDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;

@Named("PreferenceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface PreferenceMapper {

    PreferenceMapper INSTANCE = Mappers.getMapper(PreferenceMapper.class);

    @Mappings({
        @Mapping(source = "userEmail", target = "userEmailId"),
        @Mapping(source = "currentBuildingId", target = "favoriteBuilding"),
        @Mapping(source = "currentFloorId", target = "favoriteFloorId"),
        @Mapping(source = "visitedBuildings", target = "visitedBuildings", qualifiedByName = { "buildingToBuildingDTOWithoutChildren" }),
        @Mapping(source = "favoriteServices", target = "favoriteServices", qualifiedByName = { "serviceToServiceDTOWithoutChildren" })
    })
    PreferenceDTO preferenceToPreferenceDTO(Preference in, @Context String language);

    @Named("buildingToBuildingDTOWithoutChildren")
    default BuildingDTO _buildingToBuildingDTOWithoutChildren(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutChildren(building, language);
    }

    @Named("serviceToServiceDTOWithoutChildren")
    default ServiceDTO _serviceToServiceDTOWithoutChildren(Service service, @Context String language) {
        return Mappers.getMapper(ServiceMapper.class).serviceToServiceDTO(service);
    }

}