package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.City;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

	long countByCountryId(@Param("countryId") Long countryId);

	List<City> findAllByCountryId(@Param("countryId") Long countryId);
	
	City findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);
}
