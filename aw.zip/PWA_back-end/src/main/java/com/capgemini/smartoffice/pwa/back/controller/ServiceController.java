package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.mapper.ServiceMapper;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.City;
import com.capgemini.smartoffice.pwa.back.model.Country;
import com.capgemini.smartoffice.pwa.back.model.Platform;
import com.capgemini.smartoffice.pwa.back.model.PlatformQR;
import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.model.ServiceDTO;
import com.capgemini.smartoffice.pwa.back.model.Site;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.repository.UserRoleLocationRepository;
import com.capgemini.smartoffice.pwa.back.security.AuthoritiesConstants;
import com.capgemini.smartoffice.pwa.back.security.SecurityUtils;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import com.capgemini.smartoffice.pwa.back.service.BuildingService;
import com.capgemini.smartoffice.pwa.back.service.ServiceService;
import com.capgemini.smartoffice.pwa.back.service.ServiceUserService;
import com.capgemini.smartoffice.pwa.back.service.UserInformationService;
import com.capgemini.smartoffice.pwa.back.service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = ServiceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ServiceController {

    static final String ROOT_API = "api/services";

    @Autowired
    private ServiceService serviceService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserInformationService userInformationService;

    @Autowired
    private ServiceUserService serviceUserService;

    @Autowired
    private UserRoleLocationRepository userRoleLocationRepository;

    @GetMapping
    public ResponseEntity<List<ServiceDTO>> getAll() {
        boolean isBetaUser = SecurityUtils.hasCurrentUserThisAuthority(AuthoritiesConstants.BETA);

        List<Service> lServices = this.serviceService.findAll(!isBetaUser);
        if (CollectionUtils.isEmpty(lServices)) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(lServices
                .stream()
                .map(service -> ServiceMapper.INSTANCE.serviceToServiceDTO(service))
                .collect(Collectors.toList()));
    }

    @GetMapping("/{serviceId}")
    public ResponseEntity<ServiceDTO> getServiceById(@PathVariable Long serviceId) {
        boolean isBetaUser = SecurityUtils.hasCurrentUserThisAuthority(AuthoritiesConstants.BETA);

        Service service = this.serviceService.findById(serviceId);
        // Return not found is the service don't exist
        if (Objects.isNull(service)) {
            return ResponseEntity.notFound().build();
        }

        // Return Forbiden is the service is Beta but not the user
        if (!isBetaUser && "Yes".equals(service.getAttributes().get("beta"))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        return ResponseEntity.ok(ServiceMapper.INSTANCE.serviceToServiceDTO(service));
    }

    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<ServiceDTO>> getServiceByBuilding(@PathVariable Long buildingId,
        @RequestParam(name = "platform", required = false, defaultValue = "0") Integer platform,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Building building = this.buildingService.findByBuildingIdWithParent(buildingId);
        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }
        UserInformation userInformation = this.userInformationService.getCurrent();
        String userEmail = userInformation.getEmail();
        // The building is secured, we need to check if the user can access it.
        if (Boolean.TRUE.equals(building.getSecured())) {

            Boolean isAuthorized = this.userService.filterSecuredBuilding(userEmail, building );

            if (Boolean.FALSE.equals(isAuthorized)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }
        Boolean isBetaUser = userRoleLocationRepository.findUserByEmailAndRole(userEmail, AuthoritiesConstants.BETA).isPresent();
        // User does not have the "Beta User" role

        Site site = building.getSite();
        City city = site.getCity();
        Country country = city.getCountry();

        List<Service> lServices;

        if (platform == 0 || platform == null) {
            log.info("Only for WEB portal (It means NOT QR code)");
            lServices = this.serviceService.findByLevel(
                building.getCdmKeyId(),
                site.getCdmKeyId(),
                city.getCdmKeyId(),
                country.getCdmKeyId(),
                !isBetaUser
            );
        }else if (platform == 1 || platform == 2 || platform == 3 || platform == 4 || platform == 5) { 
            log.info("Only for QRScan code");
            lServices = this.serviceService.findByLevelForMobileQRScan(
                building.getCdmKeyId(),
                site.getCdmKeyId(),
                city.getCdmKeyId(),
                country.getCdmKeyId(),
                !isBetaUser
            );
        }else{
            return ResponseEntity.badRequest().build();
        }

        // Sort by priority
        lServices.sort(Comparator.comparing(Service::getPriority, Comparator.nullsLast(Integer::compareTo)));

        List<ServiceDTO> serviceDTOList = lServices
            .stream()
            .map(service -> ServiceMapper.INSTANCE.serviceToServiceDTO(service))
            .collect(Collectors.toList());

        this.applyUsedTimes(serviceDTOList);

        return ResponseEntity.ok(serviceDTOList);
    }

    private void applyUsedTimes(List<ServiceDTO> services) {
        UserInformation userInformation = this.userInformationService.getCurrent();
        String userEmail = userInformation.getEmail();
        if (Objects.nonNull(userEmail)) {
            User user = userService.findByEmailNoDeletedCheck(userEmail);
            if (Objects.isNull(user)) {
                return;
            }

            // Get all the count of use for each service, for the current user
            Map<Long, Long> mapCount = this.serviceUserService.getCountByUserId(user.getId());

            // Add the service never used into the previous map.
            services.stream()
                .forEach(service -> {
                    if (mapCount.containsKey(service.getId())) {
                        service.setUsedTimes(mapCount.get(service.getId()));
                    } else {
                        service.setUsedTimes(0L);
                    }
                });
        }
    }

}

