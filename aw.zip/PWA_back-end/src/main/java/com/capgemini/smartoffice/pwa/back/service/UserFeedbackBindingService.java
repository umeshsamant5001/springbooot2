package com.capgemini.smartoffice.pwa.back.service;

import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.SafeUserFeedbackData;
import com.capgemini.smartoffice.pwa.back.model.UserFeedback;
import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserFeedbackBindingService {

    public SafeUserFeedbackData buildSafeUserFeedbackData(String emailId, Rating rating, RatingFrom ratingFrom, String comment,
            boolean ratingFromOptional) {

    log.debug("USER_FEEDBACK_SAFE_DATA_BUILD_START | ratingFromOptional={}", ratingFromOptional);

        String validatedEmailId = safeRequiredString(emailId, "EmailId is required");

        Rating validatedRating = rating == null
                ? null
                : Rating.fromValue(rating.getValue());

        if (validatedRating == null) {
            throw new IllegalArgumentException("Rating is required");
        }

        RatingFrom validatedRatingFrom = ratingFrom == null
                ? null
                : RatingFrom.valueOf(String.valueOf(ratingFrom.name()));

        if (!ratingFromOptional && validatedRatingFrom == null) {
            throw new IllegalArgumentException("RatingFrom is required");
        }

        if (ratingFromOptional && validatedRatingFrom == null) {
            validatedRatingFrom = RatingFrom.WEB_PORTAL;
        }

        String validatedComment = safeOptionalString(comment);

        SafeUserFeedbackData safeData = new SafeUserFeedbackData();
        safeData.setEmailId(new String(validatedEmailId));
        safeData.setRating(Rating.fromValue(validatedRating.getValue()));
        safeData.setRatingFrom(RatingFrom.valueOf(String.valueOf(validatedRatingFrom.name())));
        safeData.setComment(validatedComment == null ? null : new String(validatedComment));

        log.debug("USER_FEEDBACK_SAFE_DATA_BUILD_COMPLETED | ratingFrom={}", validatedRatingFrom);

        return safeData;
    }

    public void applySafeValues(UserFeedback target, SafeUserFeedbackData safeData, boolean setCreatedDate, long nowEpochSecond) {
        log.debug("USER_FEEDBACK_SAFE_VALUES_APPLY_START | setCreatedDate={}", setCreatedDate);

        if (target == null) {
            log.warn("USER_FEEDBACK_SAFE_VALUES_APPLY_REJECTED | reason=Target is null");
            throw new IllegalArgumentException("User feedback target is required");
        }

        if (safeData == null) {
            log.warn("USER_FEEDBACK_SAFE_VALUES_APPLY_REJECTED | reason=Safe data is null");
            throw new IllegalArgumentException("User feedback data is required");
        }

        target.setEmailId(new String(safeData.getEmailId()));
        target.setRating(safeData.getRating() == null ? null : Rating.fromValue(safeData.getRating().getValue()));
        target.setRatingFrom(safeData.getRatingFrom() == null ? null
                : RatingFrom.valueOf(String.valueOf(safeData.getRatingFrom().name())));
        target.setComment(safeData.getComment() == null ? null : new String(safeData.getComment()));

        if (setCreatedDate) {
            target.setCreatedDate(Long.valueOf(nowEpochSecond));
        }
        target.setModifiedDate(Long.valueOf(nowEpochSecond));

        log.debug("USER_FEEDBACK_SAFE_VALUES_APPLY_COMPLETED | setCreatedDate={}", setCreatedDate);
    }

    private String safeRequiredString(String value, String errorMessage) {
        String safeValue = safeOptionalString(value);
        if (safeValue == null || safeValue.isEmpty()) {
            throw new IllegalArgumentException(errorMessage);
        }
        return safeValue;
    }

    private String safeOptionalString(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = new String(String.valueOf(value)).trim();

        if (trimmed.isEmpty()) {
            return null;
        }

        return new String(trimmed);
    }
}
