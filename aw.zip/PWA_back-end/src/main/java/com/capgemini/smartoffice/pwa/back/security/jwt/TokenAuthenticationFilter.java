package com.capgemini.smartoffice.pwa.back.security.jwt;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.capgemini.smartoffice.pwa.back.service.UserRoleLocationService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.repository.AuthenticationExceptionRepository;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.AuthFailureException;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.AuthenticationException;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import com.capgemini.smartoffice.pwa.back.service.UserService;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import java.util.Base64;



@Slf4j
@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private Environment environment;

    @Autowired
    private AuthenticationExceptionRepository authenticationExceptionRepository;

    @Autowired
    private JWTSignatureValidation jwtSignatureValidation;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleLocationService userRoleLocationService;

    private final Object lock = new Object();

    // private static final String AUTH_KEY_SECRET_PROPERTY = "application.security.auth-key-secret";
    // private static final int GCM_IV_LENGTH = 12;
    // private static final int GCM_TAG_LENGTH = 128;





    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        addHstsHeader(request, response);
        
        try {
            extractAndValidateToken(request, response);
        } catch (AuthFailureException e) {
            // authentication failed, build and return a 401 response with error json body
            if (isActionableEndpoint(request)) {
                sendErrorResponse(HttpStatus.OK, response, e);
            } else {
                sendErrorResponse(HttpStatus.UNAUTHORIZED, response, e);
            }
            return;
        }
        chain.doFilter(request, response);
    }

    /**
     * Decrypt and validate JWT token and store the user to security context
     *
     * @param request
     */
    private void extractAndValidateToken(HttpServletRequest request, HttpServletResponse response) {
        if (this.environment.acceptsProfiles(Profiles.of("noAuth"))) {
            return;
        }

        if (Objects.isNull(jwtSignatureValidation)) {
            jwtSignatureValidation = new JWTSignatureValidation();
        }
        boolean actionableEndpoint = isActionableEndpoint(request);
        String authToken = jwtSignatureValidation.getAuthHeader(request);
        JSONObject pingIdResponse = null;

        if (actionableEndpoint) {
            if (Objects.isNull(authToken) || authToken.isBlank()) {
                log.info("Skipping Authorization header validation for actionable endpoint {}. Signed actionToken validation will be applied in controller.", request.getRequestURI());
                return;
            }

            authToken = authToken.replaceFirst("Bearer ", "");
            jwtSignatureValidation.validateWithPingIdForAdpativeCard(authToken);
        } else {
            if (Objects.isNull(authToken) || authToken.isBlank()) {
                throw new AuthFailureException(String.format("No token found from request %s", request.getRequestURI()));
            }

            authToken = authToken.replaceFirst("Bearer ", "");
            pingIdResponse = jwtSignatureValidation.getPingIdValidateResponse(authToken);
            jwtSignatureValidation.validatePingIdResponse(pingIdResponse);
        }

        if (pingIdResponse != null) {
            this.setCurrentUser(pingIdResponse);
        }
    }

    private boolean isActionableEndpoint(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.startsWith("/api/checkin")
            || uri.startsWith("/api/cancel")
            || uri.startsWith("/api/userfeedback");
    }

    // /**
    //  * Decrypt and validate JWT token and store the user to security context
    //  *
    //  * @param request
    //  */
    // private void extractAndValidateTokenForPerfEnv(HttpServletRequest request, HttpServletResponse response) {
    //     if (this.environment.acceptsProfiles(Profiles.of("noAuth"))) {
    //         return;
    //     }

    //     if (Objects.isNull(jwtSignatureValidation)) {
    //         jwtSignatureValidation = new JWTSignatureValidation();
    //     }
    //     String authToken = jwtSignatureValidation.getAuthKeyHeader(request);

    //     if (Objects.isNull(authToken)) {
    //         throw new AuthFailureException(String.format("No token found from request %s", request.getRequestURI()));
    //     }       

    //     this.setCurrentUserForPerformanceEnv(authToken);
    // }

    private void setCurrentUser(JSONObject pingIdResponse) {
        String email = (String) pingIdResponse.get("iss");
        UserInformation userInfo = new UserInformation(email);

        User user = getOrCreateUser(email);
        List<GrantedAuthority> authorities = getAuthoritiesForUser(user);

        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userInfo, null,
                authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    // private void setCurrentUserForPerformanceEnv(String encryptedAuthKey) {
    //     String email = decrypt(encryptedAuthKey);
    //     log.info("email from header auth_key: {}", email);
    //     UserInformation userInfo = new UserInformation(email);

    //     User user = getOrCreateUser(email);
    //     List<GrantedAuthority> authorities = getAuthoritiesForUser(user);

    //     UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userInfo, null,
    //             authorities);
    //     SecurityContextHolder.getContext().setAuthentication(authentication);
    // }

    private User getOrCreateUser(String email) {
        User user = userService.findByEmailNoDeletedCheck(email);
        if (user == null) {
            synchronized (lock) {
                user = userService.findByEmailNoDeletedCheck(email);
                if (user == null) {
                    try {
                        log.info("Create user >>>>> ");
                        user = new User(); 
                        user = userService.createUserBeforeAuthentication(email, user);
                    } catch (Exception e) {
                        log.error("Create user exception, we will still resume", e);
                    }
                }
            }
        }
        return user;
    }

    private List<GrantedAuthority> getAuthoritiesForUser(User user) {
        if (user == null)
            return Collections.emptyList();

        return userRoleLocationService.findByUserId(user.getId()).stream()
                .map(roleLoc -> new SimpleGrantedAuthority(roleLoc.getRole().getName()))
                .collect(Collectors.toList());
    }

    private void sendErrorResponse(HttpStatus status, HttpServletResponse response, AuthFailureException ex) {
        authenticationExceptionRepository.save(
                new AuthenticationException(
                        HttpStatus.UNAUTHORIZED.value(),
                        ex.getErrorCode(),
                        ex.getMessage(),
                        System.currentTimeMillis() / 1000));
        response.setStatus(status.value());
        response.setContentType("application/json");
        response.setHeader("CARD-ACTION-STATUS", "Authentication failed: " + ex.getMessage());
        try {
            response.getWriter().write(buildErrorJson(ex).toString());
        } catch (IOException e) {
            log.error(String.format("Authentication: failed to build error json response: %s", e.getMessage()));
        }
    }

    private void addHstsHeader(HttpServletRequest request, HttpServletResponse response) {
        if (request.isSecure()) {
            response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        }
    }

    private JsonObject buildErrorJson(AuthFailureException exception) {
        log.error(String.format("Authentication failed - message:%s", exception.getMessage()));
        JsonObject json = new JsonObject();
        json.addProperty("errorCode", exception.getErrorCode());
        json.addProperty("message", exception.getMessage());
        json.addProperty("exception", exception.getClass().getName());

        return json;
    }

    // /**
    //  * Manage if we bypass the authentication on specific env requests.
    //  *
    //  * @param request
    //  * @return boolean
    //  */
    // private boolean bypassAuth(HttpServletRequest request) {
    //     return (Arrays.stream(environment.getActiveProfiles()).anyMatch("dev"::equals) &&
    //             request.getRequestURI().equals("/api/auth/token") && // token generation for local tests only
    //             "GET".equals(request.getMethod()));
    // }

    // private String decrypt(String encrypted) {
    //     try {
    //         byte[] decoded = Base64.getDecoder().decode(encrypted);
    //         if (decoded.length <= GCM_IV_LENGTH) {
    //             throw new RuntimeException("Decryption error: invalid encrypted payload");
    //         }

    //         byte[] iv = Arrays.copyOfRange(decoded, 0, GCM_IV_LENGTH);
    //         byte[] cipherText = Arrays.copyOfRange(decoded, GCM_IV_LENGTH, decoded.length);

    //         SecretKeySpec skeySpec = getAuthKeySecretSpec();
    //         GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);

    //         Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    //         cipher.init(Cipher.DECRYPT_MODE, skeySpec, gcmParameterSpec);

    //         byte[] original = cipher.doFinal(cipherText);

    //         return new String(original, StandardCharsets.UTF_8);

    //     } catch (Exception ex) {
    //         throw new RuntimeException("Decryption error: ", ex);
    //     }
    // }

    // private SecretKeySpec getAuthKeySecretSpec() {
    //     String configuredSecret = environment.getProperty(AUTH_KEY_SECRET_PROPERTY);
    //     if (configuredSecret == null || configuredSecret.isBlank()) {
    //         throw new RuntimeException("Decryption error: missing auth key secret configuration");
    //     }

    //     byte[] keyBytes = configuredSecret.getBytes(StandardCharsets.UTF_8);
    //     if (keyBytes.length != 16 && keyBytes.length != 24 && keyBytes.length != 32) {
    //         throw new RuntimeException("Decryption error: invalid AES key length");
    //     }

    //     return new SecretKeySpec(keyBytes, "AES");
    // }


}
