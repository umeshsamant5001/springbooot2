package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data 
public class PwaSupportedLanguageDTO {
    private Long id;
    private String language;
    private String languageCode;
}
