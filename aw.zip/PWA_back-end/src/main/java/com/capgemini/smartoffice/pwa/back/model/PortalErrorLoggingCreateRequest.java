package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class PortalErrorLoggingCreateRequest {

    @Size(max = 255)
    private String className;

    @Size(max = 255)
    private String module;

    @PositiveOrZero
    private Long lineNumber;

    @Size(max = 20000)
    private String description;

    @Size(max = 255)
    private String state;

    @Size(max = 255)
    private String errorType;

    @Size(max = 50000)
    private String data;

    @PositiveOrZero
    private Long loggingDate;

    @Size(max = 255)
    private String errorLoggingType;

    @Size(max = 320)
    private String userEmail;

    @Size(max = 20)
    private String httpMethod;

    @Size(max = 4000)
    private String requestUrl;

    @Size(max = 50000)
    private String requestPayload;

    @PositiveOrZero
    private Long responseStatus;

    @Size(max = 50000)
    private String responseBody;

    @Size(max = 100000)
    private String stackTrace;

    @Size(max = 50000)
    private String browserInfo;

    @Size(max = 255)
    private String applicationPortal;
}
