package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.security.SecurityUtils;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ActionableMessageAuthenticationService {

    private final ApplicationProperties applicationProperties;

    public ActionableMessageAuthenticationService(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    public void validatePingIdAuthenticatedOrganizer(String organizerEmail) {
        if (organizerEmail == null || organizerEmail.isBlank()) {
            throw new IllegalArgumentException("organizerEmail is required.");
        }

        log.info("Validating PingID organizer context | organizerEmail={}", organizerEmail);

        String authenticatedEmail = SecurityUtils
            .getCurrentUserLogin()
            .orElseThrow(() -> new IllegalStateException("PingID authentication is required before sending meeting actions."));

        if (!authenticatedEmail.equalsIgnoreCase(organizerEmail)) {
            log.warn("PingID organizer mismatch | organizerEmail={} | authenticatedEmail={}", organizerEmail, authenticatedEmail);
            throw new IllegalStateException("Authenticated PingID user does not match the meeting organizer.");
        }

        log.info("PingID organizer validated | organizerEmail={}", organizerEmail);
    }

    public String acquireGraphAccessToken() {
        ApplicationProperties.Azure.GraphApi graphApi = applicationProperties.getAzure().getGraphApi();

        try {
            log.info("Acquiring Microsoft Graph access token with MSAL | clientId={} | scope={}", graphApi.getClientId(), graphApi.getScopeUrl());
            ConfidentialClientApplication app = ConfidentialClientApplication
                .builder(graphApi.getClientId(), ClientCredentialFactory.createFromSecret(graphApi.getClientSecret()))
                .authority(buildAuthority())
                .build();

            ClientCredentialParameters parameters = ClientCredentialParameters
                .builder(Collections.singleton(graphApi.getScopeUrl()))
                .build();

            IAuthenticationResult result = app.acquireToken(parameters).join();
            log.info("Microsoft Graph access token acquired successfully with MSAL | tenantId={}", applicationProperties.getAzure().getTenantId());
            return result.accessToken();
        } catch (Exception ex) {
            log.error("Microsoft Graph access token acquisition failed.", ex);
            throw new IllegalStateException("Unable to acquire Microsoft Graph access token with MSAL.", ex);
        }
    }

    private String buildAuthority() {
        return "https://login.microsoftonline.com/" + applicationProperties.getAzure().getTenantId() + "/";
    }
}