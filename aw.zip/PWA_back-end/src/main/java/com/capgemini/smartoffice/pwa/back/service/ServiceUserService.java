package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.ServiceUser;
import com.capgemini.smartoffice.pwa.back.model.ServiceUserId;
import com.capgemini.smartoffice.pwa.back.repository.ServiceUserRepository;

@Service
public class ServiceUserService {

    @Autowired
    private ServiceUserRepository serviceUserRepository;

    public ServiceUser findByIds(Long userId, Long serviceId) {
        ServiceUserId serviceUserId = new ServiceUserId(serviceId, userId);

        return this.serviceUserRepository.findById(serviceUserId).orElse(null);
    }

    public void save(ServiceUser serviceUser) {
        this.serviceUserRepository.save(serviceUser);
    }

    /**
     * Return a map of number of used by service id
     * 
     * @param userId The id of the user
     * @return
     */
    public Map<Long, Long> getCountByUserId(Long userId) {
        List<ServiceUser> serviceUserList = this.serviceUserRepository.findAllByUserId(userId);

        return serviceUserList.stream()
                .collect(Collectors.toMap(
                        serviceUser -> serviceUser.getService().getId(),
                        serviceUser -> serviceUser.getCount()));
    }
}
