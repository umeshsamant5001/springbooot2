package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {
    long countBySiteId(@Param("siteId") Long siteId);

    List<Building> findAllBySiteId(@Param("siteId") Long siteId);

    List<Building> findByIdIn(List<Long> buildingIdList);

    Building findByFloorsId(@Param("floorId") Long floorId);

    Building findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

    @RestResource(exported = false)
    @Query(
        value = "select building.* from building building where id in" +
        "(select building_id from building_attribute where att_value = :asset_id) limit 1",
        nativeQuery = true
    )
    Building findByAssetId(@Param("asset_id") String asset_id);

    List<Building> findAllBySecuredTrue();

    /** To optimize query, we force the use of a JOIN for the OpeningHours */
    @Query("SELECT building FROM Building building LEFT JOIN FETCH building.information.openingHours WHERE building.deployed = 1")
    List<Building> findAllByDeployedTrue();

    List<Building> findAllBySecuredFalseAndDeployedTrue();

    @Query(
        "SELECT building FROM Building building INNER JOIN FETCH building.site site INNER JOIN FETCH site.city city INNER JOIN FETCH city.country country " +
        " WHERE building.id = :buildingId "
    )
    Building findByBuildingIdWithParent(@Param("buildingId") Long buildingId);

    Building findByIdAndSecuredFalse(@Param("buildingId") Long buildingId);

    @Query(
        value = "SELECT DISTINCT b.* " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = b.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId AND b.id = :buildingId " +
        "UNION " +
        "SELECT DISTINCT b.* " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = s.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId AND b.id = :buildingId " +
        "UNION " +
        "SELECT DISTINCT b.* " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN city c ON s.city_id = c.id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = c.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId AND b.id = :buildingId",
        nativeQuery = true
    )
    Building findSecuredBuildingByUserIdAndBuildingId(@Param("userId") Long userId,
            @Param("buildingId") Long buildingId);

    @Query(
        value = "SELECT DISTINCT b.id " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = b.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId " +
        "UNION " +
        "SELECT DISTINCT b.id " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = s.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId " +
        "UNION " +
        "SELECT DISTINCT b.id " +
        "FROM building b " +
        "INNER JOIN site s ON s.id = b.site_id " +
        "INNER JOIN city c ON s.city_id = c.id " +
        "INNER JOIN user_role_location urloc ON urloc.cdm_key_id = c.cdm_key_id " +
        "INNER JOIN role r ON r.id = urloc.role_id " +
        "INNER JOIN users u ON u.id = urloc.user_id " +
        "WHERE r.name = 'Secured User' AND u.id = :userId",
        nativeQuery = true
    )
    List<Long> findSecuredBuildingIdsByUserId(@Param("userId") Long userId);


    @Query(
		value = "select LEFT(att_value, LEN(att_value) - 2) AS modified_att_value "+
		"from building_attribute  where building_id in ( " +
		"select distinct building_id from floor where id in (" +
		"select floor_id from poi where space_type_id = ( " +
		"select id from space_type where space_type_name ='locker' ))) " + 
		"and att_key = 'cdm.asset_code'",
		nativeQuery = true
	)
	List<String> findllBuildingsWithLockers();

}
