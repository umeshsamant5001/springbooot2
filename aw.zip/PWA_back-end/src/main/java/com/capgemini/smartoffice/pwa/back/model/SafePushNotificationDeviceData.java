package com.capgemini.smartoffice.pwa.back.model;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;

import lombok.Data;

@Data
public class SafePushNotificationDeviceData {

    private String deviceId;

    private String deviceRegistrationToken;

    private String countryName;

    private String emailId;

    private EnumFcmDeviceType deviceType;

    private Long countryId;
}
