package com.capgemini.smartoffice.pwa.back.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.Meeting;

@Repository
public interface MeetingRepository extends JpaRepository<Meeting, Long> {

    @Query("SELECT m FROM Meeting m WHERE m.id = :id")
    Optional<Meeting> findByCustomId(@Param("id") String id);

}
