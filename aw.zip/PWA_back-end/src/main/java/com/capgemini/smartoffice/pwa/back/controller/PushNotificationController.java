package com.capgemini.smartoffice.pwa.back.controller;

import java.util.List;
import java.util.stream.Collectors;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.model.AppRegistrationManagement;
import com.capgemini.smartoffice.pwa.back.model.Country;
import com.capgemini.smartoffice.pwa.back.model.CountryMapping;
import com.capgemini.smartoffice.pwa.back.model.PushNotificationDeviceRequest;
import com.capgemini.smartoffice.pwa.back.model.SafePushNotificationDeviceData;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;

import com.capgemini.smartoffice.pwa.back.repository.CountryRepository;
import com.capgemini.smartoffice.pwa.back.repository.CountryMappingRepository;
import com.capgemini.smartoffice.pwa.back.repository.DeviceTokenRepository;
import com.capgemini.smartoffice.pwa.back.security.SecurityUtils;
import com.capgemini.smartoffice.pwa.back.service.PushNotificationBindingService;

import lombok.extern.slf4j.Slf4j;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import org.springframework.http.HttpStatus;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;


@Slf4j
@RestController
@RequestMapping(value = PushNotificationController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PushNotificationController {

    static final String ROOT_API = "api/notification";

    @Autowired
    private DeviceTokenRepository deviceTokenRepository; 

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private CountryMappingRepository countryMappingRepository;

    @Autowired
    private PushNotificationBindingService pushNotificationBindingService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setDisallowedFields("save");
    }

    @PostMapping("/savetoken")
    public ResponseEntity<Map<String, String>> saveDeviceDetails(@Valid @RequestBody PushNotificationDeviceRequest deviceDetails) {

        Map<String, String> response = new HashMap<>();
         try {
        SafePushNotificationDeviceData safeDeviceData = pushNotificationBindingService.buildSafeDeviceData(
                deviceDetails.getDeviceId(),
                deviceDetails.getDeviceRegistrationToken(),
                deviceDetails.getCountryName(),
                deviceDetails.getEmailId(),
                deviceDetails.getDeviceType());

        String deviceId = safeDeviceData.getDeviceId();
        String deviceRegistrationToken = safeDeviceData.getDeviceRegistrationToken();
        String countryName = safeDeviceData.getCountryName();
        String emailId = safeDeviceData.getEmailId();
        EnumFcmDeviceType deviceType = safeDeviceData.getDeviceType();


        if (deviceId == null || deviceId.isEmpty()) {
            response.put("error", "DeviceId is required.");
            return ResponseEntity.badRequest().body(response);
        }

        // Get the current authenticated user's email
        Optional<String> currentUserEmail = SecurityUtils.getCurrentUserLogin();
        if (currentUserEmail.isPresent()) {
            emailId = currentUserEmail.get() == null ? null : new String(String.valueOf(currentUserEmail.get()));
            safeDeviceData.setEmailId(emailId == null ? null : new String(emailId));
        } else {

            log.warn("No authenticated user found. EmailId will not be set.");
        }

        // Check if deviceRegistrationToken is present
        if (deviceRegistrationToken == null || deviceRegistrationToken.isEmpty()) {
            response.put("error", "DeviceRegistrationToken is required.");
            return ResponseEntity.badRequest().body(response);
        }

        if (deviceType == null) {
            response.put("error", "Invalid deviceType. Allowed values are ANDROID or IOS.");
            return ResponseEntity.badRequest().body(response);
        }

        boolean recordExists = deviceTokenRepository.existsByDeviceIdAndDeviceRegistrationToken(deviceId, deviceRegistrationToken);

        if (recordExists) {
            response.put("message", "DeviceRegistrationToken record already present in the database.");
            return ResponseEntity.ok(response);
        }

        Optional<AppRegistrationManagement> existingDevice = deviceTokenRepository.findByDeviceId(deviceId);
        AppRegistrationManagement validatedCountryDetails = new AppRegistrationManagement();

        try {
            updateCountryDetails(validatedCountryDetails, countryName); //get CountryName
        } catch (IllegalArgumentException e) {
            log.error("Country validation failed: {}", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }

        if (existingDevice.isPresent()) {
            // If deviceId already exists, update deviceRegistrationToken and emailId
            AppRegistrationManagement existingDeviceDetails = existingDevice.get();
            safeDeviceData.setCountryId(validatedCountryDetails.getCountryId() == null ? null : Long.valueOf(validatedCountryDetails.getCountryId()));
            safeDeviceData.setCountryName(validatedCountryDetails.getCountryName() == null ? null : new String(validatedCountryDetails.getCountryName()));
            pushNotificationBindingService.applySafeValues(existingDeviceDetails, safeDeviceData, false, (new Date()).getTime() / 1000);
            deviceTokenRepository.save(existingDeviceDetails);


            response.put("message", "DeviceRegistrationToken updated successfully for existing deviceId.");
            return ResponseEntity.ok(response);
        }

        safeDeviceData.setCountryId(validatedCountryDetails.getCountryId() == null ? null : Long.valueOf(validatedCountryDetails.getCountryId()));
        safeDeviceData.setCountryName(validatedCountryDetails.getCountryName() == null ? null : new String(validatedCountryDetails.getCountryName()));
        AppRegistrationManagement registration = new AppRegistrationManagement();
        pushNotificationBindingService.applySafeValues(registration, safeDeviceData, true, (new Date()).getTime() / 1000);
        AppRegistrationManagement savedToken = deviceTokenRepository.save(registration);

        response.put("message", "DeviceRegistrationToken details saved successfully");
        return ResponseEntity.ok(response);
        } catch (Exception e) {
        response.put("error", "Failed to save DeviceRegistrationToken details.");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/savetoken")
    public ResponseEntity<Map<String, String>> updateDeviceRegistrationToken(
            @RequestParam String emailId,
            @Valid @RequestBody PushNotificationDeviceRequest deviceDetails) {

        Map<String, String> response = new HashMap<>();
        String safeEmailId = emailId == null ? null : new String(String.valueOf(emailId));
        SafePushNotificationDeviceData safeDeviceData = pushNotificationBindingService.buildSafeDeviceData(
                deviceDetails.getDeviceId(),
                deviceDetails.getDeviceRegistrationToken(),
                deviceDetails.getCountryName(),
                safeEmailId,
                deviceDetails.getDeviceType());
        String deviceRegistrationToken = safeDeviceData.getDeviceRegistrationToken();
        String deviceId = safeDeviceData.getDeviceId();
        EnumFcmDeviceType deviceType = safeDeviceData.getDeviceType();
        String countryName = safeDeviceData.getCountryName();


        if (deviceType == null) {
            response.put("error", "Invalid deviceType. Allowed values are ANDROID or IOS.");
            return ResponseEntity.badRequest().body(response);
        }

        AppRegistrationManagement registration = deviceTokenRepository.findByEmailIdWithUpdatedDateTime(safeEmailId);
        AppRegistrationManagement validatedCountryDetails = new AppRegistrationManagement();

        try {
            updateCountryDetails(validatedCountryDetails, countryName); //get CountryName
        } catch (IllegalArgumentException e) {
            log.error("Country validation failed: {}", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }

        if (registration != null) {
            safeDeviceData.setEmailId(safeEmailId == null ? null : new String(safeEmailId));
            safeDeviceData.setCountryId(validatedCountryDetails.getCountryId() == null ? null : Long.valueOf(validatedCountryDetails.getCountryId()));
            safeDeviceData.setCountryName(validatedCountryDetails.getCountryName() == null ? null : new String(validatedCountryDetails.getCountryName()));
            pushNotificationBindingService.applySafeValues(registration, safeDeviceData, false, (new Date()).getTime() / 1000);

            deviceTokenRepository.save(registration);

            response.put("message", "DeviceRegistrationToken updated successfully");
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "Provided emailId not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    public List<String> getAllDeviceRegistrationTokens() {
        List<AppRegistrationManagement> tokens = deviceTokenRepository.findAll();

        if (tokens.isEmpty()) {
            return Collections.emptyList();
        }

        List<String> tokenStrings = tokens.stream()
            .map(AppRegistrationManagement::getDeviceRegistrationToken)
            .collect(Collectors.toList());

        return tokenStrings;
    }

    /**
     * Validates and resolves the correct Country using CountryMapping if needed.
     * First tries direct lookup, then checks CountryMapping for external country names.
     * 
     * @param countryName The country name to validate
     * @return The resolved Country entity, or null if not found
     */
    private Country validateAndResolveCountry(String countryName) {
        if (countryName == null || countryName.trim().isEmpty()) {
            log.warn("Country name is null or empty");
            return null;
        }

        // First, try direct lookup by country name
        Country country = countryRepository.findByCountryName(countryName);
        
        if (country != null) {
            log.info("Country found directly: {} (ID: {})", countryName, country.getId());
            return country;
        }

        // If not found, check CountryMapping for external/alternate country names
        Optional<CountryMapping> countryMapping = countryMappingRepository
            .findByGraphCountryNameIgnoreCaseAndIsActiveTrue(countryName);

        if (countryMapping.isPresent()) {
            Country mappedCountry = countryMapping.get().getCountry();
            log.info("Country resolved via mapping: {} -> {} (ID: {})", 
                countryName, mappedCountry.getTitleEn(), mappedCountry.getId());
            return mappedCountry;
        }

        log.error("Country not found: {}. No direct match or mapping exists.", countryName);
        return null;
    }

    /**
     * Updates country details in AppRegistrationManagement with validation.
     * Uses CountryMapping to resolve external country names if needed.
     * 
     * @param deviceDetails The device registration details to update
     * @param countryName The country name to validate and resolve
     * @throws IllegalArgumentException if country cannot be resolved
     */
    private void updateCountryDetails(AppRegistrationManagement deviceDetails, String countryName) {
        Country country = validateAndResolveCountry(countryName);
        
        if (country == null) {
            throw new IllegalArgumentException(
                "Invalid country name: '" + countryName + 
                "'. Country not found in Country table or CountryMapping.");
        }

        // Set the validated country details
        deviceDetails.setCountryId(country.getId());
        deviceDetails.setCountryName(country.getTitleEn()); // Use standardized name from Country table
        
        log.debug("Updated device details with Country ID: {} and Name: {}", 
            country.getId(), country.getTitleEn());
    }

    


}
