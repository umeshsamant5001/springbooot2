package com.capgemini.smartoffice.pwa.back.model;

import java.util.Map;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;

import lombok.Data;

@Data
public class DeviceDTO {

	private String uuid;
	private String poiName;
	private Map<String, String> attributes;
	private Long lastChange;
	private EnumDeviceStatus status;
	private EnumDeviceType deviceType;
    private FloorDTO floor;
}
