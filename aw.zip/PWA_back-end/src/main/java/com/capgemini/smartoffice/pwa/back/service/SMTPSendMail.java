package com.capgemini.smartoffice.pwa.back.service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;
import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.text.StringEscapeUtils;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.config.GraphHelper;
import com.microsoft.graph.models.*;
import com.microsoft.graph.requests.*;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.io.File;
import java.io.IOException;
import java.util.*;
import org.springframework.core.env.Environment;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SMTPSendMail {

    @Autowired
    GraphHelper graphHelper;
    
    @Autowired
    private Environment environment;	

    private static final String configKey = "tablet_issue_addresse";

    public void createAndSendGraphMessage(String emailBody) {
    log.info("Inside createAndSendGraphMessage method started");
        Message message = new Message();

        message.subject = "Adaptive card test";

        ItemBody body = new ItemBody();
        body.contentType = BodyType.HTML;
        body.content = emailBody;
        message.body = body;
        List<String> addresses = Arrays.asList( "umesh.samant.ext@capgemini.com"); //getTabletIssueAddressList(configKey);

        message.toRecipients = addresses.stream()
                .map(addr -> {
                    Recipient r = new Recipient();
                    r.emailAddress = new EmailAddress();
                    r.emailAddress.address = addr;
                    return r;
                })
                .collect(Collectors.toList());

        // Call method
        log.info("before Called method sendEmailViaGraph >>");
        sendEmailViaGraph(message, null, environment.getProperty("spring.profiles.active"));
        log.info("after Called method sendEmailViaGraph >>");
    }
    public void createAndSendGraphMessageTest(File file) {

        Message message = new Message();

        message.subject = "Events skipped from insertion Report";

        ItemBody body = new ItemBody();
        body.contentType = BodyType.TEXT;
        body.content = "Please find attached Excel report of events skipped from insertion.";
        message.body = body;
        List<String> addresses = Arrays.asList("umesh.samant.ext@capgemini.com"); //getTabletIssueAddressList(configKey);

        message.toRecipients = addresses.stream()
                .map(addr -> {
                    Recipient r = new Recipient();
                    r.emailAddress = new EmailAddress();
                    r.emailAddress.address = addr;
                    return r;
                })
                .collect(Collectors.toList());

        // Call method
        sendEmailViaGraphTest(message, file , environment.getProperty("spring.profiles.active"));

    }

    private void sendEmailViaGraph(Message message, byte[] attachmentContent , String profile) {
        log.info("Inside sendEmailViaGraph method started data");
        try {



            // Convert to List
            List<Attachment> attachmentList = new LinkedList<>();

            // Set AttachmentCollectionPage
            message.attachments = new AttachmentCollectionPage(
                    attachmentList,
                    null);

            // Send email
            graphHelper.getInstanceForEmail()
                    .users("SVC-IN-SMARTOFFICE@capgemini.com")
                    .sendMail(
                            UserSendMailParameterSet.newBuilder()
                                    .withMessage(message)
                                    .withSaveToSentItems(true)
                                    .build())
                    .buildRequest()
                    .post();

        } catch (RuntimeException e) {
            log.error("Failed to send email via Microsoft Graph", e);
        }
    }

    private void sendEmailViaGraphTest(Message message, File file , String profile) {

        try {
            byte[] contentBytes = Files.readAllBytes(file.toPath());

            // Create attachment
            FileAttachment attachment = new FileAttachment();
            attachment.oDataType = "#microsoft.graph.fileAttachment";
            attachment.name = file.getName();
            attachment.contentBytes = contentBytes;
            attachment.contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            // Convert to List
            List<Attachment> attachmentList = new LinkedList<>();
            attachmentList.add(attachment);

            // Set AttachmentCollectionPage
            message.attachments = new AttachmentCollectionPage(
                    attachmentList,
                    null);

            // Send email
            graphHelper.getInstanceForEmail()
                    .users("SVC-IN-SMARTOFFICE@capgemini.com")
                    .sendMail(
                            UserSendMailParameterSet.newBuilder()
                                    .withMessage(message)
                                    .withSaveToSentItems(true)
                                    .build())
                    .buildRequest()
                    .post();

        } catch (IOException e) {
            log.error("Failed to read attachment content for Graph email send", e);
        } catch (RuntimeException e) {
            log.error("Failed to send email via Microsoft Graph", e);
        }

    }

    




    // private List<String> getTabletIssueAddressList(String configKey) {

    //     String addressValues = appConfigRepository.findTabletIssueAddressList(configKey);

    //     if (addressValues == null || addressValues.isEmpty()) {
    //         return Collections.emptyList();
    //     }

    //     return Arrays.stream(addressValues.split(","))
    //             .map(String::trim)
    //             .filter(s -> !s.isEmpty())
    //             .distinct()
    //             .collect(Collectors.toList());
    // }

}