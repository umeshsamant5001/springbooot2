package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.config.GraphHelper;
import com.capgemini.smartoffice.pwa.back.model.Meeting;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

@Service
@Slf4j
public class ActionableMessageService {

    private static final String TEMPLATE_PATH = "templates/actionable/meeting-cancel-card.json";

    private final GraphHelper graphHelper;
    private final ActionTokenService actionTokenService;
    private final ActionableMessageAuthenticationService actionableMessageAuthenticationService;
    private final ApplicationProperties applicationProperties;

    @Autowired
    SMTPSendMail smtpSendMail;

    public ActionableMessageService(
        GraphHelper graphHelper,
        ActionTokenService actionTokenService,
        ActionableMessageAuthenticationService actionableMessageAuthenticationService,
        ApplicationProperties applicationProperties
    ) {
        this.graphHelper = graphHelper;
        this.actionTokenService = actionTokenService;
        this.actionableMessageAuthenticationService = actionableMessageAuthenticationService;
        this.applicationProperties = applicationProperties;
    }

    String organizerEmail ="umesh.samant.ext@capgemini.com";
    String organizerName ="Umesh Samant";
    String meetingId = "abcdef";
    String subjecttest = "SmartOffice actions for Meeting Room 1";
    public void sendMeetingActionMessage(/** Meeting meeting, String organizerEmail, String organizerName */) {
        ApplicationProperties.ActionableMessage config = applicationProperties.getActionableMessage();
        if (!config.isEnabled()) {
            log.info("Actionable message send skipped because the feature is disabled.");
            return;
        }

        if (isBlank(config.getOriginatorId()) || isBlank(config.getCheckInMeetingUrl()) || isBlank(config.getCancelMeetingUrl())) {
            log.warn("Skipping actionable message send due to incomplete configuration | hasOriginatorId={} | hasCheckInUrl={} | hasCancelUrl={}",
                !isBlank(config.getOriginatorId()),
                !isBlank(config.getCheckInMeetingUrl()),
                !isBlank(config.getCancelMeetingUrl()));
            return;
        }

        if (!isValidActionableUrl(config.getCheckInMeetingUrl()) || !isValidActionableUrl(config.getCancelMeetingUrl())) {
            log.warn("Actionable card URLs are not production-ready. Configure absolute HTTPS public URLs for check-in/cancel actions. checkInMeetingUrl={} cancelMeetingUrl={}",
                config.getCheckInMeetingUrl(),
                config.getCancelMeetingUrl());
        }

        // return;
        // }

        log.info("Preparing actionable meeting message | meetingId={} | organizerEmail={} | senderEmail={}", "abcdef", "harendra.sah@capgemini.com", config.getSenderEmail());

        //actionableMessageAuthenticationService.validatePingIdAuthenticatedOrganizer("harendra.sah@capgemini.com");

        String adaptiveCard = buildAdaptiveCard(meetingId, organizerEmail, organizerName);
        String emailBody = buildEmailBody(adaptiveCard);
        smtpSendMail.createAndSendGraphMessage(emailBody);

        //String emailBody = buildEmailBody("send mail for test Harendra!!!!!!!");
        //smtpSendMail.createAndSendGraphMessage("emailBody for test Harendra!!!!");
        log.info("Actionable meeting message sent | meetingId={} | organizerEmail={} | subject={}", meetingId, organizerEmail, subjecttest);
    }

    

    
    public void sendMeetingActionMessageBackup(Meeting meeting, String organizerEmail, String organizerName) {
        ApplicationProperties.ActionableMessage config = applicationProperties.getActionableMessage();
        if (!config.isEnabled()) {
            log.info("Actionable message send skipped because the feature is disabled.");
            return;
        }

        if (meeting == null || isBlank(organizerEmail) || isBlank(config.getOriginatorId()) || isBlank(config.getSenderEmail()) || isBlank(config.getCheckInMeetingUrl()) || isBlank(config.getCancelMeetingUrl())) {
            log.warn("Skipping actionable message send because the meeting or configuration is incomplete | meetingId={} | organizerEmail={} | senderEmail={} | hasOriginatorId={} | hasCheckInUrl={} | hasCancelUrl={}",
                meeting == null ? null : meeting.getId(),
                organizerEmail,
                config.getSenderEmail(),
                !isBlank(config.getOriginatorId()),
                !isBlank(config.getCheckInMeetingUrl()),
                !isBlank(config.getCancelMeetingUrl())
            );
            return;
        }

        log.info("Preparing actionable meeting message | meetingId={} | organizerEmail={} | senderEmail={}", meeting.getId(), organizerEmail, config.getSenderEmail());

        //actionableMessageAuthenticationService.validatePingIdAuthenticatedOrganizer(organizerEmail);

        String adaptiveCard = buildAdaptiveCard(meeting.getId(), organizerEmail, organizerName);
        String emailBody = buildEmailBody(adaptiveCard);
        String subject = buildSubject(meeting);

        smtpSendMail.createAndSendGraphMessage(emailBody);
        log.info("Actionable meeting message sent | meetingId={} | organizerEmail={} | subject={}", meeting.getId(), organizerEmail, subject);
    }
    
    
    
    
    
    String buildAdaptiveCard(String meetingId, String organizerEmail, String organizerName) {
        try {
            String template = StreamUtils.copyToString(new ClassPathResource(TEMPLATE_PATH).getInputStream(), StandardCharsets.UTF_8);
            String checkInToken = actionTokenService.generateActionToken(meetingId, organizerEmail, ActionTokenService.CHECK_IN_PURPOSE);
            String cancelToken = actionTokenService.generateActionToken(meetingId, organizerEmail, ActionTokenService.CANCEL_MEETING_PURPOSE);
            JSONObject checkInActionBody = new JSONObject()
                .put("emailId", organizerEmail)
                .put("rating", "GREAT")
                .put("comment", "Action card check-in feedback for meetingId " + meetingId);
               // .put("bookingId", meetingId)
               // .put("actionToken", checkInToken);
            JSONObject cancelActionBody = new JSONObject()
                .put("emailId", organizerEmail)
                .put("rating", "POOR")
                .put("comment", "Action card cancel feedback for meetingId " + meetingId);
                //.put("bookingId", meetingId)
               // .put("actionToken", cancelToken);

            String cardTitle = "Meeting Action Required";
            String displayName = isBlank(organizerName) ? organizerEmail : organizerName;
            String description = "Hello " + displayName + ", use the SmartOffice actions below to check in or cancel your meeting";

            String renderedCard = template
                .replace("${ORIGINATOR_ID_JSON}", jsonStringContent(applicationProperties.getActionableMessage().getOriginatorId()))
                .replace("${CARD_TITLE_JSON}", jsonStringContent(cardTitle))
                .replace("${CARD_DESCRIPTION_JSON}", jsonStringContent(description))
                .replace("${DIAGNOSTIC_OPEN_URL_JSON}", jsonStringContent(applicationProperties.getActionableMessage().getCheckInMeetingUrl()))
                .replace("${CHECKIN_MEETING_URL_JSON}", jsonStringContent(applicationProperties.getActionableMessage().getCheckInMeetingUrl()))
                .replace("${CANCEL_MEETING_URL_JSON}", jsonStringContent(applicationProperties.getActionableMessage().getCancelMeetingUrl()))
                .replace("${CHECKIN_ACTION_BODY_JSON}", jsonStringContent(checkInActionBody.toString()))
                .replace("${CANCEL_ACTION_BODY_JSON}", jsonStringContent(cancelActionBody.toString()));

            // Validate rendered payload so malformed templates fail fast and don't send plain emails.
            new JSONObject(renderedCard);
            return renderedCard;
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to load the actionable message template.", ex);
        } catch (RuntimeException ex) {
            throw new IllegalStateException("Unable to render a valid adaptive card payload.", ex);
        }
    }

    String buildEmailBody(String adaptiveCard) {
        return "<html><body><script type=\"application/ld+json\">"
            + adaptiveCard
            + "</script></body></html>";
    }

    private String buildSubject(Meeting meeting) {
        String roomName = !isBlank(meeting.getPoiName()) ? meeting.getPoiName() : meeting.getRoom();
        return isBlank(roomName) ? "SmartOffice meeting action" : "SmartOffice actions for " + roomName;
    }

    private String jsonString(String value) {
        return JSONObject.quote(value == null ? "" : value);
    }

    private String jsonStringContent(String value) {
        String quoted = jsonString(value);
        return quoted.substring(1, quoted.length() - 1);
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private boolean isValidActionableUrl(String value) {
        if (isBlank(value)) {
            return false;
        }

        try {
            URI uri = new URI(value.trim());
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(scheme) || isBlank(host)) {
                return false;
            }

            String normalizedHost = host.toLowerCase();
            return !"localhost".equals(normalizedHost)
                    && !"127.0.0.1".equals(normalizedHost)
                    && !"::1".equals(normalizedHost);
        } catch (URISyntaxException ex) {
            return false;
        }
    }
}