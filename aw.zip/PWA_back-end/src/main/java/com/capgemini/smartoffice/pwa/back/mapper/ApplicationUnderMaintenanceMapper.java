package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenance;
import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenanceDTO;

@Named("ApplicationUnderMaintenanceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface ApplicationUnderMaintenanceMapper {

    ApplicationUnderMaintenanceMapper INSTANCE = Mappers.getMapper(ApplicationUnderMaintenanceMapper.class);

    ApplicationUnderMaintenance applicationUnderMaintenanceDTOToApplicationUnderMaintenance(ApplicationUnderMaintenanceDTO in);

    ApplicationUnderMaintenanceDTO applicationUnderMaintenanceToApplicationUnderMaintenanceDTO(ApplicationUnderMaintenance in);

}
