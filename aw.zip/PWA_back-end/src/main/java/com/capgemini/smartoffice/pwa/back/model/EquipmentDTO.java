package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class EquipmentDTO implements WithTitleDTO {
    private Long id;
	private String name;
	private String titleFr;
	private String titleEn;
    private String title;
    private Long poisCount;
}
