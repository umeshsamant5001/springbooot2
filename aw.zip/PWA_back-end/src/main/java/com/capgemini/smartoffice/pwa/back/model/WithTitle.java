package com.capgemini.smartoffice.pwa.back.model;

public interface WithTitle {
    String getTitleFr();

    String getTitleEn();
}
