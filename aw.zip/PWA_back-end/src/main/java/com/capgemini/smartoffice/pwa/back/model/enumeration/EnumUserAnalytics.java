package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum EnumUserAnalytics {

    LOGIN, DELETE, EDIT, ADD, VIEW;
	
	public static EnumUserAnalytics findByName(String name) {
		EnumUserAnalytics result = null;
		for (EnumUserAnalytics userAnalytics : values()) {
			if (userAnalytics.name().equalsIgnoreCase(name)) {
				result = userAnalytics;
				break;
			}
		}
		return result;
	}
    
    
}
