package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.ColumnDefault;
import com.capgemini.smartoffice.pwa.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.CollectionTable;
import lombok.Data;
import javax.persistence.ElementCollection;
import javax.persistence.EnumType;
import java.util.ArrayList;
import java.util.List;

//TODO change model and table name, TBD, create Controller
@Data
@Entity
@Table(name = "admin_menu_page")
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class FrontPage {

	private static final long serialVersionUID = 8525407737252412465L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FrontPage_Generator")
	@SequenceGenerator(name="FrontPage_Generator", sequenceName = "FrontPage_Sequence")
	private Long id;

	@Column(name = "title")
	private String title;

	@Column(name = "path")
	private String path;

	@Column(name = "icon")
	private String icon;

	@Column(name = "htmlclass")
	private String htmlclass;

	@Column(name = "is_external_link")
	private Boolean isExternalLink;
	// this is the index in the sidebar menu
	@Column(name = "menu_index",nullable = false)
	@ColumnDefault("50")
	private Integer index;

	@ManyToOne
    @JoinColumn(name="parent_id") @JsonIgnore
    private FrontPage parent;
    @Column(name="parent_id", updatable=false,insertable=false)
	private Long parentId;

    @Column(name = "is_header_menu")
    private Integer isheadermenu;

    @ElementCollection(targetClass = EnumPrivilege.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "admin_menu_page_privilege", joinColumns = @JoinColumn(name = "admn_menu_page_id"))
    @Column(name = "privile", nullable = false)
    @Enumerated(EnumType.STRING)
    private List<EnumPrivilege> priviles = new ArrayList<>();
}
