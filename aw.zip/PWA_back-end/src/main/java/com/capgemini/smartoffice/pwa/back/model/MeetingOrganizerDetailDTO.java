package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class MeetingOrganizerDetailDTO {
    private Long id;
    private String organizerEmail;
    private String organizerName;
    private String meetingId;
    private Long createdDateTime;
    private String createdFrom;
}