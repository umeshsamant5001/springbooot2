/**
 * 
 */
package com.capgemini.smartoffice.pwa.back.model.enumeration;

/**
 * Enum type use to represent the state of a device
 * 
 * @author alcarpen
 *
 */
public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}
