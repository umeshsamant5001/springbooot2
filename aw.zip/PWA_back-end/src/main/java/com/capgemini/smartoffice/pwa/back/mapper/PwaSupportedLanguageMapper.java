package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.PwaSupportedLanguage;
import com.capgemini.smartoffice.pwa.back.model.PwaSupportedLanguageDTO;

@Mapper (config = DtoMapperConfig.class)
public interface PwaSupportedLanguageMapper {

    PwaSupportedLanguageMapper INSTANCE = Mappers.getMapper(PwaSupportedLanguageMapper.class);

    PwaSupportedLanguageDTO pwaSupportedLanguageTOPwaSupportedLanguageDTO(PwaSupportedLanguage in);

    PwaSupportedLanguage pwaSupportedLanguageDTOTOPwaSupportedLanguage(PwaSupportedLanguageDTO in);
}
