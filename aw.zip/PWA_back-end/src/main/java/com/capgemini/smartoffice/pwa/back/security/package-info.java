/**
 * Spring Security configuration.
 */
package com.capgemini.smartoffice.pwa.back.security;
