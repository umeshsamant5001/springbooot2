package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.MapperConfig;
import org.mapstruct.MappingInheritanceStrategy;
import com.capgemini.smartoffice.pwa.utils.LazyFieldCondition;

/**
 * <p>General configuration for mapper.</p>
 * <p>Need to add on each mapper :</p>
 * <p>
 * <pre><code class='java'>
 * &#64;Mapper(config = DtoMapperConfig.class, uses = { FloorMapper.class, SiteMapper.class })
 * public interface MyMapper {
 *   ...
 * }
 * </code></pre>
 * </p>
 */
@MapperConfig(
        uses = { WithTitleMapper.class, LazyFieldCondition.class },
    mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG
)
public interface DtoMapperConfig {
}