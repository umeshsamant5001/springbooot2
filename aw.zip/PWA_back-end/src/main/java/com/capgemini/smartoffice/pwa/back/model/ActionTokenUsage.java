package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "action_token_usage")
public class ActionTokenUsage {

    @Id
    @Column(name = "token_id", nullable = false)
    private String tokenId;

    @Column(name = "action_name", nullable = false)
    private String actionName;

    @Column(name = "booking_id", nullable = false)
    private String bookingId;

    @Column(name = "organizer_email", nullable = false)
    private String organizerEmail;

    @Column(name = "used_at", nullable = false)
    private Long usedAt;
}