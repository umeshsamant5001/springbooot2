package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class UserFeedbackCreateRequest {

    @NotNull
    @Size(min = 1, max = 320)
    private String emailId;

    @NotNull
    private Rating rating;

    @Size(max = 1000)
    private String comment;
}
