package com.capgemini.smartoffice.pwa.back.service;

import java.time.Instant;
import java.util.regex.Pattern;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.smartoffice.pwa.back.model.SafeUserFeedbackData;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

import com.capgemini.smartoffice.pwa.back.model.UserFeedbackDTO;

import com.capgemini.smartoffice.pwa.back.mapper.UserFeedbackMapper;
import com.capgemini.smartoffice.pwa.back.model.UserFeedback;
import com.capgemini.smartoffice.pwa.back.repository.UserFeedbackRepository;


import java.util.Optional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserFeedbackService {

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");


    @Autowired
    private UserFeedbackRepository userFeedbackRepository;

    @Autowired
    private UserFeedbackBindingService userFeedbackBindingService;

    @Transactional
    public UserFeedbackDTO createUserFeedback(
            SafeUserFeedbackData request) {

        log.info("USER_FEEDBACK_CREATE_START");

        if (request == null) {
            log.warn("USER_FEEDBACK_CREATE_REJECTED | reason=Payload is null");
            throw new IllegalArgumentException(
                    "User feedback payload is required");
        }

        SafeUserFeedbackData safeRequest = userFeedbackBindingService
                .buildSafeUserFeedbackData(
                        request.getEmailId(),
                        request.getRating(),
                        request.getRatingFrom(),
                        request.getComment(),
                        true);

        String validatedEmailId = safeRequest.getEmailId();
        RatingFrom resolvedRatingFrom = safeRequest.getRatingFrom();

        if (userFeedbackRepository
                .existsByEmailIdAndRatingFrom(
                        validatedEmailId,
                        resolvedRatingFrom)) {

            log.warn(
                    "USER_FEEDBACK_CREATE_REJECTED | emailId={} | ratingFrom={} | reason=Already exists",
                    validatedEmailId,
                    resolvedRatingFrom);

            throw new IllegalArgumentException(
                    "Feedback already exists for emailId: "
                            + validatedEmailId
                            + " and ratingFrom: "
                            + resolvedRatingFrom);
        }

        UserFeedback userFeedback = new UserFeedback();

        long now = Instant.now().getEpochSecond();

        userFeedbackBindingService.applySafeValues(
                userFeedback,
                safeRequest,
                true,
                now);


        UserFeedback savedFeedback = userFeedbackRepository
                .save(userFeedback);


        log.info(
                "USER_FEEDBACK_SAVED | emailId={} | ratingFrom={}",
                savedFeedback.getEmailId(),
                savedFeedback.getRatingFrom());

        return UserFeedbackMapper.INSTANCE
                .userFeedbackToUserFeedbackDTO(
                        savedFeedback);
    }
    
    public Optional<UserFeedbackDTO> getUserFeedback(
        String emailId,
        RatingFrom ratingFrom) {

        log.info("USER_FEEDBACK_GET_START | emailId={} | ratingFrom={}", emailId, ratingFrom);
    
        final RatingFrom resolvedRatingFrom =
                (ratingFrom == null) ? RatingFrom.WEB_PORTAL : ratingFrom;
    
        return userFeedbackRepository
                .findByEmailIdAndRatingFrom(
                        emailId.trim(),
                        resolvedRatingFrom)
                .map(feedback -> {
                    log.info(
                            "USER_FEEDBACK_FOUND | emailId={} | ratingFrom={}",
                            emailId,
                            resolvedRatingFrom);
    
                    return UserFeedbackMapper.INSTANCE
                            .userFeedbackToUserFeedbackDTO(feedback);
                });
        }

    @Transactional
    public UserFeedback updateUserFeedback(
            SafeUserFeedbackData request) {

        log.info("USER_FEEDBACK_UPDATE_START");

        if (request == null) {
            log.warn("USER_FEEDBACK_UPDATE_REJECTED | reason=Payload is null");
            throw new IllegalArgumentException(
                    "User feedback payload is required");
        }

        SafeUserFeedbackData safeRequest = userFeedbackBindingService
                .buildSafeUserFeedbackData(
                        request.getEmailId(),
                        request.getRating(),
                        request.getRatingFrom(),
                        request.getComment(),
                        false);

        String validatedEmailId = safeRequest.getEmailId();
        if (!isValidEmail(validatedEmailId)) {
                        log.warn("USER_FEEDBACK_UPDATE_REJECTED | reason=Invalid emailId format");
            throw new IllegalArgumentException(
                    "Invalid emailId format");
        }

        String safeValidatedEmailId = new String(String.valueOf(validatedEmailId));

        RatingFrom validatedRatingFrom = safeRequest.getRatingFrom();

        UserFeedback existingFeedback = userFeedbackRepository
                .findByEmailIdAndRatingFrom(
                        safeValidatedEmailId,
                        validatedRatingFrom)

                .orElseThrow(() -> new IllegalArgumentException(
                        "Feedback record not found"));

        userFeedbackBindingService.applySafeValues(
                existingFeedback,
                safeRequest,
                false,
                Instant.now().getEpochSecond());


        UserFeedback updatedFeedback = userFeedbackRepository
                .save(existingFeedback);

        log.info(
                "USER_FEEDBACK_UPDATED | emailId={} | ratingFrom={}",
                updatedFeedback.getEmailId(),
                updatedFeedback.getRatingFrom());

        return updatedFeedback;
    }


    private boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

}