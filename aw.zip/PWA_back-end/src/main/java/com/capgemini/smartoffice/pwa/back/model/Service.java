package com.capgemini.smartoffice.pwa.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "service")
public class Service {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Service_Generator")
	@SequenceGenerator(name = "Service_Generator", sequenceName = "Service_Sequence")
	private Long id;

    @Column(name = "name")
	private String name;

	@Column(name = "image")
	private String image;
    
    @Column(name = "priority")
    private Integer priority;

	@CollectionTable(name = "service_attribute", joinColumns = @JoinColumn(name = "service_id", referencedColumnName = "id"))
	@Fetch(FetchMode.SUBSELECT)
	@ElementCollection(fetch = FetchType.EAGER)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

	@OneToMany(mappedBy = "service", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	private List<ServiceLocation> locations = new ArrayList<>();

	@OneToMany(mappedBy = "service", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	private List<ServiceTranslation> translations = new ArrayList<>();

}