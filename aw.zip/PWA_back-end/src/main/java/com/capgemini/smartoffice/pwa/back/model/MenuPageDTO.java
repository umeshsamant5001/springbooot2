package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class MenuPageDTO implements  WithTitleDTO {
    private Long id;
	private String titleFr;
	private String titleEn;
    private String title;
	private String icon;
	private Boolean isExternalLink;
	private Integer index;
	private Long parentId;
    private MenuPageDTO parent;
}
