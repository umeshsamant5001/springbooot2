package com.capgemini.smartoffice.pwa.back.controller;

import java.util.List;
import java.util.stream.Collectors;
import com.capgemini.smartoffice.pwa.back.mapper.ScreenMapper;
import com.capgemini.smartoffice.pwa.back.model.ScreenDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.model.Screen;
import com.capgemini.smartoffice.pwa.back.service.ScreenService;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = ScreensController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ScreensController {

    static final String ROOT_API = "api/screen";

    @Autowired
    private ScreenService screenService;

    @GetMapping
    public ResponseEntity<List<ScreenDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Screen> screens = this.screenService.findAll();
        List<ScreenDTO> screenDTOs = screens
            .stream()
            .map(screen -> ScreenMapper.INSTANCE.screenToScreenDTO(screen, language))
            .collect(Collectors.toList());

        return ResponseEntity.ok(screenDTOs);
    }

}
