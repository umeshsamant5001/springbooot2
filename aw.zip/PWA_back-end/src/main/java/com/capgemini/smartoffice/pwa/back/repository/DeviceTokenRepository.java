package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.smartoffice.pwa.back.model.AppRegistrationManagement;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;
import java.util.List;
import java.util.Optional;

public interface DeviceTokenRepository extends JpaRepository<AppRegistrationManagement, Long> {

    List<AppRegistrationManagement> findByDeviceType(EnumFcmDeviceType deviceType);

    AppRegistrationManagement findByEmailId(String emailId);

    @Query(value = "SELECT TOP 1 * " + 
                " FROM app_registration_management " + 
                " WHERE email_id = :emailId" + 
                " ORDER BY updated_date_time DESC ", nativeQuery = true)
    AppRegistrationManagement findByEmailIdWithUpdatedDateTime(@Param("emailId") String emailId);

    boolean existsByDeviceIdAndDeviceRegistrationToken(String deviceId, String deviceRegistrationToken);

    Optional<AppRegistrationManagement> findByDeviceId(String deviceId);
    
}