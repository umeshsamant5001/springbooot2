package com.capgemini.smartoffice.pwa.back.model;

public enum TimeFormat {
    HOUR_12, HOUR_24;
}
