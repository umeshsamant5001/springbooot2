package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumUserAnalytics;

import lombok.Data;

@Data
@Entity
@Table(name = "user_analytic", uniqueConstraints = { @UniqueConstraint(columnNames = { "id"}) })
public class UserAnalytics {
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "UserAnalytics_Generator")
	@SequenceGenerator(name = "UserAnalytics_Generator", sequenceName = "UserAnalytics_Sequence")
	private Long id;

    @Column(name = "app_User")
	private String appUser;

    @Column(name = "module_Name")
	private String moduleName;

    @Column(name = "activity")
	private String activity;

    @Column(name = "activity_Date")
	private Long activityDate;

    @Column(name = "platform")
	private String platform;

    @Column(name = "user_Analytics")
	private EnumUserAnalytics userAnalytics;

	@Column(name = "parent_id")
	private Long parentId;   

    @Column(name = "email")
	private String email;
	
    @Column(name="country")
	private String country;

    @Column(name="country_id")
	private Long country_id;
}
