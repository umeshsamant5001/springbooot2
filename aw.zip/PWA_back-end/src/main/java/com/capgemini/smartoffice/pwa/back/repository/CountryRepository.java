package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

	@Query(value = "SELECT distinct c.* FROM sw_countries c JOIN sw_cities ci ON ci.country_id=c.id JOIN sw_sites s ON s.city_id=ci.id JOIN sw_buildings b ON b.site_id = s.id WHERE b.deployed=true", nativeQuery = true)
	List<Country> findAllDeployed();

	@Query(value = "SELECT distinct c.* FROM sw_countries c JOIN sw_cities ci ON ci.country_id=c.id JOIN sw_sites s ON s.city_id=ci.id JOIN sw_buildings b ON b.site_id = s.id WHERE b.deployed=true AND b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUnsecured();

	@Query(value = "SELECT distinct c.* FROM sw_countries c LEFT JOIN sw_cities ci ON ci.country_id=c.id LEFT JOIN sw_sites s ON s.city_id=ci.id LEFT JOIN sw_buildings b ON b.site_id = s.id", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployed();

	@Query(value = "SELECT distinct c.* FROM sw_countries c LEFT JOIN sw_cities ci ON ci.country_id=c.id LEFT JOIN sw_sites s ON s.city_id=ci.id LEFT JOIN sw_buildings b ON b.site_id = s.id WHERE b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployedAndUnsecured();

	Country findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	Optional<Country> findByTitleEnIgnoreCase(String titleEn);

	@Query("SELECT building.id, country.titleEn AS name FROM Country country INNER JOIN country.cities city INNER JOIN city.sites site INNER JOIN site.buildings building WHERE building.id IN (:buildingIds)")
	List<Tuple> getCountryNameByBuildingIds(@Param("buildingIds") List<Long> buildingIds);

	@Query(value = "SELECT * FROM country WHERE title_en = :countryName", nativeQuery = true)
	Country findByCountryName(@Param("countryName") String countryName);
}
