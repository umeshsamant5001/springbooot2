package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.MenuPage;
import com.capgemini.smartoffice.pwa.back.model.MenuPageDTO;

@Mapper(config = DtoMapperConfig.class)
public interface MenuPageMapper {
    
    MenuPageMapper INSTANCE = Mappers.getMapper(MenuPageMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "parent", target = "parent", qualifiedByName = { "menuPageToMenuPageDTOWithoutChildren" }),
    })
    MenuPageDTO menupageToMenuPageDTO(MenuPage in, @Context String language);

    MenuPage menupageDTOToMenuPage(MenuPageDTO in);

    @Named("menuPageToMenuPageDTOWithoutChildren")
    default MenuPageDTO _menuPageToMenuPageDTOWithoutChildren(MenuPage in, @Context String language) {
        return Mappers.getMapper(MenuPageMapper.class)._toMenuPageDTOWithoutChildren(in, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>The function map a Building to a Building DTO but without mapping the parent (Site).</p>
     */
    @Named("toMenuPageDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "parent", ignore = true)
    })
    MenuPageDTO _toMenuPageDTOWithoutChildren(MenuPage in, @Context String language);

}
