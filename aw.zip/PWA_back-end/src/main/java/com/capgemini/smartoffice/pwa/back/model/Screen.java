package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Data;

@Data
@Entity
@Table(name = "screen", uniqueConstraints = { @UniqueConstraint(columnNames = { "id"}) })
public class Screen implements WithTitle{

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Screens_Generator")
	@SequenceGenerator(name = "Screens_Generator", sequenceName = "Screens_Sequence")
	private Long id;

    @Column(name = "title_fr")
	private String titleFr;

	@Column(name = "title_en")
	private String titleEn;

    @Column(name = "description_fr")
	private String descriptionFr;

	@Column(name = "description_en")
	private String descriptionEn;

    @Column(name = "image")
	private String image;

    @Column(name = "page_number")
	private Integer pageNumber;    
}

