package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum EnumFcmDeviceType {
    ANDROID, IOS;
}
