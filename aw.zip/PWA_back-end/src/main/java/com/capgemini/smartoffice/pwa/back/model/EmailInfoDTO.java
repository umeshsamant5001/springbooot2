package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class EmailInfoDTO {
    private int id;
    private int buildingId;
    private String buildingName;
    private int floorId;
    private String floorName;
    private String poiName;
    private String email;
}
