package com.capgemini.smartoffice.pwa.back.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.smartoffice.pwa.back.model.ConfigValue;
import com.capgemini.smartoffice.pwa.back.repository.ConfigRepository;

@Service
public class ConfigService {

    @Autowired
    private ConfigRepository configRepository;

    public ConfigValue findByKeyName(String keyName) {
        return this.configRepository.findByKeyName(keyName);
    }
}
