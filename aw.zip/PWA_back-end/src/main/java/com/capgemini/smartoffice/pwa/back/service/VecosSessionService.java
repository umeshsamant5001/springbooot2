package com.capgemini.smartoffice.pwa.back.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.VecosSession;


@Service
public class VecosSessionService {

    private Map<String, VecosSession> session = new HashMap<>();

    public VecosSession getSession(String tenant) {
        return this.session.getOrDefault(tenant, null);
    }

    public void setSession(String tenant, VecosSession session) {
        this.session.put(tenant, session);
    }
}