package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.UserAnalytics;

@Repository
public interface UserAnalyticsRepository extends JpaRepository<UserAnalytics, Long> {

}
