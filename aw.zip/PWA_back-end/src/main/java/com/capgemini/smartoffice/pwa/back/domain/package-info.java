/**
 * JPA domain objects.
 */
package com.capgemini.smartoffice.pwa.back.domain;
