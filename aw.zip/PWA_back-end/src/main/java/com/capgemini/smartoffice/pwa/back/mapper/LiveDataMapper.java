package com.capgemini.smartoffice.pwa.back.mapper;

import java.util.Objects;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.LiveDataDTO;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceAttribute;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;

@Mapper(config = DtoMapperConfig.class)
public interface LiveDataMapper {

    LiveDataMapper INSTANCE = Mappers.getMapper(LiveDataMapper.class);

    @Mapping(source = "deviceType", target = "deviceType", qualifiedByName = "toDeviceType")
    @Mapping(source = "floor.id", target = "floorId")
    @Mapping(source = ".", target = "lastOccupiedDate", qualifiedByName = "toLastOccupied")
    @Mapping(source = ".", target = "co2", qualifiedByName = "toCo2")
    @Mapping(source = ".", target = "humidity", qualifiedByName = "toHumidity")
    @Mapping(source = ".", target = "tempc", qualifiedByName = "toTempC")
    @Mapping(source = ".", target = "tempf", qualifiedByName = "toTempF")
    @Mapping(source = ".", target = "lux", qualifiedByName = "toLux")
    @Mapping(source = ".", target = "sound", qualifiedByName = "toSound")
    @Mapping(source = ".", target = "vdd", qualifiedByName = "toVdd")
    @Mapping(source = ".", target = "vddPct", qualifiedByName = "toVddPct")
    @Mapping(source = ".", target = "occupation", qualifiedByName = "toOccupation")
    LiveDataDTO deviceToLiveDataDTO(Device in);

    @Named("toDeviceType")
    default String mapToDeviceType(EnumDeviceType deviceType) {
        return deviceType.toString();
    }

    @Named("toLastOccupied")
    default String mapToLastOccupied(Device device) {
        return (
                Objects.nonNull(device.getAttributes()) &&
                device.getAttributes().containsKey(EnumDeviceAttribute.LAST_OCCUPIED_DATE.toString())
            )
            ? device.getAttributes().get(EnumDeviceAttribute.LAST_OCCUPIED_DATE.toString())
            : null;
    }

    @Named("toCo2")
    default String mapToCo2(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.CO2.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.CO2.toString())
            : null;
    }

    @Named("toHumidity")
    default String mapToHumidity(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.HUMIDITY.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.HUMIDITY.toString())
            : null;
    }

    @Named("toTempC")
    default String mapToTempC(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.TEMPC.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.TEMPC.toString())
            : null;
    }

    @Named("toTempF")
    default String mapToTempF(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.TEMPF.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.TEMPF.toString())
            : null;
    }

    @Named("toOccupation")
    default String mapToOccupation(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.OCCUPATION.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.OCCUPATION.toString())
            : null;
    }

    @Named("toSound")
    default String mapToSound(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.SOUND.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.SOUND.toString())
            : null;
    }

    @Named("toLux")
    default String mapToLux(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.LUX.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.LUX.toString())
            : null;
    }

    @Named("toVdd")
    default String mapToVdd(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.VDD.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.VDD.toString())
            : null;
    }

    @Named("toVddPct")
    default String mapToVddPct(Device device) {
        return Objects.nonNull(device.getAttributes()) && device.getAttributes().containsKey(EnumDeviceAttribute.VDD_PCT.toString())
            ? device.getAttributes().get(EnumDeviceAttribute.VDD_PCT.toString())
            : null;
    }

}
