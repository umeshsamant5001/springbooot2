package com.capgemini.smartoffice.pwa.back.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.SequenceGenerator;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.CascadeType;
import com.capgemini.smartoffice.pwa.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * Entity class representing a role in the application.
*/
@Entity
@Data
@Table(name = "role", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Role {

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Role_Generator")
	@SequenceGenerator(name = "Role_Generator", sequenceName = "Role_Sequence")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "precedence")
    private Long precedence;

    @Column(name = "is_active")
    private Boolean isActive;

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "role_feature_access",
        joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "feature_access_id", referencedColumnName = "id")
    )
    private List<FeatureAccess> featureAccesses = new ArrayList<>();
}
