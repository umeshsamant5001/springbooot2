package com.capgemini.smartoffice.pwa.utils;

/**
 * Interface for Function but with Exception
 */
@FunctionalInterface
public interface CheckedFunction<T, R, E extends Exception> {
    R apply(T t) throws E;
 }