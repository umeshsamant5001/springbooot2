package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.Screen;
import com.capgemini.smartoffice.pwa.back.model.ScreenDTO;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Named("ScreenMapper")
@Mapper(config = DtoMapperConfig.class)
public interface ScreenMapper {
    
    ScreenMapper INSTANCE = Mappers.getMapper(ScreenMapper.class);

    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
    ScreenDTO screenToScreenDTO(Screen in, @Context String language);

    Screen screenDTOToScreen(ScreenDTO in);
}