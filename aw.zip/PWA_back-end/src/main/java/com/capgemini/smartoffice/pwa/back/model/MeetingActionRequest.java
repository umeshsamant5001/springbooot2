package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class MeetingActionRequest {
    private String bookingId;
    private String actionToken;
}