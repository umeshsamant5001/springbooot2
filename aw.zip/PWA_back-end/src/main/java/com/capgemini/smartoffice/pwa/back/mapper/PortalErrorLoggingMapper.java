package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.PortalErrorLogging;
import com.capgemini.smartoffice.pwa.back.model.PortalErrorLoggingDTO;

@Mapper(config = DtoMapperConfig.class)
public interface PortalErrorLoggingMapper {

    PortalErrorLoggingMapper INSTANCE = Mappers.getMapper(PortalErrorLoggingMapper.class);
    
    PortalErrorLogging portalErrorLoggingDTOToEntity(PortalErrorLoggingDTO in);

    PortalErrorLoggingDTO portalErrorLoggingToDTO(PortalErrorLogging in);
}