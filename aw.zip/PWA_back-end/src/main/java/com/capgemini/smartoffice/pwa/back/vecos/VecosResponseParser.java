package com.capgemini.smartoffice.pwa.back.vecos;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.smartoffice.pwa.back.model.VecosLockerBank;
import com.capgemini.smartoffice.pwa.back.model.VecosSession;
import com.capgemini.smartoffice.pwa.back.model.exception.UnauthorizedException;
import com.capgemini.smartoffice.pwa.back.model.exception.VecosConnectorException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class VecosResponseParser {

    @Autowired
    private ObjectMapper objectMapper;

    // Read authentication api response
    public VecosSession readAuthenticateRes(CloseableHttpResponse res) throws UnauthorizedException {
        String apiName = "AuthenticateAccess";
        this.validateStatusCode(res, HttpStatus.SC_OK, "authenticate");

        return mapResult(res, new TypeReference<VecosSession>() {
        }, apiName);
    }

    // Read locker bank status api response
    public VecosLockerBank readVecosLockerBankStatus(CloseableHttpResponse res) throws UnauthorizedException {
        String apiName = "VecosLockerBankStatus";
        this.validateStatusCode(res, HttpStatus.SC_OK, apiName);

        return mapResult(res, new TypeReference<VecosLockerBank>() {
        }, apiName);
    }

    // Function that verifies status code but does not interrupt execution
    private void validateStatusCode(CloseableHttpResponse res, int expectedStatusCode, String apiName) {
        int statusCode = res.getStatusLine().getStatusCode();

        if (expectedStatusCode != statusCode) {
            String responseBody = "";
            try {
                responseBody = EntityUtils.toString(res.getEntity(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                log.warn("Unable to read response body for status code {} in {}", statusCode, apiName, e);
            }

            log.warn("Unexpected status code [{}] for API [{}]. Response body: [{}]", statusCode, apiName,
                    responseBody);

            if (statusCode == HttpStatus.SC_UNAUTHORIZED) {
                log.warn("Unauthorized access detected for API [{}]. Consider refreshing credentials.", apiName);
            } else if (statusCode == HttpStatus.SC_NOT_FOUND) {
                log.warn("Resource not found (404) for API [{}]. Check endpoint or resource existence.", apiName);
            } else {
                readErrorBody(res, statusCode, apiName); // Optional: keep this if it logs or handles errors internally
            }
        }
    }

    // Function that Log error body response
    private void readErrorBody(CloseableHttpResponse res, int statusCode, String apiName) {
        String body = null;
        if (Objects.nonNull(res.getEntity())) {
            try {
                body = EntityUtils.toString(res.getEntity(), "UTF-8");
            } catch (ParseException | IOException e) {
                body = "unreadable body";
            }
        }
        throw new VecosConnectorException(
                String.format("Vecos [%s] ws unexpected status code:[%d] body:[%s]", apiName, statusCode, body));
    }

    // Map api response to an object
    private <T> T mapResult(CloseableHttpResponse res, TypeReference<T> typeReference, String apiName) {
        HttpEntity entity = res.getEntity();
        if (Objects.isNull(entity)) {
            log.warn("Vecos {} response - no HTTP entity found", apiName);
            return null;
        }

        try (InputStream is = entity.getContent()) {
            if (is.available() == 0) {
                log.warn("Vecos {} response - empty body", apiName);
                return null;
            }

            return objectMapper.readValue(is, typeReference);
        } catch (IOException | UnsupportedOperationException e) {
            log.warn("Vecos {} response - failed to map body to {} - error: {}", apiName,
                     typeReference.getType().getTypeName(), e.getMessage());
            return null;
        }
    }

}
