package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.capgemini.smartoffice.pwa.back.model.MeetingActionRequest;
import com.capgemini.smartoffice.pwa.back.service.ActionTokenService;
import com.capgemini.smartoffice.pwa.back.service.ActionableMessageService;
import com.capgemini.smartoffice.pwa.back.service.MeetingService;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.CONFLICT;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestController
@Slf4j
@RequestMapping(value = "/api", produces = APPLICATION_JSON_VALUE)
public class MeetingActionController {

    private final ActionTokenService actionTokenService;
    private final MeetingService meetingService;
    @Autowired 
    private ActionableMessageService actionableMessageService;

    public MeetingActionController(ActionTokenService actionTokenService, MeetingService meetingService) {
        this.actionTokenService = actionTokenService;
        this.meetingService = meetingService;
    }

    @PostMapping("/testAdaptiveCard")
    public ResponseEntity<Void> testAdaptiveCard() {
        log.info("Before Triggering test actionable meeting message");
        actionableMessageService.sendMeetingActionMessage();
        log.info("After Triggering test actionable meeting message");
        return ResponseEntity.ok().build();
    }
    
    @PostMapping("/checkin")
    public ResponseEntity<Map<String, String>> checkInMeeting(@RequestBody MeetingActionRequest request) {
        return processAction(request, ActionTokenService.CHECK_IN_PURPOSE, bookingId -> meetingService.checkInMeeting(bookingId));
    }

    @PostMapping("/cancel")
    public ResponseEntity<Map<String, String>> cancelMeeting(@RequestBody MeetingActionRequest request) {
        return processAction(request, ActionTokenService.CANCEL_MEETING_PURPOSE, bookingId -> meetingService.cancelMeeting(bookingId));
    }

    private ResponseEntity<Map<String, String>> processAction(
        MeetingActionRequest request,
        String expectedPurpose,
        java.util.function.Consumer<String> action
    ) {
        String bookingId = request == null || request.getBookingId() == null ? null : request.getBookingId().trim();
        String actionToken = request == null || request.getActionToken() == null ? null : request.getActionToken().trim();

        log.info("Meeting action request received | purpose={} | bookingId={}", expectedPurpose, bookingId);

        try {
            String organizerEmail = meetingService.getOrganizerEmail(bookingId);
            actionTokenService.consumeActionToken(actionToken, bookingId, organizerEmail, expectedPurpose);
            action.accept(bookingId);
            log.info("Meeting action completed | purpose={} | bookingId={} | organizerEmail={}", expectedPurpose, bookingId, organizerEmail);
            String successMessage = ActionTokenService.CHECK_IN_PURPOSE.equals(expectedPurpose)
                ? "Meeting checked in successfully."
                : "Meeting cancelled successfully.";
            return buildOutlookActionResponse(HttpStatus.OK, successMessage, "OK");
        } catch (NoSuchElementException ex) {
            log.warn("Meeting action failed with missing data | purpose={} | bookingId={} | message={}", expectedPurpose, bookingId, ex.getMessage());
            return buildOutlookActionResponse(HttpStatus.OK, "Unable to process action: " + safeMessage(ex), "NOT_FOUND");
        } catch (IllegalStateException ex) {
            log.warn("Meeting action rejected due to state conflict | purpose={} | bookingId={} | message={}", expectedPurpose, bookingId, ex.getMessage());
            return buildOutlookActionResponse(HttpStatus.OK, "Action not allowed: " + safeMessage(ex), "CONFLICT");
        } catch (IllegalArgumentException ex) {
            log.warn("Meeting action rejected due to invalid request | purpose={} | bookingId={} | message={}", expectedPurpose, bookingId, ex.getMessage());
            return buildOutlookActionResponse(HttpStatus.OK, "Invalid action request: " + safeMessage(ex), "BAD_REQUEST");
        } catch (Exception ex) {
            log.error("Meeting action failed with unexpected error | purpose={} | bookingId={} | message={}", expectedPurpose, bookingId, ex.getMessage(), ex);
            return buildOutlookActionResponse(HttpStatus.OK, "Unexpected server error while processing action.", "INTERNAL_SERVER_ERROR");
        }
    }

    private ResponseEntity<Map<String, String>> buildOutlookActionResponse(HttpStatus status, String message, String code) {
        Map<String, String> body = new LinkedHashMap<>();
        body.put("status", code);
        body.put("message", message);

        return ResponseEntity.status(status)
            .header("CARD-ACTION-STATUS", message)
            .body(body);
    }

    private String safeMessage(Exception ex) {
        return ex.getMessage() == null || ex.getMessage().isBlank()
            ? "Unexpected issue occurred."
            : ex.getMessage();
    }
}