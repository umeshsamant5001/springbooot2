package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name = "meeting_organizer_detail")
public class MeetingOrganizerDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MeetingOrganizerDetail_Generator")
	@SequenceGenerator(name = "MeetingOrganizerDetail_Generator", sequenceName = "MeetingOrganizerDetail_Sequence")
    private Long id;
    @Column(name = "organizer_email")
    private String organizerEmail;
    @Column(name = "organizer_name")
    private String organizerName;

    @Column(name = "meeting_id", insertable = false, updatable = false)
    private String meetingId;

    @OneToOne
    @JoinColumn(name = "meeting_id", referencedColumnName = "id")
    private Meeting meeting;

    @Column(name = "created_date_time")
    private Long createdDateTime;
    @Column(name = "created_from")
    private String createdFrom;
}