package com.capgemini.smartoffice.pwa.back.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "app_maintenance_info")
public class ApplicationUnderMaintenance {

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ApplicationUnderMaintenance_Generator")
	@SequenceGenerator(name="ApplicationUnderMaintenance_Generator", sequenceName = "ApplicationUnderMaintenance_Sequence")
    private Long id;
    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date_time")
	private Long createdDateTime = (new Date()).getTime() / 1000;
    @Column(name = "end_date_time", nullable = false)
	private Long endDateTime = (new Date()).getTime() / 1000;;
    @Column(name = "start_date_time", nullable = false)
    private Long startDateTime = (new Date()).getTime() / 1000;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
    @Column(name = "message")
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform", nullable = false)
    private Platform platform;

}

