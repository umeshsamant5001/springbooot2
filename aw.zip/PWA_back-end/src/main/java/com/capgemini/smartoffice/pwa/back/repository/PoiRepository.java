package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.helper.Constants;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.Poi;

@Repository
public interface PoiRepository extends JpaRepository<Poi, Long> {
    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    List<Poi> findAllBySpaceTypeIdAndFloorBuildingId(@Param("spaceTypeId") Long spaceTypeId, @Param("buildingId") Long buildingId);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    List<Poi> findAllBySpaceTypeIdAndFloorId(@Param("spaceTypeId") Long spaceTypeId, @Param("floorId") Long floorId);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    List<Poi> findAllByFloorIdOrderByName(@Param("floorId") Long floorId);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    Poi findByName(@Param("name") String name);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    Poi findByFloorIdAndName(@Param("floorId") Long floorId, @Param("name") String name);

    /**
     * Return all Poi of a {@link Building}
     *
     * @param buildingId Id of the {@link Building}
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi FROM Poi poi " +
        "INNER JOIN poi.spaceType spaceType " +
        "INNER JOIN poi.floor floor " +
        "LEFT JOIN floor.attributes floorAttribute ON index(floorAttribute) = 'hidden' AND floorAttribute = 'true' " +
        "INNER JOIN floor.building building " +
        "WHERE building.id = :buildingId " +
        "AND floorAttribute IS NULL"
    )
    List<Poi> findAllByBuildingId(@Param("buildingId") Long buildingId);

    @RestResource(exported = false)
    @Query(
        value = "SELECT p.* " +
        "FROM poi p " +
        "JOIN space_type st ON p.space_type_id = st.id " +
        "JOIN poi_group pg ON st.poi_group_id = pg.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "INNER JOIN building b ON f.building_id = b.id " +
        "WHERE b.id = :buildingId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''",
        nativeQuery = true
    )
    List<Poi> findAllRoomsByBuildingIdAndAttributes(@Param("buildingId") Long buildingId);

    /**
     * Return all {@link Poi} of a {@link Building} and of certains poiGroups
     *
     * @param buildingId  Id of the {@link Building}
     * @param poiGroupList List of Poi poiGroup
     * @return
     */
    @RestResource(exported = false)
    @Query(
        value = "SELECT poi.* \r\n" + //
        "FROM poi poi \r\n" + //
        "INNER JOIN space_type st ON poi.space_type_id = st.id \r\n" + //
        "JOIN poi_group pg ON st.poi_group_id = pg.id\r\n" + //
        "INNER JOIN floor ON poi.floor_id = floor.id \r\n" + //
        "LEFT JOIN floor_attribute AS floorAttribute ON floorAttribute.att_key = 'hidden' AND floorAttribute.att_value = 'true' \r\n" + //
        "INNER JOIN building ON floor.building_id = building.id \r\n" + //
        "WHERE building.id = :buildingId \r\n" + //
        "AND pg.name IN (:poiGroupNames) \r\n" + //
        "AND floorAttribute.att_key IS NULL",
        nativeQuery = true
    )
    List<Poi> findAllByBuildingIdAndPoiGroups(@Param("buildingId") Long buildingId, @Param("poiGroupNames") List<String> poiGroupNames);

    /**
     * Return all {@link Poi} of a {@link Building} excepts those of certains poiGroups
     *
     * @param buildingId     Id of the {@link Building}
     * @param excludePoiGroup List of Poi poiGroup to exclude
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi " +
        " FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType INNER JOIN FETCH poi.floor floor INNER JOIN floor.building building " +
        " WHERE building.id = :buildingId AND spaceType.spaceTypeName NOT IN (:excludeSpaceType)"
    )
    List<Poi> findAllByBuildingIdExcludeSpaceType(
        @Param("buildingId") Long buildingId,
        @Param("excludeSpaceType") List<String> excludeSpaceType
    );

    /**
     * Return all {@link Poi} of a {@link Floor}
     *
     * @param buildingId Id of the {@link Floor}
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType INNER JOIN FETCH poi.floor floor " + " WHERE floor.id = :floorId"
    )
    List<Poi> findAllByFloorId(@Param("floorId") Long floorId);

    @RestResource(exported = false)
    @Query(
        value = "SELECT p.* " +
        "FROM poi p " +
        "INNER JOIN space_type st ON p.space_type_id = st.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "WHERE f.id = :floorId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''",
        nativeQuery = true
    )
    List<Poi> findAllRoomsByFloorId(@Param("floorId") Long floorId);

    /**
     * Return all {@link Poi} of a {@link Floor} and of certains poiGroups
     *
     * @param floorId     Id of the {@link Floor}
     * @param poiGroupList List of Poi poiGroup
     * @return
     */
    @RestResource(exported = false)
    @Query(
        value = "SELECT p.* FROM poi p JOIN space_type st ON p.space_type_id = st.id " +
        "JOIN poi_group pg ON st.poi_group_id = pg.id WHERE p.floor_id = :floorId AND pg.name IN :poiGroupNames",
        nativeQuery = true
    )
    List<Poi> findByPoiGroupNamesNative(@Param("floorId") Long floorId, @Param("poiGroupNames") List<String> poiGroupNames);

    @Query(
        value = "SELECT p.* " +
        "FROM poi p " +
        "JOIN space_type st ON p.space_type_id = st.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = p.floor_id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
        "WHERE p.floor_id = :floorId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> '' " +
        "AND cm.category = 'bookable'", // Check for 'bookable' category
        nativeQuery = true
    )
    List<Poi> findRoomsByFloorIdAndBookableCategory(@Param("floorId") Long floorId);

    @Query(
        value = "SELECT p.* " +
        "FROM poi p " +
        "JOIN space_type st ON p.space_type_id = st.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = p.floor_id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "INNER JOIN building b ON f.building_id = b.id " +
        "INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
        "WHERE b.id = :buildingId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> '' " +
        "AND cm.category = 'bookable'",
        nativeQuery = true
    )
    List<Poi> findRoomsByBuildingIdAndBookableCategory(@Param("buildingId") Long buildingId);

    /**
     * Return all {@link Poi} of a {@link Floor} excepts those of certains poiGroups
     *
     * @param floorId        Id of the {@link Floor}
     * @param excludePoiGroup List of Poi poiGroup to exclude
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi " +
        " FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType INNER JOIN FETCH poi.floor floor " +
        " WHERE floor.id = :floorId AND spaceType.spaceTypeName NOT IN (:excludeSpaceType)"
    )
    List<Poi> findAllByFloorIdExcludeSpaceType(@Param("floorId") Long floorId, @Param("excludeSpaceType") List<String> excludeSpaceType);

    List<Poi> findAllByNameIn(@Param("name") List<String> name);

    @Query(
        value = "SELECT DISTINCT poi.* FROM poi " +
        "INNER JOIN device ON poi.name = device.poi_name " +
        "INNER JOIN device_attributes attribute ON device.uuid = attribute.device_uuid " +
        "INNER JOIN floor floor ON poi.floor_id = floor.id " +
        "LEFT JOIN floor_attribute floorAttribute ON floor.id = floorAttribute.floor_id " +
        "AND floorAttribute.att_key = 'hidden' AND floorAttribute.att_value = 'true' " +
        "INNER JOIN building building ON floor.building_id = building.id " +
        "INNER JOIN space_type spaceType ON poi.space_type_id = spaceType.id " +
        "INNER JOIN poi_group poiGroup ON poiGroup.id = spaceType.poi_group_id "+
        "INNER JOIN category_mapping cm ON cm.space_type_id = spaceType.id " +
        "WHERE building.id = :buildingId " +
        "AND attribute.att_key = 'state' AND attribute.att_value = 'free' " +
        "AND floorAttribute.att_key IS NULL " +
        "AND cm.category = 'bookable' " +
        "AND poiGroup.is_visible_on_pwa ="+ Constants.IS_VISIBLE_ON_PWA,
        nativeQuery = true
    )
    List<Poi> findAllFreeBookable(@Param("buildingId") Long buildingId);

    List<Poi> findByNameIn(@Param("names") List<String> names);

    @RestResource(exported = false)
    @Query(
        "SELECT poi FROM Poi poi " +
        "INNER JOIN poi.attributes attributes " +
        "INNER JOIN poi.spaceType spaceType " +
        "WHERE INDEX(attributes) = :attKeyWanted " +
        "AND spaceType.poiGroup.id = :poiGroupId"
    )
    List<Poi> findAllByGroupIdAndAttribute(@Param("poiGroupId") Long poiGroupId,@Param("attKeyWanted") String attKeyWanted);


    List<Poi> findAllByTitleEnIn(List<String> titleEn);

    @Query("SELECT poi FROM Poi poi INNER JOIN poi.attributes attributes WHERE attributes IN :mails")
    List<Poi> findAllByMailsIn(@Param("mails") List<String> mails);

    @RestResource(exported = false)
        @Query(value = "SELECT  p.id  AS roomPoiId,p.name AS roomName,p.title_en AS roomTitle, " +
                          "p.floor_id AS floorId,f.name AS floor_name,f.building_id AS buildingId, " +
                          "p.space_type_id AS space_type_id, st.space_type_name  AS roomType, " +
                          "MAX(CASE WHEN pa.att_key = 'capacity' THEN pa.att_value END) AS roomCapacity, " +
                          "MAX(CASE WHEN pa.att_key = 'conf_room_mail' THEN pa.att_value END) AS roomEmail, " +
                          "MAX(CASE WHEN pa.att_key = 'checkIn' THEN pa.att_value END) AS checkIn,  " +
                          "MAX(CASE WHEN pa.att_key = 'checkOut' THEN pa.att_value END) AS checkOut  " +
                          "FROM poi AS p " +
                          "LEFT JOIN floor AS f ON f.id = p.floor_id " +
                          "LEFT JOIN space_type AS st ON st.id = p.space_type_id " +
                          "LEFT JOIN poi_attributes AS pa ON pa.poi_id = p.id " +
                          "WHERE EXISTS ( " +
                                "SELECT 1 " +
                                "FROM poi_attributes AS pa_email " +
                                "WHERE pa_email.poi_id    = p.id  " +
                                "AND pa_email.att_key   = 'conf_room_mail' " +
                                "AND pa_email.att_value = :roomEmail "+
                          ") "+
                          "GROUP BY p.id, p.name, p.floor_id,f.name, f.building_id, p.title_en, " +
                          "p.space_type_id, st.space_type_name " ,nativeQuery = true)
        List<Object[]> findAllPosByRoomEmail(@Param("roomEmail") String roomEmail);

        @Query(
        value = "SELECT p.name, " +
        "CASE " +
        "    WHEN ( " +
        "        CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "        CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "    ) = '' THEN '' " +
        "    ELSE LEFT( " +
        "        ( " +
        "            CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "            CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "        ), " +
        "        LEN( " +
        "            ( " +
        "                CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "                CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "            ) " +
        "        ) - 1 " +
        "    ) " +
        "END AS devices " +
        "FROM poi p " +
        "JOIN space_type st ON p.space_type_id = st.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = p.floor_id AND fa.att_key = 'hidden' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "INNER JOIN building b ON f.building_id = b.id " +
        "INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
        "LEFT JOIN ( " +
        "    SELECT DISTINCT p2.id AS poi_id " +
        "    FROM device d " +
        "    INNER JOIN poi p2 ON p2.name = d.poi_name AND p2.floor_id = d.floor_id " +
        "    WHERE d.device_type = 'TABLET' " +
        ") AS t ON t.poi_id = p.id " +
        "LEFT JOIN ( " +
        "    SELECT DISTINCT pa.poi_id AS poi_id " +
        "    FROM cisco_device cd " +
        "    INNER JOIN poi_attributes pa ON pa.att_key = 'conf_room_mail' AND pa.att_value = cd.email_id " +
        ") AS c ON c.poi_id = p.id " +
        "WHERE b.id = :buildingId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> '' " +
        "AND cm.category = 'bookable'",   nativeQuery = true
        )
        List<Object[]> getPoiDetailsByBuildingId(@Param ("buildingId") Long buildingId);

        

        @Query(
        value = "SELECT p.name, " +
        "CASE " +
        "    WHEN ( " +
        "        CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "        CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "    ) = '' THEN '' " +
        "    ELSE LEFT( " +
        "        ( " +
        "            CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "            CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "        ), " +
        "        LEN( " +
        "            ( " +
        "                CASE WHEN t.poi_id IS NOT NULL THEN 'tablet,' ELSE '' END + " +
        "                CASE WHEN c.poi_id IS NOT NULL THEN 'cisco,'  ELSE '' END " +
        "            ) " +
        "        ) - 1 " +
        "    ) " +
        "END AS devices " +
        "FROM poi p " +
        "JOIN space_type st ON p.space_type_id = st.id " +
        "INNER JOIN floor f ON p.floor_id = f.id " +
        "LEFT JOIN floor_attribute fa ON fa.floor_id = f.id AND fa.att_key = 'hidden' " +
        "LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +
        "LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
        "INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
        "LEFT JOIN ( " +
        "    SELECT DISTINCT p2.id AS poi_id " +
        "    FROM device d " +
        "    INNER JOIN poi p2 ON p2.name = d.poi_name AND p2.floor_id = d.floor_id " +
        "    WHERE d.device_type = 'TABLET' " +
        ") AS t ON t.poi_id = p.id " +
        "LEFT JOIN ( " +
        "    SELECT DISTINCT pa.poi_id AS poi_id " +
        "    FROM cisco_device cd " +
        "    INNER JOIN poi_attributes pa ON pa.att_key = 'conf_room_mail' AND pa.att_value = cd.email_id " +
        ") AS c ON c.poi_id = p.id " +
        "WHERE p.floor_id = :floorId " +
        "AND (fa.att_key IS NULL OR fa.att_value != 'true') " +
        "AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " +
        "AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> '' " +
        "AND cm.category = 'bookable'",
        nativeQuery = true)
    List<Object[]> getPoiDetailsByFloorId(@Param("floorId") Long floorId);
    
}
    