package com.capgemini.smartoffice.pwa.back.scheduled;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.capgemini.smartoffice.pwa.back.vecos.VecosClient;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class VecosScheduledTask {

    private static final String CONFIG_PATH = "application.vecos.batch";

    @Autowired
    private VecosClient vecosClient;

    // Scheduled task to retrieve vecos locker bank status
    @Scheduled(cron = "${" + CONFIG_PATH + ".cron}", zone = "${" + CONFIG_PATH + ".tz}") // commented this line as of now
    private void retrieveVecosLockerBankStatus() {
        log.info("Scheduled Task : Retrieve all status of locker bank");
        this.vecosClient.retrieveAllVecosLockerBankStatus();
    }
}