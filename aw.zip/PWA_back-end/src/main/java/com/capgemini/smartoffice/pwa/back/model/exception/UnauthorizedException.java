package com.capgemini.smartoffice.pwa.back.model.exception;

public class UnauthorizedException extends Exception {
    
}
