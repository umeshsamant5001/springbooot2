package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data 
@Entity 
@Table (name = "pwa_supported_language")
public class PwaSupportedLanguage {

    @Id 
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PwaSupportedLanguage_Generator")
	@SequenceGenerator(name = "PwaSupportedLanguage_Generator", sequenceName = "PwaSupportedLanguage_Sequence")
    private Long id; 
    @Column (name = "language")
    private String language;
    @Column(name = "language_code")
    private String languageCode;
}
