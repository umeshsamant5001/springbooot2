package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.CountryDTO;
import com.capgemini.smartoffice.pwa.back.model.Country;
import com.capgemini.smartoffice.pwa.back.model.SiteDTO;
import com.capgemini.smartoffice.pwa.back.model.Site;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.City;
import com.capgemini.smartoffice.pwa.back.model.CityDTO;

@Named("CityMapper")
@Mapper(config = DtoMapperConfig.class)
public interface CityMapper {

	CityMapper INSTANCE = Mappers.getMapper(CityMapper.class);

	City cityDTOToCity(CityDTO in);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "country", target = "country", qualifiedByName = { "countryToCountryDTOWithoutChildren" }),
        @Mapping(source = "sites", target = "sites", qualifiedByName = { "siteToSiteDTOWithoutParent" }),
    })
	CityDTO cityToCityDTO(City in, @Context String language);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "country", target = "country", qualifiedByName = { "countryToCountryDTOWithoutChildren" }),
        @Mapping(target = "sites", ignore = true)
    })
    CityDTO cityToCityDTONoSites(City in, @Context String language);

    @Named("countryToCountryDTOWithoutChildren")
    default CountryDTO _countryToCountryDTOWithoutChildren(Country country, @Context String language) {
        return Mappers.getMapper(CountryMapper.class)._countryToCountryDTOWithoutChildren(country, language);
    }

    @Named("siteToSiteDTOWithoutParent")
    default SiteDTO _siteToSiteDTOWithoutParent(Site site, @Context String language) {
        return Mappers.getMapper(SiteMapper.class)._siteToSiteDTOWithoutParent(site, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("cityToCityDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "country", ignore = true),
        @Mapping(source = "sites", target = "sites", qualifiedByName = { "siteToSiteDTOWithoutParent" }),
    })
    CityDTO _cityToCityDTOWithoutParent(City in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("cityToCityDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "country", target = "country", qualifiedByName = { "countryToCountryDTOWithoutChildren" }),
        @Mapping(target = "sites", ignore = true),
    })
    CityDTO _cityToCityDTOWithoutChildren(City in, @Context String language);
}
