package com.capgemini.smartoffice.pwa.back.repository;

import com.capgemini.smartoffice.pwa.back.model.ActionTokenUsage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActionTokenUsageRepository extends JpaRepository<ActionTokenUsage, String> {
}