package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.smartoffice.pwa.back.model.SpaceType;

public interface SpaceTypeRepository extends JpaRepository<SpaceType, Long> {
    

}
