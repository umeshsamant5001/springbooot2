package com.capgemini.smartoffice.pwa.back.controller;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.mapper.UserAnalyticsMapper;
import com.capgemini.smartoffice.pwa.back.model.UserAnalytics;
import com.capgemini.smartoffice.pwa.back.model.UserAnalyticsCreateRequest;
import com.capgemini.smartoffice.pwa.back.model.UserAnalyticsDTO;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumUserAnalytics;
import com.capgemini.smartoffice.pwa.back.service.UserAnalyticsService;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import org.springframework.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = UserAnalyticsController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
public class UserAnalyticsController {

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.setDisallowedFields("save");
	}

	static final String ROOT_API = "api/useranalytics";


	@Autowired
	private UserAnalyticsService useranalyticsService;

	@GetMapping
	public ResponseEntity<List<UserAnalyticsDTO>> getAll(
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<UserAnalytics> userAnalyticss = this.useranalyticsService.findAll();
        List<UserAnalyticsDTO> userAnalyticsDTOs = userAnalyticss
                .stream()
                .map(UserAnalyticsMapper.INSTANCE::useranalyticsToUserAnalyticsDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(userAnalyticsDTOs);
	}
	
	@PostMapping
	public ResponseEntity<UserAnalyticsDTO> createUserAnalytics(@Valid @RequestBody UserAnalyticsCreateRequest useranalyticsRequest) {
		
		UserAnalyticsDTO sanitizedUseranalyticsDTO = new UserAnalyticsDTO();
		sanitizedUseranalyticsDTO.setId(useranalyticsRequest.getId() == null ? null : Long.valueOf(useranalyticsRequest.getId()));
		sanitizedUseranalyticsDTO.setParentId(useranalyticsRequest.getParentId() == null ? null : Long.valueOf(useranalyticsRequest.getParentId()));
		sanitizedUseranalyticsDTO.setAppUser(useranalyticsRequest.getAppUser() == null ? null : new String(String.valueOf(useranalyticsRequest.getAppUser())));
		sanitizedUseranalyticsDTO.setModuleName(useranalyticsRequest.getModuleName() == null ? null : new String(String.valueOf(useranalyticsRequest.getModuleName())));
		sanitizedUseranalyticsDTO.setActivity(useranalyticsRequest.getActivity() == null ? null : new String(String.valueOf(useranalyticsRequest.getActivity())));
		sanitizedUseranalyticsDTO.setActivityDate(useranalyticsRequest.getActivityDate() == null ? null : Long.valueOf(useranalyticsRequest.getActivityDate()));
		sanitizedUseranalyticsDTO.setPlatform(useranalyticsRequest.getPlatform() == null ? null : new String(String.valueOf(useranalyticsRequest.getPlatform())));
		sanitizedUseranalyticsDTO.setUserAnalytics(useranalyticsRequest.getUserAnalytics() == null ? null : EnumUserAnalytics.findByName(String.valueOf(useranalyticsRequest.getUserAnalytics().name())));
		sanitizedUseranalyticsDTO.setEmail(useranalyticsRequest.getEmail() == null ? null : new String(String.valueOf(useranalyticsRequest.getEmail())));
		sanitizedUseranalyticsDTO.setCountry(useranalyticsRequest.getCountry() == null ? null : new String(String.valueOf(useranalyticsRequest.getCountry())));


		log.info("useranlitics: {}", sanitizedUseranalyticsDTO);
		// Handle parent ID logic
		if (Objects.nonNull(sanitizedUseranalyticsDTO.getId())) {
			if (useranalyticsService.findById(sanitizedUseranalyticsDTO.getId()).isPresent()) {
				sanitizedUseranalyticsDTO.setParentId(sanitizedUseranalyticsDTO.getId());
				sanitizedUseranalyticsDTO.setId(null);
			}
		}

		UserAnalytics useranalytics = UserAnalyticsMapper.INSTANCE.useranalyticsDTOToUserAnalytics(sanitizedUseranalyticsDTO);
		
		try {
			useranalytics = useranalyticsService.createUserAnalytics(useranalytics);
			UserAnalyticsDTO newUserAnalyticsDTO = UserAnalyticsMapper.INSTANCE.useranalyticsToUserAnalyticsDTO(useranalytics);
			return ResponseEntity.status(HttpStatus.CREATED).body(newUserAnalyticsDTO);
			
		} catch (IllegalArgumentException ex) {
			log.warn("Invalid user analytics request: {}", ex.getMessage());
			return ResponseEntity.badRequest().body(null);
			
		} catch (RuntimeException ex) {
			log.error("Error creating user analytics", ex);
			return ResponseEntity.internalServerError().build();
		}
	}

}
