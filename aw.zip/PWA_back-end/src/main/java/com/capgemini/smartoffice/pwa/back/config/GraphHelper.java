package com.capgemini.smartoffice.pwa.back.config;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.requests.GraphServiceClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.requests.EventCollectionPage;
import com.microsoft.graph.requests.EventCollectionRequestBuilder;
import com.microsoft.graph.requests.GraphServiceClient;
import okhttp3.Request;


import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Component
@Slf4j
public class GraphHelper {

    @Autowired
    private ApplicationProperties applicationProperties;

    private GraphServiceClient<okhttp3.Request> mClient;

    /**
     * Lazily initializes and returns a singleton GraphServiceClient.
     */
    private synchronized GraphServiceClient<okhttp3.Request> getInstance() {
        ApplicationProperties.Azure.GraphApi graphApi = this.applicationProperties.getAzure().getGraphApi();

        if (Objects.isNull(mClient)) {
            List<String> scopes = Arrays.asList(graphApi.getScopeUrl()); // e.g., "https://graph.microsoft.com/.default"

            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                .tenantId(this.applicationProperties.getAzure().getTenantId())
                .clientId(graphApi.getClientId())
                .clientSecret(graphApi.getClientSecret())
                .build();

            TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

            // Optional: token logging (safe to remove if graphApi.getUrl() isn't set)
            try {
                String url = graphApi.getUrl(); // e.g., "https://graph.microsoft.com/v1.0/me"
                if (url != null && !url.isBlank()) {
                    URL meUrl = new URL(url);
                    log.info("Graph token acquired: {}", authProvider.getAuthorizationTokenAsync(meUrl).get());
                }
            } catch (Exception ex) {
                log.error("Graph token acquisition error: {}", ex.getMessage(), ex);
            }

            mClient = GraphServiceClient.builder()
                .authenticationProvider(authProvider)
                .buildClient();
        }
        return mClient;
    }

    /**
     * Checks event state in Graph for the given room mailbox and event id.
     * @param roomEmail Room/resource mailbox UPN/email (used in /users/{roomEmail}/events/{eventId})
     * @param eventId   Original Graph event id (NOT your encoded/custom id)
     * @return true if cancelled OR not found (404/ErrorItemNotFound) — otherwise false
     */

    public boolean checkEvent(String roomEmail, String EventId) {
        try {
            Event graphEvent = getInstance()
                    .users(roomEmail)
                    .events(EventId)
                    .buildRequest()
                    .get();
    
            // Check if the event is cancelled
            if (Boolean.TRUE.equals(graphEvent.isCancelled)) {
                log.warn("Room event is CANCELLED in Graph. roomEmail={}, eventId={}", roomEmail, EventId);
                return true; 
            }
    
            // Not cancelled -> proceed
            return false;
    
        } catch (com.microsoft.graph.http.GraphServiceException e) {
            if (e.getResponseCode() == 404) {
                log.warn("Room event NOT FOUND (possibly cancelled/deleted). roomEmail={}, eventId={}", roomEmail, EventId);
                return true; 
            } else {
                log.error("Graph API error while retrieving ROOM event. roomEmail={}, eventId={}, error={}",
                        roomEmail, EventId, e.getMessage(), e);
                return false; 
            }
        } catch (Exception e) {
            log.error("Unexpected error while checking ROOM event. roomEmail={}, eventId={}, error={}",
                    roomEmail, EventId, e.getMessage(), e);
            return false; 
        }
    }

    /**
     * Checks whether a meeting should be treated as CANCELLED by retrying
     * the cancellation/decline check for a short period.
     *
     * This retry logic is required because Microsoft Exchange processes
     * room acceptance/decline asynchronously. Immediately after creating
     * or updating a meeting, the room's response status may still be "none".
     * 
     * The method retries the check multiple times with a fixed delay,
     * allowing enough time for the room mailbox to auto-accept or auto-decline
     * the meeting due to conflicts.
     * 
     * @param organizerEmail the email address of the meeting organizer
     *                        (source of truth for the event)
     * @param roomEmail      the email address of the room resource
     *                        (used only to evaluate attendee response)
     * @param eventId        the Microsoft Graph event ID belonging to the
     *                        organizer's mailbox
     *
     * @return {@code true} if the meeting is cancelled by the organizer,
     *         deleted, or declined by the room due to conflict;
     *         {@code false} if the meeting is still active or pending
    */
    public boolean isMeetingCancelledOrDeclinedWithRetry(
            String organizerEmail,
            String roomEmail,
            String eventId) {

        int maxRetries = 5;
        int delayMillis = 3000; // 3 seconds

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
           
            boolean cancelled = isMeetingCancelledOrDeclined(
                    organizerEmail, roomEmail, eventId);

            if (cancelled) {
                log.info("Meeting marked as cancelled/declined on attempt {}", attempt);
                return true;
            }

            try {
                Thread.sleep(delayMillis);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                break;
            }
        }

        log.info("Meeting not cancelled after retries. Treating as active.");
        return false;
    }

    
    /**
     * Determines whether a meeting should be treated as CANCELLED.
     * This method checks the meeting status using the organizer's mailbox
     * (the authoritative source in Microsoft Graph) and applies the following rules:
     *
     * If the organizer explicitly cancelled the meeting → CANCELLED
     * If the room resource declined the meeting due to a conflict → CANCELLED
     * If the event is no longer found (deleted) → CANCELLED
     * Otherwise, the meeting is considered ACTIVE
     * 
     * Note: Room decline is detected by inspecting the attendee response status
     * in the organizer's event. Room auto-accept/decline is asynchronous in
     * Exchange, so this method reflects the state at the time of invocation.
     *
     * @param organizerEmail the email address of the meeting organizer.
     *                       This mailbox is the source of truth for the event.
     * @param roomEmail      the email address of the room resource.
     *                       Used only to evaluate the room attendee response.
     * @param eventId        the Microsoft Graph event ID belonging to the
     *                       organizer's mailbox.
     *
     * @return {@code true} if the meeting is cancelled by the organizer,
     *         declined by the room, or no longer exists;
     *         {@code false} if the meeting is still active or pending.
    */
    public boolean isMeetingCancelledOrDeclined(
            String organizerEmail,
            String roomEmail,
            String eventId) {

        //log.info("Checking meeting status. organizerEmail={}, roomEmail={}, eventId={}",
        //        organizerEmail, roomEmail, eventId);

        try {
            // Always fetch event from ORGANIZER mailbox
            Event event = getInstance()
                    .users(organizerEmail)
                    .events(eventId)
                    .buildRequest()
                    .get();

            // Check if organizer cancelled the meeting
            if (Boolean.TRUE.equals(event.isCancelled)) {
                log.info("Meeting is cancelled by organizer. eventId={}", eventId);
                return true;
            }

            // Check if room declined the meeting (conflict case)
            if (isRoomDeclined(event, roomEmail)) {
                log.info("Meeting declined by room due to conflict. roomEmail={}, eventId={}",
                        roomEmail, eventId);
                return true; // treat as cancelled internally
            }

            // Meeting is active and room accepted or pending
            //log.info("Meeting is active. eventId={}", eventId);
            return false;

        } catch (com.microsoft.graph.http.GraphServiceException e) {

            // If event is not found in organizer mailbox, treat as cancelled
            if (e.getResponseCode() == 404) {
                log.warn("Meeting not found (404). Treating as cancelled. eventId={}", eventId);
                return true;
            }

            log.error("Graph API error while checking meeting status. eventId={}, error={}",
                    eventId, e.getMessage(), e);

            // Conservative approach: do NOT mark cancelled on unknown Graph failure
            return false;

        } catch (Exception e) {
            log.error("Unexpected error while checking meeting status. eventId={}, error={}",
                    eventId, e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Determines whether the room resource has declined the meeting.
     *
     * This method inspects the attendees list of an event retrieved from the
     * ORGANIZER mailbox (the source of truth in Microsoft Graph) and checks
     * whether the attendee representing the room has responded with
     * {@code "declined"}.
     * 
     * Room auto-accept/auto-decline is handled asynchronously by Exchange.
     * A declined response usually indicates a scheduling conflict, even
     * though the organizer's event still exists and {@code isCancelled}
     * remains {@code false}.
     * 
     * @param event     the Event object fetched from the organizer's mailbox.
     *                  Must contain the full attendees list.
     * @param roomEmail the email address of the room resource to evaluate.
     *
     * @return {@code true} if the room attendee exists and its response status
     *         is {@code "declined"};
     *         {@code false} if the room has accepted, not yet responded,
     *         or if attendee information is unavailable.
    */
    private boolean isRoomDeclined(Event event, String roomEmail) {

        if (event == null || event.attendees == null) {
            log.info("Event or attendees list is null. Returning false.");
            return false;
        }

        return event.attendees.stream().anyMatch(a -> {

            String attendeeEmail = null;
            String responseStatus = null;

            if (a.emailAddress != null) {
                attendeeEmail = a.emailAddress.address;
            }

            if (a.status != null && a.status.response != null) {
                responseStatus = a.status.response.toString();
            }

            // Log BEFORE matching
            // log.info(
            //     "Attendee found - emailAddress={}, responseStatus={}",
            //     attendeeEmail,
            //     responseStatus
            // );

            // Actual matching logic
            return attendeeEmail != null
                    && roomEmail.equalsIgnoreCase(attendeeEmail)
                    && "declined".equalsIgnoreCase(responseStatus);
        });
    }  

	private GraphServiceClient<Request> mClientForEmail;


    public GraphServiceClient<Request> getInstanceForEmail() {
        ApplicationProperties.Azure.GraphApiSendEmail graphSendApi = this.applicationProperties.getAzure().getGraphApiSendEmail();
		if (Objects.isNull(mClientForEmail)) {
            List<String> scopes = Arrays.asList(graphSendApi.getScopeUrl());
			ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
					.tenantId(this.applicationProperties.getAzure().getTenantId())
					.clientId(graphSendApi.getClientId())
					.clientSecret(graphSendApi.getClientSecret())
					.build();
			TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

			try {
                URL meUrl = new URL(graphSendApi.getUrl());
				log.info("Graph Token {}", authProvider.getAuthorizationTokenAsync(meUrl).get());
			} catch (Exception ex) {
				log.error("Graph error {}", ex);
			}
			mClientForEmail = GraphServiceClient.builder().authenticationProvider(authProvider).buildClient();
		}
		return mClientForEmail;
	}



} 