package com.capgemini.smartoffice.pwa.back.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.CountryTenant;

@Repository
public interface CountryTenantRepository extends JpaRepository<CountryTenant, Long> {
    Optional<CountryTenant> findByTenant(String tenant);
}
