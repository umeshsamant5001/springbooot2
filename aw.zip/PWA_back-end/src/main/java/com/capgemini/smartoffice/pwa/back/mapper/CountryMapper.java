package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.City;
import com.capgemini.smartoffice.pwa.back.model.CityDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Country;
import com.capgemini.smartoffice.pwa.back.model.CountryDTO;

@Named("CountryMapper")
@Mapper(config = DtoMapperConfig.class)
public interface CountryMapper {

	CountryMapper INSTANCE = Mappers.getMapper(CountryMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "cities", target = "cities", qualifiedByName = { "cityToCityDTOWithoutParent" }),
    })
    CountryDTO countryToCountryDTO(Country in, @Context String language);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
	    @Mapping(target = "cities", ignore = true),
    })
    CountryDTO countryToCountryDTONoCities(Country in, @Context String language);

    Country countryDTOToCountry(CountryDTO in);

    @Named("cityToCityDTOWithoutParent")
    default CityDTO _cityToCityDTOWithoutParent(City city, @Context String language) {
        return Mappers.getMapper(CountryMapper.class)._cityToCityDTOWithoutParent(city, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("countryToCountryDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "cities", ignore = true)
    })
    CountryDTO _countryToCountryDTOWithoutChildren(Country in, @Context String language);

}
