package com.capgemini.smartoffice.pwa.back.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.PoiGroup;
import com.capgemini.smartoffice.pwa.back.repository.PoiGroupRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiGroupService {
    @Autowired
    private PoiGroupRepository poiGroupRepository;

    public List<PoiGroup> findAllByBuilding(Long buildingId) {
        List<Long> ids = this.poiGroupRepository.findAllIdByBuildingId(buildingId);
        if(CollectionUtils.isEmpty(ids)) {
            return new ArrayList<PoiGroup>();
        }
        return this.poiGroupRepository.findAllById(ids);
    }

    public PoiGroup findByName(String name) {
        return this.poiGroupRepository.findByName(name);
    }

    public List<PoiGroup> findAllVisibleOnPWA(Boolean isVisibleOnPwa) {
        List<PoiGroup> poiGroups = this.poiGroupRepository.findAllVisibleOnPWA(isVisibleOnPwa);
        return poiGroups;
    }

}
