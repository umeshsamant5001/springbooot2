package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;
import com.capgemini.smartoffice.pwa.back.repository.DeviceRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DeviceService {

    @Autowired
    DeviceRepository deviceRepository;

    public List<Device> findAllViaPoiByFloorIdAndPoiGroup(Long floorId, List<String> poiGroupList) {
		if (Objects.isNull(poiGroupList) || poiGroupList.isEmpty()) {
			return this.deviceRepository.findAllViaPoiByFloorId(floorId);
		}

		return this.deviceRepository.findAllViaPoiByFloorIdAndPoiGroup(floorId, poiGroupList);
	}

    public List<Device> findAllViaPoiByFloorIdAndPoiGroupExcludeTablet(Long floorId, List<String> poiGroupList) {
		if (Objects.isNull(poiGroupList) || poiGroupList.isEmpty()) {
			return this.deviceRepository.findAllViaPoiByFloorId(floorId);
		}

		return this.deviceRepository.findAllViaPoiByFloorIdAndPoiGroupExcludeTablet(floorId, poiGroupList);
	}

    public boolean existsByPoiNameAndDeviceType(String poiName, EnumDeviceType deviceType) {
        return deviceRepository.existsByPoiNameAndDeviceType(poiName, deviceType);
    }

	/**
     * Retrieves all devices via POI based on combinations of type IDs, building
     * IDs, and floor IDs.
     * Applies conditional logic to determine the appropriate repository method to
     * call.
     * 
     * @return a list of matching Device entities
     */
    public List<Device> findAllViaPoiByTypeIdAndBuildingIdAndFloorId(List<Long> typeId, List<Long> buildingId,
            List<Long> floorId) {
        if (Objects.nonNull(typeId) && !typeId.isEmpty()) {
            if (Objects.nonNull(floorId) && !floorId.isEmpty()) {
                return deviceRepository.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(typeId, buildingId, floorId);
            }

            return deviceRepository.findAllViaPoiByTypeIdAndBuildingId(typeId, buildingId);
        }

        if (Objects.nonNull(floorId) && !floorId.isEmpty()) {
            return deviceRepository.findAllViaPoiByBuildingIdAndFloorId(buildingId, floorId);
        }

        return deviceRepository.findAllViaPoiByBuildingId(buildingId);
    }



}
