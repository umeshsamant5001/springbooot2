package com.capgemini.smartoffice.pwa.back.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.model.PwaSupportedLanguageDTO;
import com.capgemini.smartoffice.pwa.back.service.PwaSupportedLanguageService;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController 
@RequestMapping(value = PwaSupportedLanguageController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PwaSupportedLanguageController {

    static final String ROOT_API = "/api/pwa-supported-language";

    @Autowired 
    private PwaSupportedLanguageService pwaSupportedLanguageService;

    @GetMapping 
    public ResponseEntity<List<PwaSupportedLanguageDTO>> getPwaSupportedLanguage() {
        List<PwaSupportedLanguageDTO> pwaSupportedLanguageDTOs = pwaSupportedLanguageService.getPwaSupportedLanguage();
        return ResponseEntity.status(HttpStatus.OK).body(pwaSupportedLanguageDTOs);
    }

}
