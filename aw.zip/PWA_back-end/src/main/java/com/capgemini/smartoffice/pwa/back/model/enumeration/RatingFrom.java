package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum RatingFrom {

    WEB_PORTAL,
    MOBILE
}

