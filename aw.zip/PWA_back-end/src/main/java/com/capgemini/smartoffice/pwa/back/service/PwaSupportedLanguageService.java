package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.mapper.PwaSupportedLanguageMapper;
import com.capgemini.smartoffice.pwa.back.model.PwaSupportedLanguage;
import com.capgemini.smartoffice.pwa.back.model.PwaSupportedLanguageDTO;
import com.capgemini.smartoffice.pwa.back.repository.PwaSupportedLanguageRepository;

@Service 
public class PwaSupportedLanguageService {

    @Autowired 
    private PwaSupportedLanguageRepository pwaSupportedLanguageRepository;

    public List<PwaSupportedLanguageDTO> getPwaSupportedLanguage(){
        List<PwaSupportedLanguage> pwaSupportedLanguages = pwaSupportedLanguageRepository.findAll();
        List<PwaSupportedLanguageDTO> pwaSupportedLanguageDTOs = pwaSupportedLanguages
                 .stream()
                 .map(pwaSupportedLang -> PwaSupportedLanguageMapper.INSTANCE.pwaSupportedLanguageTOPwaSupportedLanguageDTO(pwaSupportedLang))
                 .collect(Collectors.toList());
        return pwaSupportedLanguageDTOs;
    }
}
