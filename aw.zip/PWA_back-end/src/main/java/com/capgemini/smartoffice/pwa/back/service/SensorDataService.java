package com.capgemini.smartoffice.pwa.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.PoiDTO;
import com.capgemini.smartoffice.pwa.back.model.RoomPoiDTO;
import com.capgemini.smartoffice.pwa.back.model.SensorDataDTO;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceAttribute;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;

@Service
public class SensorDataService {
    private static final int MILLIS_IN_SECOND = 1000;
	private static final String FREE_STATE = "free";
	private static final String BUSY_STATE = "busy";
	private static final String DEFAULT_STATE = "unknown";
	public static final Integer DESK_LOCKING_TIME_MINUTES = 60;

	public List<SensorDataDTO> convertToSensorDataDTO(List<PoiDTO> poiDTOs, List<Device> devices) {
		if (Objects.isNull(devices)) {
			return null;
		}

		return devices.stream()
			.map(device -> {
				SensorDataDTO sensorData = new SensorDataDTO();

				String poiName = device.getPoiName();

				// If link to a Poi, get the Poi
				if (Objects.nonNull(poiName)) {
					PoiDTO foundPoi = poiDTOs.stream()
						.filter(poi -> Objects.equals(poi.getName(), poiName))
						.findFirst()
						.orElse(null);

					if (Objects.nonNull(foundPoi)) {
						sensorData.setCdmKeyIdPoi(foundPoi.getCdmKeyId());
					}
				}

				// Basic fields
				sensorData.setUuid(device.getUuid());
				sensorData.setPoiName(device.getPoiName());

				if (Objects.nonNull(device.getFloor())) {
					sensorData.setCdmKeyIdFloor(device.getFloor().getCdmKeyId());
				}

				if (Objects.nonNull(device.getStatus())) {
					sensorData.setStatus(device.getStatus().toString());
				}

				if (Objects.nonNull(device.getDeviceType())) {
					sensorData.setDeviceType(device.getDeviceType().toString());
				}

				if (Objects.nonNull(device.getLastChange())) {
					sensorData.setLastChange(device.getLastChange().toString());
				}

				Map<String, String> attributes = device.getAttributes();

				sensorData.setBattery(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.VDD)
				);

				sensorData.setOccupation(
					this.getAttributeAsString(attributes, EnumDeviceAttribute.OCCUPATION)
				);

				sensorData.setCo2(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.CO2)
				);

				sensorData.setHumidity(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.HUMIDITY)
				);

				sensorData.setLight(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.LUX)
				);

				sensorData.setNoise(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.SOUND)
				);

				sensorData.setTempC(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPC)
				);

				sensorData.setTempF(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPF)
				);

				return sensorData;
			})
			.collect(Collectors.toList());
	}

	public Map<String, SensorDataDTO> getPoiSensorData(List<PoiDTO> poiDTOs, List<Device> devices) {
		List<SensorDataDTO> sensorDataDTOs = this.convertToSensorDataDTO(poiDTOs, devices);

		Map<String, List<SensorDataDTO>> sensorDataMap =  sensorDataDTOs
			.stream()
			.collect(Collectors.toMap(
				SensorDataDTO::getPoiName,
				sensorData -> new ArrayList<>(Arrays.asList(sensorData)),
				(sensorData1, sensorData2) -> {
					sensorData1.addAll(sensorData2);
					return sensorData1;
				}
			));

		return sensorDataMap.keySet()
			.stream()
			.map(poiName -> {
				SensorDataDTO resultSensorDataDTO = new SensorDataDTO();
				Date now = new Date();

				sensorDataMap.get(poiName)
					.stream()
					.forEach(sensorDataDTO -> {
						if (Objects.nonNull(sensorDataDTO.getCdmKeyIdPoi())) {
							resultSensorDataDTO.setCdmKeyIdPoi(sensorDataDTO.getCdmKeyIdPoi());
						}
						if (Objects.nonNull(sensorDataDTO.getUuid())) {
							resultSensorDataDTO.setUuid(sensorDataDTO.getUuid());
						}
						if (Objects.nonNull(sensorDataDTO.getPoiName())) {
							resultSensorDataDTO.setPoiName(sensorDataDTO.getPoiName());
						}
						if (Objects.nonNull(sensorDataDTO.getUuid())) {
							resultSensorDataDTO.setCdmKeyIdFloor(sensorDataDTO.getCdmKeyIdFloor());
						}
						if (Objects.nonNull(sensorDataDTO.getStatus())) {
							resultSensorDataDTO.setStatus(sensorDataDTO.getStatus());
						}
						if (Objects.nonNull(sensorDataDTO.getDeviceType())) {
							resultSensorDataDTO.setDeviceType(sensorDataDTO.getDeviceType());
						}
						if (Objects.nonNull(sensorDataDTO.getLastChange())) {
							resultSensorDataDTO.setLastChange(sensorDataDTO.getLastChange());
						}
						if (Objects.nonNull(sensorDataDTO.getBattery())) {
							resultSensorDataDTO.setBattery(sensorDataDTO.getBattery());
						}
						if (Objects.nonNull(sensorDataDTO.getOccupation())) {
                            String occupancy;
                            if (Objects.equals(EnumDeviceType.OFFICESENSE_DESK.name(), sensorDataDTO.getDeviceType())) {
                                // Special case of a Desk
                                occupancy = deskOccupancy(sensorDataDTO, now, DESK_LOCKING_TIME_MINUTES);
                            } else {
                                occupancy = sensorDataDTO.getOccupation();
                            }

                            // As the presence can come from several sensors, we consider busy
                            // if at least one sensor is in busy mode
                            if (!BUSY_STATE.equals(resultSensorDataDTO.getOccupation())) {
                                // If the result sensor is already at "busy", we don't change it.
                                resultSensorDataDTO.setOccupation(occupancy);
                            }
                        }
						if (Objects.nonNull(sensorDataDTO.getCo2())) {
							resultSensorDataDTO.setCo2(sensorDataDTO.getCo2());
						}
						if (Objects.nonNull(sensorDataDTO.getHumidity())) {
							resultSensorDataDTO.setHumidity(sensorDataDTO.getHumidity());
						}
						if (Objects.nonNull(sensorDataDTO.getLight())) {
							resultSensorDataDTO.setLight(sensorDataDTO.getLight());
						}
						if (Objects.nonNull(sensorDataDTO.getNoise())) {
							resultSensorDataDTO.setNoise(sensorDataDTO.getNoise());
						}
						if (Objects.nonNull(sensorDataDTO.getTempC())) {
							resultSensorDataDTO.setTempC(sensorDataDTO.getTempC());
						}
						if (Objects.nonNull(sensorDataDTO.getTempF())) {
							resultSensorDataDTO.setTempF(sensorDataDTO.getTempF());
						}
					});

				return resultSensorDataDTO;
			})
			.collect(Collectors.toMap(
				SensorDataDTO::getPoiName,
				Function.identity()
			));
	}

	/**
	 * Return the value of an attribut as a String.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a String.
	 */
	private String getAttributeAsString(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();

		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
		}

		return attributes.get(keyString);
	}

	/**
	 * Return the value of an attribut as a Double.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a Double.
	 */
	private Double getAttributeAsDouble(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();

		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
		}

		return Double.parseDouble(attributes.get(keyString));
	}

	private String deskOccupancy(SensorDataDTO sensorDataDTO, Date now, Integer intevalToConsiderFree) {
		try {
			if (Objects.isNull(sensorDataDTO)) {
				return DEFAULT_STATE;
			}

			if (BUSY_STATE.equals(sensorDataDTO.getOccupation())) {
				return BUSY_STATE;
			}

			if (
				FREE_STATE.equals(sensorDataDTO.getOccupation())
				&& Objects.nonNull(sensorDataDTO.getLastChange())
			) {
				Long occupiedTs = Long.valueOf(sensorDataDTO.getLastChange());
				long nowSecond = now.getTime() / MILLIS_IN_SECOND;
				long lastOccupiedTimeInterval = nowSecond - occupiedTs;

				if (lastOccupiedTimeInterval < intevalToConsiderFree) {
					return BUSY_STATE;
				}

				return FREE_STATE;
			}
		} catch (Exception e) {
			return DEFAULT_STATE;
		}

		return DEFAULT_STATE;
	}

	
	/**
	 * Aggregates sensor data per room (POI) and returns a map from POI name to a consolidated SensorDataDTO.
	 * <p>
	 * Steps:
	 * <ol>
	 *   <li>Convert raw devices + POI list into individual {@link SensorDataDTO} entries.</li>
	 *   <li>Group those entries by POI name into a map: POI name -> list of SensorDataDTOs.</li>
	 *   <li>For each POI, consolidate multiple SensorDataDTOs into a single SensorDataDTO by:
	 *       <ul>
	 *         <li>Copying non-null scalar fields (uuid, ids, status, env readings, etc.).</li>
	 *         <li>Resolving occupancy: if any sensor reports BUSY, keep BUSY; otherwise use the latest computed occupancy.
	 *             For desks, occupancy is computed using {@code deskOccupancy(...)} with a locking window.</li>
	 *       </ul>
	 *   </li>
	 *   <li>Return a map: POI name -> consolidated SensorDataDTO.</li>
	 * </ol>
	 *
	 * @param roompoiDTOs List of RoomPoiDTO defining rooms/POIs (used by the conversion step).
	 * @param devices     List of devices providing sensor data.
	 * @return Map keyed by POI name, with a single consolidated SensorDataDTO per POI.
	*/
	public Map<String, SensorDataDTO> getPoiSensorDataForRoom(List<RoomPoiDTO> roompoiDTOs, List<Device> devices) {
        List<SensorDataDTO> sensorDataDTOs = convertToSensorDataDTOForRoom(roompoiDTOs, devices);

        Map<String, List<SensorDataDTO>> sensorDataMap = sensorDataDTOs
                .stream()
                .collect(
                        Collectors.toMap(
                                SensorDataDTO::getPoiName,
                                sensorData -> new ArrayList<>(Arrays.asList(sensorData)),
                                (sensorData1, sensorData2) -> {
                                    sensorData1.addAll(sensorData2);
                                    return sensorData1;
                                }));

        return sensorDataMap
                .keySet()
                .stream()
                .map(poiName -> {
                    SensorDataDTO resultSensorDataDTO = new SensorDataDTO();
                    Date now = new Date();

                    sensorDataMap
                            .get(poiName)
                            .stream()
                            .forEach(sensorDataDTO -> {
                                if (Objects.nonNull(sensorDataDTO.getCdmKeyIdPoi())) {
                                    resultSensorDataDTO.setCdmKeyIdPoi(sensorDataDTO.getCdmKeyIdPoi());
                                }
                                if (Objects.nonNull(sensorDataDTO.getUuid())) {
                                    resultSensorDataDTO.setUuid(sensorDataDTO.getUuid());
                                }
                                if (Objects.nonNull(sensorDataDTO.getPoiName())) {
                                    resultSensorDataDTO.setPoiName(sensorDataDTO.getPoiName());
                                }
                                if (Objects.nonNull(sensorDataDTO.getUuid())) {
                                    resultSensorDataDTO.setCdmKeyIdFloor(sensorDataDTO.getCdmKeyIdFloor());
                                }
                                if (Objects.nonNull(sensorDataDTO.getStatus())) {
                                    resultSensorDataDTO.setStatus(sensorDataDTO.getStatus());
                                }
                                if (Objects.nonNull(sensorDataDTO.getDeviceType())) {
                                    resultSensorDataDTO.setDeviceType(sensorDataDTO.getDeviceType());
                                }
                                if (Objects.nonNull(sensorDataDTO.getLastChange())) {
                                    resultSensorDataDTO.setLastChange(sensorDataDTO.getLastChange());
                                }
                                if (Objects.nonNull(sensorDataDTO.getBattery())) {
                                    resultSensorDataDTO.setBattery(sensorDataDTO.getBattery());
                                }
                                if (Objects.nonNull(sensorDataDTO.getOccupation())) {
                                    String occupancy;
                                    if (Objects.equals(EnumDeviceType.OFFICESENSE_DESK.name(),
                                            sensorDataDTO.getDeviceType())) {
                                        // Special case of a Desk
                                        occupancy = deskOccupancy(sensorDataDTO, now,DESK_LOCKING_TIME_MINUTES);
                                    } else {
                                        occupancy = sensorDataDTO.getOccupation();
                                    }

                                    // As the presence can come from several sensors, we consider busy
                                    // if at least one sensor is in busy mode
                                    if (!BUSY_STATE.equals(resultSensorDataDTO.getOccupation())) {
                                        // If the result sensor is already at "busy", we don't change it.
                                        resultSensorDataDTO.setOccupation(occupancy);
                                    }
                                }
                                if (Objects.nonNull(sensorDataDTO.getCo2())) {
                                    resultSensorDataDTO.setCo2(sensorDataDTO.getCo2());
                                }
                                if (Objects.nonNull(sensorDataDTO.getHumidity())) {
                                    resultSensorDataDTO.setHumidity(sensorDataDTO.getHumidity());
                                }
                                if (Objects.nonNull(sensorDataDTO.getLight())) {
                                    resultSensorDataDTO.setLight(sensorDataDTO.getLight());
                                }
                                if (Objects.nonNull(sensorDataDTO.getNoise())) {
                                    resultSensorDataDTO.setNoise(sensorDataDTO.getNoise());
                                }
                                if (Objects.nonNull(sensorDataDTO.getTempC())) {
                                    resultSensorDataDTO.setTempC(sensorDataDTO.getTempC());
                                }
                                if (Objects.nonNull(sensorDataDTO.getTempF())) {
                                    resultSensorDataDTO.setTempF(sensorDataDTO.getTempF());
                                }
                            });

                    return resultSensorDataDTO;
                })
                .collect(Collectors.toMap(SensorDataDTO::getPoiName, Function.identity()));
    }

	
	/**
	 * Converts a list of devices into SensorDataDTO entries for rooms (POIs).
	 * <p>
	 * For each device:
	 * <ul>
	 *   <li>Optionally find the matching RoomPoiDTO by POI name (currently not used beyond lookup).</li>
	 *   <li>Populate SensorDataDTO fields from the device:
	 *       <ul>
	 *         <li>Identifiers: uuid, poiName, floor key</li>
	 *         <li>Status, device type, last change timestamp</li>
	 *         <li>Environmental readings from attributes (battery, CO2, humidity, light, noise, temperatures)</li>
	 *       </ul>
	 *   </li>
	 * </ul>
	 *
	 * @param poiDTOs  List of room POIs (used to correlate device to POI by name).
	 * @param devices  List of devices to convert.
	 * @return List of SensorDataDTO built from the devices (or an empty list if devices is null).
	*/
	private List<SensorDataDTO> convertToSensorDataDTOForRoom(List<RoomPoiDTO> poiDTOs, List<Device> devices) {
        if (Objects.isNull(devices)) {
            return null;
        }

        return devices.stream()
                .map(device -> {
                    SensorDataDTO sensorData = new SensorDataDTO();

                    String poiName = device.getPoiName();

                    // If link to a Poi, get the Poi
                    if (Objects.nonNull(poiName)) {
                        RoomPoiDTO foundPoi = poiDTOs.stream()
                                .filter(poi -> Objects.equals(poi.getRoomName(), poiName))
                                .findFirst()
                                .orElse(null);                        
                    }

                    // Basic fields
                    sensorData.setUuid(device.getUuid());
                    sensorData.setPoiName(device.getPoiName());

                    if (Objects.nonNull(device.getFloor())) {
                        sensorData.setCdmKeyIdFloor(device.getFloor().getCdmKeyId());
                    }

                    if (Objects.nonNull(device.getStatus())) {
                        sensorData.setStatus(device.getStatus().toString());
                    }

                    if (Objects.nonNull(device.getDeviceType())) {
                        sensorData.setDeviceType(device.getDeviceType().toString());
                    }

                    if (Objects.nonNull(device.getLastChange())) {
                        sensorData.setLastChange(device.getLastChange().toString());
                    }

                    Map<String, String> attributes = device.getAttributes();

                    sensorData.setBattery(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.VDD));

                    sensorData.setOccupation(
                            this.getAttributeAsString(attributes, EnumDeviceAttribute.OCCUPATION));

                    sensorData.setCo2(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.CO2));

                    sensorData.setHumidity(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.HUMIDITY));

                    sensorData.setLight(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.LUX));

                    sensorData.setNoise(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.SOUND));

                    sensorData.setTempC(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPC));

                    sensorData.setTempF(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPF));

                    return sensorData;
                })
                .collect(Collectors.toList());
    }
}
