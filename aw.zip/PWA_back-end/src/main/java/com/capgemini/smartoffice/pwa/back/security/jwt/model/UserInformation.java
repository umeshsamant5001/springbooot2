package com.capgemini.smartoffice.pwa.back.security.jwt.model;

import lombok.Getter;

@Getter
public class UserInformation {
    private String email;

    public UserInformation(String email) {
        this.email = email;
    }
}
