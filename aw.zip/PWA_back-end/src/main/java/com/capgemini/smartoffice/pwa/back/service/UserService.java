package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.helper.Constants;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.repository.BuildingRepository;

import com.capgemini.smartoffice.pwa.back.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    BuildingRepository buildingRepository;

    @Autowired
    BuildingService buildingService;

    public User createOrUpdateUser(String userEmail, String validatedFirstName, String validatedLastName) {
        log.info("UserService createOrUpdateUser");
        //Modified to fetch user using query which is not using deleted
        //User user = userRepository.findByEmail(userEmail); // old code
        User user = findByEmailNoDeletedCheck(userEmail);

        String safeFirstName = validatedFirstName == null ? null : new String(String.valueOf(validatedFirstName));
        String safeLastName = validatedLastName == null ? null : new String(String.valueOf(validatedLastName));

        if (user == null) {            
            user = new User();
            user.setEmail(userEmail);
            user.setFirstName(safeFirstName);
            user.setLastName(safeLastName);
            user.setUserType(Constants.USER);
            userRepository.save(user);
        } else if (isNullOrEmpty(user.getFirstName()) || isNullOrEmpty(user.getLastName())) {           
            user.setFirstName(
                    isNullOrEmpty(user.getFirstName()) ? safeFirstName : user.getFirstName());
            user.setLastName(
                    isNullOrEmpty(user.getLastName()) ? safeLastName : user.getLastName());
            userRepository.save(user);
        }

        return user;
    }


    private boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    public User createUserBeforeAuthentication(String userEmail, User user) {
        log.info("UserService createUserBeforeAuthentication");
        user.setEmail(userEmail);
        user.setUserType(Constants.USER);
        userRepository.save(user);
        return user;
    }

    @Transactional
    public User findByEmail(String email) {
        log.info("UserService findByEmail");
        return this.userRepository.findByEmail(email);
    }

    @Transactional
    public User findByEmailNoDeletedCheck(String email) {
        log.info("UserService findByEmailNoDeletedCheck");
        return userRepository.findByEmailNoDeletedCheck(email);
    }

    public boolean canAccessBuilding(String userEmail, Building building) {
        log.info("UserService canAccessBuilding");
        List<Building> buildingFiltered = this.filterSecuredBuildings(userEmail, List.of(building));

        return buildingFiltered.size() > 0;
    }

    public List<Building> filterSecuredBuildings(String userEmail, List<Building> buildings) {
        log.info("UserService filterSecuredBuildings");

        User user = findByEmailNoDeletedCheck(userEmail);

        if (Objects.isNull(user)) {
            return buildings;
        }

        // Create a set of secured building IDs for the user
        Set<Long> userSecuredBuildingIds = user.getUserSecuredBuildings()
                .stream()
                .filter(Building::getSecured)
                .map(Building::getId)
                .collect(Collectors.toSet());

        // Filter buildings based on the criteria
        return buildings.stream()
                .filter(building -> Boolean.FALSE.equals(building.getSecured()) ||
                        userSecuredBuildingIds.contains(building.getId()))
                .collect(Collectors.toList());
    }

    public List<BuildingDTO> filterSecuredBuildingDTOs(String userEmail, List<BuildingDTO> buildings) {
        log.info("UserService filterSecuredBuildingDTOs");
        User user = findByEmailNoDeletedCheck(userEmail);
        if (Objects.isNull(user)) {
            return buildings;
        }
        List<Long> securedBuildingIds = buildingService.findSecuredBuildingIdsByUserId(user.getId());

        // Filter buildings based on the criteria
        return buildings.stream()
                .filter(building -> Boolean.FALSE.equals(building.getSecured()) ||
                        securedBuildingIds.contains(building.getId()))
                .collect(Collectors.toList());
    }

    public Boolean filterSecuredBuilding(String userEmail, Building building) {
        log.info("UserService filterSecuredBuilding");
        User user = findByEmailNoDeletedCheck(userEmail);
        if (Objects.isNull(user)) {
            return false;
        }
        List<Long> securedBuildingIds = this.buildingService.findSecuredBuildingIdsByUserId(user.getId());

        if (securedBuildingIds.contains(building.getId())) {
            return true;
        }
        return false;
    }

}
