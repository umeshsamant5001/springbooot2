package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Meeting;
import com.capgemini.smartoffice.pwa.back.model.MeetingDTO;

@Mapper(config = DtoMapperConfig.class)
public interface MeetingMapper {

	MeetingMapper INSTANCE = Mappers.getMapper(MeetingMapper.class);

	MeetingDTO meetingToMeetingDTO(Meeting in);

    @Mappings({
        @Mapping(target="noshowCounter", ignore = true),
        @Mapping(target="alertCheckIn", ignore = true)
    })
	Meeting meetingDTOToMeeting(MeetingDTO in);

}
