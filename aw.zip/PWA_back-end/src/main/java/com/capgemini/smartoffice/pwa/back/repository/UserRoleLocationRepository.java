package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.model.UserRoleLocation;

@Repository
public interface UserRoleLocationRepository extends JpaRepository<UserRoleLocation, Long> {

    public List<UserRoleLocation> findByUserId(Long userId);

        @Query("SELECT u FROM User u JOIN UserRoleLocation url ON u.id = url.userId JOIN Role r ON url.roleId = r.id WHERE u.email = :email AND r.name = :roleName")
        Optional<User> findUserByEmailAndRole(@Param("email") String email, @Param("roleName") String roleName);

}
