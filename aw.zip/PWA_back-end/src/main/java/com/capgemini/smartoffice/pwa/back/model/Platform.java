package com.capgemini.smartoffice.pwa.back.model;

public enum Platform {
    PWA, TABLET, ALL, OUTLOOK ;
}
