package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.smartoffice.pwa.back.helper.DistanceUtils;
import com.capgemini.smartoffice.pwa.back.mapper.BuildingMapper;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumBuildingAttribute;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import com.capgemini.smartoffice.pwa.back.service.BuildingService;
import com.capgemini.smartoffice.pwa.back.service.UserInformationService;
import com.capgemini.smartoffice.pwa.back.service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = BuildingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class BuildingController {

    static final String ROOT_API = "api/building";

    @Autowired
    private UserService userService;

    @Autowired
    private UserInformationService userInformationService;

    @Autowired
    private BuildingService buildingService;

    /***
     * API to find the building closest to the param coordinates
     *
     * @param lat
     * @param lon
     * @param nbBuilding
     * @return
     */
    @GetMapping("locate")
    public ResponseEntity<List<BuildingDTO>> locateBuildingsClosestCoordintaes(
            @RequestParam double lat, @RequestParam double lon,
            @RequestParam(required = false, defaultValue = "5") Integer nbBuilding,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Building> buildings = this.buildingService.getDeployedBuilding(false);
        // No content in case of no building available
        if (CollectionUtils.isEmpty(buildings)) {
            return ResponseEntity.noContent().build();
        }

        UserInformation userInformation = this.userInformationService.getCurrent();
        String userEmail = userInformation.getEmail();

        // We filter the secured buildings the user can't access
        buildings = this.userService.filterSecuredBuildings(userEmail, buildings);

        List<BuildingDTO> lbuildingsDTO = buildings.stream()
                .map(building -> {
                    BuildingDTO buildingDTO = BuildingMapper.INSTANCE.buildingToBuildingDTONoFloors(building, language);
                    return buildingDTO;
                }).collect(Collectors.toList());

        // Reduce list to only building distance can be compute
        lbuildingsDTO = lbuildingsDTO.stream().filter(buildingDto -> this.canComputeDistance(buildingDto))
                .collect(Collectors.toList());

        // Check that the size of nbBuilding does not exceed that of the list of
        // buildings
        if (nbBuilding > lbuildingsDTO.size()) {
            nbBuilding = lbuildingsDTO.size();
        }

        Map<BuildingDTO, Double> mapDistanceBuilding = new HashMap<>();

        // Calculate the distance between the user and the building and add it to a map
        lbuildingsDTO.forEach(buildingDto -> {
            double buildingLat = Double
                    .valueOf(buildingDto.getAttributes().get(EnumBuildingAttribute.LAT.toString()));
            double buildingLon = Double
                    .valueOf(buildingDto.getAttributes().get(EnumBuildingAttribute.LON.toString()));

            mapDistanceBuilding.put(buildingDto, DistanceUtils.distance(buildingLat, lat, buildingLon, lon));

        });

        if (mapDistanceBuilding.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Sort map by closest building
        Map<BuildingDTO, Double> result = mapDistanceBuilding.entrySet().stream()
                .sorted(Comparator.comparingDouble(Map.Entry::getValue))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (a, b) -> b, LinkedHashMap::new));

        // Convert the map into list with the nbBuilding limit
        List<BuildingDTO> lbuildingsDTORes = result.entrySet().stream().limit(nbBuilding).map(Entry::getKey)
                .collect(Collectors.toList());

        return ResponseEntity.ok(lbuildingsDTORes);
    }

    /**
     * Return a building, and its floor, by its id.
     */
    @GetMapping("/{buildingId}")
    public ResponseEntity<BuildingDTO> getBuilding(
            @PathVariable Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (Objects.isNull(buildingId) || buildingId <= 0) {
            log.info("Invalid building id {}", buildingId);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        Building building = this.buildingService.getBuilding(buildingId);


        if (Objects.isNull(building)) {
            log.info("Building {} not found", buildingId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        // The building is secured, we need to check if the user can access it.
        if (Boolean.TRUE.equals(building.getSecured())) {
            UserInformation userInformation = this.userInformationService.getCurrent();
            String userEmail = userInformation.getEmail();

            Boolean isAuthorized = this.userService.filterSecuredBuilding(userEmail, building);

            if (!isAuthorized) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        BuildingDTO buildingDTO = BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language);

        return ResponseEntity.ok(buildingDTO);
    }

    /***
     * Check building's latitude & longitude are available
     *
     * @param buildingDto
     * @return
     */
    private boolean canComputeDistance(BuildingDTO buildingDto) {
        return Objects.nonNull(buildingDto.getAttributes())
                && buildingDto.getAttributes().containsKey(EnumBuildingAttribute.LAT.toString())
                && buildingDto.getAttributes().containsKey(EnumBuildingAttribute.LON.toString())
                && this.stringIsDouble(buildingDto.getAttributes().get(EnumBuildingAttribute.LAT.toString()))
                && this.stringIsDouble(buildingDto.getAttributes().get(EnumBuildingAttribute.LON.toString()));
    }

    /***
     * Check String can be convert to double without exception
     *
     * @param str
     * @return
     */
    private boolean stringIsDouble(String str) {
        try {
            Double.valueOf(str);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /**
     * Return all deployed and unsecured buildings, handle user secured access
     */
    @GetMapping
    ResponseEntity<List<BuildingDTO>> getBuildings(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<BuildingDTO> buildings = buildingService.getDeployed();
        UserInformation userInformation = userInformationService.getCurrent();
        String userEmail = userInformation.getEmail();
        buildings = userService.filterSecuredBuildingDTOs(userEmail, buildings);
        return ResponseEntity.ok(buildings);
    }
}
