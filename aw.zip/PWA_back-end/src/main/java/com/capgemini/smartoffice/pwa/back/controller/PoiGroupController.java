package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.smartoffice.pwa.back.mapper.PoiGroupMapper;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.PoiGroupDTO;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import com.capgemini.smartoffice.pwa.back.service.BuildingService;
import com.capgemini.smartoffice.pwa.back.service.PoiGroupService;
import com.capgemini.smartoffice.pwa.back.service.UserInformationService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = PoiGroupController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PoiGroupController {

    static final String ROOT_API = "api/poigroup";

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private PoiGroupService poiGroupService;

    @Autowired
    private UserInformationService userInformationService;


    /**
     * Return all PoiGroup of a building
     * 
     * @param buildingId
     * @return
     */
    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<PoiGroupDTO>> getBuildingPoiGroup(
            @PathVariable Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (Objects.isNull(buildingId) || buildingId <= 0) {
            log.info("Invalid building id {}", buildingId);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        UserInformation userInformation = this.userInformationService.getCurrent();
        String userEmail = userInformation.getEmail();

        Building building = this.buildingService.getBuilding(buildingId, userEmail);


        if (Objects.isNull(building)) {
            log.info("Building {} not found", buildingId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        List<PoiGroupDTO> poiGroupDTOList = this.poiGroupService.findAllByBuilding(buildingId)
                .stream()
                .map(poiGroup -> PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language))
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOList);
    }

    @GetMapping
    public ResponseEntity<List<PoiGroupDTO>> getListOfIsVisibleOnPWA(
            @RequestParam(required=false) Boolean isVisibleOnPwa,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<PoiGroupDTO> poiGroupDTOs = this.poiGroupService.findAllVisibleOnPWA(isVisibleOnPwa)
                .stream()
                .map(poiGroup -> PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language))
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOs);
    }

}
