package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.ColumnDefault;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
@Entity
@Table(name = "pwa_menu_page")
public class MenuPage implements WithTitle {

   
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MenuPage_Generator")
	@SequenceGenerator(name="MenuPage_Generator", sequenceName = "MenuPage_Sequence")
	private Long id;

	@Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

	@Column(name = "icon")
	private String icon;

	@Column(name = "is_external_link")
	private Boolean isExternalLink;
	// this is the index in the sidebar menu
	@Column(name = "menu_index",nullable = false)
	@ColumnDefault("50")
	private Integer index;

	@ManyToOne
    @JoinColumn(name="parent_id") @JsonIgnore
    private MenuPage parent;
    @Column(name="parent_id", updatable=false,insertable=false)
	private Long parentId;
    
}