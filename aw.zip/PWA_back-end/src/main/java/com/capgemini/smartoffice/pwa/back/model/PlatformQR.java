package com.capgemini.smartoffice.pwa.back.model;

public enum PlatformQR {

	WEB(0), MOBILE(1), WEB_IN_BROWSER(2), ANDROID(3), IOS(4), TABLET(5);

	private final int code;

	PlatformQR(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static PlatformQR fromCode(Integer code) {
		if (code == null)
			return WEB; // default
		for (PlatformQR p : values()) {
			if (p.code == code)
				return p;
		}
		return WEB; // fallback default
	}

}
