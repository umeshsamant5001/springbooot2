package com.capgemini.smartoffice.pwa.back.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * A simple POJO to represent a Vecos Locker Bank
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
@Data
public class VecosLockerBank {

	@JsonProperty("LockerBankId")
	private String id;
	
	@JsonProperty("LockerBankName")
	private String name;
	
	@JsonProperty("StatusPerLockerGroup")
    private List<VecosStatusPerLockerGroup> status;
    	
}