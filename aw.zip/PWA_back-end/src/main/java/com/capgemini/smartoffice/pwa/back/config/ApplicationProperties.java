package com.capgemini.smartoffice.pwa.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * Properties specific to PWA Back End.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@Data
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class

    private final CORS cors = new CORS();
    private final Vecos vecos = new Vecos();
    private final Jwks jwks = new Jwks();
    private final Ping ping = new Ping();
    private final ActionableMessage actionableMessage = new ActionableMessage();
    private final Azure azure = new Azure();

 
    @Data
    public static class Ping {
        private String validateUrl;
        private String clientId;
        private String clientSecret;
    }

    @Data
    public static class CORS {
        private String origins;
    }

    @Data
    public static class Vecos {
        private String scope;

        private final Identity identity = new Identity();
        private final SApi sapi = new SApi();
        private final Batch batch = new Batch();

        @Data
        public static class Batch {
            private String cron;
            private String tz;
        }

        @Data
        public static class Identity {
            private String url;
        }

        @Data
        public static class SApi {
            private String url;
        }
    }

    @Data
    public static class Jwks {
        private String url;
    }

    @Data
    public static class ActionableMessage {
        private boolean enabled;
        private String originatorId;
        private String senderEmail;
        private String checkInMeetingUrl;
        private String cancelMeetingUrl;
        private String tokenSecret;
        private Integer tokenValidityDays = 7;
    }
    
    @Data
    public static class Azure {
        private String tenantId;
        private final GraphApi graphApi = new GraphApi();
        private final GraphApiSendEmail graphApiSendEmail = new GraphApiSendEmail();

        @Data
        public static class GraphApi {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;
            private String notificationUrl;
        } 

        @Data
        public static class GraphApiSendEmail {
        private String url;
        private String clientId;
        private String clientSecret;
        private String scopeUrl;           
        }
    }
}