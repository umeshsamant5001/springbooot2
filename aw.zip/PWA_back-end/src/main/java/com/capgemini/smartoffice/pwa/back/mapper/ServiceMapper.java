package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.model.ServiceDTO;

@Named("ServiceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface ServiceMapper {
    ServiceMapper INSTANCE = Mappers.getMapper(ServiceMapper.class);

    Service serviceDTOToService(ServiceDTO in);

    ServiceDTO serviceToServiceDTO(Service in);

}
