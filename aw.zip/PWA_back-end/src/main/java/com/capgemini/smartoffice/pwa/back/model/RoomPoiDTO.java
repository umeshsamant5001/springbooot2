package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class RoomPoiDTO {

    private Long roomPoiId;
    private String roomName;
    private String roomTitle;
    private Long floorId;
    private String floorName;
    private Long buildingId;
    private Long spaceTypeId;
    private String roomType;
    private Integer roomCapacity;
    private String roomEmail;
    private Boolean checkIn;
    private Boolean checkOut;
    private SensorDataDTO sensorData;

    public RoomPoiDTO(Long roomPoiId, String roomName, String roomTitle, Long floorId,
                   String floorName, Long buildingId, Long spaceTypeId, String roomType,
                   Integer roomCapacity, String roomEmail,Boolean checkIn,Boolean checkOut) {
        this.roomPoiId = roomPoiId;
        this.roomName = roomName;
        this.roomTitle = roomTitle;
        this.floorId = floorId;
        this.floorName = floorName;
        this.buildingId = buildingId;
        this.spaceTypeId = spaceTypeId;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.roomEmail = roomEmail;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }
}


