package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class UserFavoriteBuildingUpdateRequest {

    @NotNull
    @Positive
    private Long buildingId;

    @NotNull
    @Positive
    private Long favoriteFloorId;

    @Size(max = 255)
    private String cityName;

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = "^[\\p{L}\\p{N}\\s'._,\\-()]*$", message = "Invalid characters in first name")
    private String userFirstName;

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = "^[\\p{L}\\p{N}\\s'._,\\-()]*$", message = "Invalid characters in last name")
    private String userLastName;
}
