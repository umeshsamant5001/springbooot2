package com.capgemini.smartoffice.pwa.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class SiteDTO implements  WithTitleDTO {
    private Long id;
	private Long cityId;
    private CityDTO city;
	private Long modifiedAt;
    private Long cdmKeyId;
    private List<BuildingDTO> buildings;
    private String titleFr;
    private String titleEn;
    private String title;
    private Map<String, String> attributes = new HashMap<String, String>();
}
