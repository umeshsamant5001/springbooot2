package com.capgemini.smartoffice.pwa.back.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import com.capgemini.smartoffice.pwa.back.config.DbConfig;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;
import javax.persistence.GenerationType;
import lombok.Data;

@Data
@Entity
@Table(name = "AppRegistrationManagement")
public class AppRegistrationManagement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "device_id")
    private String deviceId;
    @Enumerated(EnumType.STRING)
    @Column(name = "device_type")
    private EnumFcmDeviceType deviceType;
    @Column(name = "email_id")
    private String emailId;
    @Column(name = "created_date_time", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long createdDateTime = (new Date()).getTime() / 1000;
    @Column(name = "updated_date_time", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long updatedDateTime = (new Date()).getTime() / 1000;
    @Column(name = "device_registration_token")
    private String deviceRegistrationToken;

    @Column(name = "country_id")
    private Long countryId;
    @Column(name = "country_name")
    private String countryName;
}
