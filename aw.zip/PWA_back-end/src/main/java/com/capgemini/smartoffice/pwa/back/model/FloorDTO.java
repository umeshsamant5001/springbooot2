package com.capgemini.smartoffice.pwa.back.model;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;

@Data
public class FloorDTO implements WithTitleDTO{
    private Long id;
    private Integer index;
    private Long buildingId;
    private BuildingDTO building;
    private String titleFr;
    private String titleEn;
    private String title;
    private Long modifiedAt;
    private Long cdmKeyId;
    private Map<String, String> attributes = new HashMap<>();
    private Boolean underConstruction;
}
