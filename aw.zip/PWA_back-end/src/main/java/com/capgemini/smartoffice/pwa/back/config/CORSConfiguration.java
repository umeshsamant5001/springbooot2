package com.capgemini.smartoffice.pwa.back.config;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;

@Configuration
@EnableWebMvc
@Slf4j
public class CORSConfiguration implements WebMvcConfigurer {

    @Autowired
    private ApplicationProperties applicationProperties;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        CorsRegistration registration = registry.addMapping("/**");

        log.info("CORS origins: '{}'", this.applicationProperties.getCors().getOrigins().replace(" ", "_"));

        if (Objects.nonNull(this.applicationProperties.getCors().getOrigins()) && !this.applicationProperties.getCors().getOrigins().isEmpty()) {
            registration.allowedOrigins(this.applicationProperties.getCors().getOrigins().split(","));
        } else {
            log.warn("CORS origins are not configured; no origins will be allowed.");
        }

        registration.allowedMethods(CorsConfiguration.ALL);
    }
}
