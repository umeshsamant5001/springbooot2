package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.FloorDTO;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.DeviceDTO;

@Named("DeviceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface DeviceMapper {
	
	DeviceMapper INSTANCE = Mappers.getMapper(DeviceMapper.class);

	Device deviceDTOToDevice(DeviceDTO in);

    @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" })
	DeviceDTO deviceToDeviceDTO(Device in, @Context String language);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }

}