package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "poi_equipment")
public class Equipment implements WithTitle {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Equipment_Generator")
    @SequenceGenerator(name="Equipment_Generator", sequenceName = "Equipment_Sequence")
    private Long id;

    @NotNull
	@Column(name = "name", nullable = false, unique = true)
	private String name;

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

}
