package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class ServiceLocationDTO {
    private Long id;
    private Long serviceId;
    private LevelEnum level;
    private Long cdmKeyId;
    private String status;
}
