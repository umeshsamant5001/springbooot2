package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.model.Country;
import com.capgemini.smartoffice.pwa.back.model.CountryMapping;
import com.capgemini.smartoffice.pwa.back.model.UserAnalytics;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumUserAnalytics;
import com.capgemini.smartoffice.pwa.back.repository.CountryMappingRepository;

import com.capgemini.smartoffice.pwa.back.repository.CountryRepository;
import com.capgemini.smartoffice.pwa.back.repository.UserAnalyticsRepository;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserAnalyticsService {

    @Autowired
    private CountryRepository countryRepository;


	@Autowired
	private UserAnalyticsRepository useranalyticsRepository;

    @Autowired
    private CountryMappingRepository countryMappingRepository;
	
    public UserAnalytics createUserAnalytics(UserAnalytics useranalytics) {
        if (useranalytics == null) {
            throw new IllegalArgumentException("User analytics payload is required");
        }

        String email = safeString(useranalytics.getEmail());

        if (email == null || email.isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }

        try {
            String graphCountry = safeString(useranalytics.getCountry());


            // STEP 1: VALIDATE INPUT

            if (graphCountry == null || graphCountry.isBlank()) {
                log.error("INVALID_INPUT | user={} | reason=Graph country is null or blank", email);

                throw new IllegalArgumentException("Graph country cannot be null or blank for user " + email);
            }

            UserAnalytics safeAnalytics = buildSafeAnalytics(useranalytics, email, graphCountry);

            // STEP 2: COUNTRY MASTER LOOKUP

            Optional<Country> countryOpt = countryRepository.findByTitleEnIgnoreCase(graphCountry);

            if (countryOpt.isPresent()) {
                Country country = countryOpt.get();
                applyCountry(safeAnalytics, country);

                log.info(
                    "COUNTRY_RESOLVED_MASTER | user={} | input={} | resolvedCountry={} | countryId={}",
                    email,
                    graphCountry,
                    country.getTitleEn(),
                    country.getId()
                );

                UserAnalytics saved = useranalyticsRepository.save(safeAnalytics);

                return saved;
            }
            // STEP 3: MAPPING LOOKUP

            Optional<CountryMapping> mappingOpt = countryMappingRepository.findByGraphCountryNameIgnoreCaseAndIsActiveTrue(graphCountry);

            if (mappingOpt.isPresent()) {
                Country mappedCountry = mappingOpt.get().getCountry();

                applyCountry(safeAnalytics, mappedCountry);


                UserAnalytics saved = useranalyticsRepository.save(safeAnalytics);

                return saved;
            }

            // STEP 4: FAILURE

            log.error("COUNTRY_RESOLUTION_FAILED | user={} | graphCountry={} | reason=Not found in master or mapping", email, graphCountry);

            throw new IllegalArgumentException("Country not found in master or mapping for graphCountry=" + graphCountry);
        } catch (Exception e) {
            log.error("USER_ANALYTICS_ERROR | user={} | message={} ", email, e.getMessage(), e);

            throw e; // Controller will return 500
        }
    }


    public List<UserAnalytics> findAll() {
        return this.useranalyticsRepository.findAll();
    }

    public Optional<UserAnalytics> findById(Long id) {
        return this.useranalyticsRepository.findById(id);
    }

    private void applyCountry(UserAnalytics analytics, Country country) {
        analytics.setCountry(country.getTitleEn());
        analytics.setCountry_id(country.getId());
    }

    private String safeString(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = new String(String.valueOf(value)).trim();

        if (trimmed.isEmpty()) {
            return null;
        }

        return new String(trimmed);
    }

    private UserAnalytics buildSafeAnalytics(UserAnalytics source, String email, String graphCountry) {
        UserAnalytics safeAnalytics = new UserAnalytics();

        safeAnalytics.setId(source.getId() == null ? null : Long.valueOf(source.getId()));
        safeAnalytics.setParentId(source.getParentId() == null ? null : Long.valueOf(source.getParentId()));
        safeAnalytics.setActivityDate(source.getActivityDate() == null ? null : Long.valueOf(source.getActivityDate()));
        safeAnalytics.setUserAnalytics(source.getUserAnalytics() == null ? null
                : EnumUserAnalytics.findByName(String.valueOf(source.getUserAnalytics().name())));


        safeAnalytics.setAppUser(safeString(source.getAppUser()));
        safeAnalytics.setModuleName(safeString(source.getModuleName()));
        safeAnalytics.setActivity(safeString(source.getActivity()));
        safeAnalytics.setPlatform(safeString(source.getPlatform()));
        safeAnalytics.setEmail(new String(email));
        safeAnalytics.setCountry(new String(graphCountry));

        return safeAnalytics;
    }
}