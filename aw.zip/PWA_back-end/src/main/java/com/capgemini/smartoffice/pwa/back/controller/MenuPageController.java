package com.capgemini.smartoffice.pwa.back.controller;

import java.util.List;
import java.util.stream.Collectors;
import com.capgemini.smartoffice.pwa.back.service.MenuPageService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.mapper.MenuPageMapper;
import com.capgemini.smartoffice.pwa.back.model.MenuPage;
import com.capgemini.smartoffice.pwa.back.model.MenuPageDTO;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = MenuPageController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class MenuPageController {

    static final String ROOT_API = "api/menupage";

    @Autowired
	private MenuPageService menuPageService;
    
    @GetMapping()
	public ResponseEntity<List<MenuPageDTO>> getAllMenuPages(@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

		List<MenuPage> menuPages = this.menuPageService.getAll();
		if (CollectionUtils.isEmpty(menuPages)){
			return ResponseEntity.noContent().build();
		}

        List<MenuPageDTO> menuPageDTOs = menuPages
            .stream()
            .map(menupage -> MenuPageMapper.INSTANCE.menupageToMenuPageDTO(menupage, language))
			.collect(Collectors.toList());

        return ResponseEntity.ok(menuPageDTOs);
	}
    
}

