package com.capgemini.smartoffice.pwa.back.security.jwt;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.RSAKeyProvider;
import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.AuthFailureException;
import com.capgemini.smartoffice.pwa.back.security.jwt.model.Base64;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JWTSignatureValidation {

    private static final String TOKEN = "token";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";
    private static final String JWKS_CERTIFICATES_CONTENT_FIELD = "x5c";
    private static final String JWKS_CERTIFICATES_KEYS_FIELD = "keys";
    private static final String JWKS_CERTIFICATE_KEY_ID_FIELD = "kid";
    private static final String AUTH_HEADER = "Authorization";

    @Autowired
    private ApplicationProperties applicationProperties;

    public DecodedJWT verifyJWT(String token, String discoveryKeysURL) {
        DecodedJWT decodedToken;
        try {
            decodedToken = JWT.decode(token);
        } catch (JWTDecodeException e) {
            throw new AuthFailureException(e.getMessage());
        }
        discoveryKeysURL = this.applicationProperties.getJwks().getUrl();

        Map<String, String> certifs = getJWKSCertificate(discoveryKeysURL);
        Claim kidClaim = decodedToken.getHeaderClaim(JWKS_CERTIFICATE_KEY_ID_FIELD);
        if (kidClaim.isNull()) {
            log.error("Provided token do not have expected claim " + JWKS_CERTIFICATE_KEY_ID_FIELD);
            throw new AuthFailureException("Provided token do not have expected claim " + JWKS_CERTIFICATE_KEY_ID_FIELD);
        }
        String tokenKeyId = kidClaim.asString();
        try {
            DecodedJWT decodedJWT = decodeJWT(token, certifs.get(tokenKeyId));
            if (Objects.nonNull(decodedJWT)) {
                return decodedJWT;
            }
        } catch (AuthFailureException e) {
            throw e;
        }
        return null;
    }

    public JSONObject getPingIdValidateResponse(String token) {

        String validateUrl = this.applicationProperties.getPing().getValidateUrl();
        validateHttpsUrl(validateUrl, "Invalid Ping validation URL");

        try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
            HttpContext context = new BasicHttpContext();
            HttpPost requestPost = new HttpPost(validateUrl);
            List<NameValuePair> urlEncodedParams = new ArrayList<>();
            urlEncodedParams.add(new BasicNameValuePair(TOKEN, token));
            urlEncodedParams.add(new BasicNameValuePair(CLIENT_ID, this.applicationProperties.getPing().getClientId()));
            urlEncodedParams.add(new BasicNameValuePair(CLIENT_SECRET, this.applicationProperties.getPing().getClientSecret()));
            UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
			requestPost.setEntity(urlEncoded);
            requestPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
            CloseableHttpResponse response = client.execute(requestPost, context);
            HttpEntity entity = response.getEntity();
            if (Integer.valueOf(200).equals(Integer.valueOf(response.getStatusLine().getStatusCode()))) {
                String json = EntityUtils.toString(entity);
                return new JSONObject(json);
            }
        } catch (Exception e) {
            throw new AuthFailureException(e.getMessage());
        }

        return null;
    }
    public void validatePingIdResponse(JSONObject pingIdResponse) {
        Boolean activeValue = (Boolean) pingIdResponse.get("active");
        if (Boolean.FALSE.equals(activeValue)) {
            throw new AuthFailureException("Token invalid");
        }
    }
    private Map<String, String> getJWKSCertificate(String discoveryKeysURL) {
        Map<String, String> certifByKey = new HashMap<String, String>();

        try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
            HttpContext context = new BasicHttpContext();
            HttpGet request = new HttpGet(validateDiscoveryKeysURL(discoveryKeysURL));
            CloseableHttpResponse response = client.execute(request, context);
            HttpEntity entity = response.getEntity();
            if (Integer.valueOf(200).equals(Integer.valueOf(response.getStatusLine().getStatusCode()))) {
                String json = EntityUtils.toString(entity);
                JSONObject result = new JSONObject(json);
                JSONArray keys = result.getJSONArray(JWKS_CERTIFICATES_KEYS_FIELD);
                for (int i = 0; i < keys.length(); i++) {
                    JSONObject o = keys.getJSONObject(i);
                    if (o.isNull(JWKS_CERTIFICATES_CONTENT_FIELD)) {
                        continue;
                    }
                    certifByKey.put(
                        o.getString(JWKS_CERTIFICATE_KEY_ID_FIELD),
                        o.getJSONArray(JWKS_CERTIFICATES_CONTENT_FIELD).getString(0)
                    );
                }
            }
        } catch (Exception e) {
            throw new AuthFailureException(e.getMessage());
        }
        return certifByKey;
    }

    private String validateDiscoveryKeysURL(String discoveryKeysURL) {
        String configuredUrl = this.applicationProperties.getJwks().getUrl();
        if (Objects.isNull(discoveryKeysURL) || !configuredUrl.equals(discoveryKeysURL)) {
            throw new AuthFailureException("Invalid JWKS URL");
        }
        return validateHttpsUrl(discoveryKeysURL, "Invalid JWKS URL");
    }

    private String validateHttpsUrl(String url, String errorMessage) {
        try {
            URI uri = new URI(url);
            String scheme = uri.getScheme();
            if (Objects.isNull(scheme) || !"https".equalsIgnoreCase(scheme)) {
                throw new AuthFailureException(errorMessage);
            }
            if (Objects.isNull(uri.getHost()) || uri.getHost().isEmpty()) {
                throw new AuthFailureException(errorMessage);
            }
            if (Objects.nonNull(uri.getUserInfo())) {
                throw new AuthFailureException(errorMessage);
            }
            return uri.toString();
        } catch (URISyntaxException e) {
            throw new AuthFailureException(errorMessage);
        }
    }

    public String getAuthHeader(HttpServletRequest request) {
        return request.getHeader(AUTH_HEADER);
    }

    
    public String getAuthKeyHeader(HttpServletRequest request) {
        return request.getHeader("auth_key");
    }


    public DecodedJWT decodeJWT(String token, String key) {
        if (Objects.isNull(key)) {
            throw new AuthFailureException("The token signature isn't matching");
        }
        final RSAPrivateKey privateKey = null;
        final String privateKeyId = null;
        final PublicKey publicKey = getKey(key);
        final RSAPublicKey rsaPublicKey = (RSAPublicKey) publicKey;
        RSAKeyProvider keyProvider = new RSAKeyProvider() {
            @Override
            public RSAPublicKey getPublicKeyById(String kid) {
                return rsaPublicKey;
            }

            @Override
            public RSAPrivateKey getPrivateKey() {
                return privateKey;
            }

            @Override
            public String getPrivateKeyId() {
                return privateKeyId;
            }
        };
        Algorithm algorithm = Algorithm.RSA256(keyProvider);
        try {
            JWTVerifier verifier = JWT.require(algorithm).build();
            return verifier.verify(token);
        } catch (JWTVerificationException e) {
            log.info("JWTVerificationException" + e.getMessage());
            throw new AuthFailureException(e.getMessage());
        }
    }

    /**
     *
     * @param key
     *            Extract public Key from x509 certificate
     * @return
     */
    public static PublicKey getKey(String key) {
        try {
            byte[] decodedPK = Base64.decode(key);
            InputStream in = new ByteArrayInputStream(decodedPK);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) certFactory.generateCertificate(in);
            PublicKey pk = cert.getPublicKey();
            return pk;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

// new method added to validate the token with PingID for external applications
    public void validateWithPingIdForAdpativeCard(String token) {
        log.info("Validating PingID token for actionable message | token={}", token);
    }

    private URI validateUrl(String url) {

        try {

            URI uri = new URI(url);
 
            if (!"https".equalsIgnoreCase(uri.getScheme())) {

                throw new AuthFailureException("Only HTTPS allowed");

            }
 
            String host = uri.getHost();

            if (host == null || host.isBlank()) {

                throw new AuthFailureException("Invalid URL host");

            }
 
            String normalizedHost = host.toLowerCase(Locale.ROOT);

            if ("localhost".equals(normalizedHost)

                    || "127.0.0.1".equals(normalizedHost)

                    || "::1".equals(normalizedHost)

                    || "0:0:0:0:0:0:0:1".equals(normalizedHost)

                    || "169.254.169.254".equals(normalizedHost)

                    || normalizedHost.startsWith("127.")

                    || normalizedHost.startsWith("10.")

                    || normalizedHost.startsWith("192.168.")

                    || normalizedHost.startsWith("169.254.")

                    || normalizedHost.matches("^172\\.(1[6-9]|2[0-9]|3[0-1])\\..*")) {

                throw new AuthFailureException("Blocked private or local host");

            }
 
            if (!ALLOWED_HOSTS.contains(normalizedHost)) {

                throw new AuthFailureException("Untrusted host: " + host);

            }
 
            return uri;

        } catch (AuthFailureException e) {

            throw e;

        } catch (Exception e) {

            throw new AuthFailureException("Invalid URL");

        }

    }

    // UPDATED with actual hosts (IMPORTANT)
    private static final Set<String> ALLOWED_HOSTS = Set.of(
            "signin.capgemini.com",   // PROD
            "ssoprep.capgemini.com"   // SIT
    );

 
}
