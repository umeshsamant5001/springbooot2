package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.smartoffice.pwa.back.model.UserRoleLocation;
import com.capgemini.smartoffice.pwa.back.repository.UserRoleLocationRepository;

@Service
public class UserRoleLocationService {
    
    @Autowired
    private UserRoleLocationRepository userRoleLocationRepository;

    @Transactional
    public List<UserRoleLocation> findByUserId(Long userId) {
        List<UserRoleLocation> result = userRoleLocationRepository.findByUserId(userId);

        for (UserRoleLocation userRoleLocation: result) {
            Hibernate.initialize(userRoleLocation.getRole());
        }

        return result;
    }
}
