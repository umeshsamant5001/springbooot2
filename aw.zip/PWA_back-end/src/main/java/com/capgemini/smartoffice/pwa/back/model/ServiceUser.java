package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "service_user")
@IdClass(ServiceUserId.class)
public class ServiceUser {

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    private Service service;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    private User user;

    @Column(name = "count")
    private Long count;

}
