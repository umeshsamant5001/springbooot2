package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.Pattern;

import lombok.Data;

@Data
public class UserFavoriteBuildingInformation {
    private Long buildingId;
    private Long favoriteFloorId;
    private String cityName;
    @Pattern(regexp = "^[\\p{L}\\s'._,\\-()]+$", message = "Invalid characters in first name")
    private String userFirstName;
    @Pattern(regexp = "^[\\p{L}\\s'._,\\-()]+$", message = "Invalid characters in last name")
    private String userLastName;
}
