package com.capgemini.smartoffice.pwa.back.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Entity
@Slf4j
@Table(name = "preference")
public class Preference {
    private static int VISITED_BUILDING_TO_KEEP = 3;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ElementCollection
    @OrderColumn(name = "visit_order")
    @CollectionTable(name = "user_visited_buildings", joinColumns = @JoinColumn(name = "preference_id"))
    @Column(name = "building_id")
    private List<Long> visitedBuildingsIds = new ArrayList<>();

    @Column(name = "user_email")
    String userEmail;

    @OneToOne(mappedBy = "preference", fetch = FetchType.LAZY)
    @JsonIgnore
    private User user;

    @Column(name = "building_id")
    private Long currentBuildingId;

    @Column(name = "city_name")
    private String currentCityName;

    @Column(name = "floor_id")
    private Long currentFloorId;

    @ManyToMany(fetch = FetchType.LAZY)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "preference_service",
        joinColumns = @JoinColumn(name = "preference_id", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "service_id", referencedColumnName = "id")
    )
    private List<Service> favoriteServices = new ArrayList<>();

    @ManyToMany(fetch = FetchType.LAZY)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "preference_language",
        joinColumns = @JoinColumn(name = "preference_id", referencedColumnName = "id"),
        inverseJoinColumns =  @JoinColumn(name = "language_id", referencedColumnName = "id")
    )
    private List<Language> selectedLanguages = new ArrayList<>();

    @Transient
    private List<Building> visitedBuildings = new ArrayList<>(3);

    public void addVisitedBuildingId(Long buildingId, Long newBuildingId) {
        if (visitedBuildingsIds.contains(newBuildingId)) {
            visitedBuildingsIds.removeIf(b -> b.equals(newBuildingId)); // Remove the already present buildingId in the
                                                                        // list
        }
        if (visitedBuildingsIds.contains(buildingId)) {
            visitedBuildingsIds.removeIf(b -> b.equals(buildingId)); // Remove the already present buildingId in the
                                                                     // list
        }

        if (visitedBuildingsIds.size() >= VISITED_BUILDING_TO_KEEP) {
            visitedBuildingsIds.remove(visitedBuildingsIds.size() - 1); // Remove the latest visited building if the
                                                                        // list is full
        }
        visitedBuildingsIds.add(0, buildingId); // Add the new building ID at the beginning of the list
    }
}
