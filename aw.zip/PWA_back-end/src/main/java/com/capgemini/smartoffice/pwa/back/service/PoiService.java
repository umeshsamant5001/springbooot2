package com.capgemini.smartoffice.pwa.back.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.Collections;
import java.util.Arrays;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.capgemini.smartoffice.pwa.back.model.Poi;
import com.capgemini.smartoffice.pwa.back.model.PoiDTO;
import com.capgemini.smartoffice.pwa.back.model.RoomPoiDTO;
import com.capgemini.smartoffice.pwa.back.repository.FloorRepository;
import com.capgemini.smartoffice.pwa.back.repository.PoiGroupRepository;
import com.capgemini.smartoffice.pwa.back.repository.PoiRepository;
import com.capgemini.smartoffice.pwa.back.repository.SpaceTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiService {

	@Autowired
	private PoiRepository poiRepository;

	@Autowired
	private FloorRepository floorRepository;

	@Autowired
	private PoiGroupRepository poiGroupRepository;

	@Autowired
	private SpaceTypeRepository spaceTypeRepository;

	/***
	 * Create a poi
	 * @param poi
	 * @return
	 */
	public Poi createPoi(Poi poi) {
		poi.setModifiedAt((new Date()).getTime() / 1000);
		Poi save = null;
		try {
			save = this.poiRepository.save(poi);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return save;
	}

	public Poi save(Poi poi) {
		poi.setModifiedAt((new Date()).getTime() / 1000);

		return this.poiRepository.save(poi);
	}


	/**
	 * Return all Poi of a Building
	 * @param buildingId The id of the Building
	 * @param excludePoiGroup A list of PoiGroup's name to exclude
	 * @return All the Poi of the associated Building, limited to the excludePoiGroup if present.
	 */
	public List<Poi> findAllByBuildingId(Long buildingId, List<String> excludePoiGroup) {
		if (Objects.isNull(excludePoiGroup) || excludePoiGroup.isEmpty()) {
			return this.poiRepository.findAllByBuildingId(buildingId);
		}

		return this.poiRepository.findAllByBuildingIdExcludeSpaceType(buildingId, excludePoiGroup);
	}

	/**
	 * Return all bookables of a Building
	 * @param buildingId The id of the Building
	 * @return All the Poi of the associated Building, filtered to the poiGroupList if present.
	 */
	public List<Poi> findAllBookableByBuildingId(Long buildingId) {

		return this.poiRepository.findRoomsByBuildingIdAndBookableCategory(buildingId);
	}

    	/**
	 * Return all Poi of a Building
	 * @param buildingId The id of the Building
	 * @return All the Poi of the associated Building, filtered to the poiGroupList if present.
	 */
	public List<Poi> findAllBookableByFloorId(Long floorId) {
		return this.poiRepository.findRoomsByFloorIdAndBookableCategory(floorId);
	}

	/**
	 * Return all Poi of a Floor
	 * @param floorId The id of the Floor
	 * @param excludePoiGroup A list of PoiGroup's name to exclude
	 * @return All the Poi of the associated Floor, except to the excludePoiGroup if present.
	 */
	public List<Poi> findAllByFloorId(Long floorId, List<String> excludePoiGroup) {
		if (Objects.isNull(excludePoiGroup) || excludePoiGroup.isEmpty()) {
			return this.poiRepository.findAllByFloorId(floorId);
		}

		return this.poiRepository.findAllByFloorIdExcludeSpaceType(floorId, excludePoiGroup);
	}

	/**
	 * Return all Poi of a Floor
	 * @param floorId The id of the Floor
	 * @param poiGroupList A list of PoiGroup's name to filter.
	 * @return All the Poi of the associated Floor, filtered to the poiGroupList if present.
	 */
	public List<Poi> findAllByFloorIdAndPoiGroup(Long floorId, List<String> poiGroupList) {
		if (Objects.isNull(poiGroupList) || poiGroupList.isEmpty()) {
			return this.poiRepository.findAllByFloorId(floorId);
		}

		return this.poiRepository.findByPoiGroupNamesNative(floorId, poiGroupList);
	}

	public Poi getById(long poiId) {
		return this.poiRepository.findById(poiId).orElse(null);
	}

	public List<Poi> findAllByGroupIdAndAttribute(Long groupId, String attKeyWanted) {
		return this.poiRepository.findAllByGroupIdAndAttribute(groupId, attKeyWanted);
	}

    /**
     * Retrieves a list of Point of Interest (POI) objects associated with the given title.
     *
     * @param titles List of poi title addresses used to query POIs.
     * @return List of POIs matching the provided email addresses.
    */
    public List<Poi> findAllByTitles(List<String> titles) {
        List<Poi> pois = this.poiRepository.findAllByTitleEnIn(titles);
        if(!CollectionUtils.isEmpty(pois)) {
            pois.forEach(poi -> poi.getFloor());
        }
        return pois;
    }

    /**
     * Retrieves a list of Point of Interest (POI) objects associated with the given email addresses.
     *
     * @param mails List of poi title addresses used to query POIs.
     * @return List of POIs matching the provided email addresses.
    */
    public List<Poi> findAllByMails(List<String> mails) {
        List<Poi> pois = this.poiRepository.findAllByMailsIn(mails);
        if(!CollectionUtils.isEmpty(pois)) {
            pois.forEach(poi -> poi.getFloor());
        }
        return pois;
    }

    public List<Poi> mergeAndRemoveDuplicates(List<Poi> list1, List<Poi> list2) {
        List<Poi> mergedList = new ArrayList<>(list1);
        for (Poi poi : list2) {
            if (!this.contains(mergedList, poi)) {
                mergedList.add(poi);
            }
        }

        return mergedList;
    }

    private Boolean contains(List<Poi> list, Poi poi) {
        return list.stream().anyMatch(p -> {
            return poi.getId().equals(p.getId());
        });
    }

    public List<Poi> initialize(List<Poi> pois) {
        pois.forEach(poi -> Hibernate.initialize(poi.getFloor()));
        return pois;
    }

    public List<Poi> getFreeBookable(Long buildingId) {
        return this.poiRepository.findAllFreeBookable(buildingId);
    }

	/**
     * Retrieves a list of RoomPoiDTO having room information.
     *
     * @param roomEmail room email.
     * @return List of RoomPoiDTO for room identified by roon email.
    */
	public List<RoomPoiDTO> findAllPosByRoomEmail(String roomEmail) {
        List<Object[]> rows = poiRepository.findAllPosByRoomEmail(roomEmail);
        if (rows == null || rows.isEmpty()) return Collections.emptyList();

        return rows.stream()
            .filter(Objects::nonNull)
                .map(r -> new RoomPoiDTO(
                toLong(r[0]),             // roomPoiId
                toStringSafe(r[1]),       // roomName
                toStringSafe(r[2]),       // roomTitle
                toLong(r[3]),             // floorId
                toStringSafe(r[4]),       // floorName
                toLong(r[5]),             // buildingId (fixed)
                toLong(r[6]),             // spaceTypeId
                toStringSafe(r[7]),       // roomType
                toInteger(r[8]),          // roomCapacity
                toStringSafe(r[9]),       // roomEmail
                toBoolean(r[10]),         // checkIn
                toBoolean(r[11])          // checkOut
            ))
            .collect(Collectors.toUnmodifiableList()); 
    }

	private static String toStringSafe(Object o) {
        if (o == null) return null;
        String s = String.valueOf(o).trim();
        return s.isEmpty() ? null : s;
    }

    private static Long toLong(Object o) {
        if (o == null) return null;
        if (o instanceof Long)       return (Long) o;
        if (o instanceof Integer)    return ((Integer) o).longValue();
        if (o instanceof Short)      return ((Short) o).longValue();
        if (o instanceof Byte)       return ((Byte) o).longValue();
        if (o instanceof BigInteger) return ((BigInteger) o).longValue();
        if (o instanceof BigDecimal) return ((BigDecimal) o).longValue();
        if (o instanceof Number)     return ((Number) o).longValue();
        if (o instanceof String) {
            String s = ((String) o).trim();
            if (s.isEmpty()) return null;
            try {
                return Long.parseLong(s);
            } catch (NumberFormatException ignored) { return null; }
        }
        return null;
    }

    private static Integer toInteger(Object o) {
        if (o == null) return null;
        if (o instanceof Integer)    return (Integer) o;
        if (o instanceof Long)       return ((Long) o).intValue();
        if (o instanceof Short)      return ((Short) o).intValue();
        if (o instanceof Byte)       return ((Byte) o).intValue();
        if (o instanceof BigInteger) return ((BigInteger) o).intValue();
        if (o instanceof BigDecimal) return ((BigDecimal) o).intValue();
        if (o instanceof Number)     return ((Number) o).intValue();
        if (o instanceof String) {
            String s = ((String) o).trim();
            if (s.isEmpty()) return null;
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException ignored) { return null; }
        }
        return null;
    }

    private static Boolean toBoolean(Object o) {
        if (o == null) return null;
        if (o instanceof Boolean) return (Boolean) o;
        if (o instanceof String) {
            String s = ((String) o).trim();
            if (s.isEmpty()) return null;
            if ("true".equalsIgnoreCase(s))  return Boolean.TRUE;
            if ("false".equalsIgnoreCase(s)) return Boolean.FALSE;
            if ("1".equals(s) || "yes".equalsIgnoreCase(s) || "y".equalsIgnoreCase(s)) return Boolean.TRUE;
            if ("0".equals(s) || "no".equalsIgnoreCase(s)  || "n".equalsIgnoreCase(s)) return Boolean.FALSE;
            return null;
        }
       
        return null;
    }

    public Map<String, List<String>> getPoiDetails(Long buildingId) {
    List<Object[]> rows = poiRepository.getPoiDetailsByBuildingId(buildingId);

    // rows: r[0] = poiName, r[1] = comma-separated devices
    return rows.stream()
        .filter(Objects::nonNull)
        .collect(Collectors.toMap(
            r -> (String) r[0],
            r -> normalizeDevices((String) r[1])  // convert to List<String>
        ));
    }

    private List<String> normalizeDevices(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return new ArrayList<>();
        }
        return Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .collect(Collectors.toCollection(ArrayList::new));
    }
   
    public void addDevicesToPoiDto(List<PoiDTO> poiDTOList, Long buildingId , Long floorId) {
       
        final Map<String, List<String>> mapPoiData =
                    (buildingId != null) ? getPoiDetails(buildingId)
                                         : getPoiDetailsByFloor(floorId);
        
            poiDTOList.forEach(poiDTO -> {
                List<String> devices = mapPoiData.getOrDefault(poiDTO.getName(), new ArrayList<>());
       
            poiDTO.setDevices(new ArrayList<>(devices));
        });
    }
    
    public Map<String, List<String>> getPoiDetailsByFloor(Long floorId) {
        List<Object[]> rows = poiRepository.getPoiDetailsByFloorId(floorId);
        return rows.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(
                        r -> (String) r[0],
                        r -> normalizeDevices((String) r[1])
                ));
    }


}
