package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.EmailInfo;
import com.capgemini.smartoffice.pwa.back.model.EmailInfoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Named("EmailInfoMapper")
@Mapper(config = DtoMapperConfig.class)
public interface EmailInfoMapper {
    
    EmailInfoMapper INSTANCE = Mappers.getMapper(EmailInfoMapper.class);

    EmailInfoDTO emailInfoToEmailInfoDTO(EmailInfo in);

    EmailInfo emailInfoDTOToEmailInfo(EmailInfoDTO in);
}