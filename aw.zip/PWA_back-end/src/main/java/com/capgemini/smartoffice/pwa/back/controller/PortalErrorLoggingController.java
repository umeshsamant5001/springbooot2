package com.capgemini.smartoffice.pwa.back.controller;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.WebDataBinder;

import com.capgemini.smartoffice.pwa.back.model.PortalErrorLoggingCreateRequest;
import com.capgemini.smartoffice.pwa.back.model.PortalErrorLoggingDTO;
import com.capgemini.smartoffice.pwa.back.service.PortalErrorLoggingService;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = PortalErrorLoggingController.ROOT_API)
public class PortalErrorLoggingController {

        @InitBinder
        public void initBinder(WebDataBinder binder) {
                binder.setDisallowedFields("save");
        }

        public static final String ROOT_API = "/api/portal-error-logging";

        @Autowired
        private PortalErrorLoggingService portalErrorLoggingService;

        @PostMapping
        public ResponseEntity<PortalErrorLoggingDTO> createPortalErrorLogging(
                        @Valid @RequestBody PortalErrorLoggingCreateRequest portalErrorLoggingRequest) {
                                
                if (Objects.isNull(portalErrorLoggingRequest)) {
                    return ResponseEntity.badRequest().build();    
                }

                PortalErrorLoggingDTO sanitizedPortalErrorLoggingDTO = new PortalErrorLoggingDTO();
                sanitizedPortalErrorLoggingDTO.setClassName(portalErrorLoggingRequest.getClassName() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getClassName())));
                sanitizedPortalErrorLoggingDTO.setModule(portalErrorLoggingRequest.getModule() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getModule())));
                sanitizedPortalErrorLoggingDTO.setLineNumber(portalErrorLoggingRequest.getLineNumber() == null ? null : Long.valueOf(portalErrorLoggingRequest.getLineNumber()));
                sanitizedPortalErrorLoggingDTO.setDescription(portalErrorLoggingRequest.getDescription() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getDescription())));
                sanitizedPortalErrorLoggingDTO.setState(portalErrorLoggingRequest.getState() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getState())));
                sanitizedPortalErrorLoggingDTO.setErrorType(portalErrorLoggingRequest.getErrorType() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getErrorType())));
                sanitizedPortalErrorLoggingDTO.setData(portalErrorLoggingRequest.getData() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getData())));
                sanitizedPortalErrorLoggingDTO.setLoggingDate(portalErrorLoggingRequest.getLoggingDate() == null ? null : Long.valueOf(portalErrorLoggingRequest.getLoggingDate()));
                sanitizedPortalErrorLoggingDTO.setErrorLoggingType(portalErrorLoggingRequest.getErrorLoggingType() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getErrorLoggingType())));
                sanitizedPortalErrorLoggingDTO.setUserEmail(portalErrorLoggingRequest.getUserEmail() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getUserEmail())));
                sanitizedPortalErrorLoggingDTO.setHttpMethod(portalErrorLoggingRequest.getHttpMethod() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getHttpMethod())));
                sanitizedPortalErrorLoggingDTO.setRequestUrl(portalErrorLoggingRequest.getRequestUrl() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getRequestUrl())));
                sanitizedPortalErrorLoggingDTO.setRequestPayload(portalErrorLoggingRequest.getRequestPayload() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getRequestPayload())));
                sanitizedPortalErrorLoggingDTO.setResponseStatus(portalErrorLoggingRequest.getResponseStatus() == null ? null : Long.valueOf(portalErrorLoggingRequest.getResponseStatus()));
                sanitizedPortalErrorLoggingDTO.setResponseBody(portalErrorLoggingRequest.getResponseBody() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getResponseBody())));
                sanitizedPortalErrorLoggingDTO.setStackTrace(portalErrorLoggingRequest.getStackTrace() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getStackTrace())));
                sanitizedPortalErrorLoggingDTO.setBrowserInfo(portalErrorLoggingRequest.getBrowserInfo() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getBrowserInfo())));
                sanitizedPortalErrorLoggingDTO.setApplicationPortal(portalErrorLoggingRequest.getApplicationPortal() == null ? null : new String(String.valueOf(portalErrorLoggingRequest.getApplicationPortal())));


                log.info("Incoming error log portalErrorLoggingDTO : {}", sanitizedPortalErrorLoggingDTO);

                PortalErrorLoggingDTO responseDTO = portalErrorLoggingService.createPortalErrorLogging(sanitizedPortalErrorLoggingDTO);

                return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
        }
}
