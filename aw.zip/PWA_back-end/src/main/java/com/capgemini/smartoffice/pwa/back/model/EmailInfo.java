package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;

@Data
@Entity
public class EmailInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "building_id")
    private int buildingId;

    @Column(name = "building_name")
    private String buildingName;

    @Column(name = "floor_id")
    private int floorId;

    @Column(name = "floor_name")
    private String floorName;

    @Column(name = "poi_name")
    private String poiName;

    @Column(name = "email")
    private String email;
}
