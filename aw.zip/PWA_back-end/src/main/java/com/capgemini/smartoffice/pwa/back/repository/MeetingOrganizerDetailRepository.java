package com.capgemini.smartoffice.pwa.back.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.MeetingOrganizerDetail;

@Repository
public interface MeetingOrganizerDetailRepository extends JpaRepository<MeetingOrganizerDetail, String>{

	Optional<MeetingOrganizerDetail> findByMeetingId(String meetingId);

}