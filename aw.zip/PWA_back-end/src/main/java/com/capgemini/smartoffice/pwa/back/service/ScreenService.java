package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.Screen;
import com.capgemini.smartoffice.pwa.back.repository.ScreensRepository;

@Service
public class ScreenService {

    @Autowired
    private ScreensRepository screensRepository;

    public List<Screen> findAll() {
        return this.screensRepository.findAll();
    }
}
