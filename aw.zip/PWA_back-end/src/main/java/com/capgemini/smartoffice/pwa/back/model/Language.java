package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
@Entity
@Table(name="language")
public class Language {

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Language_Generator")
	@SequenceGenerator(name = "Language_Generator", sequenceName = "Language_Sequence")
	private Long id;

    @Column(name = "locale")
    public String locale;

    @Column(name = "name")
    public String name;
}
