package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.model.EmailInfo;
import com.capgemini.smartoffice.pwa.back.repository.EmailInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class EmailService {
    
    @Autowired
    private EmailInfoRepository emailInfoRepository;
    
    
    @Transactional(readOnly = true)
    public List<EmailInfo> getEmailByBuildingAndFloor(Long buildingId, Long floorId) {
        return this.emailInfoRepository.getEmailIdsByBuildingAndFloorId(buildingId, floorId);
    }
}