package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.mapper.NewsMapper;
import com.capgemini.smartoffice.pwa.back.model.News;
import com.capgemini.smartoffice.pwa.back.model.NewsDTO;
import com.capgemini.smartoffice.pwa.back.repository.NewsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NewsService {
    
    @Autowired
    private NewsRepository newsRepository;

     public List<NewsDTO> findAllNewsIsActive() {
        List<News> news = newsRepository.findAllNewsIsActive();
        List<NewsDTO> newsDTOs = news.stream()
                                    .map(NewsMapper.INSTANCE::newsToNewsDTO)
                                    .collect(Collectors.toList());
        return newsDTOs;
    }
}
