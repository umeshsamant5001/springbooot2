package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.FrontLabel;
import com.capgemini.smartoffice.pwa.back.model.FrontLabelDTO;

@Named("FrontLabelMapper")
@Mapper(config = DtoMapperConfig.class)
public interface FrontLabelMapper {
    FrontLabelMapper INSTANCE = Mappers.getMapper(FrontLabelMapper.class);

    FrontLabelDTO frontLabelTofrontLabelDTO(FrontLabel in);

    FrontLabel frontLabelDTOTofrontLabel(FrontLabelDTO in);
}
