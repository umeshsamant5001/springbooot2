package com.capgemini.smartoffice.pwa.back.model.enumeration;

/**
 * Enum type use to represent the state of the meeting reservation status
 */
public enum EnumMeetingStatus {
	CREATED, CHECKED_IN, CHECKED_OUT, NOSHOW,CANCELLED;
}
