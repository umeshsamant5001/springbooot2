package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.model.MenuPage;
import com.capgemini.smartoffice.pwa.back.repository.MenuPageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MenuPageService {
    
    @Autowired
	private MenuPageRepository menupageRepository;
    
    public List<MenuPage> getAll() {
        return this.menupageRepository.findAll();
    }
    
}