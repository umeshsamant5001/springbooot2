package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum Rating {

    POOR(1),
    AVERAGE(2),
    GOOD(3),
    GREAT(4),
    EXCELLENT(5);

    private final int value;

    Rating(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static Rating fromValue(int value) {
        for (Rating rating : values()) {
            if (rating.value == value) {
                return rating;
            }
        }

        throw new IllegalArgumentException("Invalid rating value: " + value);

    }
}