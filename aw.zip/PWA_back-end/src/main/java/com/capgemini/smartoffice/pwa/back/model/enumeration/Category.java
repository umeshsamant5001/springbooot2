package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum Category {

    General, Downtime;

    public static Category findByName(String name) {
        Category result = null;
        for (Category category : values()) {
            if (category.name().equalsIgnoreCase(name)) {
                result = category;
                break;
            }
        }
        return result;
    }

}
