package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.repository.CountryRepository;

@Service
public class CountryService {

    @Autowired
    private CountryRepository countryRepository;

    public Map<Long, String> getCountryNameByBuildingIds(List<Long> buildingIds) {
        return this.countryRepository.getCountryNameByBuildingIds(buildingIds)
                .stream()
                .collect(Collectors.toMap(
                    (tuple) -> tuple.get(0, Long.class),
                    (tuple) -> tuple.get(1, String.class)
                ));
    }
}
