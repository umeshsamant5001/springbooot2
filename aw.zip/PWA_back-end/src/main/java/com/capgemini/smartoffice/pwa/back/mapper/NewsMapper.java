package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.News;
import com.capgemini.smartoffice.pwa.back.model.NewsDTO;

@Mapper(config = DtoMapperConfig.class)
public interface NewsMapper {

    NewsMapper INSTANCE =  Mappers.getMapper(NewsMapper.class);

    News newsDTOToNews(NewsDTO in);

    NewsDTO newsToNewsDTO(News in);

}
