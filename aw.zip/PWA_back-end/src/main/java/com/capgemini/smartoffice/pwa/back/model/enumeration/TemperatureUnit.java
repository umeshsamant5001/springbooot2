package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum TemperatureUnit {
    CELSIUS, FAHRENHEIT;
}
