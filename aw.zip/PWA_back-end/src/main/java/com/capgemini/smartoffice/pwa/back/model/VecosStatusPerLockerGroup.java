package com.capgemini.smartoffice.pwa.back.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * A simple POJO to represent a Status of Locker Bank
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
@Data
public class VecosStatusPerLockerGroup {

	@JsonProperty("LockerGroupId")
	private String id;
	
	@JsonProperty("LockerGroupName")
	private String name;

    @JsonProperty("AvailableDynamicLockers")
    private Long availableDynamicLockers;    	
}