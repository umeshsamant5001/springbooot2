package com.capgemini.smartoffice.pwa.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class ServiceDTO {
    private Long id;
    private String image;
    private String name;
    private Integer priority;
    private Map<String, String> attributes = new HashMap<String, String>();
    private List<ServiceLocationDTO> locations = new ArrayList<>();
    private List<ServiceTranslationDTO> translations = new ArrayList<>();
    private Long usedTimes;
}
