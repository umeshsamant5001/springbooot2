package com.capgemini.smartoffice.pwa.back.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.capgemini.smartoffice.pwa.back.config.DbConfig;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumMeetingStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
@Entity
@Table(name = "meeting", indexes = { @Index(name = "IDX_MODIFIED_MEETING", columnList = "modified_at") })
@EqualsAndHashCode
public class Meeting {
	@Id
    @Column(name = "id")
    private String id;

    @Column(name = "start_time")
    private Long from;

    @Column(name = "end_time")
    private Long to;

    @Column(name = "start_time_utc")
    private Long fromUtc;

    @Column(name = "end_time_utc")
    private Long toUtc;

    @Column(name = "check_status")
    @Enumerated(EnumType.STRING)
    private EnumMeetingStatus checkStatus;

    @Column(name = "room")
    private String room;

    // like devices, a meeting cannot be linked to a POI Id as it can be removed
    // during POI import
    // need to link to both poi name and floor
    @ManyToOne
    @JoinColumn(name = "floor_id")
    private Floor floor;

    @Column(name = "floor_id", updatable = false, insertable = false)
    private Long floorId;

    @Column(name = "poi_name")
    private String poiName;

    @Column(name = "created_ts")
    private Long created;

    @Column(name = "modified_at", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
    private Long modifiedAt = (new Date()).getTime() / 1000;

    @Column(name = "noshow_counter")
    @JsonIgnore
    private Integer noshowCounter = 0;

    @Column(name = "alert_checkin")
    @JsonIgnore
    private Boolean alertCheckIn = false;
}
