package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.capgemini.smartoffice.pwa.back.model.EmailInfo;

public interface EmailInfoRepository extends JpaRepository<EmailInfo, Integer> {

    @Procedure(name = "getEmailIdsByBuildingAndFloorId")
    List<EmailInfo> getEmailIdsByBuildingAndFloorId(@Param("buildingId") Long buildingId, @Param("floorId") Long floorId);
}

