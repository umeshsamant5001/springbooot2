package com.capgemini.smartoffice.pwa.utils;

import java.util.Objects;

public class LanguageUtils {
    /** Default language to use */
    public static final String DEFAULT_LANGUAGE = "en";

    /**
     * Return the locale to use, based on the http header
     * @param headerLanguage The string of the HTTP Header Accepted-Language
     * @return
     */
    public static String getLanguage(String headerLanguage) {
        if (Objects.isNull(headerLanguage) || headerLanguage.length() < 2) {
            return DEFAULT_LANGUAGE;
        }

        return headerLanguage.substring(0, 2);
    }
}
