package com.capgemini.smartoffice.pwa.back.model.enumeration;

/**
 * Enumeration representing different privileges.
*/
public enum EnumAccess {
    READ, WRITE, NONE
}