package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.smartoffice.pwa.back.mapper.BuildingMapper;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.repository.BuildingRepository;
import com.capgemini.smartoffice.pwa.back.repository.UserRepository;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BuildingService {

    static final String API_TAG = "Building";

    @Autowired
    private BuildingRepository buildingRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public Building getBuilding(Long buildingId) {
        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return null;
        }

        Building building = buildingRepository.findByIdAndSecuredFalse(buildingId);

        if (Objects.isNull(building)) {
            return null;
        }

        Hibernate.initialize(building.getFloors());

        return building;
    }

    @Transactional
    public Building getBuilding(Long buildingId, String userEmail) {
        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return null;
        }

        Building building = buildingRepository.findByIdAndSecuredFalse(buildingId);

        if (Objects.nonNull(building)) {
            Hibernate.initialize(building.getFloors());
            return building;
        }

        if (Objects.isNull(userEmail) || userEmail.trim().isEmpty()) {
            return null;
        }

        User user = userRepository.findByEmailNoDeletedCheck(userEmail.trim());

        if (Objects.isNull(user)) {
            return null;
        }

        Building securedBuilding = buildingRepository.findSecuredBuildingByUserIdAndBuildingId(user.getId(), buildingId);

        if (Objects.isNull(securedBuilding)) {
            return null;
        }

        Hibernate.initialize(securedBuilding.getFloors());

        return securedBuilding;
    }


    @Transactional
    public List<Building> getDeployedBuilding(boolean withFloor) {
        List<Building> buildings = this.buildingRepository.findAllByDeployedTrue();

        if (withFloor) {
            for (Building building : buildings) {
                Hibernate.initialize(building.getFloors());
            }
        }

        return buildings;
    }

    @Transactional
    public List<BuildingDTO> getDeployed() {
        List<Building> buildings = buildingRepository.findAllByDeployedTrue();
        if (Objects.isNull(buildings)) {
            return null;
        }

        for (Building building : buildings) {
            Hibernate.initialize(building.getFloors());
        }

        List<BuildingDTO> buildingDTOs = buildings
                        .stream()
                        .map(building -> BuildingMapper.INSTANCE.buildingToBuildingDTO(building,"en"))
                        .collect(Collectors.toList());

        return buildingDTOs;
    }

    public List<Building> findAll() {
        return this.buildingRepository.findAll();
    }

    public Building findByBuildingIdWithParent(Long buildingId) {
        return this.buildingRepository.findByBuildingIdWithParent(buildingId);
    }
    public List<Long> findSecuredBuildingIdsByUserId(Long userId) {
        return buildingRepository.findSecuredBuildingIdsByUserId(userId);
    }
        
    /**
     * Fetches a list of building location IDs that have lockers.     
     * @return List of building location IDs as Strings.
    */
    public List<String> getBuildingLocations() {
        return buildingRepository.findllBuildingsWithLockers();
    }
}
