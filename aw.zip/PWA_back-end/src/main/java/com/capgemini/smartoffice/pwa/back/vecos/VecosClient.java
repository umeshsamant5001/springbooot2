package com.capgemini.smartoffice.pwa.back.vecos;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.model.CountryTenant;
import com.capgemini.smartoffice.pwa.back.model.Poi;
import com.capgemini.smartoffice.pwa.back.model.PoiGroup;
import com.capgemini.smartoffice.pwa.back.model.VecosLockerBank;
import com.capgemini.smartoffice.pwa.back.model.VecosSession;
import com.capgemini.smartoffice.pwa.back.model.exception.UnauthorizedException;
import com.capgemini.smartoffice.pwa.back.model.exception.VecosConnectorException;
import com.capgemini.smartoffice.pwa.back.repository.CountryTenantRepository;
import com.capgemini.smartoffice.pwa.back.service.BuildingService;
import com.capgemini.smartoffice.pwa.back.service.PoiService;
import com.capgemini.smartoffice.pwa.back.service.PoiGroupService;
import com.capgemini.smartoffice.pwa.back.service.VecosSessionService;
import io.jsonwebtoken.io.Decoders;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.http.HttpRequest;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.smartoffice.pwa.back.config.Constants;
import java.io.IOException;

@Slf4j
@Component
public class VecosClient {

    public static final String POI_GROUP_LOCKER_NAME = "locker";

    public static final String LOCKER_BANK_ID = "lockerBankId";

    public static final String LOCKER_TENANT = "lockerTenant";

    public static final String LOCKER_FREE_NUMBER = "lockerFreeNumber";

    private static final String GRANT_TYPE = "password";

    private static final String LOGIN_ENDPOINT = "connect/token";

    private static final String LOCKER_BANK_ENDPOINT = "api/lockerbanks/";

    private static final String STATUS_ENDPOINT = "/status";

    public static final String VECOS_SECTION_ENDPOINT = "/sections";
    public static final String VECOS_SECTION_ENDPOINT_API = "api/sections";
    public static final String VECOS_SECTION_LOCKERBANKS_ENDPOINT = "/lockerbanks";
    public static final String VECOS_LOCATION_ENDPOINT = "api/locations";
    public static final String LOCKER_BANK_NAME = "lockerBankName";


    private Integer retryCounter = 0;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private VecosSessionService sessionService;

    @Autowired
    private VecosRequestFactory factory;

    @Autowired
    private VecosResponseParser resParser;

    @Autowired
    private PoiGroupService poiGroupService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CountryTenantRepository countryTenantRepository;


    public void getLockerBankStatus(Poi poi) {
        if (Objects.isNull(poi.getAttributes()) || poi.getAttributes().isEmpty()) {
            return;
        }

        String lockerBankId = poi.getAttributes().get(LOCKER_BANK_ID);
        String lockerTenant = poi.getAttributes().get(LOCKER_TENANT);

        // Verify a Session exist else authenticate
        if (!this.isAuthenticated(lockerTenant)) {
            this.authenticate(lockerTenant);
        }

        Map<String, String> header = new HashMap<>();
        header.put("Authorization", "Bearer " + this.sessionService.getSession(lockerTenant).getAccessToken());

        // Get lockerBank by lockerBankId associated to the poi
        VecosLockerBank lockerBank = null;
        while (Objects.isNull(lockerBank) && this.retryCounter < 3) {
            try {
                lockerBank = factory.get(
                    this.getSapiUri(
                        LOCKER_BANK_ENDPOINT + lockerBankId.trim() + STATUS_ENDPOINT),
                        header,
                        Collections.emptyMap(),
                        resParser::readVecosLockerBankStatus
                    );
            } catch (UnauthorizedException e) {
                this.retryCounter++;

                log.warn("Trying to re-authenticate to tenant : {} (attent {})", lockerTenant, this.retryCounter);

                this.authenticate(lockerTenant);
            }
        }

        if (Objects.isNull(lockerBank)) {
            throw new VecosConnectorException("Error while getting Locker information");
        }

        if (!Objects.isNull(lockerBank) && !CollectionUtils.isEmpty(lockerBank.getStatus())) {
            Long freeNumber = lockerBank.getStatus().stream()
                    .filter(status -> status.getAvailableDynamicLockers() != null)
                    .mapToLong(status -> status.getAvailableDynamicLockers())
                    .sum();
            log.info("Locker : {}, Number of free locker : {}", lockerBankId, freeNumber);
            poi.getAttributes().put(LOCKER_FREE_NUMBER, String.valueOf(freeNumber));        
            this.poiService.save(poi);
        }
    }

    /**
     * 
     */
    public void retrieveAllVecosLockerBankStatus() {
        this.retryCounter = 0;

        // Retrieve Locker group
        PoiGroup lockerGroup = this.poiGroupService.findByName(POI_GROUP_LOCKER_NAME);

        if (Objects.isNull(lockerGroup)) {
            log.warn("No PoiGROUP named : {}", POI_GROUP_LOCKER_NAME);

            return;
        }
        
        // Retrieve all lockers with lockerBanIdAttribute        
        List<Poi> poisLocker = this.poiService.findAllByGroupIdAndAttribute(lockerGroup.getId(), LOCKER_BANK_ID)
            .stream()
            // Sort by tenant (to avoid using changing to much of tenant)
            .sorted((poi1, poi2) -> {
                String tenant1 = poi1.getAttributes().getOrDefault(LOCKER_TENANT, "");
                String tenant2 = poi2.getAttributes().getOrDefault(LOCKER_TENANT, "");

                return tenant1.compareTo(tenant2);
            })
            .collect(Collectors.toList());

        // For each locker, get vecos status
        for (Poi poi : poisLocker) {
            // Retrive bank Id from bank name 
            setBankIdFromBankName(poi);
            String lockerBankId = poi.getAttributes().get(LOCKER_BANK_ID);
            String lockerTenant = poi.getAttributes().get(LOCKER_TENANT);
            String lockerBankName = poi.getAttributes().get(LOCKER_BANK_NAME);
           if (
                !Objects.isNull(lockerBankId) && !lockerBankId.isEmpty() && !Constants.NULLSTRING.equalsIgnoreCase(lockerBankId)
                && !Objects.isNull(lockerTenant) && !lockerTenant.isEmpty() && !Constants.NULLSTRING.equalsIgnoreCase(lockerTenant)
                && !Objects.isNull(lockerBankName) && !lockerBankName.isEmpty() && !Constants.NULLSTRING.equalsIgnoreCase(lockerBankName)
            ) {
                // Get vecos status for a poi
                this.getLockerBankStatus(poi);
            }
        }
    }

    /**
     * Function that allow to get an access token to use vecos APIs
     */
    private VecosSession authenticate(String tenant) {
        log.info("tenant: {}", tenant);

        CountryTenant countryTenant = countryTenantRepository.findByTenant(tenant)
                .orElseThrow(() -> new VecosConnectorException("Tenant not found: " + tenant));

        String password = new String(Decoders.BASE64.decode(countryTenant.getPassword()));

        List<NameValuePair> params = List.of(
                new BasicNameValuePair("username", countryTenant.getUsername()),
                new BasicNameValuePair("password", password),
                new BasicNameValuePair("grant_type", GRANT_TYPE),
                new BasicNameValuePair("scope", applicationProperties.getVecos().getScope()));

        Map<String, String> header = Map.of("Authorization", countryTenant.getBasic());

        try {
            sessionService.setSession(tenant,
                    factory.postFormUrlEncoded(getIdentityUri(), header, params, resParser::readAuthenticateRes));
            log.info("Vecos authentication success for tenant: {}", tenant);
        } catch (UnauthorizedException e) {
            throw new VecosConnectorException("Unauthorized to authenticate to Vecos for tenant: " + tenant);
        }

        return sessionService.getSession(tenant);
        
    }

    /**
     * Check if an authentication is done
     * @return
     */
    private boolean isAuthenticated(String tenant) {
        return !Objects.isNull(this.sessionService.getSession(tenant));
    }

    /**
     * Get the URL for the authentication
     * @return
     */
    private String getIdentityUri() {
        return this.applicationProperties.getVecos().getIdentity().getUrl() + LOGIN_ENDPOINT;
    }

    /**
     * Get the URL for the API
     * @param endpoint The endpoint to apply
     * @return
     */
    private String getSapiUri(String endpoint) {
        return this.applicationProperties.getVecos().getSapi().getUrl() + endpoint;
    }

    /**
     * Sets the Locker Bank ID in the POI attributes based on the Locker Bank Name
     * and Tenant.
     * 
     * This method checks if the POI has attributes and whether the Locker Bank Name
     * and Tenant are present.
     * If the Locker Bank ID is either blank or equals a predefined null string, it
     * retrieves the Bank ID
     * using the Vecos client and updates the POI attributes accordingly.
     *
     * @param poi the POI object containing locker-related attributes
     */
    private void setBankIdFromBankName(Poi poi) {
        if (Objects.nonNull(poi.getAttributes())) {
            String lockerBankName = poi.getAttributes().get(LOCKER_BANK_NAME);
            String lockerTenant = poi.getAttributes().get(LOCKER_TENANT);
            String lockerBankId = poi.getAttributes().get(LOCKER_BANK_ID);
            boolean hasBankName = Objects.nonNull(lockerBankName) && !lockerBankName.isBlank();
            boolean hasTenant = Objects.nonNull(lockerTenant) && !lockerTenant.isBlank();
            // boolean bankIdIsBlankOrNull = Objects.nonNull(lockerBankId) && lockerBankId.isBlank()
            //         || Constants.NULLSTRING.equalsIgnoreCase(lockerBankId);
            boolean bankIdIsBlankOrNull = Objects.isNull(lockerBankId) || (Objects.nonNull(lockerBankId) && (lockerBankId.isBlank()
                    || Constants.NULLSTRING.equalsIgnoreCase(lockerBankId)));
            if (hasBankName && hasTenant && bankIdIsBlankOrNull) {
                lockerBankId = retrieveBankIdFromBankName(lockerBankName, lockerTenant);              
                poi.getAttributes().put(LOCKER_BANK_ID, lockerBankId);
            }
        }
    }

    /**
     * Retrieves the locker bank ID based on the provided locker bank name.
     * It searches through location, section, and locker bank data to find a match.
     * 
     * @param lockerBankNameValue the name of the locker bank to search for
     * @param lockerTenant        the name of the locker tenant
     */
    public String retrieveBankIdFromBankName(String lockerBankNameValue, String lockerTenant) {
        List<String> lockerLocations = buildingService.getBuildingLocations();
        Map<String, String> locationIdMap = fetchLocationIds(lockerLocations, lockerTenant);
        String lockerBankId = null;
        if (!locationIdMap.isEmpty()) {
            outerLoop: for (String locationId : locationIdMap.values()) {
                List<String> sectionIds = fetchSectionIds(locationId, lockerTenant);
                if (!sectionIds.isEmpty()) {
                    for (String sectionId : sectionIds) {
                        Map<String, String> lockerBanks = fetchLockerBanks(sectionId, lockerTenant);
                        if (!lockerBanks.isEmpty()) {
                            for (Map.Entry<String, String> entry : lockerBanks.entrySet()) {
                                if (Objects.nonNull(lockerBankNameValue) && Objects.nonNull(entry.getValue()) &&
                                        lockerBankNameValue.trim().equalsIgnoreCase(entry.getValue().trim())) {
                                    lockerBankId = entry.getKey();
                                    break outerLoop;
                                }
                            }
                        }
                    }
                }
            }
        }
        return lockerBankId;
    }    

    /**
     * Fetches location IDs from the Vecos API for the given locker locations and
     * tenant.
     * This method ensures authentication, sends an HTTP GET request to the Vecos
     * endpoint,
     * parses the JSON response, and returns a map of location names to their
     * corresponding IDs. 
     * @param lockerLocations List of locker location names to filter from the
     * response
     * @param lockerTenant The tenant identifier used for authentication and API
     * access
     * @return Map of location names to their corresponding location IDs
     */
    private Map<String, String> fetchLocationIds(List<String> lockerLocations, String lockerTenant) {
        if (!this.isAuthenticated(lockerTenant)) {
            this.authenticate(lockerTenant);
        }
        HttpResponse<String> response = sendLocationRequest(lockerTenant);
        if (response == null || response.body() == null) {
            log.warn("No response received from location endpoint.");
            return Collections.emptyMap();
        }
        JsonNode root = parseJson(response.body());
        if (root == null) {
            return Collections.emptyMap();
        }
        return extractMatchingLocations(root, lockerLocations);
    }
    
    /**
     * Parses a JSON string into a JsonNode using Jackson's ObjectMapper.
     *
     * @param responseBody The raw JSON string to be parsed.
     * @return A JsonNode representing the parsed JSON structure, or null if parsing fails.
    */
    private JsonNode parseJson(String responseBody) {
        try {
            return objectMapper.readTree(responseBody);
        } catch (IOException e) {
            log.error("Error parsing JSON response", e);
            return null;
        }
    }
    
    /**
     * Sends an HTTP GET request to the Vecos location endpoint to retrieve location data.
     *
     * @param lockerTenant The tenant identifier used for authentication.
     * @return HttpResponse containing the response body as a String, or null if the request fails.
    */
    private HttpResponse<String> sendLocationRequest(String lockerTenant) {
        String accessToken = sessionService.getSession(lockerTenant).getAccessToken();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(getSapiUri(VECOS_LOCATION_ENDPOINT)))
                .header("Authorization", "Bearer " + accessToken)
                .GET()
                .build();
        try {
            return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            log.error("Error while sending request to {}", VECOS_LOCATION_ENDPOINT, e);
            return null;
        }
    }
    
    /**
     * Extracts location IDs from the JSON response that match the given list of locker location names.
     *
     * @param root The root JsonNode containing the full JSON response.
     * @param lockerLocations A list of locker location names to filter by.
     * @return A map of location name to location ID for matching entries.
    */
    private Map<String, String> extractMatchingLocations(JsonNode root, List<String> lockerLocations) {
        Map<String, String> result = new HashMap<>();
        JsonNode locations = root.get("Locations");

        if (locations != null && locations.isArray()) {
            for (JsonNode loc : locations) {
                String id = loc.path("Id").asText(null);
                String name = loc.path("Name").asText(null);
                if (name != null && lockerLocations.contains(name)) {
                    result.put(name, id);
                }
            }
        } else {
            log.info("No 'Locations' array found in JSON.");
        }

        return result;
    }
    
    /**
     * Fetches section IDs for a given location from the Vecos API.
     * This method ensures the tenant is authenticated, sends an HTTP GET request to
     * the location-specific section endpoint, parses the JSON response, and returns a
     * list of section IDs.
     * @param locationId   The ID of the location for which sections are to be
     * tched
     * @param lockerTenant The tenant identifier used for authentication and API
     * access
     * @return List of section IDs associated with the given location
     */
    private List<String> fetchSectionIds(String locationId, String lockerTenant) {
        if (!this.isAuthenticated(lockerTenant)) {
            this.authenticate(lockerTenant);
        }
        HttpResponse<String> response = sendSectionRequest(locationId, lockerTenant);
        if (response == null || response.body() == null) {
            log.warn("No response received for section request.");
            return Collections.emptyList();
        }

        JsonNode root = parseJson(response.body());
        if (root == null) {
            return Collections.emptyList();
        }

        return extractSectionIds(root);
    }
    
    /**
     * Sends an HTTP GET request to the Vecos section endpoint to retrieve section data for a given location.
     *
     * @param locationId   The ID of the location for which sections are to be fetched.
     * @param lockerTenant The tenant identifier used for authentication.
     * @return HttpResponse containing the response body as a String, or null if the request fails.
    */
    private HttpResponse<String> sendSectionRequest(String locationId, String lockerTenant) {
        String accessToken = sessionService.getSession(lockerTenant).getAccessToken();
        String uri = getSapiUri(VECOS_LOCATION_ENDPOINT + "/" + locationId + VECOS_SECTION_ENDPOINT);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .header("Authorization", "Bearer " + accessToken)
                .GET()
                .build();

        try {
            return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            log.error("Error while sending section request to {}", uri, e);
            return null;
        }
    }
    
    /**
     * Extracts section IDs from the JSON response.
     *
     * @param root The root JsonNode containing the full JSON response.
     * @return A list of section IDs as Strings.
    */
    private List<String> extractSectionIds(JsonNode root) {
        List<String> sectionIds = new ArrayList<>();
        JsonNode sections = root.get("Sections");

        if (sections != null && sections.isArray()) {
            for (JsonNode section : sections) {
                String id = section.path("Id").asText(null);
                if (id != null) {
                    sectionIds.add(id);
                }
            }
        } else {
            log.info("No 'Sections' array found in JSON.");
        }

        return sectionIds;
    }   
    
    /**
     * Fetches locker bank details for a given section and tenant.
     * @param sectionId    The ID of the section for which locker banks are to be retrieved.
     * @param lockerTenant The tenant identifier used for authentication.
     * @return A map of locker bank IDs to their names.
    */
    private Map<String, String> fetchLockerBanks(String sectionId, String lockerTenant) {
        if (!this.isAuthenticated(lockerTenant)) {
            this.authenticate(lockerTenant);
        }

        HttpResponse<String> response = sendLockerBankRequest(sectionId, lockerTenant);
        if (response == null || response.body() == null) {
            log.warn("No response received for locker bank request.");
            return Collections.emptyMap();
        }

        JsonNode root = parseJson(response.body());
        if (root == null) {
            return Collections.emptyMap();
        }

        return extractLockerBanks(root);
    }
    
    /**
     * Sends an HTTP GET request to the locker bank endpoint for a specific section.
     * @param sectionId    The ID of the section.
     * @param lockerTenant The tenant identifier used for authentication.
     * @return HttpResponse containing the response body as a String, or null if the request fails.
    */
    private HttpResponse<String> sendLockerBankRequest(String sectionId, String lockerTenant) {
        String accessToken = sessionService.getSession(lockerTenant).getAccessToken();
        String uri = getSapiUri(VECOS_SECTION_ENDPOINT_API + "/" + sectionId + VECOS_SECTION_LOCKERBANKS_ENDPOINT);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .header("Authorization", "Bearer " + accessToken)
                .GET()
                .build();

        try {
            return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            log.error("Error while sending locker bank request to {}", uri, e);
            return null;
        }
    }
    
    /**
     * Extracts locker bank IDs and names from the JSON response.
     *
     * @param root The root JsonNode containing the full JSON response.
     * @return A map of locker bank IDs to their corresponding names.
    */
    private Map<String, String> extractLockerBanks(JsonNode root) {
        Map<String, String> lockerBankMap = new HashMap<>();
        JsonNode lockerBanks = root.get("LockerBanks");

        if (lockerBanks != null && lockerBanks.isArray()) {
            for (JsonNode lockerBank : lockerBanks) {
                String id = lockerBank.path("Id").asText(null);
                String name = lockerBank.path("Name").asText(null);
                if (id != null && name != null) {
                    lockerBankMap.put(id, name);
                }
            }
        } else {
            log.info("No 'LockerBanks' array found in JSON.");
        }

        return lockerBankMap;
    }
}