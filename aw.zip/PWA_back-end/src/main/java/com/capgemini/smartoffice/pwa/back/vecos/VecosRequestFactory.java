package com.capgemini.smartoffice.pwa.back.vecos;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.capgemini.smartoffice.pwa.back.model.exception.VecosConnectorException;
import com.capgemini.smartoffice.pwa.utils.CheckedFunction;

@Component
public class VecosRequestFactory {

    private static final int DEFAULT_CONNECT_TIMEOUT = 5000;
    private static final int DEFAULT_TIMEOUT = 30000;

    private RequestConfig config;

    @PostConstruct
    public void init() {
        config = RequestConfig.custom().setConnectTimeout(DEFAULT_CONNECT_TIMEOUT)
                .setConnectionRequestTimeout(DEFAULT_TIMEOUT).setSocketTimeout(DEFAULT_TIMEOUT).build();
    }

    /**
     * GET api call
     * 
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param responseParser the function to apply to read response
     * @return T a custom object defined by function
     * @throws E
     */
    public <T, E extends Exception> T get(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            CheckedFunction<CloseableHttpResponse, T, E> responseParser) throws E {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }

            HttpGet req = new HttpGet(builder.build());

            if (!CollectionUtils.isEmpty(headers)) {
                req.setHeaders(convertHeaders(headers));
            }

            return execute(req, responseParser);
        } catch (URISyntaxException e) {
            throw new VecosConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * POST api call with x-www-form-urlencoded query
     * 
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param urlEncodedParams
     * @param responseParser
     * @return
     * @throws Exception
     */
    public <T, E extends Exception> T postFormUrlEncoded(String endpoint, Map<String, String> headers, List<NameValuePair> urlEncodedParams,
            CheckedFunction<CloseableHttpResponse, T, E> responseParser) throws E {
        try {
            URIBuilder builder = new URIBuilder(endpoint);

            HttpPost req = new HttpPost(builder.build());
            UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
            req.setEntity(urlEncoded);

            if (!CollectionUtils.isEmpty(headers)) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException | UnsupportedEncodingException e) {
            throw new VecosConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * Execute an http call and before closures,
     * apply a function to manage response
     * 
     * @param <T>
     * @param req
     * @param responseParserFunc the function to parse the HttpResponse
     * @return an object defined by responseParserFunc
     * @throws E
     */
    private <T, E extends Exception> T execute(HttpUriRequest req,
            CheckedFunction<CloseableHttpResponse, T, E> responseParserFunc) throws E {
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
                CloseableHttpResponse res = httpClient.execute(req)) {
            return responseParserFunc.apply(res);
        } catch (IOException e) {
            String message = String.format("Impossible to access Vecos API on endpoint:[%s], error:[%s]", req.getURI(),
                    e.getMessage());
            throw new VecosConnectorException(message);
        }
    }

    private List<NameValuePair> convertQueryParams(final Map<String, String> mapParams) {
        return mapParams.entrySet().stream()
                .map(e -> new BasicNameValuePair(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    private Header[] convertHeaders(final Map<String, String> mapHeaders) {
        return mapHeaders.entrySet().stream()
                .map(e -> new BasicHeader(e.getKey(), e.getValue()))
                .toArray(Header[]::new);
    }

    private String getUriBuilderErrorMessage(String endpoint, String message) {
        return String.format("Unable to build Vecos URI - endpoint:[%s] - error:[%s]", endpoint, message);
    }
}