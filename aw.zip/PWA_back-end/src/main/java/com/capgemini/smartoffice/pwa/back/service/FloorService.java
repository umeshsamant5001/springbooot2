package com.capgemini.smartoffice.pwa.back.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.repository.FloorRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FloorService {
	@Autowired
	private FloorRepository floorRepository;

    @Transactional
    public Floor getFloor(Long floorId, Long buildingId) {
		if (Objects.isNull(floorId) || Objects.isNull(buildingId)) {
			return null;
		}

		Floor floor = floorRepository.findByIdAndBuildingId(floorId, buildingId).orElse(null);

		if (Objects.isNull(floor)) {
			return null;
		}

		return floor;
	}


	public boolean floorExist(Long floorId) {
		return this.floorRepository.existsById(floorId);
	}
}
