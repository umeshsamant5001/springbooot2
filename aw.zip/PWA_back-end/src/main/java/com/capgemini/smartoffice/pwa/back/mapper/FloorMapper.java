package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;

import java.util.Map;

import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.FloorDTO;
import com.capgemini.smartoffice.pwa.back.model.Floor;

@Named("FloorMapper")
@Mapper(config = DtoMapperConfig.class)
public interface FloorMapper {

	FloorMapper INSTANCE = Mappers.getMapper(FloorMapper.class);

    @Named("mapUnderConstruction")
    default Boolean mapUnderConstruction(Map<String, String> attributes) {
        if (attributes != null && attributes.containsKey("hidden")) {
            return Boolean.parseBoolean(attributes.get("hidden"));
        }
        return false;
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("floorToFloorDTO")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "building", target = "building", qualifiedByName = { "buildingToBuildingDTOWithoutChildren" }),
        @Mapping(source = "attributes", target = "underConstruction", qualifiedByName = "mapUnderConstruction")
    })
	FloorDTO floorToFloorDTO(Floor in, @Context String language);
	
	Floor floorDTOToFloor(FloorDTO in);

    @Named("buildingToBuildingDTOWithoutChildren")
    default BuildingDTO _buildingToBuildingDTOWithoutChildren(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutChildren(building, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("floorToFloorDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "building", ignore = true),
        @Mapping(source = "attributes", target = "underConstruction", qualifiedByName = "mapUnderConstruction")
    })
    FloorDTO _floorToFloorDTOWithoutParent(Floor in, @Context String language);

}
