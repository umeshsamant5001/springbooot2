package com.capgemini.smartoffice.pwa.back.model;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

import lombok.Data;

@Data
public class SafeUserFeedbackData {

    private String emailId;

    private Rating rating;

    private RatingFrom ratingFrom;

    private String comment;
}
