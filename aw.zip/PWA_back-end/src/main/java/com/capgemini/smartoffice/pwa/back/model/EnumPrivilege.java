package com.capgemini.smartoffice.pwa.back.model;

/**
 * Enumeration representing different privileges.
*/
public enum EnumPrivilege {
    READ, WRITE
}