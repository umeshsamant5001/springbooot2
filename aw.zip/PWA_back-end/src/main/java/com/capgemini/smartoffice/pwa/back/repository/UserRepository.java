package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.User;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {

    @Query("SELECT user From User user WHERE user.email = :email AND deleted != 1")
    User findByEmail(@Param("email") String email);

    @Query("SELECT user From User user WHERE user.email = :email")
    User findByEmailNoDeletedCheck(@Param("email") String email);

}
