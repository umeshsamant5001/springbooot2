package com.capgemini.smartoffice.pwa.back.model;


public enum LevelEnum {
    GLOBAL,
    COUNTRY,
    CITY,
    SITE,
    BUILDING
}
