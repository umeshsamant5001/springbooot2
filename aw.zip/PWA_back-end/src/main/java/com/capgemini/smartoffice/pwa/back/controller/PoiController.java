package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.smartoffice.pwa.back.mapper.MeetingMapper;
import com.capgemini.smartoffice.pwa.back.mapper.PoiMapper;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.EventDTO;
import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.Meeting;
import com.capgemini.smartoffice.pwa.back.model.MeetingDTO;
import com.capgemini.smartoffice.pwa.back.model.Poi;
import com.capgemini.smartoffice.pwa.back.model.PoiDTO;
import com.capgemini.smartoffice.pwa.back.model.RoomPoiDTO;
import com.capgemini.smartoffice.pwa.back.model.SensorDataDTO;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;
import com.capgemini.smartoffice.pwa.back.service.BuildingService;
import com.capgemini.smartoffice.pwa.back.service.DeviceService;
import com.capgemini.smartoffice.pwa.back.service.FloorService;
import com.capgemini.smartoffice.pwa.back.service.MeetingService;
import com.capgemini.smartoffice.pwa.back.service.PoiService;
import com.capgemini.smartoffice.pwa.back.service.SensorDataService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = PoiController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PoiController {

    static final String ROOT_API = "api/poi";

    static final String DESK_TYPE = "desk";

    static final String HIDE_POI = "hidePoi";

    static final String UNKNOWN = "unknown";

    static final String ROOM_CONFERENCE = "room_conference";

    static final String ROOM_BUBBLE = "room_bubble";

    static final String CONF_ROOM_MAIL = "conf_room_mail";

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private SensorDataService sensorDataService;

    @Autowired
    private MeetingService meetingService;

    @GetMapping("building/{buildingId}")
    public ResponseEntity<List<PoiDTO>> getBuildingPoi(
            @PathVariable Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Building building = this.buildingService.getBuilding(buildingId);

        if (Objects.isNull(building)) {
            log.info("Building {} not found", buildingId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        // The list of PoiGroup we don't want in the result
        List<String> excludePoiGroup = List.of("desk");

        List<PoiDTO> poiDTOList = this.poiService.findAllByBuildingId(buildingId, excludePoiGroup)
                .stream()
                .map(poi -> PoiMapper.INSTANCE.poiToPoiDTONoJoin(poi, language))
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiDTOList);
    }

    @GetMapping("floor/{floorId}")
    public ResponseEntity<List<PoiDTO>> getPoiByFloor(
            @PathVariable Long floorId,
            @RequestParam(required = false) String poigroup,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        boolean floorExist = this.floorService.floorExist(floorId);

        if (!floorExist) {
            log.info("Floor {} not found", floorId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        List<String> poiGroupList = null;
        if (Objects.nonNull(poigroup) && !poigroup.isEmpty()) {
            poiGroupList = Arrays.asList(poigroup.split(","));
        }

        List<PoiDTO> poiDTOList = this.poiService.findAllByFloorIdAndPoiGroup(floorId, poiGroupList)
                .stream()
                .filter(poi -> !poi.getAttributes().containsKey(HIDE_POI) ||
                        poi.getAttributes().containsKey(HIDE_POI) &&
                                poi.getAttributes().get(HIDE_POI).equals("false")
                        ||
                        poi.getAttributes().get(HIDE_POI).equals(""))
                .map(poiEntity -> PoiMapper.INSTANCE.poiToPoiDTO(poiEntity, language))
                .collect(Collectors.toList());

        List<Device> deviceList = this.deviceService.findAllViaPoiByFloorIdAndPoiGroup(floorId, poiGroupList);

        this.addSensorDataToPoi(poiDTOList, deviceList);

        poiDTOList
                .stream()
                .forEach(poiDTO -> {
                    if (Objects.nonNull(poiDTO.getSensorData())) {
                        String lastChange = poiDTO.getSensorData().getLastChange();
                        if (Objects.nonNull(lastChange)) {
                            boolean twentyFours = checkTwentyFours(lastChange);
                            if (!twentyFours) {
                                poiDTO.getSensorData().setOccupation(UNKNOWN);
                            }
                        }
                    }
                });

        return ResponseEntity.ok(poiDTOList);
    }

    @GetMapping("/sensor/floor/{floorId}")
    public ResponseEntity<List<Device>> getSensorsByFloor(
            @PathVariable Long floorId,
            @RequestParam(required = false) String poigroup,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        boolean floorExist = this.floorService.floorExist(floorId);

        if (!floorExist) {
            log.info("Floor {} not found", floorId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        List<String> poiGroupList = null;
        if (Objects.nonNull(poigroup) && !poigroup.isEmpty()) {
            poiGroupList = Arrays.asList(poigroup.split(","));
        }

        List<Device> deviceList = this.deviceService.findAllViaPoiByFloorIdAndPoiGroupExcludeTablet(floorId,
                poiGroupList);

        deviceList
                .stream()
                .forEach(device -> {
                    if (Objects.nonNull(device.getLastChange()) &&
                            !checkTwentyFours(device.getLastChange().toString()) &&
                            !Objects.isNull(device.getAttributes().get("state"))) {
                        device.getAttributes().remove("state");
                        device.getAttributes().put("occupation", UNKNOWN);
                    } else if (!Objects.isNull(device.getAttributes().get("state"))) {
                        device.getAttributes().put("occupation", device.getAttributes().get("state"));
                    }
                });

        return ResponseEntity.ok(deviceList);
    }

    @GetMapping("/findFreeRoom")
    public ResponseEntity<List<PoiDTO>> findFreeRoom(
            @RequestParam Long buildingId,
            @RequestParam(required = false) Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (Objects.isNull(buildingId)) {
            return ResponseEntity.badRequest().build();
        }

        List<Poi> pois = this.poiService.getFreeBookable(buildingId);
        List<PoiDTO> poiDTOs = pois
                .stream()
                .filter(poi -> (!poi.getAttributes().containsKey(HIDE_POI) ||
                        (poi.getAttributes().containsKey(HIDE_POI) &&
                                poi.getAttributes().get(HIDE_POI).equals("false") ||
                                poi.getAttributes().get(HIDE_POI).equals(""))))
                .map(poi -> PoiMapper.INSTANCE.poiToPoiDTONoJoin(poi, language))
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiDTOs);
    }

    @GetMapping("meeting")
    public ResponseEntity<List<PoiDTO>> getMeetingRoom(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Define a function that return the list of Poi
        Supplier<List<Poi>> func;
        if (Objects.nonNull(floorId)) {
            func = () -> this.poiService.findAllBookableByFloorId(floorId);
        } else if (Objects.nonNull(buildingId)) {
            func = () -> this.poiService.findAllBookableByBuildingId(buildingId);
        } else {
            // Error, one of the parameters à required.
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "One of \"buildingId\" or \"floorId\" is required");
        }

        List<PoiDTO> poiDTOList = func
            .get()
            .stream()
            .map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, language))
            .collect(Collectors.toList());

        poiService.addDevicesToPoiDto(poiDTOList,buildingId,floorId);

        return ResponseEntity.ok(poiDTOList);

    }

    
    @PostMapping(value = "/{poiId}/meeting")
    public ResponseEntity<MeetingDTO> createMeeting(
            @PathVariable Long poiId,
            @RequestBody EventDTO eventDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Poi poi = this.poiService.getById(poiId);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }

        Floor floor = poi.getFloor();
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        eventDTO = sanitizeEventDTO(eventDTO);

        // Check if the PoiName in the meeting object is the same as the name of the
        // Poi.
        if (Objects.isNull(eventDTO.getPoiName()) || !Objects.equals(eventDTO.getPoiName(), poi.getName())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The provided Poi name doesn't match with the selected poi.");
        }

        // ✅ Check if the POI has a TABLET device
        boolean hasTablet = deviceService.existsByPoiNameAndDeviceType(poi.getName(), EnumDeviceType.TABLET);
        if (hasTablet) {
            return ResponseEntity.status(HttpStatus.ACCEPTED).build();
        }
        try {
            String buildingTimeZone = floor.getBuilding().getTimezoneJava();
            Meeting savedMeeting = this.meetingService.create(eventDTO, buildingTimeZone, floor);
            return ResponseEntity.ok(MeetingMapper.INSTANCE.meetingToMeetingDTO(savedMeeting));
        } catch (IllegalArgumentException e) {
            log.info(e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /**
     * Retrieves capacity and floor information associated with given title or
     * email.
     *
     * @param titles   List of poi titles for which capacity and floor information
     *                 is requested.
     * @param mails    List of poi mails for which capacity and floor information is
     *                 requested.
     * @param language The preferred language for the response (default is "en").
     * @return ResponseEntity containing a JSON array with email, capacity, and
     *         floor information.
     */
    @GetMapping(value = "getCapacityAndFloor")
    public ResponseEntity<Object> getCapacityAndFloor(
            @RequestParam List<String> titles,
            @RequestParam(required = false) List<String> mails,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        // Check if the list of emails is empty, and return a bad request if true
        if (CollectionUtils.isEmpty(titles)) {
            return ResponseEntity.badRequest().build();
        }

        // Create a JSON array to store email, capacity, and floor information
        JSONArray jsonArray = new JSONArray();

        // Retrieve POIs associated with the provided title
        List<Poi> pois_title = this.poiService.findAllByTitles(titles);
        if (CollectionUtils.isEmpty(pois_title)) {
            return new ResponseEntity<>(jsonArray.toString(), HttpStatus.OK);
        }

        // Retrieve POIs associated with the provided mail
        List<Poi> pois_mail = new ArrayList<>();
        if (!CollectionUtils.isEmpty(mails)) {
            pois_mail = this.poiService.findAllByMails(mails);
        }

        List<Poi> pois = this.poiService.mergeAndRemoveDuplicates(pois_title, pois_mail);

        this.poiService.initialize(pois);

        List<PoiDTO> poiDTOs = pois.stream().map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, language))
                .collect(Collectors.toList());

        // Iterate through each POI and populate the JSON array
        poiDTOs.forEach(poiDTO -> {
            JSONObject object = new JSONObject();
            // Populate email, capacity, and floor information in the JSON object
            object.put("title", poiDTO.getTitleEn());
            object.put("capacity", poiDTO.getAttributes().get("capacity"));
            object.put("floor", new JSONObject(poiDTO.getFloor()));
            object.put("email", poiDTO.getAttributes().get("conf_room_mail"));
            jsonArray.put(object);
        });

        // Return the JSON array in the response with a status of OK
        return new ResponseEntity<>(jsonArray.toString(), HttpStatus.OK);
    }

    private void addSensorDataToPoi(List<PoiDTO> poisDTO, List<Device> devices) {
        // Get the SensorDataDTO for all the Poi (by their name)
        Map<String, SensorDataDTO> mapSensorData = this.sensorDataService.getPoiSensorData(poisDTO, devices);

        // Put the SensorDataDTO on the corresponding PoiDTO
        poisDTO
                .stream()
                .forEach(poiDTO -> {
                    String poiName = poiDTO.getName();

                    if (mapSensorData.containsKey(poiName)) {
                        poiDTO.setSensorData(mapSensorData.get(poiName));
                    }
                });
    }

    private boolean checkTwentyFours(String lastChange) {
        long lastChangeMillis = Long.parseLong(lastChange) * 1000;
        long currentTimeMillis = System.currentTimeMillis();

        // Subtract 24 hours (24 hours * 60 minutes * 60 seconds * 1000 milliseconds)
        long twentyFourHoursInMillis = 24 * 60 * 60 * 1000;
        long adjustedMillis = currentTimeMillis - twentyFourHoursInMillis;

        if (adjustedMillis < lastChangeMillis) {
            return true;
        }
        return false;
    }

    @GetMapping("/room/{roomEmail}")
    public ResponseEntity<List<RoomPoiDTO>> getAllPoisByRopomEmail(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("roomEmail") String roomEmail) {
        
        List<RoomPoiDTO> roomPoiDto = this.poiService.findAllPosByRoomEmail(roomEmail);

        if (CollectionUtils.isEmpty(roomPoiDto)) {
            return ResponseEntity.notFound().build();
        }
       
        Long roomTypeId = roomPoiDto.get(0).getSpaceTypeId();
        Long buildingId = roomPoiDto.get(0).getBuildingId();
        Long floorId = roomPoiDto.get(0).getFloorId();

        List<Device> deviceList = this.deviceService.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(
                    Arrays.asList(roomTypeId), Arrays.asList(buildingId), Arrays.asList(floorId));

        addSensorDataToPoiForRoom(roomPoiDto, deviceList);        

        return ResponseEntity.ok(roomPoiDto);
    }
    
    /**
     * Adds sensor data to each RoomPoiDTO for a given list of rooms.
     * @param roompoisDTO List of RoomPoiDTO objects representing rooms (Points of Interest).
     * @param devices     List of Device objects used to fetch sensor data.
    */
    private void addSensorDataToPoiForRoom(List<RoomPoiDTO> roompoisDTO, List<Device> devices) {
        // Get the SensorDataDTO for room
        Map<String, SensorDataDTO> mapSensorData = this.sensorDataService.getPoiSensorDataForRoom(roompoisDTO, devices);

        // Put the SensorDataDTO on the corresponding RoomPoiDTO
        roompoisDTO
                .stream()
                .forEach(roomPoiDTO -> {
                    String poiName = roomPoiDTO.getRoomName();

                    if (mapSensorData.containsKey(poiName)) {
                        roomPoiDTO.setSensorData(mapSensorData.get(poiName));
                    }
                });
    }

    @PostMapping(value = "/mobile/{poiId}/meeting")
    public ResponseEntity<MeetingDTO> createMeetingForScanAndBook(
            @PathVariable Long poiId,
            @RequestBody EventDTO eventDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Poi poi = this.poiService.getById(poiId);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }

        Floor floor = poi.getFloor();
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        eventDTO = sanitizeEventDTO(eventDTO);

        // Check if the PoiName in the meeting object is the same as the name of the
        // Poi.
        if (Objects.isNull(eventDTO.getPoiName()) || !Objects.equals(eventDTO.getPoiName(), poi.getName())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The provided Poi name doesn't match with the selected poi.");
        }
    
        try {
            String buildingTimeZone = floor.getBuilding().getTimezoneJava();
            Meeting savedMeeting = this.meetingService.create(eventDTO, buildingTimeZone, floor);
            return ResponseEntity.ok(MeetingMapper.INSTANCE.meetingToMeetingDTO(savedMeeting));
        } catch (IllegalArgumentException e) {
            log.info(e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    private EventDTO sanitizeEventDTO(EventDTO source) {
        if (Objects.isNull(source)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request body is required");
        }

        EventDTO sanitizedEventDTO = new EventDTO();
        sanitizedEventDTO.setId(source.getId());
        sanitizedEventDTO.setFrom(source.getFrom());
        sanitizedEventDTO.setTo(source.getTo());
        sanitizedEventDTO.setRoom(source.getRoom());
        sanitizedEventDTO.setFloorId(source.getFloorId());
        sanitizedEventDTO.setPoiName(source.getPoiName());
        sanitizedEventDTO.setEventStartTime(source.getEventStartTime());
        sanitizedEventDTO.setEventEndTime(source.getEventEndTime());
        sanitizedEventDTO.setEventTimeZone(source.getEventTimeZone());
        sanitizedEventDTO.setOrganizerEmail(source.getOrganizerEmail());
        sanitizedEventDTO.setOrganizerName(source.getOrganizerName());
        return sanitizedEventDTO;
    }

}
