package com.capgemini.smartoffice.pwa.back.model;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingConverter;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;

import lombok.Data;

@Entity
@Table(name = "smartoffice_user_feedback")
@Data
public class UserFeedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "email_id", nullable = false)
    private String emailId;

    @Convert(converter = RatingConverter.class)
    @Column(name = "rating")
    private Rating rating;

    @Enumerated(EnumType.STRING)
    private RatingFrom ratingFrom;

    @Column(length = 1000)
    private String comment;

    @Column(name = "created_date")
    private Long createdDate;

    @Column(name = "modified_date")
    private Long modifiedDate;
}
