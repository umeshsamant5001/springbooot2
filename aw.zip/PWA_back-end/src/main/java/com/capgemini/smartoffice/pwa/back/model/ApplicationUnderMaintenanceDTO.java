package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class ApplicationUnderMaintenanceDTO {
    private Long id;
    private String createdBy;   
	private Long createdDateTime;
	private Long endDateTime;
    private Long startDateTime;
    private Boolean isActive;
    private String message;
    private Platform platform;
}
