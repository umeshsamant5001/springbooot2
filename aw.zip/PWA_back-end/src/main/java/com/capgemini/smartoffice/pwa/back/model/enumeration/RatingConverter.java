package com.capgemini.smartoffice.pwa.back.model.enumeration;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;


@Converter(autoApply = true)
public class RatingConverter
        implements AttributeConverter<Rating, Integer> {

    @Override
    public Integer convertToDatabaseColumn(Rating rating) {
        return rating != null ? rating.getValue() : null;
    }

    @Override
    public Rating convertToEntityAttribute(Integer value) {
        return value != null ? Rating.fromValue(value) : null;
    }
}
