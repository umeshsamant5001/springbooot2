package com.capgemini.smartoffice.pwa.back.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;

import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.config.GraphHelper;
import com.capgemini.smartoffice.pwa.back.helper.TimeZoneConverter;
import com.capgemini.smartoffice.pwa.back.model.EventDTO;
import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.Meeting;
import com.capgemini.smartoffice.pwa.back.model.MeetingOrganizerDetail;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.smartoffice.pwa.back.repository.MeetingOrganizerDetailRepository;
import com.capgemini.smartoffice.pwa.back.repository.MeetingRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MeetingService {

    @Autowired
    private MeetingRepository meetingRepository;

    @Autowired
    private GraphHelper graphHelper;
    private final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();

    @Autowired
    private MeetingOrganizerDetailRepository meetingOrganizerDetailRepository;

    @Autowired
    private ActionableMessageService actionableMessageService;

    /**
     * Save a new meeting
     *
     * @param meeting The meeting to save.
     * @throws IllegalArgumentException When data are not ok for a creation.
     */
    public Meeting create(EventDTO eventDto, String buildingTimeZone,Floor floor)
            throws IllegalArgumentException {
        this.validateMeetingForCreation(eventDto);

        final String encodedId = encodeValue(eventDto.getId());
        final String roomEmail =  eventDto.getRoom();
        final String organizerEmail =  eventDto.getOrganizerEmail();
        log.info("[create] Start | eventId={} (encoded={}) | organizerEmail={} | floorId={} | tz={}",
            eventDto.getId(), encodedId, organizerEmail, eventDto.getFloorId(), buildingTimeZone);
        
        Optional<Meeting> existingMeeting = this.meetingRepository.findByCustomId(encodedId);
        Meeting meeting = null;
        if (existingMeeting.isPresent()) {
            log.info("Existing meeting found | eventId={} | checking Graph status", eventDto.getId());
            meeting = existingMeeting.get();
            boolean cancelledOrNotFound = graphHelper.isMeetingCancelledOrDeclinedWithRetry(organizerEmail,roomEmail, eventDto.getId());
            EnumMeetingStatus newStatus = cancelledOrNotFound ? EnumMeetingStatus.CANCELLED : EnumMeetingStatus.CREATED;
            log.info("Graph result | eventId={} | cancelledOrNotFound={} | mappedStatus={}",
                eventDto.getId(), cancelledOrNotFound, newStatus);
            if (meeting.getCheckStatus() != newStatus) {
                log.info("Status change detected | eventId={} | from={} → to={}",
                        eventDto.getId(), meeting.getCheckStatus(), newStatus);
                meeting.setCheckStatus(newStatus);
                meeting.setModifiedAt(System.currentTimeMillis());
                meetingRepository.save(meeting);
                log.info("Meeting updated | eventId={} | newStatus={} | modifiedAt={}",
                        eventDto.getId(), newStatus, meeting.getModifiedAt());
            } else {
                log.info(" No status change | eventId={} | status remains={}", eventDto.getId(), newStatus);
            }
 
            log.info("Returning existing meeting | eventId={}", eventDto.getId());
            return meeting;
        } else {
            log.info("No existing meeting | creating new entity | eventId={}", eventDto.getId());
            meeting = createMeetingFromEvent(eventDto, buildingTimeZone, floor);
            boolean cancelledOrNotFound = graphHelper.isMeetingCancelledOrDeclinedWithRetry(organizerEmail, roomEmail ,eventDto.getId());
            EnumMeetingStatus status = cancelledOrNotFound ? EnumMeetingStatus.CANCELLED : EnumMeetingStatus.CREATED;
            log.info("Graph result | eventId={} | cancelledOrNotFound={} | mappedStatus={}",
                    eventDto.getId(), cancelledOrNotFound, status);
    
            meeting.setCheckStatus(status);
            meeting.setCreated(System.currentTimeMillis());
            meeting.setModifiedAt(System.currentTimeMillis());
    
            meeting = meetingRepository.save(meeting);
            log.info("Meeting created | eventId={} | status={} | created={} | modifiedAt={}",
                    eventDto.getId(), status, meeting.getCreated(), meeting.getModifiedAt());
            log.info("meeting created  id {}  " , meeting.getId());

             // to save meetingOrganizerDetail data
            MeetingOrganizerDetail meetingOrganizerDetail = new MeetingOrganizerDetail();
            meetingOrganizerDetail.setOrganizerEmail(eventDto.getOrganizerEmail());
            meetingOrganizerDetail.setOrganizerName(eventDto.getOrganizerName());
            meetingOrganizerDetail.setCreatedDateTime(System.currentTimeMillis());
            meetingOrganizerDetail.setCreatedFrom("PWA_Backend");

            // Save meeting first so FK exists
            meetingOrganizerDetail.setMeeting(meeting);
            meetingOrganizerDetailRepository.save(meetingOrganizerDetail);
            log.info("Meeting organizer details saved | bookingId={} | organizerEmail={} | organizerName={}",
                meeting.getId(),
                meetingOrganizerDetail.getOrganizerEmail(),
                meetingOrganizerDetail.getOrganizerName());

            log.info("Triggering actionable meeting message | bookingId={} | organizerEmail={}", meeting.getId(), eventDto.getOrganizerEmail());
            // actionableMessageService.sendMeetingActionMessage(
            //     meeting,
            //     eventDto.getOrganizerEmail(),
            //     eventDto.getOrganizerName()
            // );
            log.info("Actionable meeting message flow completed | bookingId={} | organizerEmail={}", meeting.getId(), eventDto.getOrganizerEmail());

            log.info("MeetingOrganizerDetail  saved | eventId={} | organizerEmail={} | organizerName={} | createdDateTime={} | createdFrom={}",
                    eventDto.getId(), eventDto.getOrganizerEmail(), eventDto.getOrganizerName(), 
                    meetingOrganizerDetail.getCreatedDateTime(), meetingOrganizerDetail.getCreatedFrom());
                    

            log.info("Returning newly created meeting | eventId={}", eventDto.getId());

            return meeting;
        }
    }

    /**
     * Validate the meeting in the case of a creation.
     *
     * @param meeting The metting to validate.
     * @throws IllegalArgumentException When data are not ok for a creation.
    */
       private void validateMeetingForCreation(EventDTO meeting) {
        if (Objects.isNull(meeting.getRoom()) ||
                Objects.isNull(meeting.getFrom()) ||
                Objects.isNull(meeting.getTo()) ||
                Objects.isNull(meeting.getFloorId())) {
            throw new IllegalArgumentException("The \"room\", \"from\", \"to\" and \"floorId\" are required.");
        }

        if (meeting.getFrom() == 0 || meeting.getTo() == 0) {
            throw new IllegalArgumentException("The \"from\" and \"to\" attributes couldn't be at 0.");
        }

        if (meeting.getFrom() > meeting.getTo()) {
            throw new IllegalArgumentException("The \"from\" attribute must be before \"to\" attribute.");
        }
    }

    /**
     *
     * @param value
     * @return
     */
    private String encodeValue(String value) {
        log.info("Calling encodeValue with: {}", value);
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            log.error("Encoding error: {}", e.getMessage());
            return value; // Fallback: return the original value
        }
    }

    /**
     *
     * @param dateTime
     * @param eventTimeZone
     * @param targetTimeZone
     * @return
     */
    private Long convertToUTC(String dateTime, String eventTimeZone, String targetTimeZone) {
        String ianaZone = TimeZoneConverter.WINDOWS_TO_IANA.getOrDefault(eventTimeZone, "UTC");
        MutableDateTime date = new MutableDateTime(dateTime, DateTimeZone.forID(ianaZone));
        date.setZone(DateTimeZone.forID(targetTimeZone));
        return this.getZonedEpochFromUTCEpoch(date.getMillis() / 1000, targetTimeZone);
    }

    /**
     * Convert given epoch to epoch in give zone
     *
     * @param timestampSeconds
     * @param zone
     * @return
     */
    private long getZonedEpochFromUTCEpoch(long timestampSeconds, String zone) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), ZoneId.of(zone)).atZone(UTC_ZONE_ID)
                .toEpochSecond();
    }


    public Meeting createMeetingFromEvent(EventDTO eventDto,String timeZone,Floor floor) {
        if (eventDto == null) {
                return null;
            }

            Meeting meeting = new Meeting();
            meeting.setId(encodeValue(eventDto.getId()));
            meeting.setFrom(convertToUTC(eventDto.getEventStartTime(), eventDto.getEventTimeZone(), timeZone));
            meeting.setTo(convertToUTC(eventDto.getEventEndTime(), eventDto.getEventTimeZone(), timeZone));
            meeting.setFromUtc(eventDto.getFrom());
            meeting.setToUtc(eventDto.getTo());
            meeting.setCheckStatus(EnumMeetingStatus.CREATED);
            meeting.setRoom(eventDto.getRoom());
            meeting.setFloor(floor);
            meeting.setFloorId(eventDto.getFloorId());
            meeting.setPoiName(eventDto.getPoiName());
            meeting.setCreated(System.currentTimeMillis());
            meeting.setModifiedAt(System.currentTimeMillis());
            return meeting;
        }

    public String getOrganizerEmail(String bookingId) {
        log.info("Resolving organizer email | bookingId={}", bookingId);
        MeetingOrganizerDetail organizerDetail = this.meetingOrganizerDetailRepository.findByMeetingId(bookingId)
            .orElseThrow(() -> new NoSuchElementException("Organizer details not found for bookingId: " + bookingId));

        if (Objects.isNull(organizerDetail.getOrganizerEmail()) || organizerDetail.getOrganizerEmail().isBlank()) {
            throw new NoSuchElementException("Organizer email not found for bookingId: " + bookingId);
        }

        log.info("Organizer email resolved | bookingId={} | organizerEmail={}", bookingId, organizerDetail.getOrganizerEmail());
        return organizerDetail.getOrganizerEmail();
    }

    public Meeting cancelMeeting(String bookingId) {
        log.info("Cancelling meeting | bookingId={}", bookingId);
        Meeting meeting = this.meetingRepository.findByCustomId(bookingId)
            .orElseThrow(() -> new NoSuchElementException("Meeting not found for bookingId: " + bookingId));

        if (meeting.getCheckStatus() != EnumMeetingStatus.CANCELLED) {
            meeting.setCheckStatus(EnumMeetingStatus.CANCELLED);
            meeting.setModifiedAt(System.currentTimeMillis());
            meeting = this.meetingRepository.save(meeting);
            log.info("Meeting cancelled | bookingId={} | modifiedAt={}", bookingId, meeting.getModifiedAt());
        } else {
            log.info("Meeting already cancelled | bookingId={}", bookingId);
        }

        return meeting;
    }

    public Meeting checkInMeeting(String bookingId) {
        log.info("Checking in meeting | bookingId={}", bookingId);
        Meeting meeting = this.meetingRepository.findByCustomId(bookingId)
            .orElseThrow(() -> new NoSuchElementException("Meeting not found for bookingId: " + bookingId));

        if (meeting.getCheckStatus() == EnumMeetingStatus.CANCELLED) {
            log.warn("Check-in rejected because meeting is cancelled | bookingId={}", bookingId);
            throw new IllegalStateException("Cancelled meetings cannot be checked in.");
        }

        if (meeting.getCheckStatus() != EnumMeetingStatus.CHECKED_IN) {
            meeting.setCheckStatus(EnumMeetingStatus.CHECKED_IN);
            meeting.setModifiedAt(System.currentTimeMillis());
            meeting = this.meetingRepository.save(meeting);
            log.info("Meeting checked in | bookingId={} | modifiedAt={}", bookingId, meeting.getModifiedAt());
        } else {
            log.info("Meeting already checked in | bookingId={}", bookingId);
        }

        return meeting;
    }

}
