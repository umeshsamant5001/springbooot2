package com.capgemini.smartoffice.pwa.back.model.exception;

public class VecosConnectorException extends RuntimeException {

	private static final Integer VECOS_CONNECTOR_UNEXPECTED_ERROR = 500;

	private static final long serialVersionUID = 7748650921857496286L;

	private final int httpStatus;

	private final int errorCode;

	public VecosConnectorException(String message) {
		super(message);
		this.httpStatus = 500;
		this.errorCode = VecosConnectorException.VECOS_CONNECTOR_UNEXPECTED_ERROR;
	}

	public VecosConnectorException(int httpStatus, int errorCode, String message) {
		super(message);
		this.httpStatus = httpStatus;
		this.errorCode = errorCode;
	}

	public int getHttpStatus() {
		return httpStatus;
	}

	public int getErrorCode() {
		return errorCode;
	}

}