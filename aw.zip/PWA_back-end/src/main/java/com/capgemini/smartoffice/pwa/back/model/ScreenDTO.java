package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class ScreenDTO implements WithTitleDTO {
    private Long id;
    private String titleFr;
    private String titleEn;
    private String title;
    private String descriptionFr;
    private String descriptionEn;
    private String image;
    private Integer pageNumber;
}
