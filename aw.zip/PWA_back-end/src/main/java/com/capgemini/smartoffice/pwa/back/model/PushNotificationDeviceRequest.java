package com.capgemini.smartoffice.pwa.back.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class PushNotificationDeviceRequest {

    @NotNull
    @Size(min = 1, max = 255)
    private String deviceId;

    @NotNull
    @Size(min = 1, max = 500)
    private String deviceRegistrationToken;

    @Size(max = 255)
    private String countryName;

    @Size(max = 320)
    private String emailId;

    @NotNull
    private EnumFcmDeviceType deviceType;
}
