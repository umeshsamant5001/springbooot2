package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.Device;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumDeviceType;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

        static final String BASE_QUERY_FIND_ALL = "SELECT device FROM Device device WHERE device.poiName IN ( " +
                        " SELECT poi.name FROM Poi poi INNER JOIN poi.spaceType spaceType " +
                        " INNER JOIN poi.floor floor INNER JOIN floor.building building ";
        @RestResource(exported = false)
        public Device findByUuid(@Param("uuid") String uuid);

        @Query(value = "SELECT device.* "
                + " FROM device "
                + " WHERE device.floor_id = :floorId "
                + " AND device.device_type = 'OFFICESENSE_PRESENCE' "
                + " AND device.status = 'ACTIVE' ", nativeQuery = true)
        public List<Device> findAllActiveOfficePresenceByFloor(@Param("floorId") long floorId);

        @Query(value = "SELECT device.* "
                + " FROM device "
                + " JOIN floor ON floor.id = device.floor_id "
                + " WHERE floor.building_id= :buildingId "
                + " AND device.device_type = 'OFFICESENSE_PRESENCE' "
                + " AND device.status = 'ACTIVE' ", nativeQuery = true)
        public List<Device> findAllActiveOfficePresenceBuilding(@Param("buildingId") long buildingId);

        public List<Device> findAllByPoiName(@Param("poiName") String poiName);

        public List<Device> findAllByPoiNameIn(@Param("poiNames") List<String> poiNames);

        @RestResource(exported = false)
        @Query("SELECT device FROM Device device WHERE device.poiName IN (SELECT poi.name FROM Poi poi INNER JOIN poi.spaceType spaceType INNER JOIN poi.floor floor "
                + " WHERE floor.id = :floorId)")
        List<Device> findAllViaPoiByFloorId(@Param("floorId") Long floorId);

        @RestResource(exported = false)
        @Query("SELECT device FROM Device device WHERE device.poiName IN ("
                + "SELECT poi.name "
                + "FROM Poi poi "
                + "INNER JOIN poi.spaceType spaceType "
                + "INNER JOIN poi.floor floor "
                + "INNER JOIN spaceType.poiGroup poiGroup "
                + "WHERE floor.id = :floorId AND poiGroup.name IN (:poiGroupList))")
        List<Device> findAllViaPoiByFloorIdAndPoiGroup(@Param("floorId") Long floorId,
                @Param("poiGroupList") List<String> poiGroupList);


        @RestResource(exported = false)
        @Query(value = "SELECT device.* FROM device device WHERE device.poi_name IN (SELECT p.name FROM poi p " +
                        "JOIN space_type st ON p.space_type_id = st.id " +
                        "JOIN poi_group pg ON st.poi_group_id = pg.id " +
                        "WHERE p.floor_id = :floorId AND pg.name IN (:poiGroupList) )" +
                        "AND device.device_type<>'TABLET'", nativeQuery = true)
        List<Device> findAllViaPoiByFloorIdAndPoiGroupExcludeTablet(@Param("floorId") Long floorId,
                @Param("poiGroupList") List<String> poiGroupList);

        @RestResource(exported = false)
        @Query("SELECT device FROM Device device WHERE device.poiName IN (SELECT poi.name FROM com.capgemini.smartoffice.pwa.back.model.Poi poi INNER JOIN poi.spaceType spaceType INNER JOIN poi.floor floor WHERE floor.id = :floorId AND spaceType.spaceTypeName IN (:poiGroupList)) AND device.deviceType !='TABLET'")
        List<Device> findAllViaPoiByFloorIdExcludeTablet(@Param("floorId") Long floorId);


        boolean existsByPoiNameAndDeviceType(String poiName, EnumDeviceType deviceType);

        @Query(BASE_QUERY_FIND_ALL
                        + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId) AND floor.id IN (:floorId))")
        List<Device> findAllViaPoiByTypeIdAndBuildingIdAndFloorId(
                        @Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId))")
        List<Device> findAllViaPoiByTypeIdAndBuildingId(
                        @Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND floor.id IN (:floorId))")
        List<Device> findAllViaPoiByBuildingIdAndFloorId(@Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId))")
        List<Device> findAllViaPoiByBuildingId(@Param("buildingId") List<Long> buildingId);


}
