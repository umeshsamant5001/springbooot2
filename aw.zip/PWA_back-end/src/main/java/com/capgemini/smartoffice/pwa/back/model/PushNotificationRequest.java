package com.capgemini.smartoffice.pwa.back.model;

import java.util.List;
import lombok.Data;

@Data
public class PushNotificationRequest {

    private Message message;

    @Data
    public static class Message {
        private Android android;
    }

    @Data
    public static class Notification {
        private String title;
        private String body;
    }

    @Data
    public static class Android {
        private Notification notification;
    }
}

