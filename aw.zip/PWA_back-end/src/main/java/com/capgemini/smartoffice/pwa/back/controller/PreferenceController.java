package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

import javax.validation.Valid;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.capgemini.smartoffice.pwa.back.model.PreferenceDTO;
import com.capgemini.smartoffice.pwa.back.model.Service;
import com.capgemini.smartoffice.pwa.back.model.ServiceDTO;
import com.capgemini.smartoffice.pwa.back.model.ServiceUser;
import com.capgemini.smartoffice.pwa.back.model.User;
import com.capgemini.smartoffice.pwa.back.model.UserFavoriteBuildingUpdateRequest;

import com.capgemini.smartoffice.pwa.back.security.jwt.model.UserInformation;
import com.capgemini.smartoffice.pwa.back.service.PreferenceService;

import com.capgemini.smartoffice.pwa.back.service.ServiceService;
import com.capgemini.smartoffice.pwa.back.service.ServiceUserService;
import com.capgemini.smartoffice.pwa.back.service.UserInformationService;
import com.capgemini.smartoffice.pwa.back.service.UserService;


@RestController
@RequestMapping(value = PreferenceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PreferenceController {

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setDisallowedFields("save");
    }

    static final String ROOT_API = "api/preference";

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    @Autowired
    private PreferenceService preferenceService;

    @Autowired
    private UserService userService;

    @Autowired
    private ServiceService serviceService;

    @Autowired
    private ServiceUserService serviceUserService;

    @Autowired
    private UserInformationService userInformationService;


    @GetMapping("/{userEmail}")
    public ResponseEntity<PreferenceDTO> getPreferencesByEmailId(
            @PathVariable("userEmail") String userEmail,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        PreferenceDTO preferenceDTO = preferenceService.getUserPreference(userEmail, language);

        if (Objects.nonNull(preferenceDTO)) {
            this.applyUsedTimes(preferenceDTO.getFavoriteServices(), userEmail);
        }

        return ResponseEntity.ok(preferenceDTO);
    }

    @PutMapping("/{emailId}/building")
    public ResponseEntity<PreferenceDTO> updateBuildingPreference(
            @PathVariable String emailId,
            @Valid @RequestBody UserFavoriteBuildingUpdateRequest visitedBuilding,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) throws Exception {


        UserInformation userInformation;
        try {
            userInformation = this.userInformationService.getCurrent();
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String authenticatedEmail = Objects.isNull(userInformation) || Objects.isNull(userInformation.getEmail())
                ? null
                : new String(String.valueOf(userInformation.getEmail()));

        if (!isValidEmail(emailId) || !isValidEmail(authenticatedEmail)) {
            return ResponseEntity.badRequest().build();
        }

        if (!authenticatedEmail.equalsIgnoreCase(emailId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }


        

        Long sanitizedBuildingId = Objects.isNull(visitedBuilding) || Objects.isNull(visitedBuilding.getBuildingId())
                ? null
                : Long.valueOf(String.valueOf(visitedBuilding.getBuildingId()));
        Long sanitizedFavoriteFloorId = Objects.isNull(visitedBuilding) || Objects.isNull(visitedBuilding.getFavoriteFloorId())
                ? null
                : Long.valueOf(String.valueOf(visitedBuilding.getFavoriteFloorId()));


        PreferenceDTO userPreference = preferenceService.updateBuildingPreference(
                sanitizedBuildingId,
                sanitizedFavoriteFloorId,
                authenticatedEmail,
                language);


        return ResponseEntity.status(HttpStatus.CREATED).body(userPreference);
    }

    @PutMapping("/{email}/service/{serviceId}")
    public ResponseEntity<Object> addFavoriteService(@PathVariable String email, @PathVariable Long serviceId) {
        boolean valid = this.preferenceService.addFavoriteService(email, serviceId);

        if (!valid) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{email}/service/{serviceId}")
    public ResponseEntity<Object> removeFavoriteService(@PathVariable String email, @PathVariable Long serviceId) {
        boolean valid = this.preferenceService.removeFavoriteService(email, serviceId);

        if (!valid) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{email}/service/{serviceId}/increment")
    public ResponseEntity<String> incrementService(
            @PathVariable String email,
            @PathVariable Long serviceId) {
        User user = userService.findByEmailNoDeletedCheck(email);

        if (Objects.isNull(user)) {
            return ResponseEntity.notFound().build();
        }

        Service service = this.serviceService.findById(serviceId);

        if (Objects.isNull(service)) {
            return ResponseEntity.notFound().build();
        }

        ServiceUser serviceUser = this.serviceUserService.findByIds(user.getId(), service.getId());

        Long count = 1L;
        if (Objects.isNull(serviceUser)) {
            // The object don't exists : creation
            serviceUser = new ServiceUser();
            serviceUser.setService(service);
            serviceUser.setUser(user);
            serviceUser.setCount(count);
        } else {
            count = serviceUser.getCount() + 1;
            // The object exists : update
            serviceUser.setCount(count);
        }

        this.serviceUserService.save(serviceUser);

        JSONObject result = new JSONObject();
        result.put("usedTimes", count);

        return ResponseEntity.ok(result.toString());
    }

    private boolean isValidEmail(String email) {
        return Objects.nonNull(email) && EMAIL_PATTERN.matcher(email).matches();
    }

    
    @GetMapping("/generate-token")
    public ResponseEntity<String> generateToken() {
        String result =  preferenceService.getToken();
        return ResponseEntity.ok(result);
    }


    private void applyUsedTimes(List<ServiceDTO> services, String userEmail) {
        if (Objects.nonNull(userEmail) && Objects.nonNull(services)) {
            User user = userService.findByEmailNoDeletedCheck(userEmail);
            if (Objects.isNull(user)) {
                return;
            }

            // Get all the count of use for each service, for the current user
            Map<Long, Long> mapCount = this.serviceUserService.getCountByUserId(user.getId());

            // Add the service never used into the previous map.
            services.stream()
                .forEach(service -> {
                    if (mapCount.containsKey(service.getId())) {
                        service.setUsedTimes(mapCount.get(service.getId()));
                    } else {
                        service.setUsedTimes(0L);
                    }
                });
        }
    }
}
