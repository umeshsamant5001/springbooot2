package com.capgemini.smartoffice.pwa.back.model;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Category;
import lombok.Data;

@Data
public class NewsDTO {
    private Long id;
    private String linkText; 
    private Category category;
    private String newsMessage;
    private Integer status;
    private String lastModifiedBy;
    private Long lastModifiedDate;
}
