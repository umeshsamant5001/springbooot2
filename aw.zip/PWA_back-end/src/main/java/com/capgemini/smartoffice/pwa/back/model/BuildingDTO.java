package com.capgemini.smartoffice.pwa.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class BuildingDTO implements WithTitleDTO{
    private Long id;
    private Long siteId;
    private SiteDTO site;
    private Boolean deployed;
    private Boolean secured;
    private Long defaultMapId;
    private Long imageId;
    private String timezoneWindows;
    private String timezoneJava;
    private Long modifiedAt;
    private List<FloorDTO> floors;
    private String titleFr;
    private String titleEn;
    private String title;
    private BuildingInformation information;
    private String mailingList;
    private Long cdmKeyId;
    private Map<String, String> attributes = new HashMap<String, String>();
    private Boolean underConstruction;
}
