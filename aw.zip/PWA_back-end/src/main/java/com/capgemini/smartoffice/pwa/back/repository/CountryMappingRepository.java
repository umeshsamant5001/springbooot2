package com.capgemini.smartoffice.pwa.back.repository;

import com.capgemini.smartoffice.pwa.back.model.CountryMapping;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryMappingRepository extends JpaRepository<CountryMapping, Long> {
    Optional<CountryMapping> findByGraphCountryNameIgnoreCaseAndIsActiveTrue(String graphCountryName);
}
