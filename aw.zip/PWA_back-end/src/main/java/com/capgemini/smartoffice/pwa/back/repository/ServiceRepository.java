package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.Service;

@Repository
public interface ServiceRepository extends JpaRepository<Service, Long> {

    @Query("SELECT DISTINCT service FROM Service service INNER JOIN service.locations locations INNER JOIN service.attributes attribute WHERE "
            + " ((locations.level = 'GLOBAL') "
            + " OR (locations.level = 'COUNTRY' AND locations.cdmKeyId = :countryCdmKeyId) "
            + " OR (locations.level = 'CITY' AND locations.cdmKeyId = :cityCdmKeyId) "
            + " OR (locations.level = 'SITE' AND locations.cdmKeyId = :siteCdmKeyId) "
            + " OR (locations.level = 'BUILDING' AND locations.cdmKeyId = :buildingCdmKeyId)) " 
            + " AND index(attribute) = 'status' AND attribute = 'Published'"
            + " AND NOT EXISTS " 
                + "( SELECT 1 FROM Service service2 INNER JOIN service2.attributes attributes2 " 
                + "  WHERE service2 = service AND index(attributes2) = 'is_mobile'"  
                + "  AND (attributes2 = 'true' OR attributes2 = 'TRUE' OR attributes2 = 'True') "  
                + ")"
        )
    List<Service> findByLevel(
            @Param("buildingCdmKeyId") Long buildingCdmKeyId,
            @Param("siteCdmKeyId") Long siteCdmKeyId,
            @Param("cityCdmKeyId") Long cityCdmKeyId,
            @Param("countryCdmKeyId") Long countryCdmKeyId);

    // Only for QRScan for Mobile service
    @Query(value = "SELECT DISTINCT s.* FROM service as s " + 
                " INNER JOIN service_location sl ON s.id = sl.service_id " +
                " INNER JOIN service_attribute sa ON s.id = sa.service_id " + 
                " WHERE (" + 
                        " (sl.level ='GLOBAL') " + 
                        " OR (sl.level = 'COUNTRY' AND sl.cdm_key_id = :countryCdmKeyId) " +
                        " OR (sl.level = 'CITY' AND sl.cdm_key_id = :cityCdmKeyId)  " +  
                        " OR (sl.level = 'SITE' AND sl.cdm_key_id = :siteCdmKeyId) " +  
                        " OR (sl.level = 'BUILDING' AND sl.cdm_key_id = :buildingCdmKeyId) " +  
                    " ) " + 
                " AND sa.att_key = 'status' AND sa.att_value = 'Published' ",nativeQuery = true)   
    List<Service> findByLevelForMobileQRScan(
            @Param("buildingCdmKeyId") Long buildingCdmKeyId,
            @Param("siteCdmKeyId") Long siteCdmKeyId,
            @Param("cityCdmKeyId") Long cityCdmKeyId,
            @Param("countryCdmKeyId") Long countryCdmKeyId);
}
