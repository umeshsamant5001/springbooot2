package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.City;
import com.capgemini.smartoffice.pwa.back.model.CityDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.Context;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Site;
import com.capgemini.smartoffice.pwa.back.model.SiteDTO;
import com.capgemini.smartoffice.pwa.back.model.Building;
import com.capgemini.smartoffice.pwa.back.model.BuildingDTO;

@Named("SiteMapper")
@Mapper(config = DtoMapperConfig.class)
public interface SiteMapper {

	SiteMapper INSTANCE = Mappers.getMapper(SiteMapper.class);

	Site siteDTOToSite(SiteDTO in);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" })
    })
	SiteDTO siteToSiteDTO(Site in, @Context String language);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(target = "buildings", ignore = true)
    })
    SiteDTO siteToSiteDTONoBuildings(Site in, @Context String language);

    @Named("cityToCityDTOWithoutChildren")
    default CityDTO _cityToCityDTOWithoutChildren(City city, @Context String language) {
        return Mappers.getMapper(CityMapper.class)._cityToCityDTOWithoutChildren(city, language);
    }

    @Named("buildingToBuildingDTOWithoutParent")
    default BuildingDTO _buildingToBuildingDTOWithoutParent(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutParent(building, language);
    }

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "city", ignore = true),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" })
    })
    SiteDTO _siteToSiteDTOWithoutParent(Site in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(target = "buildings", ignore = true)
    })
    SiteDTO _siteToSiteDTOWithoutChildren(Site in, @Context String language);
}
