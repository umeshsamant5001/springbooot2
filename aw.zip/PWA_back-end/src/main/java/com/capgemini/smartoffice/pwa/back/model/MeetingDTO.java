package com.capgemini.smartoffice.pwa.back.model;

import java.util.Date;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumMeetingStatus;

import lombok.Data;

@Data
public class MeetingDTO {
    private String id;

    private Long from;

    private Long to;

    private EnumMeetingStatus checkStatus;

    private String room;

    private Floor floor;

    private Long floorId;

    private String poiName;

    private Long created;

    private Long modifiedAt = (new Date()).getTime() / 1000;
}
