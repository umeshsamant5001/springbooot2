package com.capgemini.smartoffice.pwa.back.controller;

import java.util.List;
import java.util.stream.Collectors;
import com.capgemini.smartoffice.pwa.back.mapper.EmailInfoMapper;
import com.capgemini.smartoffice.pwa.back.model.EmailInfoDTO;
import com.capgemini.smartoffice.pwa.back.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.smartoffice.pwa.back.model.EmailInfo;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/emailinfo", produces = APPLICATION_JSON_VALUE)
public class EmailInfoController {

    @Autowired
    private EmailService emailService;

    @GetMapping
    public ResponseEntity<List<EmailInfoDTO>> getEmailInfoByBuildingAndFloorId(
            @RequestParam Long buildingId,
            @RequestParam Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
  
        List<EmailInfo> emailInfos = this.emailService.getEmailByBuildingAndFloor(buildingId, floorId);
        List<EmailInfoDTO> emailInfoDTOs = emailInfos
            .stream()
            .map(EmailInfoMapper.INSTANCE::emailInfoToEmailInfoDTO)
            .collect(Collectors.toList());

        return ResponseEntity.ok(emailInfoDTOs);
    }
}