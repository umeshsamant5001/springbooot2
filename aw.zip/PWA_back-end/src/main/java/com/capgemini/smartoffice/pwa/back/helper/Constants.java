package com.capgemini.smartoffice.pwa.back.helper;

public class Constants {
    public static final int IS_VISIBLE_ON_PWA = 1;
    public static final Integer USER = 1;
}
