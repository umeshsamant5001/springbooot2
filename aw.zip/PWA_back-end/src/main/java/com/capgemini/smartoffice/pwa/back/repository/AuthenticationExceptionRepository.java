package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.security.jwt.model.AuthenticationException;

@Repository
public interface AuthenticationExceptionRepository extends JpaRepository<AuthenticationException, Long> {

}
