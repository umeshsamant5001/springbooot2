package com.capgemini.smartoffice.pwa.back.model;

import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumUserAnalytics;

import lombok.Data;

@Data
public class UserAnalyticsDTO {
    private Long id;
    private String appUser;
    private String moduleName;
    private String activity;
    private Long activityDate;
    private String platform;
    private EnumUserAnalytics userAnalytics;
    private Long parentId;
    private String email;
    private String country;
}
