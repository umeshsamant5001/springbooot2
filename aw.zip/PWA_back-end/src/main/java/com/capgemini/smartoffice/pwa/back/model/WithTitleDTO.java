package com.capgemini.smartoffice.pwa.back.model;

public interface WithTitleDTO {
    void setTitle(String title);
}
