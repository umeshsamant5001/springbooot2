package com.capgemini.smartoffice.pwa.back.mapper;

import com.capgemini.smartoffice.pwa.back.model.FloorDTO;
import com.capgemini.smartoffice.pwa.back.model.Floor;
import com.capgemini.smartoffice.pwa.back.model.PoiGroupDTO;
import com.capgemini.smartoffice.pwa.back.model.PoiGroup;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.smartoffice.pwa.back.model.Poi;
import com.capgemini.smartoffice.pwa.back.model.PoiDTO;
import com.capgemini.smartoffice.pwa.back.model.EquipmentDTO;
import com.capgemini.smartoffice.pwa.back.model.Equipment;

@Mapper(config = DtoMapperConfig.class)
public interface PoiMapper {

    PoiMapper INSTANCE = Mappers.getMapper(PoiMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" }),
        //@Mapping(source = "poiGroup", target = "poiGroup", qualifiedByName = { "groupToGroupDTO" }),
        @Mapping(source = "equipments", target = "equipments", qualifiedByName = { "equipmentToEquipmentDTO" })
    })
    PoiDTO poiToPoiDTO(Poi in, @Context String language);

    Poi poiDTOToPoi(PoiDTO in);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" }),
        @Mapping(target="spaceType.attributeKeys", ignore=true),
        @Mapping(target="spaceType.attributes", ignore=true),
        @Mapping(source = "equipments", target = "equipments", qualifiedByName = { "equipmentToEquipmentDTO" })
    })
    PoiDTO poiToPoiDTONoJoin(Poi in, @Context String language);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }

    // @Named("groupToGroupDTO")
    // default PoiGroupDTO _groupToGroupDTO(PoiGroup floor, @Context String language) {
    //     return Mappers.getMapper(PoiGroupMapper.class).poiGroupToPoiGroupDTO(floor, language);
    // }

    @Named("equipmentToEquipmentDTO")
    default EquipmentDTO _equipmentToEquipmentDTO(Equipment equipment, @Context String language) {
        return Mappers.getMapper(EquipmentMapper.class).equipmentToEquipmentDTO(equipment, language);
    }

}

