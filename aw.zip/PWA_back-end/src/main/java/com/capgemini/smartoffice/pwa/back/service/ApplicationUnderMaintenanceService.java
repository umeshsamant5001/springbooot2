package com.capgemini.smartoffice.pwa.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.mapper.ApplicationUnderMaintenanceMapper;
import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenance;
import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenanceDTO;
import com.capgemini.smartoffice.pwa.back.model.Platform;
import com.capgemini.smartoffice.pwa.back.repository.ApplicationUnderMaintenanceRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ApplicationUnderMaintenanceService {
    @Autowired
    private ApplicationUnderMaintenanceRepository applicationUnderMaintenanceRepository;

    public List<ApplicationUnderMaintenanceDTO> getAllApplicationUnderMaintenance(Platform platform) {
        List<ApplicationUnderMaintenance> applications;

        if (platform == null || platform == Platform.ALL) {
            // Retrieve all active records when platform is ALL or null
            applications = applicationUnderMaintenanceRepository.findByIsActiveTrue();
        } else {
            // Retrieve records matching the platform and isActive = true
            applications = applicationUnderMaintenanceRepository.findByPlatformAndIsActiveTrue(platform);
        }


        return applications
            .stream()
            .map(ApplicationUnderMaintenanceMapper.INSTANCE::applicationUnderMaintenanceToApplicationUnderMaintenanceDTO)
            .collect(Collectors.toList());
    }

}
