package com.capgemini.smartoffice.pwa.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.FrontLabel;

@Repository
public interface FrontLabelRepository extends JpaRepository<FrontLabel, Long> {

}
