package com.capgemini.smartoffice.pwa.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.smartoffice.pwa.back.model.UserFeedback;
import com.capgemini.smartoffice.pwa.back.model.UserFeedbackDTO;

@Mapper
public interface UserFeedbackMapper {

    UserFeedbackMapper INSTANCE = Mappers.getMapper(UserFeedbackMapper.class);

    UserFeedbackDTO userFeedbackToUserFeedbackDTO(UserFeedback in);

    UserFeedback userFeedbackDTOToUserFeedback(UserFeedbackDTO in);
}
