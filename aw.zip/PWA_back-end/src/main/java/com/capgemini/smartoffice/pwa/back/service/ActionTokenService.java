package com.capgemini.smartoffice.pwa.back.service;

import com.capgemini.smartoffice.pwa.back.config.ApplicationProperties;
import com.capgemini.smartoffice.pwa.back.model.ActionTokenUsage;
import com.capgemini.smartoffice.pwa.back.repository.ActionTokenUsageRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tech.jhipster.config.JHipsterProperties;

@Service
@Slf4j
public class ActionTokenService {

    public static final String CHECK_IN_PURPOSE = "check-in";
    public static final String CANCEL_MEETING_PURPOSE = "cancel-meeting";

    private final ApplicationProperties applicationProperties;
    private final ActionTokenUsageRepository actionTokenUsageRepository;
    private final Key signingKey;
    private final JwtParser jwtParser;

    public ActionTokenService(
        ApplicationProperties applicationProperties,
        JHipsterProperties jHipsterProperties,
        ActionTokenUsageRepository actionTokenUsageRepository
    ) {
        this.applicationProperties = applicationProperties;
        this.actionTokenUsageRepository = actionTokenUsageRepository;
        this.signingKey = buildSigningKey(applicationProperties, jHipsterProperties);
        this.jwtParser = Jwts.parserBuilder().setSigningKey(signingKey).build();
    }

    public String generateActionToken(String bookingId, String email, String purpose) {
        validateRequired(bookingId, "bookingId");
        validateRequired(email, "email");
        validateRequired(purpose, "purpose");

        Instant expiration = Instant.now().plus(resolveTokenValidityDays(), ChronoUnit.DAYS);
        String token = Jwts.builder()
            .setId(UUID.randomUUID().toString())
            .claim("purpose", purpose)
            .claim("bookingId", bookingId)
            .claim("email", email)
            .setExpiration(Date.from(expiration))
            .signWith(signingKey, SignatureAlgorithm.HS256)
            .compact();

        log.info("Action token generated | bookingId={} | organizerEmail={} | purpose={} | expiresAt={}", bookingId, email, purpose, expiration);
        return token;
    }

    public void consumeActionToken(String token, String expectedBookingId, String expectedEmail, String expectedPurpose) {
        validateRequired(token, "actionToken");
        validateRequired(expectedBookingId, "bookingId");
        validateRequired(expectedEmail, "email");
        validateRequired(expectedPurpose, "purpose");

        log.info("Validating action token | bookingId={} | organizerEmail={} | purpose={}", expectedBookingId, expectedEmail, expectedPurpose);

        Claims claims = jwtParser.parseClaimsJws(token).getBody();
        validateClaim(claims.get("purpose", String.class), expectedPurpose, "token purpose");
        validateClaim(claims.get("bookingId", String.class), expectedBookingId, "bookingId");

        String actualEmail = claims.get("email", String.class);
        if (actualEmail == null || !actualEmail.equalsIgnoreCase(expectedEmail)) {
            log.warn("Action token organizer mismatch | bookingId={} | expectedEmail={} | actualEmail={}", expectedBookingId, expectedEmail, actualEmail);
            throw new IllegalArgumentException("Action token email does not match the meeting organizer.");
        }

        String tokenId = claims.getId();
        validateRequired(tokenId, "tokenId");
        if (actionTokenUsageRepository.existsById(tokenId)) {
            log.warn("Action token replay detected | bookingId={} | organizerEmail={} | purpose={} | tokenId={}", expectedBookingId, actualEmail, expectedPurpose, tokenId);
            throw new IllegalStateException("Action token has already been used.");
        }

        ActionTokenUsage usage = new ActionTokenUsage();
        usage.setTokenId(tokenId);
        usage.setActionName(expectedPurpose);
        usage.setBookingId(expectedBookingId);
        usage.setOrganizerEmail(actualEmail);
        usage.setUsedAt(System.currentTimeMillis());
        actionTokenUsageRepository.save(usage);

        log.info("Action token consumed for bookingId={} organizerEmail={} purpose={}", expectedBookingId, actualEmail, expectedPurpose);
    }

    private Key buildSigningKey(ApplicationProperties applicationProperties, JHipsterProperties jHipsterProperties) {
        String configuredSecret = applicationProperties.getActionableMessage().getTokenSecret();
        if (configuredSecret != null && !configuredSecret.isBlank()) {
            return Keys.hmacShaKeyFor(hash(configuredSecret.getBytes(StandardCharsets.UTF_8)));
        }

        String base64Secret = jHipsterProperties.getSecurity().getAuthentication().getJwt().getBase64Secret();
        if (base64Secret != null && !base64Secret.isBlank()) {
            return Keys.hmacShaKeyFor(Decoders.BASE64.decode(base64Secret));
        }

        String jwtSecret = jHipsterProperties.getSecurity().getAuthentication().getJwt().getSecret();
        if (jwtSecret != null && !jwtSecret.isBlank()) {
            return Keys.hmacShaKeyFor(hash(jwtSecret.getBytes(StandardCharsets.UTF_8)));
        }

        throw new IllegalStateException("No JWT secret is configured for actionable message token signing.");
    }

    private byte[] hash(byte[] source) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(source);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to initialize actionable message token signing key.", ex);
        }
    }

    private int resolveTokenValidityDays() {
        Integer configuredDays = applicationProperties.getActionableMessage().getTokenValidityDays();
        if (configuredDays == null || configuredDays <= 0) {
            return 7;
        }
        return configuredDays;
    }

    private void validateClaim(String actualValue, String expectedValue, String fieldName) {
        if (!Objects.equals(actualValue, expectedValue)) {
            log.warn("Action token claim mismatch | field={} | expectedValue={} | actualValue={}", fieldName, expectedValue, actualValue);
            throw new IllegalArgumentException("Action token " + fieldName + " is invalid.");
        }
    }

    private void validateRequired(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }
    }
}