package com.capgemini.smartoffice.pwa.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import javax.validation.Valid;
import java.util.Optional;
import java.util.regex.Pattern;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.WebDataBinder;

import com.capgemini.smartoffice.pwa.back.model.SafeUserFeedbackData;
import com.capgemini.smartoffice.pwa.back.model.UserFeedbackDTO;
import com.capgemini.smartoffice.pwa.back.model.UserFeedbackCreateRequest;
import com.capgemini.smartoffice.pwa.back.model.UserFeedbackUpdateRequest;
import com.capgemini.smartoffice.pwa.back.service.UserFeedbackService;
import com.capgemini.smartoffice.pwa.back.mapper.UserFeedbackMapper;
import com.capgemini.smartoffice.pwa.back.model.UserFeedback;

import com.capgemini.smartoffice.pwa.back.model.enumeration.Rating;
import com.capgemini.smartoffice.pwa.back.model.enumeration.RatingFrom;
import com.capgemini.smartoffice.pwa.back.security.SecurityUtils;




import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = UserFeedbackController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
public class UserFeedbackController {

    static final String ROOT_API = "api/userfeedback";
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");


    @Autowired
    private UserFeedbackService userFeedbackService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setDisallowedFields("save");
    }

    @PostMapping
    public ResponseEntity<UserFeedbackDTO> createUserFeedback(
            @RequestParam(
                    defaultValue = "WEB_PORTAL")
            RatingFrom ratingFrom,
            @Valid @RequestBody UserFeedbackCreateRequest userFeedbackRequest) {

        try {

            SafeUserFeedbackData safeUserFeedbackData = buildSafeCreateData(
                    userFeedbackRequest,
                    ratingFrom);

            UserFeedbackDTO response =
                    userFeedbackService.createUserFeedback(
                            safeUserFeedbackData);
                log.info("userfeedback: {}", response);


            return ResponseEntity

                    .status(HttpStatus.CREATED)
                    .body(response);

        } catch (IllegalArgumentException ex) {

            log.warn(
                    "Invalid user feedback request: {}",
                    ex.getMessage());

            return ResponseEntity.badRequest().build();

        } catch (RuntimeException ex) {

            log.error(
                    "Error creating user feedback",
                    ex);

            return ResponseEntity
                    .internalServerError()
                    .build();
        }
    }

    @GetMapping
    public ResponseEntity<UserFeedbackDTO> getUserFeedback(
            @RequestParam String emailId,
            @RequestParam(
                    defaultValue = "WEB_PORTAL")
            RatingFrom ratingFrom) {

        Optional<UserFeedbackDTO> feedback =
                userFeedbackService.getUserFeedback(
                        emailId,
                        ratingFrom);

        return ResponseEntity.ok(feedback.orElse(new UserFeedbackDTO()));
    }

    @PutMapping
    public ResponseEntity<UserFeedbackDTO> updateUserFeedback(
            @RequestParam String emailId,
            @RequestParam(
                    defaultValue = "WEB_PORTAL")
            RatingFrom ratingFrom,
            @Valid @RequestBody UserFeedbackUpdateRequest userFeedbackRequest) {

        try {

            String safeEmailId = emailId == null
                    ? null
                    : new String(String.valueOf(emailId)).trim();

            if (!isValidEmail(safeEmailId)) {
                return ResponseEntity.badRequest().build();
            }

            Optional<String> currentUserEmail = SecurityUtils.getCurrentUserLogin();
            if (!currentUserEmail.isPresent()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            String authenticatedEmail = new String(String.valueOf(currentUserEmail.get())).trim();
            if (!isValidEmail(authenticatedEmail)) {
                return ResponseEntity.badRequest().build();
            }

            if (!authenticatedEmail.equalsIgnoreCase(safeEmailId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
            log.info("Authenticated email: {}, Request email: {}", authenticatedEmail, safeEmailId);
            SafeUserFeedbackData safeUserFeedbackData = buildSafeUpdateData(
                    authenticatedEmail,
                    ratingFrom,
                    userFeedbackRequest);

            UserFeedback updatedFeedback =
                    userFeedbackService.updateUserFeedback(
                            safeUserFeedbackData);


            UserFeedbackDTO response =

                    UserFeedbackMapper.INSTANCE
                            .userFeedbackToUserFeedbackDTO(
                                    updatedFeedback);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) {

            log.warn(
                    "Invalid update request: {}",
                    ex.getMessage());

            return ResponseEntity.badRequest().build();

        } catch (RuntimeException ex) {

            log.error(
                    "Error updating user feedback",
                    ex);

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .build();
        }
    }

    private boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    private SafeUserFeedbackData buildSafeCreateData(UserFeedbackCreateRequest request, RatingFrom ratingFrom) {
        SafeUserFeedbackData safeData = new SafeUserFeedbackData();
        safeData.setEmailId(request.getEmailId() == null ? null : new String(String.valueOf(request.getEmailId())));
        safeData.setRating(request.getRating() == null ? null
                : Rating.valueOf(String.valueOf(request.getRating().name())));
        safeData.setRatingFrom(ratingFrom == null ? null : RatingFrom.valueOf(String.valueOf(ratingFrom.name())));
        safeData.setComment(request.getComment() == null ? null : new String(String.valueOf(request.getComment())));
        return safeData;
    }

    private SafeUserFeedbackData buildSafeUpdateData(String emailId, RatingFrom ratingFrom,
            UserFeedbackUpdateRequest request) {
        SafeUserFeedbackData safeData = new SafeUserFeedbackData();
        safeData.setEmailId(emailId == null ? null : new String(String.valueOf(emailId)));
        safeData.setRatingFrom(ratingFrom == null ? null : RatingFrom.valueOf(String.valueOf(ratingFrom.name())));
        safeData.setRating(request.getRating() == null ? null
                : Rating.valueOf(String.valueOf(request.getRating().name())));
        safeData.setComment(request.getComment() == null ? null : new String(String.valueOf(request.getComment())));
        return safeData;
    }
}