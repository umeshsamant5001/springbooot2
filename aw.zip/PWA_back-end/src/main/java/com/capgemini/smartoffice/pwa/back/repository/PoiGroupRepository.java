package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;
import com.capgemini.smartoffice.pwa.back.model.PoiGroup;

@Repository
public interface PoiGroupRepository extends JpaRepository<PoiGroup, Long> {

	@RestResource(exported = false)
	List<PoiGroup> findAllIdByNameIn(@Param("poiGroupsNames") @RequestParam("poiGroupsNames") List<String> poiGroupsNames);

	/**
	 * Return all the PoiGroup associated to a building.
	 * 
	 * @param buildingId The Id of the building.
	 * @return The list of all PoiGroup associated to the correspondaing building.
	 */
	@Query(value = "SELECT DISTINCT pg.id FROM poi AS p" + 
				"    INNER JOIN space_type AS st ON (p.space_type_id = st.id)" +
				"    INNER JOIN poi_group AS pg ON (pg.id = st.poi_group_id)" + 
				"    INNER JOIN floor AS f ON (p.floor_id = f.id) " + 
				"    WHERE f.building_id = :buildingId", nativeQuery = true)
	List<Long> findAllIdByBuildingId(@Param("buildingId") Long buildingId);

	PoiGroup findByName(@Param("name") String name);

	@Query(value = "SELECT * FROM poi_group WHERE is_visible_on_pwa = :isVisibleOnPwa", nativeQuery = true)
    List<PoiGroup> findAllVisibleOnPWA(@Param("isVisibleOnPwa") Boolean isVisibleOnPwa);
}
