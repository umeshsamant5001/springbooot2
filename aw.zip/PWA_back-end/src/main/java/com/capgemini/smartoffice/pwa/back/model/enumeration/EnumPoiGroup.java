package com.capgemini.smartoffice.pwa.back.model.enumeration;

public enum EnumPoiGroup {
    ROOM_CONFERENCE("room_conference"),
	ROOM_BUBBLE("room_bubble");

	private final String text;

	EnumPoiGroup(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}
