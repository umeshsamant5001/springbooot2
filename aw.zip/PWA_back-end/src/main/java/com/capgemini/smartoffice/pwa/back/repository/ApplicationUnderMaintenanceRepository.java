package com.capgemini.smartoffice.pwa.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.smartoffice.pwa.back.model.ApplicationUnderMaintenance;
import com.capgemini.smartoffice.pwa.back.model.Platform;

@Repository
public interface ApplicationUnderMaintenanceRepository extends JpaRepository<ApplicationUnderMaintenance, Long>{

    List<ApplicationUnderMaintenance> findByPlatformAndIsActiveTrue(Platform platform);

    List<ApplicationUnderMaintenance> findByIsActiveTrue();

}
