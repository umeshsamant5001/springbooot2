package com.capgemini.smartoffice.pwa.back.service;

import org.springframework.stereotype.Service;

import com.capgemini.smartoffice.pwa.back.model.AppRegistrationManagement;
import com.capgemini.smartoffice.pwa.back.model.SafePushNotificationDeviceData;
import com.capgemini.smartoffice.pwa.back.model.enumeration.EnumFcmDeviceType;

@Service
public class PushNotificationBindingService {

    public SafePushNotificationDeviceData buildSafeDeviceData(String deviceId,
            String deviceRegistrationToken,
            String countryName,
            String emailId,
            EnumFcmDeviceType deviceType) {

        String validatedDeviceId = safeRequiredString(deviceId, "DeviceId is required.");
        String validatedDeviceRegistrationToken = safeRequiredString(deviceRegistrationToken,
                "DeviceRegistrationToken is required.");
        String validatedCountryName = safeOptionalString(countryName);
        String validatedEmailId = safeOptionalString(emailId);

        EnumFcmDeviceType validatedDeviceType = deviceType == null
                ? null
                : EnumFcmDeviceType.valueOf(String.valueOf(deviceType.name()));

        SafePushNotificationDeviceData safeData = new SafePushNotificationDeviceData();
        safeData.setDeviceId(new String(validatedDeviceId));
        safeData.setDeviceRegistrationToken(new String(validatedDeviceRegistrationToken));
        safeData.setCountryName(validatedCountryName == null ? null : new String(validatedCountryName));
        safeData.setEmailId(validatedEmailId == null ? null : new String(validatedEmailId));
        safeData.setDeviceType(validatedDeviceType);

        return safeData;
    }

    public void applySafeValues(AppRegistrationManagement target,
            SafePushNotificationDeviceData safeData,
            boolean setCreatedDate,
            long nowEpochSecond) {

        if (target == null) {
            throw new IllegalArgumentException("Device registration target is required");
        }

        if (safeData == null) {
            throw new IllegalArgumentException("Device registration data is required");
        }

        target.setDeviceId(safeData.getDeviceId() == null ? null : new String(safeData.getDeviceId()));
        target.setDeviceRegistrationToken(safeData.getDeviceRegistrationToken() == null
                ? null
                : new String(safeData.getDeviceRegistrationToken()));
        target.setDeviceType(safeData.getDeviceType() == null
                ? null
                : EnumFcmDeviceType.valueOf(String.valueOf(safeData.getDeviceType().name())));
        target.setEmailId(safeData.getEmailId() == null ? null : new String(safeData.getEmailId()));
        target.setCountryId(safeData.getCountryId() == null ? null : Long.valueOf(safeData.getCountryId()));
        target.setCountryName(safeData.getCountryName() == null ? null : new String(safeData.getCountryName()));

        if (setCreatedDate) {
            target.setCreatedDateTime(Long.valueOf(nowEpochSecond));
        }
        target.setUpdatedDateTime(Long.valueOf(nowEpochSecond));
    }

    private String safeRequiredString(String value, String errorMessage) {
        String safeValue = safeOptionalString(value);
        if (safeValue == null || safeValue.isEmpty()) {
            throw new IllegalArgumentException(errorMessage);
        }
        return safeValue;
    }

    private String safeOptionalString(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = new String(String.valueOf(value)).trim();

        if (trimmed.isEmpty()) {
            return null;
        }

        return new String(trimmed);
    }
}
