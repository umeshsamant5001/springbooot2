package com.capgemini.smartoffice.pwa.back.model;

import lombok.Data;

@Data
public class LanguageDTO {
    private String locale;
    private String name;
}
