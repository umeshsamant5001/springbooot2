# Tablet Back-end: Optimization Coverage Note

Date: 2026-10-14
Scope: `Tablet_back-end` module only

## Summary Matrix

1. Transaction Scope Reduced: **Implemented**
2. Graph API Improvements: **Implemented**
3. Queue-Based Event Processing: **Implemented**
4. Stored Procedure Optimization: **Partially verifiable in this repo**
5. New Database Indexes (3 specific indexes): **Not found in this module**
6. Application Configuration Updates: **Implemented (primarily in SIT profile)**

---

## 1) Transaction Scope Reduced

### Evidence found
- `GraphHelper.saveRoomEventById(...)` explicitly states it is **not transactional on purpose** so Graph calls are outside DB transaction scope.
- `MeetingBookingService.getMeetingDTOs(...)` also documents it is **not transactional on purpose** for the Graph call.
- DB writes are routed through `MeetingPersistenceService` methods annotated with `@Transactional`, creating short transaction boundaries around stored procedure execution.

### Code references
- `src/main/java/com/capgemini/tablet/back/config/GraphHelper.java`
  - comment near lines 237-238
- `src/main/java/com/capgemini/tablet/back/service/MeetingBookingService.java`
  - comment near lines 63-64
- `src/main/java/com/capgemini/tablet/back/service/MeetingPersistenceService.java`
  - `@Transactional` methods near lines 20, 26, 31

---

## 2) Graph API Improvements

### Evidence found
- Hard timeout controls configured in `GraphHelper`:
  - connect timeout: 5s
  - read timeout: 15s
  - call timeout: 30s
- Dispatcher limits added (`maxRequests`, `maxRequestsPerHost`) to avoid unbounded queueing against one host.
- `MeetingBookingService` waits for calendar call with explicit timeout (`get(..., CALENDAR_VIEW_TIMEOUT_SECONDS)`), and handles timeout by logging and returning empty list.

### Code references
- `src/main/java/com/capgemini/tablet/back/config/GraphHelper.java`
  - constants near lines 81-87
  - dispatcher/timeouts near lines 131, 136-139
- `src/main/java/com/capgemini/tablet/back/service/MeetingBookingService.java`
  - bounded wait near line 80
  - timeout handling near lines 118-119

---

## 3) Queue-Based Event Processing

### Evidence found
- `/graphEvent` endpoint in `MeetingController` now enqueues work and returns 202/503.
- `GraphEventProcessor` introduces:
  - bounded in-memory queue (`LinkedBlockingQueue`)
  - de-dup for `(mail,eventId)` using `queuedEvents`
  - separate worker pools for save and planning refresh
  - coalescing of refresh requests per room to avoid repeated downstream processing
- `RoomContextResolver` adds short-lived cache (60s) to reduce repeated POI/device/tablet lookups.

### Code references
- `src/main/java/com/capgemini/tablet/back/controller/MeetingController.java`
  - `/graphEvent` mapping and enqueue response behavior near lines 215, 223-227
- `src/main/java/com/capgemini/tablet/back/service/bus/GraphEventProcessor.java`
  - queue and worker constants near lines 57-63
  - queue structure near line 78
  - de-dup structures near lines 80, 82
  - queue insert/reject behavior near lines 103, 109, 113
  - coalesced planning refresh near lines 196-204
- `src/main/java/com/capgemini/tablet/back/service/RoomContextResolver.java`
  - cache rationale near lines 32-35
  - TTL near line 49
  - cached read path near lines 70-72

---

## 4) Stored Procedure Optimization

### What is verifiable in this module
- Stored procedure integration exists and is actively used:
  - `InsertNewMeetingsFromJson`
  - `InsertSingleMeetingFromJson`
  - `UpdateMeetingStatusToCancelled`

### What is not verifiable here
- No SQL body/versioned migration for these procedures is present in `Tablet_back-end` resources.
- Therefore, the specific claim "two existing stored procedures refactored to avoid simultaneous updates/locking" cannot be validated from this module alone.

### Code references
- `src/main/java/com/capgemini/tablet/back/repository/MeetingRepository.java`
  - procedure declarations near lines 34, 42, 47
- `src/main/java/com/capgemini/tablet/back/service/MeetingPersistenceService.java`
  - transactional procedure invocation near lines 22, 28, 33

---

## 5) New Database Indexes (3 requested indexes)

Requested:
- Meeting table: `(poi_name, start_time)`
- POI attribute table: `(att_key, att_value)`
- Device table: `(poi_name)`

### Result in this module
- These three specific indexes were **not found** in Liquibase changelogs or entity index annotations.
- Found only unrelated/other indexes such as `IDX_MODIFIED_MEETING` on `meeting.modified_at`.

### Code references
- `src/main/java/com/capgemini/tablet/back/model/Meeting.java`
  - index present on `modified_at` near line 24
- `src/main/java/com/capgemini/tablet/back/model/Poi.java`
  - `poi_attributes` mapping exists near line 87 (no explicit `(att_key, att_value)` index declared)
- `src/main/java/com/capgemini/tablet/back/model/Device.java`
  - `poi_name` column exists near line 42 (no explicit index declared)
- `src/main/resources/config/liquibase/changelog/00000000000000_initial_schema.xml`
  - no index/procedure DDL for requested items

---

## 6) Application Configuration Updates

### Evidence found
- Connection-pool monitoring and fail-fast settings are added in `application-sit.yml`:
  - `maximum-pool-size: 20`
  - `connection-timeout: 5000`
  - `leak-detection-threshold: 30000`
  - Hikari pool logging enabled (`HikariPool`, `ProxyConnection`)
- `provider_disables_autocommit` is enabled to reduce unnecessary early connection acquisition under transaction boundaries.

### Code references
- `src/main/resources/config/application-sit.yml`
  - pool logging near lines 21-22
  - pool tuning near lines 48, 52, 55
  - `provider_disables_autocommit` near line 75
- `src/main/resources/config/application.yml`
  - base `hibernate.connection.provider_disables_autocommit` near line 128

---

## Final Note

This module clearly implements the asynchronous webhook pattern, Graph call bounding, and short DB transaction boundaries that reduce lock pressure and thread/connection starvation risk. For items 4 and 5, full confirmation requires DB-side migration/SP scripts that are not present inside `Tablet_back-end`.