# Tablet Back-end reference: MeetingController from `/graphEvent` onward

## Scope reviewed
- Controller starting at `MeetingController#getSubTimeslots` (`@GetMapping("/graphEvent")`) and all following endpoints.
- Direct and key downstream methods in service/bus/config layers.
- Related YAML configuration files used by these flows.

## Endpoint to method map

### 1) `GET /api/meeting/graphEvent`
- File: `src/main/java/com/capgemini/tablet/back/controller/MeetingController.java`
- Method: `getSubTimeslots(String mail, String eventId)`
- Behavior:
  - Validates `mail` and `eventId` are non-empty.
  - Enqueues event processing through `GraphEventProcessor.submit(mail, eventId)`.
  - Returns:
    - `400` if params missing,
    - `503` if local queue full,
    - `202` if accepted.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/GraphEventProcessor.java`
  - `submit(mail, eventId)`: bounded queue insert + de-duplication by `(mail,eventId)` key.
  - `saveLoop()`: worker loop consuming queue items.
  - `handle(task)`: resolves room context, saves event from Graph into DB, requests planning refresh.
  - `requestPlanningRefresh(room)`: coalesces refresh requests per room.
  - `refreshPlanning(mail)`: publishes one-day planning to tablets.
- File: `src/main/java/com/capgemini/tablet/back/service/RoomContextResolver.java`
  - `byRoomMail(mail)`: resolves and caches room context (POI, timezone, tablets) for 60 seconds.
- File: `src/main/java/com/capgemini/tablet/back/config/GraphHelper.java`
  - `saveRoomEventById(RoomContext room, String eventId)`: loads event from Graph, upserts into DB, marks cancelled on Graph 404/cancelled.
- File: `src/main/java/com/capgemini/tablet/back/service/bus/OrchestreService.java`
  - `publishPlanning(DeviceDTO, RoomContext, from, to)`: gets meetings and publishes planning payload to Service Bus tablet queue.

---

### 2) `GET /api/meeting/subscribe`
- Controller method: `subscribeToEventQueueTest()`
- Calls `OrchestreService.subscribeUniquesQueues()`.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/OrchestreService.java`
  - `subscribeUniquesQueues()`: subscribes events + kiosk queues.
  - `subscribeBusEvents()`: subscribes `event` queue.
  - `subscribeBusKiosk()`: subscribes kiosk queue.

---

### 3) `POST /api/meeting/send`
- Controller method: `sendPushNotificationTest(Map<String,String> request)`
- Behavior:
  - Expects `email`, `title`, `body`.
  - Gets user device registrations.
  - Sends push per device token and OS type.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/DeviceTokenService.java`
  - `getAppRegistrationsForUser(emailId)`: DB lookup of app registrations by email.
- File: `src/main/java/com/capgemini/tablet/back/service/PushNotificationService.java`
  - `sendPushNotification(token,title,body,osType)`: routes by OS.
  - Android: `sendAndroidPush(...)` via Firebase.
  - iOS: `sendIosApnsPush(...)` and APNs HTTP/2 call.

---

### 4) `POST /api/meeting/push-alert`
- Controller method: `pushAlertTest(String payload)`
- Calls `MeetingBusService.pushAlertReminder(payload)`.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/MeetingBusService.java`
  - `pushAlertReminder(payload)`:
    - Parses payload to `MeetingDTO`.
    - Loads POI and meeting.
    - Skips when check-in disabled or meeting not CREATED.
    - Ensures one-time send using `meeting.pushAlert` flag.
    - Builds reminder message and sends push to registered devices.

---

### 5) `POST /api/meeting/trigger-reminder`
- Controller method: `triggerReminderTest(String payload)`
- Calls `MeetingBusService.triggerReminder(payload)`.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/MeetingBusService.java`
  - `triggerReminder(payload)`:
    - Parses payload, loads POI + meeting.
    - Skips when check-in disabled.
    - Calls `GraphHelper.shouldSkipReminderForRoom(roomEmail,eventId)` to skip reminders for cancelled/not-found room event.
    - Sends check-in email (via `MeetingService.sendEmailBeforeMeeting`).
    - Sets `alertCheckIn=true` to prevent duplicates.
    - Sends push reminder to booker devices.
- File: `src/main/java/com/capgemini/tablet/back/config/GraphHelper.java`
  - `shouldSkipReminderForRoom(roomEmail, encodedEventId)`: returns true on cancelled or Graph 404.

---

### 6) `GET /api/meeting`
- Controller method: `getMeetingsTest(room, from, to, timeZone, poiName)`
- Calls `MeetingBookingService.getMeetingDTOs(...)`.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/MeetingBookingService.java`
  - `getMeetingDTOs(room,from,to,timeZone,poiName)`:
    - Resolves floor id from POI name.
    - Calls overloaded version with floor id.
  - `getMeetingDTOs(..., floorId)`:
    - Calls Graph `calendarView` (with timeout).
    - Maps events to `MeetingDTO`.
    - Inserts new meetings via stored procedure.
    - Returns Graph-origin meetings enriched with DB check status.
  - `createMeetingDTO(event,...)`: converts Graph event to DTO fields.

---

### 7) `POST /api/meeting/cancel`
- Controller method: `cancelMeetingTest(String payload)`
- Calls `MeetingBusService.cancel(payload)`.

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/MeetingBusService.java`
  - `cancel(payload)`:
    - Parses payload, loads meeting by id.
    - Calls `freeRoomForCancel(room, meetingDTO)`.
    - If Graph deletion succeeded and status is CREATED, sets DB status to CANCELLED.
  - `freeRoomForCancel(poiEmail,meetingDTO)`:
    - URL-decodes meeting id.
    - Calls `GraphHelper.deleteEventById(...)`.

---

### 8) Test email endpoints
- `POST /api/meeting/email-alert-template` -> `MeetingService.sendEmailBeforeMeetingTest()`
- `POST /api/meeting/email-template-no-show` -> `MeetingService.freeRoomForMeetingTest(true)`
- `POST /api/meeting/email-template-check-out` -> `MeetingService.freeRoomForMeetingTest(false)`
- `POST /api/meeting/email-template-check-in` -> `MeetingService.checkInRoomForMeetingTest()`

#### Downstream implementation
- File: `src/main/java/com/capgemini/tablet/back/service/MeetingService.java`
  - `sendEmailBeforeMeetingTest()`: builds test reminder email payload from hardcoded sample values.
  - `freeRoomForMeetingTest(isFromNoShow)`: builds test no-show/check-out email payload.
  - `checkInRoomForMeetingTest()`: builds test check-in email payload.
  - Also used by real reminder flow:
    - `sendEmailBeforeMeeting(meetingDTO, timeToCheckIn, poi)`
    - `getDurationCheckIn(poi)`
    - `freeRoomForMeeting(poiEmail,meetingDTO,isFromNoShow)`

---

## Service Bus callback relation
- File: `src/main/java/com/capgemini/tablet/back/service/bus/AzureServiceBusService.java`
- Method: `orchestratorResponse(...)`
- Role:
  - Receives queue messages.
  - Routes to `MeetingBusService` handlers (`checkin`, `checkout`, `noshow`, `triggerReminder`, `cancel`, `pushAlertReminder`) based on message subject prefix.

## Config files related to these flows
- `src/main/resources/config/application.yml`
- `src/main/resources/config/application-local.yml`
- `src/main/resources/config/application-develop.yml`
- `src/main/resources/config/application-sit.yml`
- `src/main/resources/config/application-uat.yml`
- `src/main/resources/config/application-production.yml`
- `src/main/resources/config/application-tls.yml`
- `src/main/resources/config/bootstrap.yml`
- `src/main/resources/config/bootstrap-prod.yml`

### Important config sections to know
- `application.azure.graphApi.*`: Graph credentials, scope, notification URL.
- `application.azure.graphApiSendEmail.*`: Graph app registration for sending emails.
- `application.meeting.checkInTrigger|checkIn|noShow|checkOut.*`: email subjects/templates/urls.
- `application.pushNotificationApns.*`: APNs identifiers and key material.
- `spring.datasource.hikari.*` (especially in `application-sit.yml`): pool behavior important for graphEvent load.

## Operational notes
- `/graphEvent` intentionally offloads heavy Graph/DB/Bus work to async workers via bounded queue.
- Queue behavior:
  - De-duplication on `(mail,eventId)` while item is waiting.
  - Returns `503` when queue full.
  - Coalesces planning refreshes per room in a small time window.
- `MeetingBookingService` and `GraphHelper` both avoid holding DB transactions around long Graph calls.
