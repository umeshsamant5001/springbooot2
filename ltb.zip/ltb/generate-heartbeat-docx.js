const fs = require("fs");
const path = require("path");
const { Document, Packer, Paragraph, TextRun } = require("docx");

const lines = [
  "HEARTBEAT End-to-End Flow (Tablet Back-end)",
  "Generated On: 2026-10-23",
  "",
  "1) Purpose",
  "This flow keeps Tablet devices marked as ACTIVE when heartbeat messages are received through Azure Service Bus.",
  "",
  "2) Entry Point and Routing",
  "- Service: AzureServiceBusService.orchestratorResponse(...)",
  "- Subject routing logic uses subject.split(\"/\")[0].",
  "- HEARTBEAT case expects subject format: heartbeat/<uuid>.",
  "- On HEARTBEAT, code executes heartbeat(subject.split(\"/\")[1]).",
  "",
  "3) HEARTBEAT Handler",
  "- Method: AzureServiceBusService.heartbeat(String uuid)",
  "- Behavior: delegates to deviceService.updateStatus(uuid, EnumDeviceStatus.ACTIVE).",
  "",
  "4) Service Layer (Business Update)",
  "- Method: DeviceService.updateStatus(String uuid, EnumDeviceStatus status)",
  "- Transactional method.",
  "- Computes now = current epoch seconds.",
  "- Calls repository update with (uuid, ACTIVE, now).",
  "",
  "5) Database Update (JPA Update Query)",
  "- Repository: DeviceRepository.updateStatus(...)",
  "- JPQL update:",
  "  UPDATE Device device",
  "  SET device.status = :status,",
  "      device.lastStatusChange = :now,",
  "      device.lastChange = :now",
  "  WHERE device.uuid = :uuid",
  "",
  "6) Table/Columns Affected",
  "- Entity: Device",
  "- Table: device",
  "- Columns updated by heartbeat:",
  "  - status -> ACTIVE",
  "  - last_status_change -> current epoch second",
  "  - last_change -> current epoch second",
  "- Row selection: uuid = <value from heartbeat subject>.",
  "",
  "7) Message Acknowledgment Behavior",
  "- If handling succeeds, message is completed (context.complete()).",
  "- If exception occurs, message is abandoned (context.abandon()) and can be retried.",
  "",
  "8) Queue Subscription Context",
  "- On app ready, TabletBackEndApp.onSpringStart() calls orchestreService.subscribeUniquesQueues().",
  "- OrchestreService subscribes queues: event and newKiosk.",
  "- AzureServiceBusService.subscribeByQueue(...) creates a processor in PEEK_LOCK mode.",
  "- HEARTBEAT is processed when a message with subject heartbeat/<uuid> arrives on subscribed queues.",
  "",
  "9) Data Integrity/Edge Notes",
  "- Subject parsing assumes '/' exists; malformed subject can throw index errors.",
  "- No explicit check that uuid exists before update query.",
  "- JPQL update may affect 0 rows if uuid is unknown.",
  "- ACTIVE/INACTIVE lifecycle: repository has updateTabletStatus(...) to set tablets INACTIVE by age, but no direct caller was found in current Tablet_back-end code scan.",
  "",
  "10) End-to-End Sequence (Short)",
  "1. Producer sends Service Bus message with subject heartbeat/<uuid>.",
  "2. Processor receives message in AzureServiceBusService.subscribeByQueue().",
  "3. orchestratorResponse routes to HEARTBEAT case.",
  "4. heartbeat(uuid) calls deviceService.updateStatus(uuid, ACTIVE).",
  "5. DeviceService computes now and triggers repository update.",
  "6. Device table row gets status and timestamps updated.",
  "7. Message is completed on success; abandoned on failure.",
  "",
  "11) Frequency Note",
  "- Heartbeat frequency is not hard-coded in this module and appears producer-driven.",
  "- Frequency/SLA can be added later in this same document."
];

const paragraphs = lines.map((line, i) =>
  new Paragraph({
    children: [
      new TextRun({
        text: line,
        bold: i === 0
      })
    ]
  })
);

const doc = new Document({
  sections: [
    {
      children: paragraphs
    }
  ]
});

const outputPath = path.resolve(__dirname, "HEARTBEAT_End_to_End_Flow.docx");

Packer.toBuffer(doc)
  .then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    console.log(`Created: ${outputPath}`);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
