package com.capgemini.tablet.back.cucumber.stepdefs;

import org.springframework.test.web.servlet.ResultActions;

public abstract class StepDefs {

    protected ResultActions actions;
}
