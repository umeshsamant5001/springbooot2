package com.capgemini.tablet.back.service.bus;

import java.time.Instant;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.RoomContext;
import com.capgemini.tablet.back.service.RoomContextResolver;

import lombok.extern.slf4j.Slf4j;

/**
 * Decouples the /graphEvent webhook from its processing.
 *
 * Before: the HTTP thread did 2 Graph calls, 4 Poi loads, 2 stored procedures and a
 * Service Bus admin call, synchronously, while holding a Hikari connection. Any Graph
 * slowdown turned into Tomcat thread + connection pool starvation for the whole app.
 *
 * Now:
 * <ul>
 * <li>{@link #submit} puts (mail, eventId) in a bounded in-memory queue and returns
 * immediately; duplicates already waiting in the queue are dropped.</li>
 * <li>{@value #SAVE_WORKERS} workers save the notified event in the meeting table
 * ({@link GraphHelper#saveRoomEventById}).</li>
 * <li>Planning refreshes are coalesced per room: the first request schedules a
 * refresh {@value #COALESCE_DELAY_MS} ms later, every other request for the same room
 * in that window is absorbed. A burst of 10 created/updated notifications on one room
 * ends up as 1 calendarView call and 1 publish instead of 10.</li>
 * </ul>
 *
 * The queue is per replica and lost on restart (accepted trade-off: the next change on
 * the room, or the periodic planning publish, resynchronizes).
 */
@Service
@Slf4j
public class GraphEventProcessor {

    /** Max notifications waiting to be processed before the webhook answers 503. */
    static final int QUEUE_CAPACITY = 10_000;
    /** Concurrent event saves per replica (each one = 1 Graph call + 1 short SQL transaction). */
    static final int SAVE_WORKERS = 4;
    /** Concurrent planning refreshes per replica (each one = 1 Graph calendarView + 1 proc + 1 publish). */
    static final int PLANNING_WORKERS = 3;
    /** Window during which planning refresh requests for the same room are merged. */
    static final long COALESCE_DELAY_MS = 2_000L;
    /** Log a warning when the queue depth crosses this threshold. */
    static final int QUEUE_WARN_THRESHOLD = 500;

    private static final long ONE_DAY_SECOND = 86400L;

    @Autowired
    private RoomContextResolver roomContextResolver;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private OrchestreService orchestreService;

    private final BlockingQueue<GraphEventTask> eventQueue = new LinkedBlockingQueue<>(QUEUE_CAPACITY);
    /** Keys (mail|eventId) currently waiting in {@link #eventQueue}, for de-duplication. */
    private final Set<String> queuedEvents = ConcurrentHashMap.newKeySet();
    /** Room keys with a planning refresh already scheduled and not yet started. */
    private final Set<String> pendingPlanning = ConcurrentHashMap.newKeySet();

    private final AtomicLong accepted = new AtomicLong();
    private final AtomicLong deduplicated = new AtomicLong();
    private final AtomicLong rejected = new AtomicLong();
    private final AtomicLong planningCoalesced = new AtomicLong();
    private final AtomicLong planningExecuted = new AtomicLong();

    private ExecutorService saveWorkers;
    private ExecutorService planningWorkers;
    private ScheduledExecutorService scheduler;

    /**
     * Enqueue a notification. Never blocks.
     *
     * @return true if the notification was accepted (queued or already queued), false
     *         if the queue is full
     */
    public boolean submit(String mail, String eventId) {
        String key = RoomContext.keyFor(mail) + "|" + eventId;

        if (!queuedEvents.add(key)) {
            deduplicated.incrementAndGet();
            log.debug("graphEvent already queued for mail {} eventId {}, skipped", mail, eventId);
            return true;
        }

        boolean queued = eventQueue.offer(new GraphEventTask(mail, eventId, key));
        if (!queued) {
            queuedEvents.remove(key);
            rejected.incrementAndGet();
            log.error("graphEvent queue full ({} items), notification for mail {} eventId {} rejected",
                    QUEUE_CAPACITY, mail, eventId);
            return false;
        }

        long total = accepted.incrementAndGet();
        int depth = eventQueue.size();
        if (depth >= QUEUE_WARN_THRESHOLD && depth % 100 == 0) {
            log.warn("graphEvent queue depth {} (accepted={} dedup={} rejected={} planning executed={} coalesced={})",
                    depth, total, deduplicated.get(), rejected.get(), planningExecuted.get(), planningCoalesced.get());
        }
        return true;
    }

    public int queueDepth() {
        return eventQueue.size();
    }

    @PostConstruct
    void start() {
        saveWorkers = Executors.newFixedThreadPool(SAVE_WORKERS, namedThreads("graph-event-save-"));
        planningWorkers = Executors.newFixedThreadPool(PLANNING_WORKERS, namedThreads("graph-planning-"));
        scheduler = Executors.newSingleThreadScheduledExecutor(namedThreads("graph-planning-scheduler-"));

        for (int i = 0; i < SAVE_WORKERS; i++) {
            saveWorkers.execute(this::saveLoop);
        }
        log.info("GraphEventProcessor started: queueCapacity={} saveWorkers={} planningWorkers={} coalesceDelayMs={}",
                QUEUE_CAPACITY, SAVE_WORKERS, PLANNING_WORKERS, COALESCE_DELAY_MS);
    }

    @PreDestroy
    void stop() {
        log.info("GraphEventProcessor stopping, {} notifications still queued will be dropped", eventQueue.size());
        scheduler.shutdownNow();
        saveWorkers.shutdownNow();
        planningWorkers.shutdownNow();
    }

    private void saveLoop() {
        while (!Thread.currentThread().isInterrupted()) {
            GraphEventTask task;
            try {
                task = eventQueue.take();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            // From here on a new notification for the same event is queued again, not dropped.
            queuedEvents.remove(task.key);
            handle(task);
        }
    }

    private void handle(GraphEventTask task) {
        long startedAt = System.currentTimeMillis();
        try {
            Optional<RoomContext> room = roomContextResolver.byRoomMail(task.mail);
            if (!room.isPresent()) {
                log.warn("graphEvent for unknown room mail {} (eventId {}), ignored", task.mail, task.eventId);
                return;
            }

            graphHelper.saveRoomEventById(room.get(), task.eventId);

            if (room.get().getTablets().isEmpty()) {
                log.info("No tablet attached to room {}, planning not published", task.mail);
                return;
            }
            requestPlanningRefresh(room.get());
        } catch (Exception e) {
            log.error("Error while processing graphEvent for mail {} eventId {}: {}", task.mail, task.eventId,
                    e.getMessage(), e);
        } finally {
            log.debug("graphEvent for mail {} eventId {} processed in {} ms", task.mail, task.eventId,
                    System.currentTimeMillis() - startedAt);
        }
    }

    /**
     * Ask for the planning of a room to be re-published to its tablets. Requests made
     * within {@link #COALESCE_DELAY_MS} of the first one are merged into a single refresh.
     */
    void requestPlanningRefresh(RoomContext room) {
        String key = room.key();
        if (!pendingPlanning.add(key)) {
            planningCoalesced.incrementAndGet();
            return;
        }
        scheduler.schedule(
                () -> planningWorkers.execute(() -> refreshPlanning(room.getMail())),
                COALESCE_DELAY_MS, TimeUnit.MILLISECONDS);
    }

    private void refreshPlanning(String mail) {
        // Released before the work starts: a notification arriving from now on schedules a
        // new refresh, which guarantees it will see a state at least as fresh as itself.
        pendingPlanning.remove(RoomContext.keyFor(mail));
        planningExecuted.incrementAndGet();

        try {
            Optional<RoomContext> room = roomContextResolver.byRoomMail(mail);
            if (!room.isPresent()) {
                return;
            }

            long timestampSecondsStart = Instant.now().getEpochSecond();
            long timestampSecondsEnd = timestampSecondsStart + ONE_DAY_SECOND;

            for (DeviceDTO tablet : room.get().getTablets()) {
                orchestreService.publishPlanning(tablet, room.get(), timestampSecondsStart, timestampSecondsEnd);
            }
        } catch (Exception e) {
            log.error("Error while refreshing planning for room {}: {}", mail, e.getMessage(), e);
        }
    }

    private static ThreadFactory namedThreads(String prefix) {
        AtomicInteger counter = new AtomicInteger();
        return runnable -> {
            Thread thread = new Thread(runnable, prefix + counter.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        };
    }

    private static final class GraphEventTask {
        private final String mail;
        private final String eventId;
        private final String key;

        private GraphEventTask(String mail, String eventId, String key) {
            this.mail = mail;
            this.eventId = eventId;
            this.key = key;
        }
    }
}
