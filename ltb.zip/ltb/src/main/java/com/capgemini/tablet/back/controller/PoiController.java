package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.mapper.PoiMapper;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.PoiDTO;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import com.hazelcast.internal.util.CollectionUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = PoiController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PoiController {

    static final String ROOT_API = "api/poi";

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private OrchestreService orchestreService;
  
    /**
     * Retrieves a POI (Point of Interest) by its name.
     *
     * @param language the preferred language for the response (default is "en")
     * @param name the name of the POI to retrieve
     * @return a ResponseEntity containing the POI data or 404 if not found
     */
    @GetMapping(value = "/name/{name}/")
    public ResponseEntity<PoiDTO> getPoiByNameTest(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable String name) {

        Poi poi = this.poiService.findByName(name);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, language);

        List<Device> deviceList = this.deviceService.findAllByPoiName(name);

        this.poiService.addSensorDataToPoi(Arrays.asList(poiDTO), deviceList);

        return ResponseEntity.ok(poiDTO);
    }
    
    /**
     * Publishes POI information to all associated tablet devices.
     *
     * @param language the preferred language for the response (default is "en")
     * @param poiID the ID of the POI to publish
     * @return a ResponseEntity indicating the result of the operation
     */
    @GetMapping("/publishPoiInformation/{poiID}")
    public ResponseEntity<Object> publishPoiInformationTest(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable Long poiID) {
            
            Poi poi = this.poiService.findById(poiID);

            if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
            }

            PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, language);
            
            List<Device> devices = this.deviceService.findAllByPoiName(poi.getName());

            this.poiService.addSensorDataToPoi(Arrays.asList(poiDTO), devices);

            if(CollectionUtil.isNotEmpty(devices)) {
               devices.stream().filter(device-> device.getDeviceType().equals(EnumDeviceType.TABLET))
                .map(device -> DeviceMapper.INSTANCE.deviceToDeviceDTO(device, language))
                .forEach(deviceDTO -> this.orchestreService.publishPoi(deviceDTO.getUuid(), poiDTO));
             }

            return ResponseEntity.accepted().build();
            }
}
