package com.capgemini.tablet.back.model.enumeration;

public enum EnumOsType {
    ANDROID,
    WEB,
    IOS
}