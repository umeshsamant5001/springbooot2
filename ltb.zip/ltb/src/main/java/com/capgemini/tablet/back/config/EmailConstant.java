package com.capgemini.tablet.back.config;

public class EmailConstant {
    public static final String TRASH_FULL = "Meeting Room is not clean";
    public static final String VIDEO_DEVICE_NOT_WORKING = "Video device is not working"; // need to confirm with functional team what should in String constant value to till below line
    public static final String CABLING_ISSUE = "Cabling issue";
    public static final String OTHER_ISSUE = "Other issue";
}
