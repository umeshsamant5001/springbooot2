package com.capgemini.tablet.back.repository;
 
import com.capgemini.tablet.back.model.AppRegistrationManagement;
import com.capgemini.tablet.back.model.enumeration.EnumOsType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import java.util.List;
 
@Repository
public interface DeviceTokenRepository extends JpaRepository<AppRegistrationManagement, Long> {
    List<AppRegistrationManagement> findByDeviceType(EnumOsType deviceType);
    List<AppRegistrationManagement> findByEmailId(String emailId);
}
