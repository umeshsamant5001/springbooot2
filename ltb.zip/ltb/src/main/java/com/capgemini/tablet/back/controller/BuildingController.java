package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.List;
import java.util.Objects;
import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.service.BuildingService;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import com.hazelcast.internal.util.CollectionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = BuildingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class BuildingController {

    static final String ROOT_API = "api/building";

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private DeviceService deviceService;
    
    @Autowired
    private OrchestreService orchestreService;
    
     /* 
     * API to publish the opening hours of a building to all associated devices.
     * 
     * @param buildingId the ID of the building whose opening hours are to be published
     * @param preferred language for the device DTOs (default is "en")
     * @return 202 Accepted if the operation is successful, 404 Not Found if the building does not exist
     */
    @GetMapping("/publishOpeningHour")
    public ResponseEntity<Object> publishOpeningHourTest(
            @RequestParam Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        Building building = this.buildingService.findById(buildingId);

        if (Objects.isNull(building)) {
            log.info("Building {} not found", buildingId);
            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }
        
        List<Device> devices = this.deviceService.findDevicesByBuildingId(building.getId());
        
        if(CollectionUtil.isNotEmpty(devices)) {
            devices.stream()
                .map(device -> DeviceMapper.INSTANCE.deviceToDeviceDTO(device, language))
                .forEach(deviceDTO -> this.orchestreService.publishBuilding(deviceDTO));
        }

        return ResponseEntity.accepted().build();
    }

}

