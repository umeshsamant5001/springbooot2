package com.capgemini.tablet.back.mapper;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.WithTitle;

/**
 * Interface to add the "toTitle" function to the Mapper
 */
@Mapper
public interface WithTitleMapper {

	WithTitleMapper INSTANCE = Mappers.getMapper(WithTitleMapper.class);

	static final String DEFAULT_LANGUAGE = "En";
	static final List<String> AUTHORIZED_LANGUAGE = List.of(DEFAULT_LANGUAGE, "Fr");
	
	/**
	 * General function to map the title of a Model.
	 * 
	 * @param <T>
	 * @param in The Model
	 * @param language The current language
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	@Named("toTitle")
	default <T extends WithTitle> String toTitle(T in, @Context String language) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		// The language can be in the form of two letters (ex: "en") or two letters dash
		// two letters (ex: "en-US")
		String shortLanguage = language.substring(0, 1).toUpperCase() + language.substring(1, 2).toLowerCase();

		if (!WithTitleMapper.AUTHORIZED_LANGUAGE.contains(shortLanguage)) {
			shortLanguage = WithTitleMapper.DEFAULT_LANGUAGE;
		}

		Method method = in.getClass()
				.getDeclaredMethod(
						"getTitle" + shortLanguage);
		method.setAccessible(true);

		return (String) method.invoke(in);
	}
}