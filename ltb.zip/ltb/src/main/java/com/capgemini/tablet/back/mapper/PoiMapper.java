package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.FloorDTO;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.PoiDTO;

@Mapper(config = DtoMapperConfig.class, uses = { PoiGroupMapper.class, EquipmentMapper.class })
public interface PoiMapper {
    
    PoiMapper INSTANCE = Mappers.getMapper(PoiMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" }),
        @Mapping(target = "sensorData", ignore = true),
    })
    PoiDTO poiToPoiDTO(Poi in, @Context String language);

    Poi poiDTOToPoi(PoiDTO in);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }
}