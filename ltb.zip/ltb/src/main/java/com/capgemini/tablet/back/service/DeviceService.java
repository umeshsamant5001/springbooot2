package com.capgemini.tablet.back.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.repository.DeviceRepository;
import com.capgemini.tablet.back.repository.PoiRepository;

@Service
public class DeviceService {

	@Autowired
	private DeviceRepository deviceRepository;

	@Autowired
	private ConfigService configService;

	@Autowired
	private PoiRepository poiRepository;

	public Device findByUuid(String uuid) {
		return this.deviceRepository.findByUuid(uuid);
	}

    public Device findTabletByUuid(String uuid) {
        return deviceRepository.findTabletByUuid(uuid);
    }

	public boolean getConfigStringValue(String key) {
		ConfigValue configValue = this.configService.findByKeyName(key);
		return Objects.nonNull(configValue) ? Boolean.parseBoolean(configValue.getValue()) : Boolean.FALSE;
	}

	public int getTabletNumber(String poiName, Long floorId){
		return (int) this.deviceRepository.findAllByPoiNameAndFloorId(poiName, floorId)
			.stream()
			.filter((device) -> device.getDeviceType().equals(EnumDeviceType.TABLET) && device.getStatus().equals(EnumDeviceStatus.ACTIVE))
			.count();
	}

	public List<Device> findAllByPoiName(String poiName) {
		return this.deviceRepository.findAllByPoiName(poiName);
  }
	public Device save(Device device) {
		return this.deviceRepository.save(device);
	}

	public List<Device> findAllByDeviceType(EnumDeviceType deviceType) {
		return this.deviceRepository.findAllByDeviceType(deviceType);
	}

	public List<DeviceDTO> getTabletAllByEmail(String email) {
		Poi poi = this.poiRepository.findByEmail(email);
		if (Objects.isNull(poi)) {
			return new ArrayList<>();
		}

		List<Device> devices = this.deviceRepository.findAllByPoiName(poi.getName());

		return listDeviceToDeviceDTOList().apply(devices);

	}

	/**
	 * Set the status of the device to "active" and update the lastStatusChange.
	 * @param uuid
	 */
	@Transactional
	public void updateStatus(String uuid, EnumDeviceStatus status) {
		Long now = (new Date()).getTime() / 1000;
		this.deviceRepository.updateStatus(uuid, status, now);
	}

	@Transactional
	public void updateTabletStatus(Long age) {
		Long now = (new Date()).getTime() / 1000;

		this.deviceRepository.updateTabletStatus(EnumDeviceType.TABLET, EnumDeviceStatus.INACTIVE, now - age * 60);
	}

	private Function<List<Device>, List<DeviceDTO>> listDeviceToDeviceDTOList() {
		return in -> in.stream()
			.map(d -> DeviceMapper.INSTANCE.deviceToDeviceDTO(d, "en"))
			.collect(Collectors.toList());
	}

    public List<Device> findDevicesByBuildingId(Long buildingId) {
        return this.deviceRepository.findAllByFloorBuildingId(buildingId);
    }

}
