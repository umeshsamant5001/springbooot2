package com.capgemini.tablet.back.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capgemini.tablet.back.config.GraphHelper;

import com.capgemini.tablet.back.model.AttendeeDTO;

import com.capgemini.tablet.back.model.MeetingDTO;
import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.model.enumeration.EnumQualification;
import com.capgemini.tablet.back.model.enumeration.EnumStatus;
import com.capgemini.tablet.back.repository.MeetingRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.Sensitivity;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MeetingBookingService {

    private final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();

    @Autowired
    private GraphHelper graphHelper;
    @Autowired 
    private MeetingPersistenceService meetingPersistenceService;
    @Autowired
    private PoiService poiService;

     /**
     * Legacy signature: looks up the floor id from the poi name.
     */
    public List<MeetingDTO> getMeetingDTOs(String room, Long from, Long to, String timeZone, String poiName) {
        Long floorId = poiService.getPoiFloorId(poiName);
        return getMeetingDTOs(room, from, to, timeZone, poiName, floorId);
    }

    /**
     * Retrieves the {@link MeetingDTO}s of a room for a time range from Microsoft Graph,
     * persists the new ones into the database and returns the Graph list with the check
     * status coming from the database.
     *
     * Not transactional on purpose: the Graph call must not be done while holding a
     * database connection. The stored procedure runs in its own short transaction
     * (see {@link MeetingRepository#insertNewMeetingsFromJson}).
     *
     * @param room     the room mailbox
     * @param from     the start timestamp (epoch seconds) of the time range
     * @param to       the end timestamp (epoch seconds) of the time range
     * @param timeZone the building timezone
     * @param poiName  the poi technical name
     * @param floorId  the floor id of the poi
     * @return the meetings in the range, or an empty list on failure
     */
    public List<MeetingDTO> getMeetingDTOs(String room, Long from, Long to, String timeZone, String poiName,
            Long floorId) {
        try {
            // Fetch events, bounded in time: a slow Graph must not pin this worker forever
            List<Event> events = graphHelper.getCalendarView(from, to, timeZone, room)
                    .get(GraphHelper.CALENDAR_VIEW_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            log.info("Fetched {} events in getMeetingDTOs for room {} between {} and {} in timezone {} for poiName {}",
                    events.size(), room, from, to, timeZone, poiName);

            if (log.isDebugEnabled()) {
                for (Event event2 : events) {
                    log.debug("Event fetched | eventId={} | subject={} | start={} | end={} | organizerEmail={} | organizerName={}",
                            event2.id, event2.subject, event2.start.dateTime, event2.end.dateTime,
                            event2.organizer != null && event2.organizer.emailAddress != null ? event2.organizer.emailAddress.address : "N/A",
                            event2.organizer != null && event2.organizer.emailAddress != null ? event2.organizer.emailAddress.name : "N/A");
                }
            }

            // Convert events to DTOs
            List<MeetingDTO> meetingDtoList = events.stream()
                    .map(event -> createMeetingDTO(event, timeZone, poiName, room, floorId))
                    .collect(Collectors.toList());

            // Serialize DTOs to JSON
            String jsonPayload = new ObjectMapper().writeValueAsString(meetingDtoList);
            log.debug("insertNewMeetingsFromJson payload: {}", jsonPayload);

            // Insert meetings and map to DTOs
            List<MeetingDTO> newMeetingDtoList = meetingPersistenceService.syncMeetings(jsonPayload, from, to, poiName);
            for (MeetingDTO originalDto : meetingDtoList) {
                for (MeetingDTO newDto : newMeetingDtoList) {
                    if (originalDto.getId().equals(newDto.getId())) {
                        originalDto.setCheckStatus(newDto.getCheckStatus()); // update meeting status according to db
                    }
                }
                log.debug("Meeting after sync | eventId={} | subject={} | from={} | to={} | status={} | checkStatus={} | poiName={} | room={} | floorId={}",
                        originalDto.getId(), originalDto.getSubject(), originalDto.getFrom(), originalDto.getTo(),
                        originalDto.getStatus(), originalDto.getCheckStatus(), originalDto.getPoiName(),
                        originalDto.getRoom(), originalDto.getFloorId());
            }
            return meetingDtoList; // only return meetings coming from graph

        } catch (TimeoutException ex) {
            log.error("Graph calendarView timed out after {}s for room {} ({} to {})",
                    GraphHelper.CALENDAR_VIEW_TIMEOUT_SECONDS, room, from, to);
            return Collections.emptyList();
        } catch (Exception ex) {
            log.error("Exception while processing meetings in getMeetingDTOs for room {}: {}", room, ex.getMessage(), ex);
            return Collections.emptyList();
        }
    }

    public MeetingDTO createMeetingDTO(Event event, String timeZone, String poiName, String room, Long floorId) {
        MeetingDTO meeting = new MeetingDTO();
        try{
          meeting.setId(encodeValue(event.id));
          meeting.setFrom(convertToUTC(event.start.dateTime, event.start.timeZone, timeZone));
          meeting.setTo(convertToUTC(event.end.dateTime, event.end.timeZone, timeZone));
          meeting.setFromUtc(GraphHelper.convertToUnixTimestamp(event.start));
          meeting.setToUtc(GraphHelper.convertToUnixTimestamp(event.end));
          meeting.setStatus(EnumStatus.BUSY);
          meeting.setCheckStatus(EnumMeetingStatus.CREATED);
          meeting.setPoiName(poiName);
          meeting.setBooker(createAttendeeDTO(event));
          meeting.setRoom(room);
          meeting.setFloorId(floorId);
          meeting.setNoshowCounter(0);
          meeting.setCreated(System.currentTimeMillis());
          meeting.setModifiedAt(System.currentTimeMillis());
          meeting.setSubject(event.subject);
          meeting.setAlertCheckIn(false);
          if (event.organizer != null && event.organizer.emailAddress != null) {
              meeting.setOrganizerEmail(event.organizer.emailAddress.address);
              meeting.setOrganizerName(event.organizer.emailAddress.name);
              meeting.setCreatedDateTime(System.currentTimeMillis());
              meeting.setCreatedFrom("Outlook");
              log.info("Meeting Organizer Details createMeetingDTO from MeetingBookingService  | eventId={} | organizerEmail={} | organizerName={} | createdDateTime={} | createdFrom={} ",
                     meeting.getId(), meeting.getOrganizerEmail(), meeting.getOrganizerName(), meeting.getCreatedDateTime(), meeting.getCreatedFrom());
          } else {
              meeting.setOrganizerEmail(null);
              meeting.setOrganizerName(null);
              meeting.setCreatedDateTime(null);
              meeting.setCreatedFrom(null);
          }
        }
        catch (Exception e) {
            log.error("Exception while creating meeting DTO for eventId={}", event.id, e);
        }
        return meeting;
    }


    /**
     *
     * @param value
     * @return
     */
    private String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            log.error("Encoding error: {}", e.getMessage());
            return value; // Fallback: return the original value
        }
    }

    /**
     *
     * @param dateTime
     * @param eventTimeZone
     * @param targetTimeZone
     * @return
     */
    private Long convertToUTC(String dateTime, String eventTimeZone, String targetTimeZone) {
        MutableDateTime date = new MutableDateTime(dateTime, DateTimeZone.forID(eventTimeZone));
        date.setZone(DateTimeZone.forID(targetTimeZone));
        return this.getZonedEpochFromUTCEpoch(date.getMillis() / 1000, targetTimeZone);
    }

    /**
     * Convert given epoch to epoch in give zone
     *
     * @param timestampSeconds
     * @param zone
     * @return
     */
    private long getZonedEpochFromUTCEpoch(long timestampSeconds, String zone) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), ZoneId.of(zone)).atZone(UTC_ZONE_ID)
                .toEpochSecond();
    }

    /**
     *
     * @param event
     * @return
     */
    private AttendeeDTO createAttendeeDTO(Event event) {
        AttendeeDTO attendee = new AttendeeDTO();
        attendee.setQualification(EnumQualification.ORGANIZER);

        if (event.sensitivity == Sensitivity.PRIVATE) {
            attendee.setEmail("PRIVATE");
            attendee.setFirstName("PRIVATE");
            attendee.setLastName("PRIVATE");
        } else {
            attendee.setEmail(event.organizer.emailAddress.address);
            String[] name = event.organizer.emailAddress.name.split(",");
            attendee.setFirstName(name[0]);
            if (name.length > 1) {
                attendee.setLastName(name[1]);
            }
        }

        return attendee;
    }
}