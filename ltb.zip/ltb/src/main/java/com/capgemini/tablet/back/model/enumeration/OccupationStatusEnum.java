package com.capgemini.tablet.back.model.enumeration;

/**
 * Enum used for attendance requirement
 */
public enum OccupationStatusEnum {
    FREE("free"),
    
    BUSY("busy");

    OccupationStatusEnum(String value) {
        this.value = value;
    }

    private String value;

    public static OccupationStatusEnum fromValue(String text) {
        for (OccupationStatusEnum b : OccupationStatusEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
