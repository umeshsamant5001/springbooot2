package com.capgemini.tablet.back.model;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@Entity
@Table(name = "device", uniqueConstraints = { @UniqueConstraint(columnNames = { "uuid" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Device {

	@Id
	@Column(name = "uuid")
	private String uuid;

	@ManyToOne
	@JoinColumn(name = "floor_id")
	@JsonIgnore
	private Floor floor;

	@Column(name = "poi_name")
	private String poiName;

	@Column(name = "last_change")
	private Long lastChange;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private EnumDeviceStatus status;

	@Column(name = "last_status_change")
	private Long lastStatusChange;

	@Enumerated(EnumType.STRING)
	@Column(name = "device_type", nullable = true)
	private EnumDeviceType deviceType;

	@CollectionTable(name = "device_attributes", joinColumns = @JoinColumn(name = "device_uuid", referencedColumnName = "uuid"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<>();

}
