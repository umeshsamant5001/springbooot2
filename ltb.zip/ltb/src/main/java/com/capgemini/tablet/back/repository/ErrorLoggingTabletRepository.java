package com.capgemini.tablet.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.tablet.back.model.ErrorLoggingTablet;

@Repository
public interface ErrorLoggingTabletRepository extends JpaRepository<ErrorLoggingTablet, Long> {

}
