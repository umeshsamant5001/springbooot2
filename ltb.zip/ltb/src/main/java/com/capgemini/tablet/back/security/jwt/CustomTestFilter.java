package com.capgemini.tablet.back.security.jwt;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

@Slf4j
@Component
public class CustomTestFilter implements Filter {

    public static final String SSL_HEADER = "SSL-CLIENT-CERT";

    @Autowired
    SSLChecker sslChecker;

    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        String path = request.getRequestURI();
        return path.contains("/api/device/certificate") || path.contains("/api/building/publishOpeningHour")  || path.contains("/api/poi/publishPoiInformation")
            || path.contains("/api/meeting/email-template-check-in") || path.contains("/api/meeting/email-alert-template")
            || path.contains("/api/meeting/email-template-check-out") || path.contains("/api/meeting/email-template-no-show");
    }

    private String resolveSSLHeader(HttpServletRequest request) {
        String sslHeader = request.getHeader(SSL_HEADER);
        if (StringUtils.hasText(sslHeader)) {
            return sslHeader;
        }
        return null;
    }

    private void setAuthenticatedPrincipal(String principal) {
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
            principal,
            null,
            AuthorityUtils.createAuthorityList("ROLE_USER")
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String sslHeader = resolveSSLHeader(req);
        if (shouldNotFilter(req)) {
            setAuthenticatedPrincipal("public-endpoint");
            chain.doFilter(request, response);
        } else {
            if (StringUtils.hasText(sslHeader) && sslChecker.validateSSLHeader(sslHeader)) {
                setAuthenticatedPrincipal("ssl-client");
                //String correlationId = req.getHeader("X-Correlation-Id");

                // if (correlationId == null || correlationId.isEmpty()) {
                //     correlationId = UUID.randomUUID().toString();
                // }
                // MDC.put("correlationId", correlationId);

                chain.doFilter(request, response);
            } else {
                res.sendError(401);
            }
        }
    }
}
