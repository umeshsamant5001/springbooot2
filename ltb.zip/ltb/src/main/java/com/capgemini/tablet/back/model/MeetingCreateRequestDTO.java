package com.capgemini.tablet.back.model;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class MeetingCreateRequestDTO {

    @NotNull
    private Long from;

    @NotNull
    private Long to;

    @Size(max = 255)
    private String subject;

    @Valid
    private MeetingCreateBookerRequestDTO booker;
}
