package com.capgemini.tablet.back.service.smtp;

import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.tablet.back.config.ApplicationProperties;

@Service
@Slf4j
public class SMTPService {

	@Autowired
    private ApplicationProperties applicationProperties;

    /**
     * Creates a MimeMessage for the SMTP session using parameters defined as local entries.
     *
     * @return MimeMessage for the SMTP session.
    */
	public MimeMessage createSessionMessage() {
        ApplicationProperties.SMTP smtp = applicationProperties.getSmtp();

        Properties properties = System.getProperties();
        properties.put(smtp.getHost(), smtp.getHostUrl());
        properties.put(smtp.getPort(), smtp.getPortNum());
        properties.put(smtp.getAuth(), smtp.getState());

        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
            @Override
			protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(smtp.getUsername(), smtp.getPassword());
            }
        });

        MimeMessage mimemessage = new MimeMessage(session);
        try {
            mimemessage.setFrom(new InternetAddress(smtp.getEmail()));
        } catch (AddressException e) {
            log.error("AddressException : " + e.getMessage());
        } catch (MessagingException e) {
            log.error("MessagingException : " + e.getMessage());
        }

        return mimemessage;
    }

}
