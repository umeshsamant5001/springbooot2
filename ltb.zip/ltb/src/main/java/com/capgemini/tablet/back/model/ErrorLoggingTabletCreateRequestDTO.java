package com.capgemini.tablet.back.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.capgemini.tablet.back.model.enumeration.EnumErrorLoggingType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class ErrorLoggingTabletCreateRequestDTO {

    @NotNull
    @Size(min = 1, max = 255)
    private String uuid;

    @NotNull
    @Size(min = 1, max = 10000)
    private String description;

    @NotNull
    private EnumErrorLoggingType errorLoggingType;

    @NotNull
    private Long date;
}
