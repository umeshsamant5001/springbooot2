package com.capgemini.tablet.back.model.enumeration;

public enum RetryStatus {
    PENDING,
    SUCCESS,
    CANCELLED,
    FAILED
}