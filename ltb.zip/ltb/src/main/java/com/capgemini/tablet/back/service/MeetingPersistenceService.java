package com.capgemini.tablet.back.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.tablet.back.mapper.MeetingMapper;
import com.capgemini.tablet.back.model.Meeting;
import com.capgemini.tablet.back.model.MeetingDTO;
import com.capgemini.tablet.back.repository.MeetingRepository;

@Service
public class MeetingPersistenceService {

    @Autowired 
    private MeetingRepository meetingRepository;

    @Transactional 
    public List<MeetingDTO> syncMeetings(String jsonPayload , Long from,Long to,String poiName) {
        List<Meeting> meetings = meetingRepository.insertNewMeetingsFromJson(jsonPayload, from, to, poiName);
        return MeetingMapper.INSTANCE.meetingToMeetingDTO(meetings);
    }

    @Transactional 
    public List<Meeting> saveMeeting(String jsonPayload) {
        return meetingRepository.insertSingleMeetingFromJson(jsonPayload);
    }

    @Transactional 
    public void markCancelled(String encodedMeetingId) {
        meetingRepository.updateMeetingStatusToCancelled(encodedMeetingId);
    }
}
