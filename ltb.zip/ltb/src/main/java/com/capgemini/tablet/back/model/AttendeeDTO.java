package com.capgemini.tablet.back.model;

import com.capgemini.tablet.back.model.enumeration.EnumQualification;
import lombok.Data;

@Data
public class AttendeeDTO {
    private String firstName;
    private String lastName;
    private String email;
    private EnumQualification qualification;
}
