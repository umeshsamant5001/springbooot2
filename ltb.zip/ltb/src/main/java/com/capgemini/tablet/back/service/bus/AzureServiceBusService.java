package com.capgemini.tablet.back.service.bus;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusErrorContext;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusProcessorClient;
import com.azure.messaging.servicebus.ServiceBusReceivedMessage;
import com.azure.messaging.servicebus.ServiceBusReceivedMessageContext;
import com.azure.messaging.servicebus.ServiceBusSenderAsyncClient;
import com.azure.messaging.servicebus.administration.ServiceBusAdministrationClient;
import com.azure.messaging.servicebus.administration.ServiceBusAdministrationClientBuilder;
import com.azure.messaging.servicebus.administration.models.CreateQueueOptions;
import com.azure.messaging.servicebus.administration.models.CreateSubscriptionOptions;
import com.azure.messaging.servicebus.administration.models.CreateTopicOptions;
import com.azure.messaging.servicebus.models.ServiceBusReceiveMode;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.model.KioskMode;
import com.capgemini.tablet.back.model.enumeration.ConfigValueEnum;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.exception.ServiceBusCredentialException;
import com.capgemini.tablet.back.service.AzureKeyVaultService;
import com.capgemini.tablet.back.service.ConfigService;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.KioskService;
import com.capgemini.tablet.back.service.TransactionLoggingService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

@Service
@Slf4j
public class AzureServiceBusService {

    public static final String CHECK_OUT = "checkout";
    public static final String CHECK_IN = "checkin";
    public static final String TRIGGER = "trigger";
    public static final String NO_SHOW = "noshow";
    public static final String KEY_VAULT_KIOSK = "kiosk";
    public static final String HEARTBEAT = "heartbeat";
    public static final String TOPIC_KIOSK = "kiosk";
    public static final String CANCEL= "cancel";
    public static final String PUSHREMINDER = "pushreminder";
    public static final int MAX_SIZE_MEGABYTES = 1024;
    public static final int MAX_DELIVERY_COUNT = 10;
    public static final int TIME_TO_LEAVE = 1;
    public static final int LOCK_DURATION = 10;
    public static final boolean DEAD_LETTER_EXPIRATION = true;
    public static final boolean PARTITIONING = false;
    ServiceBusAdministrationClient serviceBusAdministrationClient;
    public Map<String, ServiceBusSenderAsyncClient> queueSenderMap = new ConcurrentHashMap<>();
    public Map<String, ServiceBusSenderAsyncClient> topicSenderMap = new HashMap<>();
    /**
     * Queues known to exist. Checking existence is a synchronous REST call to the
     * Service Bus management API; it used to be done on every single publish.
     */
    private final Set<String> knownQueues = ConcurrentHashMap.newKeySet();
    @Autowired
    private MeetingBusService meetingBusService;

    @Autowired
    private AzureKeyVaultService azureKeyVaultService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private KioskService kioskService;

    @Autowired
    private TransactionLoggingService transactionLoggingService;

   /***
     * Publish message to specific queue
     *
     * @param queueName
     * @param subject
     * @param messageSend
     * @throws ServiceBusCredentialException
     */
    public void publish(String queueName, String subject, String messageSend)
            throws ServiceBusCredentialException {

        // Verify Device type is of TABLET only then proceed it for queue creation and
        // publish of the message
        Boolean shouldProcessQueue = shouldProcessDeviceQueue(queueName);
        if (!shouldProcessQueue) {
            return;
        }
        //String correlationId = MDC.get("correlationId");
        log.info("Publish " + queueName + " Subject : " + subject );
        createQueueIfNeed(queueName);
        ServiceBusSenderAsyncClient sender = queueSenderMap.get(queueName);
        if (Objects.isNull(sender)) {
            String connectionString = getAzureServiceBusCred();
            sender = queueSenderMap.computeIfAbsent(queueName, name -> new ServiceBusClientBuilder()
                    .connectionString(connectionString).sender().queueName(name).buildAsyncClient());
        }
        //ServiceBusMessage message = new ServiceBusMessage(messageSend);
        //message.setCorrelationId(correlationId);
        List<ServiceBusMessage> messages = Arrays.asList(new ServiceBusMessage(messageSend).setSubject(subject));
        sender.sendMessages(messages).subscribe(
                messageId -> {
                    log.info("Message sent successfully. MessageId: " + messageId);
                },
                error -> {
                    log.info("Error occurred while sending the message on queue: " + queueName + ";error : "
                            + error);
                },
                () -> {
                    log.info("Messages sending complete from queue: " + queueName);
                });
    }

    /***
     * Subscribe queue
     *
     * @param queueName
     */
    public void subscribeByQueue(String queueName) throws ServiceBusCredentialException {

        // Verify Device type is of TABLET only then proceed it for queue creation
        Boolean shouldProcessQueue = shouldProcessDeviceQueue(queueName);
        if (!shouldProcessQueue) {
            return;
        }

        Consumer<ServiceBusReceivedMessageContext> processMessage = context -> {
            final ServiceBusReceivedMessage message = context.getMessage();
            orchestratorResponse(context, message);
        };

        Consumer<ServiceBusErrorContext> processError = errorContext -> {
            log.error("Error occurred while receiving message: " + errorContext.getException());
        };

        ServiceBusProcessorClient processorClient = new ServiceBusClientBuilder()
                .connectionString(getAzureServiceBusCred()).processor().queueName(queueName)
                .receiveMode(ServiceBusReceiveMode.PEEK_LOCK).disableAutoComplete().processMessage(processMessage)
                .processError(processError).disableAutoComplete().buildProcessorClient();

        processorClient.start();
    }

    /***
     * Publish message to specific topic
     *
     * @param topicName
     * @param subject
     * @param messageSend
     */
    public void publishTopic(String topicName, String subject, String messageSend)
            throws ServiceBusCredentialException {
        createTopicIfNeed(topicName);
        log.info("Publish Topic " + topicName + " Subject : " + subject);
        if (Objects.isNull(topicSenderMap.get(topicName))) {
            ServiceBusSenderAsyncClient busSenderClient = new ServiceBusClientBuilder()
                    .connectionString(getAzureServiceBusCred()).sender().topicName(topicName).buildAsyncClient();
            queueSenderMap.put(topicName, busSenderClient);
        }

        List<ServiceBusMessage> messages = Arrays.asList(new ServiceBusMessage(messageSend).setSubject(subject));
        topicSenderMap.get(topicName).sendMessages(messages).subscribe(
                messageId -> {
                    log.info("Message sent successfully to topic. MessageId: " + messageId);
                },
                error -> {
                    log.info("Error occurred while sending the message on topic: " + topicName + "; error:" + error);
                },
                () -> {
                    log.info("Messages sending complete.");
                });
    }

    private ServiceBusAdministrationClient getAdminServiceClient() throws ServiceBusCredentialException {
        if (Objects.isNull(serviceBusAdministrationClient)) {
            serviceBusAdministrationClient = new ServiceBusAdministrationClientBuilder()

                    .connectionString(getAzureServiceBusCred()).buildClient();
        }
        return serviceBusAdministrationClient;
    }

    /***
     * Create a topic if it is needed
     *
     * @param topicName
     */
    private void createTopicIfNeed(String topicName) throws ServiceBusCredentialException {
        ServiceBusAdministrationClient sbAdminClient = getAdminServiceClient();
        if (!sbAdminClient.getTopicExists(topicName)) {
            log.info("Create topic " + topicName);
            CreateTopicOptions topicOptions = new CreateTopicOptions().setMaxSizeInMegabytes(MAX_SIZE_MEGABYTES)
                    .setDefaultMessageTimeToLive(Duration.ofDays(TIME_TO_LEAVE))
                    .setLockDuration(Duration.ofSeconds(LOCK_DURATION)).setPartitioningEnabled(PARTITIONING);
            sbAdminClient.createTopic(topicName, topicOptions);
        }
    }

    /***
     * Function to push in the right direction subscribed topic
     *
     * @param context
     * @param message
     */
    public void orchestratorResponse(ServiceBusReceivedMessageContext context, ServiceBusReceivedMessage message) {
        try {
            String body = message.getBody().toString();
            String subject = message.getSubject();

            log.trace("Subject : " + subject + " > payload : " + body);

            // test if the message comes from the keyvault
            if (Objects.isNull(subject) && comesFromKeyVault(body)) {
                updateKiosk();
                serviceBusSuccess(context, message);

            }

            switch (subject.split("/")[0]) {
                case CHECK_IN:
                    meetingBusService.checkin(body);
                    serviceBusSuccess(context, message);
                    break;
                case CHECK_OUT:
                    meetingBusService.checkout(body);
                    serviceBusSuccess(context, message);
                    break;
                case NO_SHOW:
                    meetingBusService.noshow(body);
                    serviceBusSuccess(context, message);
                    break;
                case TRIGGER:
                    meetingBusService.triggerReminder(body);
                    serviceBusSuccess(context, message);
                    break;
                case KEY_VAULT_KIOSK:
                    updateKiosk();
                    serviceBusSuccess(context, message);
                    break;
                case HEARTBEAT:
                    heartbeat(subject.split("/")[1]);
                    serviceBusSuccess(context, message);
                    break;
                case CANCEL:
                    meetingBusService.cancel(body);
                    serviceBusSuccess(context, message);
                    break;
                case PUSHREMINDER:
                    meetingBusService.pushAlertReminder(body);
                    serviceBusSuccess(context, message);
                    break;
                default:
                    transactionLoggingService.saveTransactionLogging(body);
                    serviceBusEchec(context, message);
                    break;
            }
        } catch (Exception e) {
            serviceBusEchec(context, message);
            log.error(e.getMessage());
        }
    }

    /***
     * Validate worker processing of a message
     *
     * @param context
     * @param message
     */
    private void serviceBusSuccess(ServiceBusReceivedMessageContext context, ServiceBusReceivedMessage message) {
        try {
            context.complete();
        } catch (Exception completionError) {
            log.info("Completion of the message %s failed\n", message.getMessageId());
            completionError.printStackTrace();
        }
    }

    /***
     * Invalidate worker processing of a message
     *
     * @param context
     * @param message
     */
    private void serviceBusEchec(ServiceBusReceivedMessageContext context, ServiceBusReceivedMessage message) {

        try {
            context.abandon();
        } catch (Exception abandonError) {
            log.info("Abandoning of the message %s failed\n", message.getSubject());
            abandonError.printStackTrace();
        }
    }

    /***
     * Get AzureServiceBus client secret
     *
     * @return
     * @throws Exception
     */
    private String getAzureServiceBusCred() throws ServiceBusCredentialException {
        String keyAzure = getConfigStringValue(ConfigValueEnum.KEY_AZURE_SERVICE_BUS);
        if (Objects.isNull(keyAzure) || keyAzure.length() == 0) {
            log.error("No value for {} in configuration table", ConfigValueEnum.KEY_AZURE_SERVICE_BUS);
            throw new ServiceBusCredentialException("No value in configuration table");
        }

        KeyVaultSecret secret = azureKeyVaultService.getSecret(keyAzure);
        if (Objects.isNull(secret)) {
            log.error("No secret present for {}", keyAzure);
            throw new ServiceBusCredentialException("No secret present");
        }
        return secret.getValue();
    }

    /***
     * UpdateKiosk
     *
     * @return
     */
    public void updateKiosk() {
        try {
            KioskMode kMode = kioskService.getKiosk();
            ObjectMapper mapper = new ObjectMapper();
            String payload = mapper.writeValueAsString(kMode);
            logTopicMessage(TOPIC_KIOSK, TOPIC_KIOSK, payload);
            publishTopic(TOPIC_KIOSK, TOPIC_KIOSK, payload);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * Update the status of a tablet
     *
     * @param uuid The uuid of the tablet
     */
    private void heartbeat(String uuid) {
        deviceService.updateStatus(uuid, EnumDeviceStatus.ACTIVE);
    }

    /***
     * Log Topic payload
     *
     * @param topic
     * @param subject
     * @param payload
     */
    private void logTopicMessage(String topic, String subject, String payload) {
        log.info("topic : {} subject : {} payload : {}", topic, subject, payload);
    }

    private String getConfigStringValue(String key) {
        ConfigValue cValue = configService.findByKeyName(key);
        return Objects.nonNull(cValue) ? cValue.getValue() : "";
    }

    /***
     * Create subscription on kiosk Topic
     *
     * @param subscriptionName
     */
    public void createSubscriptionOnKioskTopic(String subscriptionName) throws ServiceBusCredentialException {
        createSubscriptionOnTopicIfNeed(TOPIC_KIOSK, subscriptionName);
    }

    /***
     * Create a subscription if it is needed
     *
     * @param topicName
     * @param subscriptionName
     */
    private void createSubscriptionOnTopicIfNeed(String topicName, String subscriptionName)
            throws ServiceBusCredentialException {
        createTopicIfNeed(topicName);
        ServiceBusAdministrationClient sbAdminClient = getAdminServiceClient();
        if (!sbAdminClient.getSubscriptionExists(topicName, subscriptionName)) {
            log.info("Create subscription %s  on topic %s", subscriptionName, topicName);
            CreateSubscriptionOptions subscriptionOptions = new CreateSubscriptionOptions()
                    .setDefaultMessageTimeToLive(Duration.ofDays(TIME_TO_LEAVE))
                    .setLockDuration(Duration.ofSeconds(LOCK_DURATION));
            sbAdminClient.createSubscription(topicName, subscriptionName, subscriptionOptions);
        }
    }

    /**
     * Checks if the payload comes from Key Vault.
     *
     * @param payload The payload to check.
     * @return true if the payload comes from Key Vault, otherwise false.
     */
    private Boolean comesFromKeyVault(String payload) {
        // Convert the JSON string to a JSONObject
        JSONObject jsonObject = new JSONObject(payload);
        // Get the value of the "subject" key from the JSON object
        String subject = jsonObject.getString("subject");
        // Check if the value of "subject" equals KEY_VAULT_KIOSK
        return KEY_VAULT_KIOSK.equals(subject);
    }

    // TABLET queue Name are only Matching XX_XX_XX_XX_XX format , removed request
    // to Device table.
    public Boolean shouldProcessDeviceQueue(String queueName) throws ServiceBusCredentialException {
        // Define the pattern for the UUID
        if (queueName.equals(OrchestreService.EVENT) || queueName.equals(OrchestreService.LOG) || queueName.equals(OrchestreService.NEW_KIOSK)) {
            return true;
        }
        String uuidPattern = "^[0-9A-Fa-f]{2}_[0-9A-Fa-f]{2}_[0-9A-Fa-f]{2}_[0-9A-Fa-f]{2}_[0-9A-Fa-f]{2}_[0-9A-Fa-f]{2}$";
        Pattern pattern = Pattern.compile(uuidPattern);
        Matcher matcher = pattern.matcher(queueName);

        // Check if the queueName matches the pattern
        return matcher.matches();
    }

        /***
     * Create a queue if it is needed
     *
     * @param queueName
     */
    private void createQueueIfNeed(String queueName) throws ServiceBusCredentialException {
        if (knownQueues.contains(queueName)) {
            return;
        }
        ServiceBusAdministrationClient sbAdminClient = getAdminServiceClient();
        if (!sbAdminClient.getQueueExists(queueName)) {
            log.info("Create queue " + queueName);
            CreateQueueOptions queueOptions = new CreateQueueOptions()
                    .setMaxSizeInMegabytes(MAX_SIZE_MEGABYTES)
                    .setMaxDeliveryCount(MAX_DELIVERY_COUNT)
                    .setDefaultMessageTimeToLive(Duration.ofDays(TIME_TO_LEAVE))
                    .setLockDuration(Duration.ofSeconds(LOCK_DURATION))
                    .setDeadLetteringOnMessageExpiration(DEAD_LETTER_EXPIRATION)
                    .setPartitioningEnabled(PARTITIONING);
            try {
                sbAdminClient.createQueue(queueName, queueOptions);
            } catch (Exception e) {
                log.error("Error in createQueueIfNeed for queue {}: {}", queueName, e.getMessage());
                return; // not remembered: will be re-checked on the next publish
            }
        }
        knownQueues.add(queueName);
    }
}