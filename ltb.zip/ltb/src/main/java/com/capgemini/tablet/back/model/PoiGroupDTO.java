package com.capgemini.tablet.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiGroupDTO implements WithTitleDTO {

	private Long id;
	private String name;
	private List<String> attributeKeys;
	private Map<String, String> attributes = new HashMap<>();
	private String titleFr;
	private String titleEn;
    private String title;
	private Boolean isFromCdm;

}
