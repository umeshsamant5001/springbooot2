package com.capgemini.tablet.back.model;

import lombok.Data;

@Data
public class ServiceBusConnectionDTO {
	private String connectionString;
}
