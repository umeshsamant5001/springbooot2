package com.capgemini.tablet.back.model;

public interface WithTitleDTO {
    void setTitle(String title);
}
