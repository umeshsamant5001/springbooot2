package com.capgemini.tablet.back.model.exception;

public class ConnectorException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 7748650921857496286L;

	public ConnectorException(String message) {
		super(500, ErrorCodes.CONNECTOR_UNEXPECTED_ERROR, message);
	}

}