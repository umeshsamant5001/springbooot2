package com.capgemini.tablet.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.Floor;


@Repository
public interface FloorRepository extends JpaRepository<Floor, Long> {

    @Query(value = "SELECT title_en  FROM floor WHERE id = :id", nativeQuery = true)
    String findTitleEnByFloorId(@Param("id") Long id);

    @Query(value = "SELECT building_id  FROM floor WHERE id = :id", nativeQuery = true)
    Long getBuildingIdByFloorId(@Param("id") Long id);
	
}
