package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.BuildingDTO;
import com.capgemini.tablet.back.model.City;
import com.capgemini.tablet.back.model.CityDTO;
import com.capgemini.tablet.back.model.Site;
import com.capgemini.tablet.back.model.SiteDTO;

@Named("SiteMapper")
@Mapper(config = DtoMapperConfig.class)
public interface SiteMapper {

    SiteMapper INSTANCE = Mappers.getMapper(SiteMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" }),
    })
    SiteDTO siteToSiteDTO(Site in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "city", ignore = true),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" }),
    })
    SiteDTO _siteToSiteDTOWithoutParent(Site in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(target = "buildings", ignore = true)
    })
    SiteDTO _siteToSiteDTOWithoutChildren(Site in, @Context String language);

    Site siteDTOToSite(SiteDTO in);

    @Named("buildingToBuildingDTOWithoutParent")
    default BuildingDTO _buildingToBuildingDTOWithoutParent(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutParent(building, language);
    }

    @Named("cityToCityDTOWithoutChildren")
    default CityDTO _cityToCityDTOWithoutChildren(City city, @Context String language) {
        return Mappers.getMapper(CityMapper.class)._cityToCityDTOWithoutChildren(city, language);
    }

}