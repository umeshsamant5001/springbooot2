package com.capgemini.tablet.back.controller;

import java.util.Map;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.tablet.back.model.DeclareIssueEmailDTO;
import com.capgemini.tablet.back.service.smtp.SMTPSendMail;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/emails")
public class EmailController {

    @Autowired
    private SMTPSendMail smtpSendMail;

    @PostMapping("/send")
    public ResponseEntity<Map<String, String>> sendEmail(@Valid @RequestBody DeclareIssueEmailDTO dto) {
        try {
            smtpSendMail.sendDeclareIssueEmail(dto);
            return ResponseEntity.ok(Map.of("message", "Email sent successfully"));
        } catch (IllegalArgumentException e) {
            log.error("Validation error while sending email: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (MessagingException e) {
            log.error("Messaging error while sending email: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to send email"));
        }
    }

}
