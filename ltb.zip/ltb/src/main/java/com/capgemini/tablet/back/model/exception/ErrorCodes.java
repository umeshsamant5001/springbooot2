package com.capgemini.tablet.back.model.exception;

public final class ErrorCodes {

	public static final Integer DEVICE_NOT_FOUND = 1;
	
	public static final Integer POI_NOT_FOUND = 2;
	
	public static final Integer BUILDING_NOT_FOUND = 3;
	
	public static final Integer FLOOR_NOT_FOUND = 4;
	
	public static final Integer CONNECTOR_UNEXPECTED_ERROR = 500;
	
	public static final Integer AUTHENTICATION_FAILED = 1000;
	
	// Prevent instantiation
	private ErrorCodes() {
		throw new IllegalAccessError();
	}
}
