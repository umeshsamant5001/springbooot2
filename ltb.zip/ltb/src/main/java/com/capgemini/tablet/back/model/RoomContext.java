package com.capgemini.tablet.back.model;

import java.util.List;
import java.util.Locale;

import lombok.Builder;
import lombok.Value;

/**
 * Everything the graphEvent flow needs to know about a meeting room, resolved once
 * from the database and then passed down the call chain instead of reloading the
 * Poi / Floor / Building / Device graph at every step.
 */
@Value
@Builder
public class RoomContext {

    /** Mailbox of the room (poi attribute conf_room_mail). */
    String mail;

    Long poiId;

    String poiName;

    Long floorId;

    /** Java timezone id of the building (ex: Europe/Paris). */
    String timezoneJava;

    /** Tablets attached to the room; may be empty. */
    List<DeviceDTO> tablets;

    /** Normalized key used for caching and coalescing. */
    public String key() {
        return keyFor(mail);
    }

    public static String keyFor(String mail) {
        return mail == null ? "" : mail.trim().toLowerCase(Locale.ROOT);
    }
}
