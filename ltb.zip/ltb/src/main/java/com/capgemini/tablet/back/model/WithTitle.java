package com.capgemini.tablet.back.model;

public interface WithTitle {
    String getTitleFr();

    String getTitleEn();
}
