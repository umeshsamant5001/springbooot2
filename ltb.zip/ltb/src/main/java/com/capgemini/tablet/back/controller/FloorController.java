package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.tablet.back.mapper.BuildingMapper;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.BuildingDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.service.BuildingService;
import com.capgemini.tablet.back.service.FloorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = FloorController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class FloorController {

	static final String ROOT_API = "api/floor";

	@Autowired
	private FloorService floorService;

	@Autowired
	private BuildingService buildingService;
	
    /**
     * Retrieves the building associated with a given floor ID.
     *
     * @param language the preferred language for the response (default is "en")
     * @param floorId the ID of the floor
     * @return the building details as a BuildingDTO, or 404 Not Found if either the floor or building is not found
     */
	@GetMapping("/{floorId}/building")
	public ResponseEntity<BuildingDTO> getBuildingByFloorIdTest(
		@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
		@PathVariable Long floorId
	) {
		Floor floor = this.floorService.findById(floorId);
		if (Objects.isNull(floor)) {
			log.info("floor not found : {}", floorId);
			return ResponseEntity.notFound().build();
		}

		Building building = null;
		log.info("buildingId : {}", floor.getBuildingId());
		if (Objects.nonNull(floor.getBuildingId())) {
			building = this.buildingService.findById(floor.getBuildingId());
		}

		if (Objects.isNull(building)) {
			log.info("building not found");
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language));
	}
}
