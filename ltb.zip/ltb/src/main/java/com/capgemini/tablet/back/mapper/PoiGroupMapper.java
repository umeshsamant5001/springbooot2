package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.PoiGroup;
import com.capgemini.tablet.back.model.PoiGroupDTO;

@Mapper(config = DtoMapperConfig.class)
public interface PoiGroupMapper {
    
    PoiGroupMapper INSTANCE = Mappers.getMapper(PoiGroupMapper.class);

    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
    PoiGroupDTO poiGroupToPoiGroupDTO(PoiGroup in, @Context String language);

    PoiGroup poiGroupDTOToPoiGroup(PoiGroupDTO in);

}