package com.capgemini.tablet.utils;

import org.hibernate.Hibernate;
import org.mapstruct.Condition;

/**
 * The class is use to make Mapstruct to not try to map Lazy properties.
 */
public class LazyFieldCondition {

    @Condition
    public static boolean isNotLazy(Object value) {
        return Hibernate.isInitialized(value);
    }

}
