package com.capgemini.tablet.back.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class FloorDTO implements WithTitleDTO {

	private Long id;
	private Integer index;
	private BuildingDTO building;
	private Long buildingId;
	private String titleFr;
	private String titleEn;
    private String title;
	private Long modifiedAt = (new Date()).getTime() / 1000;
	private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();

}
