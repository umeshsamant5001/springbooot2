package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiDTO implements WithTitleDTO {

	private Long id;
	private String name;
	private FloorDTO floor;
	private Long floorId;
    private String titleFr;
    private String titleEn;
    private String title;
	private Long modifiedAt = (new Date()).getTime() / 1000;
    private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();
	private List<EquipmentDTO> equipments = new ArrayList<>();
	private String description;
	private Integer floorIndex;
	private SensorDataDTO sensorData;
}
