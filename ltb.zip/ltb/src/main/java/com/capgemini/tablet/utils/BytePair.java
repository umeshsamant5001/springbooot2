package com.capgemini.tablet.utils;

/**
 * @author alcarpen
 *
 */
public class BytePair {

	private byte[] key;

	private byte[] iv;

	/**
	 * Key and iv
	 * 
	 * @param key
	 * @param iv
	 */
	public BytePair(byte[] key, byte[] iv) {
		super();
		this.key = key;
		this.iv = iv;
	}

	/**
	 * @return the key
	 */
	public byte[] getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(byte[] key) {
		this.key = key;
	}

	/**
	 * @return the iv
	 */
	public byte[] getIv() {
		return iv;
	}

	/**
	 * @param iv
	 *            the iv to set
	 */
	public void setIv(byte[] iv) {
		this.iv = iv;
	}

}
