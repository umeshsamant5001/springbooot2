package com.capgemini.tablet.back.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class use for the reponse of the api who provide the admin password of tablet
 * 
 * @author alcarpen
 *
 */
@Data
@AllArgsConstructor
public class KioskMode {

	private String password;

	private String passcode;
}
