package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class CountryDTO implements WithTitleDTO {

	private Long id;
	private List<CityDTO> cities = new ArrayList<>();
	private Long modifiedAt = (new Date()).getTime() / 1000;
	private Long cdmKeyId;
	private String countryIsoAlpha2;
	private String titleFr;
	private String titleEn;
	private String title;
	private Map<String, String> attributes = new HashMap<String, String>();

}
