package com.capgemini.tablet.back.model.enumeration;

public enum EnumErrorLoggingType {

  NONE,DEFAULT,INFORMATION,WARNING,CRITICAL,USER;
  
}
