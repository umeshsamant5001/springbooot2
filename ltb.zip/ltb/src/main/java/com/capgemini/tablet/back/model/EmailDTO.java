package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class EmailDTO {
    private String sender;
    private List<String> adressee = new ArrayList<>();
    private List<String> copies = new ArrayList<>();
    private String subject;
    private String body;
    private String attachment;
    private String fileName;
    /** Map of CID (content ID) → classpath path of the image, e.g. "SMARTOFFICE_HEADER" → "email-assets/smartoffice-header.png" */
    private Map<String, String> inlineImages = new LinkedHashMap<>();
}
