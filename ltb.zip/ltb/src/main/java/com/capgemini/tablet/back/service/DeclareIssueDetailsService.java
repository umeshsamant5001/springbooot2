package com.capgemini.tablet.back.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.HashMap;

import com.capgemini.tablet.back.model.DeclareIssueDetailsDTO;
import com.capgemini.tablet.back.repository.DeclareIssueDetailsRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DeclareIssueDetailsService {

    @Autowired
    private DeclareIssueDetailsRepository declareIssueDetailsRepository;

    public List<DeclareIssueDetailsDTO> getDeclareIssues(Long buildingId) {
        List<DeclareIssueDetailsDTO> detailsList = declareIssueDetailsRepository
                .findDeclareIssuesByCountryByBuildingId(buildingId);
        return detailsList;
    }

    public String getDeclareIssues(Long buildingId, String issueDescription) {
        String emailId = declareIssueDetailsRepository.findByBuildingIdAndIssueDesc(
                buildingId, issueDescription);
        return emailId;
    }
   
    /**
     * Returns a map with all fields needed for the email body, using one SQL (poi -> floor -> building, poi_attributes).
     * Adds tabletUuid, issueDescription, and the current IST time as "issueRaisedAt".
     *
     * Map keys:
     *   buildingId, buildingName, meetingRoomName, poiName, meetingRoomEmail,
     *   tabletMacId, issueType, issueRaisedAt
     */
    public Map<String, Object> getEmailDisplayData(String poiName, String tabletUuid, String issueDescription) {
               
        List<Object[]> list = declareIssueDetailsRepository.fetchEmailDisplayRowByPoiName(poiName);
        
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("Invalid POI name: " + poiName);
        }
        
        Object[] row = list.get(0);

        Long buildingId = (row[0] == null) ? null : ((Number) row[0]).longValue();
        String buildingName = toStr(row[1]);
        String meetingRoomName = toStr(row[2]);
        String poiNameDb = toStr(row[3]);
        String meetingRoomEmail = toStr(row[4]);
        String timezoneJava = toStr(row[5]);   // <-- dynamic timezone

        // If building timezone is missing, fallback to UTC
        if (timezoneJava == null || timezoneJava.isBlank()) {
            timezoneJava = "UTC";
        }

        ZoneId zone = ZoneId.of(timezoneJava);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy h:mm a");
        String issueRaisedAt = ZonedDateTime.now(zone).format(fmt);

        Map<String, Object> map = new HashMap<>();
        map.put("buildingId", buildingId);
        map.put("BUILDING_TITLE_EN_NAME", buildingName);
        map.put("MEETING_ROOM_NAME", meetingRoomName);
        map.put("MEETING_ROOM_EMAIL", meetingRoomEmail);
        map.put("POI_TITLE_EN_NAME", poiNameDb);
        map.put("TABLET_MAC_ID", (tabletUuid == null || tabletUuid.isBlank()) ? "N/A" : tabletUuid);
        map.put("ISSUE_TYPE", issueDescription);
        map.put("ISSUE_RAISED_AT", issueRaisedAt);
        return map;
    }

    private static String toStr(Object o) {
        return o == null ? null : String.valueOf(o);
    }

}