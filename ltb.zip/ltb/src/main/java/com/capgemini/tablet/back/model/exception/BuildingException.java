package com.capgemini.tablet.back.model.exception;

public class BuildingException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 3154414080730702568L;

	public BuildingException(String message) {
		super(404, ErrorCodes.BUILDING_NOT_FOUND, message);
	}

}
