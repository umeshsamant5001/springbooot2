package com.capgemini.tablet.back.service;

import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.core.io.ClassPathResource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.text.StringSubstitutor;
import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import com.capgemini.tablet.back.config.ApplicationProperties;
import com.capgemini.tablet.back.config.Constants;
import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.mapper.MeetingMapper;
import com.capgemini.tablet.back.mapper.PoiMapper;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.EmailDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.Meeting;
import com.capgemini.tablet.back.model.MeetingDTO;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.PoiDTO;
import com.capgemini.tablet.back.model.RoomContext;
import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.repository.MeetingRepository;
import com.capgemini.tablet.back.service.smtp.SMTPSendMail;
import com.microsoft.graph.core.ClientException;
import com.microsoft.graph.models.Attendee;
import com.microsoft.graph.models.AttendeeType;
import com.microsoft.graph.models.DateTimeTimeZone;
import com.microsoft.graph.models.EmailAddress;
import org.springframework.core.env.Environment;
import com.microsoft.graph.models.Event;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MeetingService {

    private static final Pattern ENCODED_MEETING_ID_PATTERN = Pattern.compile("^[A-Za-z0-9%._+\\-]+$");

   


   
    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private PoiService poiService;

    @Autowired
    private MeetingRepository meetingRepository;

    @Autowired
    private FloorService floorService;

    @Autowired
    private SMTPSendMail emailService;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    MeetingBookingService meetingBookingService;

    @Autowired
    private Environment environment;

    @Autowired
    private RoomContextResolver roomContextResolver;


    /**
     *
     * @param meetingDTO
     * @param poi
     * @param timeZoneJava
     * @return CompletableFuture<Event>
     * @throws Exception
     */
    public CompletableFuture<Event> createEvent(MeetingDTO meetingDTO, Poi poi, String timeZoneJava) throws Exception {
        Event event = new Event();
        // set Subject
        event.subject = meetingDTO.getSubject();

        // set Start
        MutableDateTime mutableDateTimeStart = new MutableDateTime(
                this.getUTCEpochFromZonedEpoch(meetingDTO.getFrom(), timeZoneJava) * 1000,
                DateTimeZone.UTC);
        DateTimeTimeZone dateTimeTimeZoneStart = new DateTimeTimeZone();
        dateTimeTimeZoneStart.dateTime = mutableDateTimeStart.toDateTime().toString();
        dateTimeTimeZoneStart.timeZone = timeZoneJava;
        event.start = dateTimeTimeZoneStart;

        // set End
        MutableDateTime mutableDateTimeEnd = new MutableDateTime(
                this.getUTCEpochFromZonedEpoch(meetingDTO.getTo(), timeZoneJava) * 1000,
                DateTimeZone.UTC);
        DateTimeTimeZone dateTimeTimeZoneEnd = new DateTimeTimeZone();
        dateTimeTimeZoneEnd.dateTime = mutableDateTimeEnd.toDateTime().toString();
        dateTimeTimeZoneEnd.timeZone = timeZoneJava;
        event.end = dateTimeTimeZoneEnd;

        // Set Organizer
        if (Objects.nonNull(meetingDTO.getBooker())) {
            EmailAddress emailAddressBooker = new EmailAddress();
            emailAddressBooker.address = meetingDTO.getBooker().getEmail();
            emailAddressBooker.name = meetingDTO.getBooker().getFirstName();
            Attendee attendeeBooker = new Attendee();
            attendeeBooker.emailAddress = emailAddressBooker;
            event.organizer = attendeeBooker;
        }

        // Set list of Attendee (just add a room)
        LinkedList<Attendee> listAttendees = new LinkedList<>();
        Attendee attendeeRoom = new Attendee();
        String regexEmailRoom = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
        if (!Pattern.compile(regexEmailRoom).matcher(poi.getAttributes().get(Constants.CONF_ROOM_MAIL)).matches()) {
            throw new IllegalArgumentException("format of poi email is invalid");
        }
        EmailAddress emailAddressRoom = new EmailAddress();
        emailAddressRoom.address = poi.getAttributes().get(Constants.CONF_ROOM_MAIL);
        emailAddressRoom.name = poi.getName();
        attendeeRoom.emailAddress = emailAddressRoom;
        attendeeRoom.type = AttendeeType.REQUIRED;
        listAttendees.add(attendeeRoom);
        event.attendees = listAttendees;

        // Renvoi une erreur 404 si email incorect ou inexistante
        return graphHelper.createEvent(poi.getAttributes().get(Constants.CONF_ROOM_MAIL), event);
    }

    /**
     * Send an email few minutes before a meeting
     *
     * @param meetingDTO
     * @param timeToCheckIn
     * @throws Exception
     */
    public void sendEmailBeforeMeetingOrig(MeetingDTO meetingDTO, int timeToCheckIn, Poi poi) throws Exception {
        Floor floor = poi.getFloor();
        if (Objects.isNull(floor)) {
            throw new Exception("Floor not found");
        }

        Building building = floor.getBuilding();
        if (Objects.isNull(building)) {
            throw new Exception("Building not found");
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, "en");

        MutableDateTime time = new MutableDateTime(DateTimeZone.UTC);
        time.setMillis((meetingDTO.getFrom() * 1000) + (timeToCheckIn * 60 * 1000));
        time.setMillisOfSecond(0);
        time.setSecondOfMinute(0);
        time.setZoneRetainFields(DateTimeZone.forID(building.getTimezoneJava()));

        // Create EmailDTO
        Map<String, Object> params = new HashMap<>();
        EmailDTO emailDTO = new EmailDTO();
        params.put("LAST_NAME", meetingDTO.getBooker().getLastName());
        params.put("FIRST_NAME", meetingDTO.getBooker().getFirstName());
        params.put("ROOM_NAME", poiDTO.getTitleEn());
        params.put("END_DATE_NOSHOW_HOUR", time.getHourOfDay());
        params.put("END_DATE_NOSHOW_MINUTE", String.format("%02d", time.getMinuteOfHour()));
        emailDTO.setAdressee(List.of(meetingDTO.getBooker().getEmail()));

        emailDTO.setBody(
                StringSubstitutor.replace(this.applicationProperties.getMeeting().getCheckInTrigger().getBody(), params,
                        "${", "}"));
        params.clear();
        params.put("ROOM_NAME", poiDTO.getTitleEn());
        params.put("END_DATE_NOSHOW_HOUR", time.getHourOfDay());
        params.put("END_DATE_NOSHOW_MINUTE", String.format("%02d", time.getMinuteOfHour()));
        String originalSubject = StringSubstitutor.replace(
                this.applicationProperties.getMeeting().getCheckInTrigger().getSubject(), params, "${", "}");

        // Check if 'sit' is one of the active profiles
        String[] activeProfiles = environment.getActiveProfiles();
        boolean isSit = Arrays.asList(activeProfiles).contains(Constants.PROFILE_SIT);

        if (isSit) {
            log.info("Active profile is SIT — tagging email subject.");
            originalSubject = "[SIT] " + originalSubject;
        } else {
            log.info("Active profile is not SIT — no tagging applied.");
        }

        emailDTO.setSubject(originalSubject);

        try {
            this.emailService.sendEmail(emailDTO);
        } catch (Exception e) {
            log.warn(e.getMessage(), e);
        }
    }

    /**
     * Send an email few minutes before a meeting
     *
     * @param meetingDTO
     * @param timeToCheckIn
     * @throws Exception
     */
    public void sendEmailBeforeMeeting(MeetingDTO meetingDTO, int timeToCheckIn, Poi poi) throws Exception {
        Floor floor = poi.getFloor();
        if (Objects.isNull(floor)) {
            throw new Exception("Floor not found");
        }

        Building building = floor.getBuilding();
        if (Objects.isNull(building)) {
            throw new Exception("Building not found");
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, "en");
        String viewMapUrlParam = "buildingId=" + building.getId() + "&floorId=" + floor.getId() + "&roomEmail=" + meetingDTO.getRoom();
        MutableDateTime time = new MutableDateTime(DateTimeZone.UTC);
        time.setMillis((meetingDTO.getFrom() * 1000) + (timeToCheckIn * 60 * 1000));
        time.setMillisOfSecond(0);
        time.setSecondOfMinute(0);
        time.setZoneRetainFields(DateTimeZone.forID(building.getTimezoneJava()));

        MutableDateTime meetingEndTime = new MutableDateTime(DateTimeZone.UTC);
        meetingEndTime.setMillis(meetingDTO.getTo() * 1000);
        meetingEndTime.setMillisOfSecond(0);
        meetingEndTime.setSecondOfMinute(0);
        meetingEndTime.setZoneRetainFields(DateTimeZone.forID(building.getTimezoneJava()));
        
        // Create EmailDTO
        Map<String, Object> params = new HashMap<>();
        EmailDTO emailDTO = new EmailDTO();
        params.put("LAST_NAME", meetingDTO.getBooker().getLastName());
        params.put("FIRST_NAME", meetingDTO.getBooker().getFirstName());
        params.put("ROOM_NAME", poiDTO.getTitleEn());
        params.put("END_DATE_NOSHOW_HOUR", time.getHourOfDay());
        params.put("END_DATE_NOSHOW_MINUTE", String.format("%02d", time.getMinuteOfHour()));
        params.put("BUILDING_NAME", building.getTitleEn());
        params.put("FLOOR_NAME", floor.getTitleEn());
        params.put("MEETING_TIME", time.getHourOfDay() + ":" + String.format("%02d", time.getMinuteOfHour()) + " - " + meetingEndTime.getHourOfDay() + ":" + String.format("%02d", meetingEndTime.getMinuteOfHour()));
        params.put("CHECKIN_TIME", time.getHourOfDay() + ":" + String.format("%02d", time.getMinuteOfHour()));
        params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckInTrigger().getServiceCentralUrl(), ""));

        emailDTO.setAdressee(List.of(meetingDTO.getBooker().getEmail()));   
        // Check if 'sit' is one of the active profiles
        String[] activeProfiles = environment.getActiveProfiles();
        boolean isSit = Arrays.asList(activeProfiles).contains(Constants.PROFILE_SIT);
        params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl(isSit));
        String originalSubject = StringSubstitutor.replace(
                this.applicationProperties.getMeeting().getCheckInTrigger().getSubject(), params, "${", "}");
        if (isSit) {
            log.info("Active profile is SIT — tagging email subject.");

            originalSubject = "[SIT] " + originalSubject;
            params.put("VIEW_MAP_URL", "https://web-sit-smartoffice.capgemini.com/#/home/viewmap?" + viewMapUrlParam);
        } else {
            log.info("Active profile is not SIT — no tagging applied.");
            params.put("VIEW_MAP_URL", "https://web-smartoffice.capgemini.com/#/home/viewmap?" + viewMapUrlParam);
        }

        emailDTO.setSubject(originalSubject);
        // Set body from template
        String checkInAlertTemplate = this.applicationProperties.getMeeting().getCheckInTrigger().getTemplate();
        if (checkInAlertTemplate == null || checkInAlertTemplate.isBlank()) {
            throw new IllegalStateException("check in alert email template is not configured");
        }
        String checkInAlertBodyTemplate = this.readEmailTemplate(checkInAlertTemplate);
        emailDTO.setBody(
            StringSubstitutor.replace(checkInAlertBodyTemplate,
                        params, "${", "}"));
        emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-in-alert.png");
        emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");

      
        try {
            this.emailService.sendEmail(emailDTO);
        } catch (Exception e) {
            log.warn(e.getMessage(), e);
        }
    }

    public void sendEmailBeforeMeetingTest(){
        int timeToCheckIn =15;
    
        String viewMapUrlParam = "buildingId=" + 2815 + "&floorId=" + 5132 + "&roomEmail=" + "cr.in.ggncant5gf4pmr0-6@capgemini.com";
        MutableDateTime time = new MutableDateTime(DateTimeZone.UTC);
        time.setMillis((1775223000 * 1000) + (timeToCheckIn * 60 * 1000));
        time.setMillisOfSecond(0);
        time.setSecondOfMinute(0);
        time.setZoneRetainFields(DateTimeZone.forID(null));

        MutableDateTime meetingEndTime = new MutableDateTime(DateTimeZone.UTC);
        meetingEndTime.setMillis(1775228400 * 1000);
        meetingEndTime.setMillisOfSecond(0);
        meetingEndTime.setSecondOfMinute(0);
        meetingEndTime.setZoneRetainFields(DateTimeZone.forID(null));
        
        // Create EmailDTO
        Map<String, Object> params = new HashMap<>();
        EmailDTO emailDTO = new EmailDTO();
        params.put("LAST_NAME", "Samant");
        params.put("FIRST_NAME", "Umesh");
        params.put("ROOM_NAME", "Bubble 7");
        params.put("END_DATE_NOSHOW_HOUR", time.getHourOfDay());
        params.put("END_DATE_NOSHOW_MINUTE", String.format("%02d", time.getMinuteOfHour()));
        params.put("BUILDING_NAME", "TORANOMON");
        params.put("FLOOR_NAME", "FLOOR-0");
        params.put("MEETING_TIME", time.getHourOfDay() + ":" + String.format("%02d", time.getMinuteOfHour()) + " - " + meetingEndTime.getHourOfDay() + ":" + String.format("%02d", meetingEndTime.getMinuteOfHour()));
        params.put("CHECKIN_TIME", time.getHourOfDay() + ":" + String.format("%02d", time.getMinuteOfHour()));
        params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckInTrigger().getServiceCentralUrl(), ""));
        emailDTO.setAdressee(List.of("umesh.samant.ext@capgemini.com"));//meetingDTO.getBooker().getEmail());
        
        // Check if 'sit' is one of the active profiles
        String[] activeProfiles = environment.getActiveProfiles();
        boolean isSit = Arrays.asList(activeProfiles).contains(Constants.PROFILE_SIT);
        params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl(isSit));
        String originalSubject = StringSubstitutor.replace(
                this.applicationProperties.getMeeting().getCheckInTrigger().getSubject(), params, "${", "}");
        if (isSit) {
            log.info("Active profile is SIT — tagging email subject.");
            originalSubject = "[SIT] " + originalSubject;
            params.put("VIEW_MAP_URL", "https://web-sit-smartoffice.capgemini.com/#/home/viewmap?" + viewMapUrlParam);
        } else {
            log.info("Active profile is not SIT — no tagging applied.");
            params.put("VIEW_MAP_URL", "https://web-smartoffice.capgemini.com/#/home/viewmap?" + viewMapUrlParam);
        }

        emailDTO.setSubject(originalSubject);
        // Set body from template
        String checkInAlertTemplate = this.applicationProperties.getMeeting().getCheckInTrigger().getTemplate();
        if (checkInAlertTemplate == null || checkInAlertTemplate.isBlank()) {
            throw new IllegalStateException("check in alert email template is not configured");
        }
        String checkInAlertBodyTemplate = this.readEmailTemplate(checkInAlertTemplate);
        emailDTO.setBody(
            StringSubstitutor.replace(checkInAlertBodyTemplate,
                        params, "${", "}"));
        emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-in-alert.png");
        emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");
    
        try {
            log.info("sendEmailBeforeMeetingTest: invoking emailService.sendEmail for recipients={}, subject='{}'",
                emailDTO.getAdressee(), emailDTO.getSubject());
            this.emailService.sendEmail(emailDTO);
            log.info("sendEmailBeforeMeetingTest: emailService.sendEmail returned without throwing for recipients={}",
                emailDTO.getAdressee());
        } catch (Exception e) {
            log.error("sendEmailBeforeMeetingTest: failed to send email to {} - error class={}, message={}",
                emailDTO.getAdressee(), e.getClass().getName(), e.getMessage(), e);
        }
    }


    public int getDurationCheckIn(Poi poi) {
        return poi.getAttributes().containsKey(Constants.CHECKIN_DURATION)
                && NumberUtils.isDigits(poi.getAttributes().get(Constants.CHECKIN_DURATION))
                        ? Integer.parseInt(poi.getAttributes().get(Constants.CHECKIN_DURATION))
                        : Constants.FIFTEEN_MINUTES;
    }

    /**
     * Get an event thanks to timeslot id and delete it
     *
     * @param poiEmail
     * @param meetingDTO
     * @throws Exception
     */
    public boolean freeRoomForMeeting(String poiEmail, MeetingDTO meetingDTO, Boolean isFromNoShow) {
        String organizerEmail = meetingDTO.getBooker().getEmail();

        // Need to decode the id of the appointment from the Meeting information
        String meetingId = null;
        try {
            meetingId = URLDecoder.decode(meetingDTO.getId(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.warn(e.getMessage());
            return false;
        }

        // Delete an event
        try {
            graphHelper.deleteEventById(poiEmail, meetingId);
        } catch (ClientException e) {
            log.warn(e.getMessage());
            return false;
        }
        log.info("event {} deleted.", meetingId);

        if (!this.areSameEmail(organizerEmail, poiEmail)) {
            Poi poi = poiService.getPoiByNameAndFloorId(meetingDTO.getPoiName(),meetingDTO.getFloorId());
            PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, "en");
            String buildingTimeZoneId = poi.getFloor().getBuilding().getTimezoneJava();
            ZoneId countryTimeZone = ZoneId.of(buildingTimeZoneId);

            ZonedDateTime dateTime = ZonedDateTime.now(countryTimeZone);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            String timeNew = dateTime.format(formatter);
            Map<String, Object> params = new HashMap<>();
            EmailDTO emailDTO = new EmailDTO();
            emailDTO.setAdressee(List.of(organizerEmail));
            params.put("LAST_NAME", meetingDTO.getBooker().getLastName());
            params.put("FIRST_NAME", meetingDTO.getBooker().getFirstName());
            params.put("ROOM_NAME", poiDTO.getTitleEn());
            params.put("TIME", timeNew);
            params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckOut().getServiceCentralUrl(), ""));

            params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl());
                    
            if (Boolean.TRUE.equals(isFromNoShow)) {
                emailDTO.setSubject(
                    StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getSubject(),
                        params, "${", "}"));
                // Make SERVICE_CENTRAL_URL available to the template
                params.put("SERVICE_CENTRAL_URL",
                    this.applicationProperties.getMeeting().getNoShow().getServiceCentralUrl());
                // Try to load HTML template from classpath if configured
                String templateName = this.applicationProperties.getMeeting().getNoShow().getTemplate();
                if (templateName != null && !templateName.isEmpty()) {
                    try {
                    String templatePath = "email-templates/" + templateName;
                    ClassPathResource resource = new ClassPathResource(templatePath);
                    String template = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                    emailDTO.setBody(StringSubstitutor.replace(template, params, "${", "}"));
                    // Attach inline images referenced by the template
                    emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header.png");
                    emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");
    
                    } catch (IOException e) {
                    log.warn("Unable to load no-show template {}, falling back to plain body: {}", templateName,
                        e.getMessage());
                    emailDTO.setBody(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getBody(), params,
                            "${", "}"));
                    }
                } else {
                    emailDTO.setBody(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getBody(), params,
                            "${", "}"));
                }
            } else {
            
                String checkOutTemplatePath = this.applicationProperties.getMeeting().getCheckOut().getTemplate();
                if (checkOutTemplatePath == null || checkOutTemplatePath.isBlank()) {
                    throw new IllegalStateException("checkout email template is not configured");
                }
                String checkOutBodyTemplate = this.readEmailTemplate(checkOutTemplatePath);

                emailDTO.setSubject(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getCheckOut().getSubject(),
                                params, "${", "}"));
                emailDTO.setBody(
                    StringSubstitutor.replace(checkOutBodyTemplate,
                                params, "${", "}"));
                emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-out.png");
                emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");

            }

            try {
                emailService.sendEmail(emailDTO);
            } catch (Exception e) {
                log.warn(e.getMessage(), e);
                return false;
            }
            log.info("message sent.");
        }
        return true;
    }

    public boolean freeRoomForMeetingTest(Boolean isFromNoShow) { //String poiEmail, MeetingDTO meetingDTO, Boolean isFromNoShow) {
        String organizerEmail = "pulimi.kanaka-keerthi@capgemini.com";//umesh.samant.ext@capgemini.com";
        String poiEmail = "pulimi.kanaka-keerthi@capgemini.com"; //umesh.samant.ext1@capgemini.com

        if (!this.areSameEmail(organizerEmail, poiEmail)) {

            ZonedDateTime dateTime = ZonedDateTime.now(ZoneOffset.UTC);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            String timeNew = dateTime.format(formatter);
            Map<String, Object> params = new HashMap<>();
            EmailDTO emailDTO = new EmailDTO();
            emailDTO.setAdressee(List.of(organizerEmail));
            params.put("LAST_NAME", "Sah");
            params.put("FIRST_NAME", "Harendra");
            params.put("ROOM_NAME", "Bubble 7");
            params.put("TIME", timeNew);
            params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckOut().getServiceCentralUrl(), ""));

            params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl());
                            
            if (Boolean.TRUE.equals(isFromNoShow)) {
                emailDTO.setSubject(
                    StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getSubject(),
                        params, "${", "}"));
                params.put("SERVICE_CENTRAL_URL",
                    this.applicationProperties.getMeeting().getNoShow().getServiceCentralUrl());
                // Try to load HTML template from classpath if configured
                String templateName = this.applicationProperties.getMeeting().getNoShow().getTemplate();
                if (templateName != null && !templateName.isEmpty()) {
                    try {
                    String templatePath = "email-templates/" + templateName;
                    ClassPathResource resource = new ClassPathResource(templatePath);
                    String template = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                    emailDTO.setBody(StringSubstitutor.replace(template, params, "${", "}"));
                    // Attach inline images referenced by the template
                    emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header.png");
                    emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");
                    } catch (IOException e) {
                    log.warn("Unable to load no-show template {}, falling back to plain body: {}", templateName,
                        e.getMessage());
                    emailDTO.setBody(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getBody(), params,
                            "${", "}"));
                    }
                } else {
                    emailDTO.setBody(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getNoShow().getBody(), params,
                            "${", "}"));
                }
            } else {
            
                String checkOutTemplatePath = this.applicationProperties.getMeeting().getCheckOut().getTemplate();
                if (checkOutTemplatePath == null || checkOutTemplatePath.isBlank()) {
                    throw new IllegalStateException("checkout email template is not configured");
                }
                String checkOutBodyTemplate = this.readEmailTemplate(checkOutTemplatePath);

                emailDTO.setSubject(
                        StringSubstitutor.replace(this.applicationProperties.getMeeting().getCheckOut().getSubject(),
                                params, "${", "}"));
                emailDTO.setBody(
                    StringSubstitutor.replace(checkOutBodyTemplate,
                                params, "${", "}"));
                emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-out.png");
                emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");
                

            }

            try {
                emailService.sendEmail(emailDTO);
            } catch (Exception e) {
                log.warn(e.getMessage(), e);
                return false;
            }
            log.info("message sent.");
        }
        return true;
    }

    private String readEmailTemplate(String templateFileName) {
        String templatePath = "email-templates/" + templateFileName;
        try {
            ClassPathResource resource = new ClassPathResource(templatePath);
            if (!resource.exists()) {
                throw new IllegalArgumentException("Email template not found: " + templatePath);
            }
            try (InputStream inputStream = resource.getInputStream()) {
                return StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Unable to read email template: " + templatePath, e);
        }
    }

    public Meeting findOrCreateMeeting(MeetingDTO meetingDTO, String roomMail, Long floorId) {
        Meeting meeting = meetingRepository.findById(meetingDTO.getId());
        if (Objects.isNull(meeting)) {
            Meeting newMeeting = MeetingMapper.INSTANCE.meetingDTOToMeeting(meetingDTO);
            newMeeting.setCreated(System.currentTimeMillis());
            newMeeting.setCheckStatus(EnumMeetingStatus.CREATED);
            newMeeting.setModifiedAt(System.currentTimeMillis());
            newMeeting.setFloor(this.floorService.findById(floorId));
            newMeeting.setNoshowCounter(0);
            newMeeting.setRoom(roomMail);
            newMeeting.setPoiName(meetingDTO.getPoiName());
            return meetingRepository.save(newMeeting);
        }
        return meeting;
    }

    public Meeting findMeeting(String meetingId) {
        String sanitizedMeetingId = sanitizeMeetingId(meetingId);
        if (Objects.isNull(sanitizedMeetingId)) {
            log.warn("Rejected meeting lookup due to invalid meeting id format");
            return null;
        }
        return meetingRepository.findById(new String(sanitizedMeetingId));
    }


    public void sendCheckInEmail(MeetingDTO meetingDTO) {
        Poi poi = poiService.getPoiByNameAndFloorId(meetingDTO.getPoiName(),meetingDTO.getFloorId());
        String roomName = poi.getTitleEn();
        String firstName = meetingDTO.getBooker().getFirstName();
        String lastName = meetingDTO.getBooker().getLastName();

        String buildingTimeZoneId = poi.getFloor().getBuilding().getTimezoneJava();
        ZoneId countryTimeZone = ZoneId.of(buildingTimeZoneId);

        ZonedDateTime dateTime = ZonedDateTime.now(countryTimeZone);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String timeNew = dateTime.format(formatter);

        Map<String, Object> params = new HashMap<>();
        params.put("ROOM_NAME", roomName);
        params.put("FIRST_NAME", firstName);
        params.put("LAST_NAME", lastName);
        params.put("TIME", timeNew);
        params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckIn().getServiceCentralUrl(), ""));
        params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl());

        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setAdressee(List.of(meetingDTO.getBooker().getEmail()));

        String checkInTemplatePath = this.applicationProperties.getMeeting().getCheckIn().getTemplate();
        if (checkInTemplatePath == null || checkInTemplatePath.isBlank()) {
            throw new IllegalStateException("check-in email template is not configured");
        }
        String checkInBodyTemplate = this.readEmailTemplate(checkInTemplatePath);

        emailDTO.setSubject(
                StringSubstitutor.replace(this.applicationProperties.getMeeting().getCheckIn().getSubject(),
                        params, "${", "}"));
        emailDTO.setBody(
            StringSubstitutor.replace(checkInBodyTemplate,
                        params, "${", "}"));
        emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-in.png");
        emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");

        try {
            emailService.sendEmail(emailDTO);
            log.info("Check-in email sent to {}", meetingDTO.getBooker().getEmail());
        } catch (Exception e) {
            log.error("Error sending check-in email: {}", e.getMessage(), e);
        }

    }

    private String getMeetingBookingsUrl() {
        boolean isSit = Arrays.asList(environment.getActiveProfiles()).contains(Constants.PROFILE_SIT);
        return getMeetingBookingsUrl(isSit);
    }

    private String getMeetingBookingsUrl(boolean isSit) {
        return isSit
                ? "https://web-sit-smartoffice.capgemini.com/#/home/allServicesMenu"
                : "https://web-smartoffice.capgemini.com/#/home/allServicesMenu";
    }

    public boolean checkInRoomForMeetingTest() { //String poiEmail, MeetingDTO meetingDTO, Boolean isFromNoShow) {
        String organizerEmail = "harendra.sah@capgemini.com";

            ZonedDateTime dateTime = ZonedDateTime.now(ZoneOffset.UTC);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            String timeNew = dateTime.format(formatter);
            Map<String, Object> params = new HashMap<>();
            EmailDTO emailDTO = new EmailDTO();
            emailDTO.setAdressee(List.of(organizerEmail));
            params.put("LAST_NAME", "Sah");
            params.put("FIRST_NAME", "Harendra");
            params.put("ROOM_NAME", "Bubble 7");
            params.put("TIME", timeNew);
            params.put("SERVICE_CENTRAL_URL",
                    Objects.toString(this.applicationProperties.getMeeting().getCheckIn().getServiceCentralUrl(), ""));
            params.put("MEETING_BOOKINGS_URL", getMeetingBookingsUrl());

        String checkInTemplatePath = this.applicationProperties.getMeeting().getCheckIn().getTemplate();
        if (checkInTemplatePath == null || checkInTemplatePath.isBlank()) {
            throw new IllegalStateException("check-in email template is not configured");
        }
        String checkInBodyTemplate = this.readEmailTemplate(checkInTemplatePath);

        emailDTO.setSubject(
                StringSubstitutor.replace(this.applicationProperties.getMeeting().getCheckIn().getSubject(),
                        params, "${", "}"));
        emailDTO.setBody(
            StringSubstitutor.replace(checkInBodyTemplate,
                        params, "${", "}"));
        emailDTO.getInlineImages().put("SMARTOFFICE_HEADER", "email-assets/smartoffice-header-check-in.png");
        emailDTO.getInlineImages().put("SMARTOFFICE_PHONE", "email-assets/smartoffice-phone.png");

        try {
            log.info("checkInRoomForMeetingTest: invoking emailService.sendEmail for recipients={}, subject='{}'",
                emailDTO.getAdressee(), emailDTO.getSubject());
            emailService.sendEmail(emailDTO);
            log.info("checkInRoomForMeetingTest: emailService.sendEmail returned without throwing for recipients={}",
                emailDTO.getAdressee());
        } catch (Exception e) {
            log.error("checkInRoomForMeetingTest: failed to send check-in email to {} - error class={}, message={}",
                emailDTO.getAdressee(), e.getClass().getName(), e.getMessage(), e);
        }

        return true;
    }


    public Meeting save(Meeting meeting) {
        if (Objects.isNull(meeting)) {
            throw new IllegalArgumentException("meeting is required");
        }

        String sanitizedMeetingId = sanitizeMeetingId(meeting.getId());
        if (Objects.isNull(sanitizedMeetingId)) {
            throw new IllegalArgumentException("Invalid meeting identifier");
        }

        Long sanitizedFrom = sanitizeMeetingTimestamp(meeting.getFrom(), "start");
        Long sanitizedTo = sanitizeMeetingTimestamp(meeting.getTo(), "end");

        if (Objects.nonNull(sanitizedFrom) && Objects.nonNull(sanitizedTo)
                && sanitizedTo <= sanitizedFrom) {
            throw new IllegalArgumentException("Invalid meeting time range");
        }

        Meeting meetingToSave = new Meeting();
        meetingToSave.setId(new String(sanitizedMeetingId));

        if (Objects.nonNull(sanitizedFrom)) {
            meetingToSave.setFrom(Long.valueOf(String.valueOf(sanitizedFrom)));
        }
        if (Objects.nonNull(sanitizedTo)) {
            meetingToSave.setTo(Long.valueOf(String.valueOf(sanitizedTo)));
        }

        if (Objects.nonNull(meeting.getFromUtc())) {
            meetingToSave.setFromUtc(Long.valueOf(String.valueOf(meeting.getFromUtc())));
        }
        if (Objects.nonNull(meeting.getToUtc())) {
            meetingToSave.setToUtc(Long.valueOf(String.valueOf(meeting.getToUtc())));
        }
        if (Objects.nonNull(meeting.getCheckStatus())) {
            meetingToSave.setCheckStatus(EnumMeetingStatus.valueOf(String.valueOf(meeting.getCheckStatus())));
        }
        if (Objects.nonNull(meeting.getRoom())) {
            meetingToSave.setRoom(new String(meeting.getRoom()));
        }

        Long validatedFloorId = null;
        if (Objects.nonNull(meeting.getFloorId())) {
            validatedFloorId = Long.valueOf(String.valueOf(meeting.getFloorId()));
        } else if (Objects.nonNull(meeting.getFloor()) && Objects.nonNull(meeting.getFloor().getId())) {
            validatedFloorId = Long.valueOf(String.valueOf(meeting.getFloor().getId()));
        }
        if (Objects.nonNull(validatedFloorId)) {
            Floor validatedFloor = this.floorService.findById(validatedFloorId);
            if (Objects.isNull(validatedFloor)) {
                throw new IllegalArgumentException("Invalid floor identifier");
            }
            meetingToSave.setFloor(validatedFloor);
            meetingToSave.setFloorId(Long.valueOf(String.valueOf(validatedFloor.getId())));
        }

        if (Objects.nonNull(meeting.getPoiName())) {
            meetingToSave.setPoiName(new String(meeting.getPoiName()));
        }
        if (Objects.nonNull(meeting.getCreated())) {
            meetingToSave.setCreated(Long.valueOf(String.valueOf(meeting.getCreated())));
        }
        if (Objects.nonNull(meeting.getModifiedAt())) {
            meetingToSave.setModifiedAt(Long.valueOf(String.valueOf(meeting.getModifiedAt())));
        }
        if (Objects.nonNull(meeting.getNoshowCounter())) {
            meetingToSave.setNoshowCounter(Integer.valueOf(String.valueOf(meeting.getNoshowCounter())));
        }
        if (Objects.nonNull(meeting.getAlertCheckIn())) {
            meetingToSave.setAlertCheckIn(Boolean.valueOf(String.valueOf(meeting.getAlertCheckIn())));
        }
        if (Objects.nonNull(meeting.getPushAlert())) {
            meetingToSave.setPushAlert(Boolean.valueOf(String.valueOf(meeting.getPushAlert())));
        }

        return meetingRepository.save(meetingToSave);
    }


    private String sanitizeMeetingId(String meetingId) {
        if (Objects.isNull(meetingId)) {
            return null;
        }
        String candidateMeetingId = new String(meetingId.trim());
        if (candidateMeetingId.isEmpty()
                || !ENCODED_MEETING_ID_PATTERN.matcher(candidateMeetingId).matches()) {
            return null;
        }

        try {
            String decodedMeetingId = URLDecoder.decode(candidateMeetingId, StandardCharsets.UTF_8.toString());
            if (decodedMeetingId.isBlank()) {
                return null;
            }
            String canonicalMeetingId = URLEncoder.encode(decodedMeetingId, StandardCharsets.UTF_8.toString());
            if (!candidateMeetingId.equals(canonicalMeetingId)) {
                return null;
            }
            return new String(canonicalMeetingId);
        } catch (UnsupportedEncodingException e) {
            log.warn("Unable to validate meeting id format: {}", e.getMessage());
            return null;
        } catch (IllegalArgumentException e) {
            log.warn("Unable to decode meeting id: {}", e.getMessage());
            return null;
        }
    }

    private Long sanitizeMeetingTimestamp(Long timestamp, String fieldName) {
        if (Objects.isNull(timestamp)) {
            return null;
        }
        if (timestamp <= 0L) {
            throw new IllegalArgumentException("Invalid meeting " + fieldName + " timestamp");
        }
        return Long.valueOf(String.valueOf(timestamp));
    }


    /**
     * Legacy signature: loads the POI by id and delegates to
     * {@link #getMeetings(RoomContext, Long, Long)}.
     *
     * @throws Exception if the POI does not contain the required conference room
     *                   email attribute
     */
    public List<MeetingDTO> getMeetings(Long poiId, Long from, Long to) throws Exception {
        Poi poi = poiService.findById(poiId);
        if (poi == null || poi.getFloor() == null || poi.getFloor().getBuilding() == null) {
            log.error("POI, Floor, or Building not found");
            throw new IllegalStateException("Invalid POI data");
        }
        return getMeetings(roomContextResolver.fromPoi(poi), from, to);
    }

    /**
     * Retrieves the meetings of a room within a time range, from the Graph calendar,
     * and synchronizes them into the meeting table.
     *
     * @param room the room (poi, building timezone, mailbox) already resolved
     * @param from the start timestamp (epoch seconds) of the search range
     * @param to   the end timestamp (epoch seconds) of the search range
     * @return the meetings coming from Graph, with their check status from the DB
     * @throws Exception if the room has no conference room email attribute
     */
    public List<MeetingDTO> getMeetings(RoomContext room, Long from, Long to) throws Exception {
        if (Objects.isNull(room.getMail())) {
            throw new Exception(Constants.NO_EMAIL_CODE);
        }

        log.info("Fetching meetings for roomMail={} from={} to={} in timezone={} for poiName={}", room.getMail(),
                from, to, room.getTimezoneJava(), room.getPoiName());
        return meetingBookingService.getMeetingDTOs(room.getMail(), from, to, room.getTimezoneJava(),
                room.getPoiName(), room.getFloorId());
    }

    private boolean areSameEmail(String email1, String email2) {
        return email1.split("@")[0].equalsIgnoreCase(email2.split("@")[0]);
    }

    /**
     * Convert epoch in give zone to UTC epoch
     *
     * @param timestampSeconds
     * @param zone
     * @return
     */
    private long getUTCEpochFromZonedEpoch(long timestampSeconds, String zone) {
        ZonedDateTime zonedDatetime;
        if (zone == null) {
            zonedDatetime = LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), Constants.UTC_ZONE_ID)
                    .atZone(ZoneId.of(Constants.UTC_ZONE_ID.getId()));
        } else {
            zonedDatetime = LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), Constants.UTC_ZONE_ID)
                    .atZone(ZoneId.of(zone));
        }
        return zonedDatetime.toInstant().toEpochMilli() / 1000;
    }

}
