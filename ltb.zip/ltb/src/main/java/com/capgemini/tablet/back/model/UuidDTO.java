package com.capgemini.tablet.back.model;

import lombok.Data;

@Data
public class UuidDTO {
    private String encryptedUuid;
}