package com.capgemini.tablet.back.service.bus;

import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.azure.messaging.servicebus.ServiceBusException;
import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.mapper.BuildingMapper;
import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.BuildingDTO;
import com.capgemini.tablet.back.model.DeclareIssueBuildingDetailsDTO;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.MeetingDTO;
import com.capgemini.tablet.back.model.PoiDTO;
import com.capgemini.tablet.back.model.RoomContext;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.model.exception.BuildingException;
import com.capgemini.tablet.back.model.exception.DeviceException;
import com.capgemini.tablet.back.model.exception.PoiException;
import com.capgemini.tablet.back.service.BuildingService;
import com.capgemini.tablet.back.service.DeclareIssueBuildingDetailsService;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.MeetingService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.RoomContextResolver;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.graph.models.Subscription;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

/***
 * Service to orchestre bus communication
 *
 * @author bleduc
 *
 */
@Service
@Slf4j
public class OrchestreService {
    public static final String PLANNING = "planning";
    public static final String DEVICE = "device";
    public static final String POI = "pois";
    public static final String BUILDING = "building";
    public static final String EVENT = "event";
    public static final String LOG = "log";
    public static final String NEW_KIOSK = "newKiosk";

    @Value("${application.azure.graphApi.notificationUrl}")
    private String azureGraphAPINotificationUrl;

    @Autowired
    private AzureServiceBusService azureServiceBusService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private MeetingService meetingService;

    @Autowired
    private RoomContextResolver roomContextResolver;

    // @Autowired
    // private DeclareIssueDetailsService declareIssueDetailsService;
    @Autowired
    private DeclareIssueBuildingDetailsService declareIssueBuildingDetailsService;

    /***
     * Notification function for all tablets
     */
    public void notifyAllTablet() {
        List<Device> lTablet = deviceService.findAllByDeviceType(EnumDeviceType.TABLET);
        List<DeviceDTO> lTabletDTO = new ArrayList<>();
        for (Device device : lTablet) {
            DeviceDTO deviceDTO = DeviceMapper.INSTANCE.deviceToDeviceDTO(device, "en");

            createSubscriptionTabletOnKiosk(deviceDTO);
            lTabletDTO.add(deviceDTO);
        }

        subscribeGraphAPIList(lTabletDTO);
    }

    /*
     * trigger api on second container to get the calendar of all pois after a
     * container reboot
     */
    public void triggerSecondContainerPlanningEvent() {
        // request PUT on second container
    }

    /**
     * Manage the subscription of all the tablet
     */
    public void subscribeGraphApiAllTablet() {
        List<Device> lTablet = deviceService.findAllByDeviceType(EnumDeviceType.TABLET);

        List<DeviceDTO> lTabletDTO = lTablet.stream()
                .map(device -> DeviceMapper.INSTANCE.deviceToDeviceDTO(device, "en")) // TODO THD language
                .collect(Collectors.toList());

        subscribeGraphAPIList(lTabletDTO);
    }

    /***
     * Notification function for a tablet
     */
    public void notifyTablet(String uuid) {
        // This method will call once tablet device gets rebooted

        Device device = deviceService.findTabletByUuid(uuid);

        if (Objects.isNull(device)) {
            handleDeviceNotFound(uuid);
            return;
        }

        DeviceDTO deviceDTO = DeviceMapper.INSTANCE.deviceToDeviceDTO(device, "en"); // TODO THD language

        long timestampSecondsStart = Instant.now().getEpochSecond();
        long timestampSecondsEnd = timestampSecondsStart + MeetingBusService.ONE_DAY_SECOND;

        publishDeviceData(deviceDTO, timestampSecondsStart, timestampSecondsEnd);
        createSubscriptionTabletOnKiosk(deviceDTO);
        azureServiceBusService.updateKiosk();
        subscribeGraphAPI(deviceDTO);
    }

    private void handleDeviceNotFound(String uuid) {
        String message = String.format("Device %s doesn't exist", uuid);
        log.warn(message);
        throw new DeviceException(message);
    }

    private void publishDeviceData(DeviceDTO deviceDTO, long timestampSecondsStart, long timestampSecondsEnd) {
        publishDevice(deviceDTO);
        publishPoi(deviceDTO);
        publishBuilding(deviceDTO);
        log.info("Calling Publishing planning  in publishDeviceData for device {}, timestampSecondsStart={}, timestampSecondsEnd={}", deviceDTO.getUuid(), timestampSecondsStart, timestampSecondsEnd);
        publishPlanning(deviceDTO, timestampSecondsStart, timestampSecondsEnd);
    }

    /***
     * Legacy signature: resolves the room from the device, then publishes.
     *
     * @param deviceDTO
     * @param timestampSecondsStart
     * @param timestampSecondsEnd
     */
    public void publishPlanning(DeviceDTO deviceDTO, long timestampSecondsStart, long timestampSecondsEnd) {
        try {
            RoomContext room = roomContextResolver.fromDevice(deviceDTO);
            publishPlanning(deviceDTO, room, timestampSecondsStart, timestampSecondsEnd);
        } catch (Exception e) {
            log.error("Error while resolving room for device {}: {}", deviceDTO.getUuid(), e.getMessage(), e);
        }
    }

    /***
     * Function to publish a specific planning range on a tablet
     *
     * @param deviceDTO             the tablet to publish to
     * @param room                  the room already resolved (poi, timezone, mail)
     * @param timestampSecondsStart
     * @param timestampSecondsEnd
     */
    public void publishPlanning(DeviceDTO deviceDTO, RoomContext room, long timestampSecondsStart,
            long timestampSecondsEnd) {
        log.info("publishPlanning for device {} (room {}) from {} to {}", deviceDTO.getUuid(), room.getMail(),
                timestampSecondsStart, timestampSecondsEnd);
        String queueName = queueNameToTablet(deviceDTO.getUuid());
        try {
            logQueue(queueName, PLANNING);

            // Extend the start time backwards to include early meetings in other timezones
            long fromIncludingTimezones = timestampSecondsStart - MeetingBusService.FOURTEEN_HOURS_SECOND;

            List<MeetingDTO> meetings = meetingService.getMeetings(room, fromIncludingTimezones, timestampSecondsEnd);
            log.info("Fetched {} meetings in publishPlanning for device {} between {} and {}", meetings.size(),
                    deviceDTO.getUuid(), fromIncludingTimezones, timestampSecondsEnd);

            if (Objects.nonNull(meetings)) {
                ObjectMapper mapper = new ObjectMapper();
                String payload = mapper.writeValueAsString(meetings);
                logQueueMessage(queueName, PLANNING, payload);
                azureServiceBusService.publish(queueName, PLANNING, payload);
            }
        } catch (Exception e) {
            log.error("Error while publishing planning for device {}: {}", deviceDTO.getUuid(), e.getMessage(), e);
        }
    }
    

    /***
     * Publish one day planning for a tablet
     */
    public void publishOneDayPlanningTablet(DeviceDTO deviceDTO) {
        Instant instant = Instant.now();
        // Ensuring we include the max possible difference in timezone
        long timestampSecondsStart = instant.getEpochSecond();
        long timestampSecondsEnd = timestampSecondsStart + MeetingBusService.ONE_DAY_SECOND;
        log.info("Calling Publishing from publishOneDayPlanningTablet for device {} with timestampSecondsStart={} and timestampSecondsEnd={}", deviceDTO.getUuid(), timestampSecondsStart, timestampSecondsEnd);
        publishPlanning(deviceDTO, timestampSecondsStart, timestampSecondsEnd);
    }

    /**
     * Function to create subscription on kiosk topic for a tablet.
     *
     * @param deviceDTO
     */
    public void createSubscriptionTabletOnKiosk(DeviceDTO deviceDTO) {
        try {
            String subscriptionName = topicSubscriptionNameToTablet(deviceDTO.getUuid());
            azureServiceBusService.createSubscriptionOnKioskTopic(subscriptionName);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /***
     * Function to publish poi information on a tablet.
     *
     * @param deviceDTO
     */
    public void publishPoi(DeviceDTO deviceDTO) {
        try {
            PoiDTO poiDTO = poiService.getPoiFromDevice(deviceDTO);
            publishPoi(deviceDTO.getUuid(), poiDTO);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * Function to publish poi information on a tablet.
     *
     * @param uuid
     * @param poiDTO
     */
    public void publishPoi(String uuid, PoiDTO poiDTO) {
        try {
            String queueName = queueNameToTablet(uuid);
            logQueue(queueName, POI);
            ObjectMapper mapper = new ObjectMapper();
            String payload = mapper.writeValueAsString(poiDTO);
            logQueueMessage(queueName, POI, payload);
            azureServiceBusService.publish(queueName, POI, payload);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /***
     * Function to publish device information on a tablet
     * Removes outdated attributes if lastChange is older than 24 hours
     *
     * @param deviceDTO
     */
    public void publishDevice(DeviceDTO deviceDTO) {
        try {
            // Get the current time in seconds
            long currentTimeSeconds = Instant.now().getEpochSecond();

            // Get the last change time from deviceDTO
            Long lastChangeSeconds = deviceDTO.getLastChange();

            if (lastChangeSeconds != null) {
                // Calculate the time difference in hours (1 hour = 3600 seconds)
                long hoursDifference = (currentTimeSeconds - lastChangeSeconds) / 3600;

                // If the device's last change was more than 24 hours ago, clear outdated
                // attributes
                if (hoursDifference > 24) {
                    log.info("Clearing outdated attributes for device: {}", deviceDTO.getUuid());
                    deviceDTO.getAttributes().clear(); // Clear the attributes map
                }
            }

            // Proceed to publish device data to the Azure Service Bus
            String queueName = queueNameToTablet(deviceDTO.getUuid());
            logQueue(queueName, DEVICE);

            ObjectMapper mapper = new ObjectMapper();
            String payload = mapper.writeValueAsString(deviceDTO);

            logQueueMessage(queueName, DEVICE, payload);
            azureServiceBusService.publish(queueName, DEVICE, payload);

        } catch (Exception e) {
            log.error("Error while publishing device data to tablet: {}", e.getMessage());
        }
    }

    /***
     * Function to publish building information on a tablet
     * @param deviceDTO
    */
    public void publishBuilding(DeviceDTO deviceDTO) {
        try {
            String queueName = queueNameToTablet(deviceDTO.getUuid());
            logQueue(queueName, BUILDING);
            BuildingDTO buildingDTO = getBuildingFromDevice(deviceDTO);
            ObjectMapper mapper = new ObjectMapper();
            String payload = mapper.writeValueAsString(buildingDTO);
            List<DeclareIssueBuildingDetailsDTO> declareIssueDetailsDTOList =  getDeclareIssuesByBuildingId(buildingDTO.getId()); 
            if(Objects.nonNull(declareIssueDetailsDTOList) && !declareIssueDetailsDTOList.isEmpty()){
                String issues = declareIssueDetailsDTOList.stream()
                    .map(dto -> dto.getIssueDescription() != null ? dto.getIssueDescription() : "")
                    .collect(Collectors.joining(";")); // Join with comma and space
                JsonNode rootNode = mapper.readTree(payload);
                ObjectNode attributesNode = (ObjectNode) rootNode.get("attributes");
                attributesNode.set("declareIssue", new TextNode(issues));
                payload = mapper.writeValueAsString(rootNode);                
            }           
            logQueueMessage(
                    queueName,
                    BUILDING,
                    String.format(
                            "buildingId=%s, buildingName=%s, payloadSize=%d",
                            buildingDTO.getId(),
                            buildingDTO.getTitleEn(),
                            payload.length()));
            azureServiceBusService.publish(queueName, BUILDING, payload);            

        } catch (Exception e) {
             log.error("Error while publishing building: ", e);
        }
    }    



    /***
     * Function to publish kiosk information on a kiosk topic
     *
     * @return
     */
    public void publishKiosk() {
        azureServiceBusService.updateKiosk();
    }

    /***
     * Function to subscribe bus tablet queue events and logs
     *
     */
    public void subscribeUniquesQueues() {
        subscribeBusEvents();
        subscribeBusKiosk();
    }

    /***
     * Function to subscribe bus tablet queue Event
     *
     */
    public void subscribeBusEvents() {
        try {
            log.info("Subscribe " + EVENT);
            azureServiceBusService.subscribeByQueue(EVENT);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /***
     * Function to subscribe bus tablet queue Logs
     *
     */
    public void subscribeBusLogs() {
        try {
            log.info("Subscribe " + LOG);
            azureServiceBusService.subscribeByQueue(LOG);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    public void subscribeBusKiosk() {
        try {
            log.info("Subscribe " + NEW_KIOSK);
            azureServiceBusService.subscribeByQueue(NEW_KIOSK);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /***
     * Function to manage subscription of all tablet.
     * Create/extend/delete
     *
     * @param lTablet
     */
    private void subscribeGraphAPIList(List<DeviceDTO> lTablet) {
        
        if (CollectionUtils.isEmpty(lTablet)) {
            return;
        }

        try {

            // Get the list of emails for each tablet
            List<String> tabletEmails = getEmailsFromTablet(lTablet);
            // Get all the existing subscriptions
            Map<String, Subscription> allSubscription = getAllPlanningSubscription();
            log.info("Calling manageGraphApiSubscription from subscribeGraphAPIList ");
            // Manage the extends/creation/deletion of subscriptions
            manageGraphApiSubscription(tabletEmails, allSubscription);
        } catch (Exception e) {
            log.error("Error while processing the planning subscription", e);
        }
    }


    /**
     * Function to manage the subscription of one tablet.
     * Create/Extend
     *
     * @param tablet
     */
    private void subscribeGraphAPI(DeviceDTO tablet) {
        if (Objects.isNull(tablet)) {
            return;
        }

        try {
            // Get the email of the tablet
            String email = getEmailFromTablet(tablet);

            if (Objects.isNull(email)) {
                return;
            }

            // Get all the existing subscriptions
            Map<String, Subscription> allSubscription = getAllPlanningSubscription();

            Map<String, Subscription> oneSubscription;
            if (allSubscription.containsKey(email)) {
                oneSubscription = Collections.singletonMap(email, allSubscription.get(email));
            } else {
                oneSubscription = new HashMap<>();
            }

            // Manage the extends/creation of the subscription
            manageGraphApiSubscription(
                    Collections.singletonList(email),
                    oneSubscription);

        } catch (Exception e) {
            log.error(String.format("Error while processing the planning subscription : %s", e.getMessage()));
        }
    }

    /**
     * Get the associated emails of a list of tablets
     *
     * @param lTablet The list of tablets
     * @return A list of emails.
     */
    private List<String> getEmailsFromTablet(List<DeviceDTO> lTablet) {
        List<String> tabletEmails = new ArrayList<>();

        for (DeviceDTO deviceDTO : lTablet) {
            String email = getEmailFromTablet(deviceDTO);

            if (Objects.nonNull(email)) {
                tabletEmails.add(email);
            }
        }

        return tabletEmails;
    }

    private String getEmailFromTablet(DeviceDTO tablet) {
        try {
            PoiDTO poiDTO = poiService.getPoiFromDevice(tablet);

            if (Objects.nonNull(poiDTO.getAttributes())
                    && poiDTO.getAttributes().containsKey(MeetingBusService.CONF_ROOM_MAIL)) {
                return poiDTO.getAttributes().get(MeetingBusService.CONF_ROOM_MAIL);
            }
        } catch (PoiException e) {
            log.warn("Poi error while getting poi for email : {}", e.getMessage());
        }

        return null;
    }

    /**
     * Get all the existing subscription for the planning.
     *
     * @return A map of subscription with their email has key.
     * @throws InterruptedException
     * @throws ExecutionException
     * @throws ParseException
     */
    private Map<String, Subscription> getAllPlanningSubscription()
            throws InterruptedException, ExecutionException, ParseException {
        // Regex to be sure we only keep the type of subscriptions
        Pattern pattern = Pattern.compile("^/users/(.+)/events$");

        return graphHelper.getSubscription().get().stream()
                // Filter to keep only Planning Events
                .filter(subscription -> pattern.matcher(subscription.resource).find())
                // Filter to keep only Events link to the platform (based on norification URL)
                .filter(subscription -> azureGraphAPINotificationUrl.equals(subscription.notificationUrl))
                .collect(
                        Collectors.toMap(
                                // Function to get the key of the map
                                subscription -> {
                                    Matcher matcher = pattern.matcher(subscription.resource);
                                    matcher.find();

                                    return matcher.group(1);
                                },
                                // Function to get the value of the map
                                Function.identity(),
                                // Function in case of duplicate key : we choose one subscription
                                (subscription1, subscription2) -> subscription1));
    }

    /**
     * Synchronizes Graph subscriptions against the COMPLETE
     * authoritative list of room mailbox emails.
     *
     * Any existing subscription not present in tabletEmails
     * will be deleted.
     * @param tabletEmails        List of the tablet's emails
     * @param mappedSubscriptions Map of the subscription with their email as key.
     * @throws ParseException
     */
    private void manageGraphApiSubscription(List<String> tabletEmails, Map<String, Subscription> mappedSubscriptions)
            throws ParseException {
        // Loop over the actual subscription
        log.info("List<String> tabletEmails size() >>> "+tabletEmails.size());
        log.info("mappedSubscriptions map size() >>> "+mappedSubscriptions.size());
        for (Entry<String, Subscription> entry : mappedSubscriptions.entrySet()) {
            String email = entry.getKey();
            Subscription subscription = entry.getValue();
            

            if (tabletEmails.contains(email)) {
                log.info("In manageGraphApiSubscription from tabletEmails.contains(email) "+email);
                
                // In the case of the subscription match a tablet : extend the time of the
                // subscription
                log.info(String.format("Extend subscription for %s", email));
                graphHelper.extendSubscription(subscription, GraphHelper.EXTEND_PLANNING_SUBSCRIPTION_MINUTE);
            } else {
                // In the case of the subscription don't match a tablet : delete the
                // subscription
                log.info("In manageGraphApiSubscription from NOT tabletEmails.contains(email) "+email);
                log.info(String.format("Delete subscription for %s", email));
                graphHelper.deleteSubscription(subscription);
            }
        }

        // Loop over the emails of the tablets
        for (String email : tabletEmails) {
            if (!mappedSubscriptions.containsKey(email)) {
                // In the case of the tablet don't match a subscription : create the
                // subscription
                log.info(String.format("Create subscription for %s", email));
                try {
                    graphHelper.createPlanningSubscription(email);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }

                // For the case of tablets with same email, we add like it's already created
                mappedSubscriptions.put(email, null);
            }
        }
    }

    /***
     * Function to get BuildingDTO from a device
     *
     * @param deviceDTO
     * @return
     */
    private BuildingDTO getBuildingFromDevice(DeviceDTO deviceDTO) {
        PoiDTO poiDTO = poiService.getPoiFromDevice(deviceDTO);

        Building building = buildingService.findByFloorId(poiDTO.getFloorId());
        if (Objects.isNull(building)) {
            String message = String.format("No Building found for floorId %s", poiDTO.getFloorId());
            log.warn(message);
            throw new BuildingException(message);
        }
        return BuildingMapper.INSTANCE.buildingToBuildingDTO(building, "en");
    }

    /***
     * Log Queue payload
     *
     * @param queue
     * @param subject
     * @param payload
     */
    private void logQueueMessage(String queue, String subject, String payload) {
        log.trace("queue : {} subject : {} payload : {} ", queue, subject, payload );
    }

    /***
     * log queue name & subject
     *
     * @param queue
     * @param subject
     */
    private void logQueue(String queue, String subject) {
      log.info("queue : {} subject : {} ", queue, subject);
    }

    /***
     * Create queueName Tablet
     *
     * @param uuid
     * @return
     */
    private String queueNameToTablet(String uuid) {
        return String.format("%s", uuid);
    }

    /***
     * Create topic subscriptionName Tablet
     *
     * @param uuid
     * @return
     */
    private String topicSubscriptionNameToTablet(String uuid) {
        return String.format("%s", uuid);
    }
      
    /**
     * Retrieves declare issues for a given building ID and returns them as a JSON ArrayNode.     
     * @param buildingId The ID of the building for which declare issues need to be fetched.
     * @return List<DeclareIssueBuildingDetailsDTO> containing declare issue details DTO.
    */
    private List<DeclareIssueBuildingDetailsDTO> getDeclareIssuesByBuildingId(Long buildingId) {
   
        List<DeclareIssueBuildingDetailsDTO> declareIssueDetailsDTOList = declareIssueBuildingDetailsService.getDeclareIssues(buildingId); 
        
        return declareIssueDetailsDTOList;
      
    }     
    
}
