package com.capgemini.tablet.back.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "declare_issue_building_details")
public class DeclareIssueBuildingDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="DeclareIssueBuildingDetails_Generator")
    @SequenceGenerator(name = "DeclareIssueBuildingDetails_Generator", sequenceName = "DeclareIssueBuildingDetails_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "declare_issue_id")
    @JsonIgnore
    private DeclareIssue declareIssue;

    @Column(name = "declare_issue_id", updatable = false, insertable = false)
    private Long declareIssueId;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "building_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Building building;

    @Column(name = "building_id")
    private Long buildingId;

    @Column(name = "email_id", length = 50)
    private String emailId;

    @Column(name = "modified_at", nullable = false)
    private Long modifiedAt = new Date().getTime() / 1000;

    @Column(name = "created_at", nullable = false)
    private Long createdAt = new Date().getTime() / 1000;

     // Add this method to get the declareIssueId without the separate column
     public Long getDeclareIssueId() {
        return declareIssue != null ? declareIssue.getId() : null;
    }

}