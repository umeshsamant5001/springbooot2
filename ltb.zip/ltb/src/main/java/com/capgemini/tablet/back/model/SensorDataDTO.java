package com.capgemini.tablet.back.model;

import lombok.Data;

@Data
public class SensorDataDTO {
	private String uuid;
	private String deviceType;
	private String poiName;
	private Long cdmKeyIdPoi;
	private Long cdmKeyIdFloor;
	private String lastChange;
	private Double battery;
	private String status;
	private Double tempC;
	private Double tempF;
	private Double co2;
	private Double humidity;
	private Double noise;
	private Double light;
	private String occupancy;
}
