package com.capgemini.tablet.back.mapper;


import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.tablet.back.model.BuildingInformation;
import com.capgemini.tablet.back.model.BuildingInformationDTO;

@Named("BuildingInformationMapper")
@Mapper(config = DtoMapperConfig.class)
public interface BuildingInformationMapper {

    BuildingInformationMapper INSTANCE = Mappers.getMapper(BuildingInformationMapper.class);

    BuildingInformationDTO BuildingInformationToBuildingInformationDTO(BuildingInformation in, @Context String language);

    BuildingInformation BuildingInformationDTOToBuildingInformation(BuildingInformationDTO in, @Context String language);
    
}
