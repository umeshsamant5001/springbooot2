package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class BuildingDTO implements WithTitleDTO{

	private Long id;
    private List<FloorDTO> floors = new ArrayList<>();
	private Long siteId;
	private SiteDTO site;
	private BuildingInformationDTO information;
	private Boolean deployed = false;
	private Boolean secured = false;
	private String timezoneWindows;
	private String timezoneJava;
    private String titleFr;
    private String titleEn;
    private String title;
	private Long modifiedAt = (new Date()).getTime() / 1000;
	private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();

}
