package com.capgemini.tablet.back.model.enumeration;

public enum EnumStatus {
    FREE, BUSY, UNKNOWN, TENTATIVE;
}
