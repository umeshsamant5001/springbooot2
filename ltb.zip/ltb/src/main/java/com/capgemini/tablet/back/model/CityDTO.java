package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class CityDTO implements WithTitleDTO {

	private Long id;
	private List<SiteDTO> sites = new ArrayList<>();
	private CountryDTO country;
	private Long countryId;
	private Long modifiedAt = (new Date()).getTime() / 1000;
	private Long cdmKeyId;
	private String titleFr;
	private String titleEn;
	private String title;
	private Long cdmStateId;
	private Map<String, String> attributes = new HashMap<String, String>();

}
