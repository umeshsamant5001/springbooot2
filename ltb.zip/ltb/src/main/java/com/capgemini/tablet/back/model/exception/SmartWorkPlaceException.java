package com.capgemini.tablet.back.model.exception;


public abstract class SmartWorkPlaceException extends RuntimeException {

	private static final long serialVersionUID = -3413152488747677582L;
	
	private final int httpStatus;
	
	private final int errorCode;
	

	protected SmartWorkPlaceException(int httpStatus, int errorCode, String message) {
		super(message);
		this.httpStatus = httpStatus;
		this.errorCode = errorCode;
	}

	public int getHttpStatus() {
		return httpStatus;
	}

	public int getErrorCode() {
		return errorCode;
	}

}
