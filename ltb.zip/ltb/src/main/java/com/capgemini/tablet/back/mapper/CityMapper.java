package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.City;
import com.capgemini.tablet.back.model.CityDTO;
import com.capgemini.tablet.back.model.Country;
import com.capgemini.tablet.back.model.CountryDTO;
import com.capgemini.tablet.back.model.Site;
import com.capgemini.tablet.back.model.SiteDTO;

@Named("CityMapper")
@Mapper(config = DtoMapperConfig.class)
public interface CityMapper {

    CityMapper INSTANCE = Mappers.getMapper(CityMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "country", target = "country", qualifiedByName = { "countryToCountryDTOWithoutChildren" }),
        @Mapping(source = "sites", target = "sites", qualifiedByName = { "siteToSiteDTOWithoutParent" }),
    })
    CityDTO cityToCityDTO(City in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("cityToCityDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "country", ignore = true),
        @Mapping(source = "sites", target = "sites", qualifiedByName = { "siteToSiteDTOWithoutParent" }),
    })
    CityDTO _cityToCityDTOWithoutParent(City in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("cityToCityDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "country", target = "country", qualifiedByName = { "countryToCountryDTOWithoutChildren" }),
        @Mapping(target = "sites", ignore = true),
    })
    CityDTO _cityToCityDTOWithoutChildren(City in, @Context String language);

    City cityDTOToCity(CityDTO in);

    @Named("countryToCountryDTOWithoutChildren")
    default CountryDTO _countryToCountryDTOWithoutChildren(Country country, @Context String language) {
        return Mappers.getMapper(CountryMapper.class)._countryToCountryDTOWithoutChildren(country, language);
    }

    @Named("siteToSiteDTOWithoutParent")
    default SiteDTO _siteToSiteDTOWithoutParent(Site site, @Context String language) {
        return Mappers.getMapper(SiteMapper.class)._siteToSiteDTOWithoutParent(site, language);
    }
}
