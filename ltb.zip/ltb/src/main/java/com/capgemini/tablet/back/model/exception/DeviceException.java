package com.capgemini.tablet.back.model.exception;

public class DeviceException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 3154414080730702568L;

	public DeviceException(String message) {
		super(404, ErrorCodes.DEVICE_NOT_FOUND, message);
	}

}
