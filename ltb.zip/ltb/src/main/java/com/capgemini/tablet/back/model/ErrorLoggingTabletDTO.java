package com.capgemini.tablet.back.model;

import com.capgemini.tablet.back.model.enumeration.EnumErrorLoggingType;
import lombok.Data;

@Data
public class ErrorLoggingTabletDTO {
	private Long id;
    private String uuid;
	private String description;
	private EnumErrorLoggingType errorLoggingType;
	private Long date;
}
