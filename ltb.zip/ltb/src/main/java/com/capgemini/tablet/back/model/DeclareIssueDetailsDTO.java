package com.capgemini.tablet.back.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeclareIssueDetailsDTO {
    private Long countryId;
    private Long issueId;
    private String issueDescription;
}
