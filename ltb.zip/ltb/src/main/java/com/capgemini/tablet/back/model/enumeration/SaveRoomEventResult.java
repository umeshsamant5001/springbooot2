package com.capgemini.tablet.back.model.enumeration;

public enum SaveRoomEventResult {
    SAVED,
    CANCELLED,
    RETRY_REQUIRED,
    CONFIGURATION_ERROR
}