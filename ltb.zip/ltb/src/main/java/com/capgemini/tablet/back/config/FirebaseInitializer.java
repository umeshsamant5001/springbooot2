package com.capgemini.tablet.back.config;

import com.capgemini.tablet.back.service.AzureKeyVaultService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Map;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class FirebaseInitializer {

    private boolean isInitialized = false;

    @Autowired
    private Environment environment;

     @Autowired
    AzureKeyVaultService azureKeyVaultService;

    // public FirebaseInitializer(Environment environment) {
    //     this.environment = environment;
    // }

   // @PostConstruct
    public synchronized void initialize() {
        log.info(" STARTING initialize() Initializing Firebase for {} environment >>> "+environment.getActiveProfiles());
        if (isInitialized)
            return;
        try {
            String androidFile = getServiceAccountFile("android");
            String iosFile = getServiceAccountFile("ios");
            
            String privateKey = null;
            String privateKeyId = null;
            //String privateKeyIOS = null;
            // String privateKeyIdIOS = null;
            if (isProfile("develop") || isProfile("dev") || isProfile("sit")) {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKeySit").getValue();
                privateKey = privateKey.replace("\\n", "\n");

                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyIdSit").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n"); // decode escaped newlines
            } else if (isProfile("uat")) {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKeyUat").getValue();
                privateKey = privateKey.replace("\\n", "\n"); // decode escaped newlines
                
                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyIdUat").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n"); // decode escaped newlines
            } else {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKey").getValue();
                privateKey = privateKey.replace("\\n", "\n");

                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyId").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n");

                // log.info("Initializing Firebase for {} environment PROD IOS >>  ", Arrays.toString(environment.getActiveProfiles()));
                // privateKeyIOS = azureKeyVaultService.getSecret("fcmPrivateKeyIOS").getValue();
                // privateKeyIOS = privateKeyIOS.replace("\\n", "\n");
                // log.info("Initializing Firebase for PROD {}  privateKeyIOS ", privateKeyIOS);
                // privateKeyIdIOS = azureKeyVaultService.getSecret("fcmPrivateKeyIdIOS").getValue();
                // privateKeyIdIOS = privateKeyIdIOS.replace("\\n", "\n");
                // log.info("Initializing Firebase for PROD {}  privateKeyIdIOS ", privateKeyIdIOS);

            }
            initializeFirebaseApp("androidApp", androidFile, privateKey, privateKeyId);
            initializeFirebaseApp("iosApp", iosFile, privateKey, privateKeyId);
            // if (privateKeyIOS !=null && privateKeyIdIOS != null) {
            //     initializeFirebaseApp("iosApp", iosFile, privateKeyIOS, privateKeyIdIOS);
            // }
            isInitialized = true;
            log.info("Firebase apps initialized successfully");
        } catch (Exception e) {
            log.error("Firebase initialization failed: {}", e.getMessage(), e);
        }
    }

    private void initializeFirebaseApp(String appName, String fileName, String privateKey, String privateKeyId)
            throws Exception {
        InputStream serviceAccount = new ClassPathResource(fileName).getInputStream();
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> credentialsMap = mapper.readValue(serviceAccount, Map.class);
        // Inject values from Azure Key Vault
        credentialsMap.put("private_key", privateKey);
        credentialsMap.put("private_key_id", privateKeyId);
        // Convert back to InputStream
        byte[] updatedJson = mapper.writeValueAsBytes(credentialsMap);
        InputStream updatedStream = new java.io.ByteArrayInputStream(updatedJson);
        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(updatedStream))
                .build();
        FirebaseApp.initializeApp(options, appName);
        log.info("[Firebase] {} initialized with {}", appName, fileName);
    }

    private String getServiceAccountFile(String platform) {
        if (isProfile("develop") || isProfile("dev"))
            return "service-account_" + platform + ".json";
        if (isProfile("sit"))
            return "service-account_" + platform + "_sit.json";
        if (isProfile("uat"))
            return "service-account_" + platform + "_uat.json";
        if (isProfile("production"))
            return "service-account_" + platform + "_prod.json";
        throw new IllegalStateException("Unknown profile");
    }

    private boolean isProfile(String profile) {
        return Arrays.stream(environment.getActiveProfiles()).anyMatch(profile::equalsIgnoreCase);
    }

}