package com.capgemini.tablet.back.service.bus;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.model.AppRegistrationManagement;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.Meeting;
import com.capgemini.tablet.back.model.MeetingDTO;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.model.enumeration.EnumOsType;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.DeviceTokenService;
import com.capgemini.tablet.back.service.MeetingService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.PushNotificationService;
import com.google.gson.Gson;
import com.microsoft.graph.core.ClientException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MeetingBusService {
    public static final String CONF_ROOM_MAIL = "conf_room_mail";
    public static final long ONE_DAY_SECOND = 86400L;
    public static final long FOURTEEN_HOURS_SECOND = 50400L;
    private static final int SECONDS_TO_MILLISECONDS =1000;
    private static final int MINUTES_TO_SECONDS = 60;

    private static final String KEY_TABLET = "tablet_disable_checkin_checkout";

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private PushNotificationService pushNotificationService;

    @Autowired
    private MeetingService meetingService;

    @Autowired
    private DeviceService deviceService;

    private OrchestreService orchestreService;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    public MeetingBusService(@Lazy OrchestreService orchestreService) {
        this.orchestreService = orchestreService;
    }

    /***
     * Manage checkout from received payload from Azure ServiceBus
     *
     * @param payload
     */
    public void checkout(String payload) {
        MeetingDTO meetingTabletDTO = new Gson().fromJson(payload, MeetingDTO.class);
        Meeting meeting = this.meetingService.findMeeting(meetingTabletDTO.getId());

        if (Objects.nonNull(meeting)) {
            boolean graphOK = this.meetingService.freeRoomForMeeting(meeting.getRoom(),
                    meetingTabletDTO,
                    false);
            // only case when we should have a CheckOut if the meeting was already CheckedIn or Cancelled , meaning CHECKED_OUT will replace CANCELLED in db
            if (graphOK && (meeting.getCheckStatus().equals(EnumMeetingStatus.CHECKED_IN) || meeting.getCheckStatus().equals(EnumMeetingStatus.CANCELLED) )) {
                meeting.setCheckStatus(EnumMeetingStatus.CHECKED_OUT);
                meeting.setModifiedAt((new Date()).getTime() / 1000);
                this.meetingService.save(meeting);
            }
        }
    }

    /***
     * Manage checkin from received payload
     *
     * @param payload
     */
    public void checkin(String payload) {
        MeetingDTO meetingDTO = new Gson().fromJson(payload, MeetingDTO.class);
        Meeting meeting = this.meetingService.findMeeting(meetingDTO.getId());

        if (Objects.nonNull(meeting) && meeting.getCheckStatus().equals(EnumMeetingStatus.CREATED)) {
            meeting.setCheckStatus(EnumMeetingStatus.CHECKED_IN);
            meeting.setModifiedAt(System.currentTimeMillis() / 1000);
            meetingService.save(meeting);

            List<DeviceDTO> deviceDTOs = deviceService.getTabletAllByEmail(meeting.getRoom())
                    .stream()
                    .filter(device -> EnumDeviceType.TABLET.equals(device.getDeviceType()))
                    .collect(Collectors.toList());

            for (DeviceDTO deviceDTO : deviceDTOs) {
                if (Objects.nonNull(deviceDTO)) {
                    log.info("Calling publishOneDayPlanningTablet after check-in for device {} ", deviceDTO.getUuid());
                    this.orchestreService.publishOneDayPlanningTablet(deviceDTO);
                }
            }

            this.meetingService.sendCheckInEmail(meetingDTO);
        }
    }

    /***
     * Manage noshow form received payload
     *
     * @param payload
     */
    public void noshow(String payload) {
        MeetingDTO meetingTabletDTO = new Gson().fromJson(payload, MeetingDTO.class);
        Long floorId = poiService.getPoiFloorId(meetingTabletDTO.getPoiName());
        if (this.deviceService.getConfigStringValue(KEY_TABLET)) {
            Meeting meeting = this.meetingService.findMeeting(meetingTabletDTO.getId());

            if (Objects.nonNull(meeting)) {
                int tabletNumber = this.deviceService.getTabletNumber(meetingTabletDTO.getPoiName(), floorId);
                if (Boolean.TRUE.equals(meeting.countNoShowAttempt(tabletNumber))) {
                    boolean graphOK = this.meetingService.freeRoomForMeeting(meeting.getRoom(),
                            meetingTabletDTO,
                            true);
                    // only case when we should have a no-show is if the meeting was on CREATED or CANCELLED
                    // status before.
                    if (graphOK && (meeting.getCheckStatus().equals(EnumMeetingStatus.CREATED) || meeting.getCheckStatus().equals(EnumMeetingStatus.CANCELLED))) {
                        meeting.setCheckStatus(EnumMeetingStatus.NOSHOW);
                        meeting.setModifiedAt((new Date()).getTime() / 1000);
                        this.meetingService.save(meeting);
                        log.info("Noshow");
                    }
                }
            }
            // if we don't find an existing meeting we don't do any action for no-show
        }

    }

    /***
     * Manage trigger from received payload
     *
     * @param payload
     */
    public void triggerReminder(String payload) {
        deviceTokenService.initialize();

        MeetingDTO meetingTabletDTO = new Gson().fromJson(payload, MeetingDTO.class);
        Poi poi = this.poiService.getPoiByNameAndFloorId(meetingTabletDTO.getPoiName(),meetingTabletDTO.getFloorId());
        Meeting meeting = this.meetingService.findMeeting(meetingTabletDTO.getId());

        if (Objects.nonNull(poi) && Objects.nonNull(meeting)) {
            // Skip if check-in is disabled
            boolean isCheckInDisabled = "false".equalsIgnoreCase(poi.getAttributes().get("checkIn"));
            if (isCheckInDisabled) {
                log.info("Check-in is disabled for POI: {}. Skipping reminder.", poi.getName());
                return;
            }

        String encodedEventId = meetingTabletDTO.getId();
        // Room email from POI attributes
        String roomEmail = null;
        try {
            Map<String, String> attrs = poi.getAttributes();
            if (attrs != null) {
                roomEmail = attrs.get("conf_room_mail");
                if (roomEmail != null && roomEmail.trim().isEmpty()) {
                    roomEmail = null; // normalize blank to null
                }
            }
        } catch (Exception e) {
            log.error("Failed to read room email (conf_room_mail) from POI attributes for poi={}, error={}",
                    poi.getName(), e.getMessage(), e);
        }
 
        // ---- Graph check against ROOM  ----
        try {
            if (roomEmail != null && graphHelper.shouldSkipReminderForRoom( roomEmail,  encodedEventId)) {
                log.info("Skipping reminder: ROOM indicates CANCELLED/404. roomEmail={}, eventId={}", roomEmail, encodedEventId);
                return;
            }
        } catch (Exception e) {
            log.error("Error during ROOM Graph verification. eventId={}, error={}", encodedEventId, e.getMessage(), e);
        }
            Boolean checkInReminder = this.poiService.getCheckInReminder(poi);
            // Check if the POI can send a notification and haven't already send an alert
            // only case when we should have a Trigger_Notification if the meeting was
            // already CREATED
            if (Boolean.FALSE.equals(meeting.getAlertCheckIn()) && Boolean.TRUE.equals(checkInReminder)
                    && meeting.getCheckStatus().equals(EnumMeetingStatus.CREATED)) {
                try {
                    int durationCheckIn = this.meetingService.getDurationCheckIn(poi);
                    this.meetingService.sendEmailBeforeMeeting(meetingTabletDTO, durationCheckIn, poi);
                    meeting.setCheckStatus(EnumMeetingStatus.CREATED);
                    meeting.setModifiedAt((new Date()).getTime() / 1000);
                    meeting.setAlertCheckIn(true);
                    this.meetingService.save(meeting);
                    log.info("Trigger");

                    String meetingTitle = poi.getTitleEn();

                    String meetingTime = getCheckInDeadlineTime(meetingTabletDTO.getFrom(),
                            poi.getFloor().getBuilding().getTimezoneJava(), durationCheckIn);

                    String title = "SmartOffice Reminder: CHECK-IN for " + meetingTitle;
                    String body = String.format(
                            "\nPlease don't forget to CHECK-IN via the tablet outside the room for your meeting \"%s\" before %s otherwise the meeting will be removed from the calendar.\n\n"
                                    + "If your meeting finishes early, please remember to CHECK-OUT to free up the room.",
                            meetingTitle, meetingTime);

                    // Fetch all FCM tokens associated with the user's email
                    List<AppRegistrationManagement> devices = deviceTokenService
                            .getAppRegistrationsForUser(meetingTabletDTO.getBooker().getEmail());

                    log.info("Fetched {} devices for user: {}", devices.size(),
                            meetingTabletDTO.getBooker().getEmail());
                    for (AppRegistrationManagement device : devices) {
                        String token = device.getDeviceRegistrationToken();
                        EnumOsType osType = device.getDeviceType();
                        log.info("Sending push notification to device with token: {}, OS: {}", token,
                                osType);

                        pushNotificationService.sendPushNotification(token, title, body, osType);
                    }

                } catch (Exception e) {
                    log.error("error during trigger");
                }
            }
        }
    }


/**
 * Sends a push notification reminder to the user to check-in for their scheduled meeting.
 * Validates the associated Point of Interest (POI) and ensures check-in is enabled.
 * The reminder is only sent if the meeting is in CREATED status and no alert has been pushed yet.
 *
 * @param payload JSON string containing meeting details.
 */
    public void pushAlertReminder(String payload) {
        try {
            MeetingDTO meetingDTO = new Gson().fromJson(payload, MeetingDTO.class);
            Poi poi = poiService.getPoiByNameAndFloorId(meetingDTO.getPoiName(),meetingDTO.getFloorId());
            if (poi == null) {
                log.warn("POI not found: {}", meetingDTO.getPoiName());
                return;
            }

            // Skip if check-in is disabled
            boolean isCheckInDisabled = "false".equalsIgnoreCase(poi.getAttributes().get("checkIn"));
            if (isCheckInDisabled) {
                log.info("Check-in is disabled for POI: {}. Skipping push alert.", poi.getName());
                return;
            }

            Meeting meeting = meetingService.findMeeting(meetingDTO.getId());
            if (meeting == null) {
                log.warn("Meeting not found or created.");
                return;
            }

            // Only proceed if meeting is still in CREATED status and pushAlert is false
            if (EnumMeetingStatus.CREATED.equals(meeting.getCheckStatus())
                    && Boolean.FALSE.equals(meeting.getPushAlert())) {

                // Update meeting to avoid duplicate reminders
                meeting.setPushAlert(true);
                meeting.setModifiedAt(System.currentTimeMillis() / 1000);
                meetingService.save(meeting);

                // Compose the push notification
                String meetingTitle = poi.getTitleEn();
                int durationCheckIn = meetingService.getDurationCheckIn(poi);
                String meetingTime = getCheckInDeadlineTime(meetingDTO.getFrom(),
                        poi.getFloor().getBuilding().getTimezoneJava(), durationCheckIn);

                String title = "SmartOffice Reminder: CHECK-IN for " + meetingTitle;
                String body = String.format(
                        "\nPlease don't forget to CHECK-IN via the tablet outside the room for your meeting \"%s\" before %s otherwise the meeting will be removed from the calendar.\n\n"
                                + "If your meeting finishes early, please remember to CHECK-OUT to free up the room.",
                        meetingTitle, meetingTime);

                List<AppRegistrationManagement> devices = deviceTokenService
                        .getAppRegistrationsForUser(meetingDTO.getBooker().getEmail());

                if (devices.isEmpty()) {
                    log.warn("No device registrations found for user: {}", meetingDTO.getBooker().getEmail());
                } else {
                    devices.forEach(device -> pushNotificationService.sendPushNotification(
                            device.getDeviceRegistrationToken(), title, body, device.getDeviceType()));
                }

                log.info("Push reminder sent to {}", meetingDTO.getBooker().getEmail());
            }

        } catch (Exception e) {
            log.error("Error in pushAlertReminder", e);
        }
    }

    private String getCheckInDeadlineTime(Long meetingStartTimestamp, String timeZoneId, int offsetMinutes) {
        MutableDateTime time = new MutableDateTime(DateTimeZone.UTC);
        time.setMillis((meetingStartTimestamp * SECONDS_TO_MILLISECONDS) + (offsetMinutes * MINUTES_TO_SECONDS * SECONDS_TO_MILLISECONDS));
        time.setZoneRetainFields(DateTimeZone.forID(timeZoneId));

        return String.format("%02d:%02d", time.getHourOfDay(), time.getMinuteOfHour());
    }

    /**
     * Manage the update of the status of a tablet
     *
     * @param uuid The uuid of the tablet
     */
    public void updateStatus(String uuid) {
        this.deviceService.updateStatus(uuid, EnumDeviceStatus.ACTIVE);
    }

    /**
     * Manage cancellation from received payload from Azure ServiceBus
     * (No email notification will be sent)
     *
     * @param payload
     */
    public void cancel(String payload) {
        MeetingDTO meetingTabletDTO = new Gson().fromJson(payload,MeetingDTO.class);
        // Fetch meeting directly by ID
        Meeting meeting = meetingService.findMeeting(meetingTabletDTO.getId());

        if (Objects.nonNull(meeting)) {
            boolean graphOK = freeRoomForCancel(meeting.getRoom(),
                    meetingTabletDTO);
            if (graphOK && meeting.getCheckStatus().equals(EnumMeetingStatus.CREATED)) {
                log.info("Meeting is in CREATED state. Proceeding to CANCEL.");
                meeting.setCheckStatus(EnumMeetingStatus.CANCELLED);
                meeting.setModifiedAt((new Date()).getTime() / 1000);
                meetingService.save(meeting);
            }
        }

    }

    /**
    * Attempts to cancel a meeting by deleting the corresponding event from the calendar.
    *
    * @param poiEmail   The email address of the point of interest (e.g., meeting room or organizer).
    * @param meetingDTO The meeting data transfer object containing meeting details.
    * @return true if the event was successfully deleted; false otherwise.
    */
    public boolean freeRoomForCancel(String poiEmail, MeetingDTO meetingDTO) {
        // Need to decode the id of the appointment from the Meeting information
        String meetingId = null;
        try {
            meetingId = URLDecoder.decode(meetingDTO.getId(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.warn(e.getMessage());
            return false;
        }

        // Delete an event
        try {
            graphHelper.deleteEventById(poiEmail, meetingId);
            log.info("event {} deleted.", meetingId);
            return true;
        } catch (ClientException e) {
            log.warn(e.getMessage());
            return false;
        }
    }

}
