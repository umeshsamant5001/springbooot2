package com.capgemini.tablet.back.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;
import org.springframework.security.config.Customizer;

import com.capgemini.tablet.back.security.jwt.CustomTestFilter;

import tech.jhipster.config.JHipsterProperties;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Import(SecurityProblemSupport.class)
public class SecurityConfiguration {

    private final JHipsterProperties jHipsterProperties;
    private final SecurityProblemSupport problemSupport;

    @Autowired
    CustomTestFilter customTestFilter;

    public SecurityConfiguration(
        JHipsterProperties jHipsterProperties,
        SecurityProblemSupport problemSupport
    ) {
        this.problemSupport = problemSupport;
        this.jHipsterProperties = jHipsterProperties;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        final String API_CSP = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'";
        http
            .csrf(csrf -> csrf
                .ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**"))
                .disable()
            )
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint(problemSupport)
                .accessDeniedHandler(problemSupport)
            )
            .sessionManagement(sm -> sm
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .authorizeRequests(auth -> auth
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .antMatchers(
                    "/actuator/health/**",
                    "/actuator/info",
                    "/management/health/**",
                    "/management/info",
                    "/v3/api-docs/**",
                    "/swagger-ui/**",
                    "/swagger-ui.html",
                    "/api/device/certificate",
                    "/api/building/publishOpeningHour",
                    "/api/poi/publishPoiInformation",
                    "/api/meeting/email-template-check-in",
                    "/api/meeting/email-alert-template",
                    "/api/meeting/email-template-check-out",
                    "/api/meeting/email-template-no-show"
                ).permitAll()
                .antMatchers("/api/**").authenticated()
                .anyRequest().denyAll()
            )
            .headers(headers -> headers
                .contentSecurityPolicy(csp -> csp.policyDirectives(API_CSP))   // CSP
                .frameOptions(frame -> frame.deny())                           // X-Frame-Options: DENY
                .contentTypeOptions(Customizer.withDefaults())                 // X-Content-Type-Options: nosniff
                .referrerPolicy(ref -> ref.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.NO_REFERRER))
            )
            .addFilterAfter(customTestFilter, BasicAuthenticationFilter.class);
        return http.build();
    }           
}
