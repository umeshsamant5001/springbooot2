package com.capgemini.tablet.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import com.capgemini.tablet.back.model.enumeration.EnumErrorLoggingType;
import com.capgemini.tablet.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@Entity
@Table(name = "error_logging_tablet", uniqueConstraints = { @UniqueConstraint(columnNames = { "id"}) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class ErrorLoggingTablet {

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ErrorLoggingTablet_Generator")
	@SequenceGenerator(name = "ErrorLoggingTablet_Generator", sequenceName = "ErrorLoggingTablet_Sequence")
	private Long id;
    
    @Column(name = "uuid")
    private String uuid;

    @Lob
    @Column(name = "description")
	private String description;

    @Column(name = "error_logging_type")
	private EnumErrorLoggingType errorLoggingType;

    @Column(name = "date")
	private Long date;

}
