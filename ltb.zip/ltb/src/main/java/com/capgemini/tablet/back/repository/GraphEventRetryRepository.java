package com.capgemini.tablet.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.GraphEventRetry;

@Repository
public interface GraphEventRetryRepository
        extends JpaRepository<GraphEventRetry, String> {
}
