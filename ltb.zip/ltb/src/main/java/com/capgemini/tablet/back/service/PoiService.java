package com.capgemini.tablet.back.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.mapper.PoiMapper;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.PoiDTO;
import com.capgemini.tablet.back.model.SensorDataDTO;
import com.capgemini.tablet.back.model.exception.PoiException;
import com.capgemini.tablet.back.repository.PoiRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiService {

    private static final String CHECKIN = "checkIn";

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private SensorDataService sensorDataService;

    @Autowired
    private DeviceService deviceService;

    public Poi findByName(String name) {
        return this.poiRepository.findByName(name);
    }

    /**
     * Retrieves a Poi by its name and floorId.
     *
     * @param name the technical name of the Poi
     * @param floorId the ID of the floor
     * @return the Poi if found, otherwise null
     */
    public Poi getPoiByNameAndFloorId(String name, Long floorId) {
        //Optional<Poi> poiOptional = poiRepository.findByNameAndFloorId(name,floorId);
        //return poiOptional.orElse(null);

        
        List<Poi> pois = poiRepository.findByNameAndFloorId(name, floorId);

            if (pois.isEmpty()) {
                return null;
            }

            if (pois.size() > 1) {
                log.warn("Multiple POIs found for name {} and floorId {}", name, floorId);
            }

            return pois.get(0);  // pick first safely
    }


    public String findTitleEnByPoiName(String name) {
        return poiRepository.findTitleEnByPoiName(name);
    }

    public Long getFloorIdByPoiName(String name) {
        return poiRepository.findTitleByPoiName(name);
    }

    public Poi findById(Long id) {
        return this.poiRepository.findById(id).orElse(null);
    }

    public Boolean getPoiCheckin(Poi poi) {
        return poi.getAttributes().containsKey(CHECKIN) && "False".equalsIgnoreCase(poi.getAttributes().get(CHECKIN))
                ? Boolean.FALSE
                : Boolean.TRUE;
    }

    public Boolean getCheckInReminder(Poi poi) {
        return Objects.nonNull(poi.getFloor())
                && Objects.nonNull(poi.getFloor().getBuilding())
                && Objects.nonNull(poi.getFloor().getBuilding().getAttributes())
                && poi.getFloor().getBuilding().getAttributes().containsKey("checkin.alert.building")
                        ? Boolean.parseBoolean(
                                poi.getFloor().getBuilding().getAttributes().get("checkin.alert.building"))
                        : Boolean.TRUE;
    }

        /***
     * Function to get PoiDTO from a device
     *
     * @param deviceDTO
     * @return
     */
    public PoiDTO getPoiFromDevice(DeviceDTO deviceDTO) throws PoiException {

        if (Objects.isNull(deviceDTO.getPoiName()) || Objects.isNull(deviceDTO.getFloor()) ) {
            String message = String.format("No poi affect to device %s", deviceDTO.getUuid());
            log.warn(message);
            throw new PoiException(message);
        }

        Poi poi = getPoiByNameAndFloorId(deviceDTO.getPoiName(),deviceDTO.getFloor().getId());
        if (Objects.isNull(poi)) {
            String message = String.format("No poi found for %s", deviceDTO.getPoiName());
            log.warn(message);
            throw new PoiException(message);
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, "en"); // TODO THD language

        List<Device> deviceList = deviceService.findAllByPoiName(poi.getName());
        addSensorDataToPoi(Arrays.asList(poiDTO), deviceList);

        return poiDTO;
    }

    public Long getPoiFloorId(String poiName) {
        Long floorId = poiRepository.findFloorIdByPoiName(poiName);
        if (floorId == null) {
            throw new EntityNotFoundException("No POI found with name: " + poiName);
        }
        return floorId;
    }

    public void addSensorDataToPoi(List<PoiDTO> poisDTO, List<Device> devices) {
        // Get the SensorDataDTO for all the Poi (by their name)
        Map<String, SensorDataDTO> mapSensorData = this.sensorDataService.getPoiSensorData(poisDTO, devices);

        // Put the SensorDataDTO on the corresponding PoiDTO
        poisDTO.stream()
                .forEach(poiDTO -> {
                    String poiName = poiDTO.getName();

                    if (mapSensorData.containsKey(poiName)) {
                        poiDTO.setSensorData(mapSensorData.get(poiName));
                    }
                });
    }

}
