package com.capgemini.tablet.back.model.enumeration;

public enum EmailCategory {

    TRASH_FULL("Trash is full"),
    VIDEO_DEVICE_NOT_WORKING("Video device is not working"),
    CABLING_ISSUE("Cabling issue"),
    OTHER_ISSUE("Other issue");

    private final String description;

    EmailCategory(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }


}
