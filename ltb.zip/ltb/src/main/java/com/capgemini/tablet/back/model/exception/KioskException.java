package com.capgemini.tablet.back.model.exception;

public class KioskException extends Exception {

    private static final long serialVersionUID = 3154414080730702568L;

    public KioskException(String message) {
        super(message);
    }
}
