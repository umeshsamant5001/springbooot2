package com.capgemini.tablet.back.model.enumeration;

public enum TemperatureUnit {
    CELSIUS, FAHRENHEIT;
}
