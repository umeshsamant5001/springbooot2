package com.capgemini.tablet.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.capgemini.tablet.back.model.DeclareIssueDetails;
import com.capgemini.tablet.back.model.DeclareIssueDetailsDTO;

@Repository
public interface DeclareIssueDetailsRepository extends JpaRepository<DeclareIssueDetails, Long> {

        @Query("SELECT new com.capgemini.tablet.back.model.DeclareIssueDetailsDTO(did.country.id, did.declareIssue.id, di.issueName) "
                        +
                        "FROM DeclareIssueDetails did " +
                        "JOIN did.declareIssue di " +
                        "JOIN City c ON c.country.id = did.country.id " +
                        "JOIN Site s ON s.city.id = c.id " +
                        "JOIN Building b ON b.site.id = s.id " +
                        "WHERE b.id = :buildingId")
        List<DeclareIssueDetailsDTO> findDeclareIssuesByCountryByBuildingId(@Param("buildingId") Long buildingId);

        @Query(value = "SELECT did.email_id FROM declare_issue_details did JOIN declare_issue di ON di.id = did.declare_issue_id JOIN city c ON c.country_id = did.country_id JOIN site s ON s.city_id = c.id JOIN building b ON b.site_id = s.id WHERE b.id = :buildingId AND di.issue_name = :issueDescription", nativeQuery = true)
        String findByBuildingIdAndIssueDesc(@Param("buildingId") Long buildingId,
                        @Param("issueDescription") String issueDescription);

       @Query(value =
                "SELECT " +
                " b.id AS building_id, " +
                " b.title_en AS building_name, " +
                " p.title_en AS meeting_room_name, " +
                " p.name AS poi_name, " +
                " pa.att_value AS meeting_room_email, " +
                " b.timezone_java AS timezone_java " +     
                "FROM poi p " +
                "JOIN floor f ON f.id = p.floor_id " +
                "JOIN building b ON b.id = f.building_id " +
                "LEFT JOIN poi_attributes pa ON pa.poi_id = p.id " +
                " AND pa.att_key = 'conf_room_mail' " +
                "WHERE p.name = :poiName",
                nativeQuery = true)
        List<Object[]> fetchEmailDisplayRowByPoiName(@Param("poiName") String poiName);

}
