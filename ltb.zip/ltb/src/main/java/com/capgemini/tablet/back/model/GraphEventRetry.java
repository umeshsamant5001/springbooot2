package com.capgemini.tablet.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.EnumType;


import com.capgemini.tablet.back.model.enumeration.RetryStatus;

import lombok.Data;

@Entity
@Table(name = "graph_event_retry")
@Data
public class GraphEventRetry {

    @Id
    @Column(name = "event_id", nullable = false, length = 512)
    private String eventId;

    @Column(name = "room_email", nullable = false)
    private String roomEmail;

    @Column(name = "poi_name")
    private String poiName;

    @Column(name = "created_ts", nullable = false)
    private Long createdTs;
    
    @Column(name = "processed_ts")
    private Long processedTs;

    @Enumerated(EnumType.STRING)
    @Column(name = "retry_status", nullable = false)
    private RetryStatus retryStatus;
}
