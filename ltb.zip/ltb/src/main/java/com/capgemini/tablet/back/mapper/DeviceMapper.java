package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.FloorDTO;

@Mapper(config = DtoMapperConfig.class)
public interface DeviceMapper {

    DeviceMapper INSTANCE = Mappers.getMapper(DeviceMapper.class);

    @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" })
    DeviceDTO deviceToDeviceDTO(Device in, @Context String language);

    Device deviceDTOToDevice(DeviceDTO in);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }

}