package com.capgemini.tablet.back.model.exception;

public class GraphException extends Exception {

	private static final long serialVersionUID = -2801267992145736978L;

	public GraphException() {
        super();
    }
    public GraphException(String s) {
        super(s);
    }
}
