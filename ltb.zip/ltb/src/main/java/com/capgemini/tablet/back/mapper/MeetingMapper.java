package com.capgemini.tablet.back.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.mapstruct.Mapping;
import com.capgemini.tablet.back.model.Meeting;
import com.capgemini.tablet.back.model.MeetingDTO;

@Mapper
public interface MeetingMapper {

    MeetingMapper INSTANCE = Mappers.getMapper(MeetingMapper.class);

    @Mapping(target="booker", ignore=true)
    @Mapping(target="status", ignore=true)
    @Mapping(target="subject", ignore=true)
    MeetingDTO meetingToMeetingDTO(Meeting in);

    @Mapping(target="noshowCounter", ignore=true)
    @Mapping(target="alertCheckIn", ignore=true)
    Meeting meetingDTOToMeeting(MeetingDTO in);

    List<MeetingDTO> meetingToMeetingDTO(List<Meeting> meetingCreated);
    
}
