package com.capgemini.tablet.back.service;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.model.TransactionLoggingTablet;
import com.capgemini.tablet.back.repository.TransactionLoggingTabletRepository;

@Service
public class TransactionLoggingService {

    private static final Logger log = LoggerFactory.getLogger(TransactionLoggingService.class);

    @Autowired
    private TransactionLoggingTabletRepository transactionLoggingTabletRepository;

    public void saveTransactionLogging(String body) {
        // Log the received body
        log.info("Received body: " + body);
    
        // Parse the JSON object from the body
        JSONObject jsonObject = new JSONObject(body);
        String subject = jsonObject.getString("subject");
    
        // Create and populate the TransactionLoggingTablet object
        TransactionLoggingTablet transactionLoggingTablet = new TransactionLoggingTablet();
        transactionLoggingTablet.setDate(System.currentTimeMillis() / 1000);
        transactionLoggingTablet.setPayload(jsonObject.toString());
        transactionLoggingTablet.setSubject(subject);
    
        // Save the transaction logging tablet
        transactionLoggingTabletRepository.save(transactionLoggingTablet);
    }
    
}
