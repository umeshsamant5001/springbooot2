package com.capgemini.tablet.back.controller;

import java.util.Objects;
import javax.validation.Valid;
import com.capgemini.tablet.back.model.ErrorLoggingTablet;
import com.capgemini.tablet.back.model.ErrorLoggingTabletCreateRequestDTO;
import com.capgemini.tablet.back.model.ErrorLoggingTabletDTO;
import com.capgemini.tablet.back.model.enumeration.EnumErrorLoggingType;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.tablet.back.mapper.ErrorLoggingTabletMapper;
import com.capgemini.tablet.back.service.ErrorLoggingTabletService;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = ErrorLoggingTabletController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ErrorLoggingTabletController {

	static final String ROOT_API = "api/errorloggingtablet";

	@Autowired
	private ErrorLoggingTabletService errorLoggingTabletService;
	
    /**
     * API to create a new error log entry from a tablet.
     *
     * @param errorLoggingTabletDTO the error log data sent from the tablet
     * @param language the preferred language for the response (optional, defaults to "en")
     * @return the saved error log as a DTO, or an appropriate error response
     */
	@PostMapping
	public ResponseEntity<ErrorLoggingTabletDTO> createErrorLoggingTabletTest(
            @Valid @RequestBody ErrorLoggingTabletCreateRequestDTO errorLoggingTabletCreateRequestDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        String validatedUuid = new String(errorLoggingTabletCreateRequestDTO.getUuid());
        String validatedDescription = new String(errorLoggingTabletCreateRequestDTO.getDescription());
        EnumErrorLoggingType validatedErrorLoggingType = EnumErrorLoggingType
                .valueOf(new String(errorLoggingTabletCreateRequestDTO.getErrorLoggingType().name()));
        Long validatedDate = Long.valueOf(String.valueOf(errorLoggingTabletCreateRequestDTO.getDate()));

        ErrorLoggingTablet errorLoggingTablet;
        try {
            errorLoggingTablet = this.errorLoggingTabletService.save(validatedUuid, validatedDescription,
                    validatedErrorLoggingType, validatedDate);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }


        if(Objects.isNull(errorLoggingTablet)){

			return ResponseEntity.internalServerError().build();
		}

        ErrorLoggingTabletDTO newErrorLoggingDTO = ErrorLoggingTabletMapper.INSTANCE.errorloggingTabletToErrorLoggingTabletDTO(errorLoggingTablet);
		return ResponseEntity.ok(newErrorLoggingDTO);
	}

}