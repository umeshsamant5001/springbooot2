package com.capgemini.tablet.back.model;

import lombok.Data;

@Data
public class DeclareIssueEmailDTO {
    private String poiName;
    private String tabletUuid;
    private String issueDescription;
}
