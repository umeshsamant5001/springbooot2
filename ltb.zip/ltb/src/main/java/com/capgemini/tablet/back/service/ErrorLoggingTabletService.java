package com.capgemini.tablet.back.service;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.tablet.back.model.ErrorLoggingTablet;

import com.capgemini.tablet.back.repository.ErrorLoggingTabletRepository;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class ErrorLoggingTabletService {

	@Autowired
	private ErrorLoggingTabletRepository errorLoggingTabletRepository;

	public ErrorLoggingTablet save(String uuid, String description,
            com.capgemini.tablet.back.model.enumeration.EnumErrorLoggingType errorLoggingType, Long date) {
        String sanitizedUuid = sanitizeTextField(uuid, "uuid", 255);
        String sanitizedDescription = sanitizeTextField(description, "description", 10000);
        if (Objects.isNull(errorLoggingType)) {
            throw new IllegalArgumentException("error logging type is required");
        }
        Long sanitizedDate = sanitizeDate(date);

        ErrorLoggingTablet errorLoggingTablet = new ErrorLoggingTablet();
        errorLoggingTablet.setUuid(new String(sanitizedUuid));
        errorLoggingTablet.setDescription(new String(sanitizedDescription));
        errorLoggingTablet.setErrorLoggingType(errorLoggingType);
        errorLoggingTablet.setDate(Long.valueOf(String.valueOf(sanitizedDate)));

        return this.errorLoggingTabletRepository.save(errorLoggingTablet);
	}


    private String sanitizeTextField(String value, String fieldName, int maxLength) {
        if (Objects.isNull(value)) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
        String candidate = new String(value.trim());
        if (candidate.isEmpty() || candidate.length() > maxLength) {
            throw new IllegalArgumentException("Invalid " + fieldName);
        }
        return new String(candidate);
    }

    private Long sanitizeDate(Long date) {
        if (Objects.isNull(date) || date <= 0L) {
            throw new IllegalArgumentException("Invalid date");
        }
        return Long.valueOf(String.valueOf(date));
    }

}