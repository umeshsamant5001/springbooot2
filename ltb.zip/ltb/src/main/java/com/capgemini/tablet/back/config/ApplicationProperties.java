package com.capgemini.tablet.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * Properties specific to Tablet Back End.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class

    private final Azure azure = new Azure();
    private final SMTP smtp = new SMTP();
    private final Meeting meeting = new Meeting();
    private final Tablet tablet = new Tablet();
    private final Incident incident = new Incident();
    private final PushNotificationApns pushNotificationApns = new PushNotificationApns();

    @Data
    public static class Azure {
        private String tenantId;
        private final KeyVault keyVault = new KeyVault();
        private final GraphApi graphApi = new GraphApi();
        private final GraphApiSendEmail graphApiSendEmail = new GraphApiSendEmail();
        private final PushNotificationApns pushNotificationApns = new PushNotificationApns();

        @Data
        public static class KeyVault {
            private String url;
            private String clientId;
            private String clientSecret;
            private String certificateName;
        }

        @Data
        public static class GraphApi {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;
            private String notificationUrl;
        }

        @Data
        public static class GraphApiSendEmail {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;   
         }
    }

    @Data
    public static class SMTP {
        private String auth;
        private String host;
        private String port;
        private String state;
        private String hostUrl;
        private String portNum;
        private String username;
        private String password;
        private String email;
    }

    @Data
    public static class Incident {
        private String body;
    }

    @Data
    public static class Meeting {
        private final CheckInTrigger checkInTrigger = new CheckInTrigger();
        private final NoShow noShow = new NoShow();
        private final CheckOut checkOut = new CheckOut();
        private final CheckIn checkIn = new CheckIn();

        @Data
        public static class CheckInTrigger {
            private String subject;
            private String body;
            private String template;
            private String serviceCentralUrl;
        }

        @Data
        public static class CheckIn {
            private String subject;
            private String body;
            private String template;
            private String serviceCentralUrl;
        }

        @Data
        public static class NoShow {
            private String subject;
            private String body;
            private String template;
            private String serviceCentralUrl;
        }

        @Data
        public static class CheckOut {
            private String subject;
            private String template;
            private String serviceCentralUrl;
        }
    }

    @Data
    public static class Tablet {
        private String key;
        private final Status status = new Status();

        @Data
        public static class Status {
            private String cron;
            private String tz;
            private Long age;
        }
    }

    @Data
    public static class PushNotificationApns {
        private String teamId;
        private String keyId;
        private String base64PrivateKey;
        private String apnsHost;
        private String apnsTopic;
    }
}
