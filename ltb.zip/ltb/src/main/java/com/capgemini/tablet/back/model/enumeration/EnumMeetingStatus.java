package com.capgemini.tablet.back.model.enumeration;

public enum EnumMeetingStatus {
	CREATED, CHECKED_IN, CHECKED_OUT, NOSHOW, CANCELLED;
}
