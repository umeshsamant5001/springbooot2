package com.capgemini.tablet.back.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import lombok.Data;

@Data
@Entity
@Table(name = "declare_issue")
public class DeclareIssue {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DeclareIssue_Generator")
    @SequenceGenerator(name = "DeclareIssue_Generator", sequenceName = "DeclareIssue_Sequence")
    private Long id;

    @Column(name = "issue_name", nullable = false)
    private String issueName;

    @OneToMany(mappedBy = "declareIssue", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    private List<DeclareIssueDetails> declareIssueDetails;
}