package com.capgemini.tablet.back.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.Poi;

@Repository
public interface PoiRepository extends JpaRepository<Poi, Long> {

    Poi findByName(@Param("name") String name);

    //Optional<Poi> findByNameAndFloorId(String name, Long floorId);
    List<Poi> findByNameAndFloorId(String name, Long floorId);
    List<Poi> findAllByFloorId(Long floorId);
	List<Poi> findByNameIn(@Param("names") List<String> names);

    @Query("SELECT poi " +
           "FROM Poi poi " +
           "JOIN poi.attributes attributes " +
           "WHERE INDEX(attributes) = 'conf_room_mail' " +
           "AND attributes = :email")
	Poi findByEmail(@Param("email") String email);

    @Query(value = "SELECT floor_id FROM poi WHERE name = :poiName", nativeQuery = true)
    Long findFloorIdByPoiName(@Param("poiName") String poiName);

    @Query(value = "SELECT title_en FROM poi WHERE name = :name", nativeQuery = true)
    String findTitleEnByPoiName(@Param("name") String name);

    @Query(value = "SELECT floor_id FROM poi WHERE title_en = :name", nativeQuery = true)
    Long findTitleByPoiName(@Param("name") String name);

}
