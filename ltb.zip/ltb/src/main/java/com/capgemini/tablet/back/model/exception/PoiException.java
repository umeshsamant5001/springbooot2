package com.capgemini.tablet.back.model.exception;

public class PoiException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 3154414080730702568L;

	public PoiException(String message) {
		super(404, ErrorCodes.POI_NOT_FOUND, message);
	}

}
