package com.capgemini.tablet.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import lombok.extern.slf4j.Slf4j;

/**
 * Class use for to encrypt the password for mobile Auth
 * 
 * @author alcarpen
 *
 */
@Slf4j
public class MobileAuthCrypto {

	private MobileAuthCrypto() {

	}

    /**
	 * Generate passcode
	 * 
	 * @param length of the password
	 * @return
	 */ 
    private static final String CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final SecureRandom RND = new SecureRandom();

    public static String generatePasscode(int length) {
        if (length <= 0) throw new IllegalArgumentException("length must be > 0");

        return RND.ints(length, 0, CHARS.length())
                   .map(CHARS::charAt) // char -> int (code point)
                   .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                   .toString();
			   
    }


	/**
	 * 
	 * 
	 * @param toEncode
	 * @return
	 */
	public static String encodeTo64(String toEncode) {
		String returnValue = null;
		if (toEncode != null) {
			returnValue = new String(Base64.encodeBase64(toEncode.getBytes()));
		}
		return returnValue;
	}

	public static String decodeFrom64(String encodedData) {
		return new String(Base64.decodeBase64(encodedData.getBytes()));
	}

	/**
	 * Encrypth the plaintext with the passcode
	 * 
	 * @param plainText
	 * @param passCode
	 * @return
	 */
	public static String openSSLEncrypt(String plainText, String passCode) {
		// generate salt
		byte[] salt = new byte[8];
		SecureRandom secureRandom = new SecureRandom();
		secureRandom.nextBytes(salt);

		BytePair pair = MobileAuthCrypto.deriveKeyAndIV(passCode, salt);
		byte[] key = pair.getKey();
		byte[] iv = pair.getIv();

		// encrypt bytes
		byte[] encryptedBytes = MobileAuthCrypto.encryptStringToBytesAes(plainText, key, iv);
		// add salt as first 8 bytes
		byte[] encryptedBytesWithSalt = new byte[salt.length + encryptedBytes.length + 8];

		System.arraycopy("Salted__".getBytes(StandardCharsets.US_ASCII), 0, encryptedBytesWithSalt, 0, 8);
		System.arraycopy(salt, 0, encryptedBytesWithSalt, 8, salt.length);
		System.arraycopy(encryptedBytes, 0, encryptedBytesWithSalt, salt.length + 8, encryptedBytes.length);

		// base64 encode
		return Base64.encodeBase64String(encryptedBytesWithSalt);
	}

	/**
	 * Decrypted the input with the passphrase
	 * 
	 * @param encrypted
	 * @param passphrase
	 * @return
	 */
	public static String openSSLDecrypt(String encrypted, String passphrase) {

		// base 64 decode
		byte[] encryptedBytesWithSalt = Base64.decodeBase64(encrypted);

		// extract salt (first 8 bytes of encrypted)
		byte[] salt = new byte[8];
		byte[] encryptedBytes = new byte[encryptedBytesWithSalt.length - salt.length - 8];

		System.arraycopy(encryptedBytesWithSalt, 8, salt, 0, salt.length);
		System.arraycopy(encryptedBytesWithSalt, salt.length + 8, encryptedBytes, 0, encryptedBytes.length);

		// get key and iv
		BytePair pair = MobileAuthCrypto.deriveKeyAndIV(passphrase, salt);
		byte[] key = pair.getKey();
		byte[] iv = pair.getIv();

		return MobileAuthCrypto.decryptStringFromBytesAes(encryptedBytes, key, iv);
	}

	/**
	 * 
	 * 
	 * @param passphrase
	 * @param salt
	 * @param key output
	 * @param iv output
	 */
	private static BytePair deriveKeyAndIV(String passphrase, byte[] salt) {
		// generate key and iv
		List<Byte> concatenatedHashes = new ArrayList<>(48);

		byte[] password;
		MessageDigest md5 = null;

		byte[] key = new byte[32];
		byte[] iv = new byte[16];

		try {
			password = passphrase.getBytes(StandardCharsets.UTF_8);

			byte[] currentHash = new byte[0];

			md5 = MessageDigest.getInstance("MD5");
			Boolean enoughBytesForKey = false;

			while (!enoughBytesForKey) {
				int preHashLength = currentHash.length + password.length + salt.length;
				byte[] preHash = new byte[preHashLength];

				System.arraycopy(currentHash, 0, preHash, 0, currentHash.length);
				System.arraycopy(password, 0, preHash, currentHash.length, password.length);
				System.arraycopy(salt, 0, preHash, currentHash.length + password.length, salt.length);

				currentHash = md5.digest(preHash);
				concatenatedHashes.addAll(MobileAuthCrypto.byteToByte(currentHash));

				if (concatenatedHashes.size() >= 48) {
					enoughBytesForKey = true;
				}
			}

			byte[] concatHashArray = MobileAuthCrypto.byteListToByte(concatenatedHashes);

			key = Arrays.copyOfRange(concatHashArray, 0, 32);

			iv = Arrays.copyOfRange(concatHashArray, 32, 48);

		} catch (NoSuchAlgorithmException e) {
			log.error(e.getLocalizedMessage());
		} finally {
			if (md5 != null) {
				md5.reset();
				md5 = null;
			}
		}

		return new BytePair(key, iv);
	}

	/**
	 * Encrypt the plainText in param
	 * 
	 * @param plainText
	 * @param key
	 * @param iv
	 * @return
	 */
	private static byte[] encryptStringToBytesAes(String plainText, byte[] key, byte[] iv) {

		// Check arguments.
		if (plainText == null || plainText.length() <= 0 || key == null || key.length <= 0 || iv == null
				|| iv.length <= 0) {
			throw new IllegalArgumentException("One or more argument are null");
		}

		// Declare the stream used to encrypt to an in memory
		// array of bytes.
		try (ByteArrayOutputStream memStream = new ByteArrayOutputStream()) {

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
			SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");

			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);

			memStream.write(cipher.doFinal(plainText.getBytes("utf-8")));
			memStream.flush();

			// Return the encrypted bytes from the memory stream.
			return memStream.toByteArray();

		} catch (IOException e) {
			log.error("Error during the writing in the stream ");
		} catch (GeneralSecurityException e) {
			log.error("Error during the encryption of the parameter");
		}

		return "".getBytes();
	}

	/**
	 * Decrypt the cypherText in param
	 * 
	 * @param cipherText
	 * @param key
	 * @param iv
	 * @return
	 */
	private static String decryptStringFromBytesAes(byte[] cipherText, byte[] key, byte[] iv) {
		// Check arguments.
		if (cipherText == null || cipherText.length <= 0 || key == null || key.length <= 0 || iv == null
				|| iv.length <= 0) {
			throw new IllegalArgumentException("One or more argument are null");
		}

		// Declare the String used to hold
		// the decrypted text.
		String plaintext = null;

		try (ByteArrayOutputStream memStream = new ByteArrayOutputStream()) {
			// Create a RijndaelManaged object
			// with the specified key and IV.
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
			SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");

			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
			memStream.write(cipher.doFinal(cipherText));

			memStream.flush();

			plaintext = memStream.toString("utf-8");
		} catch (IOException e) {
			log.error("Error during the writing in the stream ");
		} catch (GeneralSecurityException e) {
			log.error("Error during the encryption of the parameter");
		}

		return plaintext;
	}

	private static List<Byte> byteToByte(byte[] input) {
		List<Byte> output = new ArrayList<>(input.length);
		for (int cpt = 0; cpt < input.length; cpt++) {
			output.add(cpt, input[cpt]);
		}
		return output;
	}

	private static byte[] byteListToByte(List<Byte> input) {
		byte[] output = new byte[input.size()];
		int i = 0;
		for (Byte cour : input) {
			output[i++] = cour;
		}
		return output;
	}

}