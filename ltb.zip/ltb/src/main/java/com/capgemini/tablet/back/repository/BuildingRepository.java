package com.capgemini.tablet.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

    @Query("SELECT building FROM Building building INNER JOIN building.floors floor WHERE floor.id = :floorId")
    Building findByFloorId(@Param("floorId") Long floorId);

    @Query(value = "SELECT title_en FROM building WHERE id = :id", nativeQuery = true)
    String findTitleEnByBuildingId(@Param("id") Long id);
}
