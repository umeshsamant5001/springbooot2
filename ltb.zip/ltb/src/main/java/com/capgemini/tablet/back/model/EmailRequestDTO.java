package com.capgemini.tablet.back.model;

import com.capgemini.tablet.back.model.enumeration.EmailCategory;

import lombok.Data;

@Data
public class EmailRequestDTO {
    private String poiName;
    private String tabletUuid;
    private EmailCategory emailCategory;
}

