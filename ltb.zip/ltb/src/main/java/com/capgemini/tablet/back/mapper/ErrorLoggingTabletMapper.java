package com.capgemini.tablet.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.capgemini.tablet.back.model.ErrorLoggingTablet;
import com.capgemini.tablet.back.model.ErrorLoggingTabletDTO;

@Mapper(config = DtoMapperConfig.class)
public interface ErrorLoggingTabletMapper {
    
    ErrorLoggingTabletMapper INSTANCE = Mappers.getMapper(ErrorLoggingTabletMapper.class);

    ErrorLoggingTabletDTO errorloggingTabletToErrorLoggingTabletDTO(ErrorLoggingTablet in);

    ErrorLoggingTablet errorloggingTabletDTOToErrorLoggingTablet(ErrorLoggingTabletDTO in);

}
