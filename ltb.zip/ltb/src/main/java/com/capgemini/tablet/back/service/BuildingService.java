package com.capgemini.tablet.back.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.repository.BuildingRepository;

@Service
public class BuildingService {

	@Autowired
	private BuildingRepository buildingRepository;

	public Building findById(Long buildingId) {
		return this.buildingRepository.findById(buildingId).orElse(null);
	}

    public Building findByFloorId(Long floorId) {
        return this.buildingRepository.findByFloorId(floorId);
    }

	public String findTitleEnByBuildingId(Long id) {
        return buildingRepository.findTitleEnByBuildingId(id);
    }

}
