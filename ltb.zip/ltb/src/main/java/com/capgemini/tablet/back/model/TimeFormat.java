package com.capgemini.tablet.back.model;

public enum TimeFormat {
    HOUR_12,HOUR_24 ;
}

