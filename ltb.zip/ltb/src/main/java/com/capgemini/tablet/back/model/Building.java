package com.capgemini.tablet.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import com.capgemini.tablet.back.config.DbConfig;
import com.capgemini.tablet.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "building", indexes = { @Index(name = "IDX_MODIFIED_BUILDING", columnList = "modified_at") })
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Building implements WithTitle {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Building_Generator")
	@SequenceGenerator(name = "Building_Generator", sequenceName = "Building_Sequence")
	private Long id;

	@OneToMany(mappedBy = "building", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    @OrderBy("index ASC")
    private List<Floor> floors = new ArrayList<>();

	@Column(name = "site_id", updatable = false, insertable = false)
	private Long siteId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "site_id", insertable = true)
	@JsonIgnore
	private Site site;

	@Embedded
	private BuildingInformation information;

	@Column(name = "deployed")
	private Boolean deployed = false;

	@Column(name = "secured")
	private Boolean secured = false;

	@Column(name = "timezone_windows")
	private String timezoneWindows;

	@Column(name = "timezone_java")
	private String timezoneJava;

    @Column(name = "title_fr")
    private String titleFr;

    @Column(name = "title_en")
    private String titleEn;

	@Column(name = "modified_at", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime() / 1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;

	@CollectionTable(name = "building_attribute", joinColumns = @JoinColumn(name = "building_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

	@PrePersist
	public void nonNullDefaultValues() {
		if (deployed == null) {
			deployed = Boolean.FALSE;
		}
		if (secured == null) {
			secured = Boolean.FALSE;
		}
	}

	public boolean hasCoordinates() {
		boolean result = false;
		if(Objects.nonNull(this.attributes)) {
			if(Objects.nonNull(this.attributes.get("lat")) && Objects.nonNull(this.attributes.get("lon"))){
				result = true;
			}
		}
		return result;
	}



}
