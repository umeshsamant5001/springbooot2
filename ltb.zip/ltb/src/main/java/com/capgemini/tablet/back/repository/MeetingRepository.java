package com.capgemini.tablet.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.tablet.back.model.Meeting;

@Repository
public interface MeetingRepository extends JpaRepository<Meeting, Long> {

    List<Meeting> findAllByPoiNameAndFloorId(@Param("poiName") String poiName, @Param("floorId") Long floorId);

    public Meeting findById(@Param("id") String id);

    @Query("SELECT meeting FROM Meeting meeting WHERE meeting.poiName = :poiName AND meeting.floorId = :floorId "
            + " AND meeting.from >= :from AND meeting.to <= :to ORDER BY meeting.from")
    List<Meeting> findAllByPoiNameAndFloorIdBetweenFromTo(
            @Param("poiName") String poiName,
            @Param("floorId") Long floorId,
            @Param("from") Long from,
            @Param("to") Long to);
            
    @Query(value = "SELECT COUNT(*) FROM meeting WHERE id = :id",nativeQuery = true)
    long countMeetingById(@Param("id") String id);


    @Procedure(name = "InsertNewMeetingsFromJson")
    public List<Meeting> insertNewMeetingsFromJson(
            @Param("json") String jsonPayload,
            @Param("fromtime") Long from,
            @Param("totime") Long to,
            @Param("poi_name") String poiName);


    @Procedure(name = "InsertSingleMeetingFromJson")
    public List<Meeting> insertSingleMeetingFromJson(
            @Param("json") String jsonPayload);


    @Procedure(name = "UpdateMeetingStatusToCancelled")
    void updateMeetingStatusToCancelled(@Param("meetingId") String meetingId);

}
