package com.capgemini.tablet.back.model;

public enum TemperatureUnit {
    CELSIUS, FAHRENHEIT;
}
