package com.capgemini.tablet.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgemini.tablet.back.model.DeclareIssueBuildingDetails;
import com.capgemini.tablet.back.model.DeclareIssueBuildingDetailsDTO;

public interface DeclareIssueBuildingDetailsRepository extends JpaRepository<DeclareIssueBuildingDetails, Long> {

    @Query("SELECT new com.capgemini.tablet.back.model.DeclareIssueBuildingDetailsDTO(did.buildingId, did.declareIssue.id, di.issueName) "
                        +
                        "FROM DeclareIssueBuildingDetails did " +
                        "JOIN did.declareIssue di " +
                        "WHERE did.buildingId = :buildingId")
        List<DeclareIssueBuildingDetailsDTO> findDeclareIssuesByBuildingId(@Param("buildingId") Long buildingId);

        @Query(value = "SELECT did.email_id FROM declare_issue_building_details did JOIN declare_issue di ON di.id = did.declare_issue_id WHERE  did.building_id = :buildingId AND di.issue_name = :issueDescription", nativeQuery = true)
        String findEmailIdForBuildingAndIssueDesc(@Param("buildingId") Long buildingId,
                        @Param("issueDescription") String issueDescription);

       @Query(value =
                "SELECT " +
                " b.id AS building_id, " +
                " b.title_en AS building_name, " +
                " p.title_en AS meeting_room_name, " +
                " p.name AS poi_name, " +
                " pa.att_value AS meeting_room_email, " +
                " b.timezone_java AS timezone_java " +     
                "FROM poi p " +
                "JOIN floor f ON f.id = p.floor_id " +
                "JOIN building b ON b.id = f.building_id " +
                "LEFT JOIN poi_attributes pa ON pa.poi_id = p.id " +
                " AND pa.att_key = 'conf_room_mail' " +
                "WHERE p.name = :poiName",
                nativeQuery = true)
        List<Object[]> fetchEmailDisplayRowByPoiName(@Param("poiName") String poiName);

}
