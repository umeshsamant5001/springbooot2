package com.capgemini.tablet.back.model;

import com.capgemini.tablet.back.model.enumeration.TemperatureUnit;
import lombok.Data;

@Data
public class BuildingInformationDTO {

    private String address;
    private String city;
    private String country;
    private String phone;
    private String receptionMail;
    private String infoUrl;
    private String ldapName;
    private String capacity;
    private OpeningHours openingHours;
    private Long limitInDay;
    private Boolean global;
    private Long deskLimitCrowded;
    private Double minimumDeskArea;
    private Integer minTemp;
    private Integer maxTemp;
    private TemperatureUnit tempFormat;
    private TimeFormat timeFormat;

}
