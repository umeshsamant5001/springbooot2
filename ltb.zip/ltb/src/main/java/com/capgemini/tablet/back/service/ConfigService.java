package com.capgemini.tablet.back.service;

import com.capgemini.tablet.back.config.ApplicationProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.repository.ConfigRepository;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Objects;

@Service
public class ConfigService {

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private ConfigRepository configRepository;

    public ConfigValue findByKeyName(String keyName) {
        return this.configRepository.findByKeyName(keyName);
    }

    public String decrypt(String encryptedUuid) {
        if(Objects.isNull(encryptedUuid)) {
            return null;
        }

        try {
            String key = this.applicationProperties.getTablet().getKey();
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(new byte[16]);

            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedUuid));

            return new String(decryptedBytes);
        } catch (Exception e) {
            return null;
        }
    }
}