package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.net.URLEncoder;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;


import com.capgemini.tablet.back.config.Constants;
import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.mapper.MeetingMapper;
import com.capgemini.tablet.back.model.AppRegistrationManagement;
import com.capgemini.tablet.back.model.AttendeeDTO;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.DeviceDTO;

import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.Meeting;
import com.capgemini.tablet.back.model.MeetingCreateBookerRequestDTO;
import com.capgemini.tablet.back.model.MeetingCreateRequestDTO;
import com.capgemini.tablet.back.model.MeetingDTO;

import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.model.enumeration.EnumOsType;
import com.capgemini.tablet.back.model.enumeration.SaveRoomEventResult;
import com.capgemini.tablet.back.model.exception.GraphException;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.DeviceTokenService;
import com.capgemini.tablet.back.service.GraphRetryService;
import com.capgemini.tablet.back.service.MeetingBookingService;
import com.capgemini.tablet.back.service.MeetingService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.PushNotificationService;
import com.capgemini.tablet.back.service.bus.GraphEventProcessor;
import com.capgemini.tablet.back.service.bus.MeetingBusService;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import com.microsoft.graph.models.Event;
import org.slf4j.MDC;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = MeetingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class MeetingController {

    public static final String ROOT_API = "api/meeting";
    private static final long ONE_DAY_SECOND = 86400L;

    @Autowired
    private MeetingService meetingService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private OrchestreService orchestreService;

    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private PushNotificationService pushNotificationService;

    @Autowired
    private MeetingBusService meetingBusService;

    @Autowired
    private MeetingBookingService meetingBookingService;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private GraphRetryService graphRetryService;

    @Autowired
    private GraphEventProcessor graphEventProcessor;

    /**
     * REST endpoint to retrieve a list of meetings for a given POI (Point of
     * Interest)
     * within a specified time range.
     *
     * @param poiId the ID of the point of interest
     * @param from  the start timestamp (in milliseconds) of the planning range
     * @param to    the end timestamp (in milliseconds) of the planning range
     * @return a ResponseEntity containing a list of MeetingDTOs or an appropriate
     *         HTTP status
     */
    @GetMapping("/planning")
    public ResponseEntity<List<MeetingDTO>> getPlanning(
            @RequestParam Long poiId,
            @RequestParam Long from,
            @RequestParam Long to) {

        try {
            List<MeetingDTO> meetings = this.meetingService.getMeetings(poiId, from, to);
            if (Objects.isNull(meetings)) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(meetings);
        } catch (Exception e) {
            if (Constants.NO_EMAIL_CODE.equals(e.getMessage())) {
                log.error("{}", e.getMessage());
                return ResponseEntity.badRequest().build();
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Crée une réunion pour le poi en paramètre
     *
     * @param poiId
     * @return
     * @throws GraphException
     */
    @PostMapping(value = "/{poiId}")
    public ResponseEntity<MeetingDTO> createMeeting(@PathVariable Long poiId,
            @Valid @RequestBody MeetingCreateRequestDTO meetingCreateRequestDTO) {

        Poi poi = this.poiService.findById(poiId);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }
        Floor floor = poi.getFloor();
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }
        Building building = floor.getBuilding();
        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }

        CompletableFuture<Event> event;
        Meeting newMeeting = new Meeting();
        MeetingDTO validatedMeetingDTO = new MeetingDTO();
        try {
            validatedMeetingDTO.setFrom(Long.valueOf(String.valueOf(meetingCreateRequestDTO.getFrom())));
            validatedMeetingDTO.setTo(Long.valueOf(String.valueOf(meetingCreateRequestDTO.getTo())));
            if (Objects.nonNull(meetingCreateRequestDTO.getSubject())) {
                validatedMeetingDTO.setSubject(new String(meetingCreateRequestDTO.getSubject()));
            }
            if (Objects.nonNull(meetingCreateRequestDTO.getBooker())) {
                MeetingCreateBookerRequestDTO meetingCreateBookerRequestDTO = meetingCreateRequestDTO.getBooker();
                AttendeeDTO validatedBooker = new AttendeeDTO();
                if (Objects.nonNull(meetingCreateBookerRequestDTO.getFirstName())) {
                    validatedBooker.setFirstName(new String(meetingCreateBookerRequestDTO.getFirstName()));
                }
                if (Objects.nonNull(meetingCreateBookerRequestDTO.getLastName())) {
                    validatedBooker.setLastName(new String(meetingCreateBookerRequestDTO.getLastName()));
                }
                if (Objects.nonNull(meetingCreateBookerRequestDTO.getEmail())) {
                    validatedBooker.setEmail(new String(meetingCreateBookerRequestDTO.getEmail()));
                }
                validatedMeetingDTO.setBooker(validatedBooker);
            }
            event = this.meetingService.createEvent(validatedMeetingDTO, poi, building.getTimezoneJava());
            // Save the meeting in DB
            newMeeting.setId(URLEncoder.encode(event.get().id, "UTF-8"));
            newMeeting.setFrom(Long.valueOf(String.valueOf(validatedMeetingDTO.getFrom())));
            newMeeting.setTo(Long.valueOf(String.valueOf(validatedMeetingDTO.getTo())));
            newMeeting.setCheckStatus(EnumMeetingStatus.CREATED);
            newMeeting.setRoom(poi.getAttributes().get(Constants.CONF_ROOM_MAIL));
            newMeeting.setFloor(floor);
            newMeeting.setFloorId(floor.getId());
            newMeeting.setPoiName(poi.getName());
            newMeeting.setCreated(System.currentTimeMillis());
            newMeeting.setModifiedAt(System.currentTimeMillis());
        } catch (Exception e) {

            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        Meeting meetingSave = this.meetingService.save(newMeeting);
        return ResponseEntity.status(HttpStatus.CREATED).body(MeetingMapper.INSTANCE.meetingToMeetingDTO(meetingSave));
    }

        /**
     * Webhook called when an Outlook calendar of a room changes (~10 calls/s).
     *
     * The request thread only validates and enqueues; all the work (Graph calls, DB,
     * Service Bus) happens asynchronously in {@link GraphEventProcessor}, so a slow
     * Graph API can no longer pin Tomcat threads and Hikari connections.
     *
     * @return 202 if the notification was accepted, 400 if parameters are missing,
     *         503 if the local queue is full (the caller may retry later)
     */
    @GetMapping("/graphEvent")
    public ResponseEntity<Object> getSubTimeslots(@RequestParam String mail, @RequestParam String eventId) {
        if (!StringUtils.hasText(mail) || !StringUtils.hasText(eventId)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        log.info("Received graphEvent for mail {} and eventId {}", mail, eventId);

        boolean accepted = graphEventProcessor.submit(mail, eventId);
        if (!accepted) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
        }
        return ResponseEntity.status(HttpStatus.ACCEPTED).build();
    }

    /**
     * Endpoint to subscribe to a unique event queue.
     * This is typically used to initialize or test event queue subscriptions.
     *
     * @return HTTP 202 Accepted if the subscription is successful, or 500 Internal
     *         Server Error if an exception occurs.
     */
    @GetMapping("subscribe")
    public ResponseEntity<Object> subscribeToEventQueueTest() {
        try {
            this.orchestreService.subscribeUniquesQueues();
            return ResponseEntity.status(HttpStatus.ACCEPTED).build();
        } catch (Exception e) {
            log.error("Error in subscribeToEventQueueTest API ", e.getMessage(), e);
            //log.error("Error in subscribeToEventQueueTest API with correlationId {}: {}", MDC.get("correlationId"), e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Endpoint to send a push notification to a user based on their email.
     * The request must include the user's email, notification title, and body.
     *
     * @param request a map containing "email", "title", and "body" keys
     * @return HTTP 200 OK if the notification is sent successfully,
     *                  400 Bad Request if required fields are missing or no tokens
     *         are found.
     */
    @PostMapping("/send")
    public ResponseEntity<String> sendPushNotificationTest(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String title = request.get("title");
        String body = request.get("body");

        if (email == null || title == null || body == null) {
            return ResponseEntity.badRequest().body("Email, title, and body are required.");
        }

        // Fetch all device registrations for the user
        List<AppRegistrationManagement> devices = deviceTokenService.getAppRegistrationsForUser(email);

        if (devices == null || devices.isEmpty()) {
            return ResponseEntity.badRequest().body("No FCM token found for user: " + email);
        }

        // Send push notification to each device
        for (AppRegistrationManagement device : devices) {
            String token = device.getDeviceRegistrationToken();
            EnumOsType osType = device.getDeviceType();

            pushNotificationService.sendPushNotification(token, title, body, osType);
        }

        return ResponseEntity.ok("Push notification sent successfully to: " + email);
    }

    @PostMapping("/push-alert")
    public ResponseEntity<String> pushAlertTest(@RequestBody String payload) {
        meetingBusService.pushAlertReminder(payload);
        return ResponseEntity.ok("Push alert processed");
    }

    
@PostMapping("/trigger-reminder")
public ResponseEntity<String> triggerReminderTest(@RequestBody String payload) {
    meetingBusService.triggerReminder(payload);
    return ResponseEntity.ok("Trigger reminder processed");
}


    /**
     * Handles HTTP GET requests to retrieve a list of {@link MeetingDTO} objects
     * for a specified room and time range.
     * This endpoint calls the service layer to fetch meetings from the calendar and
     * returns them as a JSON response.
     * In case of any exception, it returns a 500 Internal Server Error.
     *
     * @param room     the identifier of the room for which meetings are to be
     *                 fetched
     * @param from     the start timestamp (epoch milliseconds) of the time range
     * @param to       the end timestamp (epoch milliseconds) of the time range
     * @param timeZone the time zone in which the meetings should be interpreted
     * @param poiName  the name of the point of interest (POI) associated with the
     *                 room
     * @return a {@link ResponseEntity} containing a list of {@link MeetingDTO}
     *         objects or an error status
     */
    @GetMapping
    public ResponseEntity<List<MeetingDTO>> getMeetingsTest(
            @RequestParam String room,
            @RequestParam Long from,
            @RequestParam Long to,
            @RequestParam String timeZone,
            @RequestParam String poiName) {
        try {
            List<MeetingDTO> meetings = meetingBookingService.getMeetingDTOs(room, from, to, timeZone, poiName);
            return ResponseEntity.ok(meetings);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/cancel")
    public ResponseEntity<String> cancelMeetingTest(@RequestBody String payload) {
        try {
           // String meetingId = payload.get("meetingId");
            log.info("Extracted meeting ID: {}", payload);
            meetingBusService.cancel(payload);
            return ResponseEntity.ok("Meeting cancellation processed.");
        } catch (Exception e) {
            log.error("Error cancelling meeting: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to cancel meeting.");
        }
    }

    @PostMapping("/email-alert-template")
    public ResponseEntity<String> triggerReminderTemplateTest() {
        meetingService.sendEmailBeforeMeetingTest();
        return ResponseEntity.ok("Trigger email template reminder processed");
    }

    @PostMapping("/email-template-no-show")
    public ResponseEntity<String> triggerNoShowTemplateTest() {
        meetingService.freeRoomForMeetingTest(Boolean.TRUE);
        return ResponseEntity.ok("Trigger email template no-show processed");
    }

    @PostMapping("/email-template-check-out")
    public ResponseEntity<String> triggerCheckOutTemplateTest() {
        meetingService.freeRoomForMeetingTest(Boolean.FALSE);
        return ResponseEntity.ok("TriggerEmail template check-out processed");
    }

    @PostMapping("/email-template-check-in")
    public ResponseEntity<String> triggerCheckInTemplateTest() {
        meetingService.checkInRoomForMeetingTest();
        return ResponseEntity.ok("Trigger email template check-in processed");
    }

}
