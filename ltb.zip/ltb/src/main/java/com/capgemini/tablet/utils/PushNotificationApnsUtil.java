package com.capgemini.tablet.utils;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.interfaces.ECPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.ECDSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

public class PushNotificationApnsUtil {

    
	public static String generateToken(String teamId, String keyId, String base64PrivateKey) throws Exception {
		// Decode base64 PKCS#8 private key
        byte[] pkcs8Bytes = Base64.getDecoder().decode(base64PrivateKey.replaceAll("\\s+", ""));

        KeyFactory keyFactory = KeyFactory.getInstance("EC");
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8Bytes);
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        // Create signer with EC private key
        JWSSigner signer = new ECDSASigner((ECPrivateKey) privateKey);
        // Prepare JWT with header and claims
        JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.ES256)
                .keyID(keyId)
                .type(JOSEObjectType.JWT)
                .build();
        JWTClaimsSet claims = new JWTClaimsSet.Builder()
                .issuer(teamId)
                .issueTime(new Date())
                .build();
        SignedJWT signedJWT = new SignedJWT(header, claims);
        // Compute the EC signature
        signedJWT.sign(signer);
        // Serialize the JWT to a compact form
        return signedJWT.serialize();
    }
	    
}

