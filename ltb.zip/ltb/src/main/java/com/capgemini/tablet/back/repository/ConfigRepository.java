package com.capgemini.tablet.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.ConfigValue;


@Repository
public interface ConfigRepository extends JpaRepository<ConfigValue, Long> {

    public ConfigValue findByKeyName(@Param("keyName") String keyName);

}
