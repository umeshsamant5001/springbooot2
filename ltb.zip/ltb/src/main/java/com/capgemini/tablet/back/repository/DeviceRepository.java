package com.capgemini.tablet.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;


@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

    public Device findByUuid(@Param("uuid") String uuid);

    @Query(value = "SELECT * FROM device WHERE uuid = :uuid AND device_type = 'TABLET'", nativeQuery = true)
    Device findTabletByUuid(@Param("uuid") String uuid);

    public List<Device> findAllByPoiName(@Param("poiName") String poiName);

    public List<Device> findAllByPoiNameIn(@Param("poiNames") List<String> poiNames);

    public List<Device> findAllByPoiNameAndFloorId(@Param("poiName") String poiName, @Param("floorId") Long floorId);

    @Query(value = "SELECT device " +
                   "FROM Device device " +
                   "JOIN Poi poi ON device.poiName = poi.name " +
                   "JOIN poi.attributes attributes " +
                   "WHERE device.deviceType = :deviceType " +
                   "AND INDEX(attributes) = 'conf_room_mail' " +
                   "AND attributes != '@capgemini.com' " +
                   "AND attributes != NULL " +
                   "ORDER BY device.poiName")
    public List<Device> findAllByDeviceType(@Param("deviceType") EnumDeviceType deviceType);


    @Modifying
    @Query("UPDATE Device device SET device.status = :status, device.lastStatusChange = :now,device.lastChange = :now WHERE device.uuid = :uuid")
    public void updateStatus(@Param("uuid") String uuid, @Param("status") EnumDeviceStatus status, @Param("now") Long now);

    /** Set the status of devices based on the lastStatusChange */
    @Modifying
    @Query("UPDATE Device device SET device.status = :status WHERE device.deviceType = :type "
        + " AND (device.lastStatusChange IS NULL OR device.lastStatusChange <= :date)")
    public void updateTabletStatus(@Param("type") EnumDeviceType type, @Param("status") EnumDeviceStatus status, @Param("date") Long date);

    public List<Device> findAllByFloorBuildingId(Long buildingId);

}
