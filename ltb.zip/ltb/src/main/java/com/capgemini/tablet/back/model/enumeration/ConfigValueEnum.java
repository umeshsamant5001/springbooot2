package com.capgemini.tablet.back.model.enumeration;

public class ConfigValueEnum {
	public static final String KEY_VAULT_KIOSK = "key_vault_kiosk";
    public static final String KEY_AZURE_SERVICE_BUS = "azure_service_bus";
	public static final String THRASH_FULL_MAIL = "THRASH_FULL_MAIL";
    public static final String OTHER_ISSUE_MAIL = "OTHER_ISSUE_MAIL";
    public static final String VIDEO_DEVICE_NOT_WORKING_MAIL = "VIDEO_DEVICE_NOT_WORKING_MAIL";
    public static final String CABLING_ISSUE_MAIL = "CABLING_ISSUE_MAIL";

}
