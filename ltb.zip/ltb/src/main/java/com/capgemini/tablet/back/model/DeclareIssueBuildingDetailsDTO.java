package com.capgemini.tablet.back.model;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeclareIssueBuildingDetailsDTO {

    private Long buildingId;
    private Long issueId;
    private String issueDescription;

}
