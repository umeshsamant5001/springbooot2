package com.capgemini.tablet.back.service;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.config.GraphHelper;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.enumeration.RetryStatus;
import com.capgemini.tablet.back.model.enumeration.SaveRoomEventResult;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import com.capgemini.tablet.back.repository.GraphEventRetryRepository;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class GraphRetryService {

    private final GraphHelper graphHelper;
    private final OrchestreService orchestreService;
    private final GraphEventRetryRepository graphEventRetryRepository;

    @Async
    public void retryOnce(
            String roomEmail,
            String eventId,
            List<DeviceDTO> deviceDTOs) {

        try {
            Thread.sleep(30000);
            // Commented out the actual save operation and set the result to SAVED for reverting retry logic to original state. Uncomment the below line to enable retry logic.
               SaveRoomEventResult result = SaveRoomEventResult.SAVED;
            // SaveRoomEventResult result =
            //         graphHelper.saveRoomEventById(
            //                 roomEmail,
            //                 eventId,
            //                 deviceDTOs);
            if (result == SaveRoomEventResult.SAVED
                    || result == SaveRoomEventResult.CANCELLED) {

                log.info(
                        "Retry succeeded for event {}",
                        eventId);
            graphEventRetryRepository.findById(encodeValue(eventId))
                .ifPresent(retry -> {
                    retry.setRetryStatus(RetryStatus.SUCCESS);
                    retry.setProcessedTs(Instant.now().getEpochSecond());
                    graphEventRetryRepository.save(retry);
                });
            } else {
                log.warn(
                        "Retry still failed for event {}",
                        eventId);
                graphEventRetryRepository.findById(encodeValue(eventId))
                .ifPresent(retry -> {
                    retry.setRetryStatus(RetryStatus.FAILED);
                    retry.setProcessedTs(Instant.now().getEpochSecond());
                    graphEventRetryRepository.save(retry);
                });
            }
        } catch (Exception e) {
            log.error(
                    "Retry failed for event {}",
                    eventId,
                    e);
                        graphEventRetryRepository.findById(encodeValue(eventId))
                .ifPresent(retry -> {
                    retry.setRetryStatus(RetryStatus.FAILED);
                    retry.setProcessedTs(Instant.now().getEpochSecond());
                    graphEventRetryRepository.save(retry);
                });
        }
        log.info("Publishing planning after retry for event {}",eventId);
                Instant instant = Instant.now();
                long start = instant.getEpochSecond();
                long end = start + 86400;
                for (DeviceDTO deviceDTO : deviceDTOs) {
                    orchestreService.publishPlanning(
                            deviceDTO,
                            start,
                            end);
                }
    }
    /**
     *
     * @param value
     * @return
     */
    private String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            log.error("Encoding error: {}", e.getMessage());
            return value; // Fallback: return the original value
        }
    }
}