package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.BuildingDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.FloorDTO;

@Named("FloorMapper")
@Mapper(config = DtoMapperConfig.class)
public interface FloorMapper {
    
    FloorMapper INSTANCE = Mappers.getMapper(FloorMapper.class);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("floorToFloorDTO")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "building", target = "building", qualifiedByName = { "buildingToBuildingDTOWithoutChildren" }),
    })
    FloorDTO floorToFloorDTO(Floor in, @Context String language);
    
    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("floorToFloorDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "building", ignore = true)
    })
    FloorDTO _floorToFloorDTOWithoutParent(Floor in, @Context String language);

    Floor floorDTOToFloor(FloorDTO in);

    @Named("buildingToBuildingDTOWithoutChildren")
    default BuildingDTO _buildingToBuildingDTOWithoutChildren(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutChildren(building, language);
    }

}