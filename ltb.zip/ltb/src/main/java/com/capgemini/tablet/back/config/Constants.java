package com.capgemini.tablet.back.config;

import java.time.ZoneId;
import java.util.TimeZone;

/**
 * Application constants.
 */
public final class Constants {

    public static final String SYSTEM = "system";
    public static final String NO_EMAIL_CODE = "NO_CONF_MAIL";
    public final static ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();
    public static final String CONF_ROOM_MAIL = "conf_room_mail";
    public static final int FIFTEEN_MINUTES = 15;
    public static final String CHECKIN_DURATION = "checkInDuration";
    public static final String PROFILE_SIT = "sit";
    public static final long ONE_DAY_SECOND = 86400L;
    public static final long FOURTEEN_HOURS_SECOND = 50400L;
    public static final int SECONDS_TO_MILLISECONDS = 1000;
    public static final int MINUTES_TO_SECONDS = 60;
    public static final String COUNTRYID = "countryId";
    public static final String ISSUEID = "issueId";
    public static final String ISSUEDESCRIPTION  = "issueDesc";
    
    public static final String MEETING_ROOM_NOT_CLEAN = "Meeting room is not clean";
    public static final String VIDEO_DEVICE_NOT_WORKING = "Video device is not working";
    public static final String TABLET_HAS_ISSUE = "Tablet has an issue";
    public static final String OTHER_ISSUE = "Other Issue";

    
    public static final String ACTION_REQUIRED = "Please take necessary action";
    public static final String REQUEST_CHECK = "Please request someone to check";




    private Constants() {}
}
