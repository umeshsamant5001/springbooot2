package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Equipment;
import com.capgemini.tablet.back.model.EquipmentDTO;

@Mapper(config = DtoMapperConfig.class)
public interface EquipmentMapper {
    
    EquipmentMapper INSTANCE = Mappers.getMapper(EquipmentMapper.class);

    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
    EquipmentDTO equipmentToEquipmentDTO(Equipment in, @Context String language);

    Equipment equipmentDTOToEquipment(EquipmentDTO in);

}
