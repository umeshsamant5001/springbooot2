package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.UuidDTO;
import com.capgemini.tablet.back.model.KioskMode;
import com.capgemini.tablet.back.model.ServiceBusConnectionDTO;
import com.capgemini.tablet.back.model.enumeration.ConfigValueEnum;
import com.capgemini.tablet.back.service.AzureKeyVaultService;
import com.capgemini.tablet.back.service.ConfigService;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import com.capgemini.tablet.utils.MobileAuthCrypto;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = ConfigurationController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ConfigurationController {

    static final String ROOT_API = "api/config";

    @Autowired
    private AzureKeyVaultService azureKeyVaultService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private OrchestreService orchestreService;

    @Autowired
    private DeviceService deviceService;

    /**
     *      * API to retrieve Azure Service Bus connection string for a device.
     *      * This is typically called after a tablet reboots.
     *      *
     *      * @param uuidDTO DTO containing the encrypted UUID of the device
     *      * @return ServiceBusConnectionDTO with the connection string, or
     * appropriate error response
     *     
     */
    @PostMapping("/serviceBus")
    public ResponseEntity<ServiceBusConnectionDTO> getAzureServiceBus(@RequestBody UuidDTO uuidDTO) {

        // This api will call after rebooting Tablet
        String uuid = this.configService.decrypt(uuidDTO.getEncryptedUuid());
        if (Objects.isNull(uuid)) {
            return ResponseEntity.internalServerError().build();
        }

        Device device = this.deviceService.findByUuid(uuid);
        if (Objects.isNull(device)) {
            log.info("Device is null");
            return ResponseEntity.notFound().build();
        }

        // notify tablet
        log.info("Start notify tablet : " + uuid);
        CompletableFuture.runAsync(() -> {
            this.orchestreService.notifyTablet(uuid);
        });

        String keyAzure = this.getConfigStringValue(ConfigValueEnum.KEY_AZURE_SERVICE_BUS);
        if (Objects.isNull(keyAzure) || keyAzure.length() == 0) {
            log.info("Config " + ConfigValueEnum.KEY_AZURE_SERVICE_BUS + " missing");
            return ResponseEntity.notFound().build();
        }
        KeyVaultSecret secret = this.azureKeyVaultService.getSecret(keyAzure);
        if (Objects.isNull(secret)) {
            log.info("Azure service bus secret is null");
            return ResponseEntity.notFound().build();
        }

        log.info("Get secret BUS : " + secret.getValue());
        ServiceBusConnectionDTO sBus = new ServiceBusConnectionDTO();
        sBus.setConnectionString(secret.getValue());

        log.info("End notify tablet : " + uuid);
        return ResponseEntity.ok(sBus);
    }

    /**
     *      * API to retrieve kiosk mode credentials.
     *      * It fetches the encrypted kiosk password and a base64-encoded passcode.
     *      *
     *      * @return KioskMode object containing encrypted credentials, or error
     * response
     *     
     */
    @GetMapping("/kiosk")
    public ResponseEntity<KioskMode> getKioskTest() {
        String keyAzure = this.getConfigStringValue(ConfigValueEnum.KEY_VAULT_KIOSK);
        if (Objects.isNull(keyAzure) || keyAzure.length() == 0) {
            return ResponseEntity.notFound().build();
        }

        KeyVaultSecret secret = azureKeyVaultService.getSecret(keyAzure);
        if (Objects.isNull(secret)) {
            return ResponseEntity.notFound().build();
        }

        try {
            log.info("Get Kiosk");
            String uncrypted = secret.getValue();
            String passcode = MobileAuthCrypto.generatePasscode(8);
            String crypted = MobileAuthCrypto.openSSLEncrypt(uncrypted, passcode);
            String b64Passcode = MobileAuthCrypto.encodeTo64(passcode);

            KioskMode respBody = new KioskMode(crypted, b64Passcode);
            log.info("Response Kiosk");

            return ResponseEntity.ok(respBody);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    private String getConfigStringValue(String key) {
        ConfigValue cValue = this.configService.findByKeyName(key);

        return Objects.nonNull(cValue) ? cValue.getValue() : "";
    }

    @GetMapping("/connect")
    public ResponseEntity<String> connect() {
        return ResponseEntity.ok("Connection established successfully.");
    }
}