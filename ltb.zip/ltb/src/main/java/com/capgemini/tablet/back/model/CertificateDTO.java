package com.capgemini.tablet.back.model;

import lombok.Data;

@Data
public class CertificateDTO {
	
	private String certificateName;
	private String base64EncodedCertificate;
	private Long expiration;

}
