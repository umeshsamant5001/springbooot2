package com.capgemini.tablet.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.BuildingDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.FloorDTO;
import com.capgemini.tablet.back.model.Site;
import com.capgemini.tablet.back.model.SiteDTO;
import com.capgemini.tablet.back.model.BuildingInformationDTO;
import com.capgemini.tablet.back.model.BuildingInformation;

@Named("BuildingMapper")
@Mapper(config = DtoMapperConfig.class)
public interface BuildingMapper {

    BuildingMapper INSTANCE = Mappers.getMapper(BuildingMapper.class);

    /**
     * <p>Function to use to map a Building to a BuildingDTO.<p>
     * 
     * <p>The function map all children object and parent ones. But don't map children of the parents and
     * parents of the children to avoid a loop in the mapping.</p>
     * 
     * @param in The Building to map.
     * @param language The current language (use for the title)
     * @return A new Building DTO.
     */
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
        @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
        @Mapping(source = "information", target = "information", qualifiedByName = { "buildingInformationToBuildingInformationDTO" }),
    })
    BuildingDTO buildingToBuildingDTO(Building in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>The function map a Building to a Building DTO but without mapping the parent (Site).</p>
     */
    @Named("buildingToBuildingDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "site", ignore = true),
        @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
    })
    BuildingDTO _buildingToBuildingDTOWithoutParent(Building in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     * 
     * <p>The function map a Building to a Building DTO but without mapping the ;children (Floor).</p>
     */
    @Named("buildingToBuildingDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
        @Mapping(target = "floors", ignore = true)
    })
    BuildingDTO _buildingToBuildingDTOWithoutChildren(Building in, @Context String language);

    Building buildingDTOToBuilding(BuildingDTO in);

    @Named("siteToSiteDTOWithoutChildren")
    default SiteDTO _siteToSiteDTOWithoutChildren(Site site, @Context String language) {
        return Mappers.getMapper(SiteMapper.class)._siteToSiteDTOWithoutChildren(site, language);
    }

    @Named("floorToFloorDTOWithoutParent")
    default FloorDTO _floorToFloorDTOWithoutParent(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class)._floorToFloorDTOWithoutParent(floor, language);
    }

    @Named("buildingInformationToBuildingInformationDTO")
    BuildingInformationDTO buildingInformationToBuildingInformationDTO(BuildingInformation buildingInformation, @Context String language);
    
    @Named("buildingInformationDTOToBuildingInformation")
    BuildingInformation buildingInformationDTOToBuildingInformation(BuildingInformationDTO buildingInformation, @Context String language);
    
}
