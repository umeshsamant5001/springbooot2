package com.capgemini.tablet.back.model.exception;

public class ServiceBusCredentialException extends Exception {

	private static final long serialVersionUID = 3154414080730702568L;
    

    public ServiceBusCredentialException(String message) {
        super(message);
    }
}
