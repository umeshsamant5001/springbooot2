package com.capgemini.tablet.back.service;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.model.enumeration.ConfigValueEnum;
import com.capgemini.tablet.back.model.KioskMode;
import com.capgemini.tablet.back.model.exception.KioskException;
import com.capgemini.tablet.back.repository.ConfigRepository;
import com.capgemini.tablet.utils.MobileAuthCrypto;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class KioskService {

    @Autowired
    private AzureKeyVaultService azureKeyVaultService;

    @Autowired
    private ConfigRepository configRepository;

    public KioskMode getKiosk() throws KioskException {
        String keyAzure = this.getConfigStringValue(ConfigValueEnum.KEY_VAULT_KIOSK);
        if (Objects.isNull(keyAzure) || keyAzure.length() == 0) {
            log.error("No value for {} in configuration table", ConfigValueEnum.KEY_VAULT_KIOSK);
            throw new KioskException("No value in configuration table");
        }

        KeyVaultSecret secret = this.azureKeyVaultService.getSecret(keyAzure);
        if (Objects.isNull(secret)) {
            log.error("No secret present for {}", keyAzure);
            throw new KioskException("No secret present");
        }

        try {
            log.info("Get Kiosk");
            String uncrypted = secret.getValue();
            String passcode = MobileAuthCrypto.generatePasscode(8);
            String crypted = MobileAuthCrypto.openSSLEncrypt(uncrypted, passcode);
            String b64Passcode = MobileAuthCrypto.encodeTo64(passcode);
            KioskMode respBody = new KioskMode(crypted, b64Passcode);
            log.info("Response Kiosk");

            return respBody;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new KioskException(e.getMessage());
        }
    }

    private String getConfigStringValue(String key) {
        ConfigValue cValue = this.configRepository.findByKeyName(key);
        return Objects.nonNull(cValue) ? cValue.getValue() : "";
    }
}
