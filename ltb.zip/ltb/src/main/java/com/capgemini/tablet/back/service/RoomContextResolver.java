package com.capgemini.tablet.back.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.tablet.back.config.Constants;
import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.model.Building;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.model.RoomContext;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import com.capgemini.tablet.back.model.exception.PoiException;
import com.capgemini.tablet.back.repository.PoiRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * Resolves a {@link RoomContext} (poi + building timezone + tablets) from a room
 * mailbox, a device or a poi, and caches the result for a short time.
 *
 * The graphEvent webhook fires ~10 times per second; before this class the flow
 * reloaded the Poi (and its EAGER Floor -> Building -> Floors -> attributes graph)
 * four times per notification. With the cache, a room is reloaded at most once per
 * {@link #CACHE_TTL_MS}.
 *
 * The public methods are read-only transactional: they run on worker threads, outside
 * any HTTP request, so there is no open-in-view session to back the entity mappers.
 * The transaction keeps the Hibernate session open while DeviceMapper walks the
 * Device -> Floor -> Building graph. It contains DB access only (no Graph, no Service
 * Bus) and, with hibernate.connection.provider_disables_autocommit=true, no connection
 * is taken at all on a cache hit.
 */
@Service
@Slf4j
public class RoomContextResolver {

    /** How long a resolved room (poi + tablets) is reused before being reloaded from DB. */
    static final long CACHE_TTL_MS = 60_000L;

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private PoiService poiService;

    @Autowired
    private DeviceService deviceService;

    private final ConcurrentMap<String, CachedContext> cache = new ConcurrentHashMap<>();

    /**
     * Resolve a room from its mailbox (the "mail" query parameter of /graphEvent).
     *
     * @return empty if no poi carries this conf_room_mail
     */
    @Transactional(readOnly = true)
    public Optional<RoomContext> byRoomMail(String mail) {
        String key = RoomContext.keyFor(mail);
        CachedContext cached = cache.get(key);
        if (Objects.nonNull(cached) && !cached.isExpired()) {
            return Optional.of(cached.context);
        }

        Poi poi = poiRepository.findByEmail(mail);
        if (Objects.isNull(poi)) {
            log.warn("No poi found for room mail {}", mail);
            cache.remove(key);
            return Optional.empty();
        }

        RoomContext context = fromPoi(poi);
        cache.put(key, new CachedContext(context));
        return Optional.of(context);
    }

    /**
     * Resolve a room from one of its devices (legacy entry point used by callers that
     * only have a DeviceDTO, e.g. tablet reboot notifications).
     */
    @Transactional(readOnly = true)
    public RoomContext fromDevice(DeviceDTO deviceDTO) throws PoiException {
        if (Objects.isNull(deviceDTO.getPoiName()) || Objects.isNull(deviceDTO.getFloor())) {
            String message = String.format("No poi affect to device %s", deviceDTO.getUuid());
            log.warn(message);
            throw new PoiException(message);
        }

        Poi poi = poiService.getPoiByNameAndFloorId(deviceDTO.getPoiName(), deviceDTO.getFloor().getId());
        if (Objects.isNull(poi)) {
            String message = String.format("No poi found for %s", deviceDTO.getPoiName());
            log.warn(message);
            throw new PoiException(message);
        }

        return fromPoi(poi);
    }

    /**
     * Build the context from an already loaded Poi. Does not use the cache.
     *
     * @throws IllegalStateException if the poi has no floor or no building
     */
    @Transactional(readOnly = true)
    public RoomContext fromPoi(Poi poi) {
        Floor floor = poi.getFloor();
        Building building = Objects.nonNull(floor) ? floor.getBuilding() : null;
        if (Objects.isNull(building)) {
            throw new IllegalStateException("Invalid POI data: floor or building missing for poi " + poi.getName());
        }

        Map<String, String> attributes = poi.getAttributes();
        String mail = Objects.nonNull(attributes) ? attributes.get(Constants.CONF_ROOM_MAIL) : null;

        List<DeviceDTO> tablets = deviceService.findAllByPoiName(poi.getName()).stream()
                .filter(device -> EnumDeviceType.TABLET.equals(device.getDeviceType()))
                .map(device -> DeviceMapper.INSTANCE.deviceToDeviceDTO(device, "en"))
                .collect(Collectors.toList());

        return RoomContext.builder()
                .mail(mail)
                .poiId(poi.getId())
                .poiName(poi.getName())
                .floorId(poi.getFloorId())
                .timezoneJava(building.getTimezoneJava())
                .tablets(tablets)
                .build();
    }

    /** Drop a room from the cache (call it when a tablet is re-assigned to another poi). */
    public void evict(String mail) {
        cache.remove(RoomContext.keyFor(mail));
    }

    private static final class CachedContext {
        private final RoomContext context;
        private final long expiresAt;

        private CachedContext(RoomContext context) {
            this.context = context;
            this.expiresAt = System.currentTimeMillis() + CACHE_TTL_MS;
        }

        private boolean isExpired() {
            return System.currentTimeMillis() > expiresAt;
        }
    }
}
