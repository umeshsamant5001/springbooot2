package com.capgemini.tablet.back.config;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import javax.persistence.PersistenceException;

import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.capgemini.tablet.back.model.AttendeeDTO;
import com.capgemini.tablet.back.model.DeviceDTO;

import com.capgemini.tablet.back.model.MeetingDTO;

import com.capgemini.tablet.back.model.RoomContext;
import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.model.enumeration.EnumQualification;
import com.capgemini.tablet.back.model.enumeration.EnumStatus;

import com.capgemini.tablet.back.repository.MeetingRepository;
import com.capgemini.tablet.back.service.MeetingPersistenceService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.RoomContextResolver;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.core.ClientException;
import com.microsoft.graph.httpcore.HttpClients;
import com.microsoft.graph.models.DateTimeTimeZone;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.Sensitivity;
import com.microsoft.graph.models.Subscription;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.options.Option;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.requests.EventCollectionPage;
import com.microsoft.graph.requests.EventCollectionRequestBuilder;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.requests.SubscriptionCollectionPage;
import com.microsoft.graph.requests.SubscriptionCollectionRequestBuilder;
import com.capgemini.tablet.back.model.Meeting;

import lombok.extern.slf4j.Slf4j;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import okhttp3.Request;


@Component
@Slf4j
public class GraphHelper {
    // Extend time for planning subscription (must not be the exact limit time)
    public static final long EXTEND_PLANNING_SUBSCRIPTION_MINUTE = (3 * 24 - 1) * 60;
        // --- HTTP client limits -------------------------------------------------------------
    // The Graph SDK default OkHttp client has no practical timeouts (100 s) and a
    // Dispatcher limited to 5 concurrent async requests per host. Every call goes to
    // graph.microsoft.com, so under load async calls queued up without bound while
    // the calling threads waited on CompletableFuture.get() with no timeout.
    static final long GRAPH_CONNECT_TIMEOUT_SECONDS = 5;
    static final long GRAPH_READ_TIMEOUT_SECONDS = 15;
    static final long GRAPH_CALL_TIMEOUT_SECONDS = 30;
    static final int GRAPH_MAX_REQUESTS = 64;
    static final int GRAPH_MAX_REQUESTS_PER_HOST = 32;
    /** Upper bound for a full calendarView (all pages) when waited on synchronously. */
    public static final long CALENDAR_VIEW_TIMEOUT_SECONDS = 20;

    @Autowired
    private ApplicationProperties applicationProperties;
    @Autowired
    PoiService poiService;
    @Autowired 
    private MeetingPersistenceService meetingPersistenceService;

    private GraphServiceClient<Request> graphClientForSendEmail;

    @Autowired
    private RoomContextResolver roomContextResolver;

    private volatile GraphServiceClient<Request> mClient;

    private final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();

    public GraphServiceClient<Request> getInstance() {
        GraphServiceClient<Request> client = mClient;
        if (Objects.isNull(client)) {
            synchronized (this) {
                client = mClient;
                if (Objects.isNull(client)) {
                    client = buildClient();
                    mClient = client;
                }
            }
        }
        return client;
    }
        private GraphServiceClient<Request> buildClient() {
        ApplicationProperties.Azure.GraphApi graphApi = this.applicationProperties.getAzure().getGraphApi();

        List<String> scopes = Arrays.asList(graphApi.getScopeUrl());
        ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                .tenantId(this.applicationProperties.getAzure().getTenantId())
                .clientId(graphApi.getClientId())
                .clientSecret(graphApi.getClientSecret())
                .build();
        TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(GRAPH_MAX_REQUESTS);
        dispatcher.setMaxRequestsPerHost(GRAPH_MAX_REQUESTS_PER_HOST);

        // Start from the SDK default client so we keep its auth / retry / redirect handlers.
        OkHttpClient httpClient = HttpClients.createDefault(authProvider).newBuilder()
                .dispatcher(dispatcher)
                .connectTimeout(GRAPH_CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(GRAPH_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(GRAPH_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .callTimeout(GRAPH_CALL_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .build();

        log.info("Graph client initialised (connectTimeout={}s readTimeout={}s callTimeout={}s maxRequestsPerHost={})",
                GRAPH_CONNECT_TIMEOUT_SECONDS, GRAPH_READ_TIMEOUT_SECONDS, GRAPH_CALL_TIMEOUT_SECONDS,
                GRAPH_MAX_REQUESTS_PER_HOST);

        return GraphServiceClient.builder()
                .authenticationProvider(authProvider)
                .httpClient(httpClient)
                .buildClient();
    }

    public GraphServiceClient<Request> getGraphClientForSendEmail() {
        if (graphClientForSendEmail == null) {
            ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getGraphApiSendEmail().getClientId())
                    .clientSecret(applicationProperties.getAzure().getGraphApiSendEmail().getClientSecret())
                    .build();

            TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(
                    List.of(applicationProperties.getAzure().getGraphApiSendEmail().getScopeUrl()),
                    credential);

            graphClientForSendEmail = GraphServiceClient.builder()
                    .authenticationProvider(authProvider)
                    .buildClient();
        }
        return graphClientForSendEmail;
    }

    /**
     * Delete an event by id
     *
     * @idEvent : id of event we need to delete
     * @return nothing if successful
     */
    public Event deleteEventById(String mail, String idEvent) throws ClientException {
        return this.getInstance().users(mail).calendar().events(idEvent).buildRequest().delete();
    }

    /**
     * Get a list of events between two ZonedDateTime
     *
     * @param start    : start of DateTime
     * @param end      : end of DateTime
     * @param timeZone : timezone
     * @param room     : poi mail
     * @return list of events
     */
    public CompletableFuture<List<Event>> getCalendarView(long start, long end, String timeZone, String room) {
        final List<Option> options = new LinkedList<>();
        MutableDateTime dateTimeStart = new MutableDateTime(start * 1000);
        MutableDateTime dateTimeEnd = new MutableDateTime(end * 1000);

        log.info("date used for graph API : " + dateTimeStart.toString() + " | " + dateTimeEnd.toString());

        options.add(new QueryOption("startDateTime", dateTimeStart.toString()));
        options.add(new QueryOption("endDateTime", dateTimeEnd.toString()));
        // Start and end times adjusted to user's time zone
        options.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

        final List<Event> allEvents = new LinkedList<Event>();
        // Create a separate list of options for the paging requests
        // paging request should not include the query parameters from the initial
        // request, but should include the headers.
        final List<Option> pagingOptions = new LinkedList<Option>();
        pagingOptions.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

        return getInstance()
                .users(room)
                .calendarView()
                .buildRequest(options)
                .getAsync()
                .thenCompose(eventPage -> processPageEvent(eventPage, allEvents, pagingOptions));
    }

 /**
     * Legacy signature kept for callers that only have the devices of the room.
     */
    public void saveRoomEventById(String roomEmail, String eventId, List<DeviceDTO> deviceDTOs) {
        if (deviceDTOs == null || deviceDTOs.isEmpty()) {
            log.warn("Device list is null or empty for roomEmail: {}", roomEmail);
            return;
        }
        Optional<RoomContext> room = roomContextResolver.byRoomMail(roomEmail);
        if (!room.isPresent()) {
            log.error("No room found for roomEmail: {}", roomEmail);
            return;
        }
        saveRoomEventById(room.get(), eventId);
    }

    /**
     * Fetch one event from the room mailbox and persist it in the meeting table
     * (or flag it CANCELLED).
     *
     * Not transactional on purpose: the Graph call must not be done while holding a
     * database connection. The stored procedures run in their own short transactions
     * (see {@link MeetingRepository}).
     */
    public void saveRoomEventById(RoomContext room, String eventId) {
        String roomEmail = room.getMail();
        log.info("Saving room event for roomEmail: {}, eventId: {}", roomEmail, eventId);

        try {
            Event graphEvent = getInstance()
                    .users(roomEmail)
                    .events(eventId)
                    .buildRequest()
                    .get();
            log.debug("Fetched event from Graph for roomEmail: {}, eventId: {}", roomEmail, eventId);

            // Check if the event is cancelled
            if (Boolean.TRUE.equals(graphEvent.isCancelled)) {
                log.warn("Event is marked as cancelled in Graph for roomEmail: {}, eventId: {}", roomEmail, eventId);
                meetingPersistenceService.markCancelled((eventId));
                return;
            }

            MeetingDTO meetingDto = createMeetingDTO(
                    graphEvent, room.getTimezoneJava(), room.getPoiName(), roomEmail, room.getFloorId());

            String jsonPayload = new ObjectMapper().writeValueAsString(meetingDto);
            log.debug("JSON payload for save - insertSingleMeetingFromJson: {}", jsonPayload);

            try {
                List<Meeting> meetingList = meetingPersistenceService.saveMeeting(jsonPayload);
                for (Meeting meeting : meetingList) {
                    log.debug("meeting Details after insertSingleMeetingFromJson in GraphHelper  | eventId={} ",
                    meeting.getId());
                }
            } catch (PersistenceException e) {
                log.error("Failed to insert meeting via stored procedure", e);
            } catch (Exception e) {
                log.error("Unexpected error during meeting insert", e);
            }

            log.info("Successfully saved meeting(s) for room: {}", roomEmail);

        } catch (com.microsoft.graph.http.GraphServiceException e) {
            if (e.getResponseCode() == 404) {
                log.warn("Event not found (possibly cancelled) for roomEmail: {}, eventId: {}", roomEmail, eventId);
                try {
meetingPersistenceService.markCancelled((eventId));
                } catch (Exception ex) {
                    log.error("Failed to mark meeting as CANCELLED in DB for eventId: {}", eventId, ex);
                }
            } else {
                log.error("Graph API error while retrieving event: {}", e.getMessage(), e);
            }
        } catch (IOException e) {
            log.error("Failed to serialize meeting DTOs to JSON", e);
        } catch (Exception e) {
            log.error("Unexpected error while saving room event: {}", e.getMessage(), e);
        }
    }


    public static long convertToUnixTimestamp(DateTimeTimeZone dateTimeTimeZone) {
        log.info("Converting dateTime: {}, timeZone: {}", dateTimeTimeZone.dateTime, dateTimeTimeZone.timeZone);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.n]");
        LocalDateTime localDateTime = LocalDateTime.parse(dateTimeTimeZone.dateTime, formatter);
        log.debug("Parsed LocalDateTime: {}", localDateTime);

        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(dateTimeTimeZone.timeZone));
        log.debug("ZonedDateTime: {}", zonedDateTime);

        Instant instant = zonedDateTime.toInstant();
        long epochSecond = instant.getEpochSecond();
        log.info("Unix timestamp: {}", epochSecond);

        return epochSecond;
    }

    public void createPlanningSubscription(String roomMail) throws ParseException {
        Subscription sub = new Subscription();
        sub.changeType = "created,updated,deleted";
        sub.notificationUrl = this.applicationProperties.getAzure().getGraphApi().getNotificationUrl();
        sub.resource = "/users/" + roomMail + "/events";
        sub.expirationDateTime = OffsetDateTime.now().plusMinutes(GraphHelper.EXTEND_PLANNING_SUBSCRIPTION_MINUTE);
        sub.clientState = roomMail;
        Subscription sub2 = this.getInstance().subscriptions().buildRequest().post(sub);
        log.info(sub2.toString());

    }

    /**
     * Delete a subscription on graph api
     *
     * @param subscription The subscrption to delete
     */
    public void deleteSubscription(Subscription subscription) {
        log.info("deleteSubscription deleteSubscription(Subscription subscription)" +subscription.id);
        this.getInstance().subscriptions(subscription.id)
                .buildRequest()
                .delete();
    }

    /**
     * Update the expiration time of a subscription on graph api
     *
     * @param subscription The subscription to update
     * @param minutes      Number of minutes to add on the subscription
     * @throws ParseException
     */
    public void extendSubscription(Subscription subscription, long minutes) throws ParseException {
        log.info("extendSubscription(Subscription subscription, long minutes) "+subscription.id);
        Subscription updatedSubscription = new Subscription();
        updatedSubscription.expirationDateTime = OffsetDateTime.now().plusMinutes(minutes);

        Subscription subscription2 = 
        this.getInstance().subscriptions(subscription.id)
                .buildRequest()
                .patch(updatedSubscription);
        log.info("subscription2  expirationDateTime >> "+subscription2.expirationDateTime);
        log.info("subscription2 notificationUrl  >> "+subscription2.notificationUrl);
        
    }

    public CompletableFuture<List<Subscription>> getSubscription() throws ParseException {
        final List<Subscription> allSubscription = new ArrayList<>();

        return this.getInstance().subscriptions()
                .buildRequest().getAsync()
                .thenCompose(subscriptionPage -> processPageSubscription(subscriptionPage, allSubscription));
    }

    private CompletableFuture<List<Subscription>> processPageSubscription(
            SubscriptionCollectionPage currentPage,
            List<Subscription> allSubscription) {
        allSubscription.addAll(currentPage.getCurrentPage());

        // Check if there is another page of results
        SubscriptionCollectionRequestBuilder nextPage = currentPage.getNextPage();
        if (Objects.nonNull(nextPage)) {
            // Request the next page and repeat
            return nextPage.buildRequest().getAsync()
                    .thenCompose(schedulePage -> processPageSubscription(schedulePage, allSubscription));
        } else {
            // No more pages, complete the future
            // with the complete list
            return CompletableFuture.completedFuture(allSubscription);
        }
    }

    /**
     * Process each page and return a list of events
     *
     * @param currentPage
     * @param eventList
     * @param options
     * @return CompletableFuture<List<Event>>
     */
    private CompletableFuture<List<Event>> processPageEvent(EventCollectionPage currentPage, List<Event> eventList,
            List<Option> options) {
        eventList.addAll(currentPage.getCurrentPage());
        // Check if there is another page of results
        EventCollectionRequestBuilder nextPage = currentPage.getNextPage();
        if (nextPage != null) {
            // Request the next page and repeat
            return nextPage.buildRequest(options)
                    .getAsync()
                    .thenCompose(eventPage -> processPageEvent(eventPage, eventList, options));
        } else {
            // No more pages, complete the future
            // with the complete list
            return CompletableFuture.completedFuture(eventList);
        }
    }

    /**
     * Create an Event
     *
     * @param room
     * @param event
     */
    public CompletableFuture<Event> createEvent(String room, Event event) {
        return this.getInstance()
                .users(room)
                .calendar()
                .events()
                .buildRequest()
                .postAsync(event);
    }

    public MeetingDTO createMeetingDTO(Event event, String timeZone, String poiName, String room, Long floorId) {

        MeetingDTO meeting = new MeetingDTO();

        try {
            meeting.setId(encodeValue(event.id));
            meeting.setFrom(convertToUTC(event.start.dateTime, event.start.timeZone, timeZone));
            meeting.setTo(convertToUTC(event.end.dateTime, event.end.timeZone, timeZone));
            meeting.setFromUtc(convertToUnixTimestamp(event.start));
            meeting.setToUtc(convertToUnixTimestamp(event.end));
            meeting.setStatus(EnumStatus.BUSY);
            meeting.setCheckStatus(EnumMeetingStatus.CREATED);
            meeting.setPoiName(poiName);
            meeting.setBooker(createAttendeeDTO(event));
            meeting.setRoom(room);
            meeting.setFloorId(floorId);
            meeting.setNoshowCounter(0);
            meeting.setCreated(System.currentTimeMillis());
            meeting.setModifiedAt(System.currentTimeMillis());
            meeting.setSubject(event.subject);
            meeting.setAlertCheckIn(false);
            meeting.setOrganizerEmail(event.organizer.emailAddress.address);
            meeting.setOrganizerName(event.organizer.emailAddress.name);
            meeting.setCreatedDateTime(System.currentTimeMillis());
            meeting.setCreatedFrom("Outlook");
          log.info("Meeting Details while creating meetingDTO in createMeetingDTO in GraphHelper  | eventId={} , organizerEmail={} , organizerName={} , createdDateTime={} , createdFrom={} ",
                    meeting.getId(), meeting.getOrganizerEmail(), meeting.getOrganizerName(), meeting.getCreatedDateTime(), meeting.getCreatedFrom());
        } catch (Exception e) {
            log.error("Error creating MeetingDTO from Event: {} ", e.getMessage(), e);
        }

        return meeting;
    }

    /**
     *
     * @param value
     * @return
     */
    private String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            log.error("Encoding error: {}", e.getMessage());
            return value; // Fallback: return the original value
        }
    }

    /**
     *
     * @param dateTime
     * @param eventTimeZone
     * @param targetTimeZone
     * @return
     */
    private Long convertToUTC(String dateTime, String eventTimeZone, String targetTimeZone) {
        MutableDateTime date = new MutableDateTime(dateTime, DateTimeZone.forID(eventTimeZone));
        date.setZone(DateTimeZone.forID(targetTimeZone));
        return this.getZonedEpochFromUTCEpoch(date.getMillis() / 1000, targetTimeZone);
    }

    /**
     * Convert given epoch to epoch in give zone
     *
     * @param timestampSeconds
     * @param zone
     * @return
     */
    private long getZonedEpochFromUTCEpoch(long timestampSeconds, String zone) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), ZoneId.of(zone)).atZone(UTC_ZONE_ID)
                .toEpochSecond();
    }

    /**
     *
     * @param event
     * @return
     */
    private AttendeeDTO createAttendeeDTO(Event event) {
        AttendeeDTO attendee = new AttendeeDTO();
        attendee.setQualification(EnumQualification.ORGANIZER);

        if (event.sensitivity == Sensitivity.PRIVATE) {
            attendee.setEmail("PRIVATE");
            attendee.setFirstName("PRIVATE");
            attendee.setLastName("PRIVATE");
        } else {
            attendee.setEmail(event.organizer.emailAddress.address);
            String[] name = event.organizer.emailAddress.name.split(",");
            attendee.setFirstName(name[0]);
            if (name.length > 1) {
                attendee.setLastName(name[1]);
            }
        }

        return attendee;
    }


        /**
    * Checks the event in the ROOM's mailbox and decides if reminder should be skipped.
    * Conditions:
    *  - If Graph returns isCancelled = true -> skip.
    *  - If Graph returns 404 (not found)    -> skip.
    *
    *
    * @param roomEmail     The room's calendar mailbox (from POI attributes: conf_room_mail).
    * @param encodedEventId The encoded Graph event id (MeetingDTO.id).
    * @return true if reminder must be skipped; false otherwise.
    */
    public boolean shouldSkipReminderForRoom(String roomEmail, String encodedEventId) {
        try {
            Event graphEvent = getInstance()
                    .users(roomEmail)
                    .events(encodedEventId)
                    .buildRequest()
                    .get();
    
            // Check if the event is cancelled
            if (Boolean.TRUE.equals(graphEvent.isCancelled)) {
                log.warn("Room event is CANCELLED in Graph. roomEmail={}, eventId={}", roomEmail, encodedEventId);
                return true; // skip reminder
            }
    
            // Not cancelled -> proceed
            return false;
    
        } catch (com.microsoft.graph.http.GraphServiceException e) {
            if (e.getResponseCode() == 404) {
                log.warn("Room event NOT FOUND (possibly cancelled/deleted). roomEmail={}, eventId={}", roomEmail, encodedEventId);
                return true; // skip reminder
            } else {
                log.error("Graph API error while retrieving ROOM event. roomEmail={}, eventId={}, error={}",
                        roomEmail, encodedEventId, e.getMessage(), e);
                return false; 
            }
        } catch (Exception e) {
            log.error("Unexpected error while checking ROOM event. roomEmail={}, eventId={}, error={}",
                    roomEmail, encodedEventId, e.getMessage(), e);
            return false; 
        }
    }

}
