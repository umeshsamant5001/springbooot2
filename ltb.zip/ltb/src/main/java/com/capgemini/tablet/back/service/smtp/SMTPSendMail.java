package com.capgemini.tablet.back.service.smtp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.mail.MessagingException;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import com.capgemini.tablet.back.config.ApplicationProperties;
import com.capgemini.tablet.back.config.Constants;
import com.capgemini.tablet.back.config.EmailConstant;
import com.capgemini.tablet.back.model.ConfigValue;
import com.capgemini.tablet.back.model.DeclareIssueEmailDTO;
import com.capgemini.tablet.back.model.EmailDTO;
import com.capgemini.tablet.back.model.enumeration.ConfigValueEnum;
import com.capgemini.tablet.back.model.enumeration.EmailCategory;
import com.capgemini.tablet.back.service.BuildingService;
import com.capgemini.tablet.back.service.ConfigService;
import com.capgemini.tablet.back.service.DeclareIssueBuildingDetailsService;
import com.capgemini.tablet.back.service.FloorService;
import com.capgemini.tablet.back.service.PoiService;
import com.microsoft.graph.models.Attachment;
import com.microsoft.graph.requests.AttachmentCollectionPage;
import com.microsoft.graph.models.FileAttachment;
import com.microsoft.graph.models.ItemBody;
import com.microsoft.graph.models.UserSendMailParameterSet;
import com.microsoft.graph.models.BodyType;
import com.microsoft.graph.models.EmailAddress;
import com.capgemini.tablet.back.config.GraphHelper;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.models.Recipient;
import lombok.extern.slf4j.Slf4j;

/**
 * Service class responsible for sending emails via SMTP.
 */
@Service
@Slf4j
public class SMTPSendMail {

    @Autowired
    private ConfigService configService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private ApplicationProperties applicationProperties;
        
    @Autowired
    private DeclareIssueBuildingDetailsService declareIssueBuildingDetailsService;

    @Autowired
    GraphHelper graphHelper;
    
    private static final Map<String, String> ISSUE_INSTRUCTIONS = Map.of(
        Constants.MEETING_ROOM_NOT_CLEAN, Constants.ACTION_REQUIRED,
        Constants.VIDEO_DEVICE_NOT_WORKING, Constants.ACTION_REQUIRED,
        Constants.TABLET_HAS_ISSUE, Constants.REQUEST_CHECK,
        Constants.OTHER_ISSUE, Constants.REQUEST_CHECK
    );   
    
    private String getConfigStringValue(String key) {
        ConfigValue cValue = this.configService.findByKeyName(key);

        return Objects.nonNull(cValue) ? cValue.getValue() : "";
    }

    public void sendEmailBasedOnCategory(String poiName, String tabletUuid, EmailCategory emailCategory)
            throws MessagingException {

        // Get poiTitleEnName
        String poiTitleEnName = poiService.findTitleEnByPoiName(poiName);

        // Get floorTitleEnName
        Long floorId = poiService.getFloorIdByPoiName(poiTitleEnName);
        String floorTitleEnName = floorService.findTitleEnByFloorId(floorId);

        // Get buildingTitleEnName
        Long buildingId = floorService.getBuildingIdByFloorId(floorId);
        String buildingTitleEnName = buildingService.findTitleEnByBuildingId(buildingId);

        String recipientEmail;
        String bodyContentDetails;
        switch (emailCategory) {
            case TRASH_FULL:
                recipientEmail = this.getConfigStringValue(ConfigValueEnum.THRASH_FULL_MAIL); // ISS/facility manager
                bodyContentDetails = EmailConstant.TRASH_FULL;
                break;
            case VIDEO_DEVICE_NOT_WORKING:
                recipientEmail = this.getConfigStringValue(ConfigValueEnum.VIDEO_DEVICE_NOT_WORKING_MAIL); // Group
                                                                                                           // IT/GOSS
                                                                                                           // support
                bodyContentDetails = EmailConstant.VIDEO_DEVICE_NOT_WORKING;
                break;
            case CABLING_ISSUE:
                recipientEmail = this.getConfigStringValue(ConfigValueEnum.CABLING_ISSUE_MAIL); // CRES support
                bodyContentDetails = EmailConstant.CABLING_ISSUE;
                break;
            case OTHER_ISSUE:
                recipientEmail = this.getConfigStringValue(ConfigValueEnum.OTHER_ISSUE_MAIL); // CRES support
                bodyContentDetails = EmailConstant.OTHER_ISSUE;
                break;
            default:
                throw new IllegalArgumentException("Unknown email category");
        }
        if (recipientEmail == null || recipientEmail.isEmpty()) {
            throw new IllegalArgumentException("Recipient email is empty");
        }

        // Prepare Email Body Content
        Map<String, Object> params = new HashMap<>();
        params.put("POI_TITLE_EN_NAME", poiTitleEnName);
        params.put("FLOOR_TITLE_EN_NAME", floorTitleEnName);
        params.put("BUILDING_TITLE_EN_NAME", buildingTitleEnName);
        params.put("BODY_CONTENT_DETAILS", bodyContentDetails);

        String emailBody = StringSubstitutor.replace(this.applicationProperties.getIncident().getBody(), params,
                "${", "}");

        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setAdressee(Arrays.asList(recipientEmail.split(",")));
        emailDTO.setSubject("Conference Room Issue: " + emailCategory.getDescription());
        emailDTO.setBody(emailBody);

        try {
              sendEmail(emailDTO);
            //sendEmailGraph(emailDTO);
            log.info("Incident email sent to {}", Arrays.asList(recipientEmail.split(",")));
        } catch (Exception e) {
            log.error("Error sending Incident email: {}", e.getMessage(), e);
        }

    }

    public void sendDeclareIssueEmail(DeclareIssueEmailDTO dto) throws MessagingException {

        if (dto == null || dto.getPoiName() == null || dto.getPoiName().isBlank()) {
            throw new IllegalArgumentException("POI name is required");
        }
        if (dto.getIssueDescription() == null || dto.getIssueDescription().isBlank()) {
            throw new IllegalArgumentException("Issue description is required");
        }
    
        // 1) Fetch all fields in ONE SQL via service
        Map<String, Object> data = declareIssueBuildingDetailsService.getEmailDisplayData(
                dto.getPoiName(), dto.getTabletUuid(), dto.getIssueDescription()
        );

         Long buildingId = (Long) data.get("buildingId");
         // 2) Recipient lookup using existing logic
         String recipientEmailId = declareIssueBuildingDetailsService.getEmailIdForIssues(buildingId,
                  dto.getIssueDescription());
     
         if (recipientEmailId == null || recipientEmailId.isBlank()) {
             throw new IllegalArgumentException("Recipient email is empty");
         }

        // 3) USER_NAME from first recipient email
        String firstRecipient = recipientEmailId.split(",")[0].trim();
        String userName = getUserName(firstRecipient);
        
        String issueType = (String) data.get("ISSUE_TYPE");
        String instruction = getInstructionForIssue(dto.getIssueDescription());
        
        // fallback if null
        if (instruction == null) instruction = "";
        String issueTypeFinal = issueType.trim() + ". " + instruction.trim() + ".";
    
        // 4) Prepare params for YAML template
        Map<String, Object> params = new HashMap<>();
        params.put("USER_NAME", userName);
        params.put("BUILDING_TITLE_EN_NAME", data.get("BUILDING_TITLE_EN_NAME"));
        params.put("MEETING_ROOM_NAME", data.get("MEETING_ROOM_NAME"));
        params.put("MEETING_ROOM_EMAIL", data.get("MEETING_ROOM_EMAIL"));
        params.put("TABLET_MAC_ID", data.get("TABLET_MAC_ID"));
        params.put("POI_TITLE_EN_NAME", data.get("POI_TITLE_EN_NAME"));
        params.put("ISSUE_TYPE", issueTypeFinal);
        params.put("ISSUE_RAISED_AT", data.get("ISSUE_RAISED_AT"));
    
        // 5) Render template from application.yml
        String emailBody = StringSubstitutor.replace(
                applicationProperties.getIncident().getBody(),
                params,
                "${",
                "}"
        );

        // 6) Build email DTO
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setAdressee(Arrays.asList(recipientEmailId.split(",")));
        emailDTO.setSubject("Conference Room Issue: " + dto.getIssueDescription());
        emailDTO.setBody(emailBody);
        log.info("Sending email body:\n{}", emailDTO.getBody());
         
        try {
              sendEmail(emailDTO);
            //sendEmailGraph(emailDTO);
            log.info("Incident email sent to {}", Arrays.asList(recipientEmailId.split(",")));
        } catch (Exception e) {
            log.error("Error sending Incident email: {}", e.getMessage(), e);
        }
    }

    private String getUserName(String emailAddress){
        String userName = emailAddress.substring(0,emailAddress.indexOf("@") );
        String[] userNameArr = userName.split("\\.");
        return normalCase(userNameArr[1]) + " " + normalCase(userNameArr[0]);        
    }

    private String normalCase(String word) {
        return word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();
    }  

    private String getInstructionForIssue(String issueDescription) {
        return ISSUE_INSTRUCTIONS.get(issueDescription);
    }

    private String resolveImageContentType(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".webp")) return "image/webp";
        return "image/png";
    }

    /**
     * Sends an email using EmailDTO via Microsoft Graph.
     * <p>
     * This method builds the email message, sets HTML content,
     * assigns recipients, sends the email, and logs execution time.
     * @param emailDTO DTO containing subject, body, recipients, and CC list
     */
    public void sendEmail(EmailDTO emailDTO) {

        long start = System.currentTimeMillis();

        // 1. Create Graph Message
        Message message = new Message();

        // Subject
        message.subject = emailDTO.getSubject();

        // HTML Body
        ItemBody body = new ItemBody();
        body.contentType = BodyType.HTML;
        body.content = emailDTO.getBody();
        message.body = body;
        
        message.toRecipients = emailDTO.getAdressee().stream()
            .map(addr -> {
                Recipient r = new Recipient();
                r.emailAddress = new EmailAddress();
                r.emailAddress.address = addr;
                return r;
            })
            .collect(Collectors.toList());       

        // CC recipients (if any)
        if (emailDTO.getCopies() != null && !emailDTO.getCopies().isEmpty()) {
            message.ccRecipients = emailDTO.getCopies().stream()
            .map(addr -> {
                Recipient r = new Recipient();
                r.emailAddress = new EmailAddress();
                r.emailAddress.address = addr;
                return r;
            })
            .collect(Collectors.toList());
        }

        // Inline image attachments (CID references)
        if (emailDTO.getInlineImages() != null && !emailDTO.getInlineImages().isEmpty()) {
            LinkedList<Attachment> attachments = new LinkedList<>();
            emailDTO.getInlineImages().forEach((contentId, classpathPath) -> {
                ClassPathResource resource = new ClassPathResource(classpathPath);
                if (resource.exists()) {
                    try {
                        byte[] imageBytes = resource.getInputStream().readAllBytes();
                        log.info("Loaded inline image {} ({} bytes)", classpathPath, imageBytes.length);
                        FileAttachment fa = new FileAttachment();
                        log.info("Attachment class = {}", fa.getClass().getName());
                        log.info("odataType = {}", fa.oDataType);
                        fa.oDataType = "#microsoft.graph.fileAttachment";
                        fa.name = classpathPath.substring(classpathPath.lastIndexOf('/') + 1);
                        fa.contentType = resolveImageContentType(fa.name);
                        fa.isInline = true;
                        fa.contentId = contentId;
                        fa.contentBytes = imageBytes;
                        attachments.add(fa);
                    } catch (java.io.IOException e) {
                        log.warn("Could not load inline image {}: {}", classpathPath, e.getMessage());
                    }
                } else {
                    log.warn("Inline image not found on classpath: {}", classpathPath);
                }
            });
            if (!attachments.isEmpty()) {
                message.attachments = new AttachmentCollectionPage(attachments, null);
            }
        }

        // 2. Send via Microsoft Graph
        String senderMailbox = applicationProperties.getSmtp().getEmail();
        log.info("Sending email via Microsoft Graph... sender='{}', to={}, cc={}, subject='{}', bodyLength={}, attachments={}",
            senderMailbox,
            emailDTO.getAdressee(),
            emailDTO.getCopies(),
            emailDTO.getSubject(),
            emailDTO.getBody() == null ? 0 : emailDTO.getBody().length(),
            message.attachments == null ? 0 : message.attachments.getCurrentPage().size());

        try {
            graphHelper.getGraphClientForSendEmail()
                .users(senderMailbox)
                //.users("noreply_stationery.in@capgemini.com") // service mailbox
                .sendMail(
                    UserSendMailParameterSet
                        .newBuilder()
                        .withMessage(message)
                        .withSaveToSentItems(true)
                        .build()
                )
                .buildRequest()
                .post();

            long execTimeInMs = System.currentTimeMillis() - start;
            log.info("Microsoft Graph sendMail request accepted for sender='{}', to={}. Execution time : {} millisec.",
                senderMailbox, emailDTO.getAdressee(), execTimeInMs);
        } catch (Exception e) {
            long execTimeInMs = System.currentTimeMillis() - start;
            log.error("Microsoft Graph sendMail FAILED for sender='{}', to={}, subject='{}' after {} millisec. Error class={}, message={}",
                senderMailbox, emailDTO.getAdressee(), emailDTO.getSubject(), execTimeInMs,
                e.getClass().getName(), e.getMessage(), e);
            throw e;
        }
    }
         
}
