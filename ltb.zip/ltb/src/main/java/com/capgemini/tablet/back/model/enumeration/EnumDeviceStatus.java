package com.capgemini.tablet.back.model.enumeration;

public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}