package com.capgemini.tablet.back.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.tablet.back.model.Floor;
import com.capgemini.tablet.back.repository.FloorRepository;

@Service
public class FloorService {

	@Autowired
	private FloorRepository floorRepository;

	public Floor findById(Long floorId) {
		return this.floorRepository.findById(floorId).orElse(null);
	}

	public String findTitleEnByFloorId(Long id) {
        return floorRepository.findTitleEnByFloorId(id);
    }

	public Long getBuildingIdByFloorId(Long id) {
        return floorRepository.getBuildingIdByFloorId(id);
    }
}
