package com.capgemini.tablet.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import com.capgemini.tablet.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@Entity
@Table(name = "transaction_logging_tablet", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class TransactionLoggingTablet {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TransactionLoggingTablet_Generator")
    @SequenceGenerator(name = "TransactionLoggingTablet_Generator", sequenceName = "TransactionLoggingTablet_Sequence")
    private Long id;

    @Lob
    @Column(name = "payload" , columnDefinition = "TEXT")
    private String payload;

    @Lob
    @Column(name = "subject", columnDefinition = "TEXT")
    private String subject;

    @Column(name = "date")
    private Long date;

}
