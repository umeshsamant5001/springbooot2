package com.capgemini.tablet.back.service;

import com.capgemini.tablet.back.config.FirebaseInitializer;
import com.capgemini.tablet.back.config.FirebaseInitializer;
import com.capgemini.tablet.back.model.AppRegistrationManagement;
import com.capgemini.tablet.back.model.enumeration.EnumOsType;
import com.capgemini.tablet.back.repository.DeviceTokenRepository;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.BatchResponse;
import com.google.firebase.messaging.SendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
 
@Service
@Slf4j
public class DeviceTokenService {

    @Autowired
    private DeviceTokenRepository deviceTokenRepository;

    @Autowired
    private FirebaseInitializer firebaseInitializer;

    private boolean isInitialize = false;
    @Autowired
    private Environment environment;

    // public void initialize() {
    //     firebaseInitializer.initialize(); // Ensure Firebase is initialized
    // }

    /**
   * Initializes Firebase apps for Android and iOS using environment-specific service account credentials.
   * Ensures initialization is performed only once per application lifecycle.
   */
  public void initialize() {
    if (this.isInitialize) {
      return;
    }

    this.isInitialize = true;
    InputStream androidServiceAccount = null;
    InputStream iosServiceAccount = null;

    try {
        if (isDev() || isLocal()) {
            androidServiceAccount = new ClassPathResource("service-account_android.json").getInputStream();
            log.info("Initializing Firebase for DEVICEDeviceTokenService isDev : ", androidServiceAccount);
            iosServiceAccount = new ClassPathResource("service-account_ios.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService -  iosServiceAccount isDev : ", iosServiceAccount);
        } else if (isSit()) {
            androidServiceAccount = new ClassPathResource("service-account_android_sit.json").getInputStream();
             log.info("Initializing Firebase for DeviceTokenService - isSit  androidServiceAccount: ", androidServiceAccount);
            iosServiceAccount = new ClassPathResource("service-account_ios_sit.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService - isSit  iosServiceAccount: ", iosServiceAccount);
        } else if (isUat()) {
            androidServiceAccount = new ClassPathResource("service-account_android_uat.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService - isUat  androidServiceAccount: ", androidServiceAccount);
            iosServiceAccount = new ClassPathResource("service-account_ios_uat.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService - isUat  iosServiceAccount: ", iosServiceAccount);
        } else if (isProd()) {
            androidServiceAccount = new ClassPathResource("service-account_android_prod.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService - isProd  androidServiceAccount: ", androidServiceAccount);
            iosServiceAccount = new ClassPathResource("service-account_ios_prod.json").getInputStream();
            log.info("Initializing Firebase for DeviceTokenService - isProd  iosServiceAccount: ", iosServiceAccount);
        }

        FirebaseOptions androidOptions = FirebaseOptions.builder()
            .setCredentials(GoogleCredentials.fromStream(androidServiceAccount))
            .build();

        FirebaseOptions iosOptions = FirebaseOptions.builder()
            .setCredentials(GoogleCredentials.fromStream(iosServiceAccount))
            .build();

        // Initialize the Android app with the name "androidApp"
        FirebaseApp.initializeApp(androidOptions, "androidApp");

        // Initialize the iOS app with the name "iosApp"
        FirebaseApp.initializeApp(iosOptions, "iosApp");

        log.info("Initialization done");
        } catch (Exception e) {
        log.error("Error while initalized {}", e);
        }
    }

    public boolean isLocal() {
        log.info("Active profiles DeviceTokenService LOCAL: {}", Arrays.toString(this.environment.getActiveProfiles()));
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("local"::equals);
    }

    public boolean isDev() {
        log.info("Active profiles DeviceTokenService IsDEV: {}", Arrays.toString(this.environment.getActiveProfiles()));

    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("develop"::equals);
    }

    public boolean isSit() {
        log.info("Active profiles DeviceTokenService SIT: {}", Arrays.toString(this.environment.getActiveProfiles()));
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("sit"::equals);
    }

    public boolean isUat() {
        log.info("Active profiles DeviceTokenService UAT: {}", Arrays.toString(this.environment.getActiveProfiles()));
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("uat"::equals);
    }

    public boolean isProd() {
        log.info("Active profiles DeviceTokenService PROD: {}", Arrays.toString(this.environment.getActiveProfiles()));
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("production"::equals);
    }

    public void saveDeviceToken(String userId, String token, EnumOsType deviceType) {
        AppRegistrationManagement tokenEntity = new AppRegistrationManagement();
        tokenEntity.setDeviceId(userId);
        tokenEntity.setDeviceRegistrationToken(token);
        tokenEntity.setDeviceType(deviceType);

        deviceTokenRepository.save(tokenEntity);
    }

    public List<String> getDeviceRegistrationTokens(EnumOsType deviceType) {
        return deviceTokenRepository.findByDeviceType(deviceType).stream()
                .map(AppRegistrationManagement::getDeviceRegistrationToken)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public List<String> handleFailedTokens(BatchResponse response, List<String> registrationTokens, String platform) {
        List<String> failedTokens = new ArrayList<>();
        List<SendResponse> responses = response.getResponses();

        for (int i = 0; i < responses.size(); i++) {
            if (!responses.get(i).isSuccessful()) {
                failedTokens.add(registrationTokens.get(i));
            }
        }

        if (!failedTokens.isEmpty()) {
            log.warn("Tokens failed for {}: {}", platform, failedTokens);
        }

        return failedTokens;
    }

    public List<String> getTokensForUser(String email) {
        return deviceTokenRepository.findByEmailId(email).stream()
                .map(AppRegistrationManagement::getDeviceRegistrationToken)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public List<AppRegistrationManagement> getAppRegistrationsForUser(String emailId) {
        return deviceTokenRepository.findByEmailId(emailId);
    }
}
