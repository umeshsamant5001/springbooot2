package com.capgemini.tablet.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.Objects;
import com.capgemini.tablet.back.model.UuidDTO;
import com.capgemini.tablet.back.service.ConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.tablet.back.mapper.DeviceMapper;
import com.capgemini.tablet.back.model.CertificateDTO;
import com.capgemini.tablet.back.model.Device;
import com.capgemini.tablet.back.model.DeviceDTO;
import com.capgemini.tablet.back.service.DeviceService;
import com.capgemini.tablet.back.service.PoiService;
import com.capgemini.tablet.back.service.AzureKeyVaultService;
import com.capgemini.tablet.back.model.Poi;
import com.capgemini.tablet.back.mapper.CertificateMapper;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceAttribute;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.http.*;

@Slf4j
@RestController
@RequestMapping(value = DeviceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class DeviceController {

    static final String ROOT_API = "api/device";

    @Autowired
    private DeviceService deviceService;

    @Autowired
	private AzureKeyVaultService azureKeyVaultService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private PoiService poiService;
  
    /**
     * Retrieves device details by UUID.
     *
     * @param language the preferred language for the response (default is "en")
     * @param deviceUuid the UUID of the device
     * @return the device details as a DeviceDTO, or 204 No Content if not found
     */

    @GetMapping("/{deviceUuid}/")
    public ResponseEntity<DeviceDTO> getDeviceTest(
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
        @PathVariable String deviceUuid
    ) {
        Device device = this.deviceService.findByUuid(deviceUuid);

        if (Objects.isNull(device)) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(DeviceMapper.INSTANCE.deviceToDeviceDTO(device, language));
    }
  
    /**
     * Retrieves the certificate for a device based on its encrypted UUID.
     *
     * @param language the preferred language for the response (default is "en")
     * @param uuidDTO the DTO containing the encrypted UUID
     * @return the certificate as a CertificateDTO, or appropriate error response
     */
    @PostMapping("/certificate")
	public ResponseEntity<CertificateDTO> getDeviceCertificate(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestBody UuidDTO uuidDTO) {

        String uuid = this.configService.decrypt(uuidDTO.getEncryptedUuid());
        if (Objects.isNull(uuid)) {
            return ResponseEntity.internalServerError().build();
        }

        Device device = this.deviceService.findByUuid(uuid);   
        
        Poi poiInDevice =  null;
        if(Objects.nonNull(device)){
            poiInDevice = poiService.findByName(device.getPoiName());
        }

		if (Objects.isNull(device)) {
			return ResponseEntity.notFound().build();
        } else if (!device.getDeviceType().toString().equals(EnumDeviceType.TABLET.toString())) {
			return ResponseEntity.notFound().build();
		} else if (Objects.isNull(device.getAttributes().get(EnumDeviceAttribute.CERTIFICATE.toString()))) {
			return ResponseEntity.notFound().build();
		} else if (Objects.isNull(poiInDevice)) {			
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "POI_NOT_AVAILABLE: POI Name not available"
            );              
        }
        else {
            log.info("Get certificate for : " + uuid);
			return ResponseEntity.ok(CertificateMapper.INSTANCE.mapperVaultEntityToCSOEntity(this.azureKeyVaultService
					.getSecret(device.getAttributes().get(EnumDeviceAttribute.CERTIFICATE.toString()))));
		}
	}

    /*
     * Update or create the ip of the device
     * @deviceUuid: uuid of the device
     * @ip: ip of the device 
    */
    @PutMapping("/{deviceUuid}")
    public ResponseEntity<DeviceDTO> updateIpTest(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable String deviceUuid,
            @RequestParam String ip,
            @RequestParam String appVersion) {
        Device device = this.deviceService.findByUuid(deviceUuid);

        if (Objects.isNull(device)) {
            return ResponseEntity.notFound().build();
        }

        if(device.getAttributes().containsKey(EnumDeviceAttribute.IP.toString())) {
            device.getAttributes().replace(EnumDeviceAttribute.IP.toString(), ip);
        } else {
            device.getAttributes().put(EnumDeviceAttribute.IP.toString(), ip);
        }

        if(device.getAttributes().containsKey(EnumDeviceAttribute.APP_VERSION.toString())) {
            device.getAttributes().replace(EnumDeviceAttribute.APP_VERSION.toString(), appVersion);
        } else {
            device.getAttributes().put(EnumDeviceAttribute.APP_VERSION.toString(), appVersion);
        }
        Device deviceSave = this.deviceService.save(device);

        if(Objects.isNull(deviceSave)) {
            return ResponseEntity.internalServerError().build();
        }
        return ResponseEntity.ok(DeviceMapper.INSTANCE.deviceToDeviceDTO(deviceSave, language));
    }
}
