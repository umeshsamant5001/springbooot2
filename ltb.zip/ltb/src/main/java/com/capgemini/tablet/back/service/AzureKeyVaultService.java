package com.capgemini.tablet.back.service;

import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.security.keyvault.certificates.CertificateClient;
import com.azure.security.keyvault.certificates.CertificateClientBuilder;
import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.config.ApplicationProperties;

@Slf4j
@Service
public class AzureKeyVaultService {

    public static final String CERTIFICATE_NAME = "tablet-smartoffice";

	@Autowired
    private ApplicationProperties applicationProperties;

    private SecretClient secretClient;

    private CertificateClient certificateClient;

    public KeyVaultSecret getSecret(String secretName) {
        KeyVaultSecret kvSecret = getSecretClient().getSecret(secretName);
        if (Objects.isNull(kvSecret)) {
            return null;
        }

        log.info("Success to the secret");
        return kvSecret;
    }

    public KeyVaultSecret getPrivateKey() {
        ApplicationProperties.Azure.KeyVault keyVault = this.applicationProperties.getAzure().getKeyVault();
        KeyVaultSecret kvSecret = getSecretClient().getSecret(keyVault.getCertificateName());
        if (Objects.isNull(kvSecret)) {
            return null;
        }

        return kvSecret;
    }

    public KeyVaultCertificateWithPolicy getCertificate() {
        KeyVaultCertificateWithPolicy kvCertificate = getCertificateClient().getCertificate(CERTIFICATE_NAME);
        if (Objects.isNull(kvCertificate)) {
            return null;
        }

        return kvCertificate;
    }

    private SecretClient getSecretClient() {
        log.info("connection to the keyVault");
        if (Objects.isNull(secretClient)) {
            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                    .tenantId(this.applicationProperties.getAzure().getTenantId())
                    .clientId(this.applicationProperties.getAzure().getKeyVault().getClientId())
                    .clientSecret(this.applicationProperties.getAzure().getKeyVault().getClientSecret())
                    .build();

            secretClient = new SecretClientBuilder()
                    .vaultUrl(this.applicationProperties.getAzure().getKeyVault().getUrl())
                    .credential(clientSecretCredential)
                    .buildClient();
        }
        return secretClient;
    }

    private CertificateClient getCertificateClient() {
        if (Objects.isNull(secretClient)) {
            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                    .tenantId(this.applicationProperties.getAzure().getTenantId())
                    .clientId(this.applicationProperties.getAzure().getKeyVault().getClientId())
                    .clientSecret(this.applicationProperties.getAzure().getKeyVault().getClientSecret())
                    .build();

            certificateClient = new CertificateClientBuilder()
                    .vaultUrl(this.applicationProperties.getAzure().getKeyVault().getUrl())
                    .credential(clientSecretCredential)
                    .buildClient();
        }
        return certificateClient;
    }

}
