package com.capgemini.tablet.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.apache.commons.codec.binary.Base64;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.model.CertificateDTO;
import java.io.ByteArrayInputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Objects;

@Mapper(config = DtoMapperConfig.class)
public interface CertificateMapper {

    CertificateMapper INSTANCE = Mappers.getMapper(CertificateMapper.class);

    @Mappings({ 
        @Mapping(source = "in.name", target = "certificateName"),
        @Mapping(source = "in.value", target = "base64EncodedCertificate"),
        @Mapping(source = "in", target = "expiration", qualifiedByName = "toMutableDateTime") 
    })
    CertificateDTO mapperVaultEntityToCSOEntity(KeyVaultSecret in);

    @Named("toMutableDateTime")
	default Long mapToMutableDateTime(KeyVaultSecret secret) {
		CertificateFactory certFactory;
		X509Certificate cert;

        byte[] encodedCert = Base64.decodeBase64(secret.getValue());
		ByteArrayInputStream inputStream = new ByteArrayInputStream(encodedCert);

		try {
			certFactory = CertificateFactory.getInstance("X.509");
			cert = (X509Certificate) certFactory.generateCertificate(inputStream);
			if (Objects.nonNull(cert) && Objects.nonNull(cert.getNotAfter())) {
                return cert.getNotAfter().getTime() / 1000;
			} else {
				return 32503679999l;// GMT: Tuesday 31 December 2999 23:59:59
			}
		} catch (CertificateException e) {
			return 32503679999l;
		}

	}

}