package com.capgemini.tablet.back.scheduled;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgemini.tablet.back.service.bus.OrchestreService;
import lombok.extern.slf4j.Slf4j;

/**
 * A scheduled task for processing subscriptions at specific intervals.
*/
@Component
@Slf4j
public class ProcessSubscriptionScheduledTask {

    @Autowired
	private OrchestreService orchestreService;

    /**
     * This method launch the processing of all tablets subscription to graph api
     *  ONLY TABLET LINKED TO A POI ARE TAKEN
    */
    @Scheduled(cron = "0 0 0 * * ?", zone = "Europe/Paris") // 12:00 AM midNight time 
	private void launchProcessSubscription() {
        log.info("Launch of the processing of the planning subscription for inActive TABLET");
        this.orchestreService.subscribeGraphApiAllTablet();
    }

}
