package com.capgemini.tablet.back.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import com.capgemini.tablet.back.config.DbConfig;
import com.capgemini.tablet.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@Table(name = "floor", indexes = { @Index(name = "IDX_MODIFIED_FLOOR", columnList = "modified_at") })
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Floor implements WithTitle {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Floor_Generator")
	@SequenceGenerator(name = "Floor_Generator", sequenceName = "Floor_Sequence")
	private Long id;

	@NotNull
	@Column(name = "floor_index", nullable = false)
	private Integer index;

	@ManyToOne
	@JoinColumn(name = "building_id")
	@JsonIgnore
	@ToString.Exclude
	private Building building;

	@Column(name = "building_id", updatable = false, insertable = false)
	private Long buildingId;

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

	@Column(name = "modified_at", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime() / 1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;

	@CollectionTable(name = "floor_attribute", joinColumns = @JoinColumn(name = "floor_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

}
