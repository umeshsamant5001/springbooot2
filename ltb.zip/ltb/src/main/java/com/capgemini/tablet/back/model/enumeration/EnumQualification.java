package com.capgemini.tablet.back.model.enumeration;

public enum EnumQualification {
    ORGANIZER, REQUIRED, OPTIONAL;
}
