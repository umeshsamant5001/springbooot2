package com.capgemini.tablet.back.security.jwt;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Objects;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.tablet.back.service.AzureKeyVaultService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SSLChecker {

    @Autowired
    AzureKeyVaultService keyVaultService;
    private String privateKey;
    private byte[] privateKeyBytes;
    public boolean validateSSLHeader(String sslHeader) {
        try {
            String publicKeyPEM="";
            Base64 b64 = new Base64();
                publicKeyPEM = sslHeader
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");
            if (Objects.isNull(privateKeyBytes)) {
                // get private key from key vault
                KeyVaultSecret pKey = keyVaultService.getPrivateKey();
                privateKey = pKey.getValue();
                String privateKeyOnly = StringUtils.substringBefore(privateKey, "BEGIN CERTIFICATE");
                privateKeyOnly = StringUtils.substring(privateKeyOnly, 0, -6);
                privateKey =
                    privateKeyOnly
                        .replace("-----BEGIN PRIVATE KEY-----", "")
                        .replaceAll(System.lineSeparator(), "")
                        .replace("-----END PRIVATE KEY-----", "");
                privateKeyBytes = privateKey.getBytes();
            }
            PKCS8EncodedKeySpec privateKeySpec1 = new PKCS8EncodedKeySpec(b64.decode(privateKeyBytes));
            KeyFactory kf1 = KeyFactory.getInstance("RSA");
            PrivateKey privKey1 = kf1.generatePrivate(privateKeySpec1);
            byte[] encodedPub = b64.decode(publicKeyPEM);
            X509EncodedKeySpec publicKeySpec1 = new X509EncodedKeySpec(encodedPub);
            KeyFactory pk1 = KeyFactory.getInstance("RSA");
            PublicKey publicKeyObj1 = pk1.generatePublic(publicKeySpec1);
            String file1 = "qwerty";
            byte[] fileBytes1 = file1.getBytes();
            if (!Objects.isNull(publicKeyObj1) && !Objects.isNull(privKey1)) {
                byte[] digitalSignature = signData(fileBytes1, privKey1);
                boolean verified;
                verified = verifySig(fileBytes1, publicKeyObj1, digitalSignature);
                return verified;
            }
            return false;
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }
    }

    public static byte[] signData(byte[] data, PrivateKey key) throws Exception {
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(key);
        signer.update(data);
        return (signer.sign());
    }

    public static boolean verifySig(byte[] data, PublicKey key, byte[] sig) throws Exception {
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initVerify(key);
        signer.update(data);
        return (signer.verify(sig));
    }
}
