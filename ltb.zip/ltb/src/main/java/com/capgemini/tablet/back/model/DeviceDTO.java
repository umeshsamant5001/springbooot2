package com.capgemini.tablet.back.model;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceStatus;
import com.capgemini.tablet.back.model.enumeration.EnumDeviceType;
import lombok.Data;

@Data
public class DeviceDTO {

	private String uuid;
	private FloorDTO floor;
	private String poiName;
	private Long lastChange;
	private EnumDeviceStatus status;
	private EnumDeviceType deviceType;
	private Map<String, String> attributes = new HashMap<>();

}
