package com.capgemini.tablet.back.model;

import com.capgemini.tablet.back.model.enumeration.EnumMeetingStatus;
import com.capgemini.tablet.back.model.enumeration.EnumStatus;

import lombok.Data;

@Data
public class MeetingDTO {
    private String id;

    private Long from;

    private Long to;

    private Long fromUtc;

    private Long toUtc;

    private EnumMeetingStatus checkStatus;

    private String room;

    private Floor floor;

    private Long floorId;

    private String poiName;

    private Long created;

    private Long modifiedAt;

    private Integer noshowCounter;

    private Boolean alertCheckIn;

    private Boolean pushAlert;

    // Tablet need this informations
    private AttendeeDTO booker;

    private EnumStatus status;

    private String subject;
    
    private String organizerEmail;

    private String organizerName;

    private Long createdDateTime;
    private String createdFrom;

}
