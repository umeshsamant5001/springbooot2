package com.capgemini.tablet.back.service;

import com.capgemini.tablet.back.config.ApplicationProperties;
import com.capgemini.tablet.back.config.FirebaseInitializer;
import com.capgemini.tablet.back.model.enumeration.EnumOsType;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.capgemini.tablet.utils.PushNotificationApnsUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.net.URI;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

/**
 * Service class responsible for sending push notifications to Android and iOS
 * devices.
 * It uses Firebase for Android and APNs (Apple Push Notification service) for
 * iOS.
 */

@Service
@Slf4j
public class PushNotificationService {

    @Autowired
    private FirebaseInitializer firebaseInitializer;

    @Autowired
    private ApplicationProperties applicationProperties;

    /**
     * Sends a push notification to a device based on the OS type.
     * 
     * @param token  the device token to which the notification should be
     *               sent
     * @param title  the title of the notification
     * @param body   the body content of the notification
     * @param osType the operating system type (ANDROID or IOS)
     * 
     */

    public void sendPushNotification(String token, String title, String body, EnumOsType osType) {
        try {
            if (osType == EnumOsType.IOS) {
                sendIosApnsPush(token, title, body);
            } else if (osType == EnumOsType.ANDROID) {
                sendAndroidPush(title, body, token);
            } else {
                log.warn("Unknown OS type for token: {}", token);
            }
        } catch (Exception e) {
            log.error("Push failed for token {}: {}", token, e.getMessage(), e);
        }
    }

    /**
     * Sends a push notification to an Android device using Firebase Cloud
     * Messaging.
     * 
     * @param title the title of the notification
     * @param body  the body content of the notification
     * @param token the device token
     *
     */

    private void sendAndroidPush(String title, String body, String token) {
        Map<String, String> data = Map.of(
                "title", title,
                "body", body,
                "style", "bigtext");

        AndroidConfig androidConfig = AndroidConfig.builder()
                .setPriority(AndroidConfig.Priority.HIGH)
                .putAllData(data)
                .build();

        Message message = Message.builder()
                .setAndroidConfig(androidConfig)
                .setToken(token)
                .build();

        try {
            firebaseInitializer.initialize();
            String response = FirebaseMessaging.getInstance(FirebaseApp.getInstance("androidApp")).send(message);
            log.info("[PUSH][ANDROID] Sent to token: {}, Response: {}", token, response);
        } catch (FirebaseMessagingException e) {
            log.warn("[PUSH][ANDROID] Failed for token: {} | Reason: {}", token, e.getMessage());
        }
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * 
     * @param deviceToken the device token
     * @param title       the title of the notification
     * @param body        the body content of the notification
     * 
     */

    private void sendIosApnsPush(String deviceToken, String title, String body) {
        String payload;
        try {
            payload = buildApnsJsonPayload(title, body);
        } catch (IOException e) {
            log.error("APNs Payload build error", e);
            return;
        }

        String jwtToken;
        try {
            jwtToken = PushNotificationApnsUtil.generateToken(
                    applicationProperties.getPushNotificationApns().getTeamId(),
                    applicationProperties.getPushNotificationApns().getKeyId(),
                    applicationProperties.getPushNotificationApns().getBase64PrivateKey());
        } catch (Exception e) {
            log.error("JWT generation failed", e);
            return;
        }

        try {
            String response = sendApnsNotification(jwtToken, deviceToken, payload);
            log.info("[PUSH][IOS] Sent to token: {} | Response: {}", deviceToken, response);
        } catch (Exception e) {
            log.warn("[PUSH][IOS] Failed to send to {}: {}", deviceToken, e.getMessage());
        }
    }

    /**
     * Sends the actual HTTP request to APNs with the given JWT token and payload.
     * 
     * @param jwtToken    the JWT token for APNs authentication
     * @param deviceToken the device token
     * @param payload     the JSON payload of the notification
     * @return the response body from APNs
     * @throws Exception if the HTTP request fails
     * 
     */

    private String sendApnsNotification(String jwtToken, String deviceToken, String payload) throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(
                        applicationProperties.getPushNotificationApns().getApnsHost() + "/3/device/" + deviceToken))
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .setHeader("authorization", "bearer " + jwtToken)
                .setHeader("apns-topic", applicationProperties.getPushNotificationApns().getApnsTopic())
                .setHeader("apns-push-type", "alert")
                .setHeader("Content-Type", "application/json")
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }

    /**
     * Builds the JSON payload for an APNs push notification.
     * 
     * @param title   the title of the notification
     * @param message the body content of the notification
     * @return the JSON string payload
     * @throws IOException if JSON serialization fails
     * 
     */

    private String buildApnsJsonPayload(String title, String message) throws IOException {
        Map<String, Object> aps = Map.of(
                "alert", Map.of("title", title, "body", message),
                "sound", "default");
        return new com.fasterxml.jackson.databind.ObjectMapper()
                .writeValueAsString(Map.of("aps", aps));
    }
}
