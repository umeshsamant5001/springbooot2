# GIT_GA_TPM_CRES_SMARTOFFICE
## Table of contents
1. [General information](#general-information)
2. [Technologies](#technologies)
3. [Installation](#installation)
3. [Compilation](#compilation)
***
### General information
Project REBUILD of the SmartOffice project
***
### Technologies
List of technologies used in the project :
* [Java](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html) Version 17
* [Spring Boot](https://docs.spring.io/spring-boot/docs/2.7.3/) Version 2.7.3
* [Hibernate](https://hibernate.org/orm/documentation/5.6/) Version 5.6.10
* [Jhipster](https://www.jhipster.tech/2022/09/02/jhipster-release-7.9.3.html) Version 7.9.3
***
### Installation
To install the project, you can clone it with an SSH key
```
$ git clone git@github.capgemini.com:Capgemini-Group-IT/GIT_GA_TPM_CRES_SMARTOFFICE.git
```
Use the versions of the technologies indicated above.
***
### Compilation
list of environments :
* local
* develop
* uat
* sit
* production
* perf

To compile :
- Use the following command : `./mvnw -P {you environments}`
- Without testing, use the following command : `./mvnw -P {you environments} -DskipTests`
- Without using API authentication : `./mvnw -P {you environments} -D"spring-boot.run.profiles"="{you environments},noAuth"`