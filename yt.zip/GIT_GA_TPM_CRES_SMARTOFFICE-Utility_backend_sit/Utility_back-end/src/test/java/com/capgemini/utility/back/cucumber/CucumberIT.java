package com.capgemini.utility.back.cucumber;

import com.capgemini.utility.back.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
