package com.capgemini.utility.back.service;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;

import org.junit.jupiter.api.Test;

class SMTPSendMailTest {

    // @Test
    // void resolveAttachmentPathRejectsNullFile() {
    //     SMTPSendMail mailService = new SMTPSendMail();

    //     assertThrows(SecurityException.class, () -> mailService.resolveAttachmentPath(null));
    // }

    // @Test
    // void resolveAttachmentPathRejectsPathTraversalStyleInput() {
    //     SMTPSendMail mailService = new SMTPSendMail();

    //     assertThrows(SecurityException.class, () -> mailService.resolveAttachmentPath(new File("../report.xlsx")));
    // }
}
