package com.capgemini.utility.back.model;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.capgemini.utility.back.config.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "meeting_details")
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class MeetingDetails {

    @Id
    @Column(name = "id")
    private String id;

    @OneToMany(mappedBy = "meetingDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<MeetingAttendee> attendees = new ArrayList<>();

    @OneToMany(mappedBy = "meetingDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Locations> locations = new ArrayList<>();

    @Column(name = "totalbookingduration")
    private Long totalBookingDuration;

    @Column(name = "organizer_name")
    private String organizerName;

    @Column(name = "organizer_email")
    private String organizerEmail;

    @Column(name = "created_datetime")
    private OffsetDateTime createdDatetime;

    @Column(name = "start_date")
    private String startDate;

    @Column(name = "end_date")
    private String endDate;

    @Column(name = "start_timezone")
    private String startTimezone;

    @Column(name = "end_timezone")
    private String endTimezone;

    @Column(name = "start_timems")
    private Long startTimems;

    @Column(name = "end_timems")
    private Long endTimems;

    @Column(name = "duration")
    private Long duration;

    @Column(name = "isallday")
    private Boolean allDay;

    @Column(name = "iscancelled")
    private Boolean cancelled;

    @Column(name = "isorganizer")
    private Boolean organizer;

    @Column(name = "type")
    private String type;

    @Column(name = "isonlinemeeting")
    private Boolean onlineMeeting;
    
    @Column(name = "recurrence")
    private String recurrence;
    
}

