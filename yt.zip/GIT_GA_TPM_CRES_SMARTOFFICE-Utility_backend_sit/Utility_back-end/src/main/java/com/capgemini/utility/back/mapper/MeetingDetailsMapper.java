package com.capgemini.utility.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.MeetingDetails;
import com.capgemini.utility.back.model.MeetingDetailsDTO;

@Mapper(config = DtoMapperConfig.class)
public interface MeetingDetailsMapper {

    MeetingDetailsMapper INSTANCE = Mappers.getMapper(MeetingDetailsMapper.class);

    MeetingDetails meetingDetailsDTOToMeetingDetails(MeetingDetailsDTO in);
    
}
