package com.capgemini.utility.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.SensorDataValues;
import com.capgemini.utility.back.model.SensorDataValuesDTO;

@Mapper(config = DtoMapperConfig.class)
public interface SensorDataValuesMapper {

    SensorDataValuesMapper INSTANCE = Mappers.getMapper(SensorDataValuesMapper.class);

    SensorDataValues sensorDataValuesDTOToSensorDataValues(SensorDataValuesDTO in);
    SensorDataValuesDTO sensorDataValuesToSensorDataValuesDTO(SensorDataValues in);

}
