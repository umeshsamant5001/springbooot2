package com.capgemini.utility.back.model;

public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}