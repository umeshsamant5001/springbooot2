package com.capgemini.utility.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;

@Data
@Entity
@Table(name = "floor_map_scaling", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"cdm_floor_key_id"})
})
public class FloorMapScaling {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "floor_map_scaling_gen")
    @SequenceGenerator(name = "floor_map_scaling_gen", sequenceName = "floor_map_scaling_seq")
    private Long id;

    @Column(name = "cdm_floor_key_id", nullable = false)
    private Long cdmFloorKeyId;

    @Column(name = "floor_id", nullable = false)
    private Long floorId;

    @Column(name = "scaling_ratio", nullable = false)
    private Float scalingRatio;
}
