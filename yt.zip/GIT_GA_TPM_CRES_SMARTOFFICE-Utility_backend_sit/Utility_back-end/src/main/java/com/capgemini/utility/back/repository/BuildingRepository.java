package com.capgemini.utility.back.repository;
import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

    long countBySiteId(@Param("siteId") Long siteId);

	List<Building> findAllBySiteId(@Param("siteId") Long siteId);

    Building findByFloorsId(@Param("floorId") Long floorId);

	Building findByCdmKeyId(@Param("cdmKeyId")  Long cdmKeyId);

	@RestResource(exported = false)
	@Query(value = "select building.* from building building where id in"
			+ "(select building_id from building_attribute where att_value = :asset_id) limit 1", nativeQuery = true)
	Building findByAssetId(@Param("asset_id") String asset_id);

    List<Building> findAllBySecuredTrue();

	/** To optimize query, we force the use of a JOIN for the OpeningHours */
	@Query("SELECT building FROM Building building LEFT JOIN FETCH building.information.openingHours")
    List<Building> findAll();

	@Query("SELECT building.cdmKeyId, building.titleEn AS name FROM Building building WHERE building.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);

	@Query("SELECT INDEX(attributes), attributes FROM Building building INNER JOIN building.attributes attributes WHERE building.id = :buildingId")
	List<Tuple> getAttributesById(@Param("buildingId") Long buildingId);

	@Query(value = "SELECT country.title_en AS country_title, city.title_en AS city_title, site.title_en AS site_title, "
		+ " building.title_en AS building_title, building.deployed, "
		+ " building.secured, alertBuilding.att_value AS alert_checking, opening_hours.opening, opening_hours.closing, "
		+ " daysLimit.att_value AS days_limit "
		+ " FROM country INNER JOIN city ON (country.id = city.country_id) INNER JOIN site ON (city.id = site.city_id) "
		+ " INNER JOIN building ON (site.id = building.site_id) LEFT JOIN opening_hours ON (building.id_opening_hours = opening_hours.id) "
		+ " LEFT JOIN building_attribute AS daysLimit ON (building.id = daysLimit.building_id AND daysLimit.att_key = 'daysLimit') "
		+ " LEFT JOIN building_attribute AS alertBuilding ON (building.id = alertBuilding.building_id AND alertBuilding.att_key = 'checkin.alert.building') "
		+ " ORDER BY country.title_en, city.title_en, site.title_en, building.title_en", nativeQuery = true)
	List<List<String>> getExportAll();

	 /** To optimize query, we force the use of a JOIN for the OpeningHours */
	 @Query("SELECT building FROM Building building LEFT JOIN FETCH building.information.openingHours WHERE building.deployed = 1")
	 List<Building> findAllByDeployedTrue();
 
}
