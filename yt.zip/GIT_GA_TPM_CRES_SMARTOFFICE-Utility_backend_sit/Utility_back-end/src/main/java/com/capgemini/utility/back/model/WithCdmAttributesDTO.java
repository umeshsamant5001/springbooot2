package com.capgemini.utility.back.model;

import java.util.Map;

public interface WithCdmAttributesDTO {
    Long getId();

    Map<String, String> getAttributes();

    void setAttributes(Map<String, String> attributes);

    Map<String, String> getCdmAttributes();

    void setCdmAttributes(Map<String, String> cdmAttributes);
}
