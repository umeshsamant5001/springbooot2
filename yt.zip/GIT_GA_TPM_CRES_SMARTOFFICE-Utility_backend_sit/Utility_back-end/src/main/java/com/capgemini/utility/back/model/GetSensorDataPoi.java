package com.capgemini.utility.back.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "getSensorDataPoi")
public class GetSensorDataPoi {
    @Id
    @Column(name = "poi_id")
    private Long poiId;
    @Column(name = "poi_name")
    private String poiName;
    @Column(name = "poi_title")
    private String poiTitle;
    @Column(name = "space_type_name")
    private String spaceTypeName;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "capacity")
    private String capacity;
    @Column(name = "email")
    private String email;

    @ManyToOne
	@JoinColumn(name = "floor_id")
	@JsonIgnore
	private GetSensorDataFloor getSensorDataFloor;

}
