package com.capgemini.utility.back.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.utility.back.model.Site;
import com.capgemini.utility.back.repository.SiteRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SiteService {

	@Autowired
	private SiteRepository siteRepository;

    @Transactional
    public Site getSite(Long siteId) {
		try {
			Site site = siteRepository.findById(siteId).orElse(null);
			if(Objects.nonNull(site)) {
				site.getBuildings();
			}
			return site;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site by id", ex);
			throw new IllegalStateException("Unable to retrieve site");
		}
	}


	public Site createSite(Site site) {
		site.setModifiedAt((new Date()).getTime() / 1000);
		Site postedSite = null;
		try {
			postedSite = this.siteRepository.save(site);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return postedSite;

	}

	public Site updateSite(Long siteId, Site site) {
		try {
			Site oldSite = siteRepository.findById(siteId).orElse(null);
			if (Objects.isNull(oldSite)) {
				return null;
			}

			oldSite.setCdmKeyId(site.getCdmKeyId());
			oldSite.setAttributes(site.getAttributes());
        	oldSite.setTitleEn(site.getTitleEn());
        	oldSite.setTitleFr(site.getTitleFr());
			oldSite.setModifiedAt((new Date()).getTime() / 1000);

			return siteRepository.saveAndFlush(oldSite);
		} catch (DataAccessException ex) {
			log.error("Failed to update site", ex);
			throw new IllegalStateException("Unable to update site");
		}
	}


	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return this.siteRepository.getNameByCmdKeyId(cdmKeyIdList)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, Long.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site names by cmd key id", ex);
			throw new IllegalStateException("Unable to retrieve site names");
		}
	}


	public Map<String, String> getAttributesById(Long siteId) {
		try {
			return this.siteRepository.getAttributesById(siteId)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, String.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site attributes by id", ex);
			throw new IllegalStateException("Unable to retrieve site attributes");
		}
	}


    public Long countByCityId(Long cityId) {
        return this.siteRepository.countByCityId(cityId);
    }

	public Site save(Site site) {
		return this.siteRepository.saveAndFlush(site);
	}

	public List<Site> getAll() {
		return this.siteRepository.findAll();
	}

	public void deleteById(Long siteId) {
		try {
			this.siteRepository.deleteById(siteId);
		} catch (DataAccessException ex) {
			log.error("Failed to delete site by id", ex);
			throw new IllegalStateException("Unable to delete site");
		}
	}

}
