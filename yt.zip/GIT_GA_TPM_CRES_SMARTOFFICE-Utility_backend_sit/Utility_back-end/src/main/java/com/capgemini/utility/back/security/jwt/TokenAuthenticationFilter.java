package com.capgemini.utility.back.security.jwt;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.capgemini.utility.back.repository.AuthenticationExceptionRepository;
import com.google.gson.JsonObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private Environment environment;

    @Autowired
    private AuthenticationExceptionRepository authenticationExceptionRepository;

    @Autowired
    private JWTSignatureValidation jwtSignatureValidation;

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        // FIX: Add HSTS header
        response.setHeader("Strict-Transport-Security",
                "max-age=31536000; includeSubDomains");

        String requestUri = request.getRequestURI();

        // Skip the token filter for //api/device/sensorData endpoint
        if (requestUri.matches("^/api/device/sensorData(/.*)?$")) {
            chain.doFilter(request, response);
            return;
        }
        try {
            extractAndValidateToken(request, response);
        } catch (AuthFailureException e) {
            // authentication failed, build and return a 401 response with error json body
            sendErrorResponse(HttpStatus.UNAUTHORIZED, response, e);
            return;
        }

        chain.doFilter(request, response);
    }

    /**
     * Decrypt and validate JWT token and store the user to security context
     *
     * @param request
     */
    private void extractAndValidateToken(HttpServletRequest request, HttpServletResponse response) {

        if (this.environment.acceptsProfiles(Profiles.of("noAuth"))) {
            return;
        }

        if (Objects.isNull(jwtSignatureValidation)) {
            jwtSignatureValidation = new JWTSignatureValidation();
        }
        String authToken = jwtSignatureValidation.getAuthHeader(request);

        if (Objects.isNull(authToken)) {
            throw new AuthFailureException(String.format("No token found from request %s", request.getRequestURI()));
        }
        authToken = authToken.replaceFirst("Bearer ", "");
        //Below If else block need to be used once we get client id and client secret from OP team:
        if (request.getRequestURI().startsWith("/api/pushnotificationext")) {
            jwtSignatureValidation.validateWithPingIdForExternalApp(authToken);
        } else {
            jwtSignatureValidation.validateWithPingId(authToken);
        }

    }

    private void sendErrorResponse(HttpStatus status, HttpServletResponse response, AuthFailureException ex) {

        authenticationExceptionRepository.save(new AuthenticationException(
                HttpStatus.UNAUTHORIZED.value(),
                ex.getErrorCode(),
                ex.getMessage(),
                System.currentTimeMillis() / 1000));
        response.setStatus(status.value());
        response.setContentType("application/json");

        // IMPORTANT FIX (for full compliance)
        response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");

        try {
            response.getWriter().write(buildErrorJson(ex).toString());
        } catch (IOException e) {
            log.error(String.format("Authentication: failed to build error json response: %s", e.getMessage()));
        }
    }

    private JsonObject buildErrorJson(AuthFailureException exception) {
        log.error("Authentication failed", exception);
        JsonObject json = new JsonObject();
        json.addProperty("errorCode", exception.getErrorCode());
        json.addProperty("message", "Authentication failed");
        json.addProperty("exception", "AUTHENTICATION_ERROR");

        return json;
    }


    /**
     * Manage if we bypass the authentication on specific env requests.
     *
     * @param request
     * @return boolean
     */
    private boolean bypassAuth(HttpServletRequest request) {
        return (Arrays.stream(environment.getActiveProfiles()).anyMatch("dev"::equals) &&
                request.getRequestURI().equals("/api/auth/token") && // token generation for local tests only
                "GET".equals(request.getMethod()));
    }
}
