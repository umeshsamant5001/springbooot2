package com.capgemini.utility.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.PushNotificationGeneralSendHistory;

@Repository
public interface PushNotificationGeneralHistoryRepository extends JpaRepository<PushNotificationGeneralSendHistory, Long> {
    
}
