package com.capgemini.utility.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.capgemini.utility.back.model.SensorDataSP;
import com.capgemini.utility.back.model.SensorDataSPDTO;

@Mapper(config = DtoMapperConfig.class )
public interface SensorDataSPMapper {

    SensorDataSPMapper INSTANCE = Mappers.getMapper(SensorDataSPMapper.class);
    
    SensorDataSPDTO sensorDataSPToSensorDataSPDTO(SensorDataSP in);

    SensorDataSP sensorDataSPDTOToSensorDataSP(SensorDataSPDTO in);

}
