package com.capgemini.utility.back.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.AccessDeniedException;

import com.capgemini.utility.back.config.ApplicationProperties;
import com.capgemini.utility.back.config.Constants;
import com.capgemini.utility.back.mapper.PushNotificationGeneralMapper;
import com.capgemini.utility.back.model.AppRegistrationManagement;
import com.capgemini.utility.back.model.PushNotificationGeneralDTO;
import com.capgemini.utility.back.model.PushNotificationGeneral;
import com.capgemini.utility.back.model.PushNotificationGeneralSendHistory;
import com.capgemini.utility.back.repository.PushNotificationGeneralRepository;
import com.capgemini.utility.back.repository.PushNotificationGeneralHistoryRepository;
import com.capgemini.utility.back.security.AuthoritiesConstants;
import com.capgemini.utility.back.security.SecurityUtils;
import com.capgemini.utility.back.utils.PushNotificcationRevampUtil;

import com.google.api.core.ApiFuture;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Value;


@Service
@Slf4j
@Validated
public class PushNotificationGeneralService {

	@Autowired
	private PushNotificationGeneralRepository generalPushNotificationRepository;

    @Autowired
    private PushNotificationGeneralHistoryRepository historyRepo; 

    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private ApplicationProperties applicationProperties;

    final Integer MAX_RETRY = 3;
    private static final String CONFIG_PATH = "application.notificationgeneralchron.push";
    
    /**
     * Retrieves a PushNotificationGeneral entity by its ID.
     * @param id the ID of the push notification to retrieve
     * @return the PushNotificationGeneral entity
     * @throws ResourceNotFoundException if no notification is found with the given ID
    */
    public PushNotificationGeneral findById(Long id) {
        Long safeId = Long.valueOf(String.valueOf(id));
        try {
            PushNotificationGeneral generalPushNotification = generalPushNotificationRepository.findByIdAndDataRecivedFrom(safeId, Constants.SMARTOFFICE)
            .orElseThrow(() -> new ResourceNotFoundException("ExternalPushNotification not found with existing notification ID :: " + safeId));
            return generalPushNotification;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve push notification by id", ex);
            throw new IllegalStateException("Unable to retrieve push notification");
        }
    }   
        


    /**
     * Saves general push notification data to the database.    
     * @param pushNotificationDTO the DTO containing push notification details
     * @return the saved push notification as a DTO
    */
    public PushNotificationGeneralDTO saveGeneralPushNotificationData(
            @NotBlank @Size(max = 255) @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$") String title,
            @NotBlank @Size(max = 2000) @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$") String body,
            @Size(max = 50) @Pattern(regexp = "^[0-9T:\\-\\s/.]*$") String notificationscheduledDateTime,
            @NotEmpty List<@NotBlank @Email @Size(max = 255) String> emails) {
        enforceAuthorizedWriteAccess();

        PushNotificationGeneralUpsertDTO safeUpsertDTO = buildSafeUpsertDTO(title, body, notificationscheduledDateTime, emails);

        String normalizedTitle = normalizeValue(safeUpsertDTO.getTitle());
        String normalizedBody = normalizeValue(safeUpsertDTO.getBody());
        String normalizedSchedule = normalizeValue(safeUpsertDTO.getNotificationscheduled_Date_Time());
        List<String> normalizedEmails = normalizeEmails(safeUpsertDTO.getEmails());
        List<String> authorizedEmails = enforceAuthorizedEmailScope(normalizedEmails);

        PushNotificationGeneral pushNotification = buildSafeEntityForPersistence(
            null,
            normalizedTitle,
            normalizedBody,
            normalizedSchedule,
            authorizedEmails,
            Long.valueOf(String.valueOf((new Date()).getTime() / 1000))
        );

        PushNotificationGeneral savedPushNotification = generalPushNotificationRepository.save(pushNotification);
        PushNotificationGeneralDTO generalPushNotificationDTO = PushNotificationGeneralMapper.INSTANCE.generalPushNotificationToGeneralPushNotificationDTO(savedPushNotification);
		return generalPushNotificationDTO;
    }        
    
    
    /**
     * Asynchronously sends scheduled push notifications.
     * Marks notifications as sent and logs any errors encountered.
    */ 
    @Async
    @Transactional
    public void sendNotificationFromSchedular(){
        log.info(" Started From Scheduler");
        List<PushNotificationGeneral> notificationList =  generalPushNotificationRepository.findtAllReadyToSenfNoifications();
        for(PushNotificationGeneral notification: notificationList){          
            
            notification.setNotificationSentBy(Constants.SCHEDULER);
            notification.setNotificationSent(Boolean.TRUE);
           
            try{
                sendGeneralPushNotification(notification);
            }
            catch(FirebaseMessagingException fbEx){
                log.error("A error occured while sending the pushnotification", fbEx);                
             }            
             generalPushNotificationRepository.save(notification);
        }                   
       
    }    
    
    /**
     * Retrieves all push notifications from the database.
     * @return list of all push notifications
    */
    public List<PushNotificationGeneral> getAllPushNotifications() {
        try {
			return generalPushNotificationRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve all push notifications", ex);
            throw new IllegalStateException("Unable to retrieve push notifications");
        }
    } 

    
    /**
     * Deletes a push notification by its ID.
     * @param id the ID of the notification to delete
    */
    public void deletePushNotification(@Valid PushNotificationGeneral existingPushNotification) {
        enforceAuthorizedWriteAccess();

        if (Objects.isNull(existingPushNotification) || Objects.isNull(existingPushNotification.getId())) {
            throw new IllegalArgumentException("id must be greater than 0");
        }
        Long persistedId = Long.valueOf(String.valueOf(existingPushNotification.getId()));
        generalPushNotificationRepository.deleteById(persistedId);

    }        
    
        
    /**
     * Updates an existing push notification and returns the updated DTO.
     * @param PushNotification the updated push notification entity
     * @return the updated push notification as a DTO
    */
    public PushNotificationGeneralDTO updatePushNotification(
            @Valid PushNotificationGeneral existingPushNotification,
            @NotBlank @Size(max = 255) @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$") String title,
            @NotBlank @Size(max = 2000) @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$") String body,
            @Size(max = 50) @Pattern(regexp = "^[0-9T:\\-\\s/.]*$") String notificationscheduledDateTime,
            @NotEmpty List<@NotBlank @Email @Size(max = 255) String> emails) {
        enforceAuthorizedWriteAccess();

        if (Objects.isNull(existingPushNotification) || Objects.isNull(existingPushNotification.getId()) || existingPushNotification.getId() < 1L) {
            throw new IllegalArgumentException("id must be greater than 0");
        }
        PushNotificationGeneralUpsertDTO safeUpsertDTO = buildSafeUpsertDTO(title, body, notificationscheduledDateTime, emails);
        String normalizedTitle = normalizeValue(safeUpsertDTO.getTitle());
        String normalizedBody = normalizeValue(safeUpsertDTO.getBody());
        String normalizedSchedule = normalizeValue(safeUpsertDTO.getNotificationscheduled_Date_Time());
        List<String> normalizedEmails = normalizeEmails(safeUpsertDTO.getEmails());
        List<String> authorizedEmails = enforceAuthorizedEmailScope(normalizedEmails);
        PushNotificationGeneral safeEntity = buildSafeEntityForPersistence(
            Long.valueOf(String.valueOf(existingPushNotification.getId())),
            normalizedTitle,
            normalizedBody,
            normalizedSchedule,
            authorizedEmails,
            existingPushNotification.getCreatedDateTime()
        );

        safeEntity.setNotificationSentBy(Objects.nonNull(existingPushNotification.getNotificationSentBy())
            ? new String(existingPushNotification.getNotificationSentBy())
            : null);
        safeEntity.setNotificationStaus(Objects.nonNull(existingPushNotification.getNotificationStaus())
            ? new String(existingPushNotification.getNotificationStaus())
            : null);
        safeEntity.setNotificationSent(Objects.nonNull(existingPushNotification.getNotificationSent())
            ? Boolean.valueOf(String.valueOf(existingPushNotification.getNotificationSent()))
            : null);
        PushNotificationGeneral updatedGeneralPushNotification = generalPushNotificationRepository.save(safeEntity);

        PushNotificationGeneralDTO generalPushNotificationDTO = new PushNotificationGeneralDTO();
        generalPushNotificationDTO.setId(updatedGeneralPushNotification.getId());
        generalPushNotificationDTO.setTitle(updatedGeneralPushNotification.getTitle());
        generalPushNotificationDTO.setEmails(updatedGeneralPushNotification.getEmails());
        generalPushNotificationDTO.setBody(updatedGeneralPushNotification.getBody());
        generalPushNotificationDTO.setNotificationscheduled_Date_Time(updatedGeneralPushNotification.getNotificationscheduled_Date_Time());
        return generalPushNotificationDTO;
    }



    private void enforceAuthorizedWriteAccess() {
        if (!SecurityUtils.isAuthenticated() ||
            SecurityUtils.hasCurrentUserNoneOfAuthorities(AuthoritiesConstants.ADMIN, AuthoritiesConstants.USER)) {
            throw new AccessDeniedException("Access denied for push notification write operation");
        }
    }

    public PushNotificationGeneral findByIdForAuthorizedWrite(@Positive @Min(1) Long id) {
        enforceAuthorizedWriteAccess();
        Long safeId = Long.valueOf(String.valueOf(id));
        if (SecurityUtils.hasCurrentUserThisAuthority(AuthoritiesConstants.ADMIN)) {
            return findById(safeId);
        }
        String currentUserEmail = getCurrentUserEmailOrThrow();
        try {
            return generalPushNotificationRepository.findByIdAndDataRecivedFromAndEmail(safeId, Constants.SMARTOFFICE, currentUserEmail)
                .orElseThrow(() -> new AccessDeniedException("Access denied for push notification id :: " + safeId));
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve push notification for authorized user", ex);
            throw new IllegalStateException("Unable to retrieve push notification");
        }
    }


    private String getCurrentUserEmailOrThrow() {
        String currentUserLogin = SecurityUtils.getCurrentUserLogin()
            .map(String::valueOf)
            .map(String::trim)
            .orElseThrow(() -> new AccessDeniedException("Access denied for push notification write operation"));
        if (currentUserLogin.isEmpty() || currentUserLogin.length() > 255) {
            throw new AccessDeniedException("Access denied for push notification write operation");
        }
        return new String(currentUserLogin);
    }

    private List<String> enforceAuthorizedEmailScope(List<String> emails) {
        if (SecurityUtils.hasCurrentUserThisAuthority(AuthoritiesConstants.ADMIN)) {
            return emails;
        }
        String currentUserEmail = getCurrentUserEmailOrThrow();
        if (Objects.isNull(emails) || emails.isEmpty()) {
            throw new AccessDeniedException("Access denied for push notification write operation");
        }
        boolean containsCurrentUser = emails.stream()
            .filter(Objects::nonNull)
            .map(String::trim)
            .anyMatch(email -> email.equalsIgnoreCase(currentUserEmail));
        if (!containsCurrentUser) {
            throw new AccessDeniedException("Access denied for push notification write operation");
        }
        List<String> scopedEmails = new ArrayList<>();
        scopedEmails.add(new String(currentUserEmail));
        return scopedEmails;
    }


    private PushNotificationGeneralUpsertDTO buildSafeUpsertDTO(String title, String body, String notificationscheduledDateTime, List<String> emails) {
        String safeTitle = Objects.nonNull(title) ? new String(String.valueOf(title)) : null;
        String safeBody = Objects.nonNull(body) ? new String(String.valueOf(body)) : null;
        String safeSchedule = Objects.nonNull(notificationscheduledDateTime) ? new String(String.valueOf(notificationscheduledDateTime)) : null;
            List<String> safeEmails = Objects.isNull(emails)
                ? null
                : emails.stream()
                    .filter(Objects::nonNull)
                    .map(email -> new String(String.valueOf(email)))
                    .collect(Collectors.toList());
        PushNotificationGeneralUpsertDTO safeUpsertDTO = PushNotificationGeneralUpsertDTO.builder()
            .title(safeTitle)
            .body(safeBody)
            .notificationscheduled_Date_Time(safeSchedule)
            .emails(safeEmails)
            .build();
        validatePushNotificationInput(safeUpsertDTO);
        return safeUpsertDTO;
    }

    private void validatePushNotificationInput(PushNotificationGeneralUpsertDTO pushNotificationDTO) {


        if (Objects.isNull(pushNotificationDTO)) {
            throw new IllegalArgumentException("Push notification payload is required");
        }
        validateText(pushNotificationDTO.getTitle(), 255, true, "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$", "Invalid title");
        validateText(pushNotificationDTO.getBody(), 2000, true, "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$", "Invalid body");
        validateText(pushNotificationDTO.getNotificationscheduled_Date_Time(), 50, false, "^[0-9T:\\-\\s/.]*$", "Invalid schedule date time");
        validateEmails(pushNotificationDTO.getEmails());
    }


    private void validateText(String value, int maxLength, boolean required, String pattern, String errorMessage) {
        if (Objects.isNull(value)) {
            if (required) {
                throw new IllegalArgumentException(errorMessage);
            }
            return;
        }
        String validated = String.valueOf(value);
        if (required && validated.trim().isEmpty()) {
            throw new IllegalArgumentException(errorMessage);
        }
        if (validated.length() > maxLength || !validated.matches(pattern)) {
            throw new IllegalArgumentException(errorMessage);
        }
        // Defense-in-depth: explicitly reject known SQL injection sequences
        if (containsSqlInjectionPattern(validated)) {
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Returns true if the value contains common SQL injection sequences.
     * Used as a defense-in-depth blocklist alongside the whitelist @Pattern constraints.
     */
    private boolean containsSqlInjectionPattern(String value) {
        String lower = value.toLowerCase(Locale.ROOT);
        return lower.contains("'--")
            || lower.contains(";--")
            || (lower.contains("/*") && lower.contains("*/"))
            || lower.contains("' or '")
            || lower.contains("' and '")
            || (lower.contains("union") && lower.contains("select"))
            || lower.contains("exec(")
            || lower.contains("execute(")
            || lower.contains("xp_");
    }

    private void validateEmails(List<String> emails) {
        if (Objects.isNull(emails) || emails.isEmpty()) {
            throw new IllegalArgumentException("Emails cannot be empty");
        }
        emails.stream().
        forEach(email -> {
            if (Objects.isNull(email)) {
                throw new IllegalArgumentException("Invalid email");
            }
            String validatedEmail = String.valueOf(email).trim();
            if (validatedEmail.isEmpty() || validatedEmail.length() > 255 || !validatedEmail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
                throw new IllegalArgumentException("Invalid email");
            }
        });
    }

    private String normalizeValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        // Sanitize: strip control characters and SQL injection sequences as defense-in-depth
        return String.valueOf(value).trim()
            .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "")  // strip control characters
            .replaceAll("(?i)/\\*[\\s\\S]*?\\*/", "")                    // strip SQL block comments
            .replaceAll("'\\s*--", "'");                                   // neutralise SQL inline comment injection
    }

    private List<String> normalizeEmails(List<String> emails) {
        if (Objects.isNull(emails)) {
            return null;
        }
        List<String> normalizedEmails = new ArrayList<>();
        emails.stream().
        filter(Objects::nonNull).
        forEach(email -> {
            // Sanitize: strip control characters as defense-in-depth
            normalizedEmails.add(new String(String.valueOf(email).trim()
                .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "")));
        });
        return normalizedEmails;
    }

    private PushNotificationGeneral buildSafeEntityForPersistence(Long id, String title, String body,
            String notificationscheduledDateTime, List<String> emails, Long createdDateTime) {
        PushNotificationGeneral safeEntity = new PushNotificationGeneral();
        safeEntity.setId(Objects.nonNull(id) ? Long.valueOf(String.valueOf(id)) : null);
        safeEntity.setTitle(Objects.nonNull(title) ? new String(title) : null);
        safeEntity.setBody(Objects.nonNull(body) ? new String(body) : null);
        safeEntity.setNotificationscheduled_Date_Time(Objects.nonNull(notificationscheduledDateTime)
            ? new String(notificationscheduledDateTime)
            : null);
        safeEntity.setCreatedDateTime(Objects.nonNull(createdDateTime)
            ? Long.valueOf(String.valueOf(createdDateTime))
            : null);
        safeEntity.setDataRecivedFrom(new String(Constants.SMARTOFFICE));
        if (Objects.nonNull(emails)) {
            List<String> safeEmails = new ArrayList<>();
            emails.stream().filter(Objects::nonNull).forEach(email -> safeEmails.add(new String(email)));
            safeEntity.setEmails(safeEmails);
        } else {
            safeEntity.setEmails(null);
        }
        return safeEntity;
    }


    @Value
    @Builder
    public static class PushNotificationGeneralUpsertDTO {

        @NotBlank(message = "Title is required")
        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$")
        String title;

        @NotBlank(message = "Body is required")
        @Size(max = 2000)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$")
        String body;

        @Size(max = 50)
        @Pattern(regexp = "^[0-9T:\\-\\s/.]*$")
        String notificationscheduled_Date_Time;

        @NotEmpty(message = "Emails cannot be empty")
        List<@NotBlank @Email @Size(max = 255) String> emails;
    }
        
    /**
     * Sends a general push notification to all registered devices for the given notification.
     * Handles both Android and iOS devices and logs success or failure
     * @param notification the push notification to send
     * @throws FirebaseMessagingException if sending fails
    */
    @Transactional
    public void sendGeneralPushNotification(PushNotificationGeneral notification) throws FirebaseMessagingException {
        if (notification.getEmails() == null || notification.getEmails().isEmpty()) {
            log.info("No emails to process");
            return;
        }
        PushNotificationGeneralSendHistory history = new PushNotificationGeneralSendHistory();
        for (String email : notification.getEmails()) {
            String sanitizedEmail = sanitizeForLog(email);
            List<AppRegistrationManagement> appRegistrations = deviceTokenService.getAppDataForUser(email);

            if (appRegistrations == null || appRegistrations.isEmpty()) {
                log.info("No AppRegistrationData found for {}", sanitizedEmail);
                continue;
            }

            for (AppRegistrationManagement app : appRegistrations) {
                String deviceType = app.getDeviceType().toString();
                String token = app.getDeviceRegistrationToken();
                String androidResponse = null;
                String iosResponse = null;

                try {
                    if (Constants.ANDROID.equals(deviceType)) {
                        androidResponse = sendAndroidPushNotificationWithRetry(token, notification.getTitle(), notification.getBody()).get();
                    } else if (Constants.IOS.equals(deviceType)) {
                        iosResponse = sendIosPushNotification(notification.getTitle(), notification.getBody(), token, "IOS");
                    }

                    boolean isSuccess = (androidResponse != null && !androidResponse.contains("error")) ||
                                        (iosResponse != null && iosResponse.isEmpty());

                    if (isSuccess) {
                        notification.setNotificationStaus("SUCCESS");
                    } else {
                        throw new Exception("Push notification failed");
                    }

                } catch (Exception e) {
                    String sanitizedError = sanitizeForLog(e.getMessage());
                    log.error("Push notification failed for {}: {}", sanitizedEmail, sanitizedError);

                    notification.setNotificationStaus("FAIL");
                    history.setGeneralpushnotification(notification);
                    history.setNotificationStatus("FAIL");
                    history.setFailureDateTime(System.currentTimeMillis() / 1000);
                    history.setNotificationFailureReason(
                        getErrorFromResponse(androidResponse, iosResponse, deviceType)
                    );
                    historyRepo.save(history);
                }
            }
        }
    }
    
    /**
     * Sends a push notification to an Android device using Firebase
     * @param title the notification title
     * @param body the notification body
     * @param token the device registration token
     * @return the response from Firebase
    */
    public String sendAndroidPushNotification(String title, String body, String token) {       
        String response = null;
        Message message = Message.builder()
                .setToken(token)
                .setNotification(Notification.builder()
                        .setTitle(title)
                        .setBody(body)
                        .build())
                .build();        
        try {
                response = FirebaseMessaging
                    .getInstance(FirebaseApp.getInstance("androidApp")) 
                    .send(message);                    
            String sanitizedResponse = sanitizeForLog(response);
            log.info("Push sent successfully: {}", sanitizedResponse);
        } catch (FirebaseMessagingException e) {

            response = e.getMessage();
            log.error("Failed to send push: {}", e.getCause());
        }
        return response;
    }    
    
    /**
     * Sends a push notification to an Android device with retry logic.
     * @param token the device registration token
     * @param title the notification title
     * @param body the notification body
     * @return a CompletableFuture containing the result of the send operation
    */
    public CompletableFuture<String>  sendAndroidPushNotificationWithRetry(String token, String title, String body) {
        Message message = Message.builder()
                .setToken(token)
                .setNotification(Notification.builder()
                        .setTitle(title)
                        .setBody(body)
                        .build())
                .build();                
        return attemptSend(message,1, MAX_RETRY,100);                              
                  
    }   
    
    /**
     * Extracts error information from Android or iOS push notification responses.
     * @param jsonAndroidResponse the response from Android push notification
     * @param jsonIosResponse the response from iOS push notification
     * @param deviceType the type of device (ANDROID or IOS)
     * @return the extracted error message or null if not found
     */
    private String getErrorFromResponse(String jsonAndroidResponse, String jsonIosResponse, String deviceType){
        String error = null;
        try {
        // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();
            // Parse JSON response
            if(Objects.nonNull(jsonAndroidResponse) || Objects.nonNull(jsonIosResponse)){               
                
                // Extract specific fields
                if(deviceType.equals(Constants.IOS)){            
                    JsonNode rootNode = objectMapper.readTree(jsonIosResponse);                    
                    error = rootNode.path("reason").asText();
                }else{
                    error = jsonAndroidResponse;
                }             
            }                  
        } catch (Exception e) {
            String sanitizedDeviceType = sanitizeForLog(deviceType);
            log.error("Failed to parse push notification error response for device type: {}", sanitizedDeviceType, e);
        }
        return error;
    }
    
    /**
     * Generates the JSON payload for an iOS push notification.
     * @param title the notification title
     * @param body the notification body
     * @return the JSON string representing the notification payload
    */
    private String generateNotificationBodyForIOS(String title, String body){
        String notificationBody = "{\n \"aps\":{ \n" +
        "\"alert\": {\n" +
        "\"title\": \"{"+title+"}\",\n" +
        "\"body\": \"{"+body+"}\" \n" +
        "},\n" +
        "\"sound\": \"default\"\n" +
        "}\n" +
        "}";

        return notificationBody;
    }
    
    /**
     * Sends a push notification to an iOS device using Apple Push Notification service (APNs).
     * @param title the notification title
     * @param body the notification body
     * @param deviceToken the device token
     * @param deviceType the type of device (should be "IOS")
     * @return the response from APNs or error message
    */    
    public String sendIosPushNotification(String title, String body,String deviceToken, String deviceType) {
        String payLoad = generateNotificationBody(title,body, deviceType);
        String teamId = applicationProperties.getPushNotificationRevamp().getTeamId();
        String keyId = applicationProperties.getPushNotificationRevamp().getKeyId();
        String base64PrivateKey = applicationProperties.getPushNotificationRevamp().getBase64PrivateKey();
        String JwtToken = null;
        String response = null;
        try{
            JwtToken = PushNotificcationRevampUtil.generateToken(teamId,keyId,base64PrivateKey);
        }catch(Exception e){           
            log.error("Error generating token ", e);
        }
        try{
            response =  sendAPNSNotification(JwtToken,deviceToken,payLoad);
        }catch(Exception e){
            log.error("Error sending APNC Notification  for ", e.getCause(),e);
            response = e.getMessage();
        }          
        return response;
    }
    
    /**
     * Sends a push notification to Apple Push Notification service (APNs)  *
     * @param jwtToken the JWT token for authentication
     * @param deviceToken the target device token
     * @param payLoad the JSON payload of the notification
     * @return the response body from APNs
     * @throws Exception if the HTTP request fails
    */
    private String sendAPNSNotification(String jwtToken, String deviceToken,String payLoad) throws Exception {
        String apnsHost = applicationProperties.getPushNotificationRevamp().getApnsHost();
        String apnsTopic = applicationProperties.getPushNotificationRevamp().getApnsTopic();       
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apnsHost + "/3/device/" + deviceToken))
                .POST(HttpRequest.BodyPublishers.ofString(payLoad))
                .setHeader("authorization", "bearer " + jwtToken)
                .setHeader("apns-topic", apnsTopic)
                .setHeader("Content-Type", "application/json")
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    
    /**
     * Generates the appropriate notification body based on the device type.
     *
     * @param title the notification title
     * @param body the notification body
     * @param deviceType the type of device (e.g., IOS)
     * @return the formatted notification body as a JSON string
    */
    private String generateNotificationBody(String title, String body, String deviceType){
        String notificationBody = null;
        if(Objects.nonNull(deviceType)){
            notificationBody = generateNotificationBodyForIOS(title, body);
        }        
        return notificationBody;
    }  
        
    /**
     * Scheduled method that processes general push notifications.
     * It runs asynchronously and within a transactional context.
     * The schedule and timezone are configured via application properties.
    */
    @Async
    @Transactional
    public void processGeneralPushNotification() {            

        log.info("Start processGeneralPushNotification : ");
        List<PushNotificationGeneral> candidates = generalPushNotificationRepository.findtAllReadyToSenfNoifications();
        sendInBatches(candidates);
        log.info("End processGeneralPushNotification : ");
    }
    
    /**
     * Splits the list of notifications into smaller batches and processes each batch.
     * @param notifications the list of notifications to be sent
    */      
    private void sendInBatches(List<PushNotificationGeneral> notifications) { 

        List<List<PushNotificationGeneral>> batches = partition(notifications, 500);
        for (List<PushNotificationGeneral> batch : batches) { 
            processBatch(batch); 
        } 
    }    
    
    /**
     * Partitions a list into sublists of a specified size.
     * @param list the original list
     * @param size the maximum size of each partition
     * @param <T> the type of elements in the list
     * @return a list of partitions
    */
    public static <T> List<List<T>> partition(List<T> list, int size) {
        List<List<T>> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            partitions.add(new ArrayList<>(list.subList(i, Math.min(i + size, list.size()))));
         }
     return partitions;
    }
    
    
    /**
     * Processes a batch of push notifications by sending them to the appropriate devices.
     * Handles both Android and iOS devices and logs success or failure.
     * @param batch the list of notifications to process
    */
    private void processBatch(List<PushNotificationGeneral> batch) {
        for (PushNotificationGeneral notification : batch) {
            notification.setNotificationSentBy(Constants.SCHEDULER);
            notification.setNotificationSent(Boolean.TRUE);
            String sanitizedNotificationId = sanitizeForLog(String.valueOf(notification.getId()));
            try {
                if (notification.getEmails() == null || notification.getEmails().isEmpty()) {
                    log.info("No emails present to process for notification ID: {}", sanitizedNotificationId);
                    continue;
                }

                List<AppRegistrationManagement> appRegistrations = deviceTokenService.getAppDataForUsers(notification.getEmails());

                if (appRegistrations == null || appRegistrations.isEmpty()) {
                    log.info("No AppRegistrationData found for notification ID: {}", sanitizedNotificationId);
                    notification.setNotificationStaus("FAIL");
                    continue;
                }
                int successCount = 0;
                for (AppRegistrationManagement app : appRegistrations) {
                    String deviceType = app.getDeviceType().toString();
                    String token = app.getDeviceRegistrationToken();
                    String androidResponse = null;
                    String iosResponse = null;

                    try {
                        if ("ANDROID".equals(deviceType)) {
                            androidResponse = sendAndroidPushNotification(notification.getTitle(), notification.getBody(), token);
                        } else if ("IOS".equals(deviceType)) {
                            iosResponse = sendIosPushNotification(notification.getTitle(), notification.getBody(), token, "OP");
                        }
                        boolean isSuccess = (androidResponse != null && androidResponse.contains("projects")) ||
                                            (iosResponse != null && iosResponse.isEmpty());

                        if (isSuccess) {
                            successCount++;
                        } else {
                            saveFailureHistory(notification, deviceType, androidResponse, iosResponse);
                        }

                    } catch (Exception e) {
                        String sanitizedToken = sanitizeForLog(token);
                        log.error("Error sending notification to device: {}", sanitizedToken, e);
                        saveFailureHistory(notification, deviceType, androidResponse, iosResponse);
                    }

                }

                notification.setNotificationStaus(successCount == appRegistrations.size() ? "SUCCESS" : "FAIL");

                } catch (Exception e) {
                    log.error("Error processing notification ID: {}", sanitizedNotificationId, e);
                    notification.setNotificationStaus("FAIL");
                }
        }
        generalPushNotificationRepository.saveAll(batch);
    }   
    
    /**
     * Attempts to send a Firebase message with retry logic using exponential backoff.
     * @param message the Firebase message to send
     * @param attempt the current attempt number
     * @param maxAttempts the maximum number of retry attempts
     * @param delayMillis the delay before retrying (in milliseconds)
     * @return a CompletableFuture containing the result or exception
    */
    private CompletableFuture<String> attemptSend(
            Message message,
            int attempt,
            int maxAttempts,
            long delayMillis
    ) {        
        return toCompletbaleFuture(FirebaseMessaging.getInstance(FirebaseApp.getInstance("androidApp")).sendAsync(message))
                .thenApply(response -> {
                    log.info("Attempt %d succeeded: %s%n", attempt, response);
                    return response;
                })
                .exceptionally(ex -> {
                    log.error("Attempt %d failed: %s%n", attempt, ex.getMessage());
                    if (attempt >= maxAttempts) {
                        log.error("Max retries reached. Giving up.");
                        throw new RuntimeException("Push notification failed after " + maxAttempts + " attempts", ex);
                    }

                    try {
                        TimeUnit.MILLISECONDS.sleep(delayMillis); // backoff delay
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }

                    long nextDelay = delayMillis * 2; // Exponential backoff
                    return attemptSend(message, attempt + 1, maxAttempts, nextDelay).join();
                });
    }    
    
    /**
     * Converts a Firebase ApiFuture to a Java CompletableFuture.
     * @param apiFuture the Firebase ApiFuture
     * @param <T> the type of the result
     * @return a CompletableFuture representing the same result
    */
    private <T> CompletableFuture<T> toCompletbaleFuture(ApiFuture<T> apiFuture){
        CompletableFuture<T> cmpltblefuture = new CompletableFuture<>();
        new Thread(() -> {
            try{
                T result = apiFuture.get();
                cmpltblefuture.complete(result);
            }
            catch(Exception e){
                cmpltblefuture.completeExceptionally(e);
            }

        }).start();
        return cmpltblefuture;

    } 

    /**
     * Generates the appropriate notification body based on the device type.
     * @param notification the notification object     * 
     * @param deviceType the type of device (e.g., IOS)
     * @param androidResponse the FCM Resposne
     * @param iosResponse the APNs Resposne
    */
    private void saveFailureHistory(PushNotificationGeneral notification, String deviceType, String androidResponse, String iosResponse) {
        PushNotificationGeneralSendHistory history = new PushNotificationGeneralSendHistory();
        history.setGeneralpushnotification(notification);
        history.setNotificationStatus("FAIL");
        history.setFailureDateTime(System.currentTimeMillis() / 1000);
        history.setNotificationFailureReason(getErrorFromResponse(androidResponse, iosResponse, deviceType));
        historyRepo.save(history);
    }

    private String sanitizeForLog(String input) {
        if (Objects.isNull(input)) {
            return null;
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
