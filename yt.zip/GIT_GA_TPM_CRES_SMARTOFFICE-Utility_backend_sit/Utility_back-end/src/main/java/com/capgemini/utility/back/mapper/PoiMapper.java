package com.capgemini.utility.back.mapper;

import java.util.ArrayList;
import java.util.List;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.Equipment;
import com.capgemini.utility.back.model.EquipmentDTO;
import com.capgemini.utility.back.model.Floor;
import com.capgemini.utility.back.model.FloorDTO;
import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.model.PoiDTO;

import com.capgemini.utility.back.model.SpaceType;
import com.capgemini.utility.back.model.SpaceTypeDTO;

@Mapper(config = DtoMapperConfig.class, uses = {CdmAttributesMapper.class})
public interface PoiMapper {

    PoiMapper INSTANCE = Mappers.getMapper(PoiMapper.class);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" }),
        @Mapping(source = "equipments", target = "equipments", qualifiedByName = { "equipmentToEquipmentDTO" }),
        @Mapping(target = "sensorData", ignore = true),
        @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" }),
        @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper", "mapCdmAttributesDTO" })
    })
    PoiDTO poiToPoiDTO(Poi in, @Context String language);

    @Mapping(source = "in", target ="attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributes" })
    Poi poiDTOToPoi(PoiDTO in);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }

    @Named("spaceToSpaceDTO")
    default SpaceTypeDTO _spaceTypeToSpaceTypeDTO(SpaceType floor, @Context String language) {
        return Mappers.getMapper(SpaceTypeMapper.class).spaceTypeToSpaceTypeDTO(floor);
    }

    @Named("equipmentToEquipmentDTO")
    default List<EquipmentDTO> _equipmentToEquipmentDTO(List<Equipment> equipments, @Context String language) {
        List<EquipmentDTO> equipmentDTOs = new ArrayList<EquipmentDTO>();
        equipments.forEach(equipment -> {
            equipmentDTOs.add(Mappers.getMapper(EquipmentMapper.class).equipmentToEquipmentDTO(equipment, language));
        });
        return equipmentDTOs;
    }

}
