package com.capgemini.utility.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.utility.back.model.Country;


import com.capgemini.utility.back.repository.CountryRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CountryService {

    @Autowired
    private EntityManager entityManager;

	@Autowired
	private CountryRepository countryRepository;

	public Country createCountry(Country countryRequest) {
		countryRequest.setModifiedAt((new Date()).getTime() / 1000);
		Country country = null;
		try {
			country = this.countryRepository.save(countryRequest);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return country;
    }

    @Transactional
    public Country getCountry(Long countryId) {
		Country country = this.countryRepository.findById(countryId).orElse(null);
        if(Objects.nonNull(country)) {
            country.getCities();
        }
		return country;
	}

    public Country findByEntityGraph(Long id) {
        try {
            EntityGraph<?> entityGraph = entityManager.getEntityGraph("country-entity-graph");
            Map<String, Object> properties = new HashMap<>();
            properties.put("javax.persistence.fetchgraph", entityGraph);
            return this.entityManager.find(Country.class, id, properties);
        } catch (PersistenceException | IllegalArgumentException ex) {
            log.error("Failed to retrieve country by entity graph", ex);
            throw new IllegalStateException("Unable to retrieve country");
        }
    }


	

	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return this.countryRepository.getNameByCmdKeyId(cdmKeyIdList)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, Long.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve country names by cmd key id", ex);
			throw new IllegalStateException("Unable to retrieve country names");
		}
	}


	public Map<String, String> getAttributesById(Long countryId) {
		try {
			return this.countryRepository.getAttributesById(countryId)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, String.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve country attributes by id", ex);
			throw new IllegalStateException("Unable to retrieve country attributes");
		}
	}


    public List<Country> getAll() {
        return this.countryRepository.findAll();
    }

    public Country save(Country country) {
        return this.countryRepository.saveAndFlush(country);
    }

    public void deleteById(Long countryId) {
        this.countryRepository.deleteById(countryId);
    }
	public Map<Long, String> getCountryNameByBuildingIds(List<Long> buildingIds) {
        try {
            return this.countryRepository.getCountryNameByBuildingIds(buildingIds)
                    .stream()
                    .collect(Collectors.toMap(
                        (tuple) -> tuple.get(0, Long.class),
                        (tuple) -> tuple.get(1, String.class)
                    ));
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve country names by building ids", ex);
            throw new IllegalStateException("Unable to retrieve country names");
        }
    }

}
