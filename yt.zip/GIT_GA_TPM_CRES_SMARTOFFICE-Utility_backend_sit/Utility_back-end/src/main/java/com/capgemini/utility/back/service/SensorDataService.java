package com.capgemini.utility.back.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.capgemini.utility.back.model.Device;
import com.capgemini.utility.back.model.EnumDeviceAttribute;
import com.capgemini.utility.back.model.PoiDTO;
import com.capgemini.utility.back.model.SensorDataDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SensorDataService {

	public static final Integer DESK_LOCKING_TIME_MINUTES = 60;

	public List<SensorDataDTO> convertToSensorDataDTO(List<PoiDTO> poiDTOs, List<Device> devices) {
		if (Objects.isNull(devices)) {
            log.info("no device");
			return null;
		}

		return devices.stream()
			.map(device -> {
				SensorDataDTO sensorData = new SensorDataDTO();

				String poiName = device.getPoiName();

				// If link to a Poi, get the Poi
				if (Objects.nonNull(poiName)) {
					PoiDTO foundPoi = poiDTOs.stream()
						.filter(poi -> Objects.equals(poi.getName(), poiName))
						.findFirst()
						.orElse(null);

					if (Objects.nonNull(foundPoi)) {
						sensorData.setCdmKeyIdPoi(foundPoi.getCdmKeyId());
                        log.info("error ?");
					}
				}

				// Basic fields
				sensorData.setUuid(device.getUuid());
				sensorData.setPoiName(device.getPoiName());

				if (Objects.nonNull(device.getFloor())) {
					sensorData.setCdmKeyIdFloor(device.getFloor().getCdmKeyId());
				}
				if (Objects.nonNull(device.getStatus())) {
					sensorData.setStatus(device.getStatus().toString());
				}
				if (Objects.nonNull(device.getDeviceType())) {
					sensorData.setDeviceType(device.getDeviceType().toString());
				}

				if (Objects.nonNull(device.getLastChange())) {
					sensorData.setLastChange(device.getLastChange().toString());
				}

				Map<String, String> attributes = device.getAttributes();
                if (attributes != null && !attributes.isEmpty()) {
                    attributes.forEach((key, value) -> System.out.println(key + ": " + value));
                }

				sensorData.setBattery(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.VDD_PCT)
				);

				sensorData.setOccupancy(
					this.getAttributeAsString(attributes, EnumDeviceAttribute.OCCUPATION)
				);

				sensorData.setCo2(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.CO2)
				);

				sensorData.setHumidity(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.HUMIDITY)
				);

				sensorData.setLight(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.LUX)
				);

				sensorData.setNoise(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.SOUND)
				);

				sensorData.setTempC(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPC)
				);
                log.info("working ?4");
				sensorData.setTempF(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPF)
				);

				return sensorData;
			})
			.collect(Collectors.toList());
	}


	/**
	 * Return the value of an attribut as a String.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a String.
	 */
	private String getAttributeAsString(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();

		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
		}

		return attributes.get(keyString);
	}

	/**
	 * Return the value of an attribut as a Double.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a Double.
	 */
	private Double getAttributeAsDouble(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();
		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
        }
        Map<String, String> trimmedAttributes = attributes.entrySet().stream()
        .collect(Collectors.toMap(
                entry -> entry.getKey().trim(),
                Map.Entry::getValue
        ));
		return Double.parseDouble(trimmedAttributes.get(keyString));
	}
}
