package com.capgemini.utility.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.utility.back.model.Equipment;
import com.capgemini.utility.back.model.EquipmentDTO;

@Named("EquipmentMapper")
@Mapper(config = DtoMapperConfig.class)
public interface EquipmentMapper {
    EquipmentMapper INSTANCE = Mappers.getMapper(EquipmentMapper.class);

    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
    EquipmentDTO equipmentToEquipmentDTO(Equipment in, @Context String language);

    Equipment equipmentDTOToEquipment(Equipment in);
}
