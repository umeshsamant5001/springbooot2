package com.capgemini.utility.back.controller;

import com.capgemini.utility.back.model.AppConfigurationValues;
import com.capgemini.utility.back.model.NewsDTO;
import com.capgemini.utility.back.service.AppConfigService;
import com.capgemini.utility.back.service.NewsService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(AppConfigurationController.ROOT_API)
public class AppConfigurationController {

    static final String ROOT_API = "api/configuration";

    @Autowired
    private AppConfigService appConfigService;

    @Autowired
    private NewsService newsService;

    @GetMapping
    public ResponseEntity<List<AppConfigurationValues>> getConfigurationKeysByActiveStatus(@RequestParam(required = false) Boolean returnActive) {                   
     
    if(Boolean.TRUE.equals(returnActive)){
        List<AppConfigurationValues> configurations = appConfigService.getActiveConfigurations(returnActive);
            return ResponseEntity.ok(configurations);
        }
        else if(Boolean.FALSE.equals(returnActive)){
        List<AppConfigurationValues> configurations = appConfigService.getInactiveConfigurations(returnActive);
            return ResponseEntity.ok(configurations);
        }else{
            return ResponseEntity.ok(this.appConfigService.getAllRecords());
        }                       
    }

    @GetMapping("/mobile")
    public ResponseEntity<Map<String, Object>> getConfigurationsAndNews(
        @RequestParam(required = false) Boolean returnActive,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<AppConfigurationValues> configurations = getConfigurationsByStatus(returnActive);

        NewsDTO newsDTO = new NewsDTO();
        newsDTO = newsService.findFirstActiveNews();

        Map<String, Object> response = new HashMap<>();
        response.put("configurations", configurations);
        response.put("news", newsDTO);

        return ResponseEntity.ok(response);
    }

    private List<AppConfigurationValues> getConfigurationsByStatus(Boolean returnActive) {
        List<AppConfigurationValues> configurations;
        if (Boolean.TRUE.equals(returnActive)) {
            configurations = appConfigService.getActiveConfigurations(returnActive);
        } else if (Boolean.FALSE.equals(returnActive)) {
            configurations =  appConfigService.getInactiveConfigurations(returnActive);
        } else {
            configurations = appConfigService.getAllRecords();
        }
         // Filter the required keys only
        Set<String> requiredKeys = Set.of(
                    "TranslationMobileOutputContainer", 
                    "IOSCurrentVersion", 
                    "IOSMinimumVersion", 
                    "AndroidCurrentVersion", 
                    "AndroidMinimumVersion"
                    );
        return configurations.stream()
                            .filter(config -> requiredKeys.contains(config.getKey()))
                            .collect(Collectors.toList());
    }

}
