package com.capgemini.utility.back.management;

import lombok.Data;

@Data
public class TokenExchangeResponse {
    private String access_token;
    private int expires_in;
    private String issued_token_type;
    private String token_type;
}

