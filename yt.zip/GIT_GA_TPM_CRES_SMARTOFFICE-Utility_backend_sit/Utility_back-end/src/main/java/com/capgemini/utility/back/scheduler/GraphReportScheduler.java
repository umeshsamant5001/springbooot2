package com.capgemini.utility.back.scheduler;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgemini.utility.back.controller.SchedulerController;
import com.capgemini.utility.back.service.GraphReportService;
import com.capgemini.utility.back.service.MeetingService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class GraphReportScheduler {

    @Autowired
    private SchedulerController schedulerController;
    @Autowired
    private GraphReportService graphReportService;

    @Scheduled(cron = "0 0 0 * * *", zone = "Europe/Paris")
    public void execJob() throws Exception {
        log.info(" Scheduler triggered at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
        schedulerController.getMeetings();
        log.info(" Scheduler completed at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
    }

    @Scheduled(cron = "0 0 2 * * *", zone = "Europe/Paris") // Every day at 2 AM
    public void refreshConferenceRoomCache() {
        log.info("[Scheduler] Refreshing conference room cache...");
        graphReportService.findConferenceRoomsExcludingGermany();
    }

    //@Scheduled(cron = "0 */30 * * * * ", zone = "Europe/Paris") // every 30 mins
    //@Scheduled(cron = "0 0 * * * ", zone = "Europe/Paris") // every hour
    public void execJobTablet() throws Exception {
    log.info(" TabletMeetingScheduler triggered at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
    schedulerController.getTabletMeetings();
    log.info(" TabletMeetingScheduler completed at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
    }

}
