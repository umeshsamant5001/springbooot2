package com.capgemini.utility.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class CountryDTO implements Serializable, WithTitleDTO, WithCdmAttributesDTO{
    private Long id;
    private Long modifiedAt;
    private Long cdmKeyId;
    private String countryIsoAlpha2;
    private Map<String, String> attributes = new HashMap<String, String>();
    private List<CityDTO> cities;
    private Map<String, String> cdmAttributes = new HashMap<String, String>();
    private String titleFr;
    private String titleEn;
    private String title;
    private Long nbChilds;
}
