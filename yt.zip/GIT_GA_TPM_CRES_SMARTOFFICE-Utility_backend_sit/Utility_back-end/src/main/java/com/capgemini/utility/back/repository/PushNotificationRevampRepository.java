package com.capgemini.utility.back.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.utility.back.model.PushNotificationRevamp;

@Repository
public interface PushNotificationRevampRepository extends JpaRepository<PushNotificationRevamp, Long> {

    public Optional<PushNotificationRevamp> findByKeyIdAndNotificationDateTime(Long keyId, String notificationDateTime);

    /*Commented belwo query and used new below one to handle double push notification sent as next cycle of 1 minutes 
     commes before notification_status is updated and it remains the null to pick again.*/
    /*
        @Query(value = "SELECT * FROM externalpushnotification WHERE " +
            "FORMAT(TRY_CAST(notification_datetime AS DATETIME),'yyyy-MM-dd HH:mm') = " +
            "FORMAT(DATEADD(MINUTE, 01, GETDATE()) ,'yyyy-MM-dd HH:mm') " +
            "AND status = CAST(1 AS BIT) AND notification_status IS NULL ", nativeQuery = true)
    */

        @Query(value = "SELECT id FROM externalpushnotification WHERE " +
                "status = 1 " +
                "AND notification_sent = 0 " +
                "AND TRY_CAST(notification_datetime AS DATETIME) >= DATEADD(MINUTE, DATEDIFF(MINUTE, 0, GETDATE()) + 1, 0) " +
                "AND TRY_CAST(notification_datetime AS DATETIME) < DATEADD(MINUTE, DATEDIFF(MINUTE, 0, GETDATE()) + 2, 0)", nativeQuery = true)
        public List<Long> findAllMatchingNotificationIds();

        @Modifying
        @Query(value = "Update externalpushnotification set status = CAST(0 AS BIT), " +
                "updated_date_time = DATEDIFF(SECOND, '1970-01-01', GETUTCDATE()) " +
                "WHERE notification_status IS NULL and keyid =:keyId ", nativeQuery = true)
        void updateStatus(@Param("keyId") Long keyId);


        public List<PushNotificationRevamp> findByKeyId(Long keyId);

        @Modifying
        @Transactional
        @Query(value = "UPDATE externalpushnotification SET " +
                "notification_sent = 1, " +
                "notification_sent_by = :sentBy, " +
                "notification_sent_time = :sentTime, " +
                "updated_date_time = :updatedDateTime " +
                "WHERE id = :id AND notification_sent = 0 ", nativeQuery = true) 
        int claimNotificationForProcessing(@Param("id") Long id,
                @Param("sentBy") String sentBy,
                @Param("sentTime") Long sentTime,
                @Param("updatedDateTime") Long updatedDateTime);   
     
}
