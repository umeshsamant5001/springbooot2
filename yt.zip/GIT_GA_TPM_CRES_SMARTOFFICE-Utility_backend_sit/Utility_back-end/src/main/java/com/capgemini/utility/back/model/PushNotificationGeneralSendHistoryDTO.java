package com.capgemini.utility.back.model;

import lombok.Data;

@Data
public class PushNotificationGeneralSendHistoryDTO {

    private Long id;	
	private PushNotificationGeneral generalpushnotification; 
	private String title;	
	private String body;	
	private String Email;
	private String notificationStatus; 
	private String notificationFailureReason; 	
	private Long retryCount;	
	private Long failureDateTime;
}