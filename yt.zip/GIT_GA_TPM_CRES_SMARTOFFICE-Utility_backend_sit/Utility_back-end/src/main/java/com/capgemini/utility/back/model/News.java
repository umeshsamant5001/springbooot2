package com.capgemini.utility.back.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "news")
@EqualsAndHashCode
public class News {

   @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "News_Generator")
    @SequenceGenerator(name = "News_Generator", sequenceName = "News_Sequence")
    private Long id;
    @Column(name = "link_text")
    private String linkText;
    @Column(name = "category")
    private Category category;
    @Column(name = "news_message", columnDefinition = "TEXT")
    private String newsMessage;
    @Column(name = "status") 
    private Integer status; 
    @Column(name = "last_modified_by")
    private String lastModifiedBy;
    @Column(name = "last_modified_date", nullable = false)
    private Long lastModifiedDate = (new Date()).getTime() / 1000;
}
