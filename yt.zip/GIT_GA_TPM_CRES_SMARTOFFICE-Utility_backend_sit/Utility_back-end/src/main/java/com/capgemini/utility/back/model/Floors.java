package com.capgemini.utility.back.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Floors {
    @JsonProperty("floor_id")
    private Long floorId;
    @JsonProperty("floor_name")
    private String floorName;
    @JsonProperty("floor_index")
    private Long floorIndex;
}
