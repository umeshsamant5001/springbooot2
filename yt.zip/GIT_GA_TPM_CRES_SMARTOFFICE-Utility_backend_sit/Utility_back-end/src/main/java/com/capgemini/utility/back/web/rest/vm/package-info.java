/**
 * View Models used by Spring MVC REST controllers.
 */
package com.capgemini.utility.back.web.rest.vm;
