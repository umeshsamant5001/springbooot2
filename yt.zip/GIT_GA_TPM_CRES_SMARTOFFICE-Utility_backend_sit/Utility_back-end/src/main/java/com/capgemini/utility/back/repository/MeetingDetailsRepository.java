package com.capgemini.utility.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.utility.back.model.MeetingDetails;

public interface MeetingDetailsRepository extends JpaRepository<MeetingDetails, String>{


    
}
