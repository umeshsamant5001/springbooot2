package com.capgemini.utility.back.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.utility.back.mapper.SensorDataSPMapper;
import com.capgemini.utility.back.mapper.SensorDataValuesMapper;
import com.capgemini.utility.back.model.Device;
import com.capgemini.utility.back.model.EnumDeviceType;
import com.capgemini.utility.back.model.SensorBuildingFloor;
import com.capgemini.utility.back.model.SensorDataSP;
import com.capgemini.utility.back.model.SensorDataSPDTO;
import com.capgemini.utility.back.model.SensorDataValues;
import com.capgemini.utility.back.model.SensorDataValuesDTO;
import com.capgemini.utility.back.repository.DeviceRepository;
import com.capgemini.utility.back.repository.SensorBuildingFloorRepository;
import com.capgemini.utility.back.repository.SensorDataSPRepository;
import com.capgemini.utility.back.repository.SensorDataValuesRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DeviceService {

    @Autowired
    DeviceRepository deviceRepository;

    @Autowired
    SensorDataSPRepository sensorDataSPRepository;

    @Autowired 
    private SensorBuildingFloorRepository sensorBuildingFloorSPRepository;

    @Autowired
    private SensorDataValuesRepository sensorDataValuesRepository;

    /**
     * Return all device of a floor
     * @param floorId The id of the floor
     * @param typeList A list of EnumDeviceType to filter
     * @return
     */
    public List<Device> findAllByFloor(long floorId, List<EnumDeviceType> typeList) {
        try {
            if (Objects.isNull(typeList) || typeList.isEmpty()) {
                return this.deviceRepository.findAllByFloorId(floorId);
            }

            return this.deviceRepository.findAllByFloorIdAndDeviceTypeIn(floorId, typeList);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices by floor", ex);
            throw new IllegalStateException("Unable to retrieve devices");
        }
    }


    @Transactional(readOnly = true)
    public List<SensorDataSPDTO> getSensorData(Long buildingId) {
        List<SensorDataSP> sensorDataSPList = this.sensorDataSPRepository.GetSensorData(buildingId);
        List<SensorDataSPDTO> sensorDataSPDTOs = sensorDataSPList
            .stream()
            .map(sensorDataSP -> SensorDataSPMapper.INSTANCE.sensorDataSPToSensorDataSPDTO(sensorDataSP))
            .collect(Collectors.toList());

        return sensorDataSPDTOs;
    }

    @Transactional(readOnly = true)
    public List<SensorDataValuesDTO> getPoiSensorJsonData() {
        List<SensorDataValues> sensorDataValues = sensorDataValuesRepository.getPoiSensorJson();
        List<SensorDataValuesDTO> sensorDataValuesDTOs = sensorDataValues
            .stream()
            .map(sensorDataSP -> SensorDataValuesMapper.INSTANCE.sensorDataValuesToSensorDataValuesDTO(sensorDataSP))
            .collect(Collectors.toList());
        return sensorDataValuesDTOs;
    }
    
    @Transactional(readOnly = true)
    public List<SensorBuildingFloor> getAllBuildingFloorJsonSP(){
        List<SensorBuildingFloor> sensorBuildingFloors = new ArrayList<>();
        sensorBuildingFloors = sensorBuildingFloorSPRepository.GetBuildingFloorJson();
        return sensorBuildingFloors;
    }

}
