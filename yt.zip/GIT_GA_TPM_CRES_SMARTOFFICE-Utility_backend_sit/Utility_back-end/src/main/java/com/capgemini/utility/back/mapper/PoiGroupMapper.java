package com.capgemini.utility.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.utility.back.model.PoiGroup;
import com.capgemini.utility.back.model.PoiGroupDTO;

@Named("PoiGroupMapper")
@Mapper(config = DtoMapperConfig.class)
public interface PoiGroupMapper {

    PoiGroupMapper INSTANCE = Mappers.getMapper(PoiGroupMapper.class);

    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
	PoiGroupDTO poiGroupToPoiGroupDTO(PoiGroup in, @Context String language);

	PoiGroup poiGroupDTOToPoiGroup(PoiGroupDTO in);
}
