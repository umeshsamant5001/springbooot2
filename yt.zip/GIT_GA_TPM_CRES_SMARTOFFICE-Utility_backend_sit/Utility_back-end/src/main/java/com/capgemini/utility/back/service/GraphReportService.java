package com.capgemini.utility.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.capgemini.utility.back.mapper.PoiAttributeMapper;
import com.capgemini.utility.back.mapper.PoiMapper;
import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.model.PoiAttributeDTO;
import com.capgemini.utility.back.model.PoiDTO;
import com.capgemini.utility.back.repository.AppConfigRepository;
import com.capgemini.utility.back.repository.PoiRepository;
//import com.microsoft.graph.models.Workbook;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GraphReportService {

  @Autowired
  private PoiService poiService;
  @Autowired
  private PoiRepository poiRepository;

  @Autowired
  private AppConfigRepository appConfigRepository;

  private static final String configKey = "country_exclude_meeting_details";

  public List<PoiAttributeDTO> getAllPois(
      Long currentNodeId,
      String currentNodeType,
      Long parentNodeId,
      String currentNodeTypeName) {

    List<PoiAttributeDTO> poiAttributeDTOS = new ArrayList<>();
    List<Poi> pois = null;
    String language = "en";

    if (Objects.nonNull(currentNodeId) && currentNodeType.equalsIgnoreCase("Country")) {
      // poiData = this.poiService.findAllByCountryId(currentNodeId);
      if (Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL")) {
        pois = this.poiService.findAllByCountry();
      } else {
        pois = this.poiService.findAllByCountryId(currentNodeId);
      }
    }

    else if (Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId)
        && currentNodeType.equalsIgnoreCase("City")) {
      if (Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL")) {
        pois = this.poiService.findAllByCountryId(parentNodeId);
      } else {
        pois = this.poiService.findAllByCityIdAndCountryId(currentNodeId, parentNodeId);
      }
    }

    else if (Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId)
        && currentNodeType.equalsIgnoreCase("Site")) {
      if (Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL")) {
        pois = this.poiService.findAllByCityId(parentNodeId);
      } else {
        pois = this.poiService.findAllBySiteIdAndCityId(currentNodeId, parentNodeId);
      }
    }

    else if (Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId)
        && currentNodeType.equalsIgnoreCase("Building")) {
      if (Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL")) {
        pois = this.poiService.findAllBySiteId(parentNodeId);
      } else {
        pois = this.poiService.findAllByBuildingIdAndSiteId(currentNodeId, parentNodeId);
      }
    }

    else if (Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId)
        && currentNodeType.equalsIgnoreCase("Floor")) {
      if (Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL")) {
        pois = this.poiService.findAllByBuildingId(parentNodeId);
      } else {
        pois = this.poiService.findAllByFloorIdAndBuildingId(currentNodeId, parentNodeId);
      }
    }

    if (Objects.nonNull(pois)) {
      poiAttributeDTOS = pois
          .stream()
          .map(poi -> PoiAttributeMapper.INSTANCE.poiToPoiAttributeDTO(poi, language))
          .collect(Collectors.toList());
    }
    return poiAttributeDTOS;
  }

  @Cacheable(value = "conferenceRoomsCache")
  public List<PoiDTO> findConferenceRoomsExcludingGermany() {
    log.info("[Cache] Fetching conference rooms from DB...");
    List<String> excludeCountryList = getExcludeCountryList(configKey);
    List<String> sanitizedExcludeCountryList = new ArrayList<>();
    for (String excludeCountry : excludeCountryList) {
      String sanitizedExcludeCountry = excludeCountry == null ? null
          : new String(excludeCountry.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
      sanitizedExcludeCountryList.add(sanitizedExcludeCountry);
    }
    log.info("excludeCountryList {}", sanitizedExcludeCountryList);
    List<Poi> poiList;

    if (excludeCountryList != null && !excludeCountryList.isEmpty()) {
      poiList = poiRepository.findConferenceRoomsExcludingGermany(excludeCountryList);
    } else {
      poiList = poiRepository.findConferenceRooms();
    }
    return poiList.stream()
        .map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, "en"))
        .collect(Collectors.toList());
  }

  private List<String> getExcludeCountryList(String configKey) {

    String excludeCountryValues = appConfigRepository.findExcludeCountryList(configKey);

    if (excludeCountryValues == null || excludeCountryValues.isEmpty()) {
      return Collections.emptyList();
    }

    return Arrays.stream(excludeCountryValues.split(","))
        .map(String::trim)
        .filter(s -> !s.isEmpty())
        .distinct()
        .collect(Collectors.toList());

  }

  @Cacheable(value = "conferenceRoomsCacheTablet")
  public List<PoiDTO> findConferenceRoomsForTabletMeetings() {
    log.info("[Cache] Fetching conference rooms from DB...");
    List<Poi> poiList;
    poiList = poiRepository.findConferenceRoomsForTabletMeetings();
    return poiList.stream()
        .map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, "en"))
        .collect(Collectors.toList());
  }

  @Cacheable(value = "conferenceRoomsCacheTabletTest")
  public List<PoiDTO> findConferenceRoomsForTabletMeetingsTest() {
    log.info("[Cache] Test Fetching conference rooms from DB...");
    Optional<Poi> optionalPoi = poiRepository.findById(1279170L);
    List<Poi> poiList = new ArrayList<>();
    optionalPoi.ifPresent(poiList::add);
    //poiList = poiRepository.findConferenceRoomsForTabletMeetings();
    log.info("Test Fetching conference rooms from DB...poiList size {}", poiList.size());
    return poiList.stream()
        .map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, "en"))
        .collect(Collectors.toList());
  }

  private String sanitizeForLog(String input) {
    if (Objects.isNull(input)) {
      return null;
    }
    return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
  }


}
