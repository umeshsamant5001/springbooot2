package com.capgemini.utility.back.mapper;

import com.capgemini.utility.back.model.PushNotificationGeneral;
import com.capgemini.utility.back.model.PushNotificationGeneralDTO;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface PushNotificationGeneralMapper {

    PushNotificationGeneralMapper INSTANCE = Mappers.getMapper(PushNotificationGeneralMapper.class);
    
    PushNotificationGeneralDTO generalPushNotificationToGeneralPushNotificationDTO(PushNotificationGeneral in);
    PushNotificationGeneral generalPushNotificationDTOToGeneralPushNotification(PushNotificationGeneralDTO in);
}
