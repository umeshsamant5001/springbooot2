package com.capgemini.utility.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.capgemini.utility.back.config.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "meeting_attendees")
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class MeetingAttendee {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "meetingroomemailaddress")
    private String meetingRoomEmailAddress;

    @ManyToOne
    @JoinColumn(name = "meeting_details_id")
    @JsonIgnore
    private MeetingDetails meetingDetails;

    @Column(name = "meeting_details_id", updatable = false, insertable = false)
	private String meetingDetailsId;

    @Column(name = "attendees_emailAddress_name")
    private String attendeesName;

    @Column(name = "attendees_emailAddress_address")
    private String attendeesAddress;

    @Column(name = "type")
    private String type;

    @Column(name = "response")
    private String response;

}
