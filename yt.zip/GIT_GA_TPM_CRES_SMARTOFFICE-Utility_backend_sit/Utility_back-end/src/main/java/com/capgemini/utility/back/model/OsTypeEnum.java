package com.capgemini.utility.back.model;

public enum OsTypeEnum {
    IOS,
    ANDROID,
    WEB,
    iOS // the front wants the i to be lowercase but we have already implemented
    // the code so to avoid changing the fron code, the database, ... we will add this value 
}