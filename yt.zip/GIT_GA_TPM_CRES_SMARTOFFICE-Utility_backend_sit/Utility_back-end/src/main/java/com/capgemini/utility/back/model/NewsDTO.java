package com.capgemini.utility.back.model;
import lombok.Data;

@Data
public class NewsDTO {
    private String linkText;
    private Long id;
    private Category category;
    private String newsMessage;
    private Integer status;
    private String lastModifiedBy;
    private Long lastModifiedDate;
}
