package com.capgemini.utility.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.security.jwt.AuthenticationException;

@Repository
public interface AuthenticationExceptionRepository extends JpaRepository<AuthenticationException, Long> {

}
