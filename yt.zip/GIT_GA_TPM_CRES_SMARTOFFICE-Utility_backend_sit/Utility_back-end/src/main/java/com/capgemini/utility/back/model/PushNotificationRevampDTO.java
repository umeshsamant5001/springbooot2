package com.capgemini.utility.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Data
public class PushNotificationRevampDTO {
    // READ_ONLY prevents these server-managed fields from being set via deserialization (Unsafe Object Binding fix)
    @JsonProperty(access = Access.READ_ONLY)
    private Long id;
	private String title;
    private String body;
    private Long keyId;	
	private String applicationName;
    private String employeeEmail; 
    private Boolean status =  Boolean.FALSE;  
    private String  notificationDateTime; 
    private String  notificationMessage;
    @JsonProperty(access = Access.READ_ONLY)
    private Long createdDateTime;
    @JsonProperty(access = Access.READ_ONLY)
    private Long updatedDateTime;
    @JsonProperty(access = Access.READ_ONLY)
    private String notificationStatus; 
    @JsonProperty(access = Access.READ_ONLY)
    private Boolean notificationSent = Boolean.FALSE; 
    @JsonProperty(access = Access.READ_ONLY)
    private String notificationSentBy;
    @JsonProperty(access = Access.READ_ONLY)
    private Long retryCount; 
    @JsonProperty(access = Access.READ_ONLY)
    private String notificationFailureReason;
    @JsonProperty(access = Access.READ_ONLY)
    private Long notificationFailurTime;
    @JsonProperty(access = Access.READ_ONLY)
    private Long notificationSentTime;
    @JsonProperty(access = Access.READ_ONLY)
    private String successMessageIds;

}