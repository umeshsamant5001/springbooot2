package com.capgemini.utility.back.service;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.Hibernate;



import com.capgemini.utility.back.model.Building;
import com.capgemini.utility.back.repository.BuildingRepository;
import com.capgemini.utility.back.mapper.BuildingMapper;
import com.capgemini.utility.back.model.BuildingDTO;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BuildingService {

	@Autowired
	private BuildingRepository buildingRepository;

	

    @Transactional
    public Building getBuilding(Long buildingId) {
		Building building = this.buildingRepository.findById(buildingId).orElse(null);
        if(Objects.nonNull(building)) {
            building.getFloors();
        }
		return building;
	}

	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return this.buildingRepository.getNameByCmdKeyId(cdmKeyIdList)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, Long.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building names by cmd key id", ex);
			throw new IllegalStateException("Unable to retrieve building names");
		}
	}


	public Map<String, String> getAttributesById(Long buildingId) {
		try {
			return this.buildingRepository.getAttributesById(buildingId)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, String.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building attributes by id", ex);
			throw new IllegalStateException("Unable to retrieve building attributes");
		}
	}


	public boolean buidingExists(Long buildingId) {
		return this.buildingRepository.existsById(buildingId);
	}

    public List<Building> getAll() {
        try {
            return this.buildingRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve buildings", ex);
            throw new IllegalStateException("Unable to retrieve buildings");
        }
    }


    public Building save(Building building) {
        return this.buildingRepository.saveAndFlush(building);
    }

    public void delete(Long buildingId) {
        this.buildingRepository.deleteById(buildingId);
    }

	public Long countBySiteId(Long siteId) {
		return this.buildingRepository.countBySiteId(siteId);
	}

	public List<List<String>> getExportAll() {
		List<List<String>> result =  this.buildingRepository.getExportAll();

		for (List<String> row: result) {
			row.set(4, this.convertBooleanString(row.get(4)));
			row.set(5, this.convertBooleanString(row.get(4)));
			row.set(6, this.convertBooleanString(row.get(4)));
			row.set(7, this.convertHourString(row.get(7)));
			row.set(8, this.convertHourString(row.get(8)));
		}
		
		return result;
	}

	
	private String convertBooleanString(String data) {
		if (Objects.isNull(data) || "0".equals(data)) {
			return "False";
		}

		return "True";
	}

	private String convertHourString(String data) {
		if (Objects.isNull(data)) {
			return "";
		}

		int num = Integer.valueOf(data);

		return String.format("%02d:%02d", (num / 3600), (num % 3600 / 60));

	}

    @Transactional
    public List<Building> getDeployedBuilding(boolean withFloor) {
        List<Building> buildings = this.buildingRepository.findAllByDeployedTrue();

        if (withFloor) {
            for (Building building : buildings) {
                Hibernate.initialize(building.getFloors());
            }
        }

        return buildings;
    }

    @Transactional
    public List<BuildingDTO> getDeployed() {
        List<Building> buildings = this.buildingRepository.findAllByDeployedTrue();
        if (Objects.isNull(buildings)) {
            return null;
        }

        for (Building building : buildings) {
            Hibernate.initialize(building.getFloors());
        }

        List<BuildingDTO> buildingDTOs = buildings
                        .stream()
                        .map(building -> BuildingMapper.INSTANCE.buildingToBuildingDTO(building,"en"))
                        .collect(Collectors.toList());

        return buildingDTOs;
    }

    public List<Building> findAll() {
        try {
            return this.buildingRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve all buildings", ex);
            throw new IllegalStateException("Unable to retrieve buildings");
        }
    }



}
