package com.capgemini.utility.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import com.capgemini.utility.back.model.SensorBuildingFloor;

@Repository
public interface SensorBuildingFloorRepository extends JpaRepository<SensorBuildingFloor, Long>{

    @Procedure(name = "GetBuildingFloorJson")
    public List<SensorBuildingFloor> GetBuildingFloorJson();

}
