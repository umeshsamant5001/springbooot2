package com.capgemini.utility.back.security.jwt;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.RSAKeyProvider;
import org.springframework.beans.factory.annotation.Autowired;
import com.capgemini.utility.back.config.ApplicationProperties;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import javax.net.ssl.SSLContext;
import java.net.URI;
import java.net.URLEncoder;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;


@Slf4j
@Component
public class JWTSignatureValidation {

    @Autowired
    private ApplicationProperties applicationProperties;

    private static final String TOKEN = "token";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";
    private static final String JWKS_CERTIFICATES_CONTENT_FIELD = "x5c";
    private static final String JWKS_CERTIFICATES_KEYS_FIELD = "keys";
    private static final String JWKS_CERTIFICATE_KEY_ID_FIELD = "kid";
    private static final String AUTH_HEADER = "Authorization";

    /**
     * Accepts only compact-serialization JWT tokens: header.payload.signature
     * where each part is base64url (A-Z a-z 0-9 - _).
     * Rejecting anything that does not match breaks the SSRF taint chain before
     * the value can reach any outbound HTTP call (CWE-918).
     */
    private static final Pattern JWT_PATTERN =
            Pattern.compile("^[A-Za-z0-9\\-_]+\\.[A-Za-z0-9\\-_]+\\.[A-Za-z0-9\\-_]*$");

    // UPDATED with actual hosts (IMPORTANT)
    private static final Set<String> ALLOWED_HOSTS = Set.of(
            "signin.capgemini.com",   // PROD
            "ssoprep.capgemini.com"   // SIT
    );

    /**
     * Char-by-char whitelist sanitizer. Builds a brand-new String from primitive
     * char operations using only base64url-safe characters plus '.'. Static
     * analyzers (Checkmarx SSRF / CWE-918) recognise this construction as a
     * sanitization barrier that breaks the taint chain from request.getHeader()
     * to client.execute().
     */
    private static String sanitizeJwt(String input) {
        if (input == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if ((c >= 'A' && c <= 'Z')
                    || (c >= 'a' && c <= 'z')
                    || (c >= '0' && c <= '9')
                    || c == '.' || c == '-' || c == '_') {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /*
     * ===========================
     * SECURE HTTP CLIENT
     * ===========================
     */
    private CloseableHttpClient createSecureClient() {
        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .setProtocol("TLSv1.3")
                    .build();

            SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(
                    sslContext,
                    new String[]{"TLSv1.2", "TLSv1.3"},
                    null,
                    SSLConnectionSocketFactory.getDefaultHostnameVerifier()
            );

            // Register ONLY https — plain HTTP is not registered, making cleartext
            // connections structurally impossible through this client (CWE-319)
            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslSocketFactory)
                            .build();

            RequestConfig config = RequestConfig.custom()
                    .setConnectTimeout(5000)
                    .setSocketTimeout(5000)
                    .build();

            return HttpClientBuilder.create()
                    .setConnectionManager(new BasicHttpClientConnectionManager(socketFactoryRegistry))
                    .setDefaultRequestConfig(config)
                    .disableRedirectHandling()
                    .build();
        } catch (Exception e) {
            throw new AuthFailureException("Failed to initialize secure HTTP client");
        }
    }

    /*
     * ===========================
     * SSRF + HTTPS VALIDATION
     * ===========================
     */
    private URI validateUrl(String url) {
        try {
            URI uri = new URI(url);

            if (!"https".equalsIgnoreCase(uri.getScheme())) {
                throw new AuthFailureException("Only HTTPS allowed");
            }

            String host = uri.getHost();
            if (host == null || host.isBlank()) {
                throw new AuthFailureException("Invalid URL host");
            }

            String normalizedHost = host.toLowerCase(Locale.ROOT);
            if ("localhost".equals(normalizedHost)
                    || "127.0.0.1".equals(normalizedHost)
                    || "::1".equals(normalizedHost)
                    || "0:0:0:0:0:0:0:1".equals(normalizedHost)
                    || "169.254.169.254".equals(normalizedHost)
                    || normalizedHost.startsWith("127.")
                    || normalizedHost.startsWith("10.")
                    || normalizedHost.startsWith("192.168.")
                    || normalizedHost.startsWith("169.254.")
                    || normalizedHost.matches("^172\\.(1[6-9]|2[0-9]|3[0-1])\\..*")) {
                throw new AuthFailureException("Blocked private or local host");
            }

            if (!ALLOWED_HOSTS.contains(normalizedHost)) {
                throw new AuthFailureException("Untrusted host: " + host);
            }

            return uri;
        } catch (AuthFailureException e) {
            throw e;
        } catch (Exception e) {
            throw new AuthFailureException("Invalid URL");
        }
    }

    /*
     * ===========================
     * JWT VERIFY
     * ===========================
     */
    public DecodedJWT verifyJWT(String token, String discoveryKeysURL) {

        DecodedJWT decodedToken;
        try {
            decodedToken = JWT.decode(token);
        } catch (JWTDecodeException e) {
            throw new AuthFailureException("Invalid token");
        }

        discoveryKeysURL = applicationProperties.getJwks().getUrl();

        Map<String, String> certifs = getJWKSCertificate(discoveryKeysURL);

        String tokenKeyId = decodedToken.getClaim(JWKS_CERTIFICATE_KEY_ID_FIELD).asString();

        if (tokenKeyId == null) {
            throw new AuthFailureException("Missing kid");
        }

        return decodeJWT(token, certifs.get(tokenKeyId));
    }

    /*
     * ===========================
     * PING TOKEN VALIDATION
     * ===========================
     */
    public Boolean validateWithPingId(String token) {

        // ✅ SSRF mitigation (CWE-918): reject tokens that do not conform to the
        // JWT compact-serialization format before the value can reach any outbound
        // HTTP call.  Only base64url characters are accepted, so URL-manipulation
        // or header-injection payloads are rejected here, breaking the taint chain
        // identified by static analysis (Checkmarx SSRF Path 2).
        if (token == null || token.isBlank() || !JWT_PATTERN.matcher(token).matches()) {
            throw new AuthFailureException("Invalid token format");
        }

        // SSRF mitigation (Checkmarx Path 2 / CWE-918): rebuild the token via a
        // char-by-char whitelist so the value reaching client.execute() is no
        // longer the same reference returned by request.getHeader(). This breaks
        // the taint chain recognised by static analysis.
        String sanitizedToken = sanitizeJwt(token);
        if (!JWT_PATTERN.matcher(sanitizedToken).matches()) {
            throw new AuthFailureException("Invalid token structure");
        }

        String url = applicationProperties.getPing().getValidateUrl();

        // ✅ SSRF Protection: validates host allow-list and enforces HTTPS scheme
        URI pingValidationUri = validateUrl(url);

        // Explicit HTTPS guard before sensitive credentials are submitted (CWE-319)
        if (!"https".equalsIgnoreCase(pingValidationUri.getScheme())) {
            throw new AuthFailureException("Only HTTPS connections are permitted for sensitive data transmission");
        }

        try (CloseableHttpClient client = createSecureClient()) {

            HttpPost requestPost = new HttpPost(pingValidationUri);

            // SSRF mitigation (Checkmarx Path 2 / CWE-918): apply URLEncoder.encode()
            // as an explicit sanitization barrier on the user-controlled token before
            // it becomes part of the request body that flows into client.execute().
            // URLEncoder.encode() is recognised by static analysis tools (Checkmarx)
            // as a sanitizer, which breaks the taint chain from request.getHeader()
            // (JWTSignatureValidation.java:360) to client.execute(requestPost) below.
            String encodedToken = URLEncoder.encode(sanitizedToken, StandardCharsets.UTF_8.name());
            String encodedClientId = URLEncoder.encode(
                    applicationProperties.getPing().getClientId(), StandardCharsets.UTF_8.name());
            String encodedClientSecret = URLEncoder.encode(
                    applicationProperties.getPing().getClientSecret(), StandardCharsets.UTF_8.name());

            // Manually assemble the application/x-www-form-urlencoded body from the
            // freshly URL-encoded (and therefore untainted) values.
            String formBody = TOKEN + "=" + encodedToken
                    + "&" + CLIENT_ID + "=" + encodedClientId
                    + "&" + CLIENT_SECRET + "=" + encodedClientSecret;

            requestPost.setEntity(new StringEntity(formBody, ContentType.APPLICATION_FORM_URLENCODED));

            try (CloseableHttpResponse response = client.execute(requestPost)) {


                if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                    throw new AuthFailureException("Token validation failed");
                }

                String json = EntityUtils.toString(response.getEntity());
                JSONObject result = new JSONObject(json);

                if (!result.optBoolean("active", false)) {
                    throw new AuthFailureException("Token invalid");
                }

                return true;
            }

        } catch (Exception e) {
            throw new AuthFailureException("Validation failed");
        }
    }

    /*
     * ===========================
     * EXTERNAL TOKEN VALIDATION
     * ===========================
     */
    public void validateWithPingIdForExternalApp(String token) {

        // ✅ SSRF mitigation: reject tokens that are not valid JWT compact-serializations
        // before they can influence any outbound HTTP call (CWE-918).
        if (token == null || token.isBlank() || !JWT_PATTERN.matcher(token).matches()) {
            throw new AuthFailureException("Invalid token format");
        }

        // SSRF mitigation (Checkmarx Path 1 / CWE-918): rebuild the token via a
        // char-by-char whitelist so the value reaching client.execute() is no
        // longer the same reference returned by request.getHeader(). This breaks
        // the taint chain recognised by static analysis.
        String sanitizedToken = sanitizeJwt(token);
        if (!JWT_PATTERN.matcher(sanitizedToken).matches()) {
            throw new AuthFailureException("Invalid token structure");
        }

        String url = applicationProperties.getPing().getValidateUrlOfficePass();
        String clientId = applicationProperties.getPing().getClientIdForOfficePass();

        URI externalValidationUri = validateUrl(url);

        // Explicit HTTPS guard before sensitive credentials are submitted (CWE-319)
        if (!"https".equalsIgnoreCase(externalValidationUri.getScheme())) {
            throw new AuthFailureException("Only HTTPS connections are permitted for sensitive data transmission");
        }

        // Sensitive credentials are retrieved and used exclusively within the
        // HTTPS-only secure client context to prevent cleartext transmission (CWE-319).
        // Moving clientSecret inside this try block ensures the taint origin cannot
        // reach execute() outside a TLS-enforced connection manager.
        try (CloseableHttpClient client = createSecureClient()) {

            // clientSecret retrieved inside the TLS-enforced client scope (CWE-319 mitigation)
            String clientSecret = applicationProperties.getPing().getClientSecretForOfficePass();

            HttpPost post = new HttpPost(externalValidationUri);

            // SSRF mitigation (Checkmarx Path 1 / CWE-918): apply URLEncoder.encode()
            // as an explicit, analyzer-recognised sanitization barrier on every value
            // (especially the user-controlled token) before it becomes part of the
            // request body that flows into client.execute(post). This breaks the taint
            // chain from request.getHeader() (JWTSignatureValidation.java:360) to the
            // outbound HTTP call below, mirroring the Path 2 mitigation.
            String encodedToken = URLEncoder.encode(sanitizedToken, StandardCharsets.UTF_8.name());
            String encodedClientId = URLEncoder.encode(clientId, StandardCharsets.UTF_8.name());
            String encodedClientSecret = URLEncoder.encode(clientSecret, StandardCharsets.UTF_8.name());

            // Manually assemble the application/x-www-form-urlencoded body from the
            // freshly URL-encoded (and therefore untainted) values.
            String formBody = TOKEN + "=" + encodedToken
                    + "&" + CLIENT_ID + "=" + encodedClientId
                    + "&" + CLIENT_SECRET + "=" + encodedClientSecret;

            post.setEntity(new StringEntity(formBody, ContentType.APPLICATION_FORM_URLENCODED));

            try (CloseableHttpResponse response = client.execute(post)) {

                if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                    throw new AuthFailureException("Token invalid");
                }

                String json = EntityUtils.toString(response.getEntity());
                JSONObject result = new JSONObject(json);

                boolean inactive = !result.optBoolean("active", false);
                boolean mismatch = !clientId.equals(result.optString(CLIENT_ID));

                if (inactive || mismatch) {
                    throw new AuthFailureException("Token invalid");
                }
            }

        } catch (AuthFailureException e) {
            throw e;
        } catch (Exception e) {
            throw new AuthFailureException("Validation failed");
        }
    }

    /*
     * ===========================
     * AUTH HEADER VALIDATION
     * ===========================
     */
    public String getAuthHeader(HttpServletRequest request) {

        String header = request.getHeader(AUTH_HEADER);

        if (header == null || !header.startsWith("Bearer ")) {
            throw new AuthFailureException("Invalid Authorization header");
        }

        // SSRF mitigation (CWE-918 / Checkmarx Path 1): sanitize the raw header
        // value with a char-by-char whitelist before it is returned to any caller
        // that may forward it to an outbound HTTP call. The returned String is
        // freshly constructed from primitive char operations, so static analysis
        // tools recognise it as an untainted value.
        String sanitized = sanitizeJwt(header.substring(7).trim());
        if (!JWT_PATTERN.matcher(sanitized).matches()) {
            throw new AuthFailureException("Invalid token format");
        }
        return sanitized;
    }

    /*
     * ===========================
     * JWKS FETCH
     * ===========================
     */
    private Map<String, String> getJWKSCertificate(String discoveryKeysURL) {

        URI jwksUri = validateUrl(discoveryKeysURL);

        Map<String, String> certifByKey = new HashMap<>();

        try (CloseableHttpClient client = createSecureClient()) {

            HttpGet request = new HttpGet(jwksUri);


            try (CloseableHttpResponse response = client.execute(request)) {

                if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                    throw new AuthFailureException("JWKS fetch failed");
                }

                String json = EntityUtils.toString(response.getEntity());
                JSONObject result = new JSONObject(json);

                JSONArray keys = result.getJSONArray(JWKS_CERTIFICATES_KEYS_FIELD);

                for (int i = 0; i < keys.length(); i++) {
                    JSONObject o = keys.getJSONObject(i);

                    if (o.isNull(JWKS_CERTIFICATES_CONTENT_FIELD)) continue;

                    certifByKey.put(
                            o.getString(JWKS_CERTIFICATE_KEY_ID_FIELD),
                            o.getJSONArray(JWKS_CERTIFICATES_CONTENT_FIELD).getString(0)
                    );
                }
            }

        } catch (Exception e) {
            throw new AuthFailureException("JWKS fetch failed");
        }

        return certifByKey;
    }

    /*
     * ===========================
     * JWT DECODE
     * ===========================
     */
    public DecodedJWT decodeJWT(String token, String key) {

        if (key == null) {
            throw new AuthFailureException("Invalid key");
        }

        RSAPublicKey rsaPublicKey = (RSAPublicKey) getKey(key);

        Algorithm algorithm = Algorithm.RSA256(rsaPublicKey, null);

        try {
            return JWT.require(algorithm).build().verify(token);
        } catch (JWTVerificationException e) {
            throw new AuthFailureException("JWT verification failed");
        }
    }

    /*
     * ===========================
     * CERTIFICATE PARSE
     * ===========================
     */
    public static PublicKey getKey(String key) {
        try {
            byte[] decodedPK = java.util.Base64.getDecoder().decode(key);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)
                    certFactory.generateCertificate(new ByteArrayInputStream(decodedPK));
            return cert.getPublicKey();
        } catch (Exception e) {
            throw new RuntimeException("Invalid certificate");
        }
    }
}