package com.capgemini.utility.back.repository;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.EnumDeviceType;
import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.model.PoiDTO;

@Repository
public interface PoiRepository extends JpaRepository<Poi, Long> {

    @RestResource(exported = false)
    Poi findByName(@Param("name") String name);

    @RestResource(exported = false)
    List<Poi> findByNameIn(@Param("names") List<String> names);

    @Query("SELECT poi FROM Poi poi WHERE poi.name IN (SELECT device.poiName FROM Device device "
            + " INNER JOIN device.floor floor INNER JOIN floor.building WHERE floor.id = :floorId)")
    public List<Poi> findAllViaDeviceByFloorId(@Param("floorId") long floorId);

    @Query("SELECT poi FROM Poi poi WHERE poi.name IN (SELECT device.poiName  FROM Device device "
            + " INNER JOIN device.floor floor INNER JOIN floor.building "
            + " WHERE floor.id = :floorId AND device.deviceType IN (:typeList))")
    public List<Poi> findAllViaDeviceByFloorIdAndDeviceTypeIn(@Param("floorId") long floorId,
            @Param("typeList") List<EnumDeviceType> typeList);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE country.id = :countryId")
    public List<Poi> findAllByCountryId(@Param("countryId") Long countryId);

    @Query("SELECT INDEX(attributes), attributes FROM Poi poi INNER JOIN poi.attributes attributes WHERE poi.id = :poiId")
    List<Tuple> getAttributesById(@Param("poiId") Long poiId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE city.id = :cityId AND country.id = :countryId")
    public List<Poi> findAllByCityIdAndCountryId(@Param("cityId") Long cityId, @Param("countryId") Long countryId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE site.id = :siteId AND city.id = :cityId")
    public List<Poi> findAllBySiteIdAndCityId(@Param("siteId") Long siteId, @Param("cityId") Long cityId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE building.id = :buildingId AND site.id = :siteId")
    public List<Poi> findAllByBuildingIdAndSiteId(@Param("buildingId") Long buildingId, @Param("siteId") Long siteId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE floor.id = :floorId AND building.id = :buildingId")
    public List<Poi> findAllByFloorIdAndBuildingId(@Param("floorId") Long floorId,
            @Param("buildingId") Long buildingId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country ")
    public List<Poi> findAllByCountry();

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE city.id = :cityId")
    public List<Poi> findAllByCityId(@Param("cityId") Long cityId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE site.id = :siteId")
    public List<Poi> findAllBySiteId(@Param("siteId") Long siteId);

    @Query("SELECT poi FROM Poi poi " +
            "INNER JOIN poi.floor floor " +
            "INNER JOIN floor.building building " +
            "INNER JOIN building.site site " +
            "INNER JOIN site.city city " +
            "INNER JOIN city.country country " +
            "WHERE building.id = :buildingId")
    public List<Poi> findAllByBuildingId(@Param("buildingId") Long buildingId);

    @Query(value = "SELECT * FROM poi p WHERE p.space_type_id IN (SELECT st.id FROM space_type st WHERE st.space_type_name = 'COMFORT')", nativeQuery = true)
    List<Poi> findAllWithComfortSpaceType();

    @Query("SELECT f.cdmKeyId FROM Floor f JOIN Poi p ON f.id = p.floorId WHERE p.id = :poiId")
    Long findCdmKeyIdForPoi(@Param("poiId") Long poiId);

    @Query(
    value = "SELECT DISTINCT p.* " +
            "FROM poi p " +
            "JOIN poi_attributes pa  ON pa.poi_id = p.id " +
            "JOIN floor f            ON f.id = p.floor_id " +
            "JOIN building b         ON b.id = f.building_id " +
            "JOIN site s             ON s.id = b.site_id " +
            "JOIN city c             ON c.id = s.city_id " +
            "JOIN country co         ON co.id = c.country_id " +
            "JOIN space_type st      ON st.id = p.space_type_id " +
            "JOIN poi_group pg       ON pg.id = st.poi_group_id " +
            "WHERE pa.att_key = 'conf_room_mail' " +
            "  AND pa.att_value IS NOT NULL " +
            "  AND pa.att_value <> '' " +
            "  AND (pa.att_value LIKE '_%@capgemini.com' " +
            "       OR pa.att_value LIKE '_%@sogeti.%') " +
            "  AND pg.name = 'room_conference' " +
            "  AND co.title_en NOT IN (:excludeCountries)",
    nativeQuery = true
)
List<Poi> findConferenceRoomsExcludingGermany(@Param("excludeCountries") List<String> excludeCountries);

@Query(
    value = "SELECT DISTINCT p.* " +
            "FROM poi p " +
            "JOIN poi_attributes pa  ON pa.poi_id = p.id " +
            "JOIN floor f            ON f.id = p.floor_id " +
            "JOIN building b         ON b.id = f.building_id " +
                "JOIN site s             ON s.id = b.site_id " +
                "JOIN city c             ON c.id = s.city_id " +
                "JOIN country co         ON co.id = c.country_id " +
                "JOIN space_type st      ON st.id = p.space_type_id " +
                "JOIN poi_group pg       ON pg.id = st.poi_group_id " +
                "WHERE pa.att_key = 'conf_room_mail' " +
                "  AND pa.att_value IS NOT NULL " +
                "  AND pa.att_value <> '' " +
                "  AND (pa.att_value LIKE '_%@capgemini.com' " +
                "       OR pa.att_value LIKE '_%@sogeti.%') " +
                "  AND pg.name = 'room_conference' ",
        nativeQuery = true
        )
        List<Poi> findConferenceRooms();

        @Query(value = "SELECT DISTINCT poi_id, timezone_java, att_value " +
                        "FROM meeting_restoration_via_email " +
                        "WHERE att_value IS NOT NULL AND att_value <> ''"+
                        "AND att_value LIKE '_%@capgemini.com'",
                nativeQuery = true)
        List<Object[]> findPoiTimezoneAndEmail();

        @Query(
        value = "SELECT DISTINCT p.* " +
                "FROM poi p " +
                "JOIN poi_attributes pa  ON pa.poi_id = p.id " +
                "JOIN floor f            ON f.id = p.floor_id " +
                "JOIN building b         ON b.id = f.building_id " +
                "JOIN site s             ON s.id = b.site_id " +
                "JOIN city c             ON c.id = s.city_id " +
                "JOIN country co         ON co.id = c.country_id " +
                "JOIN space_type st      ON st.id = p.space_type_id " +
                "JOIN device d ON d.poi_name = p.name " +
                "JOIN poi_group pg       ON pg.id = st.poi_group_id " +
                "WHERE pa.att_key = 'conf_room_mail' " +
                "  AND pa.att_value IS NOT NULL " +
                "  AND pa.att_value <> '' " +
                "  AND (pa.att_value LIKE '_%@capgemini.com' " +
                "       OR pa.att_value LIKE '_%@sogeti.%') " +
                "  AND pg.name = 'room_conference' " +
                "  AND d.device_type = 'TABLET'",
        nativeQuery = true
        )
        List<Poi> findConferenceRoomsForTabletMeetings();

        @Query(value = "SELECT * FROM meeting m " +
                "WHERE m.room = :roomMail " +
                "AND m.start_time_utc >= :startEpoch " +
                "AND m.end_time_utc <= :endEpoch",
        nativeQuery = true)
        List<Object[]> findEventsInMeetingTable(@Param("roomMail")  String roomMail, @Param("startEpoch") long startEpoch, @Param("endEpoch") long endEpoch);

        @Query(value = "SELECT * FROM meeting m " +
                "WHERE m.room = :roomMail " +
                "AND m.start_time >= :startEpoch ", nativeQuery = true)
                //"AND m.end_time <= :endEpoch",
        List<Object[]> findFutureEventsInMeetingTablet(@Param("roomMail")  String roomMail, @Param("startEpoch") long startEpoch);

}

