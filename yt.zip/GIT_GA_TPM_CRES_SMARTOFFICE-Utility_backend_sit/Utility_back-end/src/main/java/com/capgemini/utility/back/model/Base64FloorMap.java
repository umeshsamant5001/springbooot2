package com.capgemini.utility.back.model;

import lombok.Data;

@Data
public class Base64FloorMap {
    private String floorId;
    private String base64map;
}
