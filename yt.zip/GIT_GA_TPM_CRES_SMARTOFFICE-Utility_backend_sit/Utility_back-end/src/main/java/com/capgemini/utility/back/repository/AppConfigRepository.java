package com.capgemini.utility.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.capgemini.utility.back.model.AppConfigurationValues;
import java.util.List;
import java.lang.Boolean;
import org.springframework.data.repository.query.Param;

@Repository
public interface AppConfigRepository extends JpaRepository<AppConfigurationValues, Boolean> {

   List<AppConfigurationValues> findByIsActive(Boolean isActive);

   @Query("SELECT a FROM AppConfigurationValues a WHERE a.key = :key AND a.isActive = :isActive")
    AppConfigurationValues findByKeyAndIsActive(@Param("key") String key, @Param("isActive") Boolean isActive);

    List<AppConfigurationValues> findByType(String type);

    @Query(value = "SELECT value FROM app_config_values WHERE config_key = :configKey and is_active =1",
           nativeQuery = true)
    String findExcludeCountryList(@Param("configKey") String configKey);

    @Query(value = "SELECT value FROM app_config_values WHERE config_key = :configKey and is_active =1",
           nativeQuery = true)
    String findTabletIssueAddressList(@Param("configKey") String configKey);
    
}
