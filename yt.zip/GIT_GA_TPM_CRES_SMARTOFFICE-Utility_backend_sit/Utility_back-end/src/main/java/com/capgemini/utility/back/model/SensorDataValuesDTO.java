package com.capgemini.utility.back.model;

import lombok.Data;

@Data
public class SensorDataValuesDTO {
    private String uuid;
    private String sensorStatus;
    private Long floorId;
    private String poiTypeName;
    private String poiGroupName;
    private String poiName;
    private String poiId;
    private String poiTitle;
    private String x;
    private String y;
    private String capacity;
    private String email;
}
