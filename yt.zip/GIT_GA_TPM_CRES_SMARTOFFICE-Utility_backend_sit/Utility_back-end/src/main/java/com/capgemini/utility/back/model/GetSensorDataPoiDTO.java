package com.capgemini.utility.back.model;

import java.util.List;

import lombok.Data;

@Data
public class GetSensorDataPoiDTO {
    private Long poiId;
    private String poiName;
    private String poiTitle;
    private String spaceTypeName;
    private String x;
    private String y;
    private String capacity;
    private String email;
    private List<String> uuids;
}
