package com.capgemini.utility.back.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.capgemini.utility.back.config.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "locations")
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Locations {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "meeting_details_id")
    private MeetingDetails meetingDetails;

    @Column(name = "meeting_details_id", updatable = false, insertable = false)
    @JsonIgnore
	private String meetingDetailsId;

    @Column(name = "location_displayname")
    private String locationDisplayName;

    @Column(name = "location_locationtype")
    private String locationLocationType;

    @Column(name = "location_uniqueid")
    private String locationUniqueId;

    @Column(name = "location_uniqueidtype")
    private String locationUniqueIdType;
    
    @Column(name = "location_locationuri")
    private String locationLocationUri;

    @OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_location_address")
	private LocationAddress locationAddress;

    @OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_coordinates")
	private Coordinates coordinates;
    
}
