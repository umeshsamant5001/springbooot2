package com.capgemini.utility.back.service;

import com.capgemini.utility.back.model.AppRegistrationManagement;
import com.capgemini.utility.back.repository.DeviceTokenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;



@Service
@Slf4j
public class DeviceTokenService {   
        
    @Autowired
    private DeviceTokenRepository deviceTokenRepository;    
    
    /**
     * @param email
     * @return List<AppRegistrationManagement>
    */
    public List<AppRegistrationManagement> getAppDataForUser(String email) {
      return deviceTokenRepository.findByEmailId(email).stream()
            .collect(Collectors.toList());
    }
    /**
     * @param emails List of emails
     * @return List<AppRegistrationManagement>
    */
    public List<AppRegistrationManagement> getAppDataForUsers(List<String> emails) {
      try {
          return deviceTokenRepository.findByEmailsIn(emails);
      } catch (DataAccessException ex) {
          log.error("Failed to retrieve app data for users", ex);
          throw new IllegalStateException("Unable to retrieve app data for users");
      }
    }    

    
}