package com.capgemini.utility.back.model;

import lombok.Data;

@Data
public class SensorDataSPDTO {
    private String uuid;
    private String sensorStatus;
    private String buildingName;
    private String buildingAssetCode;
    private Long buildingId;
    private String floorName;
    private Long floorId;
    private Integer floorIndex;
    private String poiTypeName;
    private String poiGroupName;
    private String poiName;
    private String poiId;
    private String poiTitle;
    private String x;
    private String y;
    private String capacity;
    private String email;
}
