package com.capgemini.utility.back.config;

import org.hibernate.Hibernate;

public class LazyFieldsFilter {
    @Override
    public boolean equals(Object obj) {
        return !Hibernate.isInitialized(obj);
    }
}
