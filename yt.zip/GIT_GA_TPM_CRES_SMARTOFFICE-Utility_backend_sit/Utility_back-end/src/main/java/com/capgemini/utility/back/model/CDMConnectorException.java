package com.capgemini.utility.back.model;

public class CDMConnectorException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 7748650921857496286L;

	public CDMConnectorException(String message) {
		super(500, ErrorCodes.JC_CONNECTOR_UNEXPECTED_ERROR, message);
	}

}
