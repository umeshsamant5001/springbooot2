package com.capgemini.utility.back.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.io.IOException;
import java.math.BigInteger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import com.capgemini.utility.back.config.ApplicationProperties;
import com.capgemini.utility.back.config.Constants;
import com.capgemini.utility.back.mapper.PushNotificationRevampMapper;
import com.capgemini.utility.back.model.AppRegistrationManagement;
import com.capgemini.utility.back.model.PushNotificationRevamp;
import com.capgemini.utility.back.model.PushNotificationRevampDTO;
import com.capgemini.utility.back.repository.PushNotificationRevampRepository;
import com.capgemini.utility.back.utils.PushNotificcationRevampUtil;
import com.google.api.core.ApiFuture;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.firebase.messaging.Notification;
import java.util.function.Function;

@Service
@Slf4j
public class PushNotificationRevampService {

    @Autowired
    private PushNotificationRevampRepository pushNotificationRepository;

    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    AzureKeyVaultService azureKeyVaultService;

    @Autowired
    private TaskExecutor pushExecutor;

    @PersistenceContext
    private EntityManager entityManager;

    private static final String CONFIG_PATH = "application.notificationrevampchron.push";
    private final AtomicBoolean notificationSchedulerRunning = new AtomicBoolean(false);

    /**
     * Retrieves an ExternalPushNotification entity by its ID.
     * Throws ResourceNotFoundException if the entity is not found.
     * 
     * @param id The ID of the ExternalPushNotification entity.
     * @return The ExternalPushNotification entity.
     */
    public PushNotificationRevamp findById(Long id) {

        try {
            PushNotificationRevamp extrernalPushsNotification = pushNotificationRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "ExternalPushNotification not found with existing notification ID :: " + id));
            return extrernalPushsNotification;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve external push notification by id", ex);
            throw new IllegalStateException("Unable to retrieve external push notification");
        }
    }

    /**
     * Saves a new ExternalPushNotification entity based on the provided DTO.
     * Sets the creation date and notification sent status.
     * 
     * @param pushNotificationDTO The DTO containing the data to be saved.
     * @return The saved ExternalPushNotification entity.
     */
    public PushNotificationRevamp saveExternalPushNotificationData(PushNotificationRevampDTO pushNotificationDTO) {

        PushNotificationRevamp pushNotification = PushNotificationRevampMapper.INSTANCE
                .pushNotificationRevampDTOToPushNotificationRevamp(pushNotificationDTO);
        pushNotification.setCreatedDateTime((new Date()).getTime() / 1000);
        pushNotification.setNotificationSent(false);
        PushNotificationRevamp savedPushNotification = pushNotificationRepository.save(pushNotification);
        return savedPushNotification;
    }

    /**
     * Retrieves all ExternalPushNotification entities.
     * 
     * @return A list of all ExternalPushNotification entities.
     */
    public List<PushNotificationRevamp> getAllPushNotifications() {
        try {
            return pushNotificationRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve external push notifications", ex);
            throw new IllegalStateException("Unable to retrieve external push notifications");
        }
    }

    /**
     * Deletes an ExternalPushNotification entity by its ID.
     * 
     * @param id The ID of the ExternalPushNotification entity to be deleted.
     */
    public void deletePushNotification(Long id) {
        pushNotificationRepository.deleteById(id);
    }

    /**
     * Updates an existing ExternalPushNotification entity.
     * 
     * @param pushNotification The ExternalPushNotification entity to be updated.
     * @return The updated ExternalPushNotification entity.
     */
    public PushNotificationRevamp updatePushNotification(PushNotificationRevamp PushNotification) {
        return pushNotificationRepository.save(PushNotification);
    }

    /**
     * Sends a push notification to an Android device using Firebase Messaging.
     * Constructs the message using the provided notification data and device token.
     * 
     * @param pushNotification The ExternalPushNotification entity containing the
     *                         notification data.
     * @param token            The device token to which the notification will be
     *                         sent.
     * @return The response from FirebaseMessaging's send method.
     */
    public String sendAndroidPushNotification(PushNotificationRevamp pushNotification, String token , String instanceId) {

        Map<String, String> androidDataMap = getMapFromNotificationMessage(pushNotification.getNotificationMessage());
        AndroidConfig androidConfig = AndroidConfig.builder()
                .putAllData(androidDataMap)
                .build();
        Message message = Message.builder()
                .setAndroidConfig(androidConfig)
                .setToken(token)
                .build();
        String response = null;
        String sanitizedEmployeeEmail = sanitizeForLog(pushNotification.getEmployeeEmail());
        String sanitizedNotificationDateTime = sanitizeForLog(String.valueOf(pushNotification.getNotificationDateTime()));
        try {
            response = FirebaseMessaging
                    .getInstance(FirebaseApp.getInstance(Constants.ANDROIDAPP))
                    .send(message);
            log.info(
                "event=push_send status=success platform=android token={} email={} notificationDateTime={} notificationId={} instanceId={} response={}",
                sanitizeForLog(token),
                sanitizedEmployeeEmail,
                sanitizedNotificationDateTime,
                pushNotification.getId(),
                sanitizeForLog(instanceId),
                sanitizeForLog(response));
        } catch (FirebaseMessagingException e) {
            response = Objects.nonNull(e.getMessagingErrorCode()) ? e.getMessagingErrorCode().name() : e.getMessage();
            log.error(
                    "event=push_send status=failure platform=android token={} email={} notificationDateTime={} notificationId={} instanceId={} errorCause={} errorMessage={}",
                    sanitizeForLog(token),
                    sanitizedEmployeeEmail,
                    sanitizedNotificationDateTime,
                    pushNotification.getId(),
                    sanitizeForLog(instanceId),
                    sanitizeForLog(String.valueOf(e.getCause())),
                    sanitizeForLog(e.getMessage()),
                    e);
        }
        return response;
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * Constructs the HTTP request using the provided JWT token, device token, and
     * payload.
     * 
     * @param jwtToken    The JWT token for authentication with APNs.
     * @param deviceToken The device token to which the notification will be sent.
     * @param payLoad     The JSON payload representing the notification data.
     * @return The response body from the APNs HTTP request.
     */
    private String sendAPNSNotification(String jwtToken, String deviceToken, String payLoad) throws Exception {
        String apnsHost = applicationProperties.getPushNotificationRevamp().getApnsHost();
        String apnsTopic = applicationProperties.getPushNotificationRevamp().getApnsTopic();
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apnsHost + "/3/device/" + deviceToken))
                .POST(HttpRequest.BodyPublishers.ofString(payLoad))
                .setHeader("authorization", "bearer " + jwtToken)
                .setHeader("apns-topic", apnsTopic)
                .setHeader("Content-Type", "application/json")
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        Optional<String> apnsId = response.headers().firstValue("apns-id");
        return "apnsId:" + apnsId.get() + "|" + response.body();
        // return response.body();
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * Constructs the payload and generates the JWT token for authentication.
     * 
     * @param notification The ExternalPushNotification entity containing the
     *                     notification data.
     * @param deviceToken  The device token to which the notification will be sent.
     * @return The response from APNs.
     */
    public String sendIosPushNotification(PushNotificationRevamp notification, String deviceToken, String instanceId) {
        String payLoad = null;
        String keyId = null;
        String base64PrivateKey = null;
        try {
            payLoad = buildApnsJsonPayload(notification.getNotificationMessage());
            log.info("event=apns_payload_build status=success notificationId={} deviceToken={} instanceId={} payloadPreview={}",
                    notification.getId(),
                    sanitizeForLog(deviceToken),
                    sanitizeForLog(instanceId),
                    sanitizeForLog(payLoad));
        } catch (IOException ioe) {
            log.error("event=apns_payload_build status=failure notificationId={} instanceId={} payloadPreview={} errorMessage={}",
                    notification.getId(),
                    sanitizeForLog(instanceId),
                    sanitizeForLog(payLoad),
                    sanitizeForLog(ioe.getMessage()),
                    ioe);
        }
        keyId = applicationProperties.getPushNotificationRevamp().getKeyId();
        base64PrivateKey = applicationProperties.getPushNotificationRevamp().getBase64PrivateKey();

        String teamId = applicationProperties.getPushNotificationRevamp().getTeamId();
        String JwtToken = null;
        String response = null;
        String sanitizedEmployeeEmail = sanitizeForLog(notification.getEmployeeEmail());
        String sanitizedNotificationDateTime = sanitizeForLog(String.valueOf(notification.getNotificationDateTime()));
        try {
            JwtToken = PushNotificcationRevampUtil.generateToken(teamId, keyId, base64PrivateKey);
        } catch (Exception e) {
            log.error("event=apns_token_generate status=failure notificationId={} instanceId={} errorMessage={}",
                    notification.getId(),
                    sanitizeForLog(instanceId),
                    sanitizeForLog(e.getMessage()),
                    e);
        }
        try {
            response = sendAPNSNotification(JwtToken, deviceToken, payLoad);
            String apnsId = response.split("\\|")[0];
            log.info(
                    "event=push_send status=success platform=ios token={} email={} notificationDateTime={} notificationId={} apnsId={} instanceId={} response={}",
                    sanitizeForLog(deviceToken), sanitizedEmployeeEmail, sanitizedNotificationDateTime, notification.getId(),
                    sanitizeForLog(apnsId), sanitizeForLog(instanceId), sanitizeForLog(response));


        } catch (Exception e) {
            log.error(
                    "event=push_send status=failure platform=ios token={} email={} notificationDateTime={} notificationId={} instanceId={} errorCause={} errorMessage={}",
                    sanitizeForLog(deviceToken), sanitizedEmployeeEmail, sanitizedNotificationDateTime, notification.getId(),
                    sanitizeForLog(instanceId), sanitizeForLog(String.valueOf(e.getCause())), sanitizeForLog(e.getMessage()),
                    e);
        }
        return response;
    }

    /**
     * Saves or updates a list of ExternalPushNotificationDTO entities in the
     * database.
     * Updates the status of existing notifications or inserts new ones.
     * 
     * @param requests The list of ExternalPushNotificationDTO entities to be saved
     *                 or updated.
     * @return A list of maps containing the transaction details and status.
     */
    @Transactional
    public List<Map<String, Object>> saveOrUpdate(List<PushNotificationRevampDTO> requests) {

        List<Map<String, Object>> resultList = new ArrayList<>();
        Long startTime = System.currentTimeMillis();
        log.info("event=push_notification_save_or_update status=start startTimeMs={} recordCount={}",
            startTime,
            Objects.nonNull(requests) ? requests.size() : 0);

        if (Objects.isNull(requests) || requests.isEmpty()) {
            Long endTime = System.currentTimeMillis();
            log.info("event=push_notification_save_or_update status=end endTimeMs={} durationMs={} recordCount={}",
                endTime,
                (endTime - startTime),
                0);
            return resultList;
        }

        for (PushNotificationRevampDTO dto : requests) {
            if (Objects.nonNull(dto) && Objects.nonNull(dto.getKeyId())
                    && Objects.nonNull(dto.getNotificationDateTime())) {
                try {
                    resultList.add(executeSaveOrUpdateStoredProcedure(dto));
                } catch (Exception e) {
                    log.error("event=push_notification_save_or_update status=failure keyId={} notificationDateTime={} errorMessage={}",
                        sanitizeForLog(String.valueOf(dto.getKeyId())),
                        sanitizeForLog(dto.getNotificationDateTime()),
                        sanitizeForLog(e.getMessage()),
                        e);
                    resultList.add(saveErrorAndMapResult(dto, e.getMessage()));
                }

            }
        }

        Long endTime = System.currentTimeMillis();
        log.info("event=push_notification_save_or_update status=end endTimeMs={} durationMs={} recordCount={}",
            endTime,
            (endTime - startTime),
            Objects.nonNull(requests) ? requests.size() : 0);
        return resultList;

    }

    private Map<String, Object> executeSaveOrUpdateStoredProcedure(PushNotificationRevampDTO dto) {
        validateUpsertDTO(dto);

        String validatedApplicationName = validateAndNormalizeText(dto.getApplicationName(), 255, false,
                "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$", "Invalid application name");
        String validatedTitle = validateAndNormalizeText(dto.getTitle(), 255, false,
                "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$", "Invalid title");
        String validatedBody = validateAndNormalizeText(dto.getBody(), 4000, false,
                "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$", "Invalid body");
        String validatedEmployeeEmail = validateAndNormalizeEmail(dto.getEmployeeEmail());
        String validatedNotificationDateTime = validateAndNormalizeText(dto.getNotificationDateTime(), 50, true,
                "^[0-9T:\\-\\s/.]*$", "Invalid notification date time");
        String validatedNotificationMessage = validateAndNormalizeText(dto.getNotificationMessage(), 4000, false,
                "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$", "Invalid notification message");

        Query query = entityManager.createNativeQuery(
                "EXEC dbo.usp_upsert_externalpushnotification " +
                "@keyid = :keyId, " +
                "@notification_datetime = :notificationDateTime, " +
                "@application_name = :applicationName, " +
                "@title = :title, " +
                "@body = :body, " +
                "@employeeemail = :employeeEmail, " +
                "@notification_message = :notificationMessage, " +
                "@status = :status");

        query.setParameter("keyId", dto.getKeyId());
        query.setParameter("notificationDateTime", validatedNotificationDateTime);
        query.setParameter("applicationName", validatedApplicationName);
        query.setParameter("title", validatedTitle);
        query.setParameter("body", validatedBody);
        query.setParameter("employeeEmail", validatedEmployeeEmail);
        query.setParameter("notificationMessage", validatedNotificationMessage);
        query.setParameter("status", Objects.nonNull(dto.getStatus()) ? dto.getStatus() : Boolean.FALSE);

        @SuppressWarnings("unchecked")
        List<Object[]> rows = query.getResultList();
        if (Objects.nonNull(rows) && !rows.isEmpty() && Objects.nonNull(rows.get(0))) {
            Object[] row = rows.get(0);
            Map<String, Object> response = new HashMap<>();
            response.put("transactionId", toLong(row[0]));
            response.put("keyId", Objects.nonNull(row[1]) ? Long.valueOf(String.valueOf(row[1])) : dto.getKeyId());
            response.put("notificationDateTime",
                    Objects.nonNull(row[2]) ? String.valueOf(row[2]) : validatedNotificationDateTime);
            response.put("status", Objects.nonNull(row[3]) ? String.valueOf(row[3]) : Constants.SUCCESS);
            return response;
        }
        return createStatusMap(null, dto, Constants.SUCCESS);
    }

    private Long toLong(Object value) {
        if (Objects.isNull(value)) {
            return null;
        }
        if (value instanceof BigInteger) {
            return ((BigInteger) value).longValue();
        }
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        return Long.valueOf(String.valueOf(value));
    }

    /**
     * Saves the PushNotificationRevamp entity to the database and maps the result
     * into a response map.
     * If saving fails due to a DataAccessException, returns a failure status with
     * relevant details.
     * 
     * @param entity the entity to be saved
     * @return a map containing transaction details and status
     */
    private Map<String, Object> saveAndMapResult(PushNotificationRevamp entity) {
        Map<String, Object> map = new HashMap<>();
        try {
            // Reconstruct the entity from validated primitive values to break taint flow
            PushNotificationRevamp safeEntity = new PushNotificationRevamp();
            // Explicitly nullify the id so the database generates it — prevents Unsafe Object Binding
            safeEntity.setId(Objects.nonNull(entity.getId())
                    ? Long.valueOf(String.valueOf(entity.getId()))
                    : null);
            safeEntity.setKeyId(Objects.nonNull(entity.getKeyId())
                    ? Long.valueOf(String.valueOf(entity.getKeyId()))
                    : null);
            safeEntity.setApplicationName(Objects.nonNull(entity.getApplicationName())
                    ? new String(entity.getApplicationName())
                    : null);
            safeEntity.setTitle(Objects.nonNull(entity.getTitle())
                    ? new String(entity.getTitle())
                    : null);
            safeEntity.setBody(Objects.nonNull(entity.getBody())
                    ? new String(entity.getBody())
                    : null);
            safeEntity.setEmployeeEmail(Objects.nonNull(entity.getEmployeeEmail())
                    ? new String(entity.getEmployeeEmail())
                    : null);
            safeEntity.setNotificationDateTime(Objects.nonNull(entity.getNotificationDateTime())
                    ? new String(entity.getNotificationDateTime())
                    : null);
            safeEntity.setNotificationMessage(Objects.nonNull(entity.getNotificationMessage())
                    ? new String(entity.getNotificationMessage())
                    : null);
            safeEntity.setStatus(Objects.nonNull(entity.getStatus())
                    ? Boolean.valueOf(String.valueOf(entity.getStatus()))
                    : Boolean.FALSE);
            safeEntity.setCreatedDateTime(entity.getCreatedDateTime());
            safeEntity.setUpdatedDateTime(entity.getUpdatedDateTime());
            PushNotificationRevamp saved = pushNotificationRepository.save(safeEntity);
            PushNotificationRevampDTO dto = PushNotificationRevampMapper.INSTANCE
                    .pushNotificationRevampToPushNotificationRevampDTO(saved);
            map.put("transactionId", dto.getId());
            map.put("keyId", dto.getKeyId());
            map.put("notificationDateTime", dto.getNotificationDateTime());
            map.put("status", Constants.SUCCESS);
        } catch (DataAccessException dae) {
            map.put("keyId", entity.getKeyId());
            map.put("notificationDateTime", entity.getNotificationDateTime());
            map.put("transactionFailureDateTime", (new Date()).getTime() / 1000);
            map.put("status", "Failed for the reason: " + dae.getMessage());
        }
        return map;
    }

    /**
     * Creates a status map containing transaction ID, key ID, notification
     * date/time, and status.
     * 
     * @param transactionId the ID of the transaction
     * @param dto           the DTO containing notification details
     * @param status        the status message to be included
     * @return a map with transaction details and status
     */
    private Map<String, Object> createStatusMap(Long transactionId, PushNotificationRevampDTO dto, String status) {
        Map<String, Object> map = new HashMap<>();
        map.put("transactionId", transactionId);
        map.put("keyId", dto.getKeyId());
        map.put("notificationDateTime", dto.getNotificationDateTime());
        map.put("status", status);
        return map;
    }

    /**
     * Scheduled method to process and send push notifications in
     * batches
     * Updates the status of sent notifications in the databa
     */
    @Scheduled(cron = "${" + CONFIG_PATH + ".cron}", zone = "${" + CONFIG_PATH + ".tz}")
    @Transactional
    public void processNotification() {
        if (!notificationSchedulerRunning.compareAndSet(false, true)) {
            log.warn("Skipping schedule run because a previous notification run is still in progress");
            return;
        }

        Long startTime = System.currentTimeMillis();
        String instanceId = getSchedulerInstanceId();
            log.info("event=push_scheduler_run status=start startTimeMs={} instanceId={}",
                    startTime, sanitizeForLog(instanceId));
        try {
            log.info("event=push_scheduler_run status=processing startTimeMs={} instanceId={}",
                    startTime, sanitizeForLog(instanceId));
            List<Long> candidateIds = pushNotificationRepository.findAllMatchingNotificationIds();
            log.info("Found {} candidate notification IDs for processing", candidateIds.size());
            List<PushNotificationRevamp> claimedNotifications = claimNotificationsForCurrentRun(candidateIds, instanceId);

            if (!claimedNotifications.isEmpty()) {

                log.info("event=push_scheduler_dispatch status=start claimedNotificationsCount={} instanceId={}",
                        claimedNotifications.size(), sanitizeForLog(instanceId));
                sendInBatches(claimedNotifications, true , instanceId);
                log.info("event=push_scheduler_run status=end endTimeMs={} instanceId={}",
                    System.currentTimeMillis(), sanitizeForLog(instanceId));
            
                
            } else {
                
                log.info("event=push_scheduler_claim_due status=empty instanceId={} , procress end time={}",
                        sanitizeForLog(instanceId), System.currentTimeMillis());
            }
        } finally {
            notificationSchedulerRunning.set(false);
        }
    }

    private List<PushNotificationRevamp>  claimNotificationsForCurrentRun(List<Long> candidateIds, String instanceId ) {
        List<PushNotificationRevamp> claimed = new ArrayList<>();
        if (Objects.isNull(candidateIds) || candidateIds.isEmpty()) {
            return claimed;
        }

        long epochSeconds = (new Date()).getTime() / 1000;
        for (Long candidateId : candidateIds) {
            if (Objects.isNull(candidateId)) {
                continue;
            }
            log.info("event=push_scheduler_claim_single status=start notificationId={} instanceId={}",
                    candidateId,
                    sanitizeForLog(instanceId));
            int updatedRows = pushNotificationRepository.claimNotificationForProcessing(
                    candidateId,
                    Constants.SCHEDULER,
                    epochSeconds,
                    epochSeconds);

            log.info("event=push_scheduler_claim_single status=updated notificationId={} updatedRows={} instanceId={}",
                    candidateId,
                    updatedRows,
                    sanitizeForLog(instanceId));
            if (updatedRows > 0) {
                log.info("event=push_scheduler_claim_single status=claimed notificationId={} updatedRows={} instanceId={}",
                    candidateId,
                    updatedRows,
                    sanitizeForLog(instanceId));
                pushNotificationRepository.findById(candidateId).ifPresent(claimed::add);
            }
        }
        return claimed;
    }


    private void sendInBatches(List<PushNotificationRevamp> notifications, boolean isFirst, String instanceId) {
        if (Objects.isNull(notifications) || notifications.isEmpty()) {
            log.info("No notifications found to process in sendInBatches");
            return;
        }

        List<List<PushNotificationRevamp>> batches = partition(notifications, 500);
        for (List<PushNotificationRevamp> batch : batches) {
            try {
                pushExecutor.execute(() -> {
                    try {
                        processBatch(batch , instanceId);
                    } catch (Exception ex) {
                        log.error("Batch processing failed in sendInBatches", ex);
                    }
                });
            } catch (Exception ex) {
                log.error("Failed to submit batch to pushExecutor in sendInBatches", ex);
            }
        }
    }

    /**
     * Creates partitions of the given list.
     * 
     * @param list The list to be partitioned.
     * @param size The size of each partition.
     * @return A list of partitions.
     */
    public static <T> List<List<T>> partition(List<T> list, int size) {
        List<List<T>> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            partitions.add(new ArrayList<>(list.subList(i, Math.min(i + size, list.size()))));
        }
        return partitions;
    }

    /**
     * Processes a batch of push notifications.
     * Sends notifications to Android and iOS devices and updates the status.
     * 
     * @param batch The list of ExternalPushNotification entities to be processed.
     */
    private void processBatch(List<PushNotificationRevamp> batch , String instanceId) {
        for (PushNotificationRevamp notification : batch) {
            int successCount = 0;
            StringBuilder failureReason = new StringBuilder();
            StringBuilder messageIdsForSuccess = new StringBuilder();

            try {
                List<AppRegistrationManagement> appData = deviceTokenService
                        .getAppDataForUser(notification.getEmployeeEmail());
                if (appData.isEmpty()) {
                    log.info("event=push_device_lookup status=empty email={} notificationId={} instanceId={}",
                        sanitizeForLog(notification.getEmployeeEmail()),
                        notification.getId(),
                        sanitizeForLog(instanceId));
                    continue;
                }
                // commented out as below fields are already set in claimNotificationsForCurrentRun method
                // notification.setNotificationSentBy(Constants.SCHEDULER);
                // notification.setNotificationSent(true);
                // notification.setNotificationSentTime((new Date()).getTime() / 1000);
                // Added new logic to filter out duplicate device registration tokens for the same user
                List<AppRegistrationManagement> uniqueAppData =
                            appData.stream()
                            .filter(app -> Objects.nonNull(app.getDeviceRegistrationToken())
                                            && !app.getDeviceRegistrationToken().trim().isEmpty())
                            .collect(Collectors.toMap(
                                        AppRegistrationManagement::getDeviceRegistrationToken,
                                        Function.identity(),
                                        (existing, duplicate) -> existing))
                                        .values()
                                        .stream()
                                        .collect(Collectors.toList());

                if (uniqueAppData.size() < appData.size()) {

                    log.warn("Duplicate device tokens detected for user={} Original records={}, Unique records={}",
                        sanitizeForLog(notification.getEmployeeEmail()),
                        appData.size(),
                        uniqueAppData.size());
                }

                for (AppRegistrationManagement app : uniqueAppData) {
                    String response = sendNotification(notification, app , instanceId);
                    boolean isSuccess = isSuccessfulResponse(response, app.getDeviceType().toString());
                    if (isSuccess) {
                        log.info("event=push_send_attempt status=success deviceId={} appRegistrationToken={} email={} notificationId={} notificationDateTime={} instanceId={}",
                                sanitizeForLog(app.getDeviceId()), sanitizeForLog(app.getDeviceRegistrationToken()), sanitizeForLog(notification.getEmployeeEmail()),
                                sanitizeForLog(String.valueOf(notification.getId())), sanitizeForLog(String.valueOf(notification.getNotificationDateTime())), instanceId);
                        successCount++;
                        String messageId = getMessageIdForSuccess(response, app.getDeviceType().toString());
                        if(messageIdsForSuccess.length() > 0) {
                            messageIdsForSuccess.append("|");
                        }
                        messageIdsForSuccess.append(messageId);
                        //messageIdsForSuccess.append(getMessageIdForSuccess(response, app.getDeviceType().toString()))
                        //        .append("|");
                    } else {
                        log.info("event=push_send_attempt status=failure deviceId={} appRegistrationToken={} email={} notificationId={} notificationDateTime={} instanceId={}",
                                sanitizeForLog(app.getDeviceId()), sanitizeForLog(app.getDeviceRegistrationToken()), sanitizeForLog(notification.getEmployeeEmail()),
                                sanitizeForLog(String.valueOf(notification.getId())), sanitizeForLog(String.valueOf(notification.getNotificationDateTime())), instanceId);
                        failureReason.append("DEVICE ID")
                                .append(" : ")
                                .append(app.getDeviceId())
                                .append(" | ")
                                .append("ERROR")
                                .append(" : ")
                                .append(getErrorFromResponse(response, app.getDeviceType().toString()))
                                .append(" | ")
                                .append(" MessageID")
                                .append(" : ")
                                .append(getMessageIdForFailure(response, app.getDeviceType().toString()))
                                .append(",");
                    }
                }
                updateNotificationStatus(notification, successCount, appData.size(), failureReason.toString(),
                        messageIdsForSuccess.toString());
            } catch (Exception e) {
                log.error("event=push_batch_process status=failure keyId={} notificationId={} notificationDateTime={} instanceId={} errorMessage={}",
                        sanitizeForLog(String.valueOf(notification.getKeyId())),
                        sanitizeForLog(String.valueOf(notification.getId())),
                        sanitizeForLog(String.valueOf(notification.getNotificationDateTime())),
                    sanitizeForLog(instanceId),
                    sanitizeForLog(e.getMessage()),
                        e);
            }
        }
        pushNotificationRepository.saveAll(batch);
    }

    /**
     * Sends a push notification to a device based on its type (Android or iOS).
     * 
     * @param notification The notification object containing the message and
     *                     metadata.
     * @param app          The app registration details including device type and
     *                     token.
     * @return The response string from the push notification service.
     */
    private String sendNotification(PushNotificationRevamp notification, AppRegistrationManagement app ,String instanceId) {
        return app.getDeviceType().toString().equals(Constants.ANDROID)
                ? sendAndroidPushNotification(notification, app.getDeviceRegistrationToken(), instanceId)
                : sendIosPushNotification(notification, app.getDeviceRegistrationToken(), instanceId);
    }

    /**
     * Determines whether the response from the push notification service indicates
     * success.
     * 
     * @param response   The response string returned by the push service.
     * @param deviceType The type of device ("ANDROID" or "IOS").
     * @return true if the response indicates a successful push; false otherwise.
     */
    private boolean isSuccessfulResponse(String response, String deviceType) {
        return (deviceType.equals(Constants.ANDROID) && response != null && response.contains("projects")) ||
                (deviceType.equals(Constants.IOS) && response != null && response.isEmpty());
    }

    /**
     * Updates the status of the notification based on the number of successful
     * deliveries.
     *
     * @param notification  The notification object to update.
     * @param successCount  The number of successful deliveries.
     * @param total         The total number of attempted deliveries.
     * @param failureReason The reason for failure if not all deliveries were
     *                      successful.
     */
    private void updateNotificationStatus(PushNotificationRevamp notification, int successCount, int total,
            String failureReason, String successMessageIds) {
        if (successCount == total) {
            notification.setNotificationStatus(Constants.SUCCESS);
            notification.setSuccessMessageIds(successMessageIds);

        } else {
            notification.setNotificationStatus(Constants.PARTIALSUCCESS);
            notification.setNotificationFailureReason(failureReason);
            notification.setNotificationFailurTime((new Date()).getTime() / 1000);
        }
    }

    /**
     * To send notification in send and retry mechanism.
     * 
     * @param message      Firebase Message.
     * @param maxRetries:  Maximum number of attempts.
     * @param delayMillis: milliseconds to delay.
     * @return completable
     */
    public CompletableFuture<String> sendWithRetry(
            Message message,
            int maxRetries,
            long initialDelayMillis) {
        return attemptSend(message, 1, maxRetries, initialDelayMillis);
    }

    /**
     * Internal method to send FCM notifications.
     * 
     * @param message:     Firebase Message.
     * @param attempt:     number of attempts.
     * @param maxAttempts: Maximum number of attempts.
     * @param delayMillis: milliseconds to delay.
     */
    private CompletableFuture<String> attemptSend(
            Message message,
            int attempt,
            int maxAttempts,
            long delayMillis) {
        return toCompletbaleFuture(
                FirebaseMessaging.getInstance(FirebaseApp.getInstance(Constants.ANDROIDAPP)).sendAsync(message))
                .thenApply(response -> {
                    log.info("Attempt %d succeeded: %s%n", attempt, response);
                    return response;
                })
                .exceptionally(ex -> {
                    log.info("Attempt %d failed: %s%n", attempt, ex.getMessage());
                    if (attempt >= maxAttempts) {
                        throw new RuntimeException("Push notification failed after " + maxAttempts + " attempts", ex);
                    }

                    try {
                        TimeUnit.MILLISECONDS.sleep(delayMillis); // backoff delay
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    long nextDelay = delayMillis * 2; // Exponential backoff
                    return attemptSend(message, attempt + 1, maxAttempts, nextDelay).join();
                });
    }

    /**
     * Converts a Firebase ApiFuture to a CompletableFuture.
     * 
     * @param apiFuture The ApiFuture to be converted.
     * @return A CompletableFuture representing the result of the ApiFuture.
     */
    private <T> CompletableFuture<T> toCompletbaleFuture(ApiFuture<T> apiFuture) {
        CompletableFuture<T> cmpltblefuture = new CompletableFuture<>();
        new Thread(() -> {
            try {
                T result = apiFuture.get();
                cmpltblefuture.complete(result);
            } catch (Exception e) {
                cmpltblefuture.completeExceptionally(e);
            }

        }).start();
        return cmpltblefuture;
    }

    /**
     * Generates a map from the JSON string representing the notification message.
     * 
     * @param notificationMessgeJson The JSON string representing the notification
     *                               message.
     * @return A map containing the notification data.
     */
    private Map<String, String> getMapFromNotificationMessage(String notificationMessgeJson) {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> map = new HashMap<String, String>();
        try {
            map = objectMapper.readValue(notificationMessgeJson,
                    new TypeReference<Map<String, String>>() {
                    });
        } catch (IOException e) {
            log.error("Unable to parse notification message JSON", e);
        }
        return map;
    }

    /**
     * Creates a JSON payload for APNs notifications.
     * Constructs the payload using the provided notification message data.
     * 
     * @param notificationMessage The notification message data.
     * @return The JSON payload for APNs notifications.
     * @throws IOException If an error occurs while constructing the payload.
     */
    private String buildApnsJsonPayload(String notificationMessage) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> dataMap = getMapFromNotificationMessage(notificationMessage);
        Map<String, Object> alert = Map.of(
                "title", dataMap.get("title"),
                "body", dataMap.get("body"));
        Map<String, Object> aps = new HashMap<>();
        aps.put("alert", alert);
        aps.put("category", "INVITE_CATEGORY");
        aps.put("sound", "default");
        aps.put("mutable-content", 1);
        aps.put("content-available", 1);

        for (String key : List.of(
                "AcceptButtonText", "AssetDate", "AssetTime_24h", "CancelButtonText",
                "EmployeeEmail", "KeyId", "OnBehalfOf", "URLToRedirect_onMsgClick")) {
            aps.put(key, dataMap.get(key));
        }
        Map<String, Object> payload = Map.of("aps", aps);
        return objectMapper.writeValueAsString(payload);
    }

    /**
     * Extracts an error message from the given JSON responses based on the device
     * type.
     * 
     * @param jsonAndroidResponse JSON response string from an Android device
     * @param jsonIosResponse     JSON response string from an iOS device
     * @param deviceType          Type of device ("ANDROID" or "IOS")
     * @return Extracted error message, or null if not found or an exception occurs
     */
    private String getErrorFromResponse(String jsonResponse, String deviceType) {
        String error = null;
        try {
            // Create ObjectMapper instance
            ObjectMapper objectMapper = new ObjectMapper();
            // Parse JSON response
            if (Objects.nonNull(jsonResponse)) {
                // Extract specific fields
                if (deviceType.equals(Constants.IOS)) {
                    if (jsonResponse.split("\\|").length > 1) {
                        JsonNode rootNode = objectMapper.readTree(jsonResponse.split("\\|")[1]);
                        error = rootNode.path("reason").asText();
                    }
                } else {
                    error = jsonResponse;
                }
            }
        } catch (IOException e) {
            log.error("Unable to parse notification response for deviceType: {}", sanitizeForLog(deviceType), e);
        }
        return error;
    }

    /**
     * Sends a push notification to a device based on its type (Android or iOS).
     * 
     * @param pushNotificationRevampDTO The PushNotificationRevampDTO object
     *                                  containing the message and metadata.
     * @return The response string from the push notification service.
     */
    public Map<String, Object> sendResposnseNotification(PushNotificationRevampDTO pushNotificationRevampDTO) {
        int successCount = 0;
        String response = null;
        Map<String, Object> responseMap = new HashMap<String, Object>();
        try {
            List<AppRegistrationManagement> appData = deviceTokenService
                    .getAppDataForUser(pushNotificationRevampDTO.getEmployeeEmail());
            if (appData.isEmpty()) {
                log.info("No AppRegistrationData found for {}",
                        sanitizeForLog(pushNotificationRevampDTO.getEmployeeEmail()));
            }

            for (AppRegistrationManagement app : appData) {
                response = sendResponseNotification(pushNotificationRevampDTO.getTitle(),
                        pushNotificationRevampDTO.getNotificationMessage(), app);
                boolean isSuccess = isSuccessfulResponse(response, app.getDeviceType().toString());
                if (isSuccess) {
                    successCount++;
                }
            }
            if (successCount > 0) {
                response = Constants.SUCCESS;
            } else {
                response = Constants.PARTIALSUCCESS;
            }
        } catch (Exception e) {
            log.error("Error Sending Notification for KeyId : {}",
                    sanitizeForLog(String.valueOf(pushNotificationRevampDTO.getKeyId())), e);
        }

        responseMap.put("keyId", pushNotificationRevampDTO.getKeyId());
        responseMap.put("notificationMessage", response);

        return responseMap;
    }

    private void validateUpsertDTO(PushNotificationRevampDTO dto) {
        if (Objects.isNull(dto)) {
            throw new IllegalArgumentException("Push notification payload is required");
        }
        if (Objects.isNull(dto.getKeyId()) || Long.valueOf(String.valueOf(dto.getKeyId())) < 1L) {
            throw new IllegalArgumentException("Invalid keyId");
        }
    }

    private String validateAndNormalizeText(String value, int maxLength, boolean required, String pattern,
            String errorMessage) {
        if (Objects.isNull(value)) {
            if (required) {
                throw new IllegalArgumentException(errorMessage);
            }
            return null;
        }
        String validated = String.valueOf(value).trim();
        if (required && validated.isEmpty()) {
            throw new IllegalArgumentException(errorMessage);
        }
        if (validated.length() > maxLength || !validated.matches(pattern)) {
            throw new IllegalArgumentException(errorMessage);
        }
        return new String(validated);
    }

    private String validateAndNormalizeEmail(String value) {
        if (Objects.isNull(value)) {
            throw new IllegalArgumentException("Invalid employee email");
        }
        String validated = String.valueOf(value).trim();
        if (validated.isEmpty() || validated.length() > 255
                || !validated.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new IllegalArgumentException("Invalid employee email");
        }
        return new String(validated);
    }


    private String sanitizeForLog(String input) {
        if (Objects.isNull(input)) {
            return null;
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }


    /**
     * Sends a push notification to a device based on its type (Android or iOS).
     * 
     * @param title               The title for notification.
     * @param notificationMessage The message for notification.
     * @param app                 The app registration details including device type
     *                            and token.
     * @return The response string from the push notification service.
     */
    private String sendResponseNotification(String title, String notificationMessage, AppRegistrationManagement app) {
        return app.getDeviceType().toString().equals(Constants.ANDROID)
                ? sendAndroidResposneNotification(title, notificationMessage, app.getDeviceRegistrationToken())
                : sendIosResponseNotification(title, notificationMessage, app.getDeviceRegistrationToken());
    }

    /**
     * Sends a push notification to an Android device using Firebase Messaging.
     * Constructs the message using the provided notification data and device token.
     * 
     * @param notificationMessage The mesage to be sent in push notification.
     * @param token               The device token to which the notification will be
     *                            sent.
     * @return The response from FirebaseMessaging's send method.
     */
    public String sendAndroidResposneNotification(String title, String notificationMessage, String token) {
        String response = null;
        Message message = Message.builder()
                .setToken(token)
                .setNotification(Notification.builder()
                        .setTitle(title)
                        .setBody(notificationMessage)
                        .build())
                .build();
        try {
            response = FirebaseMessaging
                    .getInstance(FirebaseApp.getInstance("androidApp"))
                    .send(message);
            log.info("Push sent successfully: {}", sanitizeForLog(response));
        } catch (FirebaseMessagingException e) {
            log.error("Failed to send push: {}", e.getCause(), e);
        }

        return response;
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * Constructs the HTTP request using the provided JWT token, device token, and
     * payload.
     * 
     * @param jwtToken    The JWT token for authentication with APNs.
     * @param deviceToken The device token to which the notification will be sent.
     * @param payLoad     The JSON payload representing the notification data.
     * @return The response body from the APNs HTTP request.
     */
    private String sendAPNSResponseNotification(String jwtToken, String deviceToken, String payLoad) throws Exception {
        String apnsHost = applicationProperties.getPushNotificationRevamp().getApnsHost();
        String apnsTopic = applicationProperties.getPushNotificationRevamp().getApnsTopic();
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apnsHost + "/3/device/" + deviceToken))
                .POST(HttpRequest.BodyPublishers.ofString(payLoad))
                .setHeader("authorization", "bearer " + jwtToken)
                .setHeader("apns-topic", apnsTopic)
                .setHeader("Content-Type", "application/json")
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * Constructs the payload and generates the JWT token for authentication.
     * 
     * @param title               Title for notification.
     * @param notificationMessage The message for notification.
     * @param deviceToken         The device token to which the notification will be
     *                            sent.
     * @return The response from APNs.
     */
    public String sendIosResponseNotification(String title, String notificationMessage, String deviceToken) {
        String payLoad = null;
        try {
            payLoad = buildApnsJsonResponsePayload(title, notificationMessage);
        } catch (IOException ioe) {
            log.error("event=apns_response_payload_build status=failure payloadPreview={} errorMessage={}",
                    sanitizeForLog(payLoad),
                    sanitizeForLog(ioe.getMessage()),
                    ioe);
        }

        String teamId = applicationProperties.getPushNotificationRevamp().getTeamId();
        String keyId = applicationProperties.getPushNotificationRevamp().getKeyId();
        String base64PrivateKey = applicationProperties.getPushNotificationRevamp().getBase64PrivateKey();
        String JwtToken = null;
        String response = null;
        try {
            JwtToken = PushNotificcationRevampUtil.generateToken(teamId, keyId, base64PrivateKey);
        } catch (Exception e) {
            log.error("event=apns_response_token_generate status=failure errorMessage={}",
                    sanitizeForLog(e.getMessage()),
                    e);
        }
        try {
            response = sendAPNSResponseNotification(JwtToken, deviceToken, payLoad);
        } catch (Exception e) {
            log.error("event=push_response_send status=failure platform=ios token={} errorCause={} errorMessage={}",
                    sanitizeForLog(deviceToken),
                    sanitizeForLog(String.valueOf(e.getCause())),
                    sanitizeForLog(e.getMessage()),
                    e);
            response = e.getMessage();
        }
        return response;
    }

    /**
     * Creates a JSON payload for APNs notifications.
     * Constructs the payload using the provided notification message data.
     * 
     * @param title               The notification title data.
     * @param notificationMessage The notification message data.
     * @return The JSON payload for APNs notifications.
     * @throws IOException If an error occurs while constructing the payload.
     */
    private String buildApnsJsonResponsePayload(String title, String notificationMessage) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> alert = Map.of(
                "title", title,
                "body", notificationMessage);
        Map<String, Object> aps = new HashMap<>();
        aps.put("alert", alert);
        Map<String, Object> payload = Map.of("aps", aps);
        return objectMapper.writeValueAsString(payload);
    }

    /**
     * Extracts the message ID from a successful push notification response based on
     * the device type.
     * For iOS devices, the response is expected to be delimited by a pipe character
     * ('|'),
     * and the method returns the first segment. For other device types (e.g.,
     * Android),
     * the response is expected to be a path-like string delimited by slashes ('/'),
     * and the method returns the last segment.
     * 
     * @param response   The response string received after sending a push
     *                   notification.
     * @param deviceType The type of device (e.g., Constants.IOS or other).
     * @return The extracted message ID, or null if the response is malformed or
     *         empty.
     */
    private String getMessageIdForSuccess(String response, String deviceType) {
        String messageId = null;
        if (deviceType.equals(Constants.IOS)) {
            messageId = response.split("\\|")[0];

        } else {
            String[] parts = response.split("/");
            messageId = parts[parts.length - 1];
        }
        return messageId;
    }

    /**
     * Constructs a message ID string for a failed push notification attempt based
     * on the device type.
     * For iOS devices, the method extracts the APNs ID from the response string by
     * splitting it using
     * the pipe character ('|') and prefixes it with "ApnsId:". For non-iOS devices,
     * it returns "NA".
     * 
     * @param response   The response string received after a failed push
     *                   notification.
     * @param deviceType The type of device (e.g., Constants.IOS or other).
     * @return A formatted message ID string for iOS or "NA" for other device types.
     */
    private String getMessageIdForFailure(String response, String deviceType) {
        String messageId = null;
        if (deviceType.equals(Constants.IOS)) {
            messageId = response.split("\\|")[0];
        } else {
            messageId = "NA";
        }
        return messageId;
    }

    /**
     * Saves error details from a PushNotificationRevampDTO and maps them into a
     * result map.
     * 
     * @param dto   The DTO containing notification details.
     * @param error The error message to be recorded.
     * @return A map containing keyId, notificationDateTime,
     *         transactionFailureDateTime, and status.
     */
    private Map<String, Object> saveErrorAndMapResult(PushNotificationRevampDTO dto, String error) {
        Map<String, Object> map = new HashMap<>();
        map.put("keyId", dto.getKeyId());
        map.put("notificationDateTime", dto.getNotificationDateTime());
        map.put("transactionFailureDateTime", (new Date()).getTime() / 1000);
        map.put("status", "Failed for the reason: " + error);
        return map;
    }

    private String getSchedulerInstanceId() {
        return UUID.randomUUID().toString();
    }

}