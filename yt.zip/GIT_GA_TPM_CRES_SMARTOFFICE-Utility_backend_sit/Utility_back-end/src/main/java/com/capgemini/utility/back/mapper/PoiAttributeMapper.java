package com.capgemini.utility.back.mapper;

import java.util.ArrayList;
import java.util.List;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.model.PoiAttributeDTO;

@Mapper(config = DtoMapperConfig.class, uses = {CdmAttributesMapper.class})
public interface PoiAttributeMapper {
    
    PoiAttributeMapper INSTANCE = Mappers.getMapper(PoiAttributeMapper.class);

     @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" })
    })
    PoiAttributeDTO poiToPoiAttributeDTO(Poi in, @Context String language);

}
