package com.capgemini.utility.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.capgemini.utility.back.config.ApplicationProperties.Azure.GraphApi;

import lombok.Data;

/**
 * Properties specific to Utility Back End.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class


    private final Cdm cdm = new Cdm();
    private final CORS cors = new CORS();
    private final Jwks jwks = new Jwks();
    private final Ping ping = new Ping();
    private final Azure azure = new Azure();
    private final GraphApi graphApi = new GraphApi();
    private final PushNotificationRevamp pushNotificationRevamp = new PushNotificationRevamp();
    private final PushNotificationRevampChron notificationrevampchron = new PushNotificationRevampChron();
    private final PushNotificationRevampGenChron notificationgeneralchron = new PushNotificationRevampGenChron();
    private final Graph graph = new Graph();

    @Data
    public static class Ping {
        private String validateUrl;
        private String clientId;
        private String clientSecret;
        // Need to get it from Office pass team 
        private String  validateUrlOfficePass;
        private String clientIdForOfficePass;
        private String clientSecretForOfficePass;

    }
    @Data
    public static class Jwks {
        private String url;
    }

    @Data
    public static class Cdm {

        private String url;
        private String clientId;
        private String clientSecret;
        private String ssoUrl;
        private String cgAuth;
        private String authorization;
        private String cookie;

        private final Tasks tasks = new Tasks();

        @Data
        public static class Tasks {
            private String cron;
            private String tz;
        }

    }

    @Data
    public static class CORS {
        private String origins;
    }

    @Data
    public static class Azure {
        private String tenantId;        
        private final GraphApi graphApi = new GraphApi();
        private final KeyVault keyVault = new KeyVault();
        private final GraphApiSendEmail graphApiSendEmail = new GraphApiSendEmail();

        @Data
        public static class GraphApi {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;
            private String notificationUrl;
        }
        @Data
        public static class KeyVault {
            private String url;
            private String clientId;
            private String clientSecret;
            private String certificateName;
        }

        @Data
        public static class GraphApiSendEmail {
        private String url;
        private String clientId;
        private String clientSecret;
        private String scopeUrl;           
        }
    }
    @Data
    public static class PushNotificationRevamp {  
        private String teamId;
        private String keyId;
        private String base64PrivateKey;
        private String apnsHost;
        private String apnsTopic;       
    }

    @Data
    public static class PushNotificationRevampChron {
        private final Push push = new Push();

        @Data
        public static class Push {
            private String cron;
            private String tz;
        }
        
    }
    @Data
    public static class PushNotificationRevampGenChron {
        private final Push push = new Push();

        @Data
        public static class Push {
            private String cron;
            private String tz;
        }
        
    }

    @Data
    public static class Graph {
        private final Tasks tasks = new Tasks();

        @Data
        public static class Tasks {
            private String cron;
            private String tz;
        }
      
    }

    
    
}
