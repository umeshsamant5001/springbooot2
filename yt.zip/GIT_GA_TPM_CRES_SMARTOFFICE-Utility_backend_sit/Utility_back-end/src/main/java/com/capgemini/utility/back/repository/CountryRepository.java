package com.capgemini.utility.back.repository;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

	@Query(value = "SELECT distinct c.* FROM sw_countries c JOIN sw_cities ci ON ci.country_id=c.id JOIN sw_sites s ON s.city_id=ci.id JOIN sw_buildings b ON b.site_id = s.id WHERE b.deployed=true", nativeQuery = true)
	List<Country> findAllDeployed();

	@Query(value = "SELECT distinct c.* FROM sw_countries c JOIN sw_cities ci ON ci.country_id=c.id JOIN sw_sites s ON s.city_id=ci.id JOIN sw_buildings b ON b.site_id = s.id WHERE b.deployed=true AND b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUnsecured();

	@Query(value = "SELECT distinct c.* FROM sw_countries c LEFT JOIN sw_cities ci ON ci.country_id=c.id LEFT JOIN sw_sites s ON s.city_id=ci.id LEFT JOIN sw_buildings b ON b.site_id = s.id", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployed();

	@Query(value = "SELECT distinct c.* FROM sw_countries c LEFT JOIN sw_cities ci ON ci.country_id=c.id LEFT JOIN sw_sites s ON s.city_id=ci.id LEFT JOIN sw_buildings b ON b.site_id = s.id WHERE b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployedAndUnsecured();

	Country findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	@Query("SELECT country.cdmKeyId, country.titleEn AS name FROM Country country WHERE country.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);

	@Query("SELECT INDEX(attributes), attributes FROM Country country INNER JOIN country.attributes attributes WHERE country.id = :countryId")
	List<Tuple> getAttributesById(@Param("countryId") Long countryId);
	
	@Query("SELECT building.id, country.titleEn AS name FROM Country country INNER JOIN country.cities city INNER JOIN city.sites site INNER JOIN site.buildings building WHERE building.id IN (:buildingIds)")
	List<Tuple> getCountryNameByBuildingIds(@Param("buildingIds") List<Long> buildingIds);
}
