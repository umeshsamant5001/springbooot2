package com.capgemini.utility.back.security.jwt;

import com.capgemini.utility.back.model.ErrorCodes;
import com.capgemini.utility.back.model.exceptionmapper.GeneralException;

public class AuthFailureException extends GeneralException {

	private static final long serialVersionUID = 5383016634683861626L;

	public AuthFailureException(String message) {
		super(401, ErrorCodes.AUTHENTICATION_FAILED, message);
	}

}
