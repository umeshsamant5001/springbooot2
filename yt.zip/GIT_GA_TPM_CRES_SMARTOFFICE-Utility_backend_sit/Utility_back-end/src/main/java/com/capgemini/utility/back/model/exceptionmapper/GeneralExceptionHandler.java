package com.capgemini.utility.back.model.exceptionmapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.google.gson.JsonObject;

/**
 * An exception mapper to handle the inherited GeneralExceptions
 * and emit an Http response with
 * custom json body { "errorCode":int, "message":"string debug msg", "exception":"the exception name" }
 *
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class GeneralExceptionHandler extends ResponseEntityExceptionHandler {

	   private static final Logger LOGGER = LoggerFactory.getLogger(GeneralExceptionHandler.class);
	   private static final int GENERIC_ERROR_CODE = HttpStatus.INTERNAL_SERVER_ERROR.value();
	   private static final String GENERIC_ERROR_MESSAGE = "An unexpected error occurred";
	   private static final String GENERIC_ERROR_TYPE = "GENERAL_ERROR";

	   @ExceptionHandler(GeneralException.class)
	   @ResponseBody
	   protected ResponseEntity<Object> handleException(GeneralException e) {
		   LOGGER.error("Handled general exception", e);
	       return buildResponseEntity(e);
	   }

	   private ResponseEntity<Object> buildResponseEntity(GeneralException exception) {
		   JsonObject json = new JsonObject();
		   json.addProperty("errorCode", GENERIC_ERROR_CODE);
		   json.addProperty("message", GENERIC_ERROR_MESSAGE);
		   json.addProperty("exception", GENERIC_ERROR_TYPE);

	       return new ResponseEntity<>(json.toString(), HttpStatus.valueOf(exception.getHttpStatus()));
	   }
}
