package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;
import com.capgemini.utility.back.service.FloorListConverter;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;
import org.hibernate.annotations.Synchronize;

@NamedStoredProcedureQuery(
    name = "GetBuildingFloorJson",
    procedureName = "GetBuildingFloorJson",
    resultClasses = SensorBuildingFloor.class
)
@Data
@Entity
@Immutable
@Subselect(
    "SELECT building_id, deployed, address, capacity, city, secured, " +
    "building_name, country, building_status, building_coordinates, " +
    "building_assetcode, floors FROM get_building_floor_json"
)
@Synchronize({"get_building_floor_json"})
public class SensorBuildingFloor {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SesnorBuildingFloorSP_Generator")
    @SequenceGenerator(name="SesnorBuildingFloorSP_Generator", sequenceName = "SesnorBuildingFloorSP_Sequence")
    @Column(name = "building_id")
    private Long buildingId;
    @Column(name = "deployed")
    private int deployed; 
    @Column(name = "address")
    private String address;
    @Column(name = "capacity")
    private Long capacity;
    @Column(name = "city")
    private String city;
    @Column(name = "secured")
    private int secured;
    @Column(name = "building_name")
    private String buildingName;
    @Column(name = "country")
    private String country;
    @Column(name = "building_status")
    private String buildingStatus;
    @Column(name = "building_coordinates")
    private String buildingCoordinates;
    @Column(name = "building_assetcode")
    private String buildingAssetcode;
    @Convert(converter = FloorListConverter.class)
    //@Column(name = "floors", columnDefinition = "NVARCHAR(MAX)")
    @Column(name = "floors", columnDefinition = "json")
    private List<Floors> floors = new ArrayList<>(); 
}
