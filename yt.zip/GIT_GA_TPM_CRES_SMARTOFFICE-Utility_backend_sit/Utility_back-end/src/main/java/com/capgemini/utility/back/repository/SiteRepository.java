package com.capgemini.utility.back.repository;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.utility.back.model.Site;

@Repository
public interface SiteRepository extends JpaRepository<Site, Long> {

    long countByCityId(@Param("cityId") @RequestParam("cityId")Long cityId);

    List<Site> findAllByCityId(@Param("cityId") @RequestParam("cityId") Long cityId);

	// Controller only
	@RestResource(exported = false)
	Site findByCdmKeyId(@Param("cdmKeyId") @RequestParam("cdmKeyId") Long cdmKeyId);

	// Controller only
	@RestResource(exported = false)
	@Transactional
	@Modifying
	@Query(value = "delete from sw_site_attributes ssa  where ssa.site_id=:siteId", nativeQuery = true)
	void deleteAttributeById(@Param("siteId") @RequestParam("siteId") Long siteId);

	// Controller only
	@RestResource(exported = false)
	@Transactional
	@Modifying
	@Query(value = "delete from sw_sites ss where ss.id=:siteId", nativeQuery = true)
	void deleteById(@Param("siteId") @RequestParam("siteId") Long siteId);

	@Query("SELECT site.cdmKeyId, site.titleEn AS name FROM Site site WHERE site.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);

	@Query("SELECT INDEX(attributes), attributes FROM Site site INNER JOIN site.attributes attributes WHERE site.id = :siteId")
	List<Tuple> getAttributesById(@Param("siteId") Long siteId);
}
