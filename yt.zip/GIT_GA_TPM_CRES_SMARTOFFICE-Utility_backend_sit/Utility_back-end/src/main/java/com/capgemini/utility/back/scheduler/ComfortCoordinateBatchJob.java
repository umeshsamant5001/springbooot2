package com.capgemini.utility.back.scheduler;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


import com.capgemini.utility.back.model.EnumCdmAttributes;
import com.capgemini.utility.back.model.FloorMapScaling;
import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.repository.FloorMapScalingRepository;
import com.capgemini.utility.back.repository.PoiRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ComfortCoordinateBatchJob {

    @Autowired
    PoiRepository poiRepository;
    @Autowired
    FloorMapScalingRepository floorMapScalingRepository;

    // This will run every day at midnight (00:00)
    @Scheduled(cron = "0 0 0 * * *")
    public void processComfortPois() {
        try {
            Map<Long, Float> mapScalingRatio = floorMapScalingRepository.findAll().stream().collect(Collectors.toMap(FloorMapScaling::getCdmFloorKeyId, FloorMapScaling::getScalingRatio));

            List<Poi> comfortPois = poiRepository.findAllWithComfortSpaceType();
            for (Poi comfortPoi : comfortPois) {
                if (comfortPoi.hasXY()) {
                    // if the poi already has x and y skip it
                    continue;
                }
                if (comfortPoi.hasLonLat()) { // necessary for calculation
                    Double lon = comfortPoi.getLon();
                    Double lat = comfortPoi.getLat();
                    Long floorCdmKeyId = poiRepository.findCdmKeyIdForPoi(comfortPoi.getId());
                    Float scalingRatio = mapScalingRatio.get(floorCdmKeyId);
                    if (scalingRatio == null) {
                        continue; // No scaling ratio available, skip
                    }
                    comfortPoi.getAttributes().put(EnumCdmAttributes.COORD_X.toString(),
                            Double.toString(lat * scalingRatio));
                    comfortPoi.getAttributes().put(EnumCdmAttributes.COORD_Y.toString(),
                            Double.toString(lon * scalingRatio));
                    poiRepository.save(comfortPoi);
                }

            }
        } catch (DataAccessException | IllegalStateException ex) {
            log.error("Error while processing comfort POIs batch job", ex);
        }

    }

}
