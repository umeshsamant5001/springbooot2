package com.capgemini.utility.back.model;

import java.util.List;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.ColumnDefault;
import com.capgemini.utility.back.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "generalpushnotification")  
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class PushNotificationGeneral {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "genpushnotification_Generator")
	@SequenceGenerator(name = "genpushnotification_Generator", sequenceName = "genpushnotif_Sequence")
	private Long id;	

	@Column(name = "title")
	private String title;

	@Column(name = "body")
	private String body;	

	@Column(name ="created_date_time")
	private Long createdDateTime;

	@Column(name ="notificationscheduled_date_time")
	private String notificationscheduled_Date_Time;

	@Column(name = "datarecivedfrom")
    private String dataRecivedFrom; 

	@Column(name = "notificationsentby")
    private String notificationSentBy;

	@Column(name = "notificationstatus")
	private String notificationStaus; 

	@ElementCollection
    @CollectionTable(name = "generalpushnotification_emails", joinColumns = @JoinColumn(name = "genralpushnotification_id"))
    @Column(name = "email")
    private List<String> emails;

	@Column(name = "notification_sent", nullable = true)
	@ColumnDefault("false")
    private Boolean notificationSent = false;  
	
		
}
