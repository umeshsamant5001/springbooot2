package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
@Data
@Entity
@Table(name = "getSensorDataFloor")
public class GetSensorDataFloor {
    @Id
    @Column(name = "floor_id")
    private Long floorId;
    @Column(name = "floor_name")
    private String floorName;

   @OneToMany(mappedBy = "getSensorDataFloor", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    @OrderBy("index ASC")
    private List<GetSensorDataPoi> pois = new ArrayList<>();

    @ManyToOne
	@JoinColumn(name = "building_id")
	@JsonIgnore
	private GetSensorDataBuilding getSensorDataBuilding;
    
}
