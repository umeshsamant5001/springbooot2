/**
 * Spring Security configuration.
 */
package com.capgemini.utility.back.security;
