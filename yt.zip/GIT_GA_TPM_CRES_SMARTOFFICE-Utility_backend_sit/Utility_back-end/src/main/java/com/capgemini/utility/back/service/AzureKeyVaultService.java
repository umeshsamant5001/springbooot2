package com.capgemini.utility.back.service;

import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.security.keyvault.certificates.CertificateClient;
import com.azure.security.keyvault.certificates.CertificateClientBuilder;
import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.utility.back.config.ApplicationProperties;
import com.azure.core.exception.ResourceNotFoundException;

@Slf4j
@Service
public class AzureKeyVaultService {

    public static final String CERTIFICATE_NAME = "tablet-smartoffice";

	@Autowired
    private ApplicationProperties applicationProperties;
    private SecretClient secretClient;
    private CertificateClient certificateClient;
    
    /**
     * Retrieves a secret from Azure Key Vault by its name.
     *
     * @param secretName the name of the secret to retrieve
     * @return the KeyVaultSecret object, or null if not found
    */
    public KeyVaultSecret getSecret(String secretName) {
            try{
                KeyVaultSecret kvSecret = getSecretClient().getSecret(secretName);
                if (Objects.isNull(kvSecret)) {
                    return null;
                }
                log.info("Success to the secret");
                return kvSecret;
            }
            catch(ResourceNotFoundException e){
                log.error("secret not found in AzureKeyVault", e);
                return null;
            }
    }
        
    /**
     * Retrieves the private key (as a secret) from Azure Key Vault using the configured certificate name.
     * @return the KeyVaultSecret object containing the private key, or null if not found
    */
    public KeyVaultSecret getPrivateKey() {
        ApplicationProperties.Azure.KeyVault keyVault = applicationProperties.getAzure().getKeyVault();
        KeyVaultSecret kvSecret = getSecretClient().getSecret(keyVault.getCertificateName());
        if (Objects.isNull(kvSecret)) {
            return null;
        }
        return kvSecret;
    }    
     
    /**
     * Retrieves a certificate from Azure Key Vault using a predefined certificate name.
     * @return the KeyVaultCertificateWithPolicy object, or null if not found
    */
    public KeyVaultCertificateWithPolicy getCertificate() {
        KeyVaultCertificateWithPolicy kvCertificate = getCertificateClient().getCertificate(CERTIFICATE_NAME);
        if (Objects.isNull(kvCertificate)) {
            return null;
        }

        return kvCertificate;
    }
    
    /**
     * Lazily initializes and returns the SecretClient for accessing secrets in Azure Key Vault.
     * @return the initialized SecretClient
    */
    private SecretClient getSecretClient() {
        log.info("connection to the keyVault");
        if (Objects.isNull(secretClient)) {
            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getKeyVault().getClientId())
                    .clientSecret(applicationProperties.getAzure().getKeyVault().getClientSecret())
                    .build();

            secretClient = new SecretClientBuilder()
                    .vaultUrl(applicationProperties.getAzure().getKeyVault().getUrl())
                    .credential(clientSecretCredential)
                    .buildClient();
        }
        return secretClient;
    }
    
    /**
     * Lazily initializes and returns the CertificateClient for accessing certificates in Azure Key Vault.
     * @return the initialized CertificateClient
    */
    private CertificateClient getCertificateClient() {
        if (Objects.isNull(secretClient)) {
            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getKeyVault().getClientId())
                    .clientSecret(applicationProperties.getAzure().getKeyVault().getClientSecret())
                    .build();

            certificateClient = new CertificateClientBuilder()
                    .vaultUrl(applicationProperties.getAzure().getKeyVault().getUrl())
                    .credential(clientSecretCredential)
                    .buildClient();
        }
        return certificateClient;
    }
}
