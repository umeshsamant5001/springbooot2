package com.capgemini.utility.back.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import com.capgemini.utility.back.management.TokenExchangeResponse;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class TokenExchangeController {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${token.exchange.client-secret}")
    private String clientSecret;


    @PostMapping("/exchangeToken")
    public ResponseEntity<TokenExchangeResponse> exchangeToken(
        @RequestParam("subject_token") String subject_token
    ) {
        String tokenExchangeUrl = "https://ssoprep.capgemini.com/as/token.oauth2";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "urn:ietf:params:oauth:grant-type:token-exchange");
        body.add("client_id", "tokenexchangev2");
        body.add("subject_token_type", "urn:ietf:params:oauth:token-type:jwt");
        body.add("client_secret", clientSecret);

        body.add("subject_token", subject_token);

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<TokenExchangeResponse> responseEntity = restTemplate.exchange(
            tokenExchangeUrl,
            HttpMethod.POST,
            requestEntity,
            TokenExchangeResponse.class
        );

        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            TokenExchangeResponse response = responseEntity.getBody();
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.noContent().build();
                    
        }
    }
}
