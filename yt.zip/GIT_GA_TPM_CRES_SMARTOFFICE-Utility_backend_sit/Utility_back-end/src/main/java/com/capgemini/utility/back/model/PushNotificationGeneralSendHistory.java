package com.capgemini.utility.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.capgemini.utility.back.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "generalpushNotificationsendhistory")  
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class PushNotificationGeneralSendHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)   
	@JoinColumn(name = "notificationid" , nullable = false)
	private PushNotificationGeneral generalpushnotification; 

	@Column(name = "title")
	private String title;

	@Column(name = "body")
	private String body;
	
	@Column(name = "email")
	private String Email;

	@Column(name = "notificationstatus")
	private String notificationStatus; 

	@Column(name = "notificationfailurereason")
	private String notificationFailureReason; 

	@Column(name = "retrycount")
	private Long retryCount;

	@Column(name = "failuredatetime")
	private Long failureDateTime;
    


	

	
	
}
