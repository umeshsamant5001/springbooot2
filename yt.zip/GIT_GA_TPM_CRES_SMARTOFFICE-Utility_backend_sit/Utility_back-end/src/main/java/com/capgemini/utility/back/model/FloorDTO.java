package com.capgemini.utility.back.model;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class FloorDTO implements  Serializable , WithTitleDTO, WithCdmAttributesDTO{

    private Long id;

    private Integer index;

    private BuildingDTO building;

    private Long buildingId;

    private String assetCode;

    private String titleFr;

    private String titleEn;

    private String title;

    private Long modifiedAt;

    private Long cdmKeyId;

    private Map<String, String> attributes = new HashMap<>();

    private Map<String, String> cdmAttributes = new HashMap<String, String>();
}
