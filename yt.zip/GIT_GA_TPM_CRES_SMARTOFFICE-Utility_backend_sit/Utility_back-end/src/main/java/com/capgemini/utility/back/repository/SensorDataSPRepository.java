package com.capgemini.utility.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.capgemini.utility.back.model.Device;
import com.capgemini.utility.back.model.SensorDataSP;

public interface SensorDataSPRepository extends JpaRepository<SensorDataSP, Long>, JpaSpecificationExecutor<Device> {

    @Procedure(name = "GetSensorData")
    public List<SensorDataSP> GetSensorData(@Param("building_id") Long buildingId);

}
