package com.capgemini.utility.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class CityDTO implements Serializable, WithTitleDTO {
    private Long id;
    private Long modifiedAt;
    private String titleFr;
    private String titleEn;
    private String title;
    private CountryDTO country;
    private List<SiteDTO> sites;
    private Long cdmKeyId;
    private Long cdmStateId;
    private Map<String, String> attributes = new HashMap<String, String>();
    private Long nbChilds;
}
