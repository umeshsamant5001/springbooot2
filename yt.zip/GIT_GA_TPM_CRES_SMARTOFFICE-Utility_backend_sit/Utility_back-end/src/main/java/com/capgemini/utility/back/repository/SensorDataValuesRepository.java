package com.capgemini.utility.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import com.capgemini.utility.back.model.SensorDataValues;

@Repository
public interface SensorDataValuesRepository extends JpaRepository<SensorDataValues, Long> {
    
    @Procedure(name = "getPoiSensorJson")
    public List<SensorDataValues> getPoiSensorJson();

}
