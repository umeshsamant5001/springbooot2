package com.capgemini.utility.back.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.capgemini.utility.back.model.EnumDeviceType;
import com.capgemini.utility.back.model.Poi;
import com.capgemini.utility.back.repository.PoiRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PoiService {


    @Autowired
    PoiRepository poiRepository;

    public List<Poi> findAllViaDeviceByFloor(long floorId, List<EnumDeviceType> typeList) {
        try {
            if (Objects.isNull(typeList) || typeList.isEmpty()) {
                return this.poiRepository.findAllViaDeviceByFloorId(floorId);
            }

            return this.poiRepository.findAllViaDeviceByFloorIdAndDeviceTypeIn(floorId, typeList);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by floor and device type", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }


    public List<Poi> findAllByCountryId(Long countryId) {
        try {
            return this.poiRepository.findAllByCountryId(countryId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by country id", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }


    public Map<String, String> getAttributesById(Long poiId) {
        try {
            return this.poiRepository.getAttributesById(poiId)
                .stream()
                .collect(Collectors.toMap(
                    (tuple) -> tuple.get(0, String.class),
                    (tuple) -> tuple.get(1, String.class)
                ));
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POI attributes by id", ex);
            throw new IllegalStateException("Unable to retrieve POI attributes");
        }
    }

    
    public List<Poi> findAllByCityIdAndCountryId(Long cityId, Long countryId) {
        try {
            return this.poiRepository.findAllByCityIdAndCountryId(cityId, countryId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by city id and country id", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }


    public List<Poi> findAllBySiteIdAndCityId(Long siteId, Long cityId) {
        try {
            return this.poiRepository.findAllBySiteIdAndCityId(siteId, cityId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by site id and city id", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }

    public List<Poi> findAllByBuildingIdAndSiteId(Long buildingId, Long siteId) {
        try {
            return this.poiRepository.findAllByBuildingIdAndSiteId(buildingId, siteId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by building id and site id", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }

    public List<Poi> findAllByFloorIdAndBuildingId(Long floorId, Long buildingId) {
        try {
            return this.poiRepository.findAllByFloorIdAndBuildingId(floorId, buildingId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by floor id and building id", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }

    public List<Poi> findAllByCountry() {
        try {
            return this.poiRepository.findAllByCountry();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by country", ex);
            throw new IllegalStateException("Unable to retrieve POIs");
        }
    }


	public List<Poi> findAllByCityId(Long cityId) {
		try {
			return this.poiRepository.findAllByCityId(cityId);
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve POIs by city id", ex);
			throw new IllegalStateException("Unable to retrieve POIs");
		}
	}

	public List<Poi> findAllBySiteId(Long SiteId) {
		try {
			return this.poiRepository.findAllBySiteId(SiteId);
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve POIs by site id", ex);
			throw new IllegalStateException("Unable to retrieve POIs");
		}
	}

	public List<Poi> findAllByBuildingId(Long BuildingId) {
		try {
			return this.poiRepository.findAllByBuildingId(BuildingId);
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve POIs by building id", ex);
			throw new IllegalStateException("Unable to retrieve POIs");
		}
	}


	public Poi findById(Long id) {
		return this.poiRepository.findById(id).orElse(null);
	}
}
