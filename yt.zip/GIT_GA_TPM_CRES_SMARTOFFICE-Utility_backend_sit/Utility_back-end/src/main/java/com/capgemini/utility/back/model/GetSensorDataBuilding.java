package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import lombok.Data;

@Data
@Entity
@Table(name = "getSensorDataBuilding")
public class GetSensorDataBuilding {
    @Id
    @Column(name = "building_id")
    private Long buildingId;
    @Column(name = "building_name")
    private String buildingName;
    @Column(name = "asset_code")
    private String assetCode;
    @Column(name = "building_status")
    private String buildingStatus;
    @Column(name = "building_lat")
    private Double buildingLat;
    @Column(name = "building_lon")
    private Double buildingLon;

    @OneToMany(mappedBy = "getSensorDataBuilding", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    @OrderBy("index ASC")
    private List<GetSensorDataFloor> floors = new ArrayList<>();

}
