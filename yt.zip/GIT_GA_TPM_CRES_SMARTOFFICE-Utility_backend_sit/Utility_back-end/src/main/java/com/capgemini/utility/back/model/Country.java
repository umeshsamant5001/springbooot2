package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.capgemini.utility.back.config.DbConfig;
import com.capgemini.utility.back.config.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@NamedEntityGraph(
  name = "country-entity-graph",
  attributeNodes = {
    @NamedAttributeNode("id"),
    @NamedAttributeNode("cities"),
    @NamedAttributeNode("titleEn"),
    @NamedAttributeNode("titleFr"),
    @NamedAttributeNode("attributes"),
    @NamedAttributeNode("countryIsoAlpha2"),
    @NamedAttributeNode("cdmKeyId")
  }
)
@Data
@Entity
@Table(name = "country", indexes = { @Index(name = "IDX_MODIFIED_COUNTRY", columnList = "modified_at") })
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Country implements WithTitle{

	private static final long serialVersionUID = 7816574636399103422L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Country_Generator")
	@SequenceGenerator(name = "Country_Generator", sequenceName = "Country_Sequence")
	private Long id;

	@OneToMany(mappedBy = "country", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<City> cities = new ArrayList<>();

	@Column(name = "modified_at", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime()/1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;

	@Column(name = "country_iso_alpha2")
	private String countryIsoAlpha2;

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

	@CollectionTable(name = "country_attribute", joinColumns = @JoinColumn(name = "country_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

}

