package com.capgemini.utility.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;




import com.capgemini.utility.back.mapper.PoiAttributeMapper;
import com.capgemini.utility.back.model.AppConfigurationValues;
import com.capgemini.utility.back.model.BookMeetingConfigDTO;
import com.capgemini.utility.back.model.Coordinates;
import com.capgemini.utility.back.model.LocationAddress;
import com.capgemini.utility.back.model.LocationsDTO;
import com.capgemini.utility.back.model.MeetingAttendeeDTO;
import com.capgemini.utility.back.model.MeetingDetailsDTO;
import com.capgemini.utility.back.model.Poi;

import com.capgemini.utility.back.model.PoiAttributeDTO;
import com.capgemini.utility.back.service.AppConfigService;

import com.capgemini.utility.back.service.MeetingDetailsService;
import com.capgemini.utility.back.service.PoiService;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(value = BookMeetingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class BookMeetingController {
    
    static final String ROOT_API = "api/bookMeeting";
    private static final String BOOK_MEETING_CONFIG_TYPE = "Book a Meeting";
    private static final String JOB_TYPE_COUNTRY = "Country";
    private static final String JOB_TYPE_CITY = "City";
    private static final String JOB_TYPE_SITE = "Site";
    private static final String JOB_TYPE_BUILDING = "Building";
    private static final String JOB_TYPE_FLOOR = "Floor";
    private static final String NODE_TYPE_NAME_ALL = "ALL";


     private final Logger log = LoggerFactory.getLogger(BookMeetingController.class);


    @Autowired
    private AppConfigService appConfigService;

    @Autowired
    private PoiService poiService;



    @Autowired
    private MeetingDetailsService meetingDetailsService;



    @GetMapping("/poisForJob")
    public ResponseEntity<List<PoiAttributeDTO>> getAllPois(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestParam(required = true) Long currentNodeId,
            @RequestParam(required = true) String currentNodeType,
            @RequestParam(required = false) Long parentNodeId,
            @RequestParam(required = false) String currentNodeTypeName) {
             
            List<PoiAttributeDTO> poiAttributeDTOS =  new ArrayList<>();
            List<Poi> pois =  null;
            
            if(Objects.nonNull(currentNodeId) && currentNodeType.equalsIgnoreCase("Country"))
            {
           // poiData = this.poiService.findAllByCountryId(currentNodeId);
            if(Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL"))
            {
            pois = this.poiService.findAllByCountry();
            }
            else{
            pois = this.poiService.findAllByCountryId(currentNodeId);
            }
            }
        
            else if(Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId) && currentNodeType.equalsIgnoreCase("City"))
            {
            if(Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL"))
            {
            pois = this.poiService.findAllByCountryId(parentNodeId);   
            }
            else{
            pois = this.poiService.findAllByCityIdAndCountryId(currentNodeId, parentNodeId );
            }
            }

            else if(Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId) && currentNodeType.equalsIgnoreCase("Site"))
            {
            if(Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL"))
            {
            pois = this.poiService.findAllByCityId(parentNodeId);  
            }
            else{
            pois = this.poiService.findAllBySiteIdAndCityId(currentNodeId, parentNodeId );
            }
            }

            else if(Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId) && currentNodeType.equalsIgnoreCase("Building"))
            {
            if(Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL"))
            {
            pois = this.poiService.findAllBySiteId(parentNodeId);
            }
            else{
            pois = this.poiService.findAllByBuildingIdAndSiteId(currentNodeId, parentNodeId );
            }
            }
          
            else if(Objects.nonNull(currentNodeId) && Objects.nonNull(parentNodeId) && currentNodeType.equalsIgnoreCase("Floor"))
            {
            if(Objects.nonNull(currentNodeTypeName) && currentNodeTypeName.equalsIgnoreCase("ALL"))
            {
            pois = this.poiService.findAllByBuildingId(parentNodeId);
            }
            else{
            pois = this.poiService.findAllByFloorIdAndBuildingId(currentNodeId, parentNodeId );
            }
            }

            if (Objects.nonNull(pois)) {
               poiAttributeDTOS = pois
              .stream()
              .map(poi -> PoiAttributeMapper.INSTANCE.poiToPoiAttributeDTO(poi, language))
              .collect(Collectors.toList());
            }
            return ResponseEntity.ok(poiAttributeDTOS);
    }

    @GetMapping("/configs")
    public ResponseEntity<List<AppConfigurationValues>> getConfigsByType(@RequestParam String type) {

            List<AppConfigurationValues> configs = appConfigService.getConfigsByType(type);

            return ResponseEntity.ok(configs);
    }

    @PostMapping("/meetings")
    public ResponseEntity<Map<String, String>> createMeetings(@Valid @RequestBody List<@Valid MeetingDetailsInputDTO> meetingDetailsDTOList) {
        Map<String, String> response = new HashMap<>();
        
        try {
            if (Objects.isNull(meetingDetailsDTOList)) {
                response.put("error", "Meeting details are required");
                return ResponseEntity.badRequest().body(response);
            }
            meetingDetailsDTOList.forEach(meetingDetailsDTO -> {
            if(Objects.nonNull(meetingDetailsDTO))
            {
               MeetingDetailsDTO safeMeetingDetailsDTO = createSafeMeetingDetailsDTO(meetingDetailsDTO);
               if (Objects.nonNull(safeMeetingDetailsDTO)) {
                meetingDetailsService.saveMeetingDetailsSafely(safeMeetingDetailsDTO);
            }
            }
            });
            response.put("message", "Meetings created successfully");
            return ResponseEntity.ok(response);
        }
        catch (IllegalArgumentException e) {
            log.error("Validation error while saving meetings: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
        catch (Exception e) {
            log.error("Exception: " + e.getMessage(), e);
            response.put("error", "Error saving Meetings: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }

    }

    
    @PutMapping("/configs")
    public ResponseEntity<List<AppConfigurationValues>> updateConfig(@RequestParam String type,
           @Valid @RequestBody BookMeetingConfigInputDTO bookMeetingConfigDTO) {

            if (Objects.isNull(bookMeetingConfigDTO)) {
                return ResponseEntity.badRequest().build();
            }

            String safeType = resolveSafeConfigType(type);
            if (Objects.isNull(safeType)) {
                return ResponseEntity.badRequest().build();
            }

            BookMeetingConfigDTO safeBookMeetingConfigDTO = buildSafeBookMeetingConfigDTO(bookMeetingConfigDTO);

            List<AppConfigurationValues> configs = appConfigService.getConfigsByType(safeType);

            updateConfigValue(configs, "BOM_Active_JOB_TIME", safeBookMeetingConfigDTO.getActiveJobTimeValue(), true);

            updateConfigValue(configs, "BOM_Active_JOB_Type", safeBookMeetingConfigDTO.getActiveJobType(), false);
            updateConfigValue(configs, "BOM_Active_JOB_Type_ID", safeBookMeetingConfigDTO.getActiveJobTypeId(), true);
            updateConfigValue(configs, "BOM_Active_JOB_Type_Name", safeBookMeetingConfigDTO.getActiveJobTypeName(), false);
            updateConfigValue(configs, "BOM_Parent_JOB_Type", safeBookMeetingConfigDTO.getParentJobType(), false);
            updateConfigValue(configs, "BOM_Parent_JOB_Type_ID", safeBookMeetingConfigDTO.getParentJobId(), true);
            updateConfigValue(configs, "BOM_Parent_JOB_Type_Name", safeBookMeetingConfigDTO.getParentJobTypeName(), false);
           
            return ResponseEntity.ok(configs);
    }

    private String resolveSafeConfigType(String type) {
        if (Objects.isNull(type)) {
            return null;
        }
        String normalizedType = String.valueOf(type).trim();
        if (!BOOK_MEETING_CONFIG_TYPE.equalsIgnoreCase(normalizedType)) {
            return null;
        }
        return new String(BOOK_MEETING_CONFIG_TYPE);
    }

    private BookMeetingConfigDTO buildSafeBookMeetingConfigDTO(BookMeetingConfigInputDTO bookMeetingConfigDTO) {

        BookMeetingConfigDTO safeBookMeetingConfigDTO = new BookMeetingConfigDTO();
        safeBookMeetingConfigDTO.setActiveJobTimeValue(canonicalizeNumericConfigValue(bookMeetingConfigDTO.getActiveJobTimeValue()));
        safeBookMeetingConfigDTO.setActiveJobType(canonicalizeJobType(bookMeetingConfigDTO.getActiveJobType()));
        safeBookMeetingConfigDTO.setActiveJobTypeId(canonicalizeNumericConfigValue(bookMeetingConfigDTO.getActiveJobTypeId()));
        safeBookMeetingConfigDTO.setActiveJobTypeName(canonicalizeNodeTypeName(bookMeetingConfigDTO.getActiveJobTypeName()));
        safeBookMeetingConfigDTO.setParentJobType(canonicalizeJobType(bookMeetingConfigDTO.getParentJobType()));
        safeBookMeetingConfigDTO.setParentJobId(canonicalizeNumericConfigValue(bookMeetingConfigDTO.getParentJobId()));
        safeBookMeetingConfigDTO.setParentJobTypeName(canonicalizeNodeTypeName(bookMeetingConfigDTO.getParentJobTypeName()));
        return safeBookMeetingConfigDTO;
    }

    private String canonicalizeNumericConfigValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String trimmed = String.valueOf(value).trim();
        if (!trimmed.matches("^[0-9]{1,19}$")) {
            throw new IllegalArgumentException("Invalid identifier value");
        }
        Long parsed = Long.valueOf(trimmed);
        if (parsed < 0L) {
            throw new IllegalArgumentException("Invalid identifier value");
        }
        return Long.toString(parsed);
    }

    private String canonicalizeNodeTypeName(String nodeTypeName) {
        if (Objects.isNull(nodeTypeName)) {
            return null;
        }
        String trimmed = String.valueOf(nodeTypeName).trim();
        if (NODE_TYPE_NAME_ALL.equalsIgnoreCase(trimmed)) {
            return new String(NODE_TYPE_NAME_ALL);
        }
        if (trimmed.length() > 255 || !trimmed.matches("^[\\p{L}\\p{N} _\\-.:/()]*$")) {
            throw new IllegalArgumentException("Invalid configuration value");
        }
        return new String(trimmed);
    }

    private String canonicalizeJobType(String jobType) {
        if (Objects.isNull(jobType)) {
            return null;
        }
        String trimmed = String.valueOf(jobType).trim();
        if (JOB_TYPE_COUNTRY.equalsIgnoreCase(trimmed)) {
            return new String(JOB_TYPE_COUNTRY);
        }
        if (JOB_TYPE_CITY.equalsIgnoreCase(trimmed)) {
            return new String(JOB_TYPE_CITY);
        }
        if (JOB_TYPE_SITE.equalsIgnoreCase(trimmed)) {
            return new String(JOB_TYPE_SITE);
        }
        if (JOB_TYPE_BUILDING.equalsIgnoreCase(trimmed)) {
            return new String(JOB_TYPE_BUILDING);
        }
        if (JOB_TYPE_FLOOR.equalsIgnoreCase(trimmed)) {
            return new String(JOB_TYPE_FLOOR);
        }
        throw new IllegalArgumentException("Invalid configuration value");
    }


    private void updateConfigValue(List<AppConfigurationValues> configs, String key, String value, boolean idType) {
        configs.forEach(config -> {
        if(config.getKey().equals(key))
        {
        if (idType) {
            appConfigService.saveValidatedIdConfig(config, value);
        } else {
            appConfigService.saveValidatedConfig(config, value);
        }
        }
        }
        );
    }

    private MeetingDetailsDTO createSafeMeetingDetailsDTO(MeetingDetailsInputDTO meetingDetailsDTO) {
        MeetingDetailsDTO safeMeetingDetailsDTO = new MeetingDetailsDTO();
        safeMeetingDetailsDTO.setId(safeStringValue(meetingDetailsDTO.getId()));
        safeMeetingDetailsDTO.setTotalBookingDuration(safeLongValue(meetingDetailsDTO.getTotalBookingDuration()));
        safeMeetingDetailsDTO.setOrganizerName(safeStringValue(meetingDetailsDTO.getOrganizerName()));
        safeMeetingDetailsDTO.setOrganizerEmail(safeStringValue(meetingDetailsDTO.getOrganizerEmail()));
        safeMeetingDetailsDTO.setCreatedDatetime(safeOffsetDateTimeValue(meetingDetailsDTO.getCreatedDatetime()));
        safeMeetingDetailsDTO.setStartDate(safeStringValue(meetingDetailsDTO.getStartDate()));
        safeMeetingDetailsDTO.setEndDate(safeStringValue(meetingDetailsDTO.getEndDate()));
        safeMeetingDetailsDTO.setStartTimezone(safeStringValue(meetingDetailsDTO.getStartTimezone()));
        safeMeetingDetailsDTO.setEndTimezone(safeStringValue(meetingDetailsDTO.getEndTimezone()));
        safeMeetingDetailsDTO.setStartTimems(safeLongValue(meetingDetailsDTO.getStartTimems()));
        safeMeetingDetailsDTO.setEndTimems(safeLongValue(meetingDetailsDTO.getEndTimems()));
        safeMeetingDetailsDTO.setDuration(safeLongValue(meetingDetailsDTO.getDuration()));
        safeMeetingDetailsDTO.setAllDay(safeBooleanValue(meetingDetailsDTO.getAllDay()));
        safeMeetingDetailsDTO.setCancelled(safeBooleanValue(meetingDetailsDTO.getCancelled()));
        safeMeetingDetailsDTO.setOrganizer(safeBooleanValue(meetingDetailsDTO.getOrganizer()));
        safeMeetingDetailsDTO.setType(safeStringValue(meetingDetailsDTO.getType()));
        safeMeetingDetailsDTO.setOnlineMeeting(safeBooleanValue(meetingDetailsDTO.getOnlineMeeting()));
        safeMeetingDetailsDTO.setRecurrence(safeStringValue(meetingDetailsDTO.getRecurrence()));
        safeMeetingDetailsDTO.setAttendees(createSafeAttendees(meetingDetailsDTO.getAttendees()));
        safeMeetingDetailsDTO.setLocations(createSafeLocations(meetingDetailsDTO.getLocations()));
        return safeMeetingDetailsDTO;
    }

    private List<MeetingAttendeeDTO> createSafeAttendees(List<MeetingAttendeeInputDTO> attendeeInputDTOList) {
        if (Objects.isNull(attendeeInputDTOList)) {
            return null;
        }
        List<MeetingAttendeeDTO> safeAttendeeDTOList = new ArrayList<>();
        attendeeInputDTOList.stream().filter(Objects::nonNull).forEach(attendeeInputDTO -> {
            MeetingAttendeeDTO safeAttendee = new MeetingAttendeeDTO();
            safeAttendee.setMeetingRoomEmailAddress(safeStringValue(attendeeInputDTO.getMeetingRoomEmailAddress()));
            safeAttendee.setAttendeesName(safeStringValue(attendeeInputDTO.getAttendeesName()));
            safeAttendee.setAttendeesAddress(safeStringValue(attendeeInputDTO.getAttendeesAddress()));
            safeAttendee.setType(safeStringValue(attendeeInputDTO.getType()));
            safeAttendee.setResponse(safeStringValue(attendeeInputDTO.getResponse()));
            safeAttendeeDTOList.add(safeAttendee);
        });
        return safeAttendeeDTOList;
    }

    private List<LocationsDTO> createSafeLocations(List<MeetingLocationInputDTO> locationInputDTOList) {
        if (Objects.isNull(locationInputDTOList)) {
            return null;
        }
        List<LocationsDTO> safeLocationDTOList = new ArrayList<>();
        locationInputDTOList.stream().filter(Objects::nonNull).forEach(locationInputDTO -> {
            LocationsDTO safeLocation = new LocationsDTO();
            safeLocation.setLocationDisplayName(safeStringValue(locationInputDTO.getLocationDisplayName()));
            safeLocation.setLocationLocationType(safeStringValue(locationInputDTO.getLocationLocationType()));
            safeLocation.setLocationUniqueId(safeStringValue(locationInputDTO.getLocationUniqueId()));
            safeLocation.setLocationUniqueIdType(safeStringValue(locationInputDTO.getLocationUniqueIdType()));
            safeLocation.setLocationLocationUri(safeStringValue(locationInputDTO.getLocationLocationUri()));
            safeLocation.setLocationAddress(createSafeLocationAddress(locationInputDTO.getLocationAddress()));
            safeLocation.setCoordinates(createSafeCoordinates(locationInputDTO.getCoordinates()));
            safeLocationDTOList.add(safeLocation);
        });
        return safeLocationDTOList;
    }

    private LocationAddress createSafeLocationAddress(MeetingLocationAddressInputDTO addressInputDTO) {
        if (Objects.isNull(addressInputDTO)) {
            return null;
        }
        LocationAddress safeAddress = new LocationAddress();
        safeAddress.setStreet(safeStringValue(addressInputDTO.getStreet()));
        safeAddress.setCity(safeStringValue(addressInputDTO.getCity()));
        safeAddress.setState(safeStringValue(addressInputDTO.getState()));
        safeAddress.setCountryOrRegion(safeStringValue(addressInputDTO.getCountryOrRegion()));
        safeAddress.setPostalCode(safeStringValue(addressInputDTO.getPostalCode()));
        return safeAddress;
    }

    private Coordinates createSafeCoordinates(MeetingCoordinatesInputDTO coordinatesInputDTO) {
        if (Objects.isNull(coordinatesInputDTO)) {
            return null;
        }
        Coordinates safeCoordinates = new Coordinates();
        safeCoordinates.setLatitude(safeDoubleValue(coordinatesInputDTO.getLatitude()));
        safeCoordinates.setLongitude(safeDoubleValue(coordinatesInputDTO.getLongitude()));
        return safeCoordinates;
    }

    private String safeStringValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return new String(String.valueOf(value).trim());
    }

    private Long safeLongValue(Long value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return Long.valueOf(String.valueOf(value));
    }

    private Double safeDoubleValue(Double value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return Double.valueOf(String.valueOf(value));
    }

    private Boolean safeBooleanValue(Boolean value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return Boolean.valueOf(String.valueOf(value));
    }

    private OffsetDateTime safeOffsetDateTimeValue(OffsetDateTime value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return OffsetDateTime.parse(String.valueOf(value));
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class MeetingDetailsInputDTO {

        @NotBlank(message = "id is required")
        @Size(max = 255)
        private String id;

        @Size(max = 100)
        private List<@Valid MeetingAttendeeInputDTO> attendees;

        @Size(max = 100)
        private List<@Valid MeetingLocationInputDTO> locations;

        @Min(value = 0L)
        private Long totalBookingDuration;

        @Size(max = 255)
        private String organizerName;

        @Email
        @Size(max = 255)
        private String organizerEmail;

        private OffsetDateTime createdDatetime;

        @Size(max = 100)
        private String startDate;

        @Size(max = 100)
        private String endDate;

        @Size(max = 100)
        private String startTimezone;

        @Size(max = 100)
        private String endTimezone;

        @Min(value = 0L)
        private Long startTimems;

        @Min(value = 0L)
        private Long endTimems;

        @Min(value = 0L)
        private Long duration;

        private Boolean allDay;

        private Boolean cancelled;

        private Boolean organizer;

        @Size(max = 100)
        private String type;

        private Boolean onlineMeeting;

        @Size(max = 100)
        private String recurrence;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class MeetingAttendeeInputDTO {

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}@._%+\\-\\s]*$")
        private String meetingRoomEmailAddress;

        @Size(max = 255)
        private String attendeesName;

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}@._%+\\-\\s]*$")
        private String attendeesAddress;

        @Size(max = 100)
        private String type;

        @Size(max = 100)
        private String response;
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class MeetingLocationInputDTO {

        @Size(max = 255)
        private String locationDisplayName;

        @Size(max = 100)
        private String locationLocationType;

        @Size(max = 255)
        private String locationUniqueId;

        @Size(max = 100)
        private String locationUniqueIdType;

        @Size(max = 500)
        private String locationLocationUri;

        @Valid
        private MeetingLocationAddressInputDTO locationAddress;

        @Valid
        private MeetingCoordinatesInputDTO coordinates;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class MeetingLocationAddressInputDTO {

        @Size(max = 255)
        private String street;

        @Size(max = 255)
        private String city;

        @Size(max = 255)
        private String state;

        @Size(max = 255)
        private String countryOrRegion;

        @Size(max = 50)
        private String postalCode;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class MeetingCoordinatesInputDTO {

        @DecimalMin(value = "-90.0")
        @DecimalMax(value = "90.0")
        private Double latitude;

        @DecimalMin(value = "-180.0")
        @DecimalMax(value = "180.0")
        private Double longitude;
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class BookMeetingConfigInputDTO {


        @Pattern(regexp = "^[0-9]{1,19}$")
        private String activeJobTimeValue;

        @Pattern(regexp = "^(?i)(Country|City|Site|Building|Floor)$")
        private String activeJobType;

        @Pattern(regexp = "^[0-9]{1,19}$")
        private String activeJobTypeId;

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N} _\\-.:/()]*$")
        private String activeJobTypeName;

        @Pattern(regexp = "^(?i)(Country|City|Site|Building|Floor)$")
        private String parentJobType;

        @Pattern(regexp = "^[0-9]{1,19}$")
        private String parentJobId;

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N} _\\-.:/()]*$")
        private String parentJobTypeName;

    }

}
