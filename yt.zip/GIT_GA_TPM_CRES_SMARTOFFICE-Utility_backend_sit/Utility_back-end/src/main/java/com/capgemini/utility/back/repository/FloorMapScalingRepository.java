package com.capgemini.utility.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.FloorMapScaling;

@Repository
public interface FloorMapScalingRepository extends JpaRepository<FloorMapScaling, Long> {

    @Query("SELECT f FROM FloorMapScaling f WHERE f.cdmFloorKeyId = :cdmFloorKeyId")
    FloorMapScaling findByCdmFloorKeyId(@Param("cdmFloorKeyId") Long cdmFloorKeyId);

    @Query("SELECT f FROM FloorMapScaling f")
    List<FloorMapScaling> findAllScalingRatios();
}
