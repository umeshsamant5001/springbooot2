package com.capgemini.utility.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.utility.back.mapper.PushNotificationGeneralMapper;
import com.capgemini.utility.back.model.PushNotificationGeneral;
import com.capgemini.utility.back.model.PushNotificationGeneralDTO;
import com.capgemini.utility.back.service.PushNotificationGeneralService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = PushNotificationGeneralController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
@EqualsAndHashCode
public class PushNotificationGeneralController {

    static final String ROOT_API = "api/generalpushnotification";                                   

    @Autowired
    private PushNotificationGeneralService generalPushNotificationService; 
    
    
/**
 * Endpoint to receive and save general push notification data.
 *
 * @param language         Optional request header to specify the language (default is "en").
 * @param notificationsDTO The push notification data to be saved.
 * @return The saved push notification data wrapped in a ResponseEntity.
 */

    @PostMapping 
    public ResponseEntity<PushNotificationGeneralDTO> receiveNotificationData(
    @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
    @Valid @RequestBody PushNotificationGeneralInputDTO notificationsDTO) { 
        String safeTitle = createSafeValue(notificationsDTO.getTitle());
        String safeBody = createSafeValue(notificationsDTO.getBody());
        String safeSchedule = createSafeValue(notificationsDTO.getNotificationscheduled_Date_Time());
        List<String> safeEmails = createSafeEmails(notificationsDTO.getEmails());
        PushNotificationGeneralDTO generalPushNotificationDTO = generalPushNotificationService.saveGeneralPushNotificationData(
            safeTitle,
            safeBody,
            safeSchedule,
            safeEmails);
        return ResponseEntity.ok(generalPushNotificationDTO); 
    } 


    
    
    /**
     * Endpoint to retrieve all general push notifications.
     * @return A list of push notifications wrapped in a ResponseEntity.
     * Returns 204 No Content if no notifications are found.
    */
    @GetMapping
    public ResponseEntity<List<PushNotificationGeneralDTO>> getAllPushNotifications() {

        List<PushNotificationGeneral> pushNotfnList = generalPushNotificationService.getAllPushNotifications();
        if (CollectionUtils.isEmpty(pushNotfnList)) {
            return ResponseEntity.noContent().build();
        }
        List<PushNotificationGeneralDTO> pushNotFicationDtoList = pushNotfnList.
        stream().
        map(pushnotification -> {
           return PushNotificationGeneralMapper.INSTANCE.generalPushNotificationToGeneralPushNotificationDTO(pushnotification);
        })
        .collect(Collectors.toList());
        return ResponseEntity.ok(pushNotFicationDtoList);
    }
    
    
    /**
     * Endpoint to retrieve a specific push notification by its ID.
     * @param id The ID of the push notification.
     * @return The push notification data wrapped in a ResponseEntity.
     * Returns 400 Bad Request if the ID is null.
    */

    @GetMapping("/{id}")
    public ResponseEntity<PushNotificationGeneralDTO> getPushNotificationById(@PathVariable @Min(1) Long id) {
        if (Objects.isNull(id) || id < 1L) {
            return ResponseEntity.badRequest().build();
        }
        Long safeId = Long.valueOf(String.valueOf(id));
        PushNotificationGeneral generalPushNotification = generalPushNotificationService.findById(safeId);

        return ResponseEntity.status(HttpStatus.CREATED).body(PushNotificationGeneralMapper.INSTANCE.generalPushNotificationToGeneralPushNotificationDTO(generalPushNotification));
        
    }

    
    /**
     * Endpoint to update an existing general push notification.     *
     * @param id he ID of the push notification to update.
     * @param pushNotificationdto The updated push notification data.
     * @param language Optional request header to specify the language (default is "en").
     * @return The updated push notification data wrapped in a ResponseEntity.
    */
    @PutMapping("/{id}")
    public ResponseEntity<PushNotificationGeneralDTO> updateGeneralPushNotification(@PathVariable @Min(1) Long id, @Valid @RequestBody PushNotificationGeneralInputDTO pushNotificationdto,
    @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language)
     {
        if (Objects.isNull(id) || id < 1L) {
            return ResponseEntity.badRequest().build();
        }
        Long safeId = Long.valueOf(String.valueOf(id));
        PushNotificationGeneral existingPushNotification = generalPushNotificationService.findByIdForAuthorizedWrite(safeId);
        String safeTitle = createSafeValue(pushNotificationdto.getTitle());
        String safeBody = createSafeValue(pushNotificationdto.getBody());
        String safeSchedule = createSafeValue(pushNotificationdto.getNotificationscheduled_Date_Time());
        List<String> safeEmails = createSafeEmails(pushNotificationdto.getEmails());
        PushNotificationGeneralDTO generalPushNotificationDTO = generalPushNotificationService.updatePushNotification(
            existingPushNotification,
            safeTitle,
            safeBody,
            safeSchedule,
            safeEmails);
       
        return ResponseEntity.ok(generalPushNotificationDTO);
     }



    
    /**
     * Endpoint to delete a push notification by its I
     * @param id The ID of the push notification to delete.
     * @param language Optional request header to specify the language (default is "en").
    */
    @DeleteMapping("/{id}")
    public void deletePushNotification(@PathVariable @Min(1) Long id, 
    @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (Objects.isNull(id) || id < 1L) {
            throw new IllegalArgumentException("id must be greater than 0");
        }
        Long safeId = Long.valueOf(String.valueOf(id));
        PushNotificationGeneral existingPushNotification = generalPushNotificationService.findByIdForAuthorizedWrite(safeId);
        generalPushNotificationService.deletePushNotification(existingPushNotification);
    }




    private String createSafeValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        // Sanitize: strip control characters and SQL injection sequences as defense-in-depth
        String sanitized = String.valueOf(value).trim()
            .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "")  // strip control characters
            .replaceAll("(?i)/\\*[\\s\\S]*?\\*/", "")                    // strip SQL block comments
            .replaceAll("'\\s*--", "'");                                   // neutralise SQL inline comment injection
        return new String(sanitized);
    }


    private List<String> createSafeEmails(List<String> emails) {
        if (Objects.isNull(emails)) {
            return null;
        }
        return emails.stream().
        filter(Objects::nonNull).
        map(email -> {
            // Sanitize: strip control characters as defense-in-depth
            String sanitized = String.valueOf(email).trim()
                .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "");
            return new String(sanitized);
        })
        .collect(Collectors.toList());
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class PushNotificationGeneralInputDTO {

        @NotBlank(message = "Title is required")
        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$")
        private String title;

        @NotBlank(message = "Body is required")
        @Size(max = 2000)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$")
        private String body;

        @Size(max = 50)
        @Pattern(regexp = "^[0-9T:\\-\\s/.]*$")
        private String notificationscheduled_Date_Time;

        @NotEmpty(message = "Emails cannot be empty")
        private List<@NotBlank @Email @Size(max = 255) String> emails;
    }
    
    /**
     * Endpoint to trigger sending of scheduled push notifications.
     * Typically invoked by a scheduler or cron job.
     * @param language Optional request header to specify the language (default is "en").
    */
    @PostMapping("/sendnotification")  
    public void sendNotificationFromScheduler( 
    @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
      try{            
            generalPushNotificationService.sendNotificationFromSchedular();
        } catch (Exception ex) {  
            log.error("Error while sending scheduled push notifications", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to process scheduled notification request");
        }
    }
    
}
