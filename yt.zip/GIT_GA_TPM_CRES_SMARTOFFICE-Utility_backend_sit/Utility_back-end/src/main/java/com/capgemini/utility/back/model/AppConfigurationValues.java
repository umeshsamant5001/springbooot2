package com.capgemini.utility.back.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "appConfig_values")
public class AppConfigurationValues implements Serializable {
    @Id
    @Column(name = "config_key", unique = true)
    private String key;

    @Column(name = "type")
    private String type;

    @Column(name = "value")
    private String value;

    @Column(name = "is_active")
	private Boolean isActive = false;

    @Column(name = "last_change")
    private Long lastChange;

}
