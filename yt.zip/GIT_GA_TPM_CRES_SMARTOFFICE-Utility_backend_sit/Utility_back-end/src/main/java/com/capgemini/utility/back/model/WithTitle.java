package com.capgemini.utility.back.model;

public interface WithTitle {
    String getTitleFr();

    String getTitleEn();
}
