package com.capgemini.utility.back.repository;


import com.capgemini.utility.back.model.OsTypeEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgemini.utility.back.model.AppRegistrationManagement;
import java.util.List;

public interface DeviceTokenRepository extends JpaRepository<AppRegistrationManagement, Long> {
    List<AppRegistrationManagement> findByDeviceType(OsTypeEnum deviceType);
  
    List<AppRegistrationManagement> findByEmailId(String emailId);
    
    @Query(value ="SELECT * FROM app_registration_management  WHERE email_id IN (:emails) ", nativeQuery = true )
    List<AppRegistrationManagement> findByEmailsIn(@Param("emails") List<String> emails);
    
}
