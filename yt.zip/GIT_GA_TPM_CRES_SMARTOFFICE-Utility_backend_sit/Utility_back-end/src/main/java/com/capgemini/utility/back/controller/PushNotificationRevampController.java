package com.capgemini.utility.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.utility.back.mapper.PushNotificationRevampMapper;
import com.capgemini.utility.back.model.PushNotificationRevamp;
import com.capgemini.utility.back.model.PushNotificationRevampDTO;
import com.capgemini.utility.back.service.PushNotificationRevampService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * REST controller for managing push notifications.
 * Provides endpoints to receive and retrieve push notification data.
 */
@RestController
@RequestMapping(value = PushNotificationRevampController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
public class PushNotificationRevampController {

    // Base path for all endpoints in this controller.
    static final String ROOT_API = "api/pushnotificationext";

    // Service layer dependency for handling business logic.
    @Autowired
    private PushNotificationRevampService extPushNotificationService;

    /**
     *      * Endpoint to receive and save or update a list of push notifications.
     *      * @param language the language preference from the request header
     * (default is "en")
     *      * @param notificationsDTOList list of push notification DTOs received in
     * the request body
     *      * @return a list of saved or updated notifications as maps
     *     
     */
    @PostMapping()
    public ResponseEntity<List<Map<String, Object>>> receiveNotificationData(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @Valid @RequestBody List<@Valid PushNotificationRevampUpsertInputDTO> notificationsDTOList) {

        // FIX 1: Parameter Tampering
        if (CollectionUtils.isEmpty(notificationsDTOList)) {
            return ResponseEntity.badRequest().build();
        }

        List<PushNotificationRevampDTO> safeNotificationsDTOList = notificationsDTOList.stream()
                .filter(Objects::nonNull)
                .map(this::createSafePushNotificationDTO)
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(safeNotificationsDTOList)) {
            return ResponseEntity.badRequest().build();
        }

        List<Map<String, Object>> savedOrUpdatedList = extPushNotificationService.saveOrUpdate(safeNotificationsDTOList);

        return ResponseEntity.ok(savedOrUpdatedList);
    }

    /**
     *      * Endpoint to retrieve all push notifications.
     *      * @return a list of push notification DTOs or no content if the list is
     * empty
     *     
     */
    @GetMapping
    public ResponseEntity<List<PushNotificationRevampDTO>> getAllPushNotifications() {
        List<PushNotificationRevamp> pushNotfnList = extPushNotificationService.getAllPushNotifications();
        if (CollectionUtils.isEmpty(pushNotfnList)) {
            return ResponseEntity.noContent().build();
        }
        List<PushNotificationRevampDTO> pushNotFicationDtoList = pushNotfnList.stream().map(pushnotification -> {
            return PushNotificationRevampMapper.INSTANCE
                    .pushNotificationRevampToPushNotificationRevampDTO(pushnotification);
        })
                .collect(Collectors.toList());
        return ResponseEntity.ok(pushNotFicationDtoList);
    }

    /**
     *      * Endpoint to send response of the specific actions in push
     * notifications.
     *      * @return a reponse of the FCM/APNs push notification sent as a map.
     *     
     */
    @PostMapping("/send")
    public ResponseEntity<Map<String, Object>> sendResposnseNotification(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @Valid @RequestBody PushNotificationRevampSendInputDTO notificationsDTO) {

        // FIX: Parameter Tampering
        if (notificationsDTO == null) {
            return ResponseEntity.badRequest().build();
        }

        PushNotificationRevampDTO safeNotificationsDTO = createSafeSendPushNotificationDTO(notificationsDTO);
        Map<String, Object> responseMap = extPushNotificationService.sendResposnseNotification(safeNotificationsDTO);

        return ResponseEntity.ok(responseMap);
    }

    private PushNotificationRevampDTO createSafePushNotificationDTO(PushNotificationRevampUpsertInputDTO notificationsDTO) {
        PushNotificationRevampDTO safeNotificationsDTO = new PushNotificationRevampDTO();
        safeNotificationsDTO.setTitle(Objects.nonNull(notificationsDTO.getTitle())
                ? new String(String.valueOf(notificationsDTO.getTitle()).trim())
                : null);
        safeNotificationsDTO.setBody(Objects.nonNull(notificationsDTO.getBody())
                ? new String(String.valueOf(notificationsDTO.getBody()).trim())
                : null);
        safeNotificationsDTO.setKeyId(Objects.nonNull(notificationsDTO.getKeyId())
                ? Long.valueOf(String.valueOf(notificationsDTO.getKeyId()))
                : null);
        safeNotificationsDTO.setApplicationName(Objects.nonNull(notificationsDTO.getApplicationName())
                ? new String(String.valueOf(notificationsDTO.getApplicationName()).trim())
                : null);
        safeNotificationsDTO.setEmployeeEmail(Objects.nonNull(notificationsDTO.getEmployeeEmail())
                ? new String(String.valueOf(notificationsDTO.getEmployeeEmail()).trim())
                : null);
        safeNotificationsDTO.setStatus(Objects.nonNull(notificationsDTO.getStatus())
                ? Boolean.valueOf(String.valueOf(notificationsDTO.getStatus()))
                : Boolean.FALSE);
        safeNotificationsDTO.setNotificationDateTime(Objects.nonNull(notificationsDTO.getNotificationDateTime())
                ? new String(String.valueOf(notificationsDTO.getNotificationDateTime()).trim())
                : null);
        safeNotificationsDTO.setNotificationMessage(Objects.nonNull(notificationsDTO.getNotificationMessage())
                ? new String(String.valueOf(notificationsDTO.getNotificationMessage()).trim())
                : null);
        return safeNotificationsDTO;
    }

    private PushNotificationRevampDTO createSafeSendPushNotificationDTO(PushNotificationRevampSendInputDTO notificationsDTO) {
        PushNotificationRevampDTO safeNotificationsDTO = new PushNotificationRevampDTO();
        safeNotificationsDTO.setTitle(Objects.nonNull(notificationsDTO.getTitle())
                ? new String(String.valueOf(notificationsDTO.getTitle()).trim())
                : null);
        safeNotificationsDTO.setNotificationMessage(Objects.nonNull(notificationsDTO.getNotificationMessage())
                ? new String(String.valueOf(notificationsDTO.getNotificationMessage()).trim())
                : null);
        safeNotificationsDTO.setEmployeeEmail(Objects.nonNull(notificationsDTO.getEmployeeEmail())
                ? new String(String.valueOf(notificationsDTO.getEmployeeEmail()).trim())
                : null);
        safeNotificationsDTO.setKeyId(Objects.nonNull(notificationsDTO.getKeyId())
                ? Long.valueOf(String.valueOf(notificationsDTO.getKeyId()))
                : null);
        return safeNotificationsDTO;
    }


    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class PushNotificationRevampUpsertInputDTO {

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$")
        private String title;

        @Size(max = 4000)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$")
        private String body;

        @NotNull(message = "KeyId is required")
        @Min(value = 1L, message = "KeyId should be greater than zero")
        private Long keyId;

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$")
        private String applicationName;

        @NotBlank(message = "Employee email is required")
        @Email
        @Size(max = 255)
        private String employeeEmail;

        @NotNull(message = "Status is required")
        private Boolean status = Boolean.FALSE;

        @NotBlank(message = "Notification date time is required")
        @Size(max = 50)
        @Pattern(regexp = "^[0-9T:\\-\\s/.]*$")
        private String notificationDateTime;

        @Size(max = 4000)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$")
        private String notificationMessage;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = false)
    static class PushNotificationRevampSendInputDTO {

        @Size(max = 255)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}]*$")
        private String title;

        @Size(max = 4000)
        @Pattern(regexp = "^[\\p{L}\\p{N}\\p{P}\\p{Zs}\\r\\n]*$")
        private String notificationMessage;

        @NotBlank(message = "Employee email is required")
        @Email
        @Size(max = 255)
        private String employeeEmail;

        @Min(value = 1L, message = "KeyId should be greater than zero")
        private Long keyId;
    }

}
