package com.capgemini.utility.back.mapper;

import com.capgemini.utility.back.model.PushNotificationGeneralSendHistory;
import com.capgemini.utility.back.model.PushNotificationGeneralSendHistoryDTO;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface PushNotificationGeneralSendHistoryMapper {

    PushNotificationGeneralSendHistoryMapper INSTANCE = Mappers.getMapper(PushNotificationGeneralSendHistoryMapper.class);
    
    PushNotificationGeneralSendHistoryDTO generalPushNotificationSendHistoryToDTO(PushNotificationGeneralSendHistory in);
    PushNotificationGeneralSendHistory generalPushNotificationSendHistoryDTOTEntity(PushNotificationGeneralSendHistoryDTO in);
}
