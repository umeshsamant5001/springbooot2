package com.capgemini.utility.back.model;

import java.time.OffsetDateTime;
import java.util.List;

import lombok.Data;

@Data
public class MeetingDetailsDTO {
    private String id;
    private List<MeetingAttendeeDTO> attendees;
    private List<LocationsDTO> locations;
    private Long totalBookingDuration;
    private String organizerName;
    private String organizerEmail;
    private OffsetDateTime createdDatetime;
    private String startDate;
    private String endDate;
    private String startTimezone;
    private String endTimezone;
    private Long startTimems;
    private Long endTimems;
    private Long duration;
    private Boolean allDay;
    private Boolean cancelled;
    private Boolean organizer;
    private String type;
    private Boolean onlineMeeting;
    private String recurrence;
}
