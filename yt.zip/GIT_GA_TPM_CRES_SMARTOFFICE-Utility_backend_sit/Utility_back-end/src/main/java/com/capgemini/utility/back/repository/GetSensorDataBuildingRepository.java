package com.capgemini.utility.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.GetSensorDataBuilding;

@Repository
public interface GetSensorDataBuildingRepository extends JpaRepository<GetSensorDataBuilding, Long> { 

        @Query(value = "SELECT b.id AS buildingId, " +
                "    b.title_en AS buildingName, " +
                "    bc.att_value AS assetCode, " +
                "    CASE " + 
                "        WHEN b.deployed = 1 THEN 'Active' " +
                "        ELSE 'Inactive' " +
                "    END AS buildingStatus, " + 
                "    ba.att_value AS buildingLat, " +
                "    bb.att_value AS buildingLon, " +
                "    f.id AS floorId, " + 
                "    f.title_en AS floorName, " + 
                "    p.id AS poiId, " + 
                "    p.name AS poiName, " +
                "    p.title_en AS poiTitle, " +
                "    st.space_type_name AS spaceTypeName, " +
                "    px.att_value AS x, " +
                "    py.att_value AS y, " +
                "    pc.att_value AS capacity, " +
                "    pe.att_value AS email, " +
                " STUFF((SELECT ',' + t.uuid " + 
                "           FROM device t " +
                "           WHERE t.poi_name = p.name " +
                "           FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS tabletUuids " +
                " FROM  " +
                "    building b " +
                "    LEFT JOIN building_attribute ba WITH(NOLOCK) ON b.id = ba.building_id AND ba.att_key = 'lat' " + 
                "    LEFT JOIN building_attribute bb ON b.id = bb.building_id AND bb.att_key = 'lon' " +
                "    LEFT JOIN building_attribute bc ON b.id = bc.building_id AND bc.att_key = 'cdm.asset_code' " +
                "    INNER JOIN floor f ON b.id = f.building_id " +
                "    INNER JOIN poi p WITH(NOLOCK) ON p.floor_id = f.id " +
                "    LEFT JOIN poi_attributes px WITH(NOLOCK) ON p.id = px.poi_id AND px.att_key = 'x' " +
                "    LEFT JOIN poi_attributes py WITH(NOLOCK) ON p.id = py.poi_id AND py.att_key = 'y' " +
                "    LEFT JOIN poi_attributes pc WITH(NOLOCK) ON p.id = pc.poi_id AND pc.att_key = 'capacity' " +
                "    LEFT JOIN poi_attributes pe WITH(NOLOCK) ON p.id = pe.poi_id AND pe.att_key = 'conf_room_mail' " +
                "    LEFT JOIN space_type st WITH(NOLOCK) ON st.id = p.space_type_id " +
                "    LEFT JOIN ( SELECT t1.poi_name, STRING_AGG(t1.uuid, ',') AS uuid  FROM device t1 " +
                "        GROUP BY t1.poi_name " +
                "    ) t ON p.name = t.poi_name " +
                " WHERE " +
                "    b.id = :building_id " +
                " GROUP BY " +
                "    b.id, b.title_en, bc.att_value, b.deployed, ba.att_value, bb.att_value, " +
                "    f.id, f.title_en, " +
                "    p.id, p.name, p.title_en, st.space_type_name, px.att_value, py.att_value, " +
                "    pc.att_value, pe.att_value", nativeQuery = true)
        
        List<Object[]> findBuildingDataSecond(@Param("building_id") Long buildingId);
}
