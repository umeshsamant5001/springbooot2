package com.capgemini.utility.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class BuildingDTO implements Serializable, WithTitleDTO, WithCdmAttributesDTO {
    private Long id;
    private SiteDTO site;
    private Long siteId;
    private Boolean deployed;
    private Boolean secured;
    private Long defaultMapId;
    private Long imageId;
    private String timezoneWindows;
    private String timezoneJava;
    private Long modifiedAt;
    private List<FloorDTO> floors;
    private String titleFr;
    private String titleEn;
    private String title;
    private BuildingInformation information;
    private String mailingList;
    private Long cdmKeyId;
    private Map<String, String> attributes = new HashMap<String, String>();
    private Map<String, String> cdmAttributes = new HashMap<String, String>();
    private Long nbChilds;
}
