package com.capgemini.utility.back.mapper;

import org.mapstruct.MapperConfig;
import org.mapstruct.MappingInheritanceStrategy;
import com.capgemini.utility.back.utils.LazyFieldCondition;

@MapperConfig(
    uses = { WithTitleMapper.class, LazyFieldCondition.class},
    mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG
)
public interface DtoMapperConfig {
}
