package com.capgemini.utility.back.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.utility.back.mapper.NewsMapper;
import com.capgemini.utility.back.model.News;
import com.capgemini.utility.back.model.NewsDTO;
import com.capgemini.utility.back.repository.NewsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NewsService {
    
    @Autowired
    private NewsRepository newsRepository;

    public NewsDTO findFirstActiveNews() {
        News activeNews = newsRepository.findFirstActiveNews();
        NewsDTO newsDTO = NewsMapper.INSTANCE.newsToNewsDTO(activeNews);
        return newsDTO;
    }
}
