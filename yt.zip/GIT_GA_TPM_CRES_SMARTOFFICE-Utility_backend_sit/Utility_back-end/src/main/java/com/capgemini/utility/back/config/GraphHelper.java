package com.capgemini.utility.back.config;

import java.net.URL;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.options.Option;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.requests.EventCollectionPage;
import com.microsoft.graph.requests.EventCollectionRequestBuilder;
import com.microsoft.graph.requests.GraphServiceClient;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Request;

@Component
@Slf4j
public class GraphHelper {
	// Extend time for planning subscription (must not be the exact limit time)
	public static final long EXTEND_PLANNING_SUBSCRIPTION_MINUTE = (3 * 24 - 1) * 60;

	@Autowired
	private ApplicationProperties applicationProperties;

	private GraphServiceClient<Request> mClient;
	private GraphServiceClient<Request> mClientForEmail;

	private GraphServiceClient<Request> getInstance() {
        ApplicationProperties.Azure.GraphApi graphApi = this.applicationProperties.getAzure().getGraphApi();
		if (Objects.isNull(mClient)) {
            List<String> scopes = Arrays.asList(graphApi.getScopeUrl());
			ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
					.tenantId(this.applicationProperties.getAzure().getTenantId())
					.clientId(graphApi.getClientId())
					.clientSecret(graphApi.getClientSecret())
					.build();
			TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

			try {
                URL meUrl = new URL(graphApi.getUrl());
				log.info("Graph Token {}", authProvider.getAuthorizationTokenAsync(meUrl).get());
			} catch (Exception ex) {
				log.error("Graph error {}", ex);
			}
			mClient = GraphServiceClient.builder().authenticationProvider(authProvider).buildClient();
		}
		return mClient;
	}

	public GraphServiceClient<Request> getInstanceForEmail() {
        ApplicationProperties.Azure.GraphApiSendEmail graphSendApi = this.applicationProperties.getAzure().getGraphApiSendEmail();
		if (Objects.isNull(mClientForEmail)) {
            List<String> scopes = Arrays.asList(graphSendApi.getScopeUrl());
			ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
					.tenantId(this.applicationProperties.getAzure().getTenantId())
					.clientId(graphSendApi.getClientId())
					.clientSecret(graphSendApi.getClientSecret())
					.build();
			TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

			try {
                URL meUrl = new URL(graphSendApi.getUrl());
				log.info("Graph Token {}", authProvider.getAuthorizationTokenAsync(meUrl).get());
			} catch (Exception ex) {
				log.error("Graph error {}", ex);
			}
			mClientForEmail = GraphServiceClient.builder().authenticationProvider(authProvider).buildClient();
		}
		return mClientForEmail;
	}

	/**
	 * Get a list of events between two ZonedDateTime
	 *
	 * @param start : start of DateTime
	 * @param end   : end of DateTime
	 * @param timeZone  : timezone
	 * @param room      : poi mail
	 * @return list of events
	 */
	public CompletableFuture<List<Event>> getCalendarView(long start, long end, String timeZone, String room) {
		final List<Option> options = new LinkedList<>();
		MutableDateTime dateTimeStart = new MutableDateTime(start * 1000);
		MutableDateTime dateTimeEnd = new MutableDateTime(end * 1000);

		log.info("date used for graph API : " + dateTimeStart.toString() + " | " + dateTimeEnd.toString());

		options.add(new QueryOption("startDateTime", dateTimeStart.toString()));
		options.add(new QueryOption("endDateTime", dateTimeEnd.toString()));
		// Start and end times adjusted to user's time zone
		options.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

		final List<Event> allEvents = new LinkedList<Event>();
		// Create a separate list of options for the paging requests
		// paging request should not include the query parameters from the initial
		// request, but should include the headers.
		final List<Option> pagingOptions = new LinkedList<Option>();
		pagingOptions.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

		return this.getInstance()
				.users(room)
				.calendarView()
				.buildRequest(options)
				.getAsync()
				.thenCompose(eventPage -> processPageEvent(eventPage, allEvents, pagingOptions));
	}

	/**
	 * Process each page and return a list of events
	 *
	 * @param currentPage
	 * @param eventList
	 * @param options
	 * @return CompletableFuture<List<Event>>
	 */
	private CompletableFuture<List<Event>> processPageEvent(EventCollectionPage currentPage, List<Event> eventList,
			List<Option> options) {
		eventList.addAll(currentPage.getCurrentPage());
		// Check if there is another page of results
		EventCollectionRequestBuilder nextPage = currentPage.getNextPage();
		if (nextPage != null) {
			// Request the next page and repeat
			return nextPage.buildRequest(options)
					.getAsync()
					.thenCompose(eventPage -> processPageEvent(eventPage, eventList, options));
		} else {
			// No more pages, complete the future
			// with the complete list
			return CompletableFuture.completedFuture(eventList);
		}
	}

	public CompletableFuture<List<Event>> getFutureEventsForRoom(String room, long startEpochSeconds) {

		final List<Option> options = new LinkedList<>();

		// Convert to ISO string
		MutableDateTime dateTimeStart = new MutableDateTime(startEpochSeconds * 1000);
		String startDateTime = dateTimeStart.toString();

		log.info("Using filter startDateTime: {}", startDateTime);

		// FILTER: only future events
		String filter = String.format("start/dateTime ge '%s'", startDateTime);

		options.add(new QueryOption("$filter", filter));

		// (IMPORTANT) Sort results
		options.add(new QueryOption("$orderby", "start/dateTime"));

		// Timezone header
		options.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

		final List<Event> allEvents = new LinkedList<>();

		final List<Option> pagingOptions = new LinkedList<>();
		pagingOptions.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

		return this.getInstance()
				.users(room)
				.events()
				.buildRequest(options)
				.getAsync()
				.thenCompose(eventPage ->
					processPageEvent(eventPage, allEvents, pagingOptions));
	}


}
