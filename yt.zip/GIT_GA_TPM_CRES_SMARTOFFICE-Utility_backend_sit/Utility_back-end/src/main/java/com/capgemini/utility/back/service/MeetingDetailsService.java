package com.capgemini.utility.back.service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.utility.back.model.Coordinates;
import com.capgemini.utility.back.model.LocationAddress;
import com.capgemini.utility.back.model.Locations;
import com.capgemini.utility.back.model.LocationsDTO;
import com.capgemini.utility.back.model.MeetingAttendee;
import com.capgemini.utility.back.model.MeetingAttendeeDTO;
import com.capgemini.utility.back.model.MeetingDetails;
import com.capgemini.utility.back.model.MeetingDetailsDTO;
import com.capgemini.utility.back.repository.MeetingDetailsRepository;

@Service
public class MeetingDetailsService {
    @Autowired
    private MeetingDetailsRepository meetingDetailsRepository;

    public void saveMeetingDetails(MeetingDetails meetingDetails) {
        meetingDetailsRepository.save(meetingDetails);
    }

    public void saveMeetingDetailsSafely(MeetingDetailsDTO meetingDetailsDTO) {
        MeetingDetails safeMeetingDetails = buildSafeMeetingDetails(meetingDetailsDTO);
        meetingDetailsRepository.save(safeMeetingDetails);
    }

 
    @Transactional(readOnly = true)
    public boolean existsById(String id) {
        if (id == null || id.isBlank()) return false; // defensive
        return meetingDetailsRepository.existsById(id);
    }


    private MeetingDetails buildSafeMeetingDetails(MeetingDetailsDTO meetingDetailsDTO) {
        if (Objects.isNull(meetingDetailsDTO)) {
            throw new IllegalArgumentException("Meeting details are required");
        }

        MeetingDetails safeMeetingDetails = new MeetingDetails();
        safeMeetingDetails.setId(canonicalizeMeetingId(meetingDetailsDTO.getId()));
        safeMeetingDetails.setTotalBookingDuration(canonicalizeNonNegativeLong(meetingDetailsDTO.getTotalBookingDuration()));
        safeMeetingDetails.setOrganizerName(canonicalizeOptionalText(meetingDetailsDTO.getOrganizerName(), 255));
        safeMeetingDetails.setOrganizerEmail(canonicalizeOptionalEmail(meetingDetailsDTO.getOrganizerEmail()));
        safeMeetingDetails.setCreatedDatetime(canonicalizeOffsetDateTime(meetingDetailsDTO.getCreatedDatetime()));
        safeMeetingDetails.setStartDate(canonicalizeOptionalText(meetingDetailsDTO.getStartDate(), 100));
        safeMeetingDetails.setEndDate(canonicalizeOptionalText(meetingDetailsDTO.getEndDate(), 100));
        safeMeetingDetails.setStartTimezone(canonicalizeOptionalText(meetingDetailsDTO.getStartTimezone(), 100));
        safeMeetingDetails.setEndTimezone(canonicalizeOptionalText(meetingDetailsDTO.getEndTimezone(), 100));
        safeMeetingDetails.setStartTimems(canonicalizeNonNegativeLong(meetingDetailsDTO.getStartTimems()));
        safeMeetingDetails.setEndTimems(canonicalizeNonNegativeLong(meetingDetailsDTO.getEndTimems()));
        safeMeetingDetails.setDuration(canonicalizeNonNegativeLong(meetingDetailsDTO.getDuration()));
        safeMeetingDetails.setAllDay(canonicalizeBoolean(meetingDetailsDTO.getAllDay()));
        safeMeetingDetails.setCancelled(canonicalizeBoolean(meetingDetailsDTO.getCancelled()));
        safeMeetingDetails.setOrganizer(canonicalizeBoolean(meetingDetailsDTO.getOrganizer()));
        safeMeetingDetails.setType(canonicalizeOptionalText(meetingDetailsDTO.getType(), 100));
        safeMeetingDetails.setOnlineMeeting(canonicalizeBoolean(meetingDetailsDTO.getOnlineMeeting()));
        safeMeetingDetails.setRecurrence(canonicalizeOptionalText(meetingDetailsDTO.getRecurrence(), 100));

        List<MeetingAttendee> safeAttendees = buildSafeAttendees(meetingDetailsDTO.getAttendees());
        safeMeetingDetails.setAttendees(safeAttendees);
        if (Objects.nonNull(safeAttendees)) {
            safeAttendees.forEach(attendee -> {
                if (Objects.nonNull(attendee)) {
                    attendee.setMeetingDetails(safeMeetingDetails);
                }
            });
        }

        List<Locations> safeLocations = buildSafeLocations(meetingDetailsDTO.getLocations());
        safeMeetingDetails.setLocations(safeLocations);
        if (Objects.nonNull(safeLocations)) {
            safeLocations.forEach(location -> {
                if (Objects.nonNull(location)) {
                    location.setMeetingDetails(safeMeetingDetails);
                }
            });
        }

        return safeMeetingDetails;
    }

    private List<MeetingAttendee> buildSafeAttendees(List<MeetingAttendeeDTO> attendees) {
        if (Objects.isNull(attendees)) {
            return null;
        }
        List<MeetingAttendee> safeAttendees = new ArrayList<>();
        attendees.stream().filter(Objects::nonNull).forEach(attendeeDTO -> {
            MeetingAttendee safeAttendee = new MeetingAttendee();
            safeAttendee.setMeetingRoomEmailAddress(canonicalizeOptionalAddressText(attendeeDTO.getMeetingRoomEmailAddress()));
            safeAttendee.setAttendeesName(canonicalizeOptionalText(attendeeDTO.getAttendeesName(), 255));
            safeAttendee.setAttendeesAddress(canonicalizeOptionalAddressText(attendeeDTO.getAttendeesAddress()));
            safeAttendee.setType(canonicalizeOptionalText(attendeeDTO.getType(), 100));
            safeAttendee.setResponse(canonicalizeOptionalText(attendeeDTO.getResponse(), 100));

            safeAttendees.add(safeAttendee);
        });
        return safeAttendees;
    }

    private List<Locations> buildSafeLocations(List<LocationsDTO> locations) {
        if (Objects.isNull(locations)) {
            return null;
        }
        List<Locations> safeLocations = new ArrayList<>();
        locations.stream().filter(Objects::nonNull).forEach(locationDTO -> {
            Locations safeLocation = new Locations();
            safeLocation.setLocationDisplayName(canonicalizeOptionalText(locationDTO.getLocationDisplayName(), 255));
            safeLocation.setLocationLocationType(canonicalizeOptionalText(locationDTO.getLocationLocationType(), 100));
            safeLocation.setLocationUniqueId(canonicalizeOptionalText(locationDTO.getLocationUniqueId(), 255));
            safeLocation.setLocationUniqueIdType(canonicalizeOptionalText(locationDTO.getLocationUniqueIdType(), 100));
            safeLocation.setLocationLocationUri(canonicalizeOptionalText(locationDTO.getLocationLocationUri(), 500));
            safeLocation.setLocationAddress(buildSafeLocationAddress(locationDTO.getLocationAddress()));
            safeLocation.setCoordinates(buildSafeCoordinates(locationDTO.getCoordinates()));
            safeLocations.add(safeLocation);
        });
        return safeLocations;
    }

    private LocationAddress buildSafeLocationAddress(LocationAddress locationAddress) {
        if (Objects.isNull(locationAddress)) {
            return null;
        }
        LocationAddress safeAddress = new LocationAddress();
        safeAddress.setStreet(canonicalizeOptionalText(locationAddress.getStreet(), 255));
        safeAddress.setCity(canonicalizeOptionalText(locationAddress.getCity(), 255));
        safeAddress.setState(canonicalizeOptionalText(locationAddress.getState(), 255));
        safeAddress.setCountryOrRegion(canonicalizeOptionalText(locationAddress.getCountryOrRegion(), 255));
        safeAddress.setPostalCode(canonicalizeOptionalText(locationAddress.getPostalCode(), 50));
        return safeAddress;
    }

    private Coordinates buildSafeCoordinates(Coordinates coordinates) {
        if (Objects.isNull(coordinates)) {
            return null;
        }
        Coordinates safeCoordinates = new Coordinates();
        safeCoordinates.setLatitude(canonicalizeLatitude(coordinates.getLatitude()));
        safeCoordinates.setLongitude(canonicalizeLongitude(coordinates.getLongitude()));
        return safeCoordinates;
    }

    private String canonicalizeMeetingId(String id) {
        if (Objects.isNull(id)) {
            throw new IllegalArgumentException("Meeting id is required");
        }
        String trimmed = String.valueOf(id).trim();
        if (trimmed.isEmpty() || trimmed.length() > 255 || !trimmed.matches("^[A-Za-z0-9%._~+\\-]+$")) {
            throw new IllegalArgumentException("Invalid meeting id");
        }
        return new String(trimmed);
    }

    private String canonicalizeOptionalText(String value, int maxLength) {
        if (Objects.isNull(value)) {
            return null;
        }
        String trimmed = String.valueOf(value).trim();
        if (trimmed.length() > maxLength) {
            throw new IllegalArgumentException("Invalid text value");
        }
        return new String(trimmed);
    }

    private String canonicalizeOptionalEmail(String email) {
        if (Objects.isNull(email)) {
            return null;
        }
        String trimmed = String.valueOf(email).trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > 255 || !trimmed.matches("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$")) {
            throw new IllegalArgumentException("Invalid email value");
        }
        return new String(trimmed);
    }

    private String canonicalizeOptionalAddressText(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String trimmed = String.valueOf(value).trim();
        if (trimmed.length() > 255 || !trimmed.matches("^[\\p{L}\\p{N}@._%+\\-\\s]*$")) {
            throw new IllegalArgumentException("Invalid attendee address value");
        }
        return new String(trimmed);
    }

    private Long canonicalizeNonNegativeLong(Long value) {

        if (Objects.isNull(value)) {
            return null;
        }
        Long parsed = Long.valueOf(String.valueOf(value));
        if (parsed < 0L) {
            throw new IllegalArgumentException("Invalid numeric value");
        }
        return parsed;
    }

    private OffsetDateTime canonicalizeOffsetDateTime(OffsetDateTime value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return OffsetDateTime.parse(String.valueOf(value));
    }

    private Boolean canonicalizeBoolean(Boolean value) {
        if (Objects.isNull(value)) {
            return null;
        }
        return Boolean.valueOf(String.valueOf(value));
    }

    private Double canonicalizeLatitude(Double latitude) {
        if (Objects.isNull(latitude)) {
            return null;
        }
        Double safeLatitude = Double.valueOf(String.valueOf(latitude));
        if (safeLatitude < -90.0 || safeLatitude > 90.0) {
            throw new IllegalArgumentException("Invalid latitude value");
        }
        return safeLatitude;
    }

    private Double canonicalizeLongitude(Double longitude) {
        if (Objects.isNull(longitude)) {
            return null;
        }
        Double safeLongitude = Double.valueOf(String.valueOf(longitude));
        if (safeLongitude < -180.0 || safeLongitude > 180.0) {
            throw new IllegalArgumentException("Invalid longitude value");
        }
        return safeLongitude;
    }


    
}
