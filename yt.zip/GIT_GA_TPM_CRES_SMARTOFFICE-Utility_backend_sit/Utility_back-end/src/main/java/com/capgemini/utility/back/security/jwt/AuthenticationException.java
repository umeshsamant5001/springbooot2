package com.capgemini.utility.back.security.jwt;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "authentication_exception")
@EqualsAndHashCode
public class AuthenticationException {

    public AuthenticationException(int httpStatus,int errorCode,String message,long date) {
        this.httpStatus=httpStatus;
        this.errorCode=errorCode;
        this.message=message;
        this.date = date;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Authentication_Generator")
	@SequenceGenerator(name = "Authentication_Generator", sequenceName = "Authentication_Sequence")
	private Long id;

    @Column(name = "http_status")
    private Integer httpStatus;

    @Column(name = "error_code")
    private Integer errorCode;

    @Column(name = "message")
    private String message;

    @Column(name = "date")
    private Long date;
}
