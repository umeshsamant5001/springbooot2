package com.capgemini.utility.back.model;

public enum Category {
    General, Downtime;

    public static Category findByName(String name) {
        Category result = null;
        for (Category category : values()) {
            if (category.name().equalsIgnoreCase(name)) {
                result = category;
                break;
            }
        }
        return result;
    }

}
