package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class GetSensorDataBuildingDTO {
    private Long buildingId;
    private String buildingName;
    private String assetCode;
    private String buildingStatus;
    private Double buildingLat;
    private Double buildingLon;
    private List<GetSensorDataFloorDTO> floors = new ArrayList<>();
}
