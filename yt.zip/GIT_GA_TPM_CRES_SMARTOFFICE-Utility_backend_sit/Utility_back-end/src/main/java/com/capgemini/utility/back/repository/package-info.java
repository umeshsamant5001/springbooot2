/**
 * Spring Data JPA repositories.
 */
package com.capgemini.utility.back.repository;
