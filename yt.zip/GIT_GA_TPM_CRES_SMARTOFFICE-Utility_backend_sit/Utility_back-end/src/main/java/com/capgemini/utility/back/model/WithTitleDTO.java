package com.capgemini.utility.back.model;

public interface WithTitleDTO {
    void setTitle(String title);
}
