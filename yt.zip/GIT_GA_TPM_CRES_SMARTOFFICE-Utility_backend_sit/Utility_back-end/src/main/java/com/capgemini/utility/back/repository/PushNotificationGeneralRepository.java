package com.capgemini.utility.back.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.utility.back.model.PushNotificationGeneral;



@Repository
public interface PushNotificationGeneralRepository extends JpaRepository<PushNotificationGeneral, Long> {

    Optional<PushNotificationGeneral> findByIdAndDataRecivedFrom(Long id, String dataRecivedFrom);

    @Query("SELECT g FROM PushNotificationGeneral g JOIN g.emails e WHERE g.id = :id AND g.dataRecivedFrom = :dataRecivedFrom AND LOWER(e) = LOWER(:email)")
    Optional<PushNotificationGeneral> findByIdAndDataRecivedFromAndEmail(@Param("id") Long id, @Param("dataRecivedFrom") String dataRecivedFrom, @Param("email") String email);

        
    @Query(
        value = "Select * from generalpushnotification WHERE " +
         "FORMAT(TRY_CAST(notificationscheduled_date_time AS DATETIME),'yyyy-MM-dd HH:mm') = FORMAT(GETDATE(), " +
         "'yyyy-MM-dd HH:mm') AND notification_sent = CAST(0 AS BIT) and datarecivedfrom =  'SMARTOFFICE' " , nativeQuery = true
    )    
    List<PushNotificationGeneral> findtAllReadyToSenfNoifications();
}
