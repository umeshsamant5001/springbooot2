package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CDMBatchExceptionReport {
	private List<String> listLog;

	public CDMBatchExceptionReport() {
		listLog = new ArrayList<>();
	}

	public void writeCDMBatchExceptionReport(String log) {
		listLog.add(log);
	}

	public String formatLogMail() {
		StringBuilder sb = new StringBuilder();
		sb.append("<p>").append("Exception running CDM Batch").append("</p>");
		listLog.forEach(log -> {
			sb.append("<p>").append(log).append("</p>");
		});
		return sb.toString();
	}

}
