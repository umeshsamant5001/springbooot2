package com.capgemini.utility.back.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.utility.back.mapper.PoiMapper;
import com.capgemini.utility.back.mapper.SensorBuildingFloorMapper;
import com.capgemini.utility.back.model.Building;
import com.capgemini.utility.back.model.Device;
import com.capgemini.utility.back.model.EnumDeviceType;
import com.capgemini.utility.back.model.Floor;
import com.capgemini.utility.back.model.PoiDTO;
import com.capgemini.utility.back.model.SensorBuildingFloor;
import com.capgemini.utility.back.model.SensorBuildingFloorDTO;
import com.capgemini.utility.back.model.SensorDataDTO;
import com.capgemini.utility.back.model.SensorDataSPDTO;
import com.capgemini.utility.back.model.SensorDataValuesDTO;
import com.capgemini.utility.back.service.BuildingService;
import com.capgemini.utility.back.service.DeviceService;
import com.capgemini.utility.back.service.FloorService;
import com.capgemini.utility.back.service.PoiService;
import com.capgemini.utility.back.service.SensorDataService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(DeviceController.ROOT_API)
@Slf4j
public class DeviceController {

    public static final String ROOT_API = "api/device";

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private SensorDataService sensorDataService;

    @Autowired
    private BuildingService buildingService;

    @GetMapping("/livedata")
    @Transactional
    public ResponseEntity<List<SensorDataDTO>> getLiveData(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestParam(required = true) long cdmFloorID,
            @RequestParam(required = false) List<EnumDeviceType> type) {
        Floor floor = this.floorService.findByCdmKeyId(cdmFloorID);

        if (Objects.isNull(floor)) {
            log.info("No floor found for cdmKeyId : {}", cdmFloorID);

            return ResponseEntity.notFound().build();
        }

        List<Device> deviceList = this.deviceService.findAllByFloor(floor.getId(), type);
        List<PoiDTO> poiDTOs = this.poiService.findAllViaDeviceByFloor(floor.getId(), type)
            .stream()
            .map(poi -> PoiMapper.INSTANCE.poiToPoiDTO(poi, language))
            .collect(Collectors.toList());
        
        List<SensorDataDTO> sensorDataList = this.sensorDataService.convertToSensorDataDTO(poiDTOs, deviceList);

        return ResponseEntity.ok(sensorDataList);
    }

    @GetMapping("/sensorData/{buildingId}")
    public ResponseEntity<List<SensorDataSPDTO>> getSensorDataSp(@PathVariable Long buildingId){
        Building building =   buildingService.getBuilding(buildingId);
        if (Objects.isNull(building)) {
            ResponseEntity.notFound().build();
        }
        List<SensorDataSPDTO> sensorDataSPDTO = new ArrayList<>();
            sensorDataSPDTO = this.deviceService.getSensorData(buildingId);
        return ResponseEntity.ok(sensorDataSPDTO);
    }

    @GetMapping("/sensorData/getPoiSensorJson")
    public ResponseEntity<List<SensorDataValuesDTO>> getPoiSensorJsonData(){
        List<SensorDataValuesDTO> sensorDataValuesDTOs = new ArrayList<>();
        sensorDataValuesDTOs = deviceService.getPoiSensorJsonData();
        return ResponseEntity.ok(sensorDataValuesDTOs);
    }

    @GetMapping("/sensorData/getBuildingFloorJson")
    public ResponseEntity<List<SensorBuildingFloorDTO>> getAllBuildingFloorJsonSP(){
        List<SensorBuildingFloor> sensorBuildingFloors = deviceService.getAllBuildingFloorJsonSP();
        if (Objects.isNull(sensorBuildingFloors)) {
            return ResponseEntity.notFound().build();
        }
        List<SensorBuildingFloorDTO> sensorBuildingFloorDTOs = 
            sensorBuildingFloors
            .stream()
            .map(sensorBuildingFloorData -> SensorBuildingFloorMapper.INSTANCE.sensorBuildingFloorToSensorBuildingFloorDTO(sensorBuildingFloorData))
            .collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(sensorBuildingFloorDTOs);
    }

}
