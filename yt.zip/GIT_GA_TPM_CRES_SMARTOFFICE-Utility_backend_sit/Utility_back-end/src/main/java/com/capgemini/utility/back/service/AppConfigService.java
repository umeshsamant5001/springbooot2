package com.capgemini.utility.back.service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;


import com.capgemini.utility.back.model.AppConfigurationValues;
import com.capgemini.utility.back.repository.AppConfigRepository;
import com.capgemini.utility.back.security.AuthoritiesConstants;
import com.capgemini.utility.back.security.SecurityUtils;



@Service
public class AppConfigService {

    private static final Logger log = LoggerFactory.getLogger(AppConfigService.class);
    private static final int MAX_CONFIG_VALUE_LENGTH = 255;
    private static final int MAX_LONG_VALUE_LENGTH = 19;
    private static final String BOOK_MEETING_CONFIG_TYPE = "Book a Meeting";
    private static final String JOB_TYPE_COUNTRY = "Country";
    private static final String JOB_TYPE_CITY = "City";
    private static final String JOB_TYPE_SITE = "Site";
    private static final String JOB_TYPE_BUILDING = "Building";
    private static final String JOB_TYPE_FLOOR = "Floor";
    private static final String NODE_TYPE_NAME_ALL = "ALL";

    private static final Set<String> ALLOWED_BOOK_MEETING_CONFIG_KEYS = new HashSet<>(Arrays.asList(
            "BOM_Active_JOB_TIME",
            "BOM_Active_JOB_Type",
            "BOM_Active_JOB_Type_ID",
            "BOM_Active_JOB_Type_Name",
            "BOM_Parent_JOB_Type",
            "BOM_Parent_JOB_Type_ID",
            "BOM_Parent_JOB_Type_Name"));



    @Autowired
    private AppConfigRepository appConfigRepository;


    public List<AppConfigurationValues> getActiveConfigurations(boolean isActive) {
        return appConfigRepository.findByIsActive(isActive);
    }

    public List<AppConfigurationValues> getInactiveConfigurations(boolean isActive) {
        return appConfigRepository.findByIsActive(isActive);
    }

    public AppConfigurationValues findByKeyAndIsActive(String key, Boolean isActive) {
        try {
            return appConfigRepository.findByKeyAndIsActive(key, isActive);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve app configuration by key and status", ex);
            throw new IllegalStateException("Unable to retrieve application configuration");
        }
    }

    public List<AppConfigurationValues> getAllRecords() {
        try {
            return appConfigRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve application configuration records", ex);
            throw new IllegalStateException("Unable to retrieve application configuration");
        }
    }    
    
    
    public List<AppConfigurationValues> getConfigsByType(String type) {
        return appConfigRepository.findByType(type);
    }

    public void saveValidatedConfig(AppConfigurationValues config, String value) {
        validateConfigValue(value);
        assignAndSave(config, value);
    }

    public void saveValidatedIdConfig(AppConfigurationValues config, String value) {
        validateIdValue(value);
        assignAndSave(config, value);
    }

    private void assignAndSave(AppConfigurationValues config, String value) {
        if (Objects.isNull(config)) {
            return;
        }
        enforceAuthorizedConfigWriteAccess();
        validateAllowedConfigTarget(config);
        AppConfigurationValues safeConfig = createSafeConfig(config);

        safeConfig.setType(new String(BOOK_MEETING_CONFIG_TYPE));
        String validatedValue = validateAndCanonicalizeByKey(safeConfig.getKey(), value);
        String normalizedValue = normalizeValue(validatedValue);
        // Defense-in-depth: reject any residual SQL injection sequences before persistence
        if (Objects.nonNull(normalizedValue) && containsSqlInjectionPattern(normalizedValue)) {
            throw new IllegalArgumentException("Invalid configuration value");
        }
        // Break taint flow by reconstructing the value as a brand-new String instance
        safeConfig.setValue(Objects.nonNull(normalizedValue) ? new String(normalizedValue) : null);
        appConfigRepository.save(safeConfig);
    }


    private AppConfigurationValues createSafeConfig(AppConfigurationValues config) {
        AppConfigurationValues safeConfig = new AppConfigurationValues();
        safeConfig.setKey(createSafeValue(config.getKey()));
        safeConfig.setType(createSafeValue(config.getType()));
        safeConfig.setValue(createSafeValue(config.getValue()));
        safeConfig.setIsActive(Objects.nonNull(config.getIsActive())
                ? Boolean.valueOf(String.valueOf(config.getIsActive()))
                : null);
        safeConfig.setLastChange(Objects.nonNull(config.getLastChange())
                ? Long.valueOf(String.valueOf(config.getLastChange()))
                : null);
        return safeConfig;
    }

    private String createSafeValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        // Strip control characters as defense-in-depth
        return String.valueOf(value)
            .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "");
    }

    private String normalizeValue(String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        // Sanitize: strip control characters and SQL injection sequences as defense-in-depth
        return String.valueOf(value).trim()
            .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "")  // strip control characters
            .replaceAll("(?i)/\\*[\\s\\S]*?\\*/", "")                    // strip SQL block comments
            .replaceAll("'\\s*--", "'");                                   // neutralise SQL inline comment injection
    }

    private void validateConfigValue(String value) {
        if (Objects.isNull(value)) {
            return;
        }
        if (value.length() > MAX_CONFIG_VALUE_LENGTH || !value.matches("^[\\p{L}\\p{N} _\\-.:/()]*$")) {
            throw new IllegalArgumentException("Invalid configuration value");
        }
        // Defense-in-depth: explicitly reject known SQL injection sequences
        if (containsSqlInjectionPattern(value)) {
            throw new IllegalArgumentException("Invalid configuration value");
        }
    }

    private void validateIdValue(String value) {
        if (Objects.isNull(value)) {
            return;
        }
        if (!value.matches("^[0-9]+$")) {
            throw new IllegalArgumentException("Invalid identifier value");
        }
    }

    private void validateAllowedConfigTarget(AppConfigurationValues config) {
        String safeType = Objects.nonNull(config.getType()) ? String.valueOf(config.getType()).trim() : null;
        if (Objects.isNull(safeType) || !BOOK_MEETING_CONFIG_TYPE.equalsIgnoreCase(safeType)) {
            throw new IllegalArgumentException("Invalid configuration target type");
        }
        String safeKey = Objects.nonNull(config.getKey()) ? String.valueOf(config.getKey()).trim() : null;
        if (Objects.isNull(safeKey) || !ALLOWED_BOOK_MEETING_CONFIG_KEYS.contains(safeKey)) {
            throw new IllegalArgumentException("Invalid configuration target key");
        }
    }

    private String validateAndCanonicalizeByKey(String key, String value) {
        if (Objects.isNull(value)) {
            return null;
        }
        String trimmed = String.valueOf(value).trim();
        switch (key) {
            case "BOM_Active_JOB_TIME":
            case "BOM_Active_JOB_Type_ID":
            case "BOM_Parent_JOB_Type_ID":
                validateNumericConfig(trimmed);
                return new String(trimmed);
            case "BOM_Active_JOB_Type":
            case "BOM_Parent_JOB_Type":
                return new String(canonicalizeJobType(trimmed));
            case "BOM_Active_JOB_Type_Name":
            case "BOM_Parent_JOB_Type_Name":
                if (NODE_TYPE_NAME_ALL.equalsIgnoreCase(trimmed)) {
                    return new String(NODE_TYPE_NAME_ALL);
                }
                validateConfigValue(trimmed);
                return new String(trimmed);
            default:
                throw new IllegalArgumentException("Invalid configuration target key");
        }
    }

    private void validateNumericConfig(String value) {
        validateIdValue(value);
        if (value.length() > MAX_LONG_VALUE_LENGTH) {
            throw new IllegalArgumentException("Invalid identifier value");
        }
        try {
            Long parsed = Long.valueOf(value);
            if (parsed < 0L) {
                throw new IllegalArgumentException("Invalid identifier value");
            }
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid identifier value");
        }
    }

    private String canonicalizeJobType(String jobType) {
        if (JOB_TYPE_COUNTRY.equalsIgnoreCase(jobType)) {
            return JOB_TYPE_COUNTRY;
        }
        if (JOB_TYPE_CITY.equalsIgnoreCase(jobType)) {
            return JOB_TYPE_CITY;
        }
        if (JOB_TYPE_SITE.equalsIgnoreCase(jobType)) {
            return JOB_TYPE_SITE;
        }
        if (JOB_TYPE_BUILDING.equalsIgnoreCase(jobType)) {
            return JOB_TYPE_BUILDING;
        }
        if (JOB_TYPE_FLOOR.equalsIgnoreCase(jobType)) {
            return JOB_TYPE_FLOOR;
        }
        throw new IllegalArgumentException("Invalid configuration value");
    }

    private void enforceAuthorizedConfigWriteAccess() {
        if (!SecurityUtils.isAuthenticated() ||
            SecurityUtils.hasCurrentUserNoneOfAuthorities(AuthoritiesConstants.ADMIN)) {
            throw new AccessDeniedException("Access denied for configuration write operation");
        }
    }

    /**
     * Returns true if the value contains common SQL injection sequences.
     * Used as a defense-in-depth blocklist alongside the whitelist @Pattern constraints.
     */
    private boolean containsSqlInjectionPattern(String value) {

        String lower = value.toLowerCase(Locale.ROOT);
        return lower.contains("'--")
            || lower.contains(";--")
            || (lower.contains("/*") && lower.contains("*/"))
            || lower.contains("' or '")
            || lower.contains("' and '")
            || (lower.contains("union") && lower.contains("select"))
            || lower.contains("exec(")
            || lower.contains("execute(")
            || lower.contains("xp_");
    }
}
