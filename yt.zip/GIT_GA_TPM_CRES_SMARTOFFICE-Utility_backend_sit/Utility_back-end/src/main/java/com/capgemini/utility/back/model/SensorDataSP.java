package com.capgemini.utility.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "sensordata_sp")
public class SensorDataSP {
    @Id
    @Column(name = "uuid")
    private String uuid;
    @Column(name = "sensor_status")
    private String sensorStatus;
    @Column(name = "building_name")
    private String buildingName;
    @Column(name = "building_assetcode")
    private String buildingAssetCode;
    @Column(name = "building_id")
    private Long buildingId;
    @Column(name = "floor_name")
    private String floorName;
    @Column(name = "floor_id")
    private Long floorId;
    @Column(name = "floor_index")
    private Integer floorIndex;
    @Column(name = "poi_type_name")
    private String poiTypeName;
    @Column(name = "poi_group_name")
    private String poiGroupName;
    @Column(name = "poi_name")
    private String poiName;
    @Column(name = "poi_id")
    private String poiId;
    @Column(name = "poi_title")
    private String poiTitle;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "capacity")
    private String capacity;
    @Column(name = "email")
    private String email;
}
