package com.capgemini.utility.back.model;

import lombok.Data;

@Data
public class MeetingAttendeeDTO {
    private Long id;
    private String meetingRoomEmailAddress;
    private MeetingDetailsDTO meetingDetails;
    private Long meetingDetailsId; // Reference to the MeetingDetails entity ID
    private String attendeesName;
    private String attendeesAddress;
    private String type;
    private String response;
}
