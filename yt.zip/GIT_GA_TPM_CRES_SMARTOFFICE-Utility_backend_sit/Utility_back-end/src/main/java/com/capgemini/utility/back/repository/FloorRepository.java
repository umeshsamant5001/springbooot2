package com.capgemini.utility.back.repository;

import java.util.List;
import javax.persistence.Tuple;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.Floor;

@Repository
public interface FloorRepository extends JpaRepository<Floor, Long> {

	// Count Floors by building ID
	long countByBuildingId(@Param("buildingId") Long buildingId);

	// Find floors bu building ID
	List<Floor> findAllByBuildingIdOrderByIndex(@Param("buildingId") Long buildingId);

	Floor findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	@Query(value = "select  sf.* from floor as sf left outer join building sb on sb.id = sf.building_id"
			+ " where sf.cdm_key_id =:cdmKeyId and building_id in"
			+ "(select building_id from building_attribute where att_value = :assetId) limit 1", nativeQuery = true)
	Floor findByCdmKeyIdAndAssetId(@Param("cdmKeyId") Long cdmKeyId,
			@Param("assetId") String assetId);

	List<Floor> findAllByBuildingIdAndIndex(Long buildingInd, Integer index);

	@Query("SELECT INDEX(attributes), attributes FROM Floor floor INNER JOIN floor.attributes attributes WHERE floor.id = :floorId")
	List<Tuple> getAttributesById(@Param("floorId") Long floorId);
}
