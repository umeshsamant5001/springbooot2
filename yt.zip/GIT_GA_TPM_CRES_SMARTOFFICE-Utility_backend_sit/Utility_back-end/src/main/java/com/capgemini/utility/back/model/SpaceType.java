package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import com.capgemini.utility.back.utils.StringListConverter;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "space_type")
public class SpaceType implements WithTitle{

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SpaceType_Generator")
	@SequenceGenerator(name = "SpaceType_Generator", sequenceName = "SpaceType_Sequence")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "poi_group_id", nullable = true, referencedColumnName = "id")
    @JsonIgnore
    private PoiGroup poiGroup;

    @Column(name = "poi_group_id", updatable = false, insertable = false)
	private Long poiGroupId;

    @OneToMany(mappedBy = "spaceType")
    @JsonIgnore
    private List<Poi> pois = new ArrayList<>();

    @Column(name = "space_category_name")
    private String spaceCategoryName;

    @Column(name = "space_type_name", unique = true)
    private String spaceTypeName;

    @Lob
	@Column @Convert(converter = StringListConverter.class)
	private List<String> attributeKeys;

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

    @Column(name = "is_cdm")
	private Boolean isFromCdm;

    @CollectionTable(name = "space_type_attributes", joinColumns = @JoinColumn (name = "space_type_id", referencedColumnName = "id"))
    @ElementCollection(fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    @MapKeyColumn(name = "att_key")
    @Column(name = "att_value")
    private Map<String, String> attributes = new HashMap<>();

    @OneToOne
    @JoinColumn(name = "id", referencedColumnName = "space_type_id", insertable = false, updatable = false)
    @JsonIgnore
    private CategoryMapping categoryMapping;

}
