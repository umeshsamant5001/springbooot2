package com.capgemini.utility.back.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class EquipmentDTO implements Serializable, WithTitleDTO{

    private Long id;

	private String name;

	private String titleFr;

	private String titleEn;

    private String title;

    private Long poisCount;
}
