package com.capgemini.utility.back.config;

/**
 * Application constants.
 */
public final class Constants {

    public static final String SYSTEM = "system";
    public static final Integer ACTIVE = 1;
    public static final String ANDROID = "ANDROID";
    public static final String  ANDROIDAPP = "androidApp";
    public static final String  SMARTOFFICE = "SMARTOFFICE";
    public static final String  OFFICEPASS = "OFFICEPASS";  
    public static final String  INVITE_CATEGORY = "INVITE_CATEGORY"; 
    public static final String  SCHEDULER = "SCHEDULER";
    public static final String IOS = "IOS";
    public static final String SUCCESS = "SUCCESS"; 
    public static final String PARTIALSUCCESS = "PARTIALSUCCESS"; 
    public static final String QUEUE_STATUS_PENDING = "PENDING";
    public static final String QUEUE_STATUS_PROCESSING = "PROCESSING";
    public static final String QUEUE_STATUS_SENT = "SENT";
    public static final String QUEUE_STATUS_PARTIAL_SUCCESS = "PARTIAL_SUCCESS";
    public static final String QUEUE_STATUS_FAILED_RETRYABLE = "FAILED_RETRYABLE";
    public static final String QUEUE_STATUS_FAILED_FINAL = "FAILED_FINAL";

    private Constants() {}
}
