package com.capgemini.utility.back.service;

import java.io.File;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.stream.Collectors;

import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.capgemini.utility.back.config.GraphHelper;
import com.capgemini.utility.back.mapper.MeetingDetailsMapper;
import com.capgemini.utility.back.model.AppConfigurationValues;
import com.capgemini.utility.back.model.Coordinates;
import com.capgemini.utility.back.model.LocationAddress;
import com.capgemini.utility.back.model.LocationsDTO;
import com.capgemini.utility.back.model.MeetingAttendeeDTO;
import com.capgemini.utility.back.model.MeetingDetails;
import com.capgemini.utility.back.model.MeetingDetailsDTO;
import com.capgemini.utility.back.model.PoiAttributeDTO;
import com.capgemini.utility.back.model.PoiDTO;
import com.capgemini.utility.back.repository.AppConfigRepository;
import com.capgemini.utility.back.repository.PoiRepository;
import com.microsoft.graph.models.AttendeeType;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.Location;
import com.microsoft.graph.models.Sensitivity;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MeetingService {

    private final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();

    @Autowired
    private AppConfigService appConfigService;
    @Autowired
    private GraphReportService graphReportService;
    @Autowired
    private PoiService poiService;

    @Autowired
    private AppConfigRepository appConfigRepository;

    @Autowired
    private MeetingDetailsService meetingDetailsService;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private ThreadPoolTaskExecutor meetingTaskExecutor;

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    SMTPSendMail smtpSendMail;

    private static final String type = "Book a Meeting";
    private static String currentNodeType;
    private static Long currentNodeId;
    private static Long parentNodeId;
    private static String currentNodeTypeName;
    public static final long ONE_DAY_SECOND = 86400l;

    private List<String> skippedEventsEmail = new ArrayList<>();

    /**
     * Processes meeting data from Microsoft Graph API for all configured POIs.
     * <p>
     * <ul>
     * <li>Logs the start time in Paris timezone</li>
     * <li>Fetches configuration values for job type and node IDs</li>
     * <li>Calculates the start and end of the previous day in epoch seconds</li>
     * <li>Retrieves POIs and filters those with valid conference room emails</li>
     * <li>For each POI, fetches calendar events and maps them to DTOs</li>
     * <li>Saves meeting details and updates job time configuration</li>
     * </ul>
     */
    public void doProcess() {
        log.info("doProcess() started at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));

        List<AppConfigurationValues> configs = appConfigService.getConfigsByType(type);
        // extractConfigValues(configs);

        long[] epochTimes = getPreviousDayEpochTimes("Europe/Paris");
        // long[] epochTimes = getTodayEpochTimes("Europe/Paris");

        long currentEpochTime = epochTimes[0];
        long nextMidnightEpochTime = epochTimes[1];
        List<PoiDTO> pois = graphReportService.findConferenceRoomsExcludingGermany();
        if (Objects.nonNull(pois)) {
            pois.stream()
                    .forEach(poi -> processPoiMeetings(poi, currentEpochTime, nextMidnightEpochTime, configs));
        }
    }

    /**
     * Calculates the start and end of the previous day in the specified timezone.
     *
     * @param zoneId The timezone ID (e.g., "Europe/Paris")
     * @return An array with two elements: [startEpoch, endEpoch]
     */
    private long[] getPreviousDayEpochTimes(String zoneId) {
        ZoneId parisZone = ZoneId.of(zoneId);
        ZonedDateTime now = ZonedDateTime.now(parisZone);
        ZonedDateTime start = now.minusDays(1).toLocalDate().atStartOfDay(parisZone);
        ZonedDateTime end = start.plusDays(1);
        return new long[] { start.toEpochSecond(), end.toEpochSecond() };
    }

    /**
     * Checks whether the POI has a valid non-empty conference room email.
     *
     * @param poi POI attribute DTO
     * @return true if valid, false otherwise
     */
    private boolean hasValidConfRoomMail(PoiAttributeDTO poi) {
        return Objects.nonNull(poi.getAttributes()) &&
                poi.getAttributes().containsKey("conf_room_mail") &&
                !poi.getAttributes().get("conf_room_mail").isEmpty();
    }

    public void processRoomsTest(List<String> roomEmails) {
        List<AppConfigurationValues> configs = appConfigService.getConfigsByType(type);

        long[] epochTimes = getTodayEpochTimes("Europe/Paris");
        long startEpoch = epochTimes[0];
        long endEpoch = epochTimes[1];

        for (String email : roomEmails) {
            processPoiMeetingsTest(email, startEpoch, endEpoch, configs);
        }
    }

    /** Midnight-to-midnight epoch seconds for *today* in the given timezone */
    private long[] getTodayEpochTimes(String tz) {
        ZoneId zoneId = ZoneId.of(tz);
        LocalDate today = LocalDate.now(zoneId);
        long start = today.atStartOfDay(zoneId).toEpochSecond();
        long end = today.plusDays(1).atStartOfDay(zoneId).toEpochSecond();
        return new long[] { start, end };
    }

    private void processPoiMeetings(PoiDTO poi, long startEpoch, long endEpoch,
            List<AppConfigurationValues> configs) {
        try {
            String confRoomMail = poi.getAttributes().get("conf_room_mail");
            String timezone = poi.getFloor().getBuilding().getTimezoneJava();

            List<Event> events = graphHelper
                    .getCalendarView(startEpoch, endEpoch, timezone, confRoomMail).get();

            int fetchedCount = (events == null) ? 0 : events.size();
            String sanitizedPoiId = sanitizeForLog(String.valueOf(poi.getId()));
            String sanitizedConfRoomMail = sanitizeForLog(confRoomMail);
            log.info("POI {} | Room {} | Fetched {} event(s) from Graph calendarView for window [{} - {}]",
                    sanitizedPoiId, sanitizedConfRoomMail, fetchedCount, startEpoch, endEpoch);

            if (events != null && !events.isEmpty()) {
                events = events.stream()
                        .filter(e -> {
                            boolean match = eventHasLocationUniqueIdEqualToMail(e, confRoomMail);
                            if (!match && log.isDebugEnabled()) {
                                String singleLocUid = (e.location != null ? e.location.uniqueId : null);
                                int multiLocCount = (e.locations != null ? e.locations.size() : 0);
                                log.debug(
                                        "Skipped event {}: no location.uniqueId matching room {}. singleLocUid={}, locationsCount={}",
                                        e.id, sanitizedConfRoomMail, singleLocUid, multiLocCount);
                            }
                            return match;
                        })

                        .collect(Collectors.toList());

                int kept = events.size();
                int skipped = fetchedCount - kept;
                log.info("POI {} | Room {} | Kept {} event(s), Skipped {} event(s) after uniqueId==mail filter",
                        sanitizedPoiId, sanitizedConfRoomMail, kept, skipped);
            }

            if (events != null) {
                for (Event event : events) {
                    MeetingDetailsDTO meeting = buildMeetingDetails(event, confRoomMail);
                    saveMeetings(List.of(meeting));
                    log.debug("Saved meeting {} for room {}", meeting.getId(), sanitizedConfRoomMail);
                }
            }

            updateJobTimeConfig(configs, startEpoch);

        } catch (Exception e) {
            String sanitizedPoiId = sanitizeForLog(String.valueOf(poi.getId()));
            String sanitizedErrorMessage = sanitizeForLog(e.getMessage());
            log.error("Error while fetching meetings for POI {}: {}", sanitizedPoiId, sanitizedErrorMessage, e);
        }
    }


    public boolean eventHasLocationUniqueIdEqualToMail(Event event, String roomMail) {
        if (event == null || roomMail == null || roomMail.isBlank())
            return false;

        // --- A) Single 'location'
        if (event.location != null && equalsIgnoreCase(event.location.uniqueId, roomMail)) {
            return true;
        }

        // --- B) Collection 'locations'
        if (event.locations != null) {
            for (Location loc : event.locations) {
                if (loc != null && equalsIgnoreCase(loc.uniqueId, roomMail)) {
                    return true;
                }
            }
        }

        // --- C) Fallback: if 'locations' are empty/missing, match by resource attendee
        // email
        // This ensures we keep the event even when Graph didn't populate locations.
        if (event.attendees != null) {
            boolean hasRoomResource = event.attendees.stream().anyMatch(a -> a != null && a.emailAddress != null &&
                    AttendeeType.RESOURCE.equals(a.type) &&
                    equalsIgnoreCase(a.emailAddress.address, roomMail));
            if (hasRoomResource) {
                return true;
            }
        }

        return false;
    }

    private boolean equalsIgnoreCase(String a, String b) {
        return a != null && b != null && a.trim().equalsIgnoreCase(b.trim());
    }

    /**
     * Builds a MeetingDetailsDTO object from a Microsoft Graph Event.
     *
     * @param event Microsoft Graph calendar event
     * @return Populated MeetingDetailsDTO
     * @throws UnsupportedEncodingException if encoding fails
     */
    public MeetingDetailsDTO buildMeetingDetails(Event event, String roomEmail) throws UnsupportedEncodingException {
        MeetingDetailsDTO meeting = new MeetingDetailsDTO();
        meeting.setId(URLEncoder.encode(event.id, StandardCharsets.UTF_8));
        meeting.setStartTimems(getEpochSecond(event.start.dateTime));
        meeting.setEndTimems(getEpochSecond(event.end.dateTime));
        meeting.setOnlineMeeting(event.isOnlineMeeting);
        meeting.setOrganizerEmail(event.organizer.emailAddress.address);
        meeting.setOrganizerName(event.organizer.emailAddress.name);
        meeting.setAllDay(event.isAllDay);
        meeting.setCancelled(event.isCancelled);
        meeting.setOrganizer(event.isOrganizer);
        meeting.setType(event.type.name());
        meeting.setStartDate(event.start.dateTime);
        meeting.setEndDate(event.end.dateTime);
        meeting.setStartTimezone(event.start.timeZone);
        meeting.setEndTimezone(event.end.timeZone);
        meeting.setCreatedDatetime(event.createdDateTime);
        meeting.setRecurrence(getRecurrenceType(event));
        meeting.setAttendees(buildAttendees(event));
        meeting.setLocations(buildLocationsFilteredForRoom(event, roomEmail));
        log.info("Adding slot to response {}", meeting.getId());
        return meeting;
    }

    /**
     * Extracts the recurrence type from the event.
     *
     * @param event Microsoft Graph calendar event
     * @return Recurrence type as a string, or null if not applicable
     */
    private String getRecurrenceType(Event event) {
        if (event.recurrence == null || event.recurrence.pattern == null)
            return null;
        return event.recurrence.pattern.type.toString();
    }

    private List<LocationsDTO> buildLocationsFilteredForRoom(Event event, String roomEmail) {
        List<LocationsDTO> locations = new ArrayList<>();

        // Prefer the multi-locations array when present
        if (event.locations != null && !event.locations.isEmpty()) {
            event.locations.stream()
                    .filter(loc -> loc != null && equalsIgnoreCase(loc.uniqueId, roomEmail))
                    .findFirst()
                    .ifPresent(loc -> locations.add(toLocationsDTO(loc)));
        }

        // Fallback to single 'location' if multi-locations didn't include a match
        if (locations.isEmpty() && event.location != null &&
                equalsIgnoreCase(event.location.uniqueId, roomEmail)) {
            locations.add(toLocationsDTO(event.location));
        }

        if (locations.isEmpty() && log.isDebugEnabled()) {
            String sanitizedRoomEmail = roomEmail == null ? null
                    : new String(roomEmail.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
            String sanitizedEventId = event.id == null ? null
                    : new String(event.id.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
            log.debug("No matching location found for room {} in event {}", sanitizedRoomEmail, sanitizedEventId);
        }

        return locations;
    }

    private LocationsDTO toLocationsDTO(Location location) {
        LocationsDTO dto = new LocationsDTO();
        dto.setLocationDisplayName(location.displayName);
        dto.setLocationLocationType(location.locationType != null ? location.locationType.name() : null);
        dto.setLocationUniqueId(location.uniqueId);
        dto.setLocationUniqueIdType(location.uniqueIdType != null ? location.uniqueIdType.name() : null);

        Coordinates coords = new Coordinates();
        if (location.coordinates != null) {
            coords.setLatitude(location.coordinates.latitude);
            coords.setLongitude(location.coordinates.longitude);
        }
        dto.setCoordinates(coords);

        LocationAddress address = new LocationAddress();
        if (location.address != null) {
            address.setStreet(location.address.street);
            address.setCity(location.address.city);
            address.setState(location.address.state);
            address.setCountryOrRegion(location.address.countryOrRegion);
            address.setPostalCode(location.address.postalCode);
        }
        dto.setLocationAddress(address);

        return dto;
    }

    /**
     * Builds a list of attendees for the meeting.
     *
     * @param event Microsoft Graph calendar event
     * @return List of MeetingAttendeeDTO
     */
    private List<MeetingAttendeeDTO> buildAttendees(Event event) {
        MeetingAttendeeDTO attendee = new MeetingAttendeeDTO();
        if (event.sensitivity == Sensitivity.PRIVATE) {
            attendee.setMeetingRoomEmailAddress("PRIVATE");
            attendee.setAttendeesName("PRIVATE");
        } else {
            attendee.setMeetingRoomEmailAddress(event.organizer.emailAddress.address);
            String[] name = event.organizer.emailAddress.name.split(",");
            attendee.setAttendeesName(name[0]);
            attendee.setAttendeesAddress(event.organizer.emailAddress.address);
        }
        return List.of(attendee);
    }

    /**
     * Builds a list of location DTOs from the event's location data.
     *
     * @param event Microsoft Graph calendar event
     * @return List of LocationsDTO
     */
    private List<LocationsDTO> buildLocations(Event event) {
        List<LocationsDTO> locations = new ArrayList<>();
        if (event.locations != null) {
            for (Location location : event.locations) {
                LocationsDTO dto = new LocationsDTO();
                dto.setLocationDisplayName(location.displayName);
                dto.setLocationLocationType(location.locationType.name());
                dto.setLocationUniqueId(location.uniqueId);
                dto.setLocationUniqueIdType(location.uniqueIdType.name());

                Coordinates coords = new Coordinates();
                if (location.coordinates != null) {
                    coords.setLatitude(location.coordinates.latitude);
                    coords.setLongitude(location.coordinates.longitude);
                }
                dto.setCoordinates(coords);

                LocationAddress address = new LocationAddress();
                if (location.address != null) {
                    address.setStreet(location.address.street);
                    address.setCity(location.address.city);
                    address.setState(location.address.state);
                    address.setCountryOrRegion(location.address.countryOrRegion);
                    address.setPostalCode(location.address.postalCode);
                }
                dto.setLocationAddress(address);
                locations.add(dto);
            }
        }
        return locations;
    }

    /**
     * Updates the job time configuration value with the latest epoch time.
     *
     * @param configs   List of configuration values
     * @param epochTime Epoch time to be saved
     */
    private void updateJobTimeConfig(List<AppConfigurationValues> configs, long epochTime) {
        configs.stream()
                .filter(config -> "BOM_Active_JOB_TIME".equals(config.getKey()))
                .forEach(config -> {
                    config.setValue(Long.toString(epochTime));
                    appConfigRepository.save(config);
                });
    }

    /**
     * Convert given epoch to epoch in give zone
     *
     * @param timestampSeconds
     * @param zone
     * @return
     */
    private long getZonedEpochFromUTCEpoch(long timestampSeconds, String zone) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), ZoneId.of(zone))
                .atZone(UTC_ZONE_ID)
                .toEpochSecond();
    }

    public void saveMeetings(List<MeetingDetailsDTO> meetingDetailsDTOList) {

        try {
            meetingDetailsDTOList.forEach(meetingDetailsDTO -> {
                if (Objects.nonNull(meetingDetailsDTO)) {
                    // ✅ Skip if this ID already exists in DB
                    if (meetingDetailsService.existsById(meetingDetailsDTO.getId())) {
                        log.debug("Skipping duplicate meeting with id={}", meetingDetailsDTO.getId());
                        return;
                    }
                    MeetingDetails meetingDetails = MeetingDetailsMapper.INSTANCE
                            .meetingDetailsDTOToMeetingDetails(meetingDetailsDTO);
                    if (Objects.nonNull(meetingDetails) && Objects.nonNull(meetingDetails.getAttendees())) {
                        // Set the MeetingDetails reference for each MeetingAttendee
                        meetingDetails.getAttendees().forEach(attendee -> {
                            if (Objects.nonNull(attendee)) {
                                attendee.setMeetingDetails(meetingDetails);
                            }
                        });
                    }
                    if (Objects.nonNull(meetingDetails) && Objects.nonNull(meetingDetails.getLocations())) {
                        // Set the MeetingDetails reference for each locations
                        meetingDetails.getLocations().forEach(location -> {
                            if (Objects.nonNull(location)) {
                                location.setMeetingDetails(meetingDetails);
                            }
                        });
                    }
                    meetingDetailsService.saveMeetingDetails(meetingDetails);
                }
            });
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage(), e);
        }

    }

    public long getEpochSecond(String dateString) {
        // Define the formatter
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS");

        // Parse the date string to LocalDateTime
        LocalDateTime localDateTime = LocalDateTime.parse(dateString, formatter);

        // Get the ZoneId for UTC using TimeZone
        ZoneId zoneId = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();

        // Convert LocalDateTime to ZonedDateTime with the ZoneId
        ZonedDateTime zonedDateTime = localDateTime.atZone(zoneId);

        // Convert ZonedDateTime to Instant
        Instant instant = zonedDateTime.toInstant();

        // Get the epoch seconds
        long epochSeconds = instant.getEpochSecond();

        log.info("Unix UTC epoch seconds: " + epochSeconds);
        return epochSeconds;

    }

    private void processPoiMeetingsTest(String roomEmail, long startEpoch, long endEpoch,
            List<AppConfigurationValues> configs) {
        try {
            String sanitizedRoomEmail = sanitizeForLog(roomEmail);
            String timezone = "Europe/Paris"; // Hardcoded for testing
            List<Event> events = graphHelper.getCalendarView(startEpoch, endEpoch, timezone, roomEmail).get();

            int fetchedCount = (events == null) ? 0 : events.size();
            log.info("Room {} | Fetched {} event(s) from Graph calendarView for window [{} - {}]",
                    sanitizedRoomEmail, fetchedCount, startEpoch, endEpoch);


            if (events != null && !events.isEmpty()) {
                events = events.stream()
                        .filter(e -> eventHasLocationUniqueIdEqualToMail(e, roomEmail))
                        .collect(Collectors.toList());

                int kept = events.size();
                int skipped = fetchedCount - kept;
                log.info("Room {} | Kept {} event(s), Skipped {} event(s) after uniqueId==mail filter",
                        sanitizedRoomEmail, kept, skipped);


                for (Event event : events) {
                    MeetingDetailsDTO meeting = buildMeetingDetails(event, roomEmail);
                    saveMeetings(List.of(meeting));
                    log.debug("Saved meeting {} for room {}", meeting.getId(), sanitizedRoomEmail);

                }
            }

            updateJobTimeConfig(configs, startEpoch);

        } catch (Exception e) {
            log.error("Error while fetching meetings for room {}: {}", sanitizeForLog(roomEmail), e.getMessage(), e);
        }
    }


    /**
     * Processes meeting data from Microsoft Graph API for all configured POIs.
     * <p>
     * <ul>
     * <li>Logs the start time in Paris timezone</li>
     * <li>Fetches configuration values for job type and node IDs</li>
     * <li>Calculates the start and end of the previous day in epoch seconds</li>
     * <li>Retrieves POIs and filters those with valid conference room emails</li>
     * <li>For each POI, fetches calendar events and maps them to DTOs</li>
     * <li>Saves meeting details and updates job time configuration</li>
     * </ul>
     */
    
    public void doProcessTabletMeetings() {

        log.info("doProcessTabletMeetings() started at {}",
                LocalDateTime.now(ZoneId.of("Europe/Paris")));

        List<String> allSkippedEmailList = new ArrayList<>();

        List<PoiDTO> pois = graphReportService.findConferenceRoomsForTabletMeetings();
        log.info("Total POIs fetched for tablet meetings: {}", (pois == null ? 0 : pois.size()));

        if (pois != null) {
            for (PoiDTO poi : pois) {

                List<String> roomEmailsList = processPoiMeetingsForTablet(poi);

                if (roomEmailsList != null && !roomEmailsList.isEmpty()) {
                    allSkippedEmailList.addAll(roomEmailsList);
                }
            }
        }
       
        log.info("Total skipped room emails: {}", allSkippedEmailList.size());
        if (!allSkippedEmailList.isEmpty()) {
            List<String> sanitizedSkippedEmailList = allSkippedEmailList.stream()
                    .map(this::sanitizeForLog)
                    .collect(Collectors.toList());
            log.info("Skipped room emails : {}", sanitizedSkippedEmailList);
        
            try{
                byte[] attachmentContent = generateExcel(allSkippedEmailList);
                sendEmail(attachmentContent);
            } catch (Exception e) {
                log.error("Error generating Excel file: {}", e.getMessage(), e);
            }
        }
           
    }

    /**
     * Processes meeting data from Microsoft Graph API for all configured POIs.
     * <p>
     * <ul>
     * <li>Logs the start time in Paris timezone</li>
     * <li>Fetches configuration values for job type and node IDs</li>
     * <li>Calculates the start and end of the previous day in epoch seconds</li>
     * <li>Retrieves POIs and filters those with valid conference room emails</li>
     * <li>For each POI, fetches calendar events and maps them to DTOs</li>
     * <li>Saves meeting details and updates job time configuration</li>
     * </ul>
     */
    
    public void doProcessTabletMeetingsTest() {

        log.info("doProcessTabletMeetingsTest() started at {}",
                LocalDateTime.now(ZoneId.of("Europe/Paris")));

        List<String> allSkippedEmailList = new ArrayList<>();

        List<PoiDTO> pois = graphReportService.findConferenceRoomsForTabletMeetingsTest();

        if (pois != null) {
            for (PoiDTO poi : pois) {

                List<String> roomEmailsList = processPoiMeetingsForTabletTest(poi);
                roomEmailsList.add("cr.fr.il16emet128psurfacehub@capgemini.com");
                roomEmailsList.add("cr.fr1.il16emet128psurfacehub@capgemini.com");
                roomEmailsList.add("");
                roomEmailsList.add("cr.fr2.il16emet128psurfacehub@capgemini.com");
                roomEmailsList.add("cr.fr4.il16emet128psurfacehub@capgemini.com");
                 roomEmailsList.add("");
                

                if (roomEmailsList != null && !roomEmailsList.isEmpty()) {
                    allSkippedEmailList.addAll(roomEmailsList);
                }
            }
        }
       
        log.info("Total skipped room emails: {}", allSkippedEmailList.size());
        if (!allSkippedEmailList.isEmpty()) {
            List<String> sanitizedSkippedEmailList = allSkippedEmailList.stream()
                    .map(this::sanitizeForLog)
                    .collect(Collectors.toList());
            log.info("Skipped room emails : {}", sanitizedSkippedEmailList);
        
            try{
                File file = generateExcelTest(allSkippedEmailList);
                sendEmailTest(file);
            } catch (Exception e) {
                log.error("Error generating Excel file: {}", e.getMessage(), e);
            }
        }
      
    }

    private byte[] generateExcel(List<String> roomEmailList) throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("All_Rooms");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Room Email");

            int rowNum = 1;
            for (String room : roomEmailList) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(room);
            }

            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    private void sendEmail(byte[] attachmentContent) {
        smtpSendMail.createAndSendGraphMessage(attachmentContent);
    }

      private File generateExcelTest(List<String> roomEmailList) throws Exception {

        
        for (String room : roomEmailList) {
            System.out.println("Room: " + room);  // 
        }

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("All_Rooms");

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Room Email");

        int rowNum = 1;
        for (String room : roomEmailList) {
            if(room == null || room.trim().isEmpty() || room.equals("")){ 
                continue; // Skip null or empty room emails 
            }
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(room);
        }

        File file = new File("Rooms.xlsx");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            workbook.write(fos);
        }

        workbook.close();
        return file;
      }

      private void sendEmailTest(File file) {
        smtpSendMail.createAndSendGraphMessageTest(file);
      }

    private List<String> processPoiMeetingsForTablet(PoiDTO poi) {

        List<String> emailSkipped = new ArrayList<>();

        try {
            String confRoomMail = poi.getAttributes().get("conf_room_mail");
            if(confRoomMail != null && !confRoomMail.isEmpty() && !confRoomMail.equals("")){
                String timezone = poi.getFloor().getBuilding().getTimezoneJava();

                long[] epochTimes = getStartAndDateFromScheduledTime("Europe/Paris");
                long startEpoch = epochTimes[0];
                long endEpoch = epochTimes[1];
        
                MutableDateTime dateTimeStart = new MutableDateTime(startEpoch * 1000);
		        MutableDateTime dateTimeEnd = new MutableDateTime(endEpoch * 1000);
                log.info("date used for graph API for Room : "+  confRoomMail + " | "  + dateTimeStart.toString() + " | " + dateTimeEnd.toString());
                List<Event> events = graphHelper
                        .getCalendarView(startEpoch, endEpoch, timezone, confRoomMail).get();

    
                int fetchedCount = (events == null) ? 0 : events.size();
                String sanitizedPoiId = sanitizeForLog(String.valueOf(poi.getId()));
                String sanitizedConfRoomMail = sanitizeForLog(confRoomMail);
    
                log.info("POI {} | Room {} | Fetched {} event(s)",
                        sanitizedPoiId, sanitizedConfRoomMail, fetchedCount);
    
                if(fetchedCount == 0)
                    return List.of(""); // If no events, return a list with an empty string to indicate the room is free.
        
                
                for (Event event : events) {
                    log.info("Graph Event data for confRoomMail {} POI {} | Event ID: {}, Start: {}, End: {}, Cancelled: {}, Organizer: {}",
                            confRoomMail, poi.getId(), event.id, event.start.dateTime, event.end.dateTime,
                            event.isCancelled, event.organizer.emailAddress.address);
                }

                int fetchedCount = (events == null) ? 0 : events.size();

                log.info("POI {} | Room {} | Fetched {} Graph event(s) for window [{} - {}]\"",
                        poi.getId(), confRoomMail, fetchedCount, startEpoch, endEpoch);

                if(fetchedCount == 0)
                    return List.of(""); // If no events, return a list with an empty string to indicate the room is free.
        
                //startEpoch = convertToUTC(startEpoch, timezone, timezone);
                //endEpoch = convertToUTC(endEpoch, timezone, timezone);


                List<Object[]> results =
                        poiRepository.findEventsInMeetingTable(confRoomMail, startEpoch, endEpoch);
                        
                log.info("POI {} | Room {} | Found {} event(s) in meeting table for window [{} - {}]",
                        sanitizedPoiId, sanitizedConfRoomMail, (results == null ? 0 : results.size()), startEpoch, endEpoch);
    
                if (results != null && !results.isEmpty() && results.size() < fetchedCount) {

                    log.info("POI {} | Room {} | Some events are not in the meeting table  for window [{} - {}]", poi.getId(), confRoomMail, startEpoch, endEpoch); 
                    emailSkipped.add(confRoomMail);
    
                }
            } 

        } catch (Exception e) {
            String sanitizedPoiId = sanitizeForLog(String.valueOf(poi.getId()));
            String sanitizedErrorMessage = sanitizeForLog(e.getMessage());
            log.error("Error for POI {}: {}", sanitizedPoiId, sanitizedErrorMessage, e);
        }

        return emailSkipped;
    }


    private List<String> processPoiMeetingsForTabletTest(PoiDTO poi) {

        List<String> emailSkipped = new ArrayList<>();

        try {
            String confRoomMail = poi.getAttributes().get("conf_room_mail");
            if(confRoomMail != null && !confRoomMail.isEmpty() && !confRoomMail.equals("")){
                String timezone = poi.getFloor().getBuilding().getTimezoneJava();

            //  long[] epochTimes = getTodayEpochTimes("Europe/Paris");
                long[] epochTimes = getStartAndDateFromScheduledTime(timezone);
                long startEpoch = epochTimes[0];
                long endEpoch = epochTimes[1];

                MutableDateTime dateTimeStart = new MutableDateTime(startEpoch * 1000);
		        MutableDateTime dateTimeEnd = new MutableDateTime(endEpoch * 1000);
                log.info("date used for graph API for Room : "+  confRoomMail + " | "  + dateTimeStart.toString() + " | " + dateTimeEnd.toString());
                log.info("date used for graph API for Room , Epoch time : "+  confRoomMail + " | "  + startEpoch + " | " + endEpoch);

                List<Event> events = graphHelper
                        .getCalendarView(startEpoch, endEpoch, timezone, confRoomMail).get();
                for (Event event : events) {
                    log.info("Graph Event data for confRoomMail {} POI {} | Event ID: {}, Start: {}, End: {}, Cancelled: {}, Organizer: {}",
                            confRoomMail, poi.getId(), event.id, event.start.dateTime, event.end.dateTime,
                            event.isCancelled, event.organizer.emailAddress.address);
                }

                int fetchedCount = (events == null) ? 0 : events.size();

                log.info("POI {} | Room {} | Fetched {} Graph event(s) for window [{} - {}]\"",
                        poi.getId(), confRoomMail, fetchedCount, startEpoch, endEpoch);

                if(fetchedCount == 0)
                    return List.of(""); // If no events, return a list with an empty string to indicate the room is free.

                //startEpoch = convertToUTC(startEpoch, timezone, timezone);
                //endEpoch = convertToUTC(endEpoch, timezone, timezone);
                List<Object[]> results =
                        poiRepository.findEventsInMeetingTable(confRoomMail, startEpoch, endEpoch);
                        
                log.info("POI {} | Room {} | Found {} event(s) in meeting table for window [{} - {}]",
                        poi.getId(), confRoomMail, (results == null ? 0 : results.size()), startEpoch, endEpoch);

                if (results != null && !results.isEmpty() && results.size() < fetchedCount) {
                    log.info("POI {} | Room {} | Some events are not in the meeting table", poi.getId(), confRoomMail); 
                    emailSkipped.add(confRoomMail);
                }
            }

        } catch (Exception e) {
            log.error("Error for POI {}: {}", poi.getId(), e.getMessage(), e);
        }

        return emailSkipped;
    }

    /** Midnight-to-midnight epoch seconds for *today* in the given timezone */
    private long[] getStartAndDateFromScheduledTime(String tz) {
       
        ZoneId zoneId = ZoneId.of(tz);

        ZonedDateTime now = ZonedDateTime.now(zoneId);
        //LocalDate today = LocalDate.now(zoneId);

        // Start of day (00:00)
        long start = now.toEpochSecond();//today.atStartOfDay(zoneId).toEpochSecond();

        // Add 12 hours from start of day
        // long end = today
        //         .atStartOfDay(zoneId)
        //         .plusHours(12)
        //         .toEpochSecond();
        // Add 12 hours from start of day
        long end = now
                .plusHours(12)
                .toEpochSecond();

        return new long[] { start, end };

    }

    private Long convertToUTC(long epochSeconds, String eventTimeZone, String targetTimeZone) {
        MutableDateTime date = new MutableDateTime(epochSeconds * 1000, DateTimeZone.forID(eventTimeZone));
        date.setZone(DateTimeZone.forID(targetTimeZone));
        return this.getZonedEpochFromUTCEpoch(date.getMillis() / 1000, targetTimeZone);
    }

    private String sanitizeForLog(String input) {
        if (Objects.isNull(input)) {
            return null;
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
