/**
 * JPA domain objects.
 */
package com.capgemini.utility.back.domain;
