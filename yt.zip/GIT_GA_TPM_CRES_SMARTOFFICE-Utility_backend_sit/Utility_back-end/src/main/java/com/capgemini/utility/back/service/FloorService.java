package com.capgemini.utility.back.service;

import java.util.stream.Collectors;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.capgemini.utility.back.model.Floor;
import com.capgemini.utility.back.repository.FloorRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FloorService {

	static final String API_TAG = "Floor";

	@Autowired
	private FloorRepository floorRepository;


	public Floor findByCdmKeyId(long cdmKeyId) {
		return this.floorRepository.findByCdmKeyId(cdmKeyId);
	}

	public Map<String, String> getAttributesById(Long floorId) {
		try {
			return this.floorRepository.getAttributesById(floorId)
				.stream()
				.collect(Collectors.toMap(
					(tuple) -> tuple.get(0, String.class),
					(tuple) -> tuple.get(1, String.class)
				));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve floor attributes by id", ex);
			throw new IllegalStateException("Unable to retrieve floor attributes");
		}
	}

}
