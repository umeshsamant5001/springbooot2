/**
 *
 */
package com.capgemini.utility.back.controller;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.utility.back.model.Base64FloorMap;
import com.capgemini.utility.back.model.Building;
import com.capgemini.utility.back.model.CDMBatchExceptionReport;
import com.capgemini.utility.back.model.CDMFloor;
import com.capgemini.utility.back.model.EnumCdmAttributes;
import com.capgemini.utility.back.model.Floor;
import com.capgemini.utility.back.repository.FloorRepository;
import com.capgemini.utility.back.service.CDMClient;

import lombok.extern.slf4j.Slf4j;

/**
 * Controller managing the floor API
 *
 * @author alcarpen
 *
 */
@RestController
@Slf4j
@RequestMapping(value = FloorController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class FloorController {

	static final String ROOT_API = "api/floors";

	static final String API_TAG = "Sites";

	@Autowired
	private FloorRepository floorRepository;

	@Autowired
	private CDMClient cdm;

    @GetMapping("/{floorId}/getFloorMap")
	public ResponseEntity<Base64FloorMap> getFloorMapByFloorId( //
			HttpServletRequest request, //
			@PathVariable Long floorId) {

		Floor floor = this.floorRepository.findById(floorId).orElseThrow();
		if(Objects.isNull(floor)){
			return ResponseEntity.notFound().build();
		}
		Building building = floor.getBuilding();
		if(Objects.isNull(building)){
			return ResponseEntity.notFound().build();
		}
		Base64FloorMap map = new Base64FloorMap();
		CDMBatchExceptionReport cdmBatchExceptionReport = new CDMBatchExceptionReport();
		try {
			List<CDMFloor> res = cdm.getPoiFloorCDM(building.getAttributes().get(EnumCdmAttributes.ASSET_ID.toString()),
					floor.getCdmKeyId(), cdmBatchExceptionReport);
			map.setFloorId(String.valueOf(floor.getId()));
			map.setBase64map(res.get(0).getBase64Map());
		}catch (Exception ex) {
            log.info(ex.getMessage());
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(map);
	}
}
