package com.capgemini.utility.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.Device;
import com.capgemini.utility.back.model.EnumDeviceType;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

    public List<Device> findAllByPoiName(@Param("poiName") String poiName);

    public List<Device> findAllByPoiNameIn(@Param("poiNames") List<String> poiNames);

    @Query("SELECT device FROM Device device INNER JOIN FETCH device.floor floor INNER JOIN FETCH floor.building WHERE floor.id = :floorId")
    public List<Device> findAllByFloorId(@Param("floorId") long floorId);

    @Query("SELECT device FROM Device device INNER JOIN FETCH device.floor floor INNER JOIN FETCH floor.building WHERE floor.id = :floorId AND device.deviceType IN (:typeList)")
    public List<Device> findAllByFloorIdAndDeviceTypeIn(@Param("floorId") long floorId,
            @Param("typeList") List<EnumDeviceType> typeList);

}
