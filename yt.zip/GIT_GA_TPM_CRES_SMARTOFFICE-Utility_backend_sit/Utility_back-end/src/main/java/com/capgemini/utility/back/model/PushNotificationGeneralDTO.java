package com.capgemini.utility.back.model;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public class PushNotificationGeneralDTO {

    private Long id;
    @NotBlank(message = "Title is required")
    private String title;
	
    @NotBlank(message = "Body is required")
    private String body;

    private Long createdDateTime;
    private String notificationscheduled_Date_Time;

    @NotEmpty(message = "Emails cannot be empty")
    private List<@Email String> emails;

    private String dataRecivedFrom;
    private String notificationSentBy;
    private String notificationStaus;

    private Boolean notificationSent = Boolean.FALSE;
}