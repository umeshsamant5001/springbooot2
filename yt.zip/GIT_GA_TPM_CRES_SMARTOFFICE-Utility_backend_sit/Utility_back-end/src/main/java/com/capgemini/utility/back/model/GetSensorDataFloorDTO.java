package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class GetSensorDataFloorDTO {
    private Long floorId;
    private String floorName;
    private List<GetSensorDataPoiDTO> pois = new ArrayList<>();
}
