package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class SensorBuildingFloorDTO {
    private Long buildingId;
    private int deployed; 
    private String address;
    private Long capacity;
    private String city;
    private int secured;
    private String buildingName;
    private String country;
    private String buildingStatus;
    private String buildingCoordinates;
    private String buildingAssetcode;
    private List<Floors> floors = new ArrayList<>(); 
}
