package com.capgemini.utility.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.utility.back.model.News;

@Repository
public interface NewsRepository extends JpaRepository<News, Long> {

    @Query(value = "SELECT TOP (1) * FROM news WHERE status = 1 AND status IS NOT NULL", nativeQuery = true)
    News findFirstActiveNews();
}
