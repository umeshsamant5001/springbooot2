package com.capgemini.utility.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.rest.core.annotation.RestResource;
import com.capgemini.utility.back.config.DbConfig;
import com.capgemini.utility.back.config.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "poi", uniqueConstraints = { @UniqueConstraint(columnNames = { "name", "floor_id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Poi implements WithTitle{

	private static final long serialVersionUID = -8843741413665003259L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Poi_Generator")
	@SequenceGenerator(name = "Poi_Generator", sequenceName = "Poi_Sequence")
	private Long id;

    //technical name , needed to match poi while installing sensors
	@NotNull
	@Column(name = "name", nullable = false, updatable = true, unique = true)
	private String name;

	@ManyToOne
	@JoinColumn(name = "floor_id")
	@JsonIgnore
	private Floor floor;

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

	@Column(name = "floor_id", updatable = false, insertable = false)
	private Long floorId;

	@ManyToOne
	@JoinColumn(name = "space_type_id",nullable = true)
	private SpaceType spaceType;
	@Column(name = "space_type_id", updatable = false, insertable = false)
	private Long spaceTypeId;

	@Column(name = "modifiedAt", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime() / 1000;

	@Column(name = "cdm_key_id")
	private Long cdmKeyId;

	@CollectionTable(name = "poi_attributes", joinColumns = @JoinColumn(name = "poi_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<>();

	@ManyToMany(fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
	@JoinTable(name = "pois_equipments", //
			joinColumns = @JoinColumn(name = "poi_id", referencedColumnName = "id"), //
			inverseJoinColumns = @JoinColumn(name = "equipment_id", referencedColumnName = "id"))
	@RestResource(exported = false)
	private List<Equipment> equipments = new ArrayList<>();

	@Transient
	private Integer floorIndex;

	public Integer getFloorIndex() {
		if (floor == null)
			return -1;
		return floor.getIndex();
	}

	public Double getX() {
		return Double.valueOf(attributes.getOrDefault("x", "0"));
	}

	public Double getY() {
		return Double.valueOf(attributes.getOrDefault("y", "0"));
	}

	public Double getLon() {
		return Double.valueOf(attributes.getOrDefault("lon", "0"));
	}

	public Double getLat() {
		return Double.valueOf(attributes.getOrDefault("lat", "0"));
	}

	public boolean hasCoordinates() {
		return hasXY() && hasLonLat();
	}

	public boolean hasXY() {
		boolean result = false;
		if(Objects.nonNull(attributes.get("x")) && Objects.nonNull(attributes.get("y"))) {
			result = true;
		}
		return result;
	}

	public boolean hasLonLat() {
		boolean result = false;
		if(Objects.nonNull(attributes.get("lon")) && Objects.nonNull(attributes.get("lat"))) {
			result = true;
		}
		return result;
	}

}
