package com.capgemini.utility.back.model;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class PoiAttributeDTO implements WithTitleDTO{
    private Long id;
    private String name;
    private String title;
    private Map<String, String> attributes = new HashMap<String, String>();

}
