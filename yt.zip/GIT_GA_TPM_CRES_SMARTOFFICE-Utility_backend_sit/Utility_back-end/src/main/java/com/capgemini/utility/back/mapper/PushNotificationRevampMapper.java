package com.capgemini.utility.back.mapper;

import com.capgemini.utility.back.model.PushNotificationRevamp;
import com.capgemini.utility.back.model.PushNotificationRevampDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface PushNotificationRevampMapper {

    PushNotificationRevampMapper INSTANCE = Mappers.getMapper(PushNotificationRevampMapper.class);
    
    PushNotificationRevampDTO pushNotificationRevampToPushNotificationRevampDTO(PushNotificationRevamp in);
    PushNotificationRevamp pushNotificationRevampDTOToPushNotificationRevamp(PushNotificationRevampDTO in);
}
