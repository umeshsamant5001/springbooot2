package com.capgemini.utility.back.model;


import lombok.Data;

@Data
public class BookMeetingConfigDTO {

    private String activeJobTimeValue;
    private String activeJobType;
    private String activeJobTypeId;
    private String activeJobTypeName;
    private String parentJobType;
    private String parentJobId;
    private String parentJobTypeName;

}
    

