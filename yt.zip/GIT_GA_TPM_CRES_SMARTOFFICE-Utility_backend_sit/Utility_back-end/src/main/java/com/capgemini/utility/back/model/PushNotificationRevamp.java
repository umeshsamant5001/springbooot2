package com.capgemini.utility.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.ColumnDefault;
import com.capgemini.utility.back.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "externalpushnotification")  
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class PushNotificationRevamp {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "externalpushnotification_Generator")
	@SequenceGenerator(name = "externalpushnotification_Generator", sequenceName = "extpushnotif_Sequence")
	private Long id;
	
	@Column(name = "title" )
	private String title;

	@Column(name = "body" )
	private String body;

	@Column(name ="keyid")
	private Long keyId;

	@Column(name="application_name")
	private String applicationName;

	@Column(name = "employeeemail")
	private String employeeEmail;

	@Column(name = "status")
	@ColumnDefault("false")
	private Boolean status =  false;

	@Column(name = "notification_datetime")
	private String  notificationDateTime;

	@Column(name = "notification_message",length = 2147483647)
	private String  notificationMessage;

	@Column(name ="created_date_time")
	private Long createdDateTime;

	@Column(name ="updated_date_time")
	private Long updatedDateTime;

	@Column(name = "notification_status") 
	private String notificationStatus; 

	@Column(name = "notification_sent")
	@ColumnDefault("false")
    private Boolean notificationSent = false; 

	@Column(name = "retrycount")
	private Long retryCount; 

	@Column(name = "notification_sent_by")
    private String notificationSentBy;

	@Column(name = "notification_failure_reason", length = 2147483647) 
	private String notificationFailureReason; 

	@Column(name ="notification_failure_time")
	private Long notificationFailurTime;
	
	@Column(name = "notification_sent_time")
	private Long notificationSentTime; 

	@Column(name = "success_meessage_ids", length = 2147483647) 
	private String successMessageIds; 	
		
}
