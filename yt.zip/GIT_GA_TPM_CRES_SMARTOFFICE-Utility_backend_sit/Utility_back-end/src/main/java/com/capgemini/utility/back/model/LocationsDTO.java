package com.capgemini.utility.back.model;
import lombok.Data;

@Data
public class LocationsDTO {

    private Long id;
    private String locationDisplayName;
    private String locationLocationType;
    private String locationUniqueId;
    private String locationUniqueIdType;
    private String locationLocationUri;
    private LocationAddress locationAddress;
    private Coordinates coordinates;
    private MeetingDetailsDTO meetingDetails;
    private Long meetingDetailsId; // Reference to the MeetingDetails entity ID
}
