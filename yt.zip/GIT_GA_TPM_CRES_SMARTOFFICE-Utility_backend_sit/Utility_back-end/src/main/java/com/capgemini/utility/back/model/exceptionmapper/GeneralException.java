package com.capgemini.utility.back.model.exceptionmapper;


public abstract class GeneralException extends RuntimeException {

	private static final long serialVersionUID = -3413152488747677582L;

	private final int httpStatus;

	private final int errorCode;


	public GeneralException(int httpStatus, int errorCode, String message) {
		super(message);
		this.httpStatus = httpStatus;
		this.errorCode = errorCode;
	}

	public int getHttpStatus() {
		return httpStatus;
	}

	public int getErrorCode() {
		return errorCode;
	}

}
