package com.capgemini.utility.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.SensorBuildingFloor;
import com.capgemini.utility.back.model.SensorBuildingFloorDTO;

@Mapper(config = DtoMapperConfig.class)
public interface SensorBuildingFloorMapper {
    
    SensorBuildingFloorMapper INSTANCE = Mappers.getMapper(SensorBuildingFloorMapper.class);

    SensorBuildingFloor sensorBuildingFloorDTOToSensorBuildingFloor(SensorBuildingFloorDTO in);
    SensorBuildingFloorDTO sensorBuildingFloorToSensorBuildingFloorDTO(SensorBuildingFloor in);

}
