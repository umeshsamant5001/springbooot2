package com.capgemini.utility.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.capgemini.utility.back.config.ApplicationProperties;
import com.capgemini.utility.back.model.CDMBatchExceptionReport;
import com.capgemini.utility.back.model.CDMFloor;
import com.google.gson.Gson;

/**
 * The CDM client to build requests and parse responses
 *
 *
 */
@Component
public class CDMClient {

	@Autowired
	private ApplicationProperties applicationProperties;

	private static final Logger log = LoggerFactory.getLogger(CDMClient.class);
	private static final String COUNTRIES_ENDPOINT = "/cdm/tree?externalCall=Y";
	private static final String POIS_ENDPOINT = "/cdm/floorpois?";
	private static final String COUNTRY_BY_CDM_KEY_ID_ENDPOINT = "/cdm/country/";
	private static final String CITY_BY_CDM_KEY_ID_ENDPOINT = "/cdm/city/";
	private static final String SITE_BY_CDM_KEY_ID_ENDPOINT = "/cdm/site/";
	private static final String ASSET_BY_CDM_KEY_ID_ENDPOINT = "/cdm/asset/";

	private static final String URL_REST_COUNTRIES = "https://restcountries.eu/rest/v2/all";

	@Autowired
	private CDMRequestFactory factory;

	@Autowired
	private CDMResponseParser resParser;

	@Autowired
	private CDMAuthenticationService cdmAuthenticateService;

	public List<CDMFloor> getPoiFloorCDM(String assetId, Long keyId, CDMBatchExceptionReport cdmBatchExceptionReport) {
		List<CDMFloor> result = null;

		try {
			log.info(String.format("calling CDM with assetId %s and floorId %s", assetId, String.valueOf(keyId)));
			result = Arrays
					.asList((new Gson()).fromJson(
							getPoiByAssetIdAndFloorCdmKey(assetId, keyId, cdmBatchExceptionReport), CDMFloor[].class));
		} catch (Exception e) {
			if (Objects.nonNull(cdmBatchExceptionReport)) {
				//cdmBatchExceptionReport.writeCDMBatchExceptionReport(e.getMessage());
			}
		}
		if (Objects.isNull(result)) {
			// TO be sure to always return a List
			return new ArrayList<>();
		}

		return result;
	}
    /**
	 * Get a Pois details from assetId and FloorCdmKey
	 *
	 * @param session
	 * @param assetId
	 * @param keyId
	 * @return List of Pois for corresponding Floor
	 */
	public String getPoiByAssetIdAndFloorCdmKey(String assetId, Long keyId,
			CDMBatchExceptionReport cdmBatchExceptionReport) {
		Map<String, String> params = new HashMap<>();
		params.put("assetId", assetId.toString());
		params.put("floorID", keyId.toString());
		log.debug("Log_custom_1-Before request" + POIS_ENDPOINT);
		String result = "";
		try {
			result = factory.get(getUri(POIS_ENDPOINT), cdmAuthenticateService.getDefaultHeaders(), params,
					resParser::readGetListPoiByAssetIdAndFloorKeyId);
		} catch (Exception e) {
			if (Objects.nonNull(cdmBatchExceptionReport)) {
				cdmBatchExceptionReport.writeCDMBatchExceptionReport(e.getMessage());
			}

		}

		return result;
	}
	private String getUri(String endpoint) {
		return this.applicationProperties.getCdm().getUrl() + endpoint;
	}
}
