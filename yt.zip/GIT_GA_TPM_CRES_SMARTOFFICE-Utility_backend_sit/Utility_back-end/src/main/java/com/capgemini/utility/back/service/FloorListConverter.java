package com.capgemini.utility.back.service;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import com.capgemini.utility.back.model.Floors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Converter
public class FloorListConverter implements AttributeConverter<List<Floors>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(List<Floors> floors) {
        if (floors == null) return null;
        try {
            return objectMapper.writeValueAsString(floors);
        } catch (Exception e) {
            throw new IllegalArgumentException("Error converting list of floors to JSON", e);
        }
    }

    @Override
    public List<Floors> convertToEntityAttribute(String json) {
        if (json == null || json.isEmpty()) return new ArrayList<>();
        try {
            return objectMapper.readValue(json, new TypeReference<List<Floors>>() {});
        } catch (Exception e) {
            throw new IllegalArgumentException("Error converting JSON to list of floors", e);
        }
    }
}

