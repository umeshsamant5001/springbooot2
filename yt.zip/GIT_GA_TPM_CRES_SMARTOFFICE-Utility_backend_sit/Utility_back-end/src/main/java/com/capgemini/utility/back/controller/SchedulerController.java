package com.capgemini.utility.back.controller;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.utility.back.config.GraphHelper;
import com.capgemini.utility.back.service.MeetingService;
import com.microsoft.graph.models.Event;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/scheduler")
public class SchedulerController {

    @Autowired
    private MeetingService meetingService;

    @Autowired
    private GraphHelper graphHelper;

    @PostMapping("/graphAPI/meetings")
    public ResponseEntity<Object> getMeetings() {
        log.info("getMeetings() started at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
        meetingService.doProcess();
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/graphAPI/meetings/tablet")
    public ResponseEntity<Object> getTabletMeetings() {
        log.info("getTabletMeetings() started at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
        meetingService.doProcessTabletMeetings();
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/graphAPI/meetings/tablettest")
    public ResponseEntity<Object> getTabletMeetingsTest() {
        log.info("getTabletMeetingsTest() started at {}", LocalDateTime.now(ZoneId.of("Europe/Paris")));
        meetingService.doProcessTabletMeetingsTest();
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/graphAPI/meetings/room")
    public ResponseEntity<List<Map<String, Object>>> getPreviousDayMeetingsForSingleRoomTest(
            @RequestParam String roomEmail) {

        String sanitizedRoomEmail = sanitizeForLog(roomEmail);
        List<Map<String, Object>> responseList = new ArrayList<>();


        try {
            ZoneId parisZoneId = ZoneId.of("Europe/Paris");
            ZonedDateTime nowInParis = ZonedDateTime.now(parisZoneId);
            ZonedDateTime startOfPreviousDay = nowInParis.minusDays(1).toLocalDate().atStartOfDay(parisZoneId);
            ZonedDateTime endOfPreviousDay = startOfPreviousDay.plusDays(1);

            long startEpoch = startOfPreviousDay.toEpochSecond();
            long endEpoch = endOfPreviousDay.toEpochSecond();

            // You can hardcode timezone or fetch from building if needed
            String timezone = "Asia/Kolkata";

            List<Event> events = graphHelper.getCalendarView(startEpoch, endEpoch, timezone, roomEmail).get();

            for (Event event : events) {
                Map<String, Object> meetingInfo = new HashMap<>();
                meetingInfo.put("id", event.id);
                meetingInfo.put("subject", event.subject);
                meetingInfo.put("start", event.start.dateTime);
                meetingInfo.put("end", event.end.dateTime);
                meetingInfo.put("cancelled", event.isCancelled);
                meetingInfo.put("organizer", event.organizer.emailAddress.address);
                responseList.add(meetingInfo);
            }

        } catch (Exception e) {
            log.error("Error fetching meetings for room {}: {}", sanitizedRoomEmail, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }


        return ResponseEntity.ok(responseList);
    }

    // @PostMapping("/room/customWindow")
    // public ResponseEntity<String> getRoomDataWithCustomWindow(
    //         @RequestParam String startDateTime,
    //         @RequestParam String endDateTime) {

    //     try {
    //         long startEpoch = Instant.parse(startDateTime).getEpochSecond();
    //         long endEpoch = Instant.parse(endDateTime).getEpochSecond();

    //         meetingService.processMeetingsWithCustomWindowTest(startEpoch, endEpoch);
    //         return ResponseEntity.ok("Meetings processed for custom time window.");
    //     } catch (Exception e) {
    //         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
    //                 .body("Error: " + e.getMessage());
    //     }
    // }




    @PostMapping("/fetch")
    public ResponseEntity<String> fetchMeetingsTest(@RequestBody List<String> roomEmails) {
        meetingService.processRoomsTest(roomEmails);
        return ResponseEntity.ok("Processed " + roomEmails.size() + " rooms");
    }


    private String sanitizeForLog(String input) {
        if (input == null) {
            return null;
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
