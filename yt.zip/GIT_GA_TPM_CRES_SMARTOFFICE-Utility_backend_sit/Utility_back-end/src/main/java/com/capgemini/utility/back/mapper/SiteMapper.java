package com.capgemini.utility.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.utility.back.model.Building;
import com.capgemini.utility.back.model.BuildingDTO;
import com.capgemini.utility.back.model.City;
import com.capgemini.utility.back.model.CityDTO;
import com.capgemini.utility.back.model.Site;
import com.capgemini.utility.back.model.SiteDTO;

@Named("SiteMapper")
@Mapper(config = DtoMapperConfig.class, uses = {CdmAttributesMapper.class})
public interface SiteMapper {

	SiteMapper INSTANCE = Mappers.getMapper(SiteMapper.class);

    @Mapping(source = "in", target ="attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributes" })
    Site siteDTOToSite(SiteDTO in);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(target = "buildings", ignore = true),
    	@Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" }),
		@Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper", "mapCdmAttributesDTO" })
    })
    SiteDTO siteToSiteDTONoBuildings(Site in, @Context String language);

    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" }),
    	@Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" }),
		@Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper", "mapCdmAttributesDTO" })
    })
    SiteDTO siteToSiteDTO(Site in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutParent")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(target = "city", ignore = true),
        @Mapping(source = "buildings", target = "buildings", qualifiedByName = { "buildingToBuildingDTOWithoutParent" }),
    	@Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" }),
		@Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper", "mapCdmAttributesDTO" })
    })
    SiteDTO _siteToSiteDTOWithoutParent(Site in, @Context String language);

    /**
     * <p><strong>Do not use directly</strong> : used for @Mapping() decorator.</p>
     *
     * <p>For more information, check BuildingMapper.</p>
     */
    @Named("siteToSiteDTOWithoutChildren")
    @Mappings({
        @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
        @Mapping(source = "city", target = "city", qualifiedByName = { "cityToCityDTOWithoutChildren" }),
        @Mapping(target = "buildings", ignore = true),
    	@Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributesDTO" }),
		@Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper", "mapCdmAttributesDTO" })
    })
    SiteDTO _siteToSiteDTOWithoutChildren(Site in, @Context String language);

    @Named("buildingToBuildingDTOWithoutParent")
    default BuildingDTO _buildingToBuildingDTOWithoutParent(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutParent(building, language);
    }

    @Named("cityToCityDTOWithoutChildren")
    default CityDTO _cityToCityDTOWithoutChildren(City city, @Context String language) {
        return Mappers.getMapper(CityMapper.class)._cityToCityDTOWithoutChildren(city, language);
    }

}
