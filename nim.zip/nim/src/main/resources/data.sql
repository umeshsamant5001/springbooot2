---------------------
-- H2 LOGS --
---------------------

BEGIN;
DROP TABLE IF EXISTS logging_event_property;
DROP TABLE IF EXISTS logging_event_exception;
DROP TABLE IF EXISTS logging_event;
COMMIT;


BEGIN;
CREATE TABLE logging_event
(
    timestmp         BIGINT NOT NULL,
    formatted_message  TEXT NOT NULL,
    logger_name       VARCHAR(254) NOT NULL,
    level_string      VARCHAR(254) NOT NULL,
    thread_name       VARCHAR(254),
    reference_flag    SMALLINT,
    arg0              VARCHAR(254),
    arg1              VARCHAR(254),
    arg2              VARCHAR(254),
    arg3              VARCHAR(254),
    caller_filename   VARCHAR(254) NOT NULL,
    caller_class      VARCHAR(254) NOT NULL,
    caller_method     VARCHAR(254) NOT NULL,
    caller_line       CHAR(4) NOT NULL,
    event_id          BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY
);
COMMIT;

BEGIN;
CREATE TABLE logging_event_property
(
    event_id	      BIGINT NOT NULL,
    mapped_key        VARCHAR(254) NOT NULL,
    mapped_value      TEXT,
    PRIMARY KEY(event_id, mapped_key),
    FOREIGN KEY (event_id) REFERENCES logging_event(event_id)
);
COMMIT;

BEGIN;
CREATE TABLE logging_event_exception
(
    event_id         BIGINT NOT NULL,
    i                SMALLINT NOT NULL,
    trace_line       VARCHAR(254) NOT NULL,
    PRIMARY KEY(event_id, i),
    FOREIGN KEY (event_id) REFERENCES logging_event(event_id)
);
COMMIT;

insert into country (id,cdm_key_id,country_iso_alpha2) values
(1,100,'FR');
insert into country_translation(id,country_id,locale,type,content) values
(1,1,'en','title','France-EN'),
(2,1,'fr','title','France-FR');

insert into city (id,country_id,cdm_key_id) values
(11, 1,37826);
insert into city_translation(id,city_id,locale,type,content) values
(1,11,'en','title','Nantes-EN'),
(2,11,'fr','title','Nantes-FR');
insert into site (id,city_id,cdm_key_id) values
(111,11,303);
/*insert into site_translation(id,site_id,locale,type,content) values
(1,111,'en','title','Nantes-EN'),
(1,111,'fr','title','Nantes-FR');*/

insert into opening_hours (id, opening, closing) values
(1111111111,25200,64800);

insert into building (id, site_id, address, city,id_opening_hours, capacity, deployed, phone, reception_mail, timezone_windows, timezone_java,secured, cdm_key_id) values
(1111, 111, 'Rue Nathalie Lemel', '44400 Nantes',1111111111, 2226, false, 0102030405, 'test@test.com', 'Romance Standard Time', 'Europe/Paris',true, 325);
/*insert into building_translation(id,building_id,locale,type,value) values
(1,1111,'en','title','Berlingot-EN'),
(2,1111,'fr','title','Berlingot-FR');*/
insert into building_attribute (building_id, att_value, att_key) values
(1111, '40.217500','lat'),
(1111,'-1.533700','lon'),
(1111, '-170753.7','x'),
(1111, '5977639.0','y'),
(1111, '14','daysLimit');

insert into building_attribute (building_id, att_key, att_value) values
(1111, 'cdm.asset_id','FR185OF01'),
(1111, 'checkin.alert.building','false');

insert into floor (id, building_id, floor_index,cdm_key_id) values
(11111,1111, 0,596),
(11112,1111, 1,597),
(11113,1111, 2,598),
(11114,1111, 3,599);

insert into poi_type (id, name, attribute_keys) values
(1, 'hygiene_toilets', 'has_handicaped,has_door'),
(2, 'level_elevator', ''),
(3, 'room_bubble', ''),
(4, 'room_conference', 'email,capacity,poiVisibility');


insert into poi_type_attribute (poitype_id, att_key, att_value) values
(4, 'bookable', 'true'),
(14, 'hasState', 'true'),
(14, 'defaultVisibility', 'true');



insert into poi_equipment (id, name) values
(101, 'projector'),
(102, 'phone'),
(103, 'visio');
insert into equipment_translation(id,locale,type,content,equipment_id) values
(1,'en','title','Projector',101),
(2,'fr','title','Projecteur',101),
(3,'en','title','Phone',101),
(4,'fr','title','Téléphone',101);

insert into admin_menu_page (id, title, path, icon, htmlclass, is_external_link, menu_index, parent_id) values
(1, 'homePage.Home', '/home', 'ft-home', '', false, 1, null),
(2, 'homePage.Journeys', '/journeys', 'ft-navigation', '', false, 2, null);
/*
(3, '', 'homePage.PlacesTitles','ft-globe', 'has-sub', '',  '', false, null,2),
(4, '/place', 'homePage.PlacesSitesTree','', '', '',  '', false, 3,3),
(5, '/map/list', 'homePage.PlacesMapList','', '', '',  '', false, 3,4),

(6, '', 'homePage.PoiTitle','ft-map-pin', 'has-sub', '',  '', false, null,5),
(7, '/poi/map', 'homePage.PoisList','', '', '',  '', false, 6,6),
(8, '/poi/type', 'homePage.PoiTypes','', '', '',  '', false, 6,7),
(9, '/poi/import', 'homePage.PoisImport','', '', '',  '', false, 6,8),
(10, '/poi/equipment', 'homePage.PoiEquipements','', '', '',  '', false, 6,9),

(11, '', 'homePage.ManageService','ft-settings', 'has-sub', '',  '', false, null,10),
(36, '/service/catalog', 'homePage.Service','', '', '',  '', false, 11,10),
(37, '/service/export', 'homePage.ServiceExport','', '', '',  '', false, 11,10),
(12, '', 'homePage.DashboardTitle','ft-pie-chart',  'has-sub', '',  '', false, null,11),
(27, '/dashboards/?page=co2', 'homePage.CO2','', '', '',  '', false, 12,12),
(28, '/dashboards/?page=historian', 'homePage.Historian','', '', '',  '', false,12,13),
(29, '/dashboards/?page=real_time', 'homePage.Realtime','', '', '',  '', false, 12,14),
(30, '/dashboards/?page=desk', 'homePage.Desks','', '', '',  '', false, 12,15),

(41, '', 'homePage.ManagePopup','ft-settings', 'has-sub', '',  '', false, null, 16),
(42, '/popup/message', 'homePage.PopupMessage','', '', '',  '', false, 41, 17),
(43, '/popup/constraint', 'homePage.PopupConstraint','', '', '',  '', false, 41, 18),

(13, '/information', 'homePage.InformationFlowsTitle','ft-message-circle', '', '',  '', false, null,19),

(14, '', 'navbar.Support','ft-settings', 'has-sub', '',  '', false, null,20),
(15, '/event/type', 'navbar.EventType','', '', '',  '', false, 14,21),
(16, '/report/type', 'navbar.ReportType','', '', '',  '', false, 14,22),

(17, '', 'homePage.ManageDevicesTitle','ft-sliders', 'has-sub', '',  '', false, null,28),
(33, '/devices/tablets', 'homePage.ManageTabletsTitle','', '', '',  '', false, 17,29),
(40, '/devices/import-tablets', 'homePage.ImportTabletsTitle','', '', '',  '', false, 17,29),
(32, '/devices/sensors', 'homePage.ManageSensorsTitle','', '', '',  '', false, 17,29),
(35, '/devices/import', 'homePage.ImportDevicesTitle','', '', '',  '', false, 17,29),
(34, '/devices/export', 'homePage.ExportDevicesTitle','', '', '',  '', false, 17,29),



(18, '','homePage.ManageUsersTitle','ft-user', 'has-sub', '',  '', false, null,23),
(19, '/user/list','homePage.UserList','', '', '',  '', false, 18,29),
(20, '/user/type', 'homePage.UserType','', '', '',  '', false, 18,30),
(31, '/user/import', 'homePage.UserImport','', '', '',  '', false, 18,31),
(21, '','navbar.Admin','ft-shield', 'has-sub', '',  '', false, null,32),
(22, '/swagger-ui.html','navbar.SwaggerAPI','', '', '',  '', true, 21,33),
(23, '/v2/api-docs?group=1-captain','navbar.CaptainAPIJSON','', '', '',  '', true, 21,34),
(24, '/v2/api-docs?group=2-backoffice','navbar.BackOfficeAPIJSON','', '', '',  '', true, 21,35),
(26, '/nodered/#flow','navbar.NodeRED','', '', '',  '', true, 21,37);
*/

insert into device (uuid, floor_id,  poi_name,  last_change, status, device_type) values 
('tablet1', 11123, 'PoiTablet1', 1538744231, 'ACTIVE', 'TABLET');