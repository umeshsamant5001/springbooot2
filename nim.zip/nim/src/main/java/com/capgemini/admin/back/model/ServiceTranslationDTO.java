package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class ServiceTranslationDTO {
    private Long id;
    public String key;
    public String value;
    public String locale;
    private ServiceDTO service;
    private Long serviceId;
}
