package com.capgemini.admin.back.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "distributed_lock")
@Data
public class DistributedLock {

    @Id
    @Column(name = "lock_name", nullable = false, unique = true)
    private String lockName;

    @Column(name = "locked_at", nullable = false)
    private LocalDateTime lockedAt;

    @Column(name = "locked_by", nullable = false)
    private String lockedBy;

}
