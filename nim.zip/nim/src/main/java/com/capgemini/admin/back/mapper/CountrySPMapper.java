package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.CountrySP;
import com.capgemini.admin.back.model.CountrySPDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface CountrySPMapper {
    CountrySPMapper INSTANCE = Mappers.getMapper(CountrySPMapper.class);

    CountrySPDTO countrySPToCountrySPDTO(CountrySP countrySP);
}
