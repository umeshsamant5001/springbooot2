package com.capgemini.admin.back.temporary;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.config.ApplicationProperties;
import com.google.gson.Gson;

/**
 * The CDM client to build requests and parse responses
 *
 *
 */
@Component
public class CDMClient {

	private static final Logger log = LoggerFactory.getLogger(CDMClient.class);

	private static final String POIS_ENDPOINT = "/cdm/floorpois?";

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private CDMRequestFactory factory;

	@Autowired
	private CDMResponseParser resParser;

	@Autowired
	private CDMAuthenticationService cdmAuthenticateService;

	public List<CDMFloor> getPoiFloorCDM(String assetId, Long keyId, CDMBatchExceptionReport cdmBatchExceptionReport) {
		List<CDMFloor> result = null;

		try {
			String safeAssetId = sanitizeForLog(String.valueOf(assetId));
			String safeKeyId = sanitizeForLog(String.valueOf(keyId));
			log.info("calling CDM with assetId {} and floorId {}", safeAssetId, safeKeyId);
			result = Arrays

					.asList((new Gson()).fromJson(
							getPoiByAssetIdAndFloorCdmKey(assetId, keyId, cdmBatchExceptionReport), CDMFloor[].class));
		} catch (Exception e) {
			if (Objects.nonNull(cdmBatchExceptionReport)) {
				// cdmBatchExceptionReport.writeCDMBatchExceptionReport(e.getMessage());
			}
		}
		if (Objects.isNull(result)) {
			// TO be sure to always return a List
			return new ArrayList<>();
		}

		return result;
	}

	/**
	 * Get a Pois details from assetId and FloorCdmKey
	 *
	 * @param session
	 * @param assetId
	 * @param keyId
	 * @return List of Pois for corresponding Floor
	 */
	public String getPoiByAssetIdAndFloorCdmKey(String assetId, Long keyId,
			CDMBatchExceptionReport cdmBatchExceptionReport) {
		Map<String, String> params = new HashMap<>();
		params.put("assetId", assetId.toString());
		params.put("floorID", keyId.toString());
		log.debug("Log_custom_1-Before request" + POIS_ENDPOINT);
		String result = "";
		try {
			result = factory.get(getUri(POIS_ENDPOINT), cdmAuthenticateService.getDefaultHeaders(), params,
					resParser::readGetListPoiByAssetIdAndFloorKeyId);
		} catch (Exception e) {
			if (Objects.nonNull(cdmBatchExceptionReport)) {
				cdmBatchExceptionReport.writeCDMBatchExceptionReport(e.getMessage());
			}

		}

		return result;
	}

	private String getUri(String endpoint) {
		return this.applicationProperties.getCdm().getUrl() + endpoint;
	}

	private String sanitizeForLog(String input) {
		if (input == null) {
			return "";
		}
		return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
	}
}
