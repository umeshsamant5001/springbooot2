package com.capgemini.admin.back.model;

/**
 * Level for the basic tree
 */
public enum SubLevelEnum {
    FLOOR,
    POI,
    DEVICE,
    CISCO_DEVICE
}
