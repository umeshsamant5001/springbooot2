package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;


import com.capgemini.admin.back.model.AuditLogging;
import com.capgemini.admin.back.model.AuditLoggingDTO;

@Mapper(config = DtoMapperConfig.class)

public interface AuditLoggingMapper {

    AuditLoggingMapper INSTANCE = Mappers.getMapper(AuditLoggingMapper.class);

    AuditLoggingDTO auditloggingToAuditLoggingDTO(AuditLogging in);

    @Mapping(target = "id", ignore = true)
    AuditLogging auditloggingDTOToAuditLogging(AuditLoggingDTO in);


}
