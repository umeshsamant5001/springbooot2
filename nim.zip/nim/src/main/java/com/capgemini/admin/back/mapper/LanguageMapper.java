package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.Language;
import com.capgemini.admin.back.model.LanguageDTO;

@Named("LanguageMapper")
@Mapper(config = DtoMapperConfig.class)
public interface LanguageMapper {
    LanguageMapper INSTANCE = Mappers.getMapper(LanguageMapper.class);

    LanguageDTO languageToLanguageDTO(Language in);

    Language languageDTOToLanguage(LanguageDTO in);
}
