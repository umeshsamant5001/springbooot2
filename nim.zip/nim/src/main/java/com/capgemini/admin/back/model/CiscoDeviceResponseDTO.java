package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class CiscoDeviceResponseDTO {
    private String deviceId;
    private String poiName;
    private String poiTitle;
    private String poiType;
    private String deviceType;
    private Long lastDataReceived;
    private CiscoDeviceAttributesDTO ciscoDeviceAttributes;
}
