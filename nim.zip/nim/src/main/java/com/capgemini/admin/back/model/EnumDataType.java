package com.capgemini.admin.back.model;

public enum EnumDataType {
    STRING,
    NUMBER,
    DECIMAL,
    BOOLEAN
}
