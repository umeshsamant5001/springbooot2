package com.capgemini.admin.back.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import  com.capgemini.admin.back.model.CountryMapping;

@Repository
public interface CountryMappingRepository extends JpaRepository<CountryMapping, Long> {

    Optional<CountryMapping> findByGraphCountryNameIgnoreCaseAndIsActiveTrue(String graphCountryName);

}
