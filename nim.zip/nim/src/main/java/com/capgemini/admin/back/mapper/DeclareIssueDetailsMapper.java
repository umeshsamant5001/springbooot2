package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.DeclareIssueDetails;
import com.capgemini.admin.back.model.DeclareIssueDetailsDTO;

@Mapper(config = DtoMapperConfig.class)
public interface DeclareIssueDetailsMapper {

    DeclareIssueDetailsMapper INSTANCE = Mappers.getMapper(DeclareIssueDetailsMapper.class);

    DeclareIssueDetails declareIssueDetailsDTOToDeclareIssueDetails(DeclareIssueDetailsDTO in);

    DeclareIssueDetailsDTO declareIssueDetailsToDeclareIssueDetailsDTO(DeclareIssueDetails in);
}
