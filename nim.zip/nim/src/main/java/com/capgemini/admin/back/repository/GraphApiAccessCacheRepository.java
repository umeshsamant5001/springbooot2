package com.capgemini.admin.back.repository;

import com.capgemini.admin.back.model.GraphApiAccessCache;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GraphApiAccessCacheRepository extends JpaRepository<GraphApiAccessCache, Long> {

    Optional<GraphApiAccessCache> findByRoomEmail(String roomEmail);

}
