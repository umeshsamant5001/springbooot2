package com.capgemini.admin.utils;

/**
 * Interface for Function but with Exception
 */
@FunctionalInterface
public interface CheckedFunction<T, R> {
    R apply(T t); 
 }