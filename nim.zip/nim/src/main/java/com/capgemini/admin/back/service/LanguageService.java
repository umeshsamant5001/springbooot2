package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.Language;
import com.capgemini.admin.back.repository.LanguageRepository;

@Service
public class LanguageService {

    @Autowired
    LanguageRepository languageRepository;

    public List<Language> findAll() {
        return this.languageRepository.findAll();
    }

    public List<Language> findAllByLocale(List<String> locales) {
        if (locales.isEmpty()) {
            return new ArrayList<>();
        }

        return this.languageRepository.findAllByLocaleIn(locales);
    }
}
