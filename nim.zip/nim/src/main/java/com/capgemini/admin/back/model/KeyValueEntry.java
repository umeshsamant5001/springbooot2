package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class KeyValueEntry {
    private String key;
    private List<Double> values = new ArrayList<>();

    private int MAX_SIZE = 15;

    public KeyValueEntry(int duration) {
        MAX_SIZE = duration;
    }

    public void addValue(Double value) {
        // If the list has reached the maximum size, remove the oldest value (at index
        // 0)
        if (values.size() >= MAX_SIZE) {
            values.remove(0); // Remove the oldest value
        }
        values.add(value); // Add the new value at the end
    }

}
