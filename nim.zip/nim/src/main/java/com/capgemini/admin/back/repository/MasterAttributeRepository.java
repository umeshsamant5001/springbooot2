package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.MasterAttribute;

@Repository
public interface MasterAttributeRepository extends JpaRepository<MasterAttribute, String> {

    public List<MasterAttribute> findByMandatory(@Param("mandatory") Boolean mandatory);
}
