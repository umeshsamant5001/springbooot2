package com.capgemini.admin.back.controller;

import com.capgemini.admin.back.mapper.NotificationEmailMapper;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.NotificationEmail;
import com.capgemini.admin.back.model.NotificationEmailDTO;
import com.capgemini.admin.back.model.NotificationEmailSent;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.service.NotificationEmailService;
import lombok.extern.slf4j.Slf4j;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.List;
import java.util.Objects;

/**
 * Controller class for handling notification email-related endpoints.
 */
@Slf4j
@RestController
@RequestMapping(value = NotificationEmailController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class NotificationEmailController
        extends ScheduledController<NotificationEmail, NotificationEmailSent, NotificationEmailDTO> {

    static final String ROOT_API = "api/notificationEmail";

    @Autowired
    private NotificationEmailService notificationEmailService;

    /**
     * Retrieves a scheduled notification email by its ID.
     *
     * @param id The ID of the scheduled notification email.
     * @return The NotificationEmail object corresponding to the given ID.
     */
    @Override
    protected NotificationEmail getScheduledById(Long id, String language) {
        return this.notificationEmailService.getNotificationEmail(id);
    }

    /**
     * Deletes a scheduled notification email.
     *
     * @param notificationEmail The NotificationEmail to be deleted.
     */
    @Override
    protected void deleteScheduled(NotificationEmail notificationEmail) {
        this.notificationEmailService.delete(notificationEmail);
    }

    /**
     * Saves a scheduled notification email.
     *
     * @param notificationEmail The NotificationEmail to be saved.
     * @return The saved NotificationEmail object.
     */
    @Override
    protected NotificationEmail saveScheduled(NotificationEmail notificationEmail) {
        return this.notificationEmailService.save(notificationEmail);
    }

    /**
     * Updates a scheduled notification email with the provided data from the DTO.
     *
     * @param notificationEmail    The original NotificationEmail object to be
     *                             updated.
     * @param notificationEmailDTO The data from the DTO to update the
     *                             NotificationEmail.
     * @return The updated NotificationEmail object.
     */
    @Override
    protected NotificationEmail updateScheduled(NotificationEmail notificationEmail,
            NotificationEmailDTO notificationEmailDTO) {
        return this.notificationEmailService.update(notificationEmail, notificationEmailDTO);
    }

    /**
     * Maps a scheduled NotificationEmail object to its corresponding DTO.
     *
     * @param notificationEmail The NotificationEmail object to be mapped.
     * @return The mapped NotificationEmailDTO object.
     */
    @Override
    protected NotificationEmailDTO mapToDTO(NotificationEmail notificationEmail) {
        return NotificationEmailMapper.INSTANCE.NotificationEmailToNotificationEmailDTO(notificationEmail);
    }

    /**
     * Maps a NotificationEmailDTO object to its corresponding scheduled
     * NotificationEmail object.
     *
     * @param notificationEmailDTO The NotificationEmailDTO object to be mapped.
     * @return The mapped NotificationEmail object.
     */
    @Override
    protected NotificationEmail mapToBusiness(NotificationEmailDTO notificationEmailDTO) {
        return NotificationEmailMapper.INSTANCE.NotificationEmailDTOToNotificationEmail(notificationEmailDTO);
    }

    /**
     * Retrieves a list of notificationEmails based on optional filtering parameters
     * and
     * returns them as DTOs.
     *
     * @param priorityTypes The list of priority types for filtering notifications
     *                      (optional).
     * @param status        The list of status types for filtering notifications
     *                      (optional).
     * @return ResponseEntity containing a list of NotificationEmailDTOs matching
     *         the specified filters.
     */
    @GetMapping
    public ResponseEntity<List<NotificationEmailDTO>> getNotificationEmails(
            @RequestParam(required = false) List<EnumPriorityType> priorityTypes,
            @RequestParam(required = false) List<EnumStatusScheduled> status,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Create a list of priorities based on the input
        List<EnumPriorityType> priorityTypeList = Objects.isNull(priorityTypes)
                ? List.of(EnumPriorityType.LOW, EnumPriorityType.MEDIUM, EnumPriorityType.HIGH)
                : priorityTypes;

        // Create a list of status based on the input
        List<EnumStatusScheduled> statusList = Objects.isNull(status)
                ? List.of(EnumStatusScheduled.RUNNING, EnumStatusScheduled.STOPPED)
                : status;

        // Retrieve of notificationEmails based on the provided parameters
        List<NotificationEmail> notificationEmails = this.notificationEmailService
                .getNotificationEmails(priorityTypeList, statusList);
        // Convert the list of notificationEmails to a list of NotificationEmailDTOs
        List<NotificationEmailDTO> notificationEmailDTOs = this.notificationEmailService
                .listNotificationEmailToNotificationEmailDTOList()
                .apply(notificationEmails);

        return ResponseEntity.ok(notificationEmailDTOs);
    }

    /**
     * Handles the endpoint for sending notification emails.
     *
     * @param notificationEmailDTO The data object containing information for the
     *                             email, such as title, content, etc.
     * @param addresses            A list of email addresses to which the email will
     *                             be sent.
     * @return ResponseEntity indicating the success or failure of the email sending
     *         operation.
     */
    @PostMapping("/send")
    public ResponseEntity<Object> sendNotificationEmail(@RequestBody NotificationEmailDTO notificationEmailDTO,
            @RequestParam List<String> addresses) {
        if (CollectionUtils.isEmpty(addresses)) {
            return ResponseEntity.badRequest().build();
        }

        Boolean ok = this.notificationEmailService.sendMail(notificationEmailDTO, addresses);
        if (Boolean.TRUE.equals(ok)) {
            log.info("Email sent");
            return ResponseEntity.ok().build();
        } else {
            log.error("Error during sending");
            return ResponseEntity.internalServerError().build();
        }
    }

}