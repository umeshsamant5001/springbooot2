package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SiteMaintenanceDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    private String createdBy;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long createdDateTime;
    private Long startDateTime;
    private Long endDateTime;
    private Boolean isActive;
    private String message;
    private Platform platform;
}
