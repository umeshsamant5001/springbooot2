package com.capgemini.admin.back.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.springframework.context.ApplicationContext;

import com.capgemini.admin.back.helper.ApplicationContextProvider;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.CountryDTO;
import com.capgemini.admin.back.model.FloorDTO;
import com.capgemini.admin.back.model.PoiDTO;
import com.capgemini.admin.back.model.SiteDTO;
import com.capgemini.admin.back.model.WithCdmAttributesDTO;
import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.CountryService;
import com.capgemini.admin.back.service.FloorService;
import com.capgemini.admin.back.service.PoiService;
import com.capgemini.admin.back.service.SiteService;
import com.capgemini.admin.back.temporary.EnumCdmAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * Special Mapper class to manage the attributes on some Object.
 * From the Business object to the DTO, the attributes are distribute to two
 * list : one for cdm attributes, one for the non cdm.
 * From the DTO to the Business object, the cdm attributes are fetch from the
 * database and merge with the non cdm of the DTO.
 */
@Slf4j
@Named("CdmAttributesMapper")
@Mapper
public abstract class CdmAttributesMapper {

    private CountryService countryService;

    private SiteService siteService;

    private BuildingService buildingService;

    private FloorService floorService;

    private PoiService poiService;

    public CdmAttributesMapper() {
        // We can't use the spring annotation, so custom injection
        ApplicationContext context = ApplicationContextProvider.getApplicationContext();

        this.countryService = context.getBean(CountryService.class);
        this.siteService = context.getBean(SiteService.class);
        this.buildingService = context.getBean(BuildingService.class);
        this.floorService = context.getBean(FloorService.class);
        this.poiService = context.getBean(PoiService.class);
    }

    @Named("mapAttributesDTO")
    public Map<String, String> mapAttributesDTO(Map<String, String> attributes) {
        return attributes.entrySet()
                .stream()
                .filter(entry -> !this.isCdmAttributes(entry.getKey()))
                .collect(
                        HashMap::new,
                        (map, entry) -> map.put(entry.getKey(), entry.getValue()),
                        HashMap::putAll);
    }

    @Named("mapCdmAttributesDTO")
    public Map<String, String> mapCdmAttributesDTO(Map<String, String> attributes) {
        return attributes.entrySet()
                .stream()
                .filter(entry -> this.isCdmAttributes(entry.getKey()))
                .collect(
                        HashMap::new,
                        (map, entry) -> map.put(entry.getKey(), entry.getValue()),
                        HashMap::putAll);
    }

    @Named("mapAttributes")
    public Map<String, String> mapAttributes(WithCdmAttributesDTO in) {
        log.info("Start mapping");
        if (in.getAttributes() == null) {
            // Null signals "do not update attributes" — propagate null so callers can detect it.
            return null;
        }
        try {
            Map<String, String> attributes = new HashMap<>();
            attributes.putAll(in.getAttributes());

            if (Objects.nonNull(in.getId())) {
                Map<String, String> savedAttributes = Map.of();

                if (in instanceof CountryDTO) {
                    log.info("is CountryDTO");
                    savedAttributes = this.countryService.getAttributesById(in.getId());
                } else if (in instanceof SiteDTO) {
                    log.info("is SiteDTO");
                    savedAttributes = this.siteService.getAttributesById(in.getId());
                } else if (in instanceof BuildingDTO) {
                    log.info("is BuildingDTO");
                    savedAttributes = this.buildingService.getAttributesById(in.getId());
                } else if (in instanceof FloorDTO) {
                    log.info("is FloorDTO");
                    savedAttributes = this.floorService.getAttributesById(in.getId());
                } else if (in instanceof PoiDTO) {
                    log.info("is PoiDTO");
                    savedAttributes = this.poiService.getAttributesById(in.getId());
                } else {
                    log.info("is Unknown");
                }
                String safeSavedAttributes = new String(String.valueOf(savedAttributes)
                        .replaceAll("[\\r\\n\\t]", "_")
                        .replaceAll("[^\\x20-\\x7E]", ""));
                log.info("Saved attributes = {}", safeSavedAttributes);

                savedAttributes.entrySet()
                        .stream()
                        .filter(entry -> this.isCdmAttributes(entry.getKey()))
                        .forEach(entry -> {
                            attributes.put(
                                    entry.getKey(),
                                    entry.getValue());
                        });
            }

            log.info("End mapping sucess");
            return attributes;
        } catch (Exception e) {
            log.error("Error while mapping attributes", e);

            throw e;
        }
    }

    private boolean isCdmAttributes(String key) {
        return List.of(EnumCdmAttributes.values())
                .stream()
                .anyMatch(enumValue -> enumValue.toString().equals(key));
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }


    @Named("mapUpdatedAttributes")
    public Map<String, String> mapUpdatedAttributes(WithCdmAttributesDTO in) {
        String safeAttributes = sanitizeForLog(String.valueOf(in.getAttributes()));
        log.info("Mapping attributes: {}", safeAttributes);
        return in.getAttributes();
    }


    @Named("mapUpdatedCdmAttributes")
    public Map<String, String> mapUpdatedCdmAttributes(WithCdmAttributesDTO in) {
        log.info("Fetching attributes for ID: {}", in.getId());
        Map<String, String> updatedAttributes = poiService.getAttributesById(in.getId());

        updatedAttributes.entrySet().stream()
                .filter(entry -> isCdmAttributes(entry.getKey()))
                .forEach(entry -> updatedAttributes.put(entry.getKey(), entry.getValue()));

        String safeUpdatedAttributes = sanitizeForLog(String.valueOf(updatedAttributes));
        log.info("Filtered CDM attributes: {}", safeUpdatedAttributes);
        return updatedAttributes;
    }


}
