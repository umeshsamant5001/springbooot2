package com.capgemini.admin.back.model;

public enum EnumControlType {
    INPUT,
    TEXTAREA,
    SELECT,
    MULTI_SELECT,
    RADIO,
    CHECKBOX,
    TOGGLE_TEXT
}
