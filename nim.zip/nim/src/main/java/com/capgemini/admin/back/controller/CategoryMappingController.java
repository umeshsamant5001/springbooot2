package com.capgemini.admin.back.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.repository.CategoryMappingRepository;

@RestController
@RequestMapping("/api/category")
public class CategoryMappingController {

    private final CategoryMappingRepository categoryMappingRepository;

    public CategoryMappingController(CategoryMappingRepository categoryMappingRepository) {
        this.categoryMappingRepository = categoryMappingRepository;
    }

    /**
     * Retrieves a list of all distinct category mappings.
     *
     * @return a ResponseEntity containing a list of unique category names.
     */
    @GetMapping
    public ResponseEntity<List<String>> getAllCategoryMappings() {
        List<String> categoryMappings = categoryMappingRepository.findDistinctCategories();
        return ResponseEntity.ok(categoryMappings);
    }
}
