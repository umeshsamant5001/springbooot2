package com.capgemini.admin.back.model.procedure;

import lombok.Data;

@Data
public class TranslationEntityDTO {
    public TranslationEntityDTO(String lnEntity) {
        this.lnEntity = lnEntity;
    }

    private String lnEntity;
}