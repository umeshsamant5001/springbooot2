package com.capgemini.admin.back.model;

public enum EnumOrderBy {
    ASC, DESC;
}
