package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AuditLoggingDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    private String username;
    private String moduleName;
    private String activity;
    private String previousData;
    private String currentData;
    private Long activityDate;
    private String platform;
    private EnumAuditType auditType;
    private String country;
}