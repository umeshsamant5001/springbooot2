package com.capgemini.admin.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class SiteDTO implements WithTitleDTO, WithCdmAttributesDTO {
    private Long id;
    private CityDTO city;
    private Long cityId;
    private Long modifiedAt;
    private Long cdmKeyId;
    private List<BuildingDTO> buildings;
    private String titleFr;
    private String titleEn;
    private String title;
    private Map<String, String> attributes = new HashMap<String, String>();
    private Map<String, String> cdmAttributes = new HashMap<String, String>();
    private Long nbChilds;
}
