package com.capgemini.admin.back.scheduled.scheduled;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SensorAlertJob {

    public void execJob() {
        try {
        } catch (Exception e) {
            log.error("An error occurred while using sensor alert job", e);
        }

    }

}
