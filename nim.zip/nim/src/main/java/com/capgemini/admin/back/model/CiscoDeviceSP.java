package com.capgemini.admin.back.model;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "SO_GetCiscoDeviceInfo")
public class CiscoDeviceSP {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rowId;
    @Column(name = "mac_address")
    private String deviceId;
    @Column(name = "name")
    private String poiName;
    @Column(name = "title_en")
    private String poiTitle;
    @Column(name = "device_type")
    private String deviceType;
    @Column(name = "space_type_name")
    private String poiType;
    @Column(name = "hour", nullable = false)
    private LocalDateTime lastDataReceived;
    @Column(name = "ip_address")
    private String ipAddress;
    @Column(name = "people_count")
    private Integer peopleCount;
    @Column(name = "ambient_noise_dBA")
    private Double ambientNoiseDba;
    @Column(name = "sound_level_dBA")
    private Double soundLevelDba;
    @Column(name = "ambient_temperature")
    private Double ambientTemperature;
    @Column(name = "relative_humidity")
    private Double relativeHumidity;
    @Column(name = "air_quality")
    private Double airQuality;
}
