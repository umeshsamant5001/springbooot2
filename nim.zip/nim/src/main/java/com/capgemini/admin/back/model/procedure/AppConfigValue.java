package com.capgemini.admin.back.model.procedure;

import lombok.Data;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "app_config_values")
public class AppConfigValue {

    @Id
    @Column(name = "config_key")
    private String configKey;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "type")
    private String type;

    @Column(name = "value")
    private String value;

    @Column(name = "last_change")
    private Long lastChange;

}