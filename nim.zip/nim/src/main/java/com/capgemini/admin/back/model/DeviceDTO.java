package com.capgemini.admin.back.model;

import java.util.Map;

import lombok.Data;

@Data
public class DeviceDTO {
	private String uuid;
	private String poiName;
	private Map<String, String> attributes;
	private Long lastChange;
	private Long lastStatusChange;
	private EnumDeviceStatus status;
	private EnumDeviceType deviceType;
	private FloorDTO floor;
	private String poiTitle;
	private PoiGroupDTO poiGroupDTO; // poiType
	private SpaceTypeDTO spaceTypeDTO;
	private Boolean underMaintenance;
}
