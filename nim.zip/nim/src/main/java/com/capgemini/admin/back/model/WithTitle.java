package com.capgemini.admin.back.model;

public interface WithTitle {
    String getTitleFr();

    String getTitleEn();
}
