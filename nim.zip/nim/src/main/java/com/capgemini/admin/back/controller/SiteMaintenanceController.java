package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.SiteMaintenanceMapper;
import com.capgemini.admin.back.model.Platform;
import com.capgemini.admin.back.model.SiteMaintenance;
import com.capgemini.admin.back.model.SiteMaintenanceDTO;
import com.capgemini.admin.back.service.SiteMaintenanceService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(value = SiteMaintenanceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class SiteMaintenanceController {

    public static final String ROOT_API = "api/maintenance";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class SiteMaintenanceWriteInput {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String createdBy;

        @Min(0)
        private Long startDateTime;

        @Min(0)
        private Long endDateTime;

        @NotNull
        private Boolean isActive;

        @Size(max = 10000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String message;

        @NotNull
        private Platform platform;
    }

    @Autowired
    private SiteMaintenanceService siteMaintenanceService;


    @PostMapping
    public ResponseEntity<SiteMaintenanceDTO> createSiteMaintenance(
            @Valid @RequestBody SiteMaintenanceWriteInput siteMaintenanceInput) {

        SiteMaintenance siteMaintenance = new SiteMaintenance();
        siteMaintenance.setId(null);
        siteMaintenance.setCreatedBy(siteMaintenanceInput.getCreatedBy() == null
                ? null
                : String.valueOf(siteMaintenanceInput.getCreatedBy()));
        siteMaintenance.setStartDateTime(siteMaintenanceInput.getStartDateTime() == null
                ? null
                : Long.valueOf(siteMaintenanceInput.getStartDateTime()));
        siteMaintenance.setEndDateTime(siteMaintenanceInput.getEndDateTime() == null
                ? null
                : Long.valueOf(siteMaintenanceInput.getEndDateTime()));
        siteMaintenance.setIsActive(siteMaintenanceInput.getIsActive() == null
                ? null
                : Boolean.valueOf(siteMaintenanceInput.getIsActive()));
        siteMaintenance.setMessage(siteMaintenanceInput.getMessage() == null
                ? null
                : String.valueOf(siteMaintenanceInput.getMessage()));
        siteMaintenance.setPlatform(siteMaintenanceInput.getPlatform() == null
                ? null
                : Platform.valueOf(String.valueOf(siteMaintenanceInput.getPlatform().name())));
        siteMaintenance.setCreatedDateTime((new Date()).getTime() / 1000);


        try {
            SiteMaintenance saveSiteMaintenance = siteMaintenanceService.createSiteMaintenance(siteMaintenance);
            SiteMaintenanceDTO responseDTO = SiteMaintenanceMapper.INSTANCE
                    .siteMaintenanceToSiteMaintenanceDTO(saveSiteMaintenance);
            return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<SiteMaintenanceDTO> updateSiteMaintenance(
            @Valid @RequestBody SiteMaintenanceWriteInput siteMaintenanceInput,
            @PathVariable Long id) {
        try {
            // Copy only allowed request fields using value-creating calls
            SiteMaintenance siteMaintenance = new SiteMaintenance();
            siteMaintenance.setId(null);
            siteMaintenance.setCreatedBy(siteMaintenanceInput.getCreatedBy() == null
                    ? null
                    : String.valueOf(siteMaintenanceInput.getCreatedBy()));
            siteMaintenance.setStartDateTime(siteMaintenanceInput.getStartDateTime() == null
                    ? null
                    : Long.valueOf(siteMaintenanceInput.getStartDateTime()));
            siteMaintenance.setEndDateTime(siteMaintenanceInput.getEndDateTime() == null
                    ? null
                    : Long.valueOf(siteMaintenanceInput.getEndDateTime()));
            siteMaintenance.setIsActive(siteMaintenanceInput.getIsActive() == null
                    ? null
                    : Boolean.valueOf(siteMaintenanceInput.getIsActive()));
            siteMaintenance.setMessage(siteMaintenanceInput.getMessage() == null
                    ? null
                    : String.valueOf(siteMaintenanceInput.getMessage()));
            siteMaintenance.setPlatform(siteMaintenanceInput.getPlatform() == null
                    ? null
                    : Platform.valueOf(String.valueOf(siteMaintenanceInput.getPlatform().name())));

            // Call the service to perform the update
            SiteMaintenance updatedSiteMaintenance = this.siteMaintenanceService.updateSiteMaintenance(siteMaintenance,
                    id);


            // Convert updated entity back to DTO
            SiteMaintenanceDTO siteMaintenanceDTOResponse = SiteMaintenanceMapper.INSTANCE
                    .siteMaintenanceToSiteMaintenanceDTO(updatedSiteMaintenance);

            return ResponseEntity.ok(siteMaintenanceDTOResponse);
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null); // Optionally use a custom error DTO
        }
    }

    @GetMapping
    public ResponseEntity<List<SiteMaintenanceDTO>> getAllSiteMaintenance() {
        log.info("Fetching site maintenance for all platform");
        // Call the service to get all the records
        List<SiteMaintenanceDTO> siteMaintenanceDTOs = this.siteMaintenanceService.getAllSiteMaintenance();
        return ResponseEntity.ok(siteMaintenanceDTOs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SiteMaintenanceDTO> getByIdSiteMaintenance(@PathVariable Long id) {

        // Call the service to get the record by id
        SiteMaintenance siteMaintenance = this.siteMaintenanceService.getByIdSiteMaintenance(id);

        // Convert updated entity back to DTO
        SiteMaintenanceDTO siteMaintenanceDTOResponse = SiteMaintenanceMapper.INSTANCE
                .siteMaintenanceToSiteMaintenanceDTO(siteMaintenance);

        return ResponseEntity.ok(siteMaintenanceDTOResponse);
    }

}
