package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.NotificationSent;

@Repository
public interface NotificationSentRepository extends JpaRepository<NotificationSent, Long> {

    /**
     * Return the last notificationSent for all the "running" notification
     * 
     * @return
     */
    @Query(value = "SELECT notification_sent.* FROM notification_sent INNER JOIN ( "
            + " SELECT notification_sent.notification_id AS notification_id, MAX(notification_sent.sent_at) AS sent_at "
            + " FROM notification_sent INNER JOIN notification ON (notification_sent.notification_id = notification.id) "
            + " WHERE notification.status = 'RUNNING' GROUP BY notification_sent.notification_id ) AS tmp "
            + " ON (notification_sent.notification_id = tmp.notification_id AND notification_sent.sent_at = tmp.sent_at) ", nativeQuery = true)
    List<NotificationSent> findAllLast();

    @Modifying
    @Query(value = "UPDATE notification_sent SET sent_at = NULL WHERE notification_id =:notificationId ", nativeQuery = true)
    void update(@Param("notificationId") Long notificationId);

}