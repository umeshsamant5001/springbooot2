package com.capgemini.admin.back.model;

import lombok.Data;
import java.util.List;

@Data
public class RoleLocationDTO {
    private RoleDTO role;
    private List<LocationDTO> locations;
}