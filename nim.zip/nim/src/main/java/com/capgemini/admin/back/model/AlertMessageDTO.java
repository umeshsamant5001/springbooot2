package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class AlertMessageDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long modifiedAt;

    private Long spaceTypeId;
    private String spaceTypeName;
    private ThresholdType thresholdType;
    private AlertType alertCategory;
    private String title;
    private String message;
    private List<AlertMessageLocationDTO> alertMessageLocations = new ArrayList<>();
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long alertSentAt;

}
