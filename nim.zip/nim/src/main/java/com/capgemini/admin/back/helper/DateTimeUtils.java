package com.capgemini.admin.back.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.Collectors;

import net.iakovlev.timeshape.TimeZoneEngine;

public class DateTimeUtils {
	public static final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();
	private static final TimeZoneEngine ENGINE = TimeZoneEngine.initialize();
	private static final Map<String, String> ZONE_TO_WINDOWS_ZONE;

	static {
		// Map has been initialized with a parsed version
		// of XML content found at this url :
		// http://unicode.org/repos/cldr/trunk/common/supplemental/windowsZones.xml
		// 1. looking for <mapZone with notepad then copy search result
		// 2. replace with REGEX
		// \tLine.*mapZone.*other="(.*)" terr.*type="(.*)"/>
		// with \2\t\1
		Map<String, String> map = new HashMap<String, String>();
		try (InputStream resource = DateTimeUtils.class.getResourceAsStream("/timezones.txt")) {
			List<String> timezones = new BufferedReader(new InputStreamReader(resource, StandardCharsets.UTF_8)).lines()
					.collect(Collectors.toList());
			for (String timezone : timezones) {
				// every line is made of
				String[] split = timezone.split("\t");
				if (split.length == 2) {
					// we have a good timzeone association that we can parse
					String[] zones = split[0].split(" ");
					String windowsZone = split[1];
					for (String zone : zones) {
						map.put(zone, windowsZone);
					}
				}
			}
		} catch (IOException e) {

		}
		ZONE_TO_WINDOWS_ZONE = Collections.unmodifiableMap(map);
	}

	/**
	 * Retrieve the Java ZoneId for a given latitude and longitude
	 *
	 * @param latitude
	 * @param longitude
	 * @return
	 */

	public static ZoneId getZone(Double latitude, Double longitude) {
		return ENGINE.query(latitude, longitude % 360 > 180 ? longitude - 360 : longitude % 360).orElse(UTC_ZONE_ID);
	}

	/**
	 * Retrieve the Java ZoneId for a given geometry
	 *
	 * @param geometry
	 * @return
	 *//*
		 * public static ZoneId getZone(Geometry geometry) {
		 * if (geometry != null && !geometry.isEmpty() && geometry.get(0).get(0) !=
		 * null) {
		 * Location location = geometry.get(0).get(0);
		 * if (location.getLatitude() != null && location.getLongitude() != null)
		 * return DateTimeUtils.getZone(location.getLatitude(),
		 * location.getLongitude());
		 * }
		 * return null;
		 * }
		 */

	/**
	 * Get date in UTC (no offset)
	 *
	 * @param timestampSeconds
	 * @return
	 */
	public static LocalDateTime getUTCDateTime(long timestampSeconds) {
		return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), UTC_ZONE_ID);
	}

	/**
	 * Add zone in the DateTime (not performing an offset addition, just add the
	 * timezone next to the date)
	 *
	 * @param timestampSeconds
	 * @param zone
	 * @return
	 */
	public static ZonedDateTime getZonedDateTime(long timestampSeconds, ZoneId zone) {
		if (zone == null)
			return getZonedDateTime(timestampSeconds, UTC_ZONE_ID);
		return getUTCDateTime(timestampSeconds).atZone(zone);
	}

	

	/**
	 * Add the offset regarding the zone on the provided timestamp
	 *
	 * @param timestampSeconds
	 * @param zone
	 * @return
	 *//*
		 * public static String getFormattedDateWithLocalOffset(Long timestampSeconds,
		 * Building building) {
		 * String zone = UTC_ZONE_ID.getId();
		 * if (building != null) {
		 * if (building.getTimezoneJava() != null)
		 * zone = building.getTimezoneJava();
		 * else if (building.hasCoordinates()) {
		 * ZoneId zoneId =
		 * getZone(Double.parseDouble(building.getAttributes().get("lat")),
		 * Double.parseDouble(building.getAttributes().get("lon")));
		 * if (zoneId != null)
		 * zone = zoneId.getId();
		 * }
		 * }
		 * return getFormattedDateWithLocalOffset(timestampSeconds, zone);
		 * }
		 */

	/**
	 * Retrieve equivalent Windows Timezone from Java ZoneId Used for PowerBI
	 * historization
	 *
	 * @param zone
	 * @return
	 */
	public static String getWindowsTimezoneFromZoneId(ZoneId zone) {
		if (zone == null) {
			return "UTC";
		}

		String windowsZone = ZONE_TO_WINDOWS_ZONE.get(zone.getId());
		if (windowsZone == null)
			return "UTC";
		return windowsZone;
	}
}
