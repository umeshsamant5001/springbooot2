package com.capgemini.admin.back.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.UniqueConstraint;
import javax.persistence.SequenceGenerator;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Enumerated;
import javax.persistence.EnumType;
import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * Entity class representing a feature(mapping between role and frontPage) in
 * the application.
 */
@Data
@Entity
@Table(name = "feature_access", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class FeatureAccess {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FeatureAccess_Generator")
    @SequenceGenerator(name = "FeatureAccess_Generator", sequenceName = "FeatureAccess_Sequence", allocationSize = 1)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "frontPage_id", referencedColumnName = "id")
    private FrontPage frontPage;

    @Column(name = "access")
    @Enumerated(EnumType.STRING)
    private EnumAccess access;

    @Column(name = "is_active")
    private Boolean isActive;

}
