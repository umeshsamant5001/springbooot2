package com.capgemini.admin.back.scheduled;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationSent;
import com.capgemini.admin.back.service.NotificationSentDetailsService;

import com.capgemini.admin.back.service.NotificationSentService;
import com.capgemini.admin.back.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

import com.capgemini.admin.back.config.Constants;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
@Slf4j
public class NotificationJobTest extends ScheduledJob<Notification, NotificationSent> {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private NotificationSentService notificationSentService;

    @Autowired
    private NotificationSentDetailsService notificationSentDetailsService;
    // ✅ Prevent parallel execution
    private static final AtomicBoolean running = new AtomicBoolean(false);

    // @Scheduled(
    //     cron = "${" + Constants.CONFIG_PATH_NOTIFICATION + ".cron}",
    //     zone = "${" + Constants.CONFIG_PATH_NOTIFICATION + ".tz}"
    // )
       @SchedulerLock(
        name = "notificationJobLock",
        lockAtLeastFor = "PT50S",  // prevent rapid re-trigger
        lockAtMostFor = "PT5M"     // safety timeout
    )
    public void execJob() {

        String jobName = "NotificationJobTest";

        // LOCK
        if (!running.compareAndSet(false, true)) {
            log.warn(">>> [{}] already running → skipping | Thread={}",
                    jobName, Thread.currentThread().getName());
            return;
        }

        log.info(">>> [{}] START | Thread={}", jobName, Thread.currentThread().getName());

        try {
            super.execJob(new Date());
        } catch (Exception e) {
            log.error("[{}] ERROR", jobName, e);
        } finally {
            running.set(false);
            log.info("<<< [{}] END | Thread={}", jobName, Thread.currentThread().getName());
        }
    }

    @Override
    protected List<Notification> getScheduledRunning() {
        return this.notificationService.findAllRunning();
    }

    @Override
    protected List<NotificationSent> getLastScheduledSent() {
        return this.notificationSentService.findAllLast();
    }

    @Override
    protected boolean sendScheduled(Notification notification) {
        try {
            log.info("[NotificationJob] Sending notification ID={} | Thread={}",
                    notification.getId(), Thread.currentThread().getName());

            return this.notificationService.sendNotification(notification);

        } catch (Exception e) {
            log.error("Error in Notification scheduler", e);
            return false;
        }
    }

    @Override
    protected NotificationSent getNewScheduledSent() {
        return new NotificationSent();
    }

    @Override
    protected void saveScheduledSent(NotificationSent notificationSent) {
        this.notificationSentService.save(notificationSent);
    }

    @Override
    protected void stopScheduled(Notification notification) {
        this.notificationService.stop(notification);
    }

    @Override
    protected void endJob(List<Notification> scheduledList) {

        this.notificationService.setProcessed(scheduledList);

        // ✅ CLEANUP SUCCESS LOGS
        for (Notification notification : scheduledList) {
            notificationSentDetailsService.cleanupSuccess(notification.getId());
        }
    }
}
