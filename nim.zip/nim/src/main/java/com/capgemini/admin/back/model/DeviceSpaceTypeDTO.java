package com.capgemini.admin.back.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceSpaceTypeDTO {

    private String uuid;
    private EnumDeviceType deviceType;
    private Long lastChange;
    private String poiName;
    private EnumDeviceStatus status;
    private Long floorId;
    private Long lastStatusChange;
    private Long poiId;
}
