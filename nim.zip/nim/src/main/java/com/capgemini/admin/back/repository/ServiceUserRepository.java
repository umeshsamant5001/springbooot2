package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.ServiceUser;
import com.capgemini.admin.back.model.ServiceUserId;
import java.util.List;

@Repository
public interface ServiceUserRepository extends JpaRepository<ServiceUser, ServiceUserId> {

    List<ServiceUser> findByServiceId(@Param("serviceId") Long serviceId);

}