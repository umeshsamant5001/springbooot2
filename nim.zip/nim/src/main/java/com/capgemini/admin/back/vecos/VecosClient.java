package com.capgemini.admin.back.vecos;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.model.CountryTenant;
import com.capgemini.admin.back.model.VecosLockerBank;
import com.capgemini.admin.back.model.VecosSession;
import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.CountryTenantService;
import com.capgemini.admin.back.service.VecosSessionService;
import io.jsonwebtoken.io.Decoders;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.http.HttpRequest;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class VecosClient {

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private VecosSessionService sessionService;

    @Autowired
    private VecosRequestFactory factory;

    @Autowired
    private VecosResponseParser resParser;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private CountryTenantService countryTenantService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Authenticates a tenant with the Vecos system using credentials stored in
     * configuration.
     * Retrieves configuration values, decodes the password, prepares request
     * parameters and headers,
     * and initiates a session via the session service.
     *
     * @param tenant The tenant identifier used to fetch configuration and
     *               authenticate.
     * @return A {@link VecosSession} object representing the authenticated session.
     */
    private VecosSession authenticate(String tenant) {
        log.info("Authenticating tenant: {}", tenant);

        CountryTenant countryTenant = countryTenantService.findByTenannt(tenant);
        if (countryTenant == null) {
            log.error("Tenant {} not found in country_tenant table. Aborting request.", tenant);
            sessionService.clearSession(tenant);
            return null;
        }

        String userName = countryTenant.getUsername();
        char[] encodedPasswordChars = countryTenant.getPassword().toCharArray();
        String basic = countryTenant.getBasic();

        if (userName.isBlank() || encodedPasswordChars.length == 0 || basic.isBlank()) {
            log.error("Bad vecos configuration for tenant: {}", tenant);
            sessionService.clearSession(tenant);
            return null;
        }

        char[] decodedPassword = new char[0];
        byte[] decodedPasswordBytes = null;
        try {
            decodedPasswordBytes = Decoders.BASE64.decode(new String(encodedPasswordChars));
            decodedPassword = new String(decodedPasswordBytes, StandardCharsets.UTF_8).toCharArray();
        } catch (IllegalArgumentException e) {
            log.error("Failed to decode password for tenant: {}", tenant, e);
            sessionService.clearSession(tenant);
            return null;
        }

        List<NameValuePair> params = List.of(
                new BasicNameValuePair("username", userName),
                new BasicNameValuePair("password", String.valueOf(decodedPassword)),
                new BasicNameValuePair("grant_type", VecosConstants.GRANT_TYPE),
                new BasicNameValuePair("scope", applicationProperties.getVecos().getScope()));
        Map<String, String> headers = Map.of(AUTHORIZATION_HEADER, basic);
        try {
            VecosSession session = factory.postFormUrlEncoded(
                    getIdentityUri(), headers, params, resParser::readAuthenticateRes);
            if (session == null || session.getAccessToken() == null || session.getAccessToken().isBlank()) {
                log.error("Vecos authentication returned no access token for tenant: {}", tenant);
                sessionService.clearSession(tenant);
                return null;
            }
            sessionService.setSession(tenant, session);
            log.info("Vecos authentication successful for tenant: {}", tenant);
        } catch (Exception e) {
            log.error("Vecos authentication failed for tenant: {}", tenant, e);
            sessionService.clearSession(tenant);
            return null;
        } finally {
            Arrays.fill(decodedPassword, '\0');
            Arrays.fill(encodedPasswordChars, '\0');
            if (decodedPasswordBytes != null) {
                Arrays.fill(decodedPasswordBytes, (byte) 0);
            }
        }

        return sessionService.getSession(tenant);
    }

    /**
     * Checks whether a tenant is currently authenticated by verifying if a session
     * exists.
     * 
     * @param tenant The tenant identifier whose authentication status is to be
     *               checked.
     * @return {@code true} if a session exists for the tenant, indicating
     *         authentication;
     *         {@code false} otherwise.
     */
    private boolean isAuthenticated(String tenant) {
        VecosSession session = this.sessionService.getSession(tenant);
        return session != null && session.getAccessToken() != null && !session.getAccessToken().isBlank();
    }

    private VecosSession ensureAuthenticated(String tenant, boolean forceRefresh) {
        if (forceRefresh) {
            sessionService.clearSession(tenant);
        }
        if (!isAuthenticated(tenant)) {
            return authenticate(tenant);
        }
        return sessionService.getSession(tenant);
    }

    private Map<String, String> buildAuthenticatedHeaders(String tenant, boolean forceRefresh) {
        VecosSession session = ensureAuthenticated(tenant, forceRefresh);
        if (session == null) {
            return Collections.emptyMap();
        }
        return Map.of(AUTHORIZATION_HEADER, BEARER_PREFIX + session.getAccessToken());
    }

    private boolean shouldRefreshSession(HttpResponse<String> response) {
        if (response == null) {
            return true;
        }
        int statusCode = response.statusCode();
        return statusCode == 401 || statusCode == 403;
    }

    private boolean isSuccessful(HttpResponse<String> response) {
        return response != null && response.statusCode() >= 200 && response.statusCode() < 300;
    }

    protected HttpResponse<String> sendGetRequest(String uri, Map<String, String> headers) {
        HttpRequest.Builder builder = HttpRequest.newBuilder().uri(URI.create(uri)).GET();
        headers.forEach(builder::header);
        HttpRequest request = builder.build();
        HttpClient httpClient = HttpClient.newHttpClient();
        try {
            return httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            log.error("Interrupted while calling Vecos URI [{}]", uri, interruptedException);
            return null;
        } catch (IOException ioException) {
            log.error("I/O failure while calling Vecos URI [{}]", uri, ioException);
            return null;
        }
    }

    private JsonNode parseJsonResponse(HttpResponse<String> response, String apiName) {
        if (!isSuccessful(response)) {
            log.warn("Vecos {} request failed with status {} and body {}",
                    apiName,
                    response == null ? "n/a" : response.statusCode(),
                    response == null ? "" : response.body());
            return null;
        }
        try {
            return objectMapper.readTree(response.body());
        } catch (UnsupportedOperationException | IOException e) {
            log.error("Failed to parse Vecos {} response body", apiName, e);
            return null;
        }
    }

    private JsonNode fetchJsonWithRetry(String uri, String lockerTenant, String apiName) {
        HttpResponse<String> response = sendGetRequest(uri, buildAuthenticatedHeaders(lockerTenant, false));
        if (shouldRefreshSession(response)) {
            log.warn("Vecos {} request for tenant {} requires session refresh. Status: {}",
                    apiName,
                    lockerTenant,
                    response == null ? "n/a" : response.statusCode());
            response = sendGetRequest(uri, buildAuthenticatedHeaders(lockerTenant, true));
        }
        return parseJsonResponse(response, apiName);
    }

    private VecosLockerBank fetchLockerBankStatusWithRetry(String endpoint, String lockerTenant) {
        VecosLockerBank lockerBank = factory.get(
                endpoint,
                buildAuthenticatedHeaders(lockerTenant, false),
                Collections.emptyMap(),
                resParser::readVecosLockerBankStatus);
        if (lockerBank == null) {
            log.warn("Vecos locker status request returned empty response for tenant {} and bank {}. Retrying after re-authentication.",
                    lockerTenant,
                    endpoint);
            lockerBank = factory.get(
                    endpoint,
                    buildAuthenticatedHeaders(lockerTenant, true),
                    Collections.emptyMap(),
                    resParser::readVecosLockerBankStatus);
        }
        return lockerBank;
    }

    /**
     * Get the URL for the authentication
     * 
     * @return identity url for Vecos
     */
    private String getIdentityUri() {
        return this.applicationProperties.getVecos().getIdentity().getUrl() + VecosConstants.LOGIN_ENDPOINT;
    }

    /**
     * Get the URL for the API
     * 
     * @param endpoint The endpoint to apply
     * @return API url
     */
    private String getSapiUri(String endpoint) {
        return this.applicationProperties.getVecos().getSapi().getUrl() + endpoint;
    }

    // For 1601773
    /**
     * Retrieves the locker bank ID based on the provided locker bank name.
     * It searches through location, section, and locker bank data to find a match.
     * 
     * @param lockerBankNameValue the name of the locker bank to search for
     * @param lockerTenant        the name of the locker tenant
     */
    // public void retrieveBankIdFromBankNameOld(String lockerBankNameValue,String
    // lockerTenant) {
    // PoiGroup lockerGroup =
    // poiGroupService.getByName(VecosConstants.POI_GROUP_LOCKER_NAME);
    // List<String> lockerLocations = buildingService.getBuildingLocations();
    // Map<String, String> locationIdMap =
    // fetchLocationIds(lockerLocations,lockerTenant);
    // if(!locationIdMap.isEmpty()) {
    // outerLoop:
    // for (String locationId : locationIdMap.values()) {
    // List<String> sectionIds = fetchSectionIds(locationId,lockerTenant);
    // if(!sectionIds.isEmpty()) {
    // for (String sectionId : sectionIds) {
    // Map<String, String> lockerBanks = fetchLockerBanks(sectionId,lockerTenant);
    // if(!lockerBanks.isEmpty()) {
    // for (Map.Entry<String, String> entry : lockerBanks.entrySet()) {
    // if(Objects.nonNull(lockerBankNameValue) && Objects.nonNull(entry.getValue())
    // &&
    // lockerBankNameValue.trim().equalsIgnoreCase(entry.getValue().trim())) {

    // //saveLockerBankId(entry.getValue(), entry.getKey(), lockerGroup.getId());
    // break outerLoop;
    // }
    // }
    // }
    // }
    // }
    // }
    // }
    // }

    /**
     * Retrieves the locker bank ID based on the provided locker bank name.
     * It searches through location, section, and locker bank data to find a match.
     * 
     * @param lockerBankNameValue the name of the locker bank to search for
     * @param lockerTenant        the name of the locker tenant
     */
    public String retrieveBankIdFromBankName(String lockerBankNameValue, String lockerTenant) {
        List<String> lockerLocations = buildingService.getBuildingLocations();
        Map<String, String> locationIdMap = fetchLocationIds(lockerLocations, lockerTenant);
        String lockerBankId = null;
        if (!locationIdMap.isEmpty()) {
            outerLoop: for (String locationId : locationIdMap.values()) {
                List<String> sectionIds = fetchSectionIds(locationId, lockerTenant);
                if (!sectionIds.isEmpty()) {
                    for (String sectionId : sectionIds) {
                        Map<String, String> lockerBanks = fetchLockerBanks(sectionId, lockerTenant);
                        if (!lockerBanks.isEmpty()) {
                            for (Map.Entry<String, String> entry : lockerBanks.entrySet()) {
                                if (Objects.nonNull(lockerBankNameValue) && Objects.nonNull(entry.getValue()) &&
                                        lockerBankNameValue.trim().equalsIgnoreCase(entry.getValue().trim())) {
                                    lockerBankId = entry.getKey();
                                    break outerLoop;
                                }
                            }
                        }
                    }
                }
            }
        }
        return lockerBankId;
    }

    /**
     * Fetches location IDs from the Vecos API for the given locker locations and
     * tenant.
     * This method ensures authentication, sends an HTTP GET request to the Vecos
     * endpoint,
     * parses the JSON response, and returns a map of location names to their
     * corresponding IDs.
     * 
     * @param lockerLocations List of locker location names to filter from the
     *                        response
     * @param lockerTenant    The tenant identifier used for authentication and API
     *                        access
     * @return Map of location names to their corresponding location IDs
     */
    private Map<String, String> fetchLocationIds(List<String> lockerLocations, String lockerTenant) {
        String uri = getSapiUri(VecosConstants.VECOS_LOCATION_ENDPOINT);
        JsonNode root = fetchJsonWithRetry(uri, lockerTenant, "fetchLocationIds");
        if (root == null) {
            return Collections.emptyMap();
        }
        Map<String, String> result = new HashMap<>();
        JsonNode locations = root.get("Locations");

        if (locations != null && locations.isArray()) {
            for (JsonNode loc : locations) {
                String id = loc.has("Id") ? loc.get("Id").asText() : null;
                String name = loc.has("Name") ? loc.get("Name").asText() : null;

                if (lockerLocations.contains(name)) {
                    result.put(name, id);
                }
            }
        }
        return result;
    }
 

    /**
     * Fetches section IDs for a given location from the Vecos API.
     * This method ensures the tenant is authenticated, sends an HTTP GET request to
     * the
     * location-specific section endpoint, parses the JSON response, and returns a
     * list of section IDs.
     *
     * @param locationId   The ID of the location for which sections are to be
     *                     fetched
     * @param lockerTenant The tenant identifier used for authentication and API
     *                     access
     * @return List of section IDs associated with the given location
     */
    private List<String> fetchSectionIds(String locationId, String lockerTenant) {
        JsonNode root = fetchJsonWithRetry(
                getSapiUri(VecosConstants.VECOS_LOCATION_ENDPOINT + "/" + locationId + VecosConstants.VECOS_SECTION_ENDPOINT),
                lockerTenant,
                "fetchSectionIds");
        if (root == null) {
            return Collections.emptyList();
        }
        JsonNode sections = root.get("Sections");
        List<String> sectionIds = new ArrayList<>();
        if (sections != null && sections.isArray()) {
            for (JsonNode section : sections) {
                String id = section.has("Id") ? section.get("Id").asText() : null;
                sectionIds.add(id);
            }
        } else {
            return Collections.emptyList();
        }
        return sectionIds;
    }

    /**
     * Fetches locker bank details for a given section from the Vecos API.
     * This method ensures the tenant is authenticated, sends an HTTP GET request to
     * the
     * section-specific locker banks endpoint, parses the JSON response, and returns
     * a map of locker bank IDs to names.
     *
     * @param sectionId    The ID of the section for which locker banks are to be
     *                     fetched
     * @param lockerTenant The tenant identifier used for authentication and API
     *                     access
     * @return Map of locker bank IDs to their corresponding names
     */
    private Map<String, String> fetchLockerBanks(String sectionId, String lockerTenant) {
        JsonNode root = fetchJsonWithRetry(
                getSapiUri(VecosConstants.VECOS_SECTION_ENDPOINT_API + "/" + sectionId
                        + VecosConstants.VECOS_SECTION_LOCKERBANKS_ENDPOINT),
                lockerTenant,
                "fetchLockerBanks");
        if (root == null) {
            return Collections.emptyMap();
        }
        JsonNode lockerBanks = root.get("LockerBanks");
        Map<String, String> lockerBankMap = new HashMap<>();
        if (lockerBanks != null && lockerBanks.isArray()) {
            for (JsonNode lockerBank : lockerBanks) {
                String lockerBankId = lockerBank.has("Id") ? lockerBank.get("Id").asText() : null;
                String lockerBankName = lockerBank.has("Name") ? lockerBank.get("Name").asText() : null;
                lockerBankMap.put(lockerBankId, lockerBankName);
            }
        } else {
            return Collections.emptyMap();
        }
        return lockerBankMap;
    }

    /**
     * Sets the number of free lockers available for a given POI (Point of
     * Interest).
     * It retrieves locker bank status from an external service and updates the
     * POI's attributes.
     * 
     * @param lockerBankId the name of the locker bank Id to search for locker free
     *                     number
     * @param lockerTenant the name of the locker tenant
     */
    public String getLockerFreeNumber(String lockerBankId, String lockerTenant) {
        String lockerFreeNumber = null;
        VecosLockerBank lockerBank = fetchLockerBankStatusWithRetry(
                this.getSapiUri(
                        VecosConstants.LOCKER_BANK_ENDPOINT + lockerBankId.trim() + VecosConstants.STATUS_ENDPOINT),
                lockerTenant);
        if (Objects.isNull(lockerBank)) {
            log.error("Error while getting Locker information");
        }
        if (!Objects.isNull(lockerBank) && !CollectionUtils.isEmpty(lockerBank.getStatus())) {
            Long freeNumber = lockerBank.getStatus().stream()
                    .filter(status -> status.getAvailableDynamicLockers() != null)
                    .mapToLong(status -> status.getAvailableDynamicLockers())
                    .sum();
            log.info("Locker : {}, Number of free locker : {}", lockerBankId, freeNumber);
            lockerFreeNumber = String.valueOf(freeNumber);
        }
        return lockerFreeNumber;
    }
}