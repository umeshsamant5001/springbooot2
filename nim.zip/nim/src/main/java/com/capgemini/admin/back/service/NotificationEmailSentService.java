package com.capgemini.admin.back.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.NotificationEmailSent;
import com.capgemini.admin.back.repository.NotificationEmailSentRepository;

@Service
public class NotificationEmailSentService {

    private static final Logger log = LoggerFactory.getLogger(NotificationEmailSentService.class);

    @Autowired
    private NotificationEmailSentRepository notificationEmailSentRepository;

    /**
     * Retrieves a list of the last sent notification emails.
     *
     * @return A List of NotificationEmailSent objects representing the last sent
     *         notification emails.
     */
    public List<NotificationEmailSent> findAllLast() {
        try {
            return this.notificationEmailSentRepository.findAllLast();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve last notification emails.", ex);
            throw new IllegalStateException("Unable to retrieve last notification emails at this time.");
        }
    }

    /**
     * Saves a NotificationEmailSent object to the repository.
     *
     * @param notificationSent The NotificationEmailSent object to be saved.
     * @return The saved NotificationEmailSent object.
     */
    public NotificationEmailSent save(NotificationEmailSent notificationSent) {
        return this.notificationEmailSentRepository.save(notificationSent);
    }
}