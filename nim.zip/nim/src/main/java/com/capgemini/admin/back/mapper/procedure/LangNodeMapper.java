package com.capgemini.admin.back.mapper.procedure;

import com.capgemini.admin.back.mapper.DtoMapperConfig;
import com.capgemini.admin.back.model.procedure.LangAdminNode;
import com.capgemini.admin.back.model.procedure.LangNodeDTO;
import com.capgemini.admin.back.model.procedure.LangUserNode;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface LangNodeMapper {

    LangNodeMapper INSTANCE = Mappers.getMapper(LangNodeMapper.class);

    LangNodeDTO langUserNodeToLangNodeDTO(LangUserNode in);

    LangUserNode langNodeDTOToLangUserNode(LangNodeDTO in);

    LangNodeDTO langAdminNodeToLangNodeDTO(LangAdminNode in);

    LangAdminNode langNodeDTOToLangAdminNode(LangNodeDTO in);

}