package com.capgemini.admin.back.helper;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class PageSizeResult implements Pageable {

	int page;
	int size;

	public PageSizeResult(Integer page, Integer size) {
		this.page = page;
		this.size = size;
	}

	@Override
	public int getPageNumber() {
		return this.page;
	}

	@Override
	public int getPageSize() {
		return this.size;
	}

	@Override
	public long getOffset() {
		return this.page * this.size;
	}

	@Override
	public Sort getSort() {
		return null;
	}

	@Override
	public Pageable next() {
		return new PageSizeResult(this.page + 1, this.size);
	}

	@Override
	public Pageable previousOrFirst() {
		if (this.page - 1 > 0) {
			return new PageSizeResult(this.page - 1, this.size);
		}
		return null;
	}

	@Override
	public Pageable first() {
		return new PageSizeResult(1, this.size);
	}

	@Override
	public boolean hasPrevious() {
		return false;
	}

	@Override
	public Pageable withPage(int pageNumber) {
		// Auto-generated method stub
		throw new UnsupportedOperationException("Unimplemented method 'withPage'");
	}

}
