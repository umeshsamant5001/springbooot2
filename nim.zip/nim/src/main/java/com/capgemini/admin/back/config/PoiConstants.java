package com.capgemini.admin.back.config;

public class PoiConstants {

    public static final String HEADER_POI_NAME = "POINAME";
    public static final String HEADER_CONF_ROOM_MAIL = "CONFROOMMAIL";
    public static final String HEADER_CAPACITY = "CAPACITY";
    public static final int IDX_POI_NAME = 0;
    public static final int IDX_CONF_ROOM_MAIL = 1;
    public static final int IDX_HEADER_CAPACITY = 2;
    public static final int POI_COLUMN_COUNT = 3;
    public static final int MAX_POI_IMPORT_DATA_LINES = 10000;

    public static final String CONF_ROOM_MAIL = "conf_room_mail";
    public static final String CAPACITY = "capacity";
    public static final String FREE_STATE = "FREE";
    public static final String BUSY_STATE = "BUSY";
    public static final String DEFAULT_STATE = "UNKNOWN";
    public static final String AVERAGE_KEY_TEMP = "temp";
    public static final String AVERAGE_KEY_HUMIDITY = "humidity";
    public static final String AVERAGE_KEY_LUX = "lux";
    public static final String AVERAGE_KEY_SOUND = "sound";
    public static final String AVERAGE_KEY_CO2 = "co2";
    public static final String TYPE_LOCKER = "locker";
    public static final String TYPE_COMFORT = "Comfort";
    /** Position of the Poi Name from the Query Export */
    public static final int EXPORT_INDEX_POI_NAME = 5;
    /** Position of the Temperature from the Query Export */
    public static final int EXPORT_INDEX_TEMPERATURE = 8;
    /** Position of the Humidity from the Query Export */
    public static final int EXPORT_INDEX_HUMIDITY = 9;
    /** Position of the State from the Query Export */
    public static final int EXPORT_INDEX_STATE = 10;
    // Position of Lux in the Result Export
    public static final int EXPORT_INDEX_LUX = 12;
    // Position of Sound in the Result Export
    public static final int EXPORT_INDEX_SOUND = 13;
    // Position of CO2 in the Result Export
    public static final int EXPORT_INDEX_CO2 = 14;
    /** Position of the Apparent Temperature to the Result Export */
    public static final int EXPORT_INDEX_APPARENT_TEMP = 16;
    /** Position of the Temperature in fahrenheit to the Result Export */
    public static final int EXPORT_INDEX_TEMP_F = 17;

    
}
