package com.capgemini.admin.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.BuildingInformation;
import com.capgemini.admin.back.model.BuildingInformationDTO;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.FloorDTO;
import com.capgemini.admin.back.model.Site;
import com.capgemini.admin.back.model.SiteDTO;

@Named("BuildingMapper")
@Mapper(config = DtoMapperConfig.class, uses = CdmAttributesMapper.class)
public interface BuildingMapper {

    BuildingMapper INSTANCE = Mappers.getMapper(BuildingMapper.class);

    /**
     * <p>
     * Function to use to map a Building to a BuildingDTO.
     * <p>
     *
     * <p>
     * The function map all children object and parent ones. But don't map children
     * of the parents and
     * parents of the children to avoid a loop in the mapping.
     * </p>
     *
     * @param in       The Building to map.
     * @param language The current language (use for the title)
     * @return A new Building DTO.
     */
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
            @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
            @Mapping(source = "information", target = "information", qualifiedByName = {
                    "buildingInformationToBuildingInformationDTO" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    BuildingDTO buildingToBuildingDTO(Building in, @Context String language);

    @Mapping(source = "in", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributes" })
    Building buildingDTOToBuilding(BuildingDTO in);

    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
            @Mapping(target = "floors", ignore = true),
            @Mapping(source = "information", target = "information", qualifiedByName = {
                    "buildingInformationToBuildingInformationDTO" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    BuildingDTO buildingToBuildingDTONoFloors(Building in, @Context String language);

    /**
     * <p>
     * <strong>Do not use directly</strong> : used for @Mapping() decorator.
     * </p>
     *
     * <p>
     * The function map a Building to a Building DTO but without mapping the parent
     * (Site).
     * </p>
     */
    @Named("buildingToBuildingDTOWithoutParent")
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(target = "site", ignore = true),
            @Mapping(source = "floors", target = "floors", qualifiedByName = { "floorToFloorDTOWithoutParent" }),
            @Mapping(source = "information", target = "information", qualifiedByName = {
                    "buildingInformationToBuildingInformationDTO" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    BuildingDTO _buildingToBuildingDTOWithoutParent(Building in, @Context String language);

    /**
     * <p>
     * <strong>Do not use directly</strong> : used for @Mapping() decorator.
     * </p>
     *
     * <p>
     * The function map a Building to a Building DTO but without mapping the
     * ;children (Floor).
     * </p>
     */
    @Named("buildingToBuildingDTOWithoutChildren")
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(source = "site", target = "site", qualifiedByName = { "siteToSiteDTOWithoutChildren" }),
            @Mapping(target = "floors", ignore = true),
            @Mapping(source = "information", target = "information", qualifiedByName = {
                    "buildingInformationToBuildingInformationDTO" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    BuildingDTO _buildingToBuildingDTOWithoutChildren(Building in, @Context String language);

    @Named("siteToSiteDTOWithoutChildren")
    default SiteDTO _siteToSiteDTOWithoutChildren(Site site, @Context String language) {
        return Mappers.getMapper(SiteMapper.class)._siteToSiteDTOWithoutChildren(site, language);
    }

    @Named("floorToFloorDTOWithoutParent")
    default FloorDTO _floorToFloorDTOWithoutParent(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class)._floorToFloorDTOWithoutParent(floor, language);
    }

    @Named("buildingInformationToBuildingInformationDTO")
    default BuildingInformationDTO buildingInformationToBuildingInformationDTO(BuildingInformation buildingInformation,
            @Context String language) {
        return Mappers.getMapper(BuildingInformationMapper.class)
                .BuildingInformationToBuildingInformationDTO(buildingInformation, language);
    }

    @Named("buildingInformationDTOToBuildingInformation")
    default BuildingInformation buildingInformationDTOToBuildingInformation(BuildingInformationDTO buildingInformation,
            @Context String language) {
        return Mappers.getMapper(BuildingInformationMapper.class)
                .BuildingInformationDTOToBuildingInformation(buildingInformation, language);
    }

}
