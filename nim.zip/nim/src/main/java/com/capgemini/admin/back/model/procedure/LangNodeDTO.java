package com.capgemini.admin.back.model.procedure;

import lombok.Data;

@Data
public class LangNodeDTO {
    private Long id;
    private String jsonNode;
    private String xmlNode;
    private String xmlNodewithdata;
}