package com.capgemini.admin.back.config;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableWebMvc
@Slf4j
public class CORSConfiguration implements WebMvcConfigurer {

    @Autowired
    private ApplicationProperties applicationProperties;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        CorsRegistration registration = registry.addMapping("/**");

        log.info("CORS origins: '{}'", this.applicationProperties.getCors().getOrigins().replace(" ", "_"));

        if (Objects.nonNull(this.applicationProperties.getCors().getOrigins())
                && !this.applicationProperties.getCors().getOrigins().isEmpty()) {
            registration.allowedOrigins(this.applicationProperties.getCors().getOrigins().split(","));
        } else {
            registration.allowedOrigins(CorsConfiguration.ALL);
        }


        registration.allowedMethods(CorsConfiguration.ALL);
    }
}
