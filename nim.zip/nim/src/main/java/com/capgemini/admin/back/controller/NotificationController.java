package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.mapper.NotificationMapper;
import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationDTO;
import com.capgemini.admin.back.model.NotificationSent;
import com.capgemini.admin.back.service.NotificationService.NotificationSanitizedInput;


import com.capgemini.admin.back.model.PushNotificationRequest;
import com.capgemini.admin.back.service.DeviceTokenService;
import com.capgemini.admin.back.service.NotificationService;
import com.capgemini.admin.back.service.PushNotificationService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.ApnsConfig;
import com.google.firebase.messaging.Aps;
import com.google.firebase.messaging.ApsAlert;
import com.google.firebase.messaging.BatchResponse;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.MulticastMessage;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping(value = NotificationController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class NotificationController extends ScheduledController<Notification, NotificationSent, NotificationDTO> {

    static final String ROOT_API = "api/notification";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class NotificationLocationWriteInput {
        @Min(0)
        private Long cdmKeyId;
        private LevelEnum level;
        @Min(0)
        private Long countryId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String countryName;
        @Size(max = 64)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String status;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class NotificationWriteInput {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String title;
        @Size(max = 5000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String message;
        @Size(max = 128)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String messageType;
        @Size(max = 1000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String image;
        @Size(max = 10)
        private List<EnumOsType> osTypes = new ArrayList<>();
        private EnumPriorityType priorityType;
        @Min(0)
        private Long startDate;
        @Min(0)
        private Long endDate;
        @Size(max = 100)
        private Map<String, String> attributes = new HashMap<>();
        @Valid
        @Size(max = 100)
        private List<NotificationLocationWriteInput> notificationLocations = new ArrayList<>();
    }

    @Autowired
    private NotificationService notificationService;


    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private PushNotificationService pushNotificationService;

    @Override
    protected Notification getScheduledById(Long id, String language) {
        return this.notificationService.getNotification(id);
    }

    @Override
    protected void deleteScheduled(Notification notification) {
        this.notificationService.delete(notification);
    }

    @Override
    protected Notification saveScheduled(Notification notification) {
        return this.notificationService.save(notification);
    }

    @Override
    protected Notification updateScheduled(Notification notification, NotificationDTO notificationDTO) {
        return this.notificationService.update(notification, notificationDTO);
    }

    @Override
    protected NotificationDTO mapToDTO(Notification notification) {
        return NotificationMapper.INSTANCE.NotificationToNotificationDTO(notification);
    }

    @Override
    protected Notification mapToBusiness(NotificationDTO notificationDTO) {
        return NotificationMapper.INSTANCE.NotificationDTOToNotification(notificationDTO);
    }

    /**
     * Retrieves a list of notifications based on optional filtering parameters and
     * returns them as DTOs.
     *
     * @param osTypes       The list of operating system types for filtering
     *                      notifications (optional).
     * @param priorityTypes The list of priority types for filtering notifications
     *                      (optional).
     * @param status        The list of status types for filtering notifications
     *                      (optional).
     * @return ResponseEntity containing a list of NotificationDTOs matching the
     *         specified filters.
     */
    @GetMapping
    public ResponseEntity<List<NotificationDTO>> getNotifications(
            @RequestParam(required = false) List<EnumOsType> osTypes,
            @RequestParam(required = false) List<EnumPriorityType> priorityTypes,
            @RequestParam(required = false) List<EnumStatusScheduled> status,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        // Create a list of os based on the input
        List<EnumOsType> osTypeList = Objects.isNull(osTypes)
                ? List.of(EnumOsType.ANDROID, EnumOsType.IOS, EnumOsType.WEB)
                : osTypes;

        // Create a list of priorities based on the input
        List<EnumPriorityType> priorityTypeList = Objects.isNull(priorityTypes)
                ? List.of(EnumPriorityType.LOW, EnumPriorityType.MEDIUM, EnumPriorityType.HIGH)
                : priorityTypes;

        // Create a list of status based on the input
        List<EnumStatusScheduled> statusList = Objects.isNull(status)
                ? List.of(EnumStatusScheduled.RUNNING, EnumStatusScheduled.STOPPED)
                : status;

        // Retrieve of notifications based on the provided parameters
        List<Notification> notifications = this.notificationService.getNotifications(osTypeList, priorityTypeList,
                statusList);
        // Convert the list of notifications to a list of NotificationDTOs
        List<NotificationDTO> notificationDTOs = this.notificationService.listNotificationToNotificationDTOList()
                .apply(notifications);

        return ResponseEntity.ok(notificationDTOs);
    }

    @PostMapping("/send")
    public ResponseEntity<Map<String, String>> sendPushNotification(@RequestParam String targetPlatform,
            @RequestBody PushNotificationRequest request) {
        Map<String, String> response = new HashMap<>();

        this.deviceTokenService.initialize();

        try {
            List<String> androidRegistrationTokens = new ArrayList<>();
            List<String> iosRegistrationTokens = new ArrayList<>();
            List<String> failedTokens = new ArrayList<>();
            MulticastMessage androidMessage = null;
            MulticastMessage iosMessage = null;
            BatchResponse androidResponse = null;
            BatchResponse iosResponse = null;
            int batchSize = 450;

            if (targetPlatform.equalsIgnoreCase("Android") || targetPlatform.equalsIgnoreCase("All")) {
                androidRegistrationTokens = this.deviceTokenService.getDeviceRegistrationTokens(EnumOsType.ANDROID);
                int processedTokens = 0;
                // Split the list into batches
                while (processedTokens < androidRegistrationTokens.size()) {
                    int endIndex = Math.min(processedTokens + batchSize, androidRegistrationTokens.size());
                    List<String> batchTokens = androidRegistrationTokens.subList(processedTokens, endIndex);
                    String androidBody = request.getMessage().getAndroid().getNotification().getBody();
                    androidBody = removeHtmlTags(androidBody);
                    androidMessage = MulticastMessage.builder()
                            .addAllTokens(batchTokens)
                            .setAndroidConfig(AndroidConfig.builder()
                                    .setNotification(AndroidNotification.builder()
                                            .setTitle(request.getMessage().getAndroid().getNotification().getTitle())
                                            .setBody(androidBody)
                                            .build())
                                    .build())
                            .build();

                    // Send Android notifications
                    androidResponse = FirebaseMessaging.getInstance(FirebaseApp.getInstance("androidApp"))
                            .sendMulticast(androidMessage);
                    log.info("Android notifications sent");

                    // Handle Android failures
                    if (Objects.nonNull(androidResponse) && androidResponse.getFailureCount() > 0) {
                        List<String> androidFailedTokens = this.deviceTokenService.handleFailedTokens(androidResponse,
                                batchTokens, "Android");
                        failedTokens.addAll(androidFailedTokens);
                    }
                    processedTokens = endIndex;
                }

            }
            if (targetPlatform.equalsIgnoreCase("iOS") || targetPlatform.equalsIgnoreCase("All")) {
                iosRegistrationTokens = this.deviceTokenService.getDeviceRegistrationTokens(EnumOsType.IOS);
                int processedTokens = 0;
                while (processedTokens < iosRegistrationTokens.size()) {
                    int endIndex = Math.min(processedTokens + batchSize, iosRegistrationTokens.size());
                    List<String> batchTokens = iosRegistrationTokens.subList(processedTokens, endIndex);
                    String iosBody = request.getMessage().getApns().getPayload().getAps().getAlert().getBody();
                    iosBody = removeHtmlTags(iosBody);
                    iosMessage = MulticastMessage.builder()
                            .addAllTokens(batchTokens)
                            .setApnsConfig(ApnsConfig.builder()
                                    .setAps(Aps.builder()
                                            .setAlert(ApsAlert.builder()
                                                    .setTitle(request.getMessage().getApns().getPayload().getAps()
                                                            .getAlert().getTitle())
                                                    .setBody(iosBody)
                                                    .build())
                                            .build())
                                    .build())
                            .build();

                    // Send iOS notifications
                    iosResponse = FirebaseMessaging.getInstance(FirebaseApp.getInstance("iosApp"))
                            .sendMulticast(iosMessage);
                    log.info("iOS notifications sent");

                    // Handle iOS failures
                    if (Objects.nonNull(iosResponse) && iosResponse.getFailureCount() > 0) {
                        List<String> iosFailedTokens = this.deviceTokenService.handleFailedTokens(iosResponse,
                                batchTokens, "iOS");
                        failedTokens.addAll(iosFailedTokens);
                    }
                    processedTokens = endIndex;
                }
            }

            if (Objects.nonNull(androidResponse) && androidResponse.getSuccessCount() > 0) {
                String safeAndroidSuccessCount = sanitizeForLog(String.valueOf(androidResponse.getSuccessCount()));
                log.info("{}  Android messages were sent successfully", safeAndroidSuccessCount);
            }

            if (Objects.nonNull(iosResponse) && iosResponse.getSuccessCount() > 0) {
                String safeIosSuccessCount = sanitizeForLog(String.valueOf(iosResponse.getSuccessCount()));
                log.info("{}  IOS messages were sent successfully", safeIosSuccessCount);
            }


            if (targetPlatform.equalsIgnoreCase("All")
                    && (Objects.nonNull(androidResponse) && androidResponse.getFailureCount() == 0)
                    && (Objects.nonNull(iosResponse) && iosResponse.getFailureCount() == 0)) {
                response.put("message", "Notification sent successfully");
                return ResponseEntity.ok(response);
            }

            if (targetPlatform.equalsIgnoreCase("Android")
                    && (Objects.nonNull(androidResponse) && androidResponse.getFailureCount() == 0)) {
                response.put("message", "Notification sent successfully");
                return ResponseEntity.ok(response);
            }

            if (targetPlatform.equalsIgnoreCase("iOS")
                    && (Objects.nonNull(iosResponse) && iosResponse.getFailureCount() == 0)) {
                response.put("message", "Notification sent successfully");
                return ResponseEntity.ok(response);
            }

            if ((Objects.nonNull(androidResponse) && androidResponse.getFailureCount() > 0)
                    || (Objects.nonNull(iosResponse) && iosResponse.getFailureCount() > 0)) {
                response.put("error", "Error sending notification: tokens have failed - " + failedTokens);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(response);
            }
            response.put("error", "Error sending notification: Some failure response received.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage(), e);
            response.put("error", "Error sending notification: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }

    // To keep compatibility for testing for now.
    @PostMapping("/sendNotification")
    public ResponseEntity<Map<String, String>> sendPushNotificationTopic(@RequestParam String targetPlatform,
            @RequestBody PushNotificationRequest request) {
        Map<String, String> response = new HashMap<>();

        Notification notification = new Notification();

        if (targetPlatform.equalsIgnoreCase("iOS")) {
            notification.setMessage(request.getMessage().getApns().getPayload().getAps().getAlert().getBody());
            notification.setTitle(request.getMessage().getApns().getPayload().getAps().getAlert().getTitle());
            notification.setOsTypes(List.of(EnumOsType.IOS));
        }

        if (targetPlatform.equalsIgnoreCase("Android")) {
            notification.setMessage(request.getMessage().getAndroid().getNotification().getBody());
            notification.setTitle(request.getMessage().getAndroid().getNotification().getTitle());
            notification.setOsTypes(List.of(EnumOsType.ANDROID));
        }

        if (targetPlatform.equalsIgnoreCase("All")) {
            notification.setOsTypes(List.of(EnumOsType.ANDROID, EnumOsType.IOS, EnumOsType.WEB));
        }

        try {
            this.notificationService.send(notification);

            response.put("message", "Notification sent successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage(), e);
            response.put("error", "Error sending notification: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }

    // APIs for testing purpose manually
    /**
     * Saves a notification and sends it immediately if the start date is not in the
     * future.
     *
     * @param notificationDTO the notification data to be saved and potentially sent
     * @return the saved notification with updated status and ID, or an error
     *         response if failed
     */

    @PostMapping("/countryNotification")
    public ResponseEntity<NotificationDTO> saveAndSendNotification(
            @Valid @RequestBody NotificationWriteInput notificationInput) {
        try {
            NotificationSanitizedInput sanitizedNotification = sanitizeNotificationInput(notificationInput);
            String safeTitle = sanitizeForLog(sanitizedNotification.getTitle());
            log.info("Received request to save and send notification: Title='{}'", safeTitle);

            Notification saved = notificationService.saveFromSanitizedInput(
                    sanitizedNotification,
                    EnumStatusScheduled.RUNNING);


            long now = System.currentTimeMillis() / 1000;

            boolean sent = false;

            if (saved.getStartDate() == null || saved.getStartDate() <= now) {
                sent = pushNotificationService.sendByLocations(saved);
                log.info("notification sent immediately(ID={}): {}", saved.getId(), sent);
            } else {
                String safeStartDate = sanitizeForLog(String.valueOf(saved.getStartDate()));
                log.info(
                        "notification ID = {} saved for future startDate = {}, skip immediately push",
                        saved.getId(),
                        safeStartDate);
            }

            log.info("Notification ID={} sent status = {}", saved.getId(), sent);

            NotificationDTO responseDTO = NotificationMapper.INSTANCE.NotificationToNotificationDTO(saved);
            return ResponseEntity.ok(responseDTO);
        } catch (Exception e) {
            log.error("Error saving or sending push: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


    /**
     * Saves a notification without sending it, setting default status if not
     * provided.
     *
     * @param notificationDTO the notification data to be saved
     * @return the saved notification with assigned ID and status, or an error
     *         response if failed
     */

    @PostMapping("/save")
    public ResponseEntity<NotificationDTO> saveNotification(
            @Valid @RequestBody NotificationWriteInput notificationInput) {
        try {
            NotificationSanitizedInput sanitizedNotification = sanitizeNotificationInput(notificationInput);
            Notification saved = notificationService.saveFromSanitizedInput(
                    sanitizedNotification,
                    EnumStatusScheduled.STOPPED);


            String safeStatus = sanitizeForLog(saved.getStatus() == null ? null : saved.getStatus().name());
            String safeStartDate = sanitizeForLog(
                    saved.getStartDate() == null ? null : String.valueOf(saved.getStartDate()));
            log.info(
                    "[SAVE] Notification saved with ID={}, status={}, startDate={}",
                    saved.getId(),
                    safeStatus,
                    safeStartDate);
            NotificationDTO responseDTO = NotificationMapper.INSTANCE.NotificationToNotificationDTO(saved);
            return ResponseEntity.ok(responseDTO);

        } catch (Exception e) {
            log.error("[ERROR] Failed to save notification: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


    /**
     * Sends a previously saved notification by its ID if it exists.
     *
     * @param id the ID of the notification to send
     * @return the notification data if sent successfully, or an error/not found
     *         response
     */

    @PostMapping("/send/country/{id}")
    public ResponseEntity<NotificationDTO> sendNotificationById(@PathVariable Long id) {
        log.info("Attempting to send notification by ID={}", id);

        Notification notification = notificationService.getNotification(id);

        if (notification == null) {
            log.warn("Notification with ID={} not found", id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        try {
            boolean sent = pushNotificationService.sendByLocations(notification);

            if (sent) {
                log.info(" Notification ID={} sent successfully", id);
            } else {
                log.warn(" No tokens found for notification ID={}", id);
            }

            NotificationDTO dto = NotificationMapper.INSTANCE.NotificationToNotificationDTO(notification);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            log.error(" Error while sending push for ID={}: {}", id, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private NotificationSanitizedInput sanitizeNotificationInput(NotificationWriteInput notificationInput) {
        NotificationSanitizedInput sanitizedNotification = new NotificationSanitizedInput();

        if (notificationInput.getTitle() != null) {
            sanitizedNotification.setTitle(new String(String.valueOf(notificationInput.getTitle())));
        }
        if (notificationInput.getMessage() != null) {
            sanitizedNotification.setMessage(new String(String.valueOf(notificationInput.getMessage())));
        }
        if (notificationInput.getMessageType() != null) {
            sanitizedNotification.setMessageType(new String(String.valueOf(notificationInput.getMessageType())));
        }
        if (notificationInput.getImage() != null) {
            sanitizedNotification.setImage(new String(String.valueOf(notificationInput.getImage())));
        }

        List<EnumOsType> safeOsTypes = new ArrayList<>();
        if (notificationInput.getOsTypes() != null) {
            for (EnumOsType osType : notificationInput.getOsTypes()) {
                if (osType != null) {
                    safeOsTypes.add(EnumOsType.valueOf(String.valueOf(osType.name())));
                }
            }
        }
        sanitizedNotification.setOsTypes(safeOsTypes);

        if (notificationInput.getPriorityType() != null) {
            sanitizedNotification
                    .setPriorityType(EnumPriorityType.valueOf(String.valueOf(notificationInput.getPriorityType().name())));
        }
        if (notificationInput.getStartDate() != null) {
            sanitizedNotification.setStartDate(Long.valueOf(notificationInput.getStartDate()));
        }
        if (notificationInput.getEndDate() != null) {
            sanitizedNotification.setEndDate(Long.valueOf(notificationInput.getEndDate()));
        }

        Map<String, String> safeAttributes = new HashMap<>();
        if (notificationInput.getAttributes() != null) {
            notificationInput.getAttributes().forEach((key, value) -> {
                if (key != null) {
                    String safeKey = new String(String.valueOf(key));
                    String safeValue = value == null ? null : new String(String.valueOf(value));
                    safeAttributes.put(safeKey, safeValue);
                }
            });
        }
        sanitizedNotification.setAttributes(safeAttributes);

        List<NotificationSanitizedInput.NotificationLocationSanitizedInput> safeLocations = new ArrayList<>();
        if (notificationInput.getNotificationLocations() != null) {
            for (NotificationLocationWriteInput locationInput : notificationInput.getNotificationLocations()) {
                if (locationInput == null) {
                    continue;
                }
                NotificationSanitizedInput.NotificationLocationSanitizedInput safeLocation = new NotificationSanitizedInput.NotificationLocationSanitizedInput();
                if (locationInput.getCdmKeyId() != null) {
                    safeLocation.setCdmKeyId(Long.valueOf(locationInput.getCdmKeyId()));
                }
                if (locationInput.getLevel() != null) {
                    safeLocation.setLevel(LevelEnum.valueOf(String.valueOf(locationInput.getLevel().name())));
                }
                if (locationInput.getCountryId() != null) {
                    safeLocation.setCountryId(Long.valueOf(locationInput.getCountryId()));
                }
                if (locationInput.getCountryName() != null) {
                    safeLocation.setCountryName(new String(String.valueOf(locationInput.getCountryName())));
                }
                if (locationInput.getStatus() != null) {
                    safeLocation.setStatus(new String(String.valueOf(locationInput.getStatus())));
                }
                safeLocations.add(safeLocation);
            }
        }
        sanitizedNotification.setNotificationLocations(safeLocations);

        return sanitizedNotification;
    }



    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

    private String removeHtmlTags(String input) {
        return input.replaceAll("<div>", " ").replaceAll("</div>", " ").replaceAll("<br>", "").replaceAll("</br>", "");
    }


    /**
     * Test API to trigger push by notification ID
     */
    @PostMapping("/send/{id}")
    public ResponseEntity<String> sendNotification(@PathVariable Long id) {

        log.info("API Triggered for notificationId={}", id);

        Notification notification = notificationService.getNotification(id);

        if (notification == null) {
            return ResponseEntity.badRequest()
                    .body("Notification not found for id: " + id);
        }

        try {
            boolean result = pushNotificationService.sendByLocations(notification);

            return ResponseEntity.ok(
                    "Notification sent. Success=" + result
            );

        } catch (Exception e) {
            log.error("Error sending notification", e);
            return ResponseEntity.internalServerError()
                    .body("Failed to send notification: " + e.getMessage());
        }
    }
}
