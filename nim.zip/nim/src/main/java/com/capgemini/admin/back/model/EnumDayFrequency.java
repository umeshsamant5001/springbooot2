package com.capgemini.admin.back.model;

public enum EnumDayFrequency {
    DAILY, WEEKLY, MONTHLY, YEARLY
}