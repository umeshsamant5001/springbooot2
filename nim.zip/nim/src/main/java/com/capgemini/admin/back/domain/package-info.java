/**
 * JPA domain objects.
 */
package com.capgemini.admin.back.domain;
