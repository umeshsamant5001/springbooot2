package com.capgemini.admin.back.scheduled;

import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.model.EmployeeDetailDTO;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.service.LDAPData;
import com.capgemini.admin.back.service.UserDeletionService;
import com.capgemini.admin.back.service.UserService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DeleteUsersActionJob {

    @Autowired
    private UserService userService;

    @Autowired
    private UserDeletionService userDeletionService;

    private static final String CONFIG_PATH = "application.users.job";

    @Autowired
    private LDAPData ldapData;

    //Batch to remove users who left the company
    @Scheduled(cron = "${" + CONFIG_PATH + ".cron}", zone = "${" + CONFIG_PATH + ".tz}")//US#1676286 will be part of March 2026
    public void execJob() {

        List<User> users = userService.getAllAdminUsers();
        try  {
            ldapData.getLdapData();
            users.forEach(user -> {   
            try {     
                String safeEmailForLog = sanitizeForLog(user.getEmail());
                log.info("user emailid :-----------{}", safeEmailForLog);   
                List<EmployeeDetailDTO> employeeDetailDTOs = ldapData.getUserDetailsBySearch(user.getEmail());
                if (CollectionUtils.isEmpty(employeeDetailDTOs)) {     
                    log.info("user to be deleted {}:" , safeEmailForLog);                                   
                    purgeUserByEmail(user.getEmail());  
                }
            } catch (Exception e) {
                String safeEmailForLog = sanitizeForLog(user.getEmail());
                log.error("An error occurred while retrieving user details from LDAP for user {}", safeEmailForLog, e);
            }
            });

        } catch (Exception e) {
            log.error("An error occurred while retrieving LDAP data", e);
        }        
    }
    
    private void purgeUserByEmail(String email) {
        // Call the deletion method
        userDeletionService.deleteAdminUserCompletely(email);        
        String safeEmailForLog = sanitizeForLog(email);
        log.info("User purge completed for {}: ", safeEmailForLog);          
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
