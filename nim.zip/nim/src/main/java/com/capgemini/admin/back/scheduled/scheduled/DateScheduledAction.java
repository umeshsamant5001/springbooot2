package com.capgemini.admin.back.scheduled.scheduled;

import java.util.Date;
import java.util.Objects;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;

public class DateScheduledAction<N extends Scheduled, S extends ScheduledSent> extends ScheduledAction<N, S> {

    public boolean checkType(N scheduled) {
        return Objects.nonNull(scheduled.getStartDate()) && Objects.nonNull(scheduled.getEndDate())
                && Objects.equals(scheduled.getStartDate(), scheduled.getEndDate())
                && Objects.nonNull(scheduled.getAttributes()) && scheduled.getAttributes().isEmpty();
    }

    @Override
    public boolean shouldBeSent() {
        // If the Scheduled is allready sent, we don't send another
        if (Objects.nonNull(this.lastScheduledSent)) {
            return false;
        }

        Date startDate = new Date(this.scheduled.getStartDate() * 1000);

        // If the startDate is before now we send the Scheduled
        return this.now.compareTo(startDate) >= 0;
    }

    @Override
    public boolean wasLastSent() {
        // Once sent, it is necessarily the last
        return true;
    }
}
