package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationDTO;
import java.util.HashMap;
import java.util.Map;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class, uses = { NotificationLocationMapper.class })
public interface NotificationMapper {
    NotificationMapper INSTANCE = Mappers.getMapper(NotificationMapper.class);

    @Mapping(source = "osTypes", target = "osTypes", qualifiedByName = "toLowerCase")
    @Mapping(target = "notificationLocations", source = "notificationLocations")
    NotificationDTO NotificationToNotificationDTO(Notification in);

    // Mapping NotificationDTO -> Notification
    @Mapping(target = "id", ignore = true)
    @Mapping(source = "osTypes", target = "osTypes", qualifiedByName = "toLowerCase")
    @Mapping(source = "attributes", target = "attributes", qualifiedByName = "safeMap")
    Notification NotificationDTOToNotification(NotificationDTO in);


    @Named("safeMap")
    default Map<String, String> safeMap(Map<String, String> input) {
        return input != null ? new HashMap<>(input) : new HashMap<>();
    }

    @Named("toLowerCase")
    default EnumOsType _toLowerCase(EnumOsType osType) {
        if (osType.equals(EnumOsType.IOS)) {
            return EnumOsType.iOS;
        } else {
            return osType;
        }
    }
}