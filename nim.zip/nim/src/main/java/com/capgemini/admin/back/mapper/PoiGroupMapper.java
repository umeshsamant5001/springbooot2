package com.capgemini.admin.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.PoiGroup;
import com.capgemini.admin.back.model.PoiGroupDTO;

@Named("PoiGroupMapper")
@Mapper(config = DtoMapperConfig.class, uses = { SpaceTypeMapper.class })
public interface PoiGroupMapper {

    PoiGroupMapper INSTANCE = Mappers.getMapper(PoiGroupMapper.class);

    // Map entity to DTO, including spaceTypes
    @Mapping(source = "in.spaceTypes", target = "spaceTypes")
    @Mapping(source = "in", target = "title", qualifiedByName = "toTitle")
    PoiGroupDTO poiGroupToPoiGroupDTO(PoiGroup in, @Context String language);

    // Map DTO to entity while ignoring spaceTypes (to handle circular dependencies)
    @Mapping(target = "spaceTypes", ignore = true)
    PoiGroup poiGroupDTOToPoiGroup(PoiGroupDTO in);
}
