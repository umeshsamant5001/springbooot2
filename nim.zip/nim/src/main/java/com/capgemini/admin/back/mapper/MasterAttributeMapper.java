package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.InvalidParameterException;
import com.capgemini.admin.back.model.MasterAttribute;
import com.capgemini.admin.back.model.MasterAttributeDTO;

@Mapper(config = DtoMapperConfig.class)
public interface MasterAttributeMapper {
    MasterAttributeMapper INSTANCE = Mappers.getMapper(MasterAttributeMapper.class);

    MasterAttribute masterAttributeDTOToMasterAttribute(MasterAttributeDTO in) throws InvalidParameterException;

    MasterAttributeDTO masterAttributeToMasterAttributeDTO(MasterAttribute in) throws InvalidParameterException;

}
