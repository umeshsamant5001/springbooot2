package com.capgemini.admin.back.repository.procedure;

import com.capgemini.admin.back.model.procedure.AppConfigValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AppConfigValueRepository extends JpaRepository<AppConfigValue, Long> {

    @Procedure(name = "GetAppConfigByConfigkey")
    AppConfigValue getAppConfigByConfigkey(@Param("configkey") String configkey);

}