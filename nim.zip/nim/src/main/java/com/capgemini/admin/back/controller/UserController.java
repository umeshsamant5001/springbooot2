package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.admin.back.model.Building;

import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.LocationDTO;
import com.capgemini.admin.back.model.ResponseSecuredUserImportDTO;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.model.SecuredUserImportDTO;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.model.UserDTO;
import com.capgemini.admin.back.model.UserRoleLocation;
import com.capgemini.admin.back.model.UserRoleLocationDTO;
import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.RoleRepository;
import com.capgemini.admin.back.repository.UserRepository;
import com.capgemini.admin.back.repository.UserRoleLocationRepository;
import com.capgemini.admin.back.scheduled.DeleteUsersActionJob;
import com.capgemini.admin.back.service.UserProfileService;
import com.capgemini.admin.back.service.UserRoleLocationService;
import com.capgemini.admin.back.service.UserService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.admin.back.config.Constants;


@RestController
@Slf4j
@RequestMapping(value = UserController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class UserController {

    public static final String ROOT_API = "api/user";

    // Upper bound for secured-user CSV imports. Prevents an attacker from
    // uploading an arbitrarily large file that would cause unbounded loop
    // iterations in checkCSVFormat / generateResponseSecuredUserImportDTO.
    private static final long MAX_SECURED_USERS_IMPORT_FILE_SIZE_BYTES = 5L * 1024L * 1024L; // 5 MB
    
    

    @Autowired
    private UserService userService;

    @Autowired
    private BuildingRepository buildingRepository;

    @Autowired
    private UserRoleLocationService userRoleLocationService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRoleLocationRepository userRoleLocationRepository;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private DeleteUsersActionJob deleteUsersActionJob;

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserRoleInput {
        @NotNull
        @Min(1)
        private Long id;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String name;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserLocationInput {
        @Min(0)
        private Long id;
        private Boolean alertStatus;
        private LevelEnum level;
        @Min(0)
        private Long cdmKeyId;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserRoleLocationInput {
        @NotNull
        @Valid
        private UserRoleInput role;
        @Valid
        @Size(max = 1000)
        private List<UserLocationInput> locations = new ArrayList<>();
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserWriteInput {
        @Min(0)
        private Long id;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String firstName;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String lastName;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String email;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String country;
        private Boolean subscribeAlert;
        @NotNull
        @Valid
        @Size(min = 1, max = 1000)
        private List<UserRoleLocationInput> roleLocations = new ArrayList<>();
        private Integer userType;
        private Boolean enabled;
        private Boolean tokenExpired;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class SecuredBuildingWriteInput {
        @NotNull
        @Min(1)
        private Long id;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserRoleLocationUpdateLocationInput {
        private LevelEnum level;
        @Min(0)
        private Long cdmKeyId;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class UserRoleLocationUpdateInput {
        private Boolean subscribeAlert;
        @NotNull
        @Min(1)
        private Long roleId;
        @Valid
        @Size(max = 1000)
        private List<UserRoleLocationUpdateLocationInput> locations = new ArrayList<>();
    }


    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUsers(
            @RequestParam(required = false) Boolean hasWebUserProfile,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<UserDTO> usersDTO = new ArrayList<>();

        if (Boolean.TRUE.equals(hasWebUserProfile)) {
            // Fetch users who have at least one role with `isWebUserProfile = true`
            List<User> users = this.userService.getUsersWithWebUserProfile();
            List<UserRoleLocation> userRoleLocations = this.userRoleLocationService.getAllWithRole();
            usersDTO = users
                    .stream()
                    .map(user -> this.userService.toUserDTOWithRoleWithoutRoleLocations(user, userRoleLocations,
                            language))
                    .collect(Collectors.toList());
        } else if (Boolean.FALSE.equals(hasWebUserProfile)) {
            // Fetch users with no web user profile roles or at least one admin role
            List<User> users = this.userService.getUsersWithoutWebUserProfileOrWithAdminRole();
            List<UserRoleLocation> userRoleLocations = this.userRoleLocationService.getAllWithRole();
            usersDTO = users
                    .stream()
                    .map(user -> this.userService.toUserDTOWithRoleWithoutRoleLocations(user, userRoleLocations,
                            language))
                    .collect(Collectors.toList());
        } else {
            List<User> users = this.userService.getAllUserWithRole();
            List<UserRoleLocation> userRoleLocations = this.userRoleLocationService.getAllWithRole();
            usersDTO = users
                    .stream()
                    .map(user -> this.userService.toUserDTOWithRoleWithoutRoleLocations(user, userRoleLocations,
                            language))
                    .collect(Collectors.toList());
        }

        return ResponseEntity.ok(usersDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(
            @PathVariable Long id,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        User user = this.userService.getUserEveifDeleted(id);
        if (Objects.isNull(user)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with this id." + id);
        }
        UserDTO userDTO = this.userService.toUserDTOWithRoleLocations(user, language);
        return ResponseEntity.ok(userDTO);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<UserDTO> getUserByEmail(
            @PathVariable String email,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        User user = userService.getUserByEmail(email);
        if (Objects.isNull(user)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with this email." + email);
        }
        UserDTO userDTO = userService.toUserDTOWithRoleLocations(user, language);
        return ResponseEntity.ok(userDTO);
    }

    @PutMapping("/{id}/secured-building")
    public ResponseEntity<UserDTO> updateUserSecuredBuilding(
            @PathVariable Long id,
            @Valid @RequestBody List<SecuredBuildingWriteInput> securedBuildingDTOs,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        // Sanitize incoming building inputs with value-creating copies
        List<Long> sanitizedSecuredBuildingIds = new ArrayList<>();
        if (securedBuildingDTOs != null) {
            for (SecuredBuildingWriteInput incoming : securedBuildingDTOs) {
                if (incoming == null || incoming.getId() == null) {
                    continue;
                }
                sanitizedSecuredBuildingIds.add(Long.valueOf(incoming.getId()));
            }
        }
        User user = this.userService.updateUserSecuredBuilding(id, sanitizedSecuredBuildingIds);
        UserDTO userDTO = this.userService.toUserDTOWithRoleLocations(user, language);
        return ResponseEntity.ok(userDTO);
    }


    @PostMapping
    public ResponseEntity<?> createUser(
            @Valid @RequestBody UserWriteInput userDTO,
            @RequestParam(required = false) Boolean hasWebUserProfile,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        try {
            
            // Sanitize incoming User input: copy only allowed fields with value-creating calls
            UserDTO sanitizedUserDTO = toSanitizedUserDTO(userDTO);
            
            // Call service method to handle user creation or profile assignment
            User savedUser = userService.createUser(sanitizedUserDTO, hasWebUserProfile);
            log.info("createUser service returned savedUser id={}, email={}", savedUser != null ? savedUser.getId() : null,
                savedUser != null ? savedUser.getEmail() : null);
            UserDTO newUserDTO = userService.toUserDTOWithRoleLocations(savedUser, language);
            HttpStatus status = (sanitizedUserDTO.getId() == null) ? HttpStatus.CREATED : HttpStatus.OK;
            return ResponseEntity.status(status).body(newUserDTO);

        } catch (ResponseStatusException e) {
            log.error("User creation error: {}", e.getReason());
            return ResponseEntity.status(e.getStatus()).body(Collections.singletonMap("error", e.getReason()));
        } catch (Exception e) {
            log.error("Unexpected error in user creation", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonMap("error", "An unexpected error occurred " + e));
        }
    }


    @PutMapping("/{id}")
    public ResponseEntity<UserDTO> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserWriteInput userDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        // Sanitize incoming User input: copy only allowed fields with value-creating calls
        UserDTO sanitizedUserDTO = toSanitizedUserDTO(userDTO);
        User updatedUser = this.userService.updateUser(id, sanitizedUserDTO);
        UserDTO newUserDTO = this.userService.toUserDTOWithRoleLocations(updatedUser, language);
        return ResponseEntity.ok(newUserDTO);
    }


    /**
     * Handles HTTP DELETE requests to remove a user by their ID.
     * This method performs the following steps:
     * Retrieves the user by the provided ID.
     * If the user does not exist, returns a 404 Not Found response.
     * If the user exists, delegates the deletion logic to the service
     * layer.
     * Returns a 204 No Content response upon successful deletion.
     *
     * @param id the ID of the user to be deleted
     * @return a ResponseEntity indicating the result of the operation
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userProfileService.deleteAdminProfiles(id);
        userService.deleteFromUserRoleLocation(id);
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    /*
     * Export all users as a CSV file
     */
    @GetMapping("/export")
    public ResponseEntity<String> exportAllUsers() {
        List<List<String>> data = userService.getExportAllUsers();

        // Return CSV response
        return userService.export(data);
    }

    /*
     * Export for only Secured User as a CSV file
     */
    @GetMapping("/export/securedandbeta")
    public ResponseEntity<String> getExportSecuredAndBetaUsers() {
        List<List<String>> data = userService.getExportSecuredAndBetaUsers();

        // Return CSV response
        return userService.securedUsersExport(data);
    }

    /**
     * Imports secured users from a CSV file and assigns them to secured buildings.
     *
     * @param language The Accept-Language header (optional).
     * @param file     The CSV file to be imported.
     * @return Response containing import status and any errors encountered.
     */
    @PostMapping("/import/secured-users")
    public ResponseEntity<ResponseSecuredUserImportDTO> importSecuredUsers(@RequestParam("file") MultipartFile file) {
        ResponseSecuredUserImportDTO responseSecuredUserImportDTO = new ResponseSecuredUserImportDTO();

        // Validate the uploaded file BEFORE it reaches downstream loops to prevent
        // attackers from supplying an unbounded/very large input that would cause
        // excessive iterations in checkCSVFormat / generateResponseSecuredUserImportDTO.
        if (file == null || file.isEmpty()) {
            responseSecuredUserImportDTO.addError("The uploaded file is empty.");
            return ResponseEntity.unprocessableEntity().body(responseSecuredUserImportDTO);
        }
        if (file.getSize() > MAX_SECURED_USERS_IMPORT_FILE_SIZE_BYTES) {
            responseSecuredUserImportDTO.addError(
                    "The uploaded file exceeds the maximum allowed size of "
                            + MAX_SECURED_USERS_IMPORT_FILE_SIZE_BYTES + " bytes.");
            return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(responseSecuredUserImportDTO);
        }

        Role securedRole = roleRepository.findByName(Constants.SECURED_USER);

        // Step 1: Validate CSV Format
        responseSecuredUserImportDTO.setErrorsInFile(this.userService.checkCSVFormat(file));
        if (!CollectionUtils.isEmpty(responseSecuredUserImportDTO.getErrorsInFile())) {
            log.info("CollectionUtils NOT Empty(responseSecuredUserImportDTO.getErrorsInFile()");
            return ResponseEntity.unprocessableEntity().body(responseSecuredUserImportDTO);
        }

        // Step 2: Parse CSV Data
        responseSecuredUserImportDTO = this.userService.generateResponseSecuredUserImportDTO(file);
        if (!CollectionUtils.isEmpty(responseSecuredUserImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responseSecuredUserImportDTO);
        }

        Set<String> emails = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .filter(dto -> dto.getRoleName().equals(Constants.SECURED_USER))
                .map(SecuredUserImportDTO::getEmailId)
                .collect(Collectors.toSet());
        log.info("Emails for Secured Users: {}", emails);  

        Set<String> buildingNames = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .filter(dto -> dto.getRoleName().equals(Constants.SECURED_USER))
                .map(SecuredUserImportDTO::getBuildingTitleEn)
                .collect(Collectors.toSet());
        log.info("Building Names for Secured Users: {}", buildingNames);  

        Map<String,String> emailsBuildingForBetaMap = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .filter(dto -> dto.getRoleName().equals(Constants.BETA_USER))
                .collect(Collectors.toMap(SecuredUserImportDTO::getEmailId, SecuredUserImportDTO::getBuildingTitleEn));

        Set<String> emailsForBetaSet = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .filter(dto -> dto.getRoleName().equals(Constants.BETA_USER))
                .map(SecuredUserImportDTO::getEmailId)
                .collect(Collectors.toSet());

        List<String> buildingNamesForBeta = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .filter(dto -> dto.getRoleName().equals(Constants.BETA_USER))
                .map(SecuredUserImportDTO::getBuildingTitleEn)
                .collect(Collectors.toList());


        // Fetch all users by email
        Map<String, User> userByEmail = userRepository
                .findAllByEmailIn(emails)
                .stream()
                .collect(Collectors.toMap(User::getEmail, user -> user));
        log.info("Fetched users by email: {}", userByEmail.keySet());  // Time being logged for debugging

        // Fetch all buildings by name
        buildingNames.forEach(name -> log.info("Building Name: {}", name));
        Map<String, Building> buildingByName = buildingRepository
                .findByTitleEnIgnoreCaseIn(buildingNames)
                .stream()
                .collect(Collectors.toMap(Building::getTitleEn, building -> building));
        // Log the content of the map
        if (buildingByName.isEmpty()) {
            log.info("No buildings found for the given names.");
        } else {
            buildingByName.forEach((name, building) -> log.info("Building Name: {}, Building Details: {}", name,
                    building.getTitleEn()));
        }
        // Step 3: Collect all user-location mappings from the import
        Map<String, Set<Long>> userToImportedBuildingIds = new HashMap<>();
        for (SecuredUserImportDTO dto : responseSecuredUserImportDTO.getSecuredUserImportDTOs()) {
            String email = dto.getEmailId();
            Building building = buildingByName.get(dto.getBuildingTitleEn());
            log.info("Processing to put in >> user email: {} with building title: {}", email, dto.getBuildingTitleEn());  // Time being logged for debugging
            if (building == null) {
                log.info("No secured building found with this name: {}", dto.getBuildingTitleEn());  // Time being logged for debugging
                responseSecuredUserImportDTO
                    .addError("No secured building found with this name: " + dto.getBuildingTitleEn());
               
            }else{
                log.info("Mapping user email: {} to building ID: {}", email, building.getCdmKeyId());  // Time being logged for debugging
                userToImportedBuildingIds.computeIfAbsent(email, k -> new HashSet<>()).add(building.getCdmKeyId());
            }
        }
        testSecured(userToImportedBuildingIds, userByEmail, buildingByName, responseSecuredUserImportDTO);
        testBeta(emailsBuildingForBetaMap, buildingNamesForBeta, userToImportedBuildingIds, userByEmail, buildingByName, responseSecuredUserImportDTO);

        return ResponseEntity.ok(responseSecuredUserImportDTO);
    }

    private void testBeta(Map<String,String> emailsBuildingForBetaMap ,List<String> buildingNamesForBeta ,Map<String, Set<Long>> userToImportedBuildingIds, Map<String, User> userByEmail, Map<String, Building> buildingByName,
            ResponseSecuredUserImportDTO responseSecuredUserImportDTO   ) {
        // Test method implementation here

        userToImportedBuildingIds.forEach((email, buildingIds) -> log.info("User Email: {}, Imported Building IDs: {}", email, buildingIds));  // Time being logged for debugging
        Role betaUserRole = roleRepository.findByName(Constants.BETA_USER);
        Long betaUserRoleId = betaUserRole.getId();
        Set<String> importedUserEmails = userToImportedBuildingIds.keySet();
        List<User> usersWithSecuredRole = userRepository.findUsersWithRole(betaUserRoleId); // Implement this method!
        
        //importedUserEmails.forEach(email -> log.info("Imported User Email: {}", email)); // Time being logged for debugging
        // ✅ If user is NOT in the import anymore, remove all "Beta User" locations
        // for (User user : usersWithSecuredRole) {
        //     log.info("Checking user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
        //     if (!importedUserEmails.contains(user.getEmail())) { // User no longer in import
        //         log.info("Removing all 'Beta User' locations for user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
        //         List<UserRoleLocation> toRemove = userRoleLocationRepository
        //                 .findByUserId(user.getId())
        //                 .stream()
        //                 .filter(url -> url.getRoleId().equals(betaUserRoleId))
        //                 .collect(Collectors.toList());

        //         userRoleLocationRepository.deleteAll(toRemove);
        //     }
        // }
        //for (Map.Entry<String, Set<Long>> entry : userToImportedBuildingIds.entrySet()) {
        for (Map.Entry<String, String> betaEntry : emailsBuildingForBetaMap.entrySet()) {
            String email = betaEntry.getKey();
            log.info("Processing user in testBeta method before existingRoleLocations with email: {}", email);  // Time being logged for debugging
            //String buildingName = betaEntry.getValue();

            //User user = userByEmail.get(email);  // Need to commented
            User user = userService.getUserByEmail(email);
            if (user == null) {
                // Find the DTO for this user to get additional details
               // log.info("User not found in DB for email: {}. Creating new user.", email); // Time being logged for debugging
                Optional<SecuredUserImportDTO> optionalDto = responseSecuredUserImportDTO
                        .getSecuredUserImportDTOs()
                        .stream()
                        .filter(dto -> dto.getEmailId().equals(email))
                        .findFirst();

                if (optionalDto.isEmpty()) {
                    responseSecuredUserImportDTO.addError("User details missing for email: " + email);
                    continue;
                }

                SecuredUserImportDTO dto = optionalDto.get();

                user = new User();
                user.setFirstName(dto.getFirstName());
                user.setLastName(dto.getLastName());
                user.setEmail(email);
                user.setEnabled(true);
                user.setDeleted(false);
                user.setTokenExpired(false);
                user.setUserSecuredBuildings(new HashSet<>());
                user = userRepository.save(user);
                userByEmail.put(email, user);
            }

            // Fetch user's current role-location mappings
            List<UserRoleLocation> existingRoleLocations = userRoleLocationRepository.findByUserId(user.getId());
            List<Long> existingRoleIds = existingRoleLocations.stream().map(UserRoleLocation::getRoleId).collect(Collectors.toList());
            // Get "Secured User" role ID once (to avoid multiple DB queries)

            // Filter "Secured User" locations
        //     Set<Long> existingBuildingIds = existingRoleLocations
        //             .stream()
        //             //.peek(url -> System.out.println("existingBuildingIds - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
        //             .filter(url -> url.getRoleId().equals(betaUserRoleId)) // Compare IDs directly
        //             .map(UserRoleLocation::getCdmKeyId)
        //             .collect(Collectors.toSet());

        //     // Determine which locations to remove (only those with role name "Secured
        //     // User")
        //     List<UserRoleLocation> toRemove = existingRoleLocations
        //             .stream()
        //             //.peek(url -> System.out.println("toRemove - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
        //             .filter(url -> url.getRoleId().equals(betaUserRoleId)) // Compare IDs directly
        //             .filter(url -> !importedBuildingIds.contains(url.getCdmKeyId())) // Only remove missing locations
        //             .collect(Collectors.toList());

        //     // Remove outdated locations
        //    // log.info("Removing {} 'Secured User' locations for user: {} with email: {}", toRemove.size(), user.getId(), user.getEmail()); // Time being logged for debugging
        //     userRoleLocationRepository.deleteAll(toRemove);

            // Assign missing buildings
            //for (Long cdmKeyId : importedBuildingIds) {
           // for (UserRoleLocation existingRoleLocation : existingRoleLocations) {
                //log.info("Existing Role Locationid: {} user id: {} with Role ID: {} and CdmKeyId: {}", existingRoleLocation.getId(), existingRoleLocation.getUser().getId(), existingRoleLocation.getRoleId(), existingRoleLocation.getCdmKeyId());
                
            //}
               // if (!existingRoleLocation.getRoleId().equals(betaUserRoleId)) {
                if (!existingRoleIds.contains(betaUserRoleId)) {
                    UserRoleLocation newUserRoleLocation = new UserRoleLocation();
                    newUserRoleLocation.setRole(betaUserRole);
                    newUserRoleLocation.setUser(user);
                    newUserRoleLocation.setLevel(LevelEnum.GLOBAL);
                    newUserRoleLocation.setCdmKeyId(null);
                    log.info("Saving a user {} with GLOBAL role", user.getEmail());
                    userRoleLocationRepository.save(newUserRoleLocation);

                    // // Get the actual Building entity
                    // Building building = buildingByName
                    //         .values()
                    //         .stream()
                    //         .filter(b -> b.getCdmKeyId().equals(cdmKeyId))
                    //         .findFirst()
                    //         .orElse(null);

                    // if (building != null) {
                    //     log.info("Assigning user {} to building {} (CdmKeyId: {})", user.getEmail(), building.getTitleEn(), cdmKeyId);
                    //     this.userService.assignUserToBuilding(user, building);
                    // }
                    userService.sendEmailSecuredUserImport(user, Constants.BETA_USER, LevelEnum.GLOBAL.toString());
                }
           // }
            
        }
    }

    private void testSecured(Map<String, Set<Long>> userToImportedBuildingIds, Map<String, User> userByEmail, Map<String, Building> buildingByName,
            ResponseSecuredUserImportDTO responseSecuredUserImportDTO   ) {
        // Test method implementation here

        userToImportedBuildingIds.forEach((email, buildingIds) -> log.info("User Email: {}, Imported Building IDs: {}", email, buildingIds));  // Time being logged for debugging
        Role securedUserRole = roleRepository.findByName(Constants.SECURED_USER);
        Long securedUserRoleId = securedUserRole.getId();
        Set<String> importedUserEmails = userToImportedBuildingIds.keySet();
        List<User> usersWithSecuredRole = userRepository.findUsersWithRole(securedUserRoleId); // Implement this method!
        
        //importedUserEmails.forEach(email -> log.info("Imported User Email: {}", email)); // Time being logged for debugging
        // ✅ If user is NOT in the import anymore, remove all "Secured User" locations
        // for (User user : usersWithSecuredRole) {
        //     log.info("Checking user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
        //     if (!importedUserEmails.contains(user.getEmail())) { // User no longer in import
        //         log.info("Removing all 'Secured User' locations for user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
        //         List<UserRoleLocation> toRemove = userRoleLocationRepository
        //                 .findByUserId(user.getId())
        //                 .stream()
        //                 .filter(url -> url.getRoleId().equals(securedUserRoleId))
        //                 .collect(Collectors.toList());

        //         userRoleLocationRepository.deleteAll(toRemove);
        //     }
        // }
        for (Map.Entry<String, Set<Long>> entry : userToImportedBuildingIds.entrySet()) {
            String email = entry.getKey();
            log.info("Processing user in testSecured method with email: {}", email);  // Time being logged for debugging
            Set<Long> importedBuildingIds = entry.getValue();

            //User user = userByEmail.get(email);  // Need to commented
            User user = userService.getUserByEmail(email);
            log.info("Fetched user from userByEmail for email: {}: {}", email, user != null ? "Found" : "Not Found");  // Time being logged for debugging
            if (user == null) {
                // Find the DTO for this user to get additional details
               // log.info("User not found in DB for email: {}. Creating new user.", email); // Time being logged for debugging
                Optional<SecuredUserImportDTO> optionalDto = responseSecuredUserImportDTO
                        .getSecuredUserImportDTOs()
                        .stream()
                        .filter(dto -> dto.getEmailId().equals(email))
                        .findFirst();

                if (optionalDto.isEmpty()) {
                    responseSecuredUserImportDTO.addError("User details missing for email: " + email);
                    continue;
                }

                SecuredUserImportDTO dto = optionalDto.get();

                user = new User();
                user.setFirstName(dto.getFirstName());
                user.setLastName(dto.getLastName());
                user.setEmail(email);
                user.setEnabled(true);
                user.setDeleted(false);
                user.setTokenExpired(false);
                user.setUserSecuredBuildings(new HashSet<>());
                log.info("Creating new user with email: {}, firstName: {}, lastName: {}", email, dto.getFirstName(), dto.getLastName()); // Time being logged for debugging
                user = userRepository.save(user);
                userByEmail.put(email, user);
            }

            // Fetch user's current role-location mappings
            List<UserRoleLocation> existingRoleLocations = userRoleLocationRepository.findByUserId(user.getId());

            // Get "Secured User" role ID once (to avoid multiple DB queries)

            // Filter "Secured User" locations
            Set<Long> existingBuildingIds = existingRoleLocations
                    .stream()
                    //.peek(url -> System.out.println("existingBuildingIds - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
                    .filter(url -> url.getRoleId().equals(securedUserRoleId)) // Compare IDs directly
                    .map(UserRoleLocation::getCdmKeyId)
                    .collect(Collectors.toSet());

            // Determine which locations to remove (only those with role name "Secured
            // User")
        //     List<UserRoleLocation> toRemove = existingRoleLocations
        //             .stream()
        //             //.peek(url -> System.out.println("toRemove - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
        //             .filter(url -> url.getRoleId().equals(securedUserRoleId)) // Compare IDs directly
        //             .filter(url -> !importedBuildingIds.contains(url.getCdmKeyId())) // Only remove missing locations
        //             .collect(Collectors.toList());

        //     // Remove outdated locations
        //    // log.info("Removing {} 'Secured User' locations for user: {} with email: {}", toRemove.size(), user.getId(), user.getEmail()); // Time being logged for debugging
        //     userRoleLocationRepository.deleteAll(toRemove);

            // Assign missing buildings
            for (Long cdmKeyId : importedBuildingIds) {
                if (!existingBuildingIds.contains(cdmKeyId)) {
                    UserRoleLocation newUserRoleLocation = new UserRoleLocation();
                    newUserRoleLocation.setRole(securedUserRole);
                    newUserRoleLocation.setUser(user);
                    newUserRoleLocation.setLevel(LevelEnum.BUILDING);
                    newUserRoleLocation.setCdmKeyId(cdmKeyId);
                    log.info("Saving a user {} to building with CdmKeyId: {}", user.getEmail(), cdmKeyId);
                    userRoleLocationRepository.save(newUserRoleLocation);

                    // Get the actual Building entity
                    Building building = buildingByName
                            .values()
                            .stream()
                            .filter(b -> b.getCdmKeyId().equals(cdmKeyId))
                            .findFirst()
                            .orElse(null);

                    if (building != null) {
                        log.info("Assigning user {} to building {} (CdmKeyId: {})", user.getEmail(), building.getTitleEn(), cdmKeyId);
                        this.userService.assignUserToBuilding(user, building);
                    }
                }
            }
        }
    }

    @PostMapping("/import/secured-usersold") // Backu up
    public ResponseEntity<ResponseSecuredUserImportDTO> importSecuredUsersOLd(@RequestParam("file") MultipartFile file) {
        ResponseSecuredUserImportDTO responseSecuredUserImportDTO = new ResponseSecuredUserImportDTO();

        // Validate the uploaded file BEFORE it reaches downstream loops to prevent
        // attackers from supplying an unbounded/very large input that would cause
        // excessive iterations in checkCSVFormat / generateResponseSecuredUserImportDTO.
        if (file == null || file.isEmpty()) {
            responseSecuredUserImportDTO.addError("The uploaded file is empty.");
            return ResponseEntity.unprocessableEntity().body(responseSecuredUserImportDTO);
        }
        if (file.getSize() > MAX_SECURED_USERS_IMPORT_FILE_SIZE_BYTES) {
            responseSecuredUserImportDTO.addError(
                    "The uploaded file exceeds the maximum allowed size of "
                            + MAX_SECURED_USERS_IMPORT_FILE_SIZE_BYTES + " bytes.");
            return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(responseSecuredUserImportDTO);
        }

        Role securedRole = roleRepository.findByName(Constants.SECURED_USER);

        // Step 1: Validate CSV Format
        responseSecuredUserImportDTO.setErrorsInFile(this.userService.checkCSVFormat(file));
        if (!CollectionUtils.isEmpty(responseSecuredUserImportDTO.getErrorsInFile())) {
            log.info("CollectionUtils NOT Empty(responseSecuredUserImportDTO.getErrorsInFile()");
            return ResponseEntity.unprocessableEntity().body(responseSecuredUserImportDTO);
        }

        // Step 2: Parse CSV Data
        responseSecuredUserImportDTO = this.userService.generateResponseSecuredUserImportDTO(file);
        if (!CollectionUtils.isEmpty(responseSecuredUserImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responseSecuredUserImportDTO);
        }

        Set<String> emails = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .map(SecuredUserImportDTO::getEmailId)
                .collect(Collectors.toSet());

        Set<String> buildingNames = responseSecuredUserImportDTO
                .getSecuredUserImportDTOs()
                .stream()
                .map(SecuredUserImportDTO::getBuildingTitleEn)
                .collect(Collectors.toSet());

        // Fetch all users by email
        Map<String, User> userByEmail = userRepository
                .findAllByEmailIn(emails)
                .stream()
                .collect(Collectors.toMap(User::getEmail, user -> user));

        // Fetch all buildings by name
        buildingNames.forEach(name -> log.info("Building Name: {}", name));
        Map<String, Building> buildingByName = buildingRepository
                .findByTitleEnIgnoreCaseIn(buildingNames)
                .stream()
                .collect(Collectors.toMap(Building::getTitleEn, building -> building));
        // Log the content of the map
        if (buildingByName.isEmpty()) {
            log.info("No buildings found for the given names.");
        } else {
            buildingByName.forEach((name, building) -> log.info("Building Name: {}, Building Details: {}", name,
                    building.getTitleEn()));
        }
        // Step 3: Collect all user-location mappings from the import
        Map<String, Set<Long>> userToImportedBuildingIds = new HashMap<>();
        for (SecuredUserImportDTO dto : responseSecuredUserImportDTO.getSecuredUserImportDTOs()) {
            String email = dto.getEmailId();
            Building building = buildingByName.get(dto.getBuildingTitleEn());
            if (building == null) {
                responseSecuredUserImportDTO
                        .addError("No secured building found with this name: " + dto.getBuildingTitleEn());
                continue;
            }
            userToImportedBuildingIds.computeIfAbsent(email, k -> new HashSet<>()).add(building.getCdmKeyId());
        }
        userToImportedBuildingIds.forEach((email, buildingIds) -> log.info("User Email: {}, Imported Building IDs: {}", email, buildingIds));  // Time being logged for debugging
        Role securedUserRole = roleRepository.findByName(Constants.SECURED_USER);
        Long securedUserRoleId = securedUserRole.getId();
        Set<String> importedUserEmails = userToImportedBuildingIds.keySet();
        List<User> usersWithSecuredRole = userRepository.findUsersWithRole(securedUserRoleId); // Implement this method!
        
        //importedUserEmails.forEach(email -> log.info("Imported User Email: {}", email)); // Time being logged for debugging
        // ✅ If user is NOT in the import anymore, remove all "Secured User" locations
        for (User user : usersWithSecuredRole) {
            log.info("Checking user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
            if (!importedUserEmails.contains(user.getEmail())) { // User no longer in import
                log.info("Removing all 'Secured User' locations for user: {} with email: {}", user.getId(), user.getEmail()); // Time being logged for debugging
                List<UserRoleLocation> toRemove = userRoleLocationRepository
                        .findByUserId(user.getId())
                        .stream()
                        .filter(url -> url.getRoleId().equals(securedUserRoleId))
                        .collect(Collectors.toList());

                userRoleLocationRepository.deleteAll(toRemove);
            }
        }
        for (Map.Entry<String, Set<Long>> entry : userToImportedBuildingIds.entrySet()) {
            String email = entry.getKey();
            Set<Long> importedBuildingIds = entry.getValue();

            User user = userByEmail.get(email);
            if (user == null) {
                // Find the DTO for this user to get additional details
               // log.info("User not found in DB for email: {}. Creating new user.", email); // Time being logged for debugging
                Optional<SecuredUserImportDTO> optionalDto = responseSecuredUserImportDTO
                        .getSecuredUserImportDTOs()
                        .stream()
                        .filter(dto -> dto.getEmailId().equals(email))
                        .findFirst();

                if (optionalDto.isEmpty()) {
                    responseSecuredUserImportDTO.addError("User details missing for email: " + email);
                    continue;
                }

                SecuredUserImportDTO dto = optionalDto.get();

                user = new User();
                user.setFirstName(dto.getFirstName());
                user.setLastName(dto.getLastName());
                user.setEmail(email);
                user.setEnabled(true);
                user.setDeleted(false);
                user.setTokenExpired(false);
                user.setUserSecuredBuildings(new HashSet<>());
                user = userRepository.save(user);
                userByEmail.put(email, user);
            }

            // Fetch user's current role-location mappings
            List<UserRoleLocation> existingRoleLocations = userRoleLocationRepository.findByUserId(user.getId());

            // Get "Secured User" role ID once (to avoid multiple DB queries)

            // Filter "Secured User" locations
            Set<Long> existingBuildingIds = existingRoleLocations
                    .stream()
                    //.peek(url -> System.out.println("existingBuildingIds - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
                    .filter(url -> url.getRoleId().equals(securedUserRoleId)) // Compare IDs directly
                    .map(UserRoleLocation::getCdmKeyId)
                    .collect(Collectors.toSet());

            // Determine which locations to remove (only those with role name "Secured
            // User")
            List<UserRoleLocation> toRemove = existingRoleLocations
                    .stream()
                    //.peek(url -> System.out.println("toRemove - Existing Role Location: " + url.getId() + ", Role ID: " + url.getRoleId() + ", CdmKeyId: " + url.getCdmKeyId())) // Debugging log
                    .filter(url -> url.getRoleId().equals(securedUserRoleId)) // Compare IDs directly
                    .filter(url -> !importedBuildingIds.contains(url.getCdmKeyId())) // Only remove missing locations
                    .collect(Collectors.toList());

            // Remove outdated locations
           // log.info("Removing {} 'Secured User' locations for user: {} with email: {}", toRemove.size(), user.getId(), user.getEmail()); // Time being logged for debugging
            userRoleLocationRepository.deleteAll(toRemove);

            // Assign missing buildings
            for (Long cdmKeyId : importedBuildingIds) {
                if (!existingBuildingIds.contains(cdmKeyId)) {
                    UserRoleLocation newUserRoleLocation = new UserRoleLocation();
                    newUserRoleLocation.setRole(securedRole);
                    newUserRoleLocation.setUser(user);
                    newUserRoleLocation.setLevel(LevelEnum.BUILDING);
                    newUserRoleLocation.setCdmKeyId(cdmKeyId);
                    log.info("Saving a user {} to building with CdmKeyId: {}", user.getEmail(), cdmKeyId);
                    userRoleLocationRepository.save(newUserRoleLocation);

                    // Get the actual Building entity
                    Building building = buildingByName
                            .values()
                            .stream()
                            .filter(b -> b.getCdmKeyId().equals(cdmKeyId))
                            .findFirst()
                            .orElse(null);

                    if (building != null) {
                        log.info("Assigning user {} to building {} (CdmKeyId: {})", user.getEmail(), building.getTitleEn(), cdmKeyId);
                        this.userService.assignUserToBuilding(user, building);
                    }
                }
            }
        }

        return ResponseEntity.ok(responseSecuredUserImportDTO);
    }

    /**
     * Endpoint to unassign a web profile from a user.
     * 
     * This method performs the following steps:
     * Checks if the user has a web profile (`hasWebUserProfile` flag).
     * If true, retrieves the user by email from the provided `UserDTO`.
     * Calls the service method to unassign the user's profile.
     * Converts the updated user entity to a `UserDTO` including role-location
     * details.
     * Returns the updated user data with HTTP 200 OK status.
     * 
     * If the user does not have a web profile, it throws a
     * `ResponseStatusException` with HTTP 404.
     * Any unexpected errors are logged and returned with HTTP 500 Internal Server
     * Error.
     * 
     * @param userDTO           The data transfer object containing user information
     *                          (primarily email).
     * @param hasWebUserProfile Boolean flag indicating if the user has a web
     *                          profile assigned.
     * @param language          Optional request header to specify the language for
     *                          localization (default is "en").
     * @return ResponseEntity containing the updated user data or an error message.
     */

    @DeleteMapping("/unassignProfile")
    public ResponseEntity<?> unassignProfile(
            @RequestBody UserDTO userDTO,
            @RequestParam Boolean hasWebUserProfile,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        try {
            if (hasWebUserProfile) {

                List<Long> roleIds = userDTO.getRoleLocations()
                .stream()
                .map(roleLocation -> roleLocation.getRole().getId())
                .collect(Collectors.toList());
                for (Long roleId : roleIds) {
                    log.info("Role ID to unassign: {}", roleId);
                }
                String roleName = userDTO.getRoleLocations().get(0).getRole().getName();
                Long roleId = roleRepository.findByName(roleName).getId();
                log.info("Unassigning profile for user with email: {}, roleId: {}", userDTO.getEmail(), roleId);
                User user = userService.getActiveUserByEmail(userDTO.getEmail());
                userRoleLocationService.unassignSoSpecialRoleLocation(user.getId(), roleId); // Existing remove single
                //userRoleLocationService.unassignSoSpecialRoleLocation(user.getId(), roleIds); // New remove multiple
                userProfileService.unassignSoSpecialProfiles(user.getId(), userDTO, roleId); // old removing only single
                //userProfileService.unassignSoSpecialProfiles(user.getId(), userDTO, roleIds); // new removing multiple
                UserDTO newUserDTO = userService.toUserDTOWithRoleLocations(user, language);
                return ResponseEntity.status(HttpStatus.OK).body(newUserDTO);
            } else {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Please select a web profile.");
            }

        } catch (Exception e) {
            log.error("Unexpected error while Unassigning profiles", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonMap("error", "An unexpected error occurred " + e));
        }
    }

    @GetMapping("/{id}/locations")
    public ResponseEntity<List<LocationDTO>> getUserLocationsById(@PathVariable Long id) {
        List<LocationDTO> locations = userService.getUserLocationsById(id);
        return ResponseEntity.ok(locations);
    }

    // Update UserRoleLocation API
    @PutMapping("/{userId}/roleLocations")
    public ResponseEntity<UserRoleLocationDTO> updateUserRoleLocations(@PathVariable Long userId,
            @Valid @RequestBody UserRoleLocationUpdateInput userRoleLocationDTO) {
        if (Objects.isNull(userRoleLocationDTO)) {
            return ResponseEntity.badRequest().build();
        }
        // Sanitize incoming input with value-creating copies
        Long sanitizedUserId = userId == null ? null : Long.valueOf(String.valueOf(userId));
        Boolean sanitizedSubscribeAlert = userRoleLocationDTO.getSubscribeAlert() == null
                ? null
                : Boolean.valueOf(String.valueOf(userRoleLocationDTO.getSubscribeAlert()));
        List<LocationDTO> sanitizedLocations = new ArrayList<>();

        if (Objects.nonNull(userRoleLocationDTO.getLocations())) {
            for (UserRoleLocationUpdateLocationInput incomingLocation : userRoleLocationDTO.getLocations()) {
                if (Objects.isNull(incomingLocation)) {
                    continue;
                }
                LocationDTO sanitizedLocation = new LocationDTO();
                sanitizedLocation.setLevel(incomingLocation.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(incomingLocation.getLevel().name())));
                sanitizedLocation.setCdmKeyId(incomingLocation.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(incomingLocation.getCdmKeyId()));
                sanitizedLocations.add(sanitizedLocation);
            }
        }
        UserRoleLocationDTO updatedDTO = userService.updateUserRoleLocations(
                sanitizedUserId,
                sanitizedSubscribeAlert,
                sanitizedLocations);


        return ResponseEntity.ok(updatedDTO);
    }


    @PostMapping("/assignProfile")
    public ResponseEntity<?> assignProfile(
            @Valid @RequestBody UserWriteInput userDTO,
            @RequestParam(required = false) Boolean hasWebUserProfile,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        try {
            // Sanitize incoming User input: copy only allowed fields with value-creating calls
            UserDTO sanitizedUserDTO = toSanitizedUserDTO(userDTO);
            // Step 1: Assign profile
            User savedUser = userService.assignProfile(sanitizedUserDTO, hasWebUserProfile);

            // Step 2: Convert to DTO for response
            UserDTO newUserDTO = userService.toUserDTOWithRoleLocations(savedUser, language);

            // Step 3: Set response status
            HttpStatus status = (sanitizedUserDTO.getId() == null) ? HttpStatus.CREATED : HttpStatus.OK;
            return ResponseEntity.status(status).body(newUserDTO);

        } catch (Exception e) {
            log.error("Unexpected error in user creation", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonMap("error", "An unexpected error occurred: " + e.getMessage()));
        }
    }


    private UserDTO toSanitizedUserDTO(UserWriteInput input) {

        UserDTO sanitizedUserDTO = new UserDTO();
    
        sanitizedUserDTO.setId(
                input.getId() == null ? null : Long.valueOf(input.getId()));
    
        sanitizedUserDTO.setFirstName(
                input.getFirstName() == null ? null : String.valueOf(input.getFirstName()));
    
        sanitizedUserDTO.setLastName(
                input.getLastName() == null ? null : String.valueOf(input.getLastName()));
    
        sanitizedUserDTO.setEmail(
                input.getEmail() == null ? null : String.valueOf(input.getEmail()));
    
        sanitizedUserDTO.setCountry(
                input.getCountry() == null ? null : String.valueOf(input.getCountry()));

        sanitizedUserDTO.setUserType(
                input.getUserType() == null ? null : Integer.valueOf(input.getUserType()));
    
        sanitizedUserDTO.setEnabled(
                input.getEnabled() != null ? input.getEnabled() : false);
    
        sanitizedUserDTO.setTokenExpired(
                input.getTokenExpired() != null ? input.getTokenExpired() : false);
    
        sanitizedUserDTO.setSubscribeAlert(
                input.getSubscribeAlert() == null
                        ? null
                        : Boolean.valueOf(String.valueOf(input.getSubscribeAlert())));
    
        List<com.capgemini.admin.back.model.RoleLocationDTO> sanitizedRoleLocations = new ArrayList<>();
    
        if (input.getRoleLocations() != null) {
    
            for (UserRoleLocationInput roleLocationInput : input.getRoleLocations()) {
    
                if (roleLocationInput == null
                        || roleLocationInput.getRole() == null
                        || roleLocationInput.getRole().getId() == null) {
                    continue;
                }
    
                com.capgemini.admin.back.model.RoleLocationDTO sanitizedRoleLocation =
                        new com.capgemini.admin.back.model.RoleLocationDTO();

                com.capgemini.admin.back.model.RoleDTO sanitizedRole =
                        new com.capgemini.admin.back.model.RoleDTO();
    
                sanitizedRole.setId(
                        Long.valueOf(roleLocationInput.getRole().getId()));
    
                sanitizedRole.setName(
                        roleLocationInput.getRole().getName() == null
                                ? null
                                : String.valueOf(roleLocationInput.getRole().getName()));
    
                sanitizedRoleLocation.setRole(sanitizedRole);
    
                List<LocationDTO> sanitizedLocations = new ArrayList<>();
    
                if (roleLocationInput.getLocations() != null) {
    
                    for (UserLocationInput locationInput : roleLocationInput.getLocations()) {
    
                        if (locationInput == null) {
                            continue;
                        }
    
                        LocationDTO locationDTO = new LocationDTO();
    
                        locationDTO.setId(
                                locationInput.getId() == null
                                        ? null
                                        : Long.valueOf(locationInput.getId()));
    
                        locationDTO.setLevel(
                                locationInput.getLevel() == null
                                        ? null
                                        : LevelEnum.valueOf(locationInput.getLevel().name()));
    
                        locationDTO.setCdmKeyId(
                            locationInput.getCdmKeyId() == null
                                        ? null
                                        : Long.valueOf(locationInput.getCdmKeyId()));
    
                        locationDTO.setAlertStatus(
                                locationInput.getAlertStatus() == null
                                        ? null
                                        : Boolean.valueOf(locationInput.getAlertStatus()));
    
                        sanitizedLocations.add(locationDTO);
                    }
                }
    
                sanitizedRoleLocation.setLocations(sanitizedLocations);
                sanitizedRoleLocations.add(sanitizedRoleLocation);
            }
        }
    
        sanitizedUserDTO.setRoleLocations(sanitizedRoleLocations);
    
        return sanitizedUserDTO;
    }

    @PostMapping("/deleteadminuserinorg")
    public ResponseEntity<?> removeUser(){
        deleteUsersActionJob.execJob();
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }


}
