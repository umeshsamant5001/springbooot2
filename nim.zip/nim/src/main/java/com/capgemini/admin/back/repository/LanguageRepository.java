package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.Language;

@Repository
public interface LanguageRepository extends JpaRepository<Language, Long> {

    List<Language> findAllByLocaleIn(List<String> locale);
}
