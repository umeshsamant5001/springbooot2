package com.capgemini.admin.back.service;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.TabletImportAudit;
import com.capgemini.admin.back.model.TabletImportDTO;
import com.capgemini.admin.back.repository.TabletImportAuditRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TabletImportAuditService {

    @Autowired
    private TabletImportAuditRepository tabletImportAuditRepository;

    /**
     * Audits changes before updating or inserting TabletImport data.
     * Compares existing values with new DTO values and logs differences.
     *
     * @param dto          TabletImportDTO containing new values
     * @param headersArray Array of header names for audit details
     * @param email        Email of the user performing the action
     */
    public void tabletImportAuditBeforeUpdate(TabletImportDTO dto, String[] headersArray, String email) {
        List<Object[]> poiDeviceAttributeList = tabletImportAuditRepository
                .fetchTabletImportAuditPoiDeviceAttribute(dto.getPoiName(), dto.getUuid());

        // Map of field names to new values from DTO
        Map<String, Object> newValuesMap = Map.ofEntries(
                Map.entry("bookable", dto.isBookable()),
                Map.entry("checkIn", dto.isCheckIn()),
                Map.entry("checkInDuration", dto.getCheckInDuration()),
                Map.entry("earlyCheckIn", dto.getEarlyCheckIn()),
                Map.entry("checkOut", dto.isCheckOut()),
                Map.entry("showState", dto.isShowState()),
                Map.entry("showTemp", dto.isShowTemp()),
                Map.entry("showHumidity", dto.isShowHumidity()),
                Map.entry("showSound", dto.isShowSound()),
                Map.entry("showCo2", dto.isShowCo2()),
                Map.entry("showLux", dto.isShowLux()),
                Map.entry("reportAnIssue", dto.isReportAnIssue()));

        StringJoiner oldValue = new StringJoiner(",");
        StringJoiner newValue = new StringJoiner(",");

        if (!poiDeviceAttributeList.isEmpty()) {
            // Compare old and new values for UPDATE
            for (Object[] objectArr : poiDeviceAttributeList) {
                String header = String.valueOf(objectArr[1]);
                String oldVal = String.valueOf(objectArr[2]);
                String poiDetail = headersArray[1] + ":" + objectArr[3];

                if (newValuesMap.containsKey(header)) {
                    Object newValObj = newValuesMap.get(header);
                    if (!oldVal.equals(String.valueOf(newValObj))) {
                        addTabletImportAuditEntry(oldValue, newValue, poiDetail, header, oldVal, newValObj,
                                headersArray);
                    }
                }
            }

            if (oldValue.length() > 0 || newValue.length() > 0) {
                saveTabletImportAudit(dto.getPoiName(), "UPDATED", oldValue.toString(), newValue.toString(), email);
            }
        } else {
            // INSERT case: Add UUID and all new values
            newValue.add(headersArray[1] + ":" + dto.getUuid());
            newValuesMap.forEach((key, val) -> newValue.add(key + ":" + val));
            saveTabletImportAudit(dto.getPoiName(), "INSERTED", null, newValue.toString(), email);
        }
    }

    /**
     * Adds audit entry details for changed fields.
     *
     * @param oldValue     StringJoiner for old values
     * @param newValue     StringJoiner for new values
     * @param poiDetail    POI detail string
     * @param header       Field name
     * @param oldVal       Old value
     * @param newValObj    New value
     * @param headersArray Array of headers
     */
    private void addTabletImportAuditEntry(StringJoiner oldValue, StringJoiner newValue, String poiDetail,
            String header, String oldVal, Object newValObj, String[] headersArray) {
        addIfAbsent(oldValue, poiDetail);
        addIfAbsent(newValue, poiDetail);
        oldValue.add(header + ":" + oldVal);
        newValue.add(header + ":" + newValObj);
    }

    /**
     * Saves audit record to the database.
     *
     * @param poiName POI name
     * @param action  Action performed (INSERTED/UPDATED)
     * @param oldVal  Old values string
     * @param newVal  New values string
     * @param email   User email
     */
    private void saveTabletImportAudit(String poiName, String action, String oldVal, String newVal, String email) {
        TabletImportAudit audit = new TabletImportAudit();
        audit.setPoiName(poiName);
        audit.setActivityDateTime(System.currentTimeMillis() / 1000);
        audit.setAction(action);
        audit.setOldValue(oldVal);
        audit.setNewValue(newVal);
        audit.setEmail(email);
        tabletImportAuditRepository.saveAndFlush(audit);
    }

    /**
     * Adds text to StringJoiner if not already present.
     *
     * @param joiner StringJoiner instance
     * @param text   Text to add
     */
    private void addIfAbsent(StringJoiner joiner, String text) {
        if (!joiner.toString().contains(text)) {
            joiner.add(text);
        }
    }

    /**
     * Retrieves all field names from TabletImportDTO using reflection.
     *
     * @param dto TabletImportDTO instance
     * @return Array of field names
     */
    public String[] getHeaders(TabletImportDTO dto) {
        return Arrays.stream(dto.getClass().getDeclaredFields())
                .map(Field::getName)
                .toArray(String[]::new);
    }

}