package com.capgemini.admin.back.security.jwt;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.model.UserRoleLocation;
import com.capgemini.admin.back.repository.AuthenticationExceptionRepository;
import com.capgemini.admin.back.security.jwt.model.AuthFailureException;
import com.capgemini.admin.back.security.jwt.model.AuthenticationException;
import com.capgemini.admin.back.security.jwt.model.UserInformation;
import com.capgemini.admin.back.service.UserRoleLocationService;
import com.capgemini.admin.back.service.UserService;
import com.google.gson.JsonObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private Environment environment;

    @Autowired
    private AuthenticationExceptionRepository authenticationExceptionRepository;

    @Autowired
    private JWTSignatureValidation jwtSignatureValidation;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleLocationService userRoleLocationService;

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            extractAndValidateToken(request, response);
        } catch (AuthFailureException e) {
            // authentication failed, build and return a 401 response with error json body
            sendErrorResponse(HttpStatus.UNAUTHORIZED, response, e);
            return;
        }
        chain.doFilter(request, response);
    }

    /**
     * Decrypt and validate JWT token and store the user to security context
     *
     * @param request
     */
    private void extractAndValidateToken(HttpServletRequest request, HttpServletResponse response) {
        if (this.environment.acceptsProfiles(Profiles.of("noAuth"))) {
            return;
        }

        if (Objects.isNull(jwtSignatureValidation)) {
            jwtSignatureValidation = new JWTSignatureValidation();
        }
        String authToken = jwtSignatureValidation.getAuthHeader(request);
        if (Objects.isNull(authToken)) {
            throw new AuthFailureException(String.format("No token found from request %s", request.getRequestURI()));
        }
        authToken = authToken.replaceFirst("Bearer ", "");
        // Below If else block need to be used once we get client id and client secret
        // from OP team:
        if (request.getRequestURI().startsWith("/api/pushnotificationext")) {
            jwtSignatureValidation.validateWithPingIdForExternalApp(authToken);
        } else {
            JSONObject pingIdResponse = jwtSignatureValidation.validateWithPingId(authToken);
            this.setCurrentUser(pingIdResponse);
        }
        // JSONObject pingIdResponse =
        // jwtSignatureValidation.validateWithPingId(authToken);
        // this.setCurrentUser(pingIdResponse);

    }

    private void setCurrentUser(JSONObject pingIdResponse) {
        String email = (String) pingIdResponse.get("iss");
        UserInformation userInformation = new UserInformation(email);

        User user = this.userService.getUserByEmail(email);
        List<GrantedAuthority> authorities = new ArrayList<>();
        if (Objects.isNull(user)) {
            throw new AuthFailureException("User is not authorized");
        }

        List<UserRoleLocation> userRoleLocations = this.userRoleLocationService.findByUserId(user.getId());
        Set<String> names = new HashSet<String>();
        userRoleLocations.forEach(u -> {
            String name = u.getRole().getName();
            if (!names.contains(name)) {
                names.add(name);
            }
        });

        authorities = names
                .stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userInformation,
                null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);

    }

    private void sendErrorResponse(HttpStatus status, HttpServletResponse response, AuthFailureException ex) {

        authenticationExceptionRepository.save(new AuthenticationException(
                HttpStatus.UNAUTHORIZED.value(),
                ex.getErrorCode(),
                ex.getMessage(),
                System.currentTimeMillis() / 1000));
        response.setStatus(status.value());
        response.setContentType("application/json");
        response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        try {
            response.getWriter().write(buildErrorJson().toString());
        } catch (IOException e) {
            log.error(String.format("Authentication: failed to build error json response: %s", e.getMessage()));
        }
    }

    private JsonObject buildErrorJson() {
        log.error("Authentication failed");
        JsonObject json = new JsonObject();
        json.addProperty("errorCode", 1000);
        json.addProperty("message", "Authentication failed");
        json.addProperty("exception", "AuthenticationException");

        return json;
    }


}
