package com.capgemini.admin.back.helper;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;

/**
 * Class used to calculate correct average from values.
 */
@Slf4j
public class AverageValues {
    Map<String, Double> mapSum;
    Map<String, Integer> mapNumber;

    public AverageValues() {
        this.mapSum = new HashMap<>();
        this.mapNumber = new HashMap<>();
    }

    public void addValue(String valueName, Double... values) {
        Integer nbNonNull = 0;
        Double sum = 0.0;

        for (Double value : values) {
            if (Objects.nonNull(value)) {
                nbNonNull++;
                sum += value;
            }
        }

        if (nbNonNull > 0) {
            if (this.mapNumber.containsKey(valueName)) {
                nbNonNull += this.mapNumber.get(valueName);
                sum += this.mapSum.get(valueName);
            }

            this.mapNumber.put(valueName, nbNonNull);
            this.mapSum.put(valueName, sum);
        }
    }

    public void addValue(String valueName, String... values) {
        Double[] doubleValues = new Double[values.length];

        for (int i = 0; i < values.length; i++) {
            String value = values[i];

            // Try parsing the string to a Double; if it fails, set the entry to null
            if (value == null || value.isEmpty()) {
                doubleValues[i] = null;
            } else {
                try {
                    doubleValues[i] = Double.parseDouble(value);
                } catch (NumberFormatException e) {
                    // If parsing fails, log and set to null
                    String safeValue = sanitizeForLog(value);
                    log.info("Warning: Unable to parse '{}' as a Double. Setting to null.", safeValue);
                    doubleValues[i] = null;
                }

            }
        }

        this.addValue(valueName, doubleValues);
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

    public Double getAverage(String valueName) {

        if (!this.mapNumber.containsKey(valueName)) {
            return null;
        }

        Integer nbValue = this.mapNumber.get(valueName);
        Double sum = this.mapSum.get(valueName);

        return sum / nbValue;
    }
}
