package com.capgemini.admin.back.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.AllLocationsByUser;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.UserRoleLocation;

@Repository
public interface UserRoleLocationRepository extends JpaRepository<UserRoleLocation, Long> {

        public List<UserRoleLocation> findByUserId(Long userId);

        public void deleteAllByUserId(Long userId);

        @Modifying
        @Transactional
        @Query(value = "DELETE ur FROM user_role_location ur INNER JOIN role r ON ur.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR  r.is_web_user_profile = 'false') " +
                        "  AND ur.user_id = :userId", nativeQuery = true)
        public void adminProfileDeletedByUserId(@Param("userId") Long userId);

        @Query(value = "SELECT (CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END) AS nbGlobal FROM user_role_location "
                        + " WHERE user_id = :userId AND level = 'GLOBAL'", nativeQuery = true)
        public Integer userIsGlobal(@Param("userId") Long userId);

        /**
         * Query to return all the id of the Country, City, Site and Building available
         * by the user. Return also the level from which the location is authorized
         * 
         * @param userId Id of the user
         * @return
         */
        @Query(value = "SELECT (CASE WHEN url_country.level IS NOT NULL THEN 1 ELSE 0 END) AS countryLevel, "
                        + " country.id AS countryId, (CASE WHEN url_city.level IS NOT NULL THEN 1 ELSE 0 END) AS cityLevel, "
                        + " city.id AS cityId, (CASE WHEN url_site.level IS NOT NULL THEN 1 ELSE 0 END) AS siteLevel, "
                        + " site.id AS siteId, (CASE WHEN url_building.level IS NOT NULL THEN 1 ELSE 0 END) AS buildingLevel, "
                        + " building.id AS buildingId FROM country "
                        + " LEFT JOIN user_role_location AS url_country ON (url_country.cdm_key_id = country.cdm_key_id and url_country.level = 'COUNTRY' AND url_country.user_id = :userId) "
                        + " LEFT JOIN city ON (country.id = city.country_id) "
                        + " LEFT JOIN user_role_location AS url_city ON (url_city.cdm_key_id = city.cdm_key_id and url_city.level = 'CITY' AND url_city.user_id = :userId) "
                        + " LEFT JOIN site ON (city.id = site.city_id) "
                        + " LEFT JOIN user_role_location AS url_site ON (url_site.cdm_key_id = site.cdm_key_id and url_site.level = 'SITE' AND url_site.user_id = :userId) "
                        + " LEFT JOIN building ON (site.id = building.site_id) "
                        + " LEFT JOIN user_role_location AS url_building ON (url_building.cdm_key_id = building.cdm_key_id and url_building.level = 'BUILDING' AND url_building.user_id = :userId) "
                        + " WHERE  url_country.level IS NOT NULL OR url_city.level IS NOT NULL OR url_site.level IS NOT NULL OR url_building.level IS NOT NULL", nativeQuery = true)
        public List<AllLocationsByUser> getAllLocationsByUser(@Param("userId") Long userId);

        @Query(value = "SELECT floor.id "
                        + " FROM country LEFT JOIN city ON (country.id = city.country_id) LEFT JOIN site ON (city.id = site.city_id) "
                        + " LEFT JOIN building ON (site.id = building.site_id) LEFT JOIN floor ON (building.id = floor.building_id) WHERE "
                        + " (country.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) "
                        + " OR city.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) "
                        + " OR site.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) "
                        + " OR building.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)) "
                        + " AND floor.id IN (:floorIds)", nativeQuery = true)
        public List<Long> filterAuthorizedFloorId(@Param("userId") Long userId, @Param("floorIds") List<Long> floorIds);

        @Query(value = "SELECT poi.id "
                        + " FROM country LEFT JOIN city ON (country.id = city.country_id) LEFT JOIN site ON (city.id = site.city_id) "
                        + " LEFT JOIN building ON (site.id = building.site_id) LEFT JOIN floor ON (building.id = floor.building_id) "
                        + " LEFT JOIN poi ON (floor.id = poi.floor_id) WHERE "
                        + " (country.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) "
                        + " OR city.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) "
                        + " OR site.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) "
                        + " OR building.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)) "
                        + " AND poi.id IN (:poiIds)", nativeQuery = true)
        public List<Long> filterAuthorizedPoiId(@Param("userId") Long userId, @Param("poiIds") List<Long> poiIds);

        @Query(value = "SELECT device.uuid "
                        + " FROM country LEFT JOIN city ON (country.id = city.country_id) LEFT JOIN site ON (city.id = site.city_id) "
                        + " LEFT JOIN building ON (site.id = building.site_id) LEFT JOIN floor ON (building.id = floor.building_id) "
                        + " LEFT JOIN poi ON (floor.id = poi.floor_id) LEFT JOIN device ON (poi.name = device.poi_name) WHERE "
                        + " (country.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) "
                        + " OR city.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) "
                        + " OR site.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) "
                        + " OR building.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)) "
                        + " AND device.uuid IN (:deviceUuids)", nativeQuery = true)
        public List<String> filterAuthorizedDeviceId(@Param("userId") Long userId,
                        @Param("deviceUuids") List<String> deviceUuids);

        // Implement site tree-based filtration logic to validate users during the
        // CiscoDevice query execution.
        @Query(value = " SELECT cd.mac_address FROM country " +
                        " LEFT JOIN city ON (country.id = city.country_id) " +
                        " LEFT JOIN site ON (city.id = site.city_id) " +
                        " LEFT JOIN building ON (site.id = building.site_id) " +
                        " LEFT JOIN building_attribute ba  ON building.id = ba.building_id and ba.att_key = 'cdm.asset_code' "
                        +
                        " LEFT JOIN floor ON (building.id = floor.building_id) " +
                        " LEFT JOIN poi p ON p.floor_id = floor.id " +
                        " LEFT  JOIN poi_attributes pa ON pa.poi_id = p.id " +
                        " LEFT join cisco_device cd on cd.email_id = pa.att_value " +
                        " LEFT JOIN space_type st on p.space_type_id = st.id " +
                        " WHERE " +
                        " (country.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) "
                        +
                        " OR city.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) "
                        +
                        " OR site.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) "
                        +
                        " OR building.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)) "
                        +
                        " AND cd.mac_address IN (:deviceIds)", nativeQuery = true)
        public List<String> filterAuthorizedCiscoDeviceByDeviceId(@Param("userId") Long userId,
                        @Param("deviceIds") List<String> deviceIds);

        @Query("SELECT url FROM UserRoleLocation url WHERE url.userId = :userId AND url.roleId = :roleId")
        List<UserRoleLocation> findByUserIdAndRoleId(@Param("userId") Long userId, @Param("roleId") Long roleId);

        @Query("SELECT url FROM UserRoleLocation url WHERE url.userId = :userId AND url.roleId = :roleId AND url.cdmKeyId = :cdmKeyId AND url.level = :level")
        List<UserRoleLocation> findByIdAndLevel(@Param("userId") Long userId, @Param("roleId") Long roleId,
                        @Param("cdmKeyId") Long cdmKeyId, @Param("level") LevelEnum level);

        @Modifying
        @Transactional
        @Query(value = "DELETE ur FROM user_role_location ur INNER JOIN role r ON ur.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR  r.is_web_user_profile = 'true') " +
                        "AND ur.user_id = :userId AND ur.role_id = :roleId", nativeQuery = true)
        public void unassignSoSpecialRoleLocation(@Param("userId") Long userId, @Param("roleId") Long roleId);


        @Modifying
        @Transactional
        @Query(value = "DELETE ur FROM user_role_location ur INNER JOIN role r ON ur.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR  r.is_web_user_profile = 'true') " +
                        "AND ur.user_id = :userId AND ur.role_id in :roleIds", nativeQuery = true)
        public void unassignSoSpecialRoleLocation(@Param("userId") Long userId, @Param("roleIds") List<Long> roleIds);
}