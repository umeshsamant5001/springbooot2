package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.ErrorLogging;

@Repository
public interface ErrorLoggingRepository extends JpaRepository<ErrorLogging, Long> {

}
