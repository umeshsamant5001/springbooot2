package com.capgemini.admin.back.scheduled.scheduled;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;

public abstract class ScheduledAction<N extends Scheduled, S extends ScheduledSent> {
    protected N scheduled;
    protected S lastScheduledSent;
    protected Date now;

    /**
     * Check if the Scheduled is of the current type
     * 
     * @return True if the Scheduled is of the current type, false otherwise
     */
    abstract public boolean checkType(N scheduled);

    public ScheduledAction<N, S> getAction(N scheduled, S lastScheduledSent, Date now) {
        try {
            ScheduledAction<N, S> action = this.getClass().getDeclaredConstructor().newInstance();
            action.setScheduled(scheduled, lastScheduledSent, now);

            return action;
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e) {
            return null;
        }
    }

    public N getScheduled() {
        return this.scheduled;
    }

    private void setScheduled(N scheduled, S lastScheduledSent, Date now) {
        this.scheduled = scheduled;
        this.lastScheduledSent = lastScheduledSent;
        this.now = now;
    }

    /**
     * Check if the Scheduled should be sent now.
     * 
     * @return True if the Scheduled should be sent, false otherwise
     */
    abstract public boolean shouldBeSent();

    /**
     * Check if it was the last sent of the Scheduled.
     * 
     * This function is launched only when a Scheduled was sent.
     * 
     * @return True if it was the last sent, false otherwise.
     */
    abstract public boolean wasLastSent();
}
