package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Set;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

	long countBySiteId(@Param("siteId") Long siteId);

	Building findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	List<Building> findByIdIn(List<Long> buildingIdList);

	/** To optimize query, we force the use of a JOIN for the OpeningHours */
	@Query("SELECT building FROM Building building LEFT JOIN FETCH building.information.openingHours")
	List<Building> findAll();

	@Query("SELECT building.cdmKeyId, building.titleEn AS name FROM Building building WHERE building.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);

	@Query("SELECT INDEX(attributes), attributes FROM Building building INNER JOIN building.attributes attributes WHERE building.id = :buildingId")
	List<Tuple> getAttributesById(@Param("buildingId") Long buildingId);

	@Query(value = "SELECT REPLACE(country.title_en, ',', ' ') AS country_title, REPLACE(city.title_en, ',', ' ') AS city_title, REPLACE(site.title_en, ',', ' ') AS site_title, "
			+ " REPLACE(building.title_en, ',', ' ') AS building_title, building.deployed, "
			+ " building.secured, alertBuilding.att_value AS alert_checking, opening_hours.opening, opening_hours.closing, "
			+ " building.limit_in_day AS days_limit, building.capacity "
			+ " FROM country INNER JOIN city ON (country.id = city.country_id) INNER JOIN site ON (city.id = site.city_id) "
			+ " INNER JOIN building ON (site.id = building.site_id) LEFT JOIN opening_hours ON (building.id_opening_hours = opening_hours.id) "
			+ " LEFT JOIN building_attribute AS daysLimit ON (building.id = daysLimit.building_id AND daysLimit.att_key = 'daysLimit') "
			+ " LEFT JOIN building_attribute AS alertBuilding ON (building.id = alertBuilding.building_id AND alertBuilding.att_key = 'checkin.alert.building') "
			+ " ORDER BY country.title_en, city.title_en, site.title_en, building.title_en", nativeQuery = true)
	List<List<String>> getExportAll();

	@Query(value = "SELECT b.* from country c inner join city ct on c.id = ct.country_id inner join site s on s.city_id = ct.id inner join building b on b.site_id = s.id WHERE c.id = :countryId", nativeQuery = true)
	List<Building> findAllBuildings(@Param("countryId") Long countryId);

	@Query(value = "SELECT b.* from country c inner join city ct on c.id = ct.country_id inner join site s on s.city_id = ct.id inner join building b on b.site_id = s.id WHERE b.global=1 AND c.id = :countryId", nativeQuery = true)
	List<Building> findAllBuildingsGlobal(@Param("countryId") Long countryId);

	@Query(value = "SELECT b.* from country c inner join city ct on c.id = ct.country_id inner join site s on s.city_id = ct.id inner join building b on b.site_id = s.id WHERE b.global=0 AND c.id = :countryId", nativeQuery = true)
	List<Building> findAllBuildingsLocal(@Param("countryId") Long countryId);

	@Query("SELECT city.countryId FROM Building building JOIN building.site site JOIN site.city city WHERE building.id = :buildingId")
	Long findCountryIdByBuildingId(@Param("buildingId") Long buildingId);

	List<Building> findByTitleEnIgnoreCaseIn(Set<String> buildinsgNames);


	@Query(value = "select LEFT(att_value, LEN(att_value) - 2) AS modified_att_value " +
			"from building_attribute  where building_id in ( " +
			"select distinct building_id from floor where id in (" +
			"select floor_id from poi where space_type_id = ( " +
			"select id from space_type where space_type_name ='locker' ))) " +
			"and att_key = 'cdm.asset_code'", nativeQuery = true)
	List<String> findllBuildingsWithLockers();
}
