package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class AlertDTO {
    private Integer interval;
    private AlertType alertType;
    private Boolean enabled;
    private Long thresholdConfigurationId;
}
