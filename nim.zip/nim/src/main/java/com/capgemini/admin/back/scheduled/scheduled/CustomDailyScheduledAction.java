package com.capgemini.admin.back.scheduled.scheduled;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.time.DateUtils;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;

/**
 * Class for the type of Scheduled to send "custom daily".
 */
public class CustomDailyScheduledAction<N extends Scheduled, S extends ScheduledSent> extends ScheduledAction<N, S> {

    public boolean checkType(N scheduled) {
        return scheduled.getAttributes().containsKey("day")
                && !scheduled.getAttributes().containsKey("month");
    }

    @Override
    public boolean shouldBeSent() {
        // Get the start date
        Date startDate = this.getRealStartDate();
        // If present, get the end date
        Date endDate = this.getRealEndDate();

        if (DateUtils.truncatedCompareTo(this.now, startDate, Calendar.DAY_OF_MONTH) < 0
                || Objects.nonNull(endDate)
                        && DateUtils.truncatedCompareTo(this.now, endDate, Calendar.DAY_OF_MONTH) > 0) {
            // We are outside of the date range
            return false;
        }

        if (Objects.nonNull(this.lastScheduledSent)) {
            Date sentAt = new Date(this.lastScheduledSent.getSentAt() * 1000);
            if (DateUtils.truncatedCompareTo(this.now, sentAt, Calendar.DAY_OF_MONTH) == 0) {
                // A Scheduled was already sent for today
                return false;
            }
        }

        // Get the recurence (send every X days)
        Integer recur = Integer.parseInt(scheduled.getAttributes().get("day"));

        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        // We search the futur send of Scheduled
        while (DateUtils.truncatedCompareTo(cal.getTime(), this.now, Calendar.DAY_OF_MONTH) < 0) {
            cal.add(Calendar.DAY_OF_MONTH, recur);
        }

        if (DateUtils.truncatedCompareTo(cal.getTime(), this.now, Calendar.DAY_OF_MONTH) != 0) {
            // The next send is not today
            return false;
        }

        return true;
    }

    @Override
    public boolean wasLastSent() {
        // Get the real end date
        Date endDate = this.getRealEndDate();

        if (Objects.isNull(endDate)) {
            return false;
        }

        return DateUtils.truncatedCompareTo(this.now, endDate, Calendar.DAY_OF_MONTH) == 0;
    }

    private Date getRealStartDate() {
        Date startDate = new Date(this.scheduled.getStartDate() * 1000);

        return startDate;
    }

    /**
     * Calcul the end date based on the start date, the recurence, the occurence and
     * the end date.
     * 
     * @return
     */
    private Date getRealEndDate() {
        // Get the recurence (send every X days)
        Integer recur = Integer.parseInt(scheduled.getAttributes().get("day"));

        // Get the start date
        Date startDate = this.getRealStartDate();
        // If present, get the end date
        Date endDate = null;
        if (Objects.nonNull(this.scheduled.getEndDate())) {
            endDate = new Date(this.scheduled.getEndDate() * 1000);

            Calendar endCal = Calendar.getInstance();
            endCal.setTime(startDate);
            Date prevDate = startDate;
            while (DateUtils.truncatedCompareTo(endCal.getTime(), endDate, Calendar.DAY_OF_MONTH) <= 0) {
                prevDate = endCal.getTime();
                endCal.add(Calendar.DAY_OF_MONTH, recur);
            }

            endDate = prevDate;
        } else if (this.scheduled.getAttributes().containsKey("occurence")) {
            // Else get the "occurence"
            Integer occurence = Integer.parseInt(this.scheduled.getAttributes().get("occurence"));
            // Calcul the end date base on the "startDate", "recur" and "occurrence"
            Calendar endCal = Calendar.getInstance();
            endCal.setTime(startDate);
            endCal.add(Calendar.DAY_OF_MONTH, occurence * recur);
            endDate = endCal.getTime();
        } else {
            // No End date
        }

        return endDate;
    }
}
