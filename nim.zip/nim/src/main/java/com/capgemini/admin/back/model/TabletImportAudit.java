package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "tablet_import_audit")
public class TabletImportAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TabletImportAudit_Generator")
    @SequenceGenerator(name = "TabletImportAudit_Generator", sequenceName = "TabletImportAudit_Sequence")
    private Long id;
    @Column(name = "poi_name")
    private String poiName;
    @Lob
    @Column(name = "old_value", columnDefinition = "TEXT")
    private String oldValue;
    @Lob
    @Column(name = "new_value", columnDefinition = "TEXT")
    private String newValue;
    @Column(name = "activity_date_time")
    private Long activityDateTime;
    @Column(name = "action")
    private String action;
    @Column(name = "email")
    private String email;
}
