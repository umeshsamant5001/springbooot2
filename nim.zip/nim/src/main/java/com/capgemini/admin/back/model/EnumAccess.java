package com.capgemini.admin.back.model;

/**
 * Enumeration representing different privileges.
 */
public enum EnumAccess {
    READ, WRITE, NONE
}