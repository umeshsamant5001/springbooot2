package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.Data;

@Data
public class MasterAttributeDTO {
    private static int MAX_VALUE_NUMBER = 35;

    private String name;
    private EnumControlType controlType;
    private EnumDataType dataType;
    private Integer length;
    private Boolean mandatory;
    private List<String> controlValue = new ArrayList<>();

    public void setControlValue(List<String> controlValue) throws InvalidParameterException {
        // Limit the size of possible value to MAX_VALUE_NUMBER
        if (Objects.nonNull(controlValue) && controlValue.size() > MAX_VALUE_NUMBER) {
            throw new InvalidParameterException(
                    String.format("The ControlType can have %S values maximum.", MAX_VALUE_NUMBER));
        }

        this.controlValue = controlValue;
    }
}
