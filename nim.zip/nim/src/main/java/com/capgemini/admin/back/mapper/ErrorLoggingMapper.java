package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.ErrorLogging;
import com.capgemini.admin.back.model.ErrorLoggingDTO;

@Mapper(config = DtoMapperConfig.class)
public interface ErrorLoggingMapper {

    ErrorLoggingMapper INSTANCE = Mappers.getMapper(ErrorLoggingMapper.class);

    ErrorLoggingDTO errorloggingToErrorLoggingDTO(ErrorLogging in);

    ErrorLogging errorloggingDTOToErrorLogging(ErrorLoggingDTO in);

}
