package com.capgemini.admin.back.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.admin.back.mapper.BuildingMapper;
import com.capgemini.admin.back.mapper.PreferenceMapper;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.Preference;
import com.capgemini.admin.back.model.PreferenceDTO;
import com.capgemini.admin.back.model.Service;
import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.PreferenceRepository;

@org.springframework.stereotype.Service
public class PreferenceService {

    @Autowired
    private PreferenceRepository preferenceRepository;

    @Autowired
    private BuildingRepository buildingRepository;

    /**
     * Retrieves a list of user preferences where the given service is marked as a favorite.
     *
     * @param service The service to search for in user favorites.
     * @return List of Preference entities containing the service as a favorite.
     */
    public List<Preference> getFavoriteService(Service service) {
        return this.preferenceRepository.findByFavoriteServicesContaining(service);
    }

    public Preference save(Preference preference) {
        return this.preferenceRepository.saveAndFlush(preference);
    }

    /**
     * Retrieves a user's preference by their email.
     *
     * @param userEmail The user's email address.
     * @return The Preference entity if found, otherwise null.
     */
    public Preference getUserPreference(String userEmail) {
        return preferenceRepository.findByUserEmail(userEmail).orElse(null);
    }

    /**
     * Retrieves a user's preference by email and converts it to a DTO with language-specific mapping.
     * Filters out services marked as "Disabled".
     *
     * @param userEmail The user's email address.
     * @param language  The language for DTO conversion.
     * @return A PreferenceDTO containing user preferences, or null if not found.
     */
    @Transactional
    public PreferenceDTO getUserPreference(String userEmail, String language) {
        Optional<Preference> userPreferenceOpt = this.preferenceRepository.findByUserEmail(userEmail);
        if (userPreferenceOpt.isPresent()) {
            Preference userPref = userPreferenceOpt.get();
            List<Service> serviceList = userPref.getFavoriteServices()
                    .stream()
                    .filter(service -> service.getAttributes().containsKey("status")
                            && !"Disabled".equals(service.getAttributes().get("status")))
                    .collect(Collectors.toList());

            userPref.setFavoriteServices(serviceList);
            return preferenceToPreferenceDto(userPref, language);
        } else {
            return null;
        }
    }

    /**
     * Converts a Preference entity to a PreferenceDTO, including visited buildings.
     *
     * @param userPreference The Preference entity to convert.
     * @param language       The language for DTO conversion.
     * @return A PreferenceDTO with localized building information.
     */
    private PreferenceDTO preferenceToPreferenceDto(Preference userPreference, String language) {
        Hibernate.initialize(userPreference.getFavoriteServices());
        PreferenceDTO prefDTO = PreferenceMapper.INSTANCE.preferenceToPreferenceDTO(userPreference, language);
        List<Long> visitedBuildingIds = userPreference.getVisitedBuildingsIds();
        List<BuildingDTO> buildingDTOs = this.buildingRepository.findByIdIn(visitedBuildingIds)
                .stream()
                .map(building -> BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language))
                .collect(Collectors.toList());
        prefDTO.setVisitedBuildings(buildingDTOs);
        return prefDTO;
    }
}