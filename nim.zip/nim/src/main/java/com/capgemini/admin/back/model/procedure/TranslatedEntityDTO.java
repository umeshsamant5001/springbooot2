package com.capgemini.admin.back.model.procedure;

import lombok.Data;

@Data
public class TranslatedEntityDTO {
    private Long id;
    private String titleEn;
    private String title;
}
