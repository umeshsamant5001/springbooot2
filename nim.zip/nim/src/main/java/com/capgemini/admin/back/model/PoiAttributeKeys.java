package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "poi_attribute_keys")
public class PoiAttributeKeys {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PoiAttributeKeys_Generator")
    @SequenceGenerator(name = "PoiAttributeKeys_Generator", sequenceName = "PoiAttributeKeys_Sequence")
    private Long id;
    @Column(name = "poi_attribute_key")
    private String poiAttributeKey;
}
