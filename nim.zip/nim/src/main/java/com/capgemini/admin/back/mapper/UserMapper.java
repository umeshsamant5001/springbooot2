package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.model.UserDTO;

@Mapper(config = DtoMapperConfig.class)
public interface UserMapper {

	UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

	@Mapping(target = "roleLocations", ignore = true)
	UserDTO userToUserDTO(User in);

	User userDTOToUser(UserDTO in);
}
