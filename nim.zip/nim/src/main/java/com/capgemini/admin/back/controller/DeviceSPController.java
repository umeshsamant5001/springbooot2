package com.capgemini.admin.back.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import com.capgemini.admin.back.service.DeviceSPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.model.DeviceSP;
import com.capgemini.admin.back.model.DeviceSPDTO;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = DeviceSPController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class DeviceSPController {

    public static final String ROOT_API = "api/SPDevice";

    @Autowired
    private DeviceSPService deviceSPService;

    /**
     * Searches for items within a specific building based on the given search
     * string.
     *
     * @param buildingId   The ID of the building to search within.
     * @param searchString The search string to use for searching items.
     * @param language     The language to use for the request (default is English
     *                     if not provided).
     * @return ResponseEntity containing a list of DeviceSPDTO objects matching the
     *         search criteria.
     */
    @Transactional(readOnly = true)
    @GetMapping("/search/{buildingId}/{searchString}")
    public ResponseEntity<List<DeviceSPDTO>> searchItems(
            @PathVariable("buildingId") int buildingId,
            @PathVariable("searchString") String searchString,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Retrieve list of DeviceSP objects based on the building ID and search string
        List<DeviceSP> deviceSPs = this.deviceSPService.getAllDeviceSPByBuildingId(searchString, buildingId);

        deviceSPs = this.deviceSPService.filterDeviceSP(deviceSPs);

        // Convert the list of DeviceSP objects to a list of DeviceSPDTO objects
        List<DeviceSPDTO> deviceSPDTOs = this.deviceSPsTODeviceSPDTOs(deviceSPs);
        return ResponseEntity.ok(deviceSPDTOs);
    }

    /**
     * Searches for items globally based on the given search string.
     *
     * @param searchString The search string to use for searching items.
     * @param language     The language to use for the request (default is English
     *                     if not provided).
     * @return ResponseEntity containing a list of DeviceSPDTO objects matching the
     *         search criteria.
     */
    @Transactional(readOnly = true)
    @GetMapping("/search/{searchString}")
    public ResponseEntity<List<DeviceSPDTO>> SearchItemGlobal(
            @PathVariable("searchString") String searchString,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Retrieve list of DeviceSP objects based on the search string
        List<DeviceSP> deviceSPs = this.deviceSPService.getAllDeviceSP(searchString);

        deviceSPs = this.deviceSPService.filterDeviceSP(deviceSPs);

        // Convert the list of DeviceSP objects to a list of DeviceSPDTO objects
        List<DeviceSPDTO> deviceSPDTOs = this.deviceSPsTODeviceSPDTOs(deviceSPs);
        return ResponseEntity.ok(deviceSPDTOs);
    }

    /**
     * Converts a list of DeviceSP objects to a list of DeviceSPDTO objects.
     *
     * @param deviceSPs The list of DeviceSP objects to convert.
     * @return The list of DeviceSPDTO objects converted from the input list of
     *         DeviceSP objects.
     */
    private List<DeviceSPDTO> deviceSPsTODeviceSPDTOs(List<DeviceSP> deviceSPs) {
        Map<String, DeviceSPDTO> deviceSPDTOMap = new HashMap<>();

        for (DeviceSP deviceSP : deviceSPs) {
            String uuid = deviceSP.getUuid();
            DeviceSPDTO deviceSPDTO = deviceSPDTOMap.get(uuid);

            if (deviceSPDTO == null) {
                deviceSPDTO = new DeviceSPDTO();
                deviceSPDTO.setUuid(deviceSP.getUuid());
                deviceSPDTO.setPoiName(deviceSP.getPoiName());
                deviceSPDTO.setSpaceTypeName(deviceSP.getSpaceTypeName());
                deviceSPDTO.setPoiTitle(deviceSP.getPoiTitle());
                deviceSPDTO.setDeviceType(deviceSP.getDeviceType());
                deviceSPDTO.setStatus(deviceSP.getStatus());
                deviceSPDTO.setLastChange(deviceSP.getLastChange());
                deviceSPDTO.setFloorId(deviceSP.getFloorId());
                deviceSPDTO.setAttributes(new HashMap<>());

                deviceSPDTOMap.put(uuid, deviceSPDTO);
            }

            if (Objects.nonNull(deviceSP.getAttKey()) && Objects.nonNull(deviceSP.getAttValue())) {
                deviceSPDTO.getAttributes().put(deviceSP.getAttKey(), deviceSP.getAttValue());
            }
        }

        return new ArrayList<>(deviceSPDTOMap.values());
    }
}