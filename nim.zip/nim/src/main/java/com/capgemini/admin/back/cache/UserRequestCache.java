package com.capgemini.admin.back.cache;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.security.jwt.model.UserInformation;
import com.capgemini.admin.back.service.UserInformationService;
import com.capgemini.admin.back.service.UserService;

@Component
@RequestScope
public class UserRequestCache {

    // The current User
    private User currentUser;

    // USed to know if the user exist in database or not
    private Boolean userExist;

    @Autowired
    private UserService userService;

    @Autowired
    private UserInformationService userInformationService;

    /**
     * Return the current user of the HTTP Request
     * 
     * @return The current User or `null` if the user don't exist.
     */
    public User getCurrentUser() {
        // Check if the user is null and it's not because it doesn't exist in database
        if (Objects.isNull(this.currentUser) && Objects.isNull(this.userExist)) {
            UserInformation userInformation = this.userInformationService.getCurrent();
            String UserEmail = userInformation.getEmail();

            this.currentUser = this.userService.getUserByEmail(UserEmail);

            this.userExist = Objects.nonNull(this.currentUser);
        }

        return this.currentUser;
    }
}
