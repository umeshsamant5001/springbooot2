package com.capgemini.admin.back.mapper.procedure;

import com.capgemini.admin.back.mapper.DtoMapperConfig;
import com.capgemini.admin.back.model.procedure.AppConfigValue;
import com.capgemini.admin.back.model.procedure.AppConfigValueDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface AppConfigValueMapper {

    AppConfigValueMapper INSTANCE = Mappers.getMapper(AppConfigValueMapper.class);

    AppConfigValueDTO appConfigValueToAppConfigValueDTO(AppConfigValue in);

    AppConfigValue appConfigValueDTOToAppConfigValue(AppConfigValueDTO in);

}