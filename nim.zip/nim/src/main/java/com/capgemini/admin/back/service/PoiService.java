package com.capgemini.admin.back.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.persistence.Tuple;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.back.mapper.PoiMapper;
import com.capgemini.admin.back.model.Equipment;
import com.capgemini.admin.back.model.Poi;
import com.capgemini.admin.back.model.PoiBulkImportDTO;
import com.capgemini.admin.back.model.PoiDTO;
import com.capgemini.admin.back.model.ResponsePoiBulkImportDTO;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.SubLevelEnum;
import com.capgemini.admin.back.repository.FloorRepository;
import com.capgemini.admin.back.repository.PoiRepository;
import com.capgemini.admin.back.repository.SpaceTypeRepository;

import com.capgemini.admin.back.vecos.VecosClient;
import com.capgemini.admin.back.vecos.VecosConstants;
import com.capgemini.admin.back.config.PoiConstants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    // Upper bound for CSV import payload size to prevent excessive loop iterations

    // and resource usage during line-by-line parsing.
    // 5 MB comfortably covers the configured logical cap of 10,000 data lines.
    private static final long MAX_POI_IMPORT_FILE_SIZE_BYTES = 5L * 1024L * 1024L;

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private FloorRepository floorRepository;

    @Autowired
    private SpaceTypeRepository spaceTypeRepository;

    @Autowired
    private VecosClient vecosClient;

    @Autowired
    private TreeService treeService;


    /***
     * Create a poi
     * 
     * @param poi
     * @return
     */
    public Poi createPoi(Poi poi) {
        Poi sanitizedPoi = sanitizePoiForPersistence(poi);
        if (Objects.isNull(sanitizedPoi)) {
            return null;
        }
        setBankIdFromBankName(sanitizedPoi);
        setLockerFreeNumber(sanitizedPoi);
        Poi save = null;
        try {
            save = this.poiRepository.saveAndFlush(sanitizedPoi);
        } catch (Exception e) {
            log.error("Error while saving in poi ",e.getMessage(), e );
        }
        return save;
    }



    /***
     * Update a poi
     * 
     * @param oldPoi
     * @param newPoi
     * @return
     */
    public Poi updatePoi(Poi oldPoi, Poi newPoi) {
        if (Objects.isNull(oldPoi) || Objects.isNull(newPoi)) {
            return null;
        }

        Poi sanitizedPoi = sanitizePoiForPersistence(newPoi);
        if (Objects.isNull(sanitizedPoi)) {
            return null;
        }

        oldPoi.setName(sanitizedPoi.getName() == null
                ? null
                : new String(String.valueOf(sanitizedPoi.getName())));
        oldPoi.setAttributes(new HashMap<>(sanitizedPoi.getAttributes()));
        oldPoi.setEquipments(sanitizedPoi.getEquipments());
        oldPoi.setCdmKeyId(sanitizedPoi.getCdmKeyId() == null ? null : Long.valueOf(sanitizedPoi.getCdmKeyId()));
        oldPoi.setTitleEn(sanitizedPoi.getTitleEn() == null
                ? null
                : new String(String.valueOf(sanitizedPoi.getTitleEn())));
        oldPoi.setTitleFr(sanitizedPoi.getTitleFr() == null
                ? null
                : new String(String.valueOf(sanitizedPoi.getTitleFr())));

        oldPoi.setModifiedAt(System.currentTimeMillis() / 1000);
        updateFloor(oldPoi, sanitizedPoi.getFloorId());
        updateSpaceType(oldPoi, sanitizedPoi.getSpaceTypeId());
        setBankIdFromBankName(oldPoi);
        setLockerFreeNumber(oldPoi);
        try {
            return poiRepository.saveAndFlush(oldPoi);
        } catch (Exception e) {
            log.error("Failed to update POI: {}", e.getMessage());
            return null;
        }
    }


    /**
     * Updates the floor information of a given POI based on the provided floor ID.
     *
     * @param poi     The POI entity to update.
     * @param floorId The ID of the floor to associate with the POI.
     */
    private void updateFloor(Poi poi, Long floorId) {
        Long requestedFloorId = sanitizePositiveId(floorId);
        if (Objects.isNull(requestedFloorId)) {
            return;
        }

        List<Long> authorizedFloorIds = this.treeService.filterId(SubLevelEnum.FLOOR, List.of(requestedFloorId));
        if (authorizedFloorIds.isEmpty()) {
            return;
        }

        Long scopedFloorId = Long.valueOf(authorizedFloorIds.get(0));
        try {
            floorRepository.findById(scopedFloorId).ifPresent(floor -> {
                poi.setFloor(floor);
                poi.setFloorId(Long.valueOf(floor.getId()));
            });
        } catch (DataAccessException ex) {
            log.error("Failed to update floor for poi with floorId {}", scopedFloorId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update POI floor.");
        }
    }


    /**
     * Updates the space type of a given POI based on the provided space type ID.
     *
     * @param poi          The POI entity to update.
     * @param spaceTypeId  The ID of the space type to associate with the POI.
     */
    private void updateSpaceType(Poi poi, Long spaceTypeId) {
        if (spaceTypeId != null) {
            try {
                spaceTypeRepository.findById(spaceTypeId).ifPresent(spaceType -> {
                    poi.setSpaceType(spaceType);
                    poi.setSpaceTypeId(spaceType.getId());
                });
            } catch (DataAccessException ex) {
                log.error("Failed to update space type for poi with spaceTypeId {}", spaceTypeId, ex);
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update POI space type.");
            }
        }
    }

    private Poi sanitizePoiForPersistence(Poi poi) {
        if (Objects.isNull(poi)) {
            return null;
        }

        Poi sanitizedPoi = new Poi();
        sanitizedPoi.setId(null);
        sanitizedPoi.setModifiedAt((new Date()).getTime() / 1000);

        String validatedName = sanitizeOptionalText(poi.getName(), 255);
        String validatedTitleEn = sanitizeOptionalText(poi.getTitleEn(), 255);
        String validatedTitleFr = sanitizeOptionalText(poi.getTitleFr(), 255);

        sanitizedPoi.setName(validatedName == null ? null : new String(validatedName));
        sanitizedPoi.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
        sanitizedPoi.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
        sanitizedPoi.setCdmKeyId(poi.getCdmKeyId() == null ? null : Long.valueOf(poi.getCdmKeyId()));
        sanitizedPoi.setAttributes(new HashMap<>(sanitizeAttributes(poi.getAttributes())));
        sanitizedPoi.setEquipments(sanitizeEquipments(poi.getEquipments()));

        Long validatedFloorId = sanitizePositiveId(poi.getFloorId());
        if (Objects.isNull(validatedFloorId) && Objects.nonNull(poi.getFloor())) {
            validatedFloorId = sanitizePositiveId(poi.getFloor().getId());
        }

        Long validatedSpaceTypeId = sanitizePositiveId(poi.getSpaceTypeId());
        if (Objects.isNull(validatedSpaceTypeId) && Objects.nonNull(poi.getSpaceType())) {
            validatedSpaceTypeId = sanitizePositiveId(poi.getSpaceType().getId());
        }

        updateFloor(sanitizedPoi, validatedFloorId);
        updateSpaceType(sanitizedPoi, validatedSpaceTypeId);

        return sanitizedPoi;
    }

    private Long sanitizePositiveId(Long id) {
        if (Objects.isNull(id) || id <= 0) {
            return null;
        }
        return Long.valueOf(id);
    }

    private String sanitizeOptionalText(String value, int maxLength) {
        if (Objects.isNull(value)) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            return null;
        }

        return new String(validated);
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();

        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

    private List<Equipment> sanitizeEquipments(List<Equipment> equipments) {
        List<Equipment> sanitized = new ArrayList<>();

        if (Objects.isNull(equipments)) {
            return sanitized;
        }

        equipments.forEach(equipment -> {
            if (Objects.nonNull(equipment)) {
                Equipment safeEquipment = new Equipment();
                safeEquipment.setId(equipment.getId() == null ? null : Long.valueOf(equipment.getId()));

                String validatedName = sanitizeOptionalText(equipment.getName(), 255);
                String validatedTitleEn = sanitizeOptionalText(equipment.getTitleEn(), 255);
                String validatedTitleFr = sanitizeOptionalText(equipment.getTitleFr(), 255);

                safeEquipment.setName(validatedName == null ? null : new String(validatedName));
                safeEquipment.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
                safeEquipment.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
                sanitized.add(safeEquipment);
            }
        });

        return sanitized;
    }


    /**
     * Finds a POI by its name.

     *
     * @param poiName The name of the POI.
     * @return The POI entity if found, otherwise null.
     */
    public Poi findByName(String poiName) {
        return this.poiRepository.findByName(poiName);
    }

    /**
     * Converts a list of POI entities to a list of POI DTOs using the specified language.
     * @param language The language to use for DTO conversion.
     * @return A function that maps a list of POIs to POI DTOs.
     */
    public Function<List<Poi>, List<PoiDTO>> poiListToPoiDTOList(String language) {
        return in -> in.stream().map(p -> PoiMapper.INSTANCE.poiToPoiDTO(p, language)).collect(Collectors.toList());
    }

    /**
     * Check if poi name exist
     * 
     * @param poi
     */
    public Poi checkPoiNameExist(Poi poi) {
        Poi checkPoi = this.poiRepository.findByName(poi.getName());
        if (Objects.isNull(checkPoi)) {
            return null;
        }
        return checkPoi;
    }

    /**
     * Gets a map of space type ID to POI count.
     *
     * @return A map of space type ID to count.
     */
    public Map<Long, Long> countByGroup() {
        try {
            return this.poiRepository.countByType()
                    .stream()
                    .collect(Collectors.toMap(tuple -> (Long) tuple.get(0), tuple -> (Long) tuple.get(1)));
        } catch (DataAccessException ex) {
            log.error("Failed to count POIs by group.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count POIs.");
        }
    }

    /**
     * Gets a map of space type ID to POI count (CDM-specific).
     *
     * @return A map of space type ID to count.
     */
    public Map<Long, Long> countByTypeCDM() { // CDM
        try {
            return this.poiRepository.countBySpaceType()
                    .stream()
                    .collect(Collectors.toMap(tuple -> (Long) tuple.get(0), tuple -> (Long) tuple.get(1)));
        } catch (DataAccessException ex) {
            log.error("Failed to count POIs by space type (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count POIs.");
        }
    }

    /**
     * Gets a map of equipment ID to POI count.
     *
     * @return A map of equipment ID to count.
     */
    public Map<Long, Long> countByEquipment() {
        try {
            return this.poiRepository.countByEquipment()
                    .stream()
                    .collect(Collectors.toMap(tuple -> (Long) tuple.get(0), tuple -> (Long) tuple.get(1)));
        } catch (DataAccessException ex) {
            log.error("Failed to count POIs by equipment.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count POIs.");
        }
    }

    /**
     * Gets POI counts by space type and building ID.
     *
     * @param buildingId The building ID.
     * @return A map of space type ID to POI count.
     */
    public Map<Long, Long> countByTypeAndBuilding(Long buildingId) {
        List<Tuple> poiCounts = this.poiRepository.countByTypeAndBuilding(buildingId);
        Map<Long, Long> poiCountByType = new HashMap<>();
        for (Tuple tuple : poiCounts) {
            Long typeId = (Long) tuple.get("typeId");
            Long count = (Long) tuple.get("nbPoi");
            poiCountByType.put(typeId, count);
        }
        return poiCountByType;
    }

    /**
     * Gets POI counts by space type and building ID (CDM-specific).
     *
     * @param buildingId The building ID.
     * @return A map of space type ID to POI count.
     */
    public Map<Long, Long> countByTypeAndBuildingCDM(Long buildingId) { // CDM
        List<Tuple> poiCounts = this.poiRepository.countBySpaceTypeAndBuilding(buildingId);
        Map<Long, Long> poiCountByType = new HashMap<>();
        for (Tuple tuple : poiCounts) {
            Long typeId = (Long) tuple.get("spaceTypeId");
            Long count = (Long) tuple.get("nbPoi");
            poiCountByType.put(typeId, count);
        }
        return poiCountByType;
    }

    /**
     * Gets POI counts by space type, building ID, and floor ID.
     * 
     * @param buildingId The building ID.
     * @param floorId    The floor ID.
     * @return A map of space type ID to POI count.
     */
    public Map<Long, Long> countByTypeAndFloorId(Long buildingId, Long floorId) {
        List<Tuple> poiCounts = this.poiRepository.countByTypeAndBuildingAndFloor(buildingId, floorId);

        Map<Long, Long> poiCountByType = new HashMap<>();
        for (Tuple tuple : poiCounts) {
            Long typeId = (Long) tuple.get("typeId");
            Long count = (Long) tuple.get("nbPoi");
            poiCountByType.put(typeId, count);
        }

        return poiCountByType;
    }

    /**
     * Exports POI data by country ID and optional space type category
     * (CDM-specific).
     *
     * @param countryId The country ID.
     * @param category  The list of space type categories.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByTypeIdAndCountryIdCDM(Long countryId, List<String> category) {
        boolean isCategoryEmpty = category == null || category.isEmpty();

        try {
            List<SpaceType> spaceTypeList;
            if (!isCategoryEmpty) {
                spaceTypeList = spaceTypeRepository.findByCategory(category);
            } else {
                return this.poiRepository.findExportDataByCountryIdCDM(countryId);
            }

            // If no space types are found, return an empty list
            if (spaceTypeList.isEmpty()) {
                return Collections.emptyList();
            }

            List<Long> spaceTypeIdList = spaceTypeList.stream().map(SpaceType::getId).collect(Collectors.toList());
            return this.poiRepository.findExportDataByCountryIdAndSpaceTypeId(countryId, spaceTypeIdList);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by country and type (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }

    /**
     * Exports POI data by optional space type category (CDM-specific).
     *
     * @param category The list of space type categories.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByTypeIdCDM(List<String> category) {
        boolean isCategoryEmpty = category == null || category.isEmpty();
        // CDM
        try {
            if (isCategoryEmpty) {
                return this.poiRepository.findAllExportDataCDM();
            }
            List<SpaceType> spaceTypeList = spaceTypeRepository.findByCategory(category);
            List<Long> spaceTypeIdList = spaceTypeList.stream().map(SpaceType::getId).collect(Collectors.toList());
            return this.poiRepository.findExportDataBySpaceTypeId(spaceTypeIdList);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by type (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }

    /**
     * Exports POI data by city ID and optional space type category (CDM-specific).
     *
     * @param cityId   The city ID.
     * @param category The list of space type categories.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByTypeIdAndCityIdCDM(Long cityId, List<String> category) {
        boolean isCategoryEmpty = category == null || category.isEmpty();

        try {
            if (isCategoryEmpty) {
                return this.poiRepository.findExportDataByCityIdCDM(cityId);
            }
            List<SpaceType> spaceTypeList;
            if (!isCategoryEmpty) {
                spaceTypeList = spaceTypeRepository.findByCategory(category);
            } else {
                return this.poiRepository.findExportDataByCityIdCDM(cityId);
            }

            if (spaceTypeList.isEmpty()) {
                return Collections.emptyList();
            }

            List<Long> spaceTypeIdList = spaceTypeList.stream().map(SpaceType::getId).collect(Collectors.toList());
            return this.poiRepository.findExportDataByCityIdAndSpaceTypeId(cityId, spaceTypeIdList);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by city and type (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }

    /**
     * Exports POI data by site ID and optional space type category (CDM-specific).
     *
     * @param siteId   The site ID.
     * @param category The list of space type categories.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByTypeIdAndSiteIdCDM(Long siteId, List<String> category) {
        boolean isCategoryEmpty = category == null || category.isEmpty();

        try {
            if (isCategoryEmpty) {
                return this.poiRepository.findExportDataBySiteIdCDM(siteId);
            }

            List<SpaceType> spaceTypeList = spaceTypeRepository.findByCategory(category);

            if (spaceTypeList.isEmpty()) {
                return Collections.emptyList();
            }

            List<Long> spaceTypeIdList = spaceTypeList.stream().map(SpaceType::getId).collect(Collectors.toList());
            return this.poiRepository.findExportDataBySiteIdAndSpaceTypeId(siteId, spaceTypeIdList);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by site and type (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }

    /**
     * Exports POI data by building ID (CDM-specific).
     * 
     * @param buildingId The building ID.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByBuildingIdCDM(Long buildingId) { // CDM
        try {
            return this.poiRepository.findExportDataByBuildingIdCDM(buildingId);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by building (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }


    /**
     * Exports POI data by floor ID (CDM-specific).
     *
     * @param floorId The floor ID.
     * @return A list of export data rows.
     */
    public List<List<String>> getExportDataByFloorIdCDM(Long floorId) { // CDM
        try {
            return this.poiRepository.findExportDataByFloorIdCDM(floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to export POI data by floor (CDM).", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export POI data.");
        }
    }


    /**
     * Finds all POIs filtered by type ID, building ID, and optionally floor ID.
     * Handles combinations where typeId or floorId may be null or empty.
     *
     * @param typeId     List of space type IDs to filter by.
     * @param buildingId List of building IDs to filter by.
     * @param floorId    List of floor IDs to filter by.
     * @return List of matching POIs.
     */
    public List<Poi> findAllByTypeIdAndBuildingIdAndFloorId(List<Long> typeId, List<Long> buildingId,
            List<Long> floorId) {
        boolean isTypeIdEmpty = typeId == null || typeId.isEmpty();
        boolean isFloorIdEmpty = floorId == null || floorId.isEmpty();

        try {
            if (!isTypeIdEmpty) {
                return isFloorIdEmpty
                        ? this.poiRepository.findAllByTypeIdAndBuildingId(typeId, buildingId)
                        : this.poiRepository.findAllByTypeIdAndBuildingIdAndFloorId(typeId, buildingId, floorId);
            }

            return isFloorIdEmpty
                    ? this.poiRepository.findAllByBuildingId(buildingId)
                    : this.poiRepository.findAllByBuildingIdAndFloorId(buildingId, floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by type/building/floor filters.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve POIs.");
        }
    }


    /**
     * Retrieves all POIs on a given floor, ordered by name.
     *
     * @param floorId The floor ID.
     * @return List of POIs ordered by name.
     */
    public List<Poi> findAllByFloorIdOrderByName(Long floorId) {
        try {
            return this.poiRepository.findAllByFloorIdOrderByName(floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by floor ordered by name.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve POIs.");
        }
    }

    /**
     * Finds a POI by its ID.
     *
     * @param poiId The POI ID.
     * @return The POI entity if found, otherwise null.
     */
    public Poi findById(Long poiId) {
        return this.poiRepository.findById(poiId).orElse(null);
    }

    /**
     * Finds a POI by its ID.
     *
     * @param poiId The POI ID.
     * @return The POI entity if found, otherwise null.
     */
    public void deleteById(Long poiId) {
        this.poiRepository.deleteById(poiId);
    }

    /**
     * Finds all POIs by space type ID and floor ID.
     *
     * @param typeId  The space type ID.
     * @param floorId The floor ID.
     * @return List of matching POIs.
     */
    public List<Poi> findAllByTypeIdAndFloorId(Long typeId, Long floorId) {
        try {
            return this.poiRepository.findAllByTypeIdAndFloorId(typeId, floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POIs by type and floor.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve POIs.");
        }
    }

    /**
     * Finds a POI by floor ID and name.
     *
     * @param floorId The floor ID.
     * @param name    The name of the POI.
     * @return The POI entity if found, otherwise null.
     */
    public Poi findByFloorIdAndName(Long floorId, String name) {
        return this.poiRepository.findByFloorIdAndName(floorId, name);
    }

    /**
     * Retrieves the attributes of a POI as a key-value map.
     *
     * @param poiId The POI ID.
     * @return A map of attribute keys and values.
     */
    public Map<String, String> getAttributesById(Long poiId) {
        try {
            return this.poiRepository.getAttributesById(poiId)
                    .stream()
                    .collect(Collectors.toMap(
                            tuple -> Objects.toString(tuple.get(0), ""), // Handle null key
                            tuple -> Objects.toString(tuple.get(1), "") // Handle null value
                    ));
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve POI attributes for poiId {}.", poiId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve POI attributes.");
        }
    }


    /**
     * Checks the format of the CSV file and returns any structural errors found.
     *
     * @param file The CSV file to be checked
     * @return A list of structural errors found during the check
     */
    public List<String> checkCSVFormat(MultipartFile file) {
        List<String> structuralErrors = new ArrayList<>();
        if (file == null || file.isEmpty()) {
            structuralErrors.add("The file is empty.");
            return structuralErrors;
        }
        if (file.getSize() > MAX_POI_IMPORT_FILE_SIZE_BYTES) {
            structuralErrors.add(String.format(
                    "The file is too large. Maximum allowed size is %s bytes.",
                    MAX_POI_IMPORT_FILE_SIZE_BYTES));
            return structuralErrors;
        }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            final int maxLinesToRead = PoiConstants.MAX_POI_IMPORT_DATA_LINES + 1;
            while (lineNumber < maxLinesToRead && Objects.nonNull((line = br.readLine()))) {
                lineNumber++;
                line = line.trim();

                // Strip trailing commas in a single bounded operation to avoid an
                // unbounded loop driven by attacker-controlled file content (a line
                // consisting of many trailing commas would otherwise cause O(n) substring
                // allocations per comma).
                line = stripTrailingCommas(line);
                String[] infos = line.split(",");
                // Check if it's the header line and verify its format
                if (lineNumber == 1) {
                    if (checkHeader(infos)) {
                        continue;
                    } else {
                        structuralErrors.add("Incorrect header format. Please use the correct headers.");
                        return structuralErrors;
                    }
                }
                int length = infos.length;
                // Check the number of variables in each line
                if (length != PoiConstants.POI_COLUMN_COUNT) {
                    structuralErrors.add(
                            String.format(
                                    "Line %s: must contain %s variables - this line contains %s variables",
                                    lineNumber,
                                    PoiConstants.POI_COLUMN_COUNT,
                                    length));
                }
            }

            if (Objects.nonNull(br.readLine())) {
                structuralErrors.add(String.format(
                        "The file contains too many data lines. Maximum allowed is %s.",
                        PoiConstants.MAX_POI_IMPORT_DATA_LINES));
                return structuralErrors;
            }

            if (lineNumber == 0) {
                structuralErrors.add("The file is empty.");
            } else if (lineNumber == 1) {
                structuralErrors.add("No data present in the file.");
            }
        } catch (IOException e) {
            structuralErrors.add("Error while reading the file: " + e.getMessage() + ".");
        }
        return structuralErrors;
    }

    /**
     * Validates if the given CSV header line matches the expected POI column structure.
     *
     * @param line The header line from the CSV file.
     * @return true if the header is valid, false otherwise.
     */
    private boolean checkHeader(String[] line) {
        return (line.length == PoiConstants.POI_COLUMN_COUNT &&
                PoiConstants.HEADER_POI_NAME.equalsIgnoreCase(line[PoiConstants.IDX_POI_NAME]) &&
                PoiConstants.HEADER_CONF_ROOM_MAIL.equalsIgnoreCase(line[PoiConstants.IDX_CONF_ROOM_MAIL]) &&
                PoiConstants.HEADER_CAPACITY.equalsIgnoreCase(line[PoiConstants.IDX_HEADER_CAPACITY]));
    }

    /**
     * Generates a ResponsePoiBulkImportDTO from the provided CSV file, adding pois
     * and errors as needed.
     *
     * @param file The CSV file from which to generate the response DTO
     * @return The ResponsePoiBulkImportDTO containing the imported pois and any
     *         errors encountered
     */
    public ResponsePoiBulkImportDTO generateResponsePoiImportDTO(MultipartFile file) {
        ResponsePoiBulkImportDTO responsePoiBulkImportDTO = new ResponsePoiBulkImportDTO();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (lineNumber > PoiConstants.MAX_POI_IMPORT_DATA_LINES + 1) {
                    responsePoiBulkImportDTO.addError(String.format(
                            "The file contains too many data lines. Maximum allowed is %s.",
                            PoiConstants.MAX_POI_IMPORT_DATA_LINES));
                    return responsePoiBulkImportDTO;
                }
                // Skip the header line

                if (lineNumber == 1) {
                    continue;
                }
                // Clean trailing commas
                line = line.trim();
                // Strip trailing commas in a single bounded operation to avoid an
                // unbounded loop driven by attacker-controlled file content (a line
                // consisting of many trailing commas would otherwise cause O(n) substring
                // allocations per comma).
                line = stripTrailingCommas(line);

                String[] poiFromCsv = line.split(",");
                int length = poiFromCsv.length;
                // Check the number of columns in each line
                if (length != PoiConstants.POI_COLUMN_COUNT) {
                    String error = String.format("Line %s: must contain %s columns - found %s", lineNumber,
                            PoiConstants.POI_COLUMN_COUNT, length);
                    responsePoiBulkImportDTO.addError(error);
                    continue; // Skip the rest of the processing for this line
                }

                if (Objects.isNull(poiFromCsv[PoiConstants.IDX_POI_NAME])
                        || poiFromCsv[PoiConstants.IDX_POI_NAME].isEmpty()) {
                    responsePoiBulkImportDTO
                            .addError(String.format("Line %s: PoiName column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(poiFromCsv[PoiConstants.IDX_CONF_ROOM_MAIL])
                        || poiFromCsv[PoiConstants.IDX_CONF_ROOM_MAIL].isEmpty()) {
                    responsePoiBulkImportDTO
                            .addError(String.format("Line %s: ConfRoomMail column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(poiFromCsv[PoiConstants.IDX_HEADER_CAPACITY])
                        || poiFromCsv[PoiConstants.IDX_HEADER_CAPACITY].isEmpty()) {
                    responsePoiBulkImportDTO
                            .addError(String.format("Line %s: Capacity column shouldn't be empty.", lineNumber));
                }

                if (Objects.isNull(responsePoiBulkImportDTO.getErrorsInFile())
                        || responsePoiBulkImportDTO.getErrorsInFile().isEmpty()) {
                    try {
                        // Create PoiBulkImportDTO from the line
                        PoiBulkImportDTO poiBulkImportDTO = createPoiImportDTO(poiFromCsv);
                        responsePoiBulkImportDTO.addPoi(poiBulkImportDTO);
                    } catch (NumberFormatException e) {
                        log.error("Failed to parse POI import data at line {}.", lineNumber, e);
                        String error = String.format("Line %s: Error while parsing information.", lineNumber);
                        responsePoiBulkImportDTO.addError(error);
                    } catch (Exception e) {
                        log.error("Failed to import POI data at line {}.", lineNumber, e);
                        String error = String.format("Line %s: Error while importing poi.", lineNumber);
                        responsePoiBulkImportDTO.addError(error);
                    }

                }
            }
        } catch (IOException e) {
            log.error("Failed to read POI import file.", e);
            String error = "Error while reading the file.";
            responsePoiBulkImportDTO.addError(error);
        }

        return responsePoiBulkImportDTO;
    }

    /**
     * Creates a {@link PoiBulkImportDTO} from a CSV line.
     *
     * @param poiFromCsv The CSV line representing a POI.
     * @return A populated PoiBulkImportDTO.
     * @throws NumberFormatException if numeric parsing fails.
     */
    private PoiBulkImportDTO createPoiImportDTO(String[] poiFromCsv) throws NumberFormatException {
        PoiBulkImportDTO poiBulkImportDTO = new PoiBulkImportDTO();

        poiBulkImportDTO.setPoiName(poiFromCsv[PoiConstants.IDX_POI_NAME]);
        poiBulkImportDTO.setConfRoomMail(poiFromCsv[PoiConstants.IDX_CONF_ROOM_MAIL]);
        poiBulkImportDTO.setCapacity(poiFromCsv[PoiConstants.IDX_HEADER_CAPACITY]);

        return poiBulkImportDTO;
    }

    /**
     * Updates the attributes of a POI using data from a {@link PoiBulkImportDTO}.
     *
     * @param poiBulkImportDTO The DTO containing updated attribute values.
     * @param poi              The POI entity to update.
     */
    public void updatePoiAttributes(PoiBulkImportDTO poiBulkImportDTO, Poi poi) {
        // Update POI attributes if the Poi is not null
        if (Objects.nonNull(poi)) {
            if (Objects.nonNull(poi.getAttributes())) {
                poi.getAttributes().put(PoiConstants.CONF_ROOM_MAIL,
                        String.valueOf(poiBulkImportDTO.getConfRoomMail()).trim());
                poi.getAttributes().put(PoiConstants.CAPACITY, String.valueOf(poiBulkImportDTO.getCapacity()));
            } else {
                Map<String, String> attributes = new HashMap<>();
                attributes.put(PoiConstants.CONF_ROOM_MAIL, String.valueOf(poiBulkImportDTO.getConfRoomMail()).trim());
                attributes.put(PoiConstants.CAPACITY, String.valueOf(poiBulkImportDTO.getCapacity()));
                poi.setAttributes(attributes);
            }
            poi.setModifiedAt((new Date()).getTime() / 1000);
            this.poiRepository.saveAndFlush(poi);
        }
    }

    /**
     * Updates a specific attribute's visibility across POIs.
     *
     * @param value The value to set.
     * @param key   The attribute key to update.
     */
    @Transactional
    public void updateShowAttribute(String value, String key) {
        try {
            this.poiRepository.setShowAttribute(value, key);
        } catch (DataAccessException ex) {
            String safeKey = sanitizeForLog(key);
            log.error("Failed to update show attribute for key {}.", safeKey, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update POI attribute visibility.");
        }
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }


    private static final List<String> ATTRIBUTE_ORDER = Arrays.asList(

            "conf_room_mail",
            "capacity",
            "bookable",
            "hidePoi",
            "showState",
            "checkIn",
            "checkOut",
            "showTemp",
            "showHumidity",
            "showCo2",
            "showSound",
            "showLux");

    /**
     * Sorts POI attributes based on a predefined order.
     * Unordered attributes are appended at the end.
     *
     * @param attributes The original attribute map.
     * @return A sorted attribute map.
     */
    public Map<String, String> sortAttributes(Map<String, String> attributes) {
        Map<String, String> sortedAttributes = new LinkedHashMap<>();

        for (String key : ATTRIBUTE_ORDER) {
            if (attributes.containsKey(key)) {
                sortedAttributes.put(key, attributes.get(key));
            }
        }

        // Add any remaining attributes that are not in the predefined order
        attributes
                .entrySet()
                .stream()
                .filter(entry -> !sortedAttributes.containsKey(entry.getKey()))
                .forEach(entry -> sortedAttributes.put(entry.getKey(), entry.getValue()));

        return sortedAttributes;
    }

    /**
     * Retrieves the next available POI sequence number.
     *
     * @return The next POI sequence number.
     */
    public Integer findByNextPoiSequence() {
        try {
            return this.poiRepository.findByNextPoiSequence();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve next POI sequence.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve next POI sequence.");
        }
    }


    /**
     * Sets the Locker Bank ID in the POI attributes based on the Locker Bank Name
     * and Tenant.
     * 
     * This method checks if the POI has attributes and whether the Locker Bank Name
     * and Tenant are present.
     * If the Locker Bank ID is either blank or equals a predefined null string, it
     * retrieves the Bank ID
     * using the Vecos client and updates the POI attributes accordingly.
     *
     * @param poi the POI object containing locker-related attributes
     */
    private void setBankIdFromBankName(Poi poi) {
        if (Objects.nonNull(poi.getAttributes())) {
            String lockerBankName = poi.getAttributes().get(VecosConstants.LOCKER_BANK_NAME);
            String lockerTenant = poi.getAttributes().get(VecosConstants.LOCKER_TENANT);
            String lockerBankId = poi.getAttributes().get(VecosConstants.LOCKER_BANK_ID);
            String lockerBankIdFromVecos = null;
            boolean hasBankName = Objects.nonNull(lockerBankName) && !lockerBankName.isBlank();
            boolean hasTenant = Objects.nonNull(lockerTenant) && !lockerTenant.isBlank();
            
            boolean bankIdIsBlankOrNull = Objects.nonNull(lockerBankId) && lockerBankId.isBlank()
                    || Constants.NULLSTRING.equalsIgnoreCase(lockerBankId);
                    
            // SSRF guard: lockerBankName and lockerTenant are user-controlled and are passed
            // to VecosClient where they flow into outbound HTTP requests. Restrict them to a
            // safe character set (alphanumerics, dot, dash, underscore, space) so an attacker
            // cannot inject URL control characters (/, :, ?, #, @, ..) to retarget the request.
            if (hasBankName && hasTenant && bankIdIsBlankOrNull
                    && isSafeVecosToken(lockerBankName) && isSafeVecosToken(lockerTenant)) {
                        
                lockerBankIdFromVecos = vecosClient.retrieveBankIdFromBankName(lockerBankName, lockerTenant);
                 
                if (lockerBankIdFromVecos != null) {
                    
                    poi.getAttributes().put(VecosConstants.LOCKER_BANK_ID, lockerBankIdFromVecos);
                     
                }
            }
        }
    }

    // Allow only a conservative set of characters that are safe to embed inside an HTTP
    // URL path/query segment built by VecosClient. Rejects '/', ':', '?', '#', '@',
    // whitespace control chars, and anything that could be used to pivot the request
    // target (SSRF). Kept package-private/static for unit testing.
    private static final java.util.regex.Pattern SAFE_VECOS_TOKEN =
            java.util.regex.Pattern.compile("^[A-Za-z0-9._\\- ]{1,128}$");

    private static boolean isSafeVecosToken(String value) {
        return value != null && SAFE_VECOS_TOKEN.matcher(value).matches();
    }

    /**
     * Removes any trailing ',' characters from the given line in a single pass.
     * Replaces the prior {@code while (line.endsWith(",")) line = line.substring(...)}
     * loop whose iteration count was driven by attacker-controlled CSV content.
     *
     * @param line the input line (must not be null)
     * @return the line with trailing commas removed
     */
    private static String stripTrailingCommas(String line) {
        int end = line.length();
        while (end > 0 && line.charAt(end - 1) == ',') {
            end--;
        }
        return end == line.length() ? line : line.substring(0, end);
    }

    /**
     * Sets the Locker Free Number in the POI attributes based on the Locker Bank ID
     * and Tenant.
     * 
     * This method checks if the POI has attributes and whether the Locker Bank ID
     * and Tenant are present.
     * If both are available, it retrieves the next available locker number using
     * the Vecos client
     * and updates the POI attributes accordingly.
     *
     * @param poi the POI object containing locker-related attributes
     */
    private void setLockerFreeNumber(Poi poi) {
        if (Objects.nonNull(poi.getAttributes())) {
            String lockerFreeNumber = null;
            String lockerTenant = poi.getAttributes().get(VecosConstants.LOCKER_TENANT);
            String lockerBankId = poi.getAttributes().get(VecosConstants.LOCKER_BANK_ID);
            boolean hasBankId = Objects.nonNull(lockerBankId) && !lockerBankId.isBlank();
            boolean hasTenant = Objects.nonNull(lockerTenant) && !lockerTenant.isBlank();
            // SSRF guard: lockerBankId is concatenated into the Vecos request URL path in
            // VecosClient.getLockerFreeNumber, and lockerTenant drives authentication / API
            // calls. Reject any value containing URL control characters so an attacker
            // cannot pivot the outbound request to an arbitrary host or path.
            if (hasBankId && hasTenant
                    && isSafeVecosToken(lockerBankId.trim()) && isSafeVecosToken(lockerTenant)) {
                lockerFreeNumber = vecosClient.getLockerFreeNumber(lockerBankId, lockerTenant);
                poi.getAttributes().put(VecosConstants.LOCKER_FREE_NUMBER, String.valueOf(lockerFreeNumber));
            }
        }
    }

}