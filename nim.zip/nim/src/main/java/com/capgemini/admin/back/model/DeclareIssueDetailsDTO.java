package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class DeclareIssueDetailsDTO {
    private Long id;
    private Long declareIssueId;
    private Long countryId;
    private String emailId;
    private Long modifiedAt;
    private Long createdAt;
    private DeclareIssueDTO declareIssue;
}