package com.capgemini.admin.back.controller.procedure;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.procedure.AppConfigValueMapper;

import com.capgemini.admin.back.mapper.procedure.FrontLabelMapper;
import com.capgemini.admin.back.mapper.procedure.LangNodeMapper;
import com.capgemini.admin.back.mapper.procedure.LogAuditTranslationMapper;
import com.capgemini.admin.back.model.procedure.AppConfigValue;
import com.capgemini.admin.back.model.procedure.AppConfigValueDTO;
import com.capgemini.admin.back.model.procedure.EntityDataDTO;
import com.capgemini.admin.back.model.procedure.EntityFieldIndexDTO;
import com.capgemini.admin.back.model.procedure.FrontLabel;
import com.capgemini.admin.back.model.procedure.FrontLabelDTO;
import com.capgemini.admin.back.model.procedure.LangAdminNode;



import com.capgemini.admin.back.model.procedure.LangNodeDTO;
import com.capgemini.admin.back.model.procedure.LangUserNode;
import com.capgemini.admin.back.model.procedure.LogAuditTranslation;
import com.capgemini.admin.back.model.procedure.LogAuditTranslationDTO;
import com.capgemini.admin.back.model.procedure.TranslatedEntityDTO;
import com.capgemini.admin.back.model.procedure.TranslationEntityDTO;
import com.capgemini.admin.back.service.procedure.ProcedureService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nimbusds.oauth2.sdk.GeneralException;


import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping(value = ProcedureController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ProcedureController {
    static final String ROOT_API = "api/procedure";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class FrontLabelUpdateInput {
        @NotNull
        @Size(min = 1, max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String keyId;

        @NotNull
        @Size(min = 1, max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String fieldKey;

        @NotNull
        @Size(min = 1, max = 4000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String languageText;

        @NotNull
        @Size(min = 2, max = 16)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String languageCode;
    }


    @Autowired
    private ProcedureService procedureService;

    @GetMapping(value = "getMobileData")
    public ResponseEntity<List<FrontLabelDTO>> getMobileData(@RequestParam String languageCode) {
        List<FrontLabel> frontLabels = procedureService.getMobileDataByLanguageCode(languageCode);

        if (frontLabels == null || frontLabels.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<FrontLabelDTO> frontLabelDTOs = frontLabels.stream()
                .map(FrontLabelMapper.INSTANCE::frontLabelToFrontLabelDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(frontLabelDTOs);
    }

    @GetMapping(value = "getLangUserNode")
    public ResponseEntity<List<LangNodeDTO>> getLangUserNode() {
        List<LangUserNode> langUserNodes = procedureService.getLangUserNode();

        if (langUserNodes == null || langUserNodes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<LangNodeDTO> langNodeDTOs = langUserNodes.stream()
                .map(LangNodeMapper.INSTANCE::langUserNodeToLangNodeDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(langNodeDTOs);
    }

    @GetMapping(value = "getLangAdminNode")
    public ResponseEntity<List<LangNodeDTO>> getLangAdminNode() {
        List<LangAdminNode> langAdminNodes = procedureService.getLangAdminNode();

        if (langAdminNodes == null || langAdminNodes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<LangNodeDTO> langNodeDTOs = langAdminNodes.stream()
                .map(LangNodeMapper.INSTANCE::langAdminNodeToLangNodeDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(langNodeDTOs);
    }

    @GetMapping(value = "getEntityData")
    public ResponseEntity<List<EntityDataDTO>> getEntityData(@RequestParam String entityName) {
        List<EntityDataDTO> entityDataDTOs = procedureService.getEntityData(entityName);

        if (entityDataDTOs == null || entityDataDTOs.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(entityDataDTOs);
    }

    @GetMapping(value = "getEntityByEntity")
    public ResponseEntity<List<EntityFieldIndexDTO>> getEntityByEntity(@RequestParam String entity) {
        List<EntityFieldIndexDTO> entityFieldIndexDTOs = procedureService.getEntityByEntity(entity);

        if (entityFieldIndexDTOs == null || entityFieldIndexDTOs.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(entityFieldIndexDTOs);
    }

    @GetMapping(value = "getTranslationEntity")
    public ResponseEntity<List<TranslationEntityDTO>> getTranslationEntity() {
        List<String> translationEntities = procedureService.getTranslationEntity();

        if (translationEntities == null || translationEntities.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<TranslationEntityDTO> translationEntityDTOs = translationEntities.stream()
                .map(TranslationEntityDTO::new)
                .collect(Collectors.toList());

        return ResponseEntity.ok(translationEntityDTOs);
    }

    @GetMapping(value = "getAppConfigByConfigkey")
    public ResponseEntity<AppConfigValueDTO> getAppConfigByConfigkey(@RequestParam String configKey) {
        AppConfigValue appConfigValue = procedureService.getAppConfigByConfigkey(configKey);

        if (appConfigValue == null) {
            return ResponseEntity.notFound().build();
        }

        AppConfigValueDTO appConfigValueDTO = AppConfigValueMapper.INSTANCE
                .appConfigValueToAppConfigValueDTO(appConfigValue);

        return ResponseEntity.ok(appConfigValueDTO);
    }

    @PostMapping(value = "updateMobileData")
    public ResponseEntity<Object> updateMobileData(
            @Valid @RequestBody @NotNull @Size(min = 1) List<@Valid FrontLabelUpdateInput> frontLabelInputs) {
        try {
            List<ProcedureService.FrontLabelWriteInput> sanitizedInputs = toSanitizedFrontLabelWriteInputs(frontLabelInputs);

            procedureService.saveMobileData(sanitizedInputs);



            return ResponseEntity.accepted().build();
        } catch (IllegalArgumentException e) {
            log.warn("Invalid mobile data payload: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            log.error("Error updating mobile data: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }



    private List<ProcedureService.FrontLabelWriteInput> toSanitizedFrontLabelWriteInputs(
            List<FrontLabelUpdateInput> frontLabelInputs) {
        List<ProcedureService.FrontLabelWriteInput> sanitizedInputs = new ArrayList<>();

        if (frontLabelInputs == null) {
            throw new IllegalArgumentException("frontLabelInputs must not be null");
        }

        for (FrontLabelUpdateInput frontLabelInput : frontLabelInputs) {
            if (frontLabelInput == null) {
                throw new IllegalArgumentException("frontLabelInput must not be null");
            }

            sanitizedInputs.add(new ProcedureService.FrontLabelWriteInput(
                    frontLabelInput.getKeyId() == null
                            ? null
                            : new String(String.valueOf(frontLabelInput.getKeyId())),
                    frontLabelInput.getFieldKey() == null
                            ? null
                            : new String(String.valueOf(frontLabelInput.getFieldKey())),
                    frontLabelInput.getLanguageText() == null
                            ? null
                            : new String(String.valueOf(frontLabelInput.getLanguageText())),
                    frontLabelInput.getLanguageCode() == null
                            ? null
                            : new String(String.valueOf(frontLabelInput.getLanguageCode()))));
        }

        return sanitizedInputs;
    }


    @PostMapping(value = "updateEntityData")

    public ResponseEntity<Object> updateEntityData(
            @RequestBody List<TranslatedEntityDTO> entities,
            @RequestParam String entityName,
            @RequestParam String languageCode) {
        try {
            procedureService.saveEntityData(entities, entityName, languageCode);
            return ResponseEntity.accepted().build();
        } catch (GeneralException e) {
            log.error("Error saving entity data: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping(value = "insertLogAuditTranslation")
    public ResponseEntity<Object> insertLogAuditTranslation(
            @RequestBody LogAuditTranslationDTO logAuditTranslationDTO) {

        LogAuditTranslation logAuditTranslation = LogAuditTranslationMapper.INSTANCE
                .logAuditTranslationDTOToLogAuditTranslation(logAuditTranslationDTO);

        if (logAuditTranslation == null) {
            log.warn("Received null LogAuditTranslation after mapping from DTO.");
            return ResponseEntity.badRequest().build();
        }

        try {
            procedureService.saveLogAudit(logAuditTranslation);
            return ResponseEntity.accepted().build();
        } catch (Exception e) {
            log.error("Error saving audit log: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }
}