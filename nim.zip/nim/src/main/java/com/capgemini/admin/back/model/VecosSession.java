package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * A simple POJO to represent a Vecos Session
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class VecosSession {

	@JsonProperty("access_token")
	private String accessToken;

	@JsonProperty("refresh_token")
	private String refreshToken;

}