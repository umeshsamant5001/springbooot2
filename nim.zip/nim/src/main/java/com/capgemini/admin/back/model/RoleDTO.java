package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class RoleDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    private String name;
    private Long precedence;
    private Boolean isActive;
    private Boolean isWebUserProfile;
    private List<FeatureAccessDTO> featureAccesses;
}
