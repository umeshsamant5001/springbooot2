package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "facility_manager")
public class FacilityManager {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FacilityManager_Generator")
    @SequenceGenerator(name = "FacilityManager_Generator", sequenceName = "FacilityManager_Sequence")
    private String uuid;

    @Column(name = "name")
    private String name;
    @Column(name = "title_en_floor")
    private String titleEnFloor;
    @Column(name = "title_en_building")
    private String titleEnBuilding;
    @Column(name = "level")
    private String level;
    @Column(name = "email")
    private String email;
}
