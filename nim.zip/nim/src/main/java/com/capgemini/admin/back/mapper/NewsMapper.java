package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.News;
import com.capgemini.admin.back.model.NewsDTO;

@Mapper(config = DtoMapperConfig.class)
public interface NewsMapper {

    NewsMapper INSTANCE = Mappers.getMapper(NewsMapper.class);

    News newsDTOToNews(NewsDTO in);

    NewsDTO newsToNewsDTO(News in);
}
