package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.DeclareIssueDetails;

@Repository
public interface DeclareIssueDetailsRepository extends JpaRepository<DeclareIssueDetails, Long> {

        @Query("SELECT d FROM DeclareIssueDetails d JOIN FETCH d.declareIssue WHERE d.countryId = :countryId")
        List<DeclareIssueDetails> findByCountryId(@Param("countryId") Long countryId);

        List<DeclareIssueDetails> findByIdInAndCountryId(List<Long> ids, Long countryId);

        @EntityGraph(attributePaths = { "declareIssue" })
        List<DeclareIssueDetails> findByIdIn(List<Long> ids);


        @Modifying
        @Query("DELETE FROM DeclareIssueDetails d WHERE d.id IN :ids AND d.countryId = :countryId")
        void deleteByIdsandCountryId(@Param("ids") List<Long> ids, @Param("countryId") Long countryId);

        DeclareIssueDetails findByCountryIdAndDeclareIssueId(Long countryId, Long declareIssueId);

}
