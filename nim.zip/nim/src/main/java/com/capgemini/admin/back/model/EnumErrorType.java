package com.capgemini.admin.back.model;

public enum EnumErrorType {

	EVALERROR, OTHERERROR, RANGEERROR, REFERENCEERROR, SYNTAXERROR, TYPEERROR, URLERROR, DBERROR, INDEXOUTOFBOUNDERROR;

	public static EnumErrorType findByName(String name) {
		EnumErrorType result = null;
		for (EnumErrorType errorType : values()) {
			if (errorType.name().equalsIgnoreCase(name)) {
				result = errorType;
				break;
			}
		}
		return result;
	}

}
