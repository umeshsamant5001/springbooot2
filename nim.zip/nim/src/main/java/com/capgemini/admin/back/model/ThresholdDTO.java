package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class ThresholdDTO {
    private ThresholdType type;
    private ThresholdLevel level;
    private String value;
    private String unit;
}
