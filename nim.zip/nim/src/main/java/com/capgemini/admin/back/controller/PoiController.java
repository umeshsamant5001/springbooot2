package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.capgemini.admin.back.helper.AverageValues;
import com.capgemini.admin.back.mapper.PoiMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.Equipment;
import com.capgemini.admin.back.model.EquipmentDTO;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.FloorDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Poi;
import com.capgemini.admin.back.model.PoiBulkImportDTO;
import com.capgemini.admin.back.model.PoiDTO;
import com.capgemini.admin.back.model.ResponsePoiBulkImportDTO;
import com.capgemini.admin.back.model.SensorDataDTO;
import com.capgemini.admin.back.model.Site;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.SpaceTypeDTO;
import com.capgemini.admin.back.model.SubLevelEnum;

import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.CityService;
import com.capgemini.admin.back.service.CountryService;
import com.capgemini.admin.back.service.DeviceService;
import com.capgemini.admin.back.service.FloorService;
import com.capgemini.admin.back.service.PoiService;
import com.capgemini.admin.back.service.SensorDataService;
import com.capgemini.admin.back.service.SiteService;
import com.capgemini.admin.back.service.SpaceTypeService;
import com.capgemini.admin.back.service.TreeService;

import com.capgemini.admin.back.temporary.EnumCdmAttributes;
import com.capgemini.admin.utils.ExportCsv;
import com.capgemini.admin.utils.SensorUtil;
import com.hazelcast.internal.util.CollectionUtil;
import com.capgemini.admin.back.config.PoiConstants;
import com.capgemini.admin.back.vecos.VecosConstants;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = PoiController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
public class PoiController {

    public static final String ROOT_API = "api/poi";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @Autowired
    private PoiService poiService;

    @Autowired
    private SensorDataService sensorDataService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private SiteService siteService;

    @Autowired
    private CityService cityService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private SpaceTypeService spaceTypeService;

    @Autowired
    private TreeService treeService;

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
@Data
private static class PoiWriteRequest {

    @Min(1)
    private Long id;

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String name;

    @Valid
    private FloorDTO floor;

    @Min(1)
    private Long floorId;

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String titleFr;

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String titleEn;

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String title;

    @Valid
    private SpaceTypeDTO spaceType;

    @Min(1)
    private Long spaceTypeId;

    @Min(0)
    private Long modifiedAt;

    @Min(0)
    private Long cdmKeyId;

    @Size(max = 1000)
    private Map<String, String> attributes = new HashMap<>();

    @Size(max = 1000)
    private List<EquipmentDTO> equipments = new ArrayList<>();

    @Size(max = 1000)
    private Map<String, String> cdmAttributes = new HashMap<>();

    @Size(max = 1000)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String description;

    private Integer floorIndex;

    @Valid
    private SensorDataDTO sensorData;
}

    /**
     * Get Pois by Type and building id
     *
     * 
     * @param language   : language of poi information
     * @param typeId
     * @param buildingId
     * @return list of pois
     */
    @GetMapping("/type/{typeId}/building/{buildingId}")
    public ResponseEntity<List<PoiDTO>> getAllPoisByTypeIdAndBuildingId(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("typeId") Long typeId,
            @PathVariable("buildingId") Long buildingId,
            @RequestParam(required = false) List<Long> floorIds,
            @RequestParam(defaultValue = "false") boolean withSensorData) {
        if (!this.treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        List<Poi> pois = this.poiService.findAllByTypeIdAndBuildingIdAndFloorId(Arrays.asList(typeId),
                Arrays.asList(buildingId), floorIds);

        if (CollectionUtils.isEmpty(pois)) {
            return ResponseEntity.notFound().build();
        }

        // Convert to DTOs
        List<PoiDTO> poisDTO = this.poiService.poiListToPoiDTOList(language).apply(pois);

        if (withSensorData) {
            List<Device> deviceList = this.deviceService.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(
                    Arrays.asList(typeId), Arrays.asList(buildingId), floorIds);

            this.addSensorDataToPoi(poisDTO, deviceList);
        }

        return ResponseEntity.ok(poisDTO);
    }

    @GetMapping("/building")
    public ResponseEntity<List<PoiDTO>> getAllPoisByBuildingIds(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestParam(required = true) List<Long> buildingIds,
            @RequestParam(required = false) List<Long> typeIds,
            @RequestParam(defaultValue = "false") boolean withSensorData) {
        // Check if each building exists
        for (Long buildingId : buildingIds) {
            boolean buildingExists = this.buildingService.buidingExists(buildingId);
            if (!buildingExists) {
                return ResponseEntity.badRequest().build();
            }
        }

        buildingIds = this.treeService.filterId(LevelEnum.BUILDING, buildingIds);

        // Fetch regular POIs
        List<Poi> pois = this.poiService.findAllByTypeIdAndBuildingIdAndFloorId(typeIds, buildingIds, null);
        if (CollectionUtils.isEmpty(pois)) {
            return ResponseEntity.notFound().build();
        }

        // Convert to DTOs
        List<PoiDTO> poisDTO = this.poiService.poiListToPoiDTOList(language).apply(pois);

        if (withSensorData) {
            List<Device> deviceList = this.deviceService.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(typeIds,
                    buildingIds, null);

            this.addSensorDataToPoi(poisDTO, deviceList);
        }

        return ResponseEntity.ok(poisDTO);
    }

    /**
     * Get Pois by Type and building id
     *
     * @param language       : language of poi information
     * @param floorIds
     * @param withSensorData
     * @param buildingId
     * @return list of pois
     */
    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<PoiDTO>> getAllPoisByBuildingId(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("buildingId") Long buildingId,
            @RequestParam(required = false) List<Long> floorIds,
            @RequestParam(defaultValue = "false") boolean withSensorData) {
        if (!this.treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        // Fetching regular POIs
        List<Poi> pois = this.poiService.findAllByTypeIdAndBuildingIdAndFloorId(null, Arrays.asList(buildingId),
                floorIds);
        if (CollectionUtils.isEmpty(pois)) {
            return ResponseEntity.notFound().build();
        }

        List<PoiDTO> poisDTO = this.poiService.poiListToPoiDTOList(language).apply(pois);

        if (withSensorData) {
            List<Device> deviceList = this.deviceService.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(null,
                    Arrays.asList(buildingId), floorIds);

            this.addSensorDataToPoi(poisDTO, deviceList);
        }

        // Calculate apparent temperature for each POI
        poisDTO = poisDTO
                .stream()
                .map(poi -> {
                    if (Objects.isNull(poi.getSensorData()) ||
                            Objects.isNull(poi.getSensorData().getHumidity()) ||
                            Objects.isNull(poi.getSensorData().getTempC())) {
                        return poi;
                    }
                    Double temp = poi.getSensorData().getTempC();
                    Double humidity = poi.getSensorData().getHumidity();
                    Double apparentTemp = SensorUtil.calculApparentTemp(temp, humidity);
                    poi.getSensorData().setApparentTemp(apparentTemp);
                    return poi;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(poisDTO);
    }

    /**
     * Get Pois by Type and Floor id
     *
     * @param language : language of poi information
     * @param typeId
     * @param floorId
     * @return list of pois
     */
    @GetMapping("/type/{typeId}/floor/{floorId}")
    public ResponseEntity<List<PoiDTO>> getAllPoisByTypeIdAndFloorId(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("typeId") Long typeId,
            @PathVariable("floorId") Long floorId,
            @RequestParam(defaultValue = "false") boolean withSensorData) {
        // Authorization check
        if (!this.treeService.isAuthorized(SubLevelEnum.FLOOR, floorId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        // Fetching POIs
        List<Poi> pois = this.poiService.findAllByTypeIdAndFloorId(typeId, floorId);
        if (CollectionUtils.isEmpty(pois)) {
            return ResponseEntity.notFound().build();
        }

        // Convert to DTOs
        List<PoiDTO> poisDTO = this.poiService.poiListToPoiDTOList(language).apply(pois);

        if (withSensorData) {
            List<Device> deviceList = this.deviceService.findAllViaPoiByTypeIdAndFloorId(floorId, typeId);
            this.addSensorDataToPoi(poisDTO, deviceList);
        }

        return ResponseEntity.ok(poisDTO);
    }

    /**
     * Get Pois by Floor id and order by name
     *
     * @param language : language of poi information
     * @param floorId
     * @return list of pois
     */
    @GetMapping("/floor/{floorId}/orderByName")
    public ResponseEntity<List<PoiDTO>> getAllPoisByFloorIdOrderByName(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("floorId") Long floorId,
            @RequestParam(defaultValue = "false") boolean withSensorData) {
        if (!this.treeService.isAuthorized(SubLevelEnum.FLOOR, floorId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        List<Poi> pois = this.poiService.findAllByFloorIdOrderByName(floorId);
        if (CollectionUtils.isEmpty(pois)) {
            return ResponseEntity.ok(new ArrayList<PoiDTO>());
        }
        List<PoiDTO> poisDTO = this.poiService.poiListToPoiDTOList(language).apply(pois);

        if (withSensorData) {
            List<Device> deviceList = this.deviceService.findAllViaPoiByFloorId(floorId);

            this.addSensorDataToPoi(poisDTO, deviceList);
        }
        poisDTO = poisDTO
                .stream()
                .map(poi -> {
                    if (Objects.isNull(poi.getSensorData()) ||
                            Objects.isNull(poi.getSensorData().getHumidity()) ||
                            Objects.isNull(poi.getSensorData().getTempC())) {
                        return poi;
                    }
                    Double temp = poi.getSensorData().getTempC();
                    Double humidity = poi.getSensorData().getHumidity();
                    Double apparentTemp = SensorUtil.calculApparentTemp(temp, humidity);
                    poi.getSensorData().setApparentTemp(apparentTemp);
                    return poi;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(poisDTO);
    }

    /**
     * Get a POI by name
     *
     * @param name
     * @return pois
     */
    @GetMapping(value = "/name/{name}")
    public ResponseEntity<PoiDTO> getPoiByName(
            @PathVariable String name,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Poi poi = this.poiService.findByName(name);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }

        if (!this.treeService.isAuthorized(SubLevelEnum.POI, poi.getId())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, language);
        return ResponseEntity.ok(poiDTO);
    }

    /**
     * Get a POI by id
     *
     * @param poiId
     * @return poi
     */
    @GetMapping("/{poiId}")
    public ResponseEntity<PoiDTO> getPoi(
            @PathVariable Long poiId,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {

        Poi poi = poiService.findById(poiId);
        if (poi == null) {
            return ResponseEntity.notFound().build();
        }

        if (!treeService.isAuthorized(SubLevelEnum.POI, poi.getId())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        PoiDTO poiDTO = PoiMapper.INSTANCE.poiToPoiDTO(poi, language);
        poiDTO.setAttributes(poiService.sortAttributes(poiDTO.getAttributes()));

        if (poiDTO.getCdmAttributes() != null && Boolean.FALSE.equals(poiDTO.getSpaceType().getIsFromCdm())) {
            poiDTO.getAttributes().putAll(poiDTO.getCdmAttributes());
            poiDTO.setCdmAttributes(null);
        }
        return ResponseEntity.ok(poiDTO);
    }

    /**
     * Create a POI
     *
     * @param poiDTO
     * @return poi
     */

    @PostMapping
    @Transactional
    public ResponseEntity<PoiDTO> createPoi(
            @Valid @RequestBody PoiWriteRequest poiDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (!hasSafeLockerAttributes(poiDTO)) {
            return ResponseEntity.badRequest().build();
        }
        Long safeFloorId = resolveFloorId(poiDTO);
        Long safeSpaceTypeId = resolveSpaceTypeId(poiDTO);
        if (Objects.isNull(safeFloorId) || Objects.isNull(safeSpaceTypeId)) {
            return ResponseEntity.badRequest().build();
        }
        if (!this.treeService.isAuthorized(SubLevelEnum.FLOOR, safeFloorId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        String safeName = sanitizeOptionalTextInput(poiDTO.getName(), 255);
        PoiDTO sanitizedPoiDTO = new PoiDTO();
        sanitizedPoiDTO.setName(safeName);
        sanitizedPoiDTO.setFloorId(safeFloorId);
        sanitizedPoiDTO.setTitleEn(sanitizeOptionalTextInput(poiDTO.getTitleEn(), 255));
        sanitizedPoiDTO.setTitleFr(sanitizeOptionalTextInput(poiDTO.getTitleFr(), 255));
        sanitizedPoiDTO.setSpaceTypeId(safeSpaceTypeId);
        Long safeCdmKeyId = poiDTO.getCdmKeyId() == null ? null : Long.valueOf(poiDTO.getCdmKeyId());
        sanitizedPoiDTO.setCdmKeyId(safeCdmKeyId);
        sanitizedPoiDTO.setAttributes(sanitizeAttributes(poiDTO.getAttributes()));
        sanitizedPoiDTO.setCdmAttributes(sanitizeAttributes(poiDTO.getCdmAttributes()));
        sanitizedPoiDTO.setEquipments(sanitizeEquipments(poiDTO.getEquipments()));
        sanitizedPoiDTO.setDescription(sanitizeOptionalTextInput(poiDTO.getDescription(), 1000));
        Poi poi = PoiMapper.INSTANCE.poiDTOToPoi(sanitizedPoiDTO);

        if (Objects.isNull(poi)) {
            return ResponseEntity.badRequest().build();
        }
        SpaceType resolvedSpaceType = spaceTypeService.getSpaceTypeById(safeSpaceTypeId);
        if (Objects.isNull(resolvedSpaceType)) {
            return ResponseEntity.badRequest().build();
        }
        poi.setSpaceType(resolvedSpaceType);
        poi.setSpaceTypeId(resolvedSpaceType.getId());

        if (PoiConstants.TYPE_LOCKER.equals(resolvedSpaceType.getSpaceTypeName())
                || PoiConstants.TYPE_COMFORT.equals(resolvedSpaceType.getSpaceTypeName())) {

            if (Objects.isNull(safeName) || safeName.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
            poi.setName(safeName);
            if (Objects.nonNull(this.poiService.checkPoiNameExist(poi))) {
                return ResponseEntity.status(HttpStatus.CONFLICT).build();
            }
        }

        Poi safePoiForPersistence = toSafePoiForPersistence(poi);

        poi = poiService.createPoi(safePoiForPersistence);

        if (Objects.isNull(poi)) {
            log.error("Failed to create POI - returned null from poiService.createPoi");
            return ResponseEntity.internalServerError().build();
        }

        if (Objects.isNull(safeName) || safeName.isEmpty()) {
            initPoiName(poi);
        }
        return ResponseEntity.ok(
                PoiMapper.INSTANCE.poiToPoiDTO(poi, language));
    }

    /**
     * Updates an existing POI identified by its ID.
     * This method handles HTTP PUT requests to update a POI. It accepts a POI ID as
     * a path variable,
     * a POI data transfer object (DTO) in the request body, and an optional
     * "Accept-Language" header
     * to determine the language for the response.
     *
     * If the POI with the given ID does not exist, it returns a 404 Not Found
     * response.
     * If CDM attributes are present in the DTO, it merges them based on the source
     * of the space type and maps the DTO to the appropriate entity.
     * The updated POI is then persisted and returned as a DTO in the response.
     *
     * @param poiId    the ID of the POI to update
     * @param poiDTO   the POI data to update
     * @param language the preferred language for the response (default is "en")
     * @return a ResponseEntity containing the updated POI DTO or an appropriate
     *         error response
     */
    @PutMapping("/{poiId}")
    public ResponseEntity<PoiDTO> updatePoi(
            @PathVariable Long poiId,
            @Valid @RequestBody PoiWriteRequest poiDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Poi existingPoi = poiService.findById(poiId);

        if (existingPoi == null) {
            return ResponseEntity.notFound().build();
        }

        if (!hasSafeLockerAttributes(poiDTO)) {
            return ResponseEntity.badRequest().build();
        }

        Long safeFloorId = resolveFloorId(poiDTO);
        Long safeSpaceTypeId = resolveSpaceTypeId(poiDTO);

        if (Objects.isNull(safeFloorId)
                || Objects.isNull(safeSpaceTypeId)) {
            return ResponseEntity.badRequest().build();
        }

        if (!treeService.isAuthorized(
                SubLevelEnum.FLOOR,
                safeFloorId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        SpaceType resolvedSpaceType = spaceTypeService.getSpaceTypeById(safeSpaceTypeId);

        if (resolvedSpaceType == null) {
            return ResponseEntity.badRequest().build();
        }

        PoiDTO sanitizedPoiDTO = new PoiDTO();

        sanitizedPoiDTO.setId(existingPoi.getId());

        String safeName = sanitizeOptionalTextInput(
                poiDTO.getName(),
                255);

        sanitizedPoiDTO.setName(safeName);
        sanitizedPoiDTO.setFloorId(safeFloorId);

        sanitizedPoiDTO.setTitleEn(
                sanitizeOptionalTextInput(
                        poiDTO.getTitleEn(),
                        255));

        sanitizedPoiDTO.setTitleFr(
                sanitizeOptionalTextInput(
                        poiDTO.getTitleFr(),
                        255));

        sanitizedPoiDTO.setSpaceTypeId(safeSpaceTypeId);
        sanitizedPoiDTO.setSpaceType(resolvedSpaceType);

        Long safeCdmKeyId = poiDTO.getCdmKeyId() == null ? null : Long.valueOf(poiDTO.getCdmKeyId());
        sanitizedPoiDTO.setCdmKeyId(safeCdmKeyId);

        sanitizedPoiDTO.setAttributes(
                sanitizeAttributes(
                        poiDTO.getAttributes()));

        sanitizedPoiDTO.setCdmAttributes(
                sanitizeAttributes(
                        poiDTO.getCdmAttributes()));

        sanitizedPoiDTO.setEquipments(
                sanitizeEquipments(
                        poiDTO.getEquipments()));

        sanitizedPoiDTO.setDescription(
                sanitizeOptionalTextInput(
                        poiDTO.getDescription(),
                        1000));

        Poi newPoi;

        // Restore ORIGINAL business logic
        if (sanitizedPoiDTO.getCdmAttributes() != null) {

            if (resolvedSpaceType.getIsFromCdm() != null) {

                sanitizedPoiDTO.getAttributes()
                        .putAll(
                                sanitizedPoiDTO.getCdmAttributes());

                newPoi = PoiMapper.INSTANCE
                        .poiDTOToUpdatedPoi(sanitizedPoiDTO);

            } else {

                newPoi = PoiMapper.INSTANCE
                        .poiDTOToUpdatedCmdPoi(sanitizedPoiDTO);
            }

        } else {

            newPoi = PoiMapper.INSTANCE
                    .poiDTOToUpdatedPoi(sanitizedPoiDTO);
        }


        Poi safeNewPoi = toSafePoiForPersistence(newPoi);

        Poi updatedPoi = poiService.updatePoi(existingPoi, safeNewPoi);


        if (updatedPoi == null) {
            return ResponseEntity.internalServerError().build();
        }

        PoiDTO updatedPoiDTO = PoiMapper.INSTANCE
                .poiToPoiDTO(updatedPoi, language);

        if (Boolean.FALSE.equals(
                updatedPoiDTO.getSpaceType().getIsFromCdm())) {

            updatedPoiDTO.getAttributes()
                    .putAll(updatedPoiDTO.getCdmAttributes());

            updatedPoiDTO.setCdmAttributes(null);
        }

        return ResponseEntity.ok(updatedPoiDTO);
    }

    /**
     * Delete a POI
     *
     * @param poiId
     * @return ResponseEntity
     */
    @DeleteMapping(value = "/{poiId}")
    public ResponseEntity<Object> deletePoi(@PathVariable Long poiId) {
        try {
            this.poiService.deleteById(poiId);
        } catch (Exception e) {
            log.error("Poi with id {} not found", poiId);
            log.error(e.getMessage());
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().build();
    }

    // Allow only conservative locker tokens so user-provided POI attributes cannot
    // inject URL control characters into downstream Vecos HTTP endpoints.
    private static final java.util.regex.Pattern SAFE_VECOS_TOKEN = java.util.regex.Pattern
            .compile("^[A-Za-z0-9._\\- ]{1,128}$");

    private boolean hasSafeLockerAttributes(PoiWriteRequest poiDTO) {
        if (Objects.isNull(poiDTO) || Objects.isNull(poiDTO.getAttributes())) {
            return true;
        }

        Map<String, String> attributes = poiDTO.getAttributes();
        return isSafeOptionalLockerAttribute(attributes.get(VecosConstants.LOCKER_TENANT))
                && isSafeOptionalLockerAttribute(attributes.get(VecosConstants.LOCKER_BANK_NAME))
                && isSafeOptionalLockerAttribute(attributes.get(VecosConstants.LOCKER_BANK_ID));
    }

    private boolean isSafeOptionalLockerAttribute(String value) {
        if (Objects.isNull(value) || value.isBlank()) {
            return true;
        }
        return SAFE_VECOS_TOKEN.matcher(value.trim()).matches();
    }

    private Long resolveFloorId(PoiWriteRequest poiDTO) {
        if (Objects.isNull(poiDTO)) {
            return null;
        }

        Long floorId = poiDTO.getFloorId();
        if (Objects.isNull(floorId) && Objects.nonNull(poiDTO.getFloor())) {
            floorId = poiDTO.getFloor().getId();
        }

        if (Objects.isNull(floorId) || floorId <= 0) {
            return null;
        }

        return Long.valueOf(floorId);
    }

    private Long resolveSpaceTypeId(PoiWriteRequest poiDTO) {
        if (Objects.isNull(poiDTO)) {
            return null;
        }

        Long spaceTypeId = poiDTO.getSpaceTypeId();
        if (Objects.isNull(spaceTypeId) && Objects.nonNull(poiDTO.getSpaceType())) {
            spaceTypeId = poiDTO.getSpaceType().getId();
        }

        if (Objects.isNull(spaceTypeId) || spaceTypeId <= 0) {
            return null;
        }

        return Long.valueOf(spaceTypeId);
    }

    private String sanitizeOptionalTextInput(String value, int maxLength) {
        if (Objects.isNull(value)) {
            return null;
        }

        String safeValue = new String(String.valueOf(value).trim());
        if (safeValue.length() > maxLength || !safeValue.matches(SAFE_TEXT_REGEX)) {
            return null;
        }

        return new String(safeValue);
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

    private List<EquipmentDTO> sanitizeEquipments(List<EquipmentDTO> equipments) {
        List<EquipmentDTO> sanitized = new ArrayList<>();
        if (Objects.isNull(equipments)) {
            return sanitized;
        }

        equipments.forEach(equipment -> {
            if (Objects.nonNull(equipment)) {
                EquipmentDTO safeEquipment = new EquipmentDTO();
                safeEquipment.setId(equipment.getId() == null ? null : Long.valueOf(equipment.getId()));
                safeEquipment.setName(sanitizeOptionalTextInput(equipment.getName(), 255));
                safeEquipment.setTitleEn(sanitizeOptionalTextInput(equipment.getTitleEn(), 255));
                safeEquipment.setTitleFr(sanitizeOptionalTextInput(equipment.getTitleFr(), 255));
                sanitized.add(safeEquipment);
            }
        });

        return sanitized;
    }

    private List<Equipment> sanitizePoiEquipments(List<Equipment> equipments) {
        List<Equipment> sanitized = new ArrayList<>();
        if (Objects.isNull(equipments)) {
            return sanitized;
        }

        equipments.forEach(equipment -> {
            if (Objects.nonNull(equipment)) {
                Equipment safeEquipment = new Equipment();
                safeEquipment.setId(equipment.getId() == null ? null : Long.valueOf(equipment.getId()));
                safeEquipment.setName(sanitizeOptionalTextInput(equipment.getName(), 255));
                safeEquipment.setTitleEn(sanitizeOptionalTextInput(equipment.getTitleEn(), 255));
                safeEquipment.setTitleFr(sanitizeOptionalTextInput(equipment.getTitleFr(), 255));
                sanitized.add(safeEquipment);
            }
        });

        return sanitized;
    }

    private Poi toSafePoiForPersistence(Poi poi) {
        if (Objects.isNull(poi)) {
            return null;
        }

        Poi safePoi = new Poi();
        safePoi.setId(null);

        String safeName = sanitizeOptionalTextInput(poi.getName(), 255);
        safePoi.setName(safeName == null ? null : new String(String.valueOf(safeName)));

        Long safeFloorId = poi.getFloorId() == null ? null : Long.valueOf(poi.getFloorId());
        if (Objects.isNull(safeFloorId) && Objects.nonNull(poi.getFloor()) && Objects.nonNull(poi.getFloor().getId())) {
            safeFloorId = Long.valueOf(poi.getFloor().getId());
        }
        safePoi.setFloorId(safeFloorId);
        if (Objects.nonNull(safeFloorId)) {
            Floor safeFloor = new Floor();
            safeFloor.setId(Long.valueOf(safeFloorId));
            safePoi.setFloor(safeFloor);
        }

        safePoi.setTitleEn(sanitizeOptionalTextInput(poi.getTitleEn(), 255));
        safePoi.setTitleFr(sanitizeOptionalTextInput(poi.getTitleFr(), 255));

        Long safeSpaceTypeId = poi.getSpaceTypeId() == null ? null : Long.valueOf(poi.getSpaceTypeId());
        if (Objects.isNull(safeSpaceTypeId) && Objects.nonNull(poi.getSpaceType())
                && Objects.nonNull(poi.getSpaceType().getId())) {
            safeSpaceTypeId = Long.valueOf(poi.getSpaceType().getId());
        }
        safePoi.setSpaceTypeId(safeSpaceTypeId);
        if (Objects.nonNull(poi.getSpaceType()) && Objects.nonNull(poi.getSpaceType().getId())) {
            SpaceType safeSpaceType = new SpaceType();
            safeSpaceType.setId(Long.valueOf(poi.getSpaceType().getId()));
            safeSpaceType.setSpaceTypeName(sanitizeOptionalTextInput(poi.getSpaceType().getSpaceTypeName(), 255));
            safeSpaceType.setIsFromCdm(poi.getSpaceType().getIsFromCdm());
            safePoi.setSpaceType(safeSpaceType);
        }

        safePoi.setCdmKeyId(poi.getCdmKeyId() == null ? null : Long.valueOf(poi.getCdmKeyId()));
        safePoi.setAttributes(this.sanitizeAttributes(poi.getAttributes()));
        safePoi.setEquipments(this.sanitizePoiEquipments(poi.getEquipments()));

        return safePoi;
    }

    private void addSensorDataToPoi(List<PoiDTO> poisDTO, List<Device> devices) {

        // Get the SensorDataDTO for all the Poi (by their name)
        Map<String, SensorDataDTO> mapSensorData = this.sensorDataService.getPoiSensorData(poisDTO, devices);

        // Put the SensorDataDTO on the corresponding PoiDTO
        poisDTO
                .stream()
                .forEach(poiDTO -> {
                    String poiName = poiDTO.getName();

                    if (mapSensorData.containsKey(poiName)) {
                        poiDTO.setSensorData(mapSensorData.get(poiName));
                    }
                });
    }

    /**
     * Get average of a DEVICE attribute
     * ex: state, tempC, apparentTemp...
     * 
     * @param attributeName
     * @param buildingId
     * @param floorIds
     * @param poiTypes
     */
    @GetMapping(value = "/average")
    public ResponseEntity<Map<String, Float>> averageByAttribute(
            @RequestParam String attributeName,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) List<Long> floorIds,
            @RequestParam List<String> category

    ) {
        if (CollectionUtil.isEmpty(floorIds)) {
            if (Objects.isNull(buildingId) || buildingId <= 0) {
                return ResponseEntity.badRequest().build();
            }
            if (!this.buildingService.buidingExists(buildingId)) {
                return ResponseEntity.notFound().build();
            }
            List<Long> buildingIds = this.treeService.filterId(LevelEnum.BUILDING, List.of(buildingId));
            if (buildingIds.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }
            Long authorizedBuildingId = buildingIds.get(0);
            Map<String, Float> result = this.deviceService.calculAverageByBuildingId(authorizedBuildingId,
                    attributeName,
                    category);
            if (Objects.isNull(result)) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(result);
        } else {
            Boolean allFloorsExist = floorIds
                    .stream()
                    .allMatch(floorId -> {
                        Floor floor = this.floorService.getFloor(floorId);
                        return Objects.isNull(floor) ? false : true;
                    });

            floorIds = this.treeService.filterId(SubLevelEnum.FLOOR, floorIds);

            if (allFloorsExist) {
                Map<String, Float> result = this.deviceService.calculAverageByFloorIds(floorIds, attributeName,
                        category);
                if (Objects.isNull(result)) {
                    return ResponseEntity.notFound().build();
                }
                return ResponseEntity.ok(result);
            }
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping(value = "/export/all", produces = "text/csv")
    public ResponseEntity<String> exportAll(@RequestParam(required = false) List<String> category) {
        // No Location limitation because only SuperAdmin should access it

        // Fetch POI data
        List<List<String>> data = this.poiService.getExportDataByTypeIdCDM(category);
        log.info("Number of POI data: {}", data.size());
        return this.exportPoiDTO(data, "poi_country");
    }

    @GetMapping(value = "/export/{level}/{id}", produces = "text/csv")
    public ResponseEntity<String> exportByLevel(
            @PathVariable("level") String level,
            @PathVariable("id") Long id,
            @RequestParam(required = false) List<Long> typeIds,
            @RequestParam(required = false) List<String> category,
            @RequestParam(defaultValue = "false") boolean getBookable) { // Applied to all levels
        if (Objects.isNull(id) || id <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Object entity;
        List<List<String>> data;
        String fileName = "poi_" + level;

        // Fetch entity and data based on level
        switch (level.toLowerCase()) {
            case "country":
                entity = countryService.getCountry(id);
                if (entity != null)
                    entity = treeService.filterTree((Country) entity);
                data = poiService.getExportDataByTypeIdAndCountryIdCDM(id, category);
                break;
            case "city":
                List<Long> cityIds = treeService.filterId(LevelEnum.CITY, List.of(id));
                if (cityIds.isEmpty()) {
                    return ResponseEntity.notFound().build();
                }
                Long cityId = cityIds.get(0);
                entity = cityService.getCity(cityId);
                if (entity != null)
                    entity = treeService.filterTree((City) entity);
                data = poiService.getExportDataByTypeIdAndCityIdCDM(cityId, category);
                break;

            case "site":
                List<Long> siteIds = treeService.filterId(LevelEnum.SITE, List.of(id));
                if (siteIds.isEmpty()) {
                    return ResponseEntity.notFound().build();
                }
                Long siteId = siteIds.get(0);
                if (!siteService.siteExists(siteId)) {
                    return ResponseEntity.notFound().build();
                }
                entity = siteId;
                data = poiService.getExportDataByTypeIdAndSiteIdCDM(siteId, category);
                break;
            case "building":
                List<Long> buildingIds = treeService.filterId(LevelEnum.BUILDING, List.of(id));
                if (buildingIds.isEmpty()) {
                    return ResponseEntity.notFound().build();
                }
                Long buildingId = buildingIds.get(0);
                if (!buildingService.buidingExists(buildingId)) {
                    return ResponseEntity.notFound().build();
                }
                entity = buildingId;
                data = poiService.getExportDataByBuildingIdCDM(buildingId);
                break;
            case "floor":
                List<Long> ids = treeService.filterId(SubLevelEnum.FLOOR, List.of(id));
                if (ids.isEmpty())
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
                entity = floorService.getFloor(id);
                data = poiService.getExportDataByFloorIdCDM(id);
                break;
            default:
                return ResponseEntity.badRequest().build();
        }

        // Handle not found or unauthorized cases
        if (Objects.isNull(entity))
            return ResponseEntity.notFound().build();

        // Export data
        return (level.equalsIgnoreCase("building") || level.equalsIgnoreCase("floor"))
                ? exportPoiDTOForBuilding(data, fileName)
                : exportPoiDTO(data, fileName);
    }

    private ResponseEntity<String> exportPoiDTO(List<List<String>> data, String filename) {
        List<String> headers;

        headers = Arrays.asList(
                "Country",
                "City",
                "Site",
                "Building",
                "POI Title",
                "POI Name",
                "POI Group",
                "Space Type",
                "Temperature (°C)",
                "Humidity",
                "State",
                "POI Floor index",
                "Lux",
                "Sound",
                "Co2",
                "Asset code",
                "Apparent Temperature (°C)",
                "Temperature in fahrenheit (°F)");

        removeDuplicatedRow(data);

        data
                .stream()
                .forEach(list -> {
                    String tempStr = list.get(8);
                    String humidityStr = list.get(9);

                    if (Objects.isNull(tempStr) || Objects.isNull(humidityStr) || tempStr.isEmpty()
                            || humidityStr.isEmpty()) {
                        // Need to add an empty value
                        list.add(PoiConstants.EXPORT_INDEX_APPARENT_TEMP, "");
                        return;
                    }

                    if (isNumeric(tempStr) && isNumeric(humidityStr)) {
                        Double temp = Double.parseDouble(tempStr);
                        Double humidity = Double.parseDouble(humidityStr);

                        // Calculate apparent temperature and temperature in Fahrenheit
                        Double apparentTemp = SensorUtil.calculApparentTemp(temp, humidity);
                        apparentTemp = Math.round(apparentTemp * 100.0) / 100.0;

                        list.add(PoiConstants.EXPORT_INDEX_APPARENT_TEMP, Double.toString(apparentTemp));

                        Double tempF = (temp * 9 / 5) + 32;
                        list.add(PoiConstants.EXPORT_INDEX_TEMP_F, Double.toString(tempF));
                    } else {
                        // Add empty values if parsing failed
                        list.add(PoiConstants.EXPORT_INDEX_APPARENT_TEMP, "");
                        list.add(PoiConstants.EXPORT_INDEX_TEMP_F, "");
                    }
                });

        data.add(0, headers);
        ExportCsv exportCsv = new ExportCsv();
        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity
                .ok()
                .header("Content-Disposition", "attachment; filename=" + filename + ".csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    private boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private ResponseEntity<String> exportPoiDTOForBuilding(List<List<String>> data, String filename) {
        List<String> headers = Arrays.asList(
                "Building Name",
                "Floor",
                "POI Name",
                "POI Title",
                "POI Group",
                "Space Type",
                "X co-ordinate",
                "Y co-ordinate",
                "conf_room_mail",
                "Capacity",
                "Hide Poi",
                "DeviceId",
                "Last Data Received (UTC)",
                "Device Status",
                "Device Type",
                "swVersion",
                "vddPct");

        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();
        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity
                .ok()
                .header("Content-Disposition", "attachment; filename=" + filename + ".csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    /**
     * Function to remove the duplicate rows, based on the Poi Name.
     *
     * Do an average on the temperature and humidity values
     */
    private void removeDuplicatedRow(List<List<String>> data) {
        List<String> previousRow = null;
        long nbDuplicate = 0;
        String currentState = PoiConstants.DEFAULT_STATE;

        AverageValues averageValues = new AverageValues();

        // Use of an iterator
        Iterator<List<String>> iterator = data.iterator();
        while (iterator.hasNext()) {
            List<String> row = iterator.next();

            if (Objects.isNull(previousRow)) {
                // First line
                previousRow = row;
            } else {
                if (Objects.equals(previousRow.get(PoiConstants.EXPORT_INDEX_POI_NAME),
                        row.get(PoiConstants.EXPORT_INDEX_POI_NAME))) {
                    // Duplicate row, we need to manage Temperature, Humidity and State
                    if (nbDuplicate == 0) {
                        averageValues = new AverageValues();

                        // We get the values of the previous row and the current one.
                        currentState = this.mergeState(previousRow.get(PoiConstants.EXPORT_INDEX_STATE),
                                row.get(PoiConstants.EXPORT_INDEX_STATE));
                        averageValues.addValue(
                                PoiConstants.AVERAGE_KEY_TEMP,
                                previousRow.get(PoiConstants.EXPORT_INDEX_TEMPERATURE),
                                row.get(PoiConstants.EXPORT_INDEX_TEMPERATURE));
                        averageValues.addValue(
                                PoiConstants.AVERAGE_KEY_HUMIDITY,
                                previousRow.get(PoiConstants.EXPORT_INDEX_HUMIDITY),
                                row.get(PoiConstants.EXPORT_INDEX_HUMIDITY));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_LUX,
                                previousRow.get(PoiConstants.EXPORT_INDEX_LUX),
                                row.get(PoiConstants.EXPORT_INDEX_LUX));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_SOUND,
                                previousRow.get(PoiConstants.EXPORT_INDEX_SOUND),
                                row.get(PoiConstants.EXPORT_INDEX_SOUND));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_CO2,
                                previousRow.get(PoiConstants.EXPORT_INDEX_CO2),
                                row.get(PoiConstants.EXPORT_INDEX_CO2));
                    } else {
                        // We get the values of the current row and the current "sum"
                        currentState = this.mergeState(currentState, row.get(PoiConstants.EXPORT_INDEX_STATE));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_TEMP,
                                row.get(PoiConstants.EXPORT_INDEX_TEMPERATURE));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_HUMIDITY,
                                row.get(PoiConstants.EXPORT_INDEX_HUMIDITY));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_LUX, row.get(PoiConstants.EXPORT_INDEX_LUX));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_SOUND,
                                row.get(PoiConstants.EXPORT_INDEX_SOUND));
                        averageValues.addValue(PoiConstants.AVERAGE_KEY_CO2, row.get(PoiConstants.EXPORT_INDEX_CO2));
                    }

                    // We remove the current duplicated line
                    iterator.remove();
                    nbDuplicate++;
                } else {
                    if (nbDuplicate > 0) {
                        // We were on duplicated rows, but not anymore : set the good values

                        previousRow.set(PoiConstants.EXPORT_INDEX_STATE, String.valueOf(currentState));

                        if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_TEMP))) {
                            previousRow.set(PoiConstants.EXPORT_INDEX_TEMPERATURE,
                                    String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_TEMP)));
                        }
                        if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_HUMIDITY))) {
                            previousRow.set(PoiConstants.EXPORT_INDEX_HUMIDITY,
                                    String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_HUMIDITY)));
                        }
                        if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_LUX))) {
                            previousRow.set(PoiConstants.EXPORT_INDEX_LUX,
                                    String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_LUX)));
                        }
                        if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_SOUND))) {
                            previousRow.set(PoiConstants.EXPORT_INDEX_SOUND,
                                    String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_SOUND)));
                        }
                        if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_CO2))) {
                            previousRow.set(PoiConstants.EXPORT_INDEX_CO2,
                                    String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_CO2)));
                        }

                        nbDuplicate = 0;
                        currentState = PoiConstants.DEFAULT_STATE;
                    }

                    previousRow = row;
                }
            }
        }

        if (nbDuplicate > 0 && Objects.nonNull(previousRow)) {
            previousRow.set(PoiConstants.EXPORT_INDEX_STATE, String.valueOf(currentState));
            if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_TEMP))) {
                previousRow.set(PoiConstants.EXPORT_INDEX_TEMPERATURE,
                        String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_TEMP)));
            }
            if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_HUMIDITY))) {
                previousRow.set(PoiConstants.EXPORT_INDEX_HUMIDITY,
                        String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_HUMIDITY)));
            }
            if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_LUX))) {
                previousRow.set(PoiConstants.EXPORT_INDEX_LUX,
                        String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_LUX)));
            }
            if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_SOUND))) {
                previousRow.set(PoiConstants.EXPORT_INDEX_SOUND,
                        String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_SOUND)));
            }
            if (Objects.nonNull(averageValues.getAverage(PoiConstants.AVERAGE_KEY_CO2))) {
                previousRow.set(PoiConstants.EXPORT_INDEX_CO2,
                        String.valueOf(averageValues.getAverage(PoiConstants.AVERAGE_KEY_CO2)));
            }
        }
    }

    /**
     * Function to "merge" state
     * 
     * @param state1
     * @param state2
     * @return
     */
    private String mergeState(String state1, String state2) {
        if (Objects.isNull(state1)) {
            return state2;
        }

        if (Objects.isNull(state2)) {
            return state1;
        }

        if (PoiConstants.BUSY_STATE.equals(state1) || PoiConstants.BUSY_STATE.equals(state2)) {
            return PoiConstants.BUSY_STATE;
        }

        if (PoiConstants.FREE_STATE.equals(state1) || PoiConstants.FREE_STATE.equals(state2)) {
            return PoiConstants.FREE_STATE;
        }

        return PoiConstants.DEFAULT_STATE;
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

    /**
     * Init the POI name on an already saved POI (we need the POI Id to init the
     * name)
     * 
     * @param poi The Poi to init the name
     */
    private void initPoiName(Poi poi) {
        if (poi == null) {
            log.error("Cannot initialize POI name - POI object is null");
            return;
        }

        if (poi.getId() == null) {
            log.error("Cannot initialize POI name - POI ID is null");
            return;
        }

        String safePoiId = sanitizeForLog(String.valueOf(poi.getId()));

        if (poi.getFloor() == null) {
            log.error("Cannot initialize POI name - Floor is null for POI with ID: {}", safePoiId);
            return;
        }

        Floor floor = this.floorService.getFloor(poi.getFloor().getId());
        if (floor == null) {
            log.error("Floor not found for POI with ID: {}", safePoiId);
            return;
        }

        Building building = this.buildingService.getBuilding(floor.getBuildingId());
        if (building == null) {
            String safeFloorId = sanitizeForLog(String.valueOf(floor.getId()));
            log.error("Building not found for floor with ID: {}", safeFloorId);
            return;
        }

        SpaceType cdmSpaceType = poi.getSpaceType(); // cdm
        if (cdmSpaceType == null) {
            log.error("SpaceType not found for POI with ID: {}", safePoiId);
            return;
        }

        // Extract the asset ID from the building's attributes
        String assetId = building.getAttributes().get(EnumCdmAttributes.ASSET_CODE.toString());
        if (assetId == null) {
            String safeBuildingId = sanitizeForLog(String.valueOf(building.getId()));
            log.error("Asset ID not found for building with ID: {}", safeBuildingId);
            return;
        }

        // Format the name using assetId, POI type ID, CdmSpaceType ID, and POI ID
        String name = String.format("%s_SO_%03d_%03d", assetId, cdmSpaceType.getId(),
                poiService.findByNextPoiSequence());
        String safeLogName = sanitizeForLog(name);
        log.info("Generated name for POI (ID: {}): {}", safePoiId, safeLogName);

        // Set the generated name to the POI object
        poi.setName(name);
    }

    @PostMapping("/import")
    public ResponseEntity<ResponsePoiBulkImportDTO> importPois(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestParam("file") MultipartFile file) {
        ResponsePoiBulkImportDTO responsePoiBulkImportDTO = new ResponsePoiBulkImportDTO();
        // Check the format of the CSV file and store any structural errors in the
        // response
        responsePoiBulkImportDTO.setErrorsInFile(this.poiService.checkCSVFormat(file));

        // Check if there are errors while reading the CSV file and return a response in
        // case of error
        if (!CollectionUtils.isEmpty(responsePoiBulkImportDTO.getErrorsInFile())) {
            return ResponseEntity.unprocessableEntity().body(responsePoiBulkImportDTO);
        }

        responsePoiBulkImportDTO = this.poiService.generateResponsePoiImportDTO(file);
        if (!CollectionUtils.isEmpty(responsePoiBulkImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responsePoiBulkImportDTO);
        }

        Map<String, Poi> poiByName = new HashMap<>();
        // Iterate through each PoiBulkImportDTO in the response
        for (PoiBulkImportDTO poiBulkImportDTO : responsePoiBulkImportDTO.getPoiBulkImportDTOs()) {
            // Find the Poi based on the POI name in the file
            Poi poi = null;
            String poiName = poiBulkImportDTO.getPoiName();
            if (poiByName.containsKey(poiName)) {
                poi = poiByName.get(poiName);
            } else {
                poi = this.poiService.findByName(poiBulkImportDTO.getPoiName());
                poiByName.put(poiName, poi);
            }

            if (Objects.isNull(poi)) {
                String message = String.format("No poi with this name (poiName: %S)", poiBulkImportDTO.getPoiName());
                responsePoiBulkImportDTO.addError(message);
            }
        }
        if (!CollectionUtils.isEmpty(responsePoiBulkImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responsePoiBulkImportDTO);
        }

        // Process the import
        for (PoiBulkImportDTO poiBulkImportDTO : responsePoiBulkImportDTO.getPoiBulkImportDTOs()) {
            String poiName = poiBulkImportDTO.getPoiName();
            Poi poi = poiByName.get(poiName);

            // Create or update the poi based on the imported data and the associated Poi
            this.poiService.updatePoiAttributes(poiBulkImportDTO, poi);
        }
        return ResponseEntity.ok(responsePoiBulkImportDTO);
    }

    @PutMapping(value = "/updateRoomAttribute")
    public ResponseEntity<Object> updateRoomAttribute(@RequestParam String value, @RequestParam String key) {
        try {
            if (value.equals("true") || value.equals("false")) {
                this.poiService.updateShowAttribute(value, key);
            } else {
                return ResponseEntity.badRequest().build();
            }
        } catch (RuntimeException e) {
            log.error("Failed to update room attribute for key {}", sanitizeForLog(key), e);
            return ResponseEntity.internalServerError().build();
        }

        return ResponseEntity.ok().build();
    }
}