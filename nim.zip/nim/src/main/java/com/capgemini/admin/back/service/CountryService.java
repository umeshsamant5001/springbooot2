package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;



import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.Country;

import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.CountryRepository;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class CountryService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    public static class CountryUpsertInput {
        private final Long cdmKeyId;
        private final String countryIsoAlpha2;
        private final String titleFr;
        private final String titleEn;
        private final Map<String, String> attributes;

        public CountryUpsertInput(Long cdmKeyId, String countryIsoAlpha2, String titleFr, String titleEn,
                Map<String, String> attributes) {
            this.cdmKeyId = cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
            this.countryIsoAlpha2 = countryIsoAlpha2 == null ? null : new String(String.valueOf(countryIsoAlpha2));
            this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
            this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));

            Map<String, String> copiedAttributes = new HashMap<>();
            if (attributes != null) {
                attributes.forEach((key, value) -> {
                    if (key != null && value != null) {
                        copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
                    }
                });
            }
            this.attributes = copiedAttributes;
        }

        public Long getCdmKeyId() {
            return cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
        }

        public String getCountryIsoAlpha2() {
            return countryIsoAlpha2 == null ? null : new String(String.valueOf(countryIsoAlpha2));
        }

        public String getTitleFr() {
            return titleFr == null ? null : new String(String.valueOf(titleFr));
        }

        public String getTitleEn() {
            return titleEn == null ? null : new String(String.valueOf(titleEn));
        }

        public Map<String, String> getAttributes() {
            Map<String, String> copiedAttributes = new HashMap<>();
            attributes.forEach((key, value) -> {
                if (key != null && value != null) {
                    copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
                }
            });
            return copiedAttributes;
        }
    }


    @Autowired
    private EntityManager entityManager;

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private BuildingRepository buildingRepository;

    /**
     * Retrieves a Country by its ID, including its associated cities.
     *
     * @param countryId the ID of the country to retrieve
     * @return the Country object if found, otherwise null
     */
    @Transactional
    public Country getCountry(Long countryId) {
        try {
            Country country = this.countryRepository.findById(countryId).orElse(null);
            if (Objects.nonNull(country)) {
                country.getCities();
            }
            return country;
        } catch (IllegalArgumentException | PersistenceException ex) {
            log.error("Failed to retrieve country for id {}", countryId, ex);
            return null;
        }
    }


    /**
     * Retrieves a Country entity using a JPA EntityGraph for optimized fetching of related entities.
     *
     * @param id the ID of the country to retrieve
     * @return the Country object with related entities loaded
     */
    public Country findByEntityGraph(Long id) {
        try {
            EntityGraph<?> entityGraph = entityManager.getEntityGraph("country-entity-graph");
            Map<String, Object> properties = new HashMap<>();
            properties.put("javax.persistence.fetchgraph", entityGraph);
            return this.entityManager.find(Country.class, id, properties);
        } catch (IllegalArgumentException | PersistenceException ex) {
            log.error("Failed to retrieve country by entity graph for id {}", id, ex);
            return null;
        }
    }


    /**
     * Updates an existing Country entity with new values from scoped update fields.
     *
     * @param countryId the ID of the country to update
     * @param cdmKeyId the new cdmKeyId value
     * @param titleFr the new French title value
     * @param titleEn the new English title value
     * @param attributes the new attributes map
     * @return the updated Country object, or null if not found or an exception occurs
     */
    @Transactional
    public Country updateCountry(Long countryId, Long cdmKeyId, String titleFr, String titleEn,
            Map<String, String> attributes) {


        if (Objects.isNull(countryId)) {
            return null;
        }

        Country oldCountry = findByEntityGraph(Long.valueOf(String.valueOf(countryId)));

        if (Objects.isNull(oldCountry))
            return null;

        CountryUpsertInput scopedCountryInput = sanitizeCountryUpsertInput(new CountryUpsertInput(
                cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId)),
                null,
                titleFr == null ? null : new String(String.valueOf(titleFr)),
                titleEn == null ? null : new String(String.valueOf(titleEn)),
                attributes == null ? new HashMap<>() : new HashMap<>(attributes)));

        Long validatedCdmKeyId = sanitizeOptionalNonNegativeLong(scopedCountryInput.getCdmKeyId());
        String validatedTitleEn = sanitizeOptionalText(scopedCountryInput.getTitleEn(), 255);
        String validatedTitleFr = sanitizeOptionalText(scopedCountryInput.getTitleFr(), 255);
        Map<String, String> validatedAttributes = sanitizeAttributes(scopedCountryInput.getAttributes());


        Long safeModifiedAt = (new Date()).getTime() / 1000;
        Country newCountry = null;
        try {
            int updatedRows = this.countryRepository.updateCountryCoreFields(
                    oldCountry.getId() == null ? null : Long.valueOf(String.valueOf(oldCountry.getId())),
                    validatedCdmKeyId == null ? null : Long.valueOf(String.valueOf(validatedCdmKeyId)),
                    validatedTitleFr == null ? null : new String(validatedTitleFr),
                    validatedTitleEn == null ? null : new String(validatedTitleEn),
                    Long.valueOf(String.valueOf(safeModifiedAt)));
            if (updatedRows <= 0) {
                return null;
            }

            this.countryRepository.deleteAttributesByCountryId(oldCountry.getId());
            for (Entry<String, String> validatedAttribute : validatedAttributes.entrySet()) {
                if (validatedAttribute == null) {
                    continue;
                }
                String safeAttributeKey = validatedAttribute.getKey() == null
                        ? null
                        : new String(String.valueOf(validatedAttribute.getKey()));
                String safeAttributeValue = validatedAttribute.getValue() == null
                        ? null
                        : new String(String.valueOf(validatedAttribute.getValue()));
                if (safeAttributeKey != null && safeAttributeValue != null) {
                    this.countryRepository.insertCountryAttribute(
                            oldCountry.getId() == null ? null : Long.valueOf(String.valueOf(oldCountry.getId())),
                            safeAttributeKey,
                            safeAttributeValue);
                }
            }

            newCountry = findByEntityGraph(oldCountry.getId() == null ? null : Long.valueOf(String.valueOf(oldCountry.getId())));
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return newCountry;

    }





    /**
     * Updates an existing Country entity with new values from a CountryDTO.
     *
     * @param countryId the ID of the country to update
     * @param updatedCountry the DTO containing updated country data
     * @return the updated Country object, or null if not found or an exception occurs
     */
    public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
        try {
            return this.countryRepository.getNameByCmdKeyId(cdmKeyIdList)
                    .stream()
                    .collect(Collectors.toMap(tuple -> tuple.get(0, Long.class), tuple -> tuple.get(1, String.class)));
        } catch (IllegalArgumentException | PersistenceException ex) {
            log.error("Failed to retrieve country names by cdmKeyId list", ex);
            return new HashMap<>();
        }
    }


    /**
     * Retrieves a map of attribute key-value pairs for a given country ID.
     *
     * @param countryId the ID of the country
     * @return a map of attribute keys and values
     */
    public Map<String, String> getAttributesById(Long countryId) {
        try {
            return this.countryRepository.getAttributesById(countryId)
                    .stream()
                    .collect(Collectors.toMap(tuple -> tuple.get(0, String.class), tuple -> tuple.get(1, String.class)));
        } catch (IllegalArgumentException | PersistenceException ex) {
            log.error("Failed to retrieve country attributes for countryId {}", countryId, ex);
            return new HashMap<>();
        }
    }


    /**
     * Retrieves all Country entities from the database.
     *
     * @return a list of all Country objects
     */
    public List<Country> getAll() {
        return this.countryRepository.findAll();
    }

    /**
     * Saves and flushes a Country entity to the database.
     *
     * @param countryInput the Country input object to save
     * @return the saved Country object
     */
    public Country save(CountryUpsertInput countryInput) {
        if (Objects.isNull(countryInput)) {
            return null;
        }

        CountryUpsertInput scopedCountryInput = sanitizeCountryUpsertInput(countryInput);

        Long validatedCdmKeyId = sanitizeOptionalNonNegativeLong(scopedCountryInput.getCdmKeyId());
        String validatedCountryIsoAlpha2 = sanitizeOptionalText(scopedCountryInput.getCountryIsoAlpha2(), 255);
        String validatedTitleEn = sanitizeOptionalText(scopedCountryInput.getTitleEn(), 255);
        String validatedTitleFr = sanitizeOptionalText(scopedCountryInput.getTitleFr(), 255);
        Map<String, String> validatedAttributes = sanitizeAttributes(scopedCountryInput.getAttributes());


        Country sanitized = new Country();
        sanitized.setId(null);
        sanitized.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(String.valueOf(validatedCdmKeyId)));
        sanitized.setCountryIsoAlpha2(validatedCountryIsoAlpha2 == null ? null : new String(validatedCountryIsoAlpha2));
        sanitized.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
        sanitized.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
        sanitized.setAttributes(new HashMap<>(validatedAttributes));
        sanitized.setModifiedAt((new Date()).getTime() / 1000);

        return this.countryRepository.saveAndFlush(sanitized);
    }

    public Country saveSanitizedCountry(Country country) {
        if (Objects.isNull(country)) {
            return null;
        }

        Country sanitized;
        if (country.getId() == null) {
            sanitized = new Country();
            sanitized.setId(null);
        } else {
            try {
                sanitized = this.countryRepository.findById(Long.valueOf(String.valueOf(country.getId()))).orElse(null);
            } catch (IllegalArgumentException | PersistenceException ex) {
                log.error("Failed to retrieve existing country before save for id {}", country.getId(), ex);
                return null;
            }
            if (Objects.isNull(sanitized)) {
                return null;
            }
        }

        Long validatedCdmKeyId = sanitizeOptionalNonNegativeLong(country.getCdmKeyId());
        String validatedCountryIsoAlpha2 = sanitizeOptionalText(country.getCountryIsoAlpha2(), 255);
        String validatedTitleEn = sanitizeOptionalText(country.getTitleEn(), 255);
        String validatedTitleFr = sanitizeOptionalText(country.getTitleFr(), 255);
        Map<String, String> validatedAttributes = sanitizeAttributes(country.getAttributes());

        sanitized.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(String.valueOf(validatedCdmKeyId)));
        sanitized.setCountryIsoAlpha2(validatedCountryIsoAlpha2 == null ? null : new String(validatedCountryIsoAlpha2));
        sanitized.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
        sanitized.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
        sanitized.setAttributes(new HashMap<>(validatedAttributes));

        Long validatedModifiedAt = country.getModifiedAt() == null
                ? null
                : sanitizeOptionalNonNegativeLong(Long.valueOf(String.valueOf(country.getModifiedAt())));
        sanitized.setModifiedAt(validatedModifiedAt == null
                ? (new Date()).getTime() / 1000
                : Long.valueOf(String.valueOf(validatedModifiedAt)));

        try {
            return this.countryRepository.saveAndFlush(sanitized);
        } catch (IllegalArgumentException | PersistenceException ex) {
            log.error("Failed to save sanitized country for id {}", country.getId(), ex);
            return null;
        }
    }






    /**
     * Deletes a Country entity by its ID.
     *
     * @param countryId the ID of the country to delete
     */
    public void deleteById(Long countryId) {
        this.countryRepository.deleteById(countryId);
    }

    /**
     * Retrieves all buildings associated with a given country ID.
     *
     * @param countryId the ID of the country
     * @return a list of Building objects
     */
    @Transactional
    public List<Building> getBuildings(Long countryId) {
        List<Building> buildings = this.buildingRepository.findAllBuildings(countryId);
        return buildings;
    }

    /**
     * Retrieves all globally scoped buildings for a given country ID.
     *
     * @param countryId the ID of the country
     * @return a list of globally scoped Building objects
     */
    @Transactional
    public List<Building> getBuildingsGlobal(Long countryId) {
        List<Building> buildings = this.buildingRepository.findAllBuildingsGlobal(countryId);
        return buildings;
    }

    /**
     * Retrieves all locally scoped buildings for a given country ID.
     *
     * @param countryId the ID of the country
     * @return a list of locally scoped Building objects
     */
    @Transactional
    public List<Building> getBuildingsLocal(Long countryId) {
        List<Building> buildings = this.buildingRepository.findAllBuildingsLocal(countryId);
        return buildings;
    }

    /**
     * Checks if a Country exists by matching country ID, CDM key ID, and country name.
     *
     * @param countryId the ID of the country
     * @param cdmKeyId the CDM key ID
     * @param countryName the name of the country
     * @return the matching Country object if found, otherwise null
     */
    public Country existsByCountryIdAndCdmKeyIdAndCountryName(Long countryId, Long cdmKeyId, String countryName) {
        Country countries = countryRepository.existsByCountryIdAndCdmKeyIdAndCountryName(countryId, cdmKeyId,
                countryName);
        return countries;
    }

    private CountryUpsertInput sanitizeCountryUpsertInput(CountryUpsertInput source) {
        if (source == null) {
            throw new IllegalArgumentException("Country input must not be null");
        }

        Long safeCdmKeyId = source.getCdmKeyId() == null ? null : Long.valueOf(String.valueOf(source.getCdmKeyId()));
        String safeCountryIsoAlpha2 = source.getCountryIsoAlpha2() == null
                ? null
                : new String(String.valueOf(source.getCountryIsoAlpha2()));
        String safeTitleEn = source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn()));
        String safeTitleFr = source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr()));

        Map<String, String> safeAttributes = new HashMap<>();
        Map<String, String> sourceAttributes = source.getAttributes();
        if (sourceAttributes != null) {
            sourceAttributes.forEach((key, value) -> {
                if (Objects.nonNull(key) && Objects.nonNull(value)) {
                    safeAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
                }
            });
        }

        return new CountryUpsertInput(safeCdmKeyId, safeCountryIsoAlpha2, safeTitleFr, safeTitleEn, safeAttributes);
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }


        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = sanitizeOptionalText(key, 255);
                String safeValue = sanitizeOptionalText(value, 1000);
                if (Objects.nonNull(safeKey) && Objects.nonNull(safeValue)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });
        return sanitized;
    }


    private Long sanitizeOptionalNonNegativeLong(Long value) {
        if (Objects.isNull(value)) {
            return null;
        }

        Long validated = Long.valueOf(String.valueOf(value));
        if (validated < 0) {
            throw new IllegalArgumentException("Invalid numeric input");
        }

        return Long.valueOf(String.valueOf(validated));
    }

    private String sanitizeOptionalText(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(trimmed);
    }
}
