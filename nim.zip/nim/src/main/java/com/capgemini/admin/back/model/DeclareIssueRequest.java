package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * Request DTO for creating a DeclareIssueDetails record. Only the fields declared below are
 * bindable from the client payload. Unknown properties are rejected to prevent unsafe object
 * binding (mass-assignment) on the downstream persistence sink (saveAndFlush).
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class DeclareIssueRequest {
    private Long countryId;
    private String emailId;
    private DeclareIssueDTO declareIssue;
}