package com.capgemini.admin.back.model;

public enum EnumPriorityType {
    LOW, MEDIUM, HIGH
}