package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.MasterAttribute;
import com.capgemini.admin.back.repository.MasterAttributeRepository;

@Service
public class MasterAttributeService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";


    @Autowired
    private MasterAttributeRepository masterAttributeRepository;

    public List<MasterAttribute> findAllMandatory() {
        return this.masterAttributeRepository.findByMandatory(true);
    }

    public MasterAttribute findByName(String name) {
        return this.masterAttributeRepository.findById(name).orElse(null);
    }

    public MasterAttribute save(MasterAttribute masterAttribute) {
        MasterAttribute sanitizedMasterAttribute = this.toSanitizedMasterAttributeForSave(masterAttribute);
        return this.masterAttributeRepository.save(sanitizedMasterAttribute);
    }

    private MasterAttribute toSanitizedMasterAttributeForSave(MasterAttribute masterAttribute) {
        MasterAttribute sanitizedMasterAttribute = new MasterAttribute();
        sanitizedMasterAttribute.setName(this.validateAndSanitizeText(masterAttribute.getName(), 255, "name"));
        sanitizedMasterAttribute.setControlType(masterAttribute.getControlType() == null
                ? null
                : com.capgemini.admin.back.model.EnumControlType
                        .valueOf(String.valueOf(masterAttribute.getControlType().name())));
        sanitizedMasterAttribute.setDataType(masterAttribute.getDataType() == null
                ? null
                : com.capgemini.admin.back.model.EnumDataType
                        .valueOf(String.valueOf(masterAttribute.getDataType().name())));
        sanitizedMasterAttribute.setLength(masterAttribute.getLength() == null
                ? null
                : Integer.valueOf(masterAttribute.getLength()));
        sanitizedMasterAttribute.setMandatory(masterAttribute.getMandatory() == null
                ? null
                : Boolean.valueOf(String.valueOf(masterAttribute.getMandatory())));

        List<String> sanitizedControlValues = new ArrayList<>();
        if (masterAttribute.getControlValue() != null) {
            for (String controlValue : masterAttribute.getControlValue()) {
                sanitizedControlValues.add(this.validateAndSanitizeText(controlValue, 255, "controlValue"));
            }
        }
        try {
            sanitizedMasterAttribute.setControlValue(sanitizedControlValues);
        } catch (com.capgemini.admin.back.model.InvalidParameterException e) {
            throw new IllegalArgumentException("Invalid controlValue.");
        }

        return sanitizedMasterAttribute;
    }

    private String validateAndSanitizeText(String value, int maxLength, String fieldName) {
        if (Objects.isNull(value)) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.length() > maxLength || !Pattern.matches(SAFE_TEXT_REGEX, validated)) {
            throw new IllegalArgumentException("Invalid " + fieldName + ".");
        }

        return new String(validated);

    }


    public void delete(MasterAttribute masterAttribute) {
        this.masterAttributeRepository.delete(masterAttribute);
    }
}
