package com.capgemini.admin.back.repository;

import com.capgemini.admin.back.model.EnumOsType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgemini.admin.back.model.AppRegistrationManagement;
import java.util.List;

public interface DeviceTokenRepository extends JpaRepository<AppRegistrationManagement, Long> {

        List<AppRegistrationManagement> findByDeviceType(EnumOsType deviceType);

        @Query(value = "SELECT DISTINCT ar.device_registration_token " +
                        "FROM app_registration_management ar " +
                        "JOIN users u ON ar.email_id = u.email " +
                        "JOIN [preference] p ON p.user_email = u.email " +
                        "JOIN building b ON p.building_id = b.id " +
                        "JOIN Site s ON b.site_id = s.id " +
                        "JOIN City c ON s.city_id= c.id " +
                        "JOIN Country co ON c.country_id= co.id " +
                        "WHERE ar.device_type = :deviceType AND co.title_en = :countryName", nativeQuery = true)
        List<String> findDeviceTokensByDeviceTypeAndCountry(@Param("deviceType") String deviceType,
                        @Param("countryName") String countryName);

        List<AppRegistrationManagement> findByEmailId(String emailId);

        @Query(value = "SELECT * FROM app_registration_management  WHERE email_id IN (:emails) ", nativeQuery = true)
        List<AppRegistrationManagement> findByEmailsIn(@Param("emails") List<String> emails);

}
