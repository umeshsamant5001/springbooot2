package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class ErrorLoggingDTO {

    private Long id;
    private String className;
    private String module;
    private Integer lineNumber;
    private String description;
    private String state;
    private EnumErrorType errorType;
    private String data;
    private Long loggingDate;
    private EnumErrorLoggingType errorLoggingType;
}
