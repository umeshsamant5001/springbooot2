package com.capgemini.admin.back.service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.checkerframework.checker.units.qual.cd;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.admin.back.mapper.CiscoDeviceMapper;

import com.capgemini.admin.back.model.CiscoDeviceDTO;
import com.capgemini.admin.back.model.CiscoDeviceResponseDTO;
import com.capgemini.admin.back.model.EnumOrderBy;
import com.capgemini.admin.back.repository.CiscoDeviceRepository;
import com.capgemini.admin.utils.ExportCsv;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CiscoDeviceService {


    @Autowired
    private CiscoDeviceRepository ciscoDeviceRepository;

    /**
     * Retrieves a list of Cisco devices associated with a given POI (Point of Interest) name.
     * The method queries the repository, maps the result to DTOs, and returns the list.
     *
     * @param poiName the name of the POI to search devices for
     * @return a list of CiscoDeviceResponseDTO objects representing the matched devices
     */
    public List<CiscoDeviceResponseDTO> findCiscoDevicesByPoiName(String poiName) {
        List<Map<String, Object>> results = ciscoDeviceRepository.findCiscoDevicesByPoiName(poiName);
        List<CiscoDeviceResponseDTO> responseDTOs = results.stream()
                .map(CiscoDeviceMapper.INSTANCE::mapToDTO)
                .collect(Collectors.toList());
        return responseDTOs;
    }

    /**
     * Fetches and maps Cisco devices for a given floor ID.
     *
     * @param floorId the ID of the floor to retrieve devices for
     * @return a list of CiscoDeviceDTO objects mapped from the query results
     */
    public List<CiscoDeviceDTO> getCiscoDevicesByFloorId(Long floorId) {
        try {
            return ciscoDeviceRepository.getCiscoDevicesByFloorId(floorId).stream()
                    .map(CiscoDeviceMapper.INSTANCE::mapToCiscoDeviceDTO)
                    .collect(Collectors.toList());
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve Cisco devices by floorId {}", floorId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve Cisco devices.");
        }
    }


    /**
     * Retrieves a paginated list of Cisco devices for a given building.
     *
     * @param buildingId The ID of the building to filter devices.
     * @param first      The starting index for pagination.
     * @param last       The ending index for pagination.
     * @param column     The column name to sort by.
     * @param orderBy    The order direction (ASC or DESC).
     * @return A map containing paginated device data, current page, total items,
     *         and total pages.
     */
    public Map<String, Object> getPaginatedCiscoDevices(Long buildingId, int first, int last,
            String column, EnumOrderBy orderBy) {

        int size;
        int pageNumber = 0;

        Long totalItems = ciscoDeviceRepository.countCiscoDevices(buildingId);

        if (first == 0 && last == 9999) {
            size = totalItems.intValue();
        } else {
            size = last - first;
            pageNumber = size > 0 ? (last / size) - 1 : 0;
        }

        List<Map<String, Object>> rawData = ciscoDeviceRepository.getPaginatedCiscoDevices(buildingId);

        List<CiscoDeviceResponseDTO> dtos = rawData.stream()
                .map(CiscoDeviceMapper.INSTANCE::mapToDTO)
                .collect(Collectors.toList());

        if (Objects.nonNull(column) && Objects.nonNull(orderBy)) {
            Comparator<CiscoDeviceResponseDTO> comparator;

            switch (column) {
                case "Ip":
                    comparator = Comparator.comparing(
                            d -> d.getCiscoDeviceAttributes().getIpAddress(),
                            Comparator.nullsLast(String::compareTo));
                    break;
                case "PoiName":
                    comparator = Comparator.comparing(
                            CiscoDeviceResponseDTO::getPoiName,
                            Comparator.nullsLast(String::compareTo));
                    break;
                case "PoiTitle":
                    comparator = Comparator.comparing(
                            CiscoDeviceResponseDTO::getPoiTitle,
                            Comparator.nullsLast(String::compareTo));
                    break;
                case "PoiType":
                    comparator = Comparator.comparing(
                            CiscoDeviceResponseDTO::getPoiType,
                            Comparator.nullsLast(String::compareTo));
                    break;
                default:
                    comparator = Comparator.comparing(CiscoDeviceResponseDTO::getDeviceId);
                    break;
            }

            if (orderBy == EnumOrderBy.DESC) {
                comparator = comparator.reversed();
            }

            dtos.sort(comparator);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("ldevices", dtos);
        response.put("currentPage", pageNumber);
        response.put("totalItems", totalItems);
        response.put("totalPages", size > 0 ? (int) Math.ceil((double) totalItems / size) : 1);

        return response;
    }


    /**
     * Exports the ciscoDevice data to a CSV file.
     *
     * @param data The list of ciscoDevice data to be exported.
     */
    public ResponseEntity<String> exportCiscoDevice(List<List<String>> data) {
        List<String> headers = Arrays.asList(
                "Country",
                "City",
                "Site",
                "Building",
                "DeviceId",
                "DeviceType",
                "PoiName",
                "PoiTitle", 
                "Cisco_Devices_Email_Id", 
                "Capacity"
               );

        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();
        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity
                .ok()
                .header("Content-Disposition", "attachment; filename=CiscoDevices.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    public List<List<String>> fetchExportCiscoDevices() {
        try {
            return ciscoDeviceRepository.fetchExportCiscoDevices();
        } catch (DataAccessException ex) {
            log.error("Failed to fetch Cisco devices for export", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export Cisco devices.");
        }
    }

}
