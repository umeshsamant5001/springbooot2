package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.FeatureAccess;
import com.capgemini.admin.back.model.FeatureAccessDTO;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.model.RoleDTO;
import java.util.List;
import java.util.stream.Collectors;

@Named("RoleMapper")
@Mapper(config = DtoMapperConfig.class)
public interface RoleMapper {

    RoleMapper INSTANCE = Mappers.getMapper(RoleMapper.class);

    /**
     * Maps a Role entity to a RoleDTO entity.
     *
     * @param in The input Role entity.
     * @return The mapped RoleDTO entity.
     */
    @Named("roleToRoleDTO")
    @Mappings({
            @Mapping(source = "featureAccesses", target = "featureAccesses", qualifiedByName = {
                    "featureAccessToFeatureAccessDTO" })
    })
    RoleDTO roleToRoleDTO(Role in, @Context String language);

    /**
     * Maps a RoleDTO entity to a Role entity.
     *
     * @param in The input RoleDTO entity.
     * @return The mapped Role entity.
     */
    @Named("roleDTOToRole")
    Role roleDTOToRole(RoleDTO in);

    @Named("featureAccessToFeatureAccessDTO")
    default List<FeatureAccessDTO> _featureAccessToFeatureAccessDTO(List<FeatureAccess> featureAccesses,
            @Context String language) {
        return featureAccesses
                .stream()
                .map(f -> Mappers.getMapper(FeatureAccessMapper.class).featureAccessToFeatureAccessDTO(f, language))
                .collect(Collectors.toList());
    }

}
