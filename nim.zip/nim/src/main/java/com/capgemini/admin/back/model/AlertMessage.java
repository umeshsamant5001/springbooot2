package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import lombok.Data;

@Data
@Entity
@Table(name = "alert_message")
public class AlertMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AlertMessage_Generator")
    @SequenceGenerator(name = "AlertMessage_Generator", sequenceName = "AlertMessage_Sequence")
    private Long id;
    @Column(name = "modified_at", nullable = false)
    private Long modifiedAt = (new Date()).getTime() / 1000;
    @Column(name = "space_type_id", nullable = false)
    private Long spaceTypeId;
    @Column(name = "space_type_name", nullable = false)
    private String spaceTypeName;
    @Enumerated(EnumType.STRING)
    @Column(name = "threshold_type")
    private ThresholdType thresholdType;
    @Enumerated(EnumType.STRING)
    @Column(name = "alert_type")
    private AlertType alertCategory;
    @Column(name = "title", nullable = false)
    private String title;
    @Column(name = "message", nullable = false, columnDefinition = "TEXT")
    private String message;
    @OneToMany(mappedBy = "alertMessage", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    private List<AlertMessageLocation> alertMessageLocations = new ArrayList<>();
    @Column(name = "alert_sent_at")
    private Long alertSentAt = (new Date()).getTime() / 1000;

}
