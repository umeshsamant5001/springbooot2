package com.capgemini.admin.utils;

import org.hibernate.Hibernate;
import org.mapstruct.Condition;

/**
 * The class is use to make Mapstruct to not try to map Lazy properties.
 */
public class LazyFieldCondition {

    private LazyFieldCondition() {
    }

    @Condition
    public static boolean isNotLazy(Object value) {
        return value != null && Hibernate.isInitialized(value);
    }

}
