package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class FacilityManagerDTO {
    private String uuid;
    private String name;
    private String titleEnFloor;
    private String titleEnBuilding;
    private String level;
    private String email;
}
