package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class PushNotificationRequest {

    private Message message;

    @Data
    public static class Message {
        private Android android;
        private Apns apns;

        @Data
        public static class Android {
            private Notification notification;

            @Data
            public static class Notification {
                private String title;
                private String body;
            }
        }

        @Data
        public static class Apns {
            private Payload payload;

            @Data
            public static class Payload {
                private Aps aps;

                @Data
                public static class Aps {
                    private ApsAlert alert;

                    @Data
                    public static class ApsAlert {
                        private String body;
                        private String title;
                    }
                }
            }
        }
    }

}
