package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.Floor;

@Repository
public interface FloorRepository extends JpaRepository<Floor, Long> {

    // Count Floors by building ID
    long countByBuildingId(@Param("buildingId") Long buildingId);

    // Find floors bu building ID
    List<Floor> findAllByBuildingIdOrderByIndex(@Param("buildingId") Long buildingId);

    /**
     * To optimize query, we force the use of a JOIN for the Building and
     * OpeningHours
     */
    @Query("SELECT floor FROM Floor floor INNER JOIN FETCH floor.building building INNER JOIN FETCH building.information.openingHours")
    List<Floor> findAll();

    @Query(value = "SELECT b.timezone_java FROM floor f " + "JOIN building b ON f.building_id = b.id "
            + "WHERE f.id = :floorId", nativeQuery = true)
    Optional<String> findBuildingTimezoneByFloorId(@Param("floorId") Long floorId);

    @Query("SELECT INDEX(attributes), attributes FROM Floor floor INNER JOIN floor.attributes attributes WHERE floor.id = :floorId")
    List<Tuple> getAttributesById(@Param("floorId") Long floorId);

    @Query("SELECT f FROM Floor f WHERE f.cdmKeyId = :cdmKeyId")
    Floor findByCdmKeyId(@Param("cdmKeyId") Long floorCdmKeyId);
}
