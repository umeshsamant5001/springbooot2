package com.capgemini.admin.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * Properties specific to Admin Portal Back End.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = true)
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class

    private final Cdm cdm = new Cdm();
    private final CORS cors = new CORS();
    private final Jwks jwks = new Jwks();
    private final Ping ping = new Ping();
    private final SMTP smtp = new SMTP();
    private final Notification notification = new Notification();
    private final PushNotificationApns pushNotificationApns = new PushNotificationApns();
    private final Email email = new Email();
    private final Azure azure = new Azure();
    private final Cache cache = new Cache();
    private final Vecos vecos = new Vecos();
    private final LDAP ldap = new LDAP();

    @Data
    public static class Azure {
        private String tenantId;
        private final GraphApi graphApi = new GraphApi();
        private final GraphApiSendEmail graphApiSendEmail = new GraphApiSendEmail();
        private final KeyVault keyVault = new KeyVault();

        @Data
        public static class GraphApi {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;       
        }

        @Data
        public static class KeyVault {
            private String url;
            private String clientId;
            private String clientSecret;
            private String certificateName;
        }

        @Data
        public static class GraphApiSendEmail {
            private String url;
            private String clientId;
            private String clientSecret;
            private String scopeUrl;
        }
    }

    @Data
    public static class Jwks {
        private String url;
    }

    @Data
    public static class Ping {
        private String validateUrl;
        private String clientId;
        private String clientSecret;
        // Need to get it from Office pass team
        private String validateUrlOfficePass;
        private String clientIdForOfficePass;
        private String clientSecretForOfficePass;

    }

    @Data
    public static class Cdm {

        private String url;
        private String clientId;
        private String clientSecret;
        private String ssoUrl;
        private String cgAuth;
        private String authorization;
        private String cookie;

        private final Tasks tasks = new Tasks();

        @Data
        public static class Tasks {
            private String cron;
            private String tz;
        }

    }

    @Data
    public static class CORS {
        private String origins;
    }

    @Data
    public static class SMTP {
        private String auth;
        private String host;
        private String port;
        private String state;
        private String hostUrl;
        private String portNum;
        private String username;
        private String password;
        private String email;
    }

    @Data
    public static class Notification {
        private final Push push = new Push();

        @Data
        public static class Push {
            private String cron;
            private String tz;
        }

        // Possibility to add "email" and "sms"
    }

    @Data
    public static class Email {
        private final CreateUser createUser = new CreateUser();
        private final UpdateUser updateUser = new UpdateUser();
        private final DeleteUser deleteUser = new DeleteUser();
        private final DeleteSpecialUser deleteSpecialUser = new DeleteSpecialUser();

        private final UpdateUserLocations updateUserLocations = new UpdateUserLocations();
        private final UpdateUserNew updateUserNew = new UpdateUserNew();
        private final CreateUserNew createUserNew = new CreateUserNew();
        private final UpdateUserLocationsNew updateUserLocationsNew = new UpdateUserLocationsNew();
        private final SpecialUserImport specialUserImport = new SpecialUserImport();

        @Data
        public static class CreateUser {
            private String subject;
            private String body;
        }

        @Data
        public static class UpdateUser {
            private String subject;
            private String body;
        }

        @Data
        public static class DeleteUser {
            private String subject;
            private String body;
        }

        @Data
        public static class DeleteSpecialUser {
            private String subjectspecialuser;
            private String bodyspecialuser;
        }
        
        @Data
        public static class UpdateUserLocations {
            private String subject;
            private String body;
        }

        @Data
        public static class UpdateUserLocationsNew {
            private String subject;
            private String body;
            private String footer;
        }

        @Data
        public static class SpecialUserImport {
            private String subject;
            private String bodysecured;
            private String bodybeta;
        }

    }

    @Data
    public static class PushNotificationApns {
        private String teamId;
        private String keyId;
        private String base64PrivateKey;
        private String apnsHost;
        private String apnsTopic;
    }

    @Data
    public static class Cache {
        private final Clear clear = new Clear();

        @Data
        public static class Clear {
            private String url;
            private String username;
            private String password;
            private String subscriptionKey;
        }

    }

    @Data
    public static class Vecos {
        private String scope;

        private final Identity identity = new Identity();
        private final SApi sapi = new SApi();
        private final Batch batch = new Batch();

        @Data
        public static class Batch {
            private String cron;
            private String tz;
        }

        @Data
        public static class Identity {
            private String url;
        }

        @Data
        public static class SApi {
            private String url;
        }
    }

    @Data
    public static class UpdateUserNew {
        private String subject;
        private String body;
        private String footer;
    }

    @Data
    public static class CreateUserNew {
        private String subject;
        private String body;
        private String footer;
    }

    @Data
    public static class LDAP {
        private String serviceUserName;
        private String servicePassword;
        private String serverURL;
    }

}
