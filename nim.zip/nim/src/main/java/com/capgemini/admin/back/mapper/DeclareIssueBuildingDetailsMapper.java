package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.DeclareIssueBuildingDetails;
import com.capgemini.admin.back.model.DeclareIssueBuildingDetailsDTO;

@Mapper(config = DtoMapperConfig.class)
public interface DeclareIssueBuildingDetailsMapper {
    DeclareIssueBuildingDetailsMapper INSTANCE = Mappers.getMapper(DeclareIssueBuildingDetailsMapper.class);

    DeclareIssueBuildingDetails declareIssueBuildingDetailsDTOToDeclareIssueBuildingDetails(DeclareIssueBuildingDetailsDTO in);

    DeclareIssueBuildingDetailsDTO declareIssueBuildingDetailsToDeclareIssueBuildingDetailsDTO(DeclareIssueBuildingDetails in);

}
