package com.capgemini.admin.back.vecos;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.model.VecosLockerBank;
import com.capgemini.admin.back.model.VecosSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class VecosResponseParser {

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * Reads and processes the HTTP response from an authentication request.
	 * Validates the response status code and maps the result to a VecosSession
	 * object.
	 * 
	 * @param res The HTTP response received from the authentication API call.
	 * @return A VecosSession object containing session details extracted from the
	 *         response.
	 * @throws UnauthorizedException If the response status code is not HTTP 200
	 *                               (OK),
	 *                               indicating that authentication failed or was
	 *                               unauthorized.
	 */
	public VecosSession readAuthenticateRes(CloseableHttpResponse res) {
		String apiName = "AuthenticateAccess";
		this.validateStatusCode(res, HttpStatus.SC_OK, "authenticate");

		return mapResult(res, new TypeReference<VecosSession>() {
		}, apiName);
	}

	/**
	 * Reads and processes the HTTP response from the Vecos Locker Bank status API.
	 * Validates the response status code and maps the result to a VecosLockerBank
	 * object.
	 * 
	 * @param res The HTTP response received from the VecosLockerBankStatus API
	 *            call.
	 * @return A VecosLockerBank object containing the status details of the locker
	 *         bank.
	 * @throws UnauthorizedException If the response status code is not HTTP 200
	 *                               (OK),
	 *                               indicating that the request was unauthorized or
	 *                               failed.
	 */
	public VecosLockerBank readVecosLockerBankStatus(CloseableHttpResponse res) {
		String apiName = "VecosLockerBankStatus";
		this.validateStatusCode(res, HttpStatus.SC_OK, apiName);

		return mapResult(res, new TypeReference<VecosLockerBank>() {
		}, apiName);
	}

	/**
	 * Validates the HTTP response status code against the expected status code.
	 * If the status code does not match, logs the error and handles unauthorized
	 * access
	 * or other errors appropriately.
	 * 
	 * @param res                The HTTP response to validate.
	 * @param expectedStatusCode The expected HTTP status code (e.g., 200 for OK).
	 * @param apiName            The name of the API being called, used for logging
	 *                           and error handling.
	 * @throws UnauthorizedException If the response status code is 401
	 *                               (Unauthorized),
	 */
	private void validateStatusCode(CloseableHttpResponse res, int expectedStatusCode, String apiName) {
		int statusCode = res.getStatusLine().getStatusCode();
		if (expectedStatusCode != statusCode) {
			log.info("ERROR : {}", statusCode);
			// In case of 401, authenticate and retry request
			if (statusCode == HttpStatus.SC_UNAUTHORIZED) {
				log.error("Expected staus code " + HttpStatus.SC_OK + " ,but received " + HttpStatus.SC_UNAUTHORIZED);
			} else {
				readErrorBody(res, statusCode, apiName);
			}
		}
	}

	/**
	 * Reads the error body from an HTTP response.
	 * 
	 * @param res        The HTTP response containing the error.
	 * @param statusCode The HTTP status code returned by the server.
	 * @param apiName    The name of the API that was called, used for error
	 *                   context.
	 */
	private void readErrorBody(CloseableHttpResponse res, int statusCode, String apiName) {
		String body = null;
		if (Objects.nonNull(res.getEntity())) {
			try {
				body = EntityUtils.toString(res.getEntity(), "UTF-8");
			} catch (ParseException | IOException e) {
				body = "unreadable body";
			}
		}
	}

	/**
	 * Maps the HTTP response body to a Java object of the specified type.
	 * Validates that the response contains an entity and attempts to deserialize it
	 * using the provided {@link TypeReference}. If mapping fails, throws a custom
	 * exception.
	 * 
	 * @param <T>           The type of the object to map the response to.
	 * @param res           The HTTP response containing the body to be mapped.
	 * @param typeReference A {@link TypeReference} indicating the target type for
	 *                      deserialization.
	 * @param apiName       The name of the API being processed, used for logging
	 *                      and error messages.
	 * @return An object of type T mapped from the response body.
	 */
	private <T> T mapResult(CloseableHttpResponse res, TypeReference<T> typeReference, String apiName) {
		HttpEntity entity = res.getEntity();
		if (Objects.isNull(entity)) {
			String msg = String.format("Vecos %s response - cannot find http entity from response",
					apiName);
			log.error(msg);
			return null;
		}
		try (InputStream is = entity.getContent()) {

			return objectMapper.readValue(is, typeReference);
		} catch (UnsupportedOperationException | IOException e) {
			String msg = String.format("Vecos %s response - cannot map body to %s - error: %s",
					apiName, typeReference.getType().getTypeName(), e.getMessage());
			log.error(msg);
			return null;
		}
	}

}
