package com.capgemini.admin.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CountryDTO implements WithTitleDTO, WithCdmAttributesDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long modifiedAt;
    private Long cdmKeyId;
    private String countryIsoAlpha2;
    private Map<String, String> attributes = new HashMap<String, String>();
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private List<CityDTO> cities;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Map<String, String> cdmAttributes = new HashMap<String, String>();
    private String titleFr;
    private String titleEn;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String title;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long nbChilds;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OpeningHours openingHours;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long limitInDay;
}
