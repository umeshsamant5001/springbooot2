package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.EnumDeviceAttribute;
import com.capgemini.admin.back.model.EnumDeviceType;
import com.capgemini.admin.back.model.PoiDTO;
import com.capgemini.admin.back.model.SensorDataDTO;
import com.capgemini.admin.back.config.SensorConstants;

@Service
public class SensorDataService {



    /**
     * Converts a list of {@link Device} entities into a list of {@link SensorDataDTO} objects.
     * It enriches the sensor data with POI information (if available) and maps device attributes
     * such as temperature, humidity, CO2, etc., into the DTO.
     *
     * @param poiDTOs List of POI DTOs used to map POI names to CDM key IDs.
     * @param devices List of devices to convert.
     * @return A list of SensorDataDTOs representing the sensor data for each device,
     *         or null if the devices list is null.
     */
    public List<SensorDataDTO> convertToSensorDataDTO(List<PoiDTO> poiDTOs, List<Device> devices) {
        if (Objects.isNull(devices)) {
            return null;
        }

        return devices.stream()
                .map(device -> {
                    SensorDataDTO sensorData = new SensorDataDTO();

                    String poiName = device.getPoiName();

                    // If link to a Poi, get the Poi
                    if (Objects.nonNull(poiName)) {
                        PoiDTO foundPoi = poiDTOs.stream()
                                .filter(poi -> Objects.equals(poi.getName(), poiName))
                                .findFirst()
                                .orElse(null);

                        if (Objects.nonNull(foundPoi)) {
                            sensorData.setCdmKeyIdPoi(foundPoi.getCdmKeyId());
                        }
                    }

                    // Basic fields
                    sensorData.setUuid(device.getUuid());
                    sensorData.setPoiName(device.getPoiName());

                    if (Objects.nonNull(device.getFloor())) {
                        sensorData.setCdmKeyIdFloor(device.getFloor().getCdmKeyId());
                    }

                    if (Objects.nonNull(device.getStatus())) {
                        sensorData.setStatus(device.getStatus().toString());
                    }

                    if (Objects.nonNull(device.getDeviceType())) {
                        sensorData.setDeviceType(device.getDeviceType().toString());
                    }

                    if (Objects.nonNull(device.getLastChange())) {
                        sensorData.setLastChange(device.getLastChange().toString());
                    }

                    Map<String, String> attributes = device.getAttributes();

                    sensorData.setBattery(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.VDD));

                    sensorData.setOccupancy(
                            this.getAttributeAsString(attributes, EnumDeviceAttribute.OCCUPATION));

                    sensorData.setCo2(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.CO2));

                    sensorData.setHumidity(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.HUMIDITY));

                    sensorData.setLight(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.LUX));

                    sensorData.setNoise(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.SOUND));

                    sensorData.setTempC(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPC));

                    sensorData.setTempF(
                            this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPF));

                    return sensorData;
                })
                .collect(Collectors.toList());
    }

    /**
     * Aggregates sensor data from multiple devices and maps it to their corresponding POIs.
     * If multiple devices are linked to the same POI, their data is merged into a single {@link SensorDataDTO}.
     * Special handling is applied for desk occupancy to determine if the desk is busy based on recent activity.
     *
     * @param poiDTOs  List of POI DTOs used to enrich sensor data with POI metadata.
     * @param devices  List of devices providing sensor data.
     * @return A map where the key is the POI name and the value is the aggregated {@link SensorDataDTO}.
     */
    public Map<String, SensorDataDTO> getPoiSensorData(List<PoiDTO> poiDTOs, List<Device> devices) {
        List<SensorDataDTO> sensorDataDTOs = this.convertToSensorDataDTO(poiDTOs, devices);

        Map<String, List<SensorDataDTO>> sensorDataMap = sensorDataDTOs
                .stream()
                .collect(
                        Collectors.toMap(
                                SensorDataDTO::getPoiName,
                                sensorData -> new ArrayList<>(Arrays.asList(sensorData)),
                                (sensorData1, sensorData2) -> {
                                    sensorData1.addAll(sensorData2);
                                    return sensorData1;
                                }));

        return sensorDataMap
                .keySet()
                .stream()
                .map(poiName -> {
                    SensorDataDTO resultSensorDataDTO = new SensorDataDTO();
                    Date now = new Date();

                    sensorDataMap
                            .get(poiName)
                            .stream()
                            .forEach(sensorDataDTO -> {
                                if (Objects.nonNull(sensorDataDTO.getCdmKeyIdPoi())) {
                                    resultSensorDataDTO.setCdmKeyIdPoi(sensorDataDTO.getCdmKeyIdPoi());
                                }
                                if (Objects.nonNull(sensorDataDTO.getUuid())) {
                                    resultSensorDataDTO.setUuid(sensorDataDTO.getUuid());
                                }
                                if (Objects.nonNull(sensorDataDTO.getPoiName())) {
                                    resultSensorDataDTO.setPoiName(sensorDataDTO.getPoiName());
                                }
                                if (Objects.nonNull(sensorDataDTO.getUuid())) {
                                    resultSensorDataDTO.setCdmKeyIdFloor(sensorDataDTO.getCdmKeyIdFloor());
                                }
                                if (Objects.nonNull(sensorDataDTO.getStatus())) {
                                    resultSensorDataDTO.setStatus(sensorDataDTO.getStatus());
                                }
                                if (Objects.nonNull(sensorDataDTO.getDeviceType())) {
                                    resultSensorDataDTO.setDeviceType(sensorDataDTO.getDeviceType());
                                }
                                if (Objects.nonNull(sensorDataDTO.getLastChange())) {
                                    resultSensorDataDTO.setLastChange(sensorDataDTO.getLastChange());
                                }
                                if (Objects.nonNull(sensorDataDTO.getBattery())) {
                                    resultSensorDataDTO.setBattery(sensorDataDTO.getBattery());
                                }
                                if (Objects.nonNull(sensorDataDTO.getOccupancy())) {
                                    String occupancy;
                                    if (Objects.equals(EnumDeviceType.OFFICESENSE_DESK.name(),
                                            sensorDataDTO.getDeviceType())) {
                                        // Special case of a Desk
                                        occupancy = deskOccupancy(sensorDataDTO, now, SensorConstants.DESK_LOCKING_TIME_MINUTES);
                                    } else {
                                        occupancy = sensorDataDTO.getOccupancy();
                                    }

                                    // As the presence can come from several sensors, we consider busy
                                    // if at least one sensor is in busy mode
                                    if (!SensorConstants.BUSY_STATE.equals(resultSensorDataDTO.getOccupancy())) {
                                        // If the result sensor is already at "busy", we don't change it.
                                        resultSensorDataDTO.setOccupancy(occupancy);
                                    }
                                }
                                if (Objects.nonNull(sensorDataDTO.getCo2())) {
                                    resultSensorDataDTO.setCo2(sensorDataDTO.getCo2());
                                }
                                if (Objects.nonNull(sensorDataDTO.getHumidity())) {
                                    resultSensorDataDTO.setHumidity(sensorDataDTO.getHumidity());
                                }
                                if (Objects.nonNull(sensorDataDTO.getLight())) {
                                    resultSensorDataDTO.setLight(sensorDataDTO.getLight());
                                }
                                if (Objects.nonNull(sensorDataDTO.getNoise())) {
                                    resultSensorDataDTO.setNoise(sensorDataDTO.getNoise());
                                }
                                if (Objects.nonNull(sensorDataDTO.getTempC())) {
                                    resultSensorDataDTO.setTempC(sensorDataDTO.getTempC());
                                }
                                if (Objects.nonNull(sensorDataDTO.getTempF())) {
                                    resultSensorDataDTO.setTempF(sensorDataDTO.getTempF());
                                }
                            });

                    return resultSensorDataDTO;
                })
                .collect(Collectors.toMap(SensorDataDTO::getPoiName, Function.identity()));
    }

    /**
     * Return the value of an attribut as a String.
     * 
     * @param attributes The Map of attributes
     * @param key        The key
     * @return The value as a String.
     */
    private String getAttributeAsString(Map<String, String> attributes, EnumDeviceAttribute key) {
        String keyString = key.toString();

        return attributes.get(keyString);
    }

    /**
     * Return the value of an attribut as a Double.
     * 
     * @param attributes The Map of attributes
     * @param key        The key
     * @return The value as a Double.
     */
    private Double getAttributeAsDouble(Map<String, String> attributes, EnumDeviceAttribute key) {
        String keyString = key.toString();

        if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
            return null;
        }

        return Double.parseDouble(attributes.get(keyString));
    }

    /**
     * Determines the occupancy state of a desk based on the last change timestamp and a locking interval.
     * 
     * If the desk is currently marked as "busy", it remains busy.
     * If it's marked as "free" but was recently occupied (within the locking interval), it is considered "busy".
     * If no valid data is available or an exception occurs, a default state is returned.
     *
     * @param sensorDataDTO         The sensor data DTO containing occupancy and last change info.
     * @param now                   The current timestamp.
     * @param intevalToConsiderFree The time interval (in seconds) to consider a desk as free after last activity.
     * @return The occupancy state: "busy", "free", or a default state.
     */
    private String deskOccupancy(SensorDataDTO sensorDataDTO, Date now, Integer intevalToConsiderFree) {
        try {
            if (Objects.isNull(sensorDataDTO)) {
                return SensorConstants.DEFAULT_STATE;
            }

            if (SensorConstants.BUSY_STATE.equals(sensorDataDTO.getOccupancy())) {
                return SensorConstants.BUSY_STATE;
            }

            if (SensorConstants.FREE_STATE.equals(sensorDataDTO.getOccupancy()) && Objects.nonNull(sensorDataDTO.getLastChange())) {
                Long occupiedTs = Long.valueOf(sensorDataDTO.getLastChange());
                long nowSecond = now.getTime() / SensorConstants.MILLIS_IN_SECOND;
                long lastOccupiedTimeInterval = nowSecond - occupiedTs;

                if (lastOccupiedTimeInterval < intevalToConsiderFree) {
                    return SensorConstants.BUSY_STATE;
                }

                return SensorConstants.FREE_STATE;
            }
        } catch (Exception e) {
            return SensorConstants.DEFAULT_STATE;
        }

        return SensorConstants.DEFAULT_STATE;
    }
}
