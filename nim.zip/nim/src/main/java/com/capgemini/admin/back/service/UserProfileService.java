package com.capgemini.admin.back.service;

import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.repository.UserProfileRepository;
import com.capgemini.admin.back.service.smtp.SMTPSendMail;

import lombok.extern.slf4j.Slf4j;

import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.model.EmailDTO;
import com.capgemini.admin.back.model.UserDTO;
import com.capgemini.admin.back.model.UserProfile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.transaction.Transactional;

@Slf4j
@Service
public class UserProfileService {

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private SMTPSendMail emailService;

    /**
     * Finds user profiles by a specific user ID.
     * 
     * @param userId the ID of the user whose profiles are to be retrieved.
     * @return a list of UserProfile entities associated with the given user ID.
     */
    public List<UserProfile> findByUserId(Long userId) {
        return userProfileRepository.findByUserId(userId);
    }

    /**
     * Finds all user profiles that match both user ID and role ID.
     * 
     * @param userId the ID of the user.
     * @param roleId the ID of the role.
     * @return a list of UserProfile entities matching the given user ID and role
     *         ID.
     */
    public List<UserProfile> findAllByUserIdAndRoleId(Long userId, Long roleId) {
        return userProfileRepository.findAllByUserIdAndRoleId(userId, roleId);
    }

    /**
     * Creates and saves a new UserProfile entity using the provided user ID and
     * role ID.
     *
     * @param userId the ID of the user to associate with the profile.
     * @param roleId the ID of the role to associate with the profile.
     */
    public void saveUserProfile(Long userId, Long roleId) {

        UserProfile existingUserProfile = findProfileByUserIdAndRoleId(userId,
                roleId);
        if (Objects.nonNull(existingUserProfile)) {
            existingUserProfile.setUserId(userId);
            existingUserProfile.setRoleId(roleId);
            userProfileRepository.save(existingUserProfile);
        } else {
            UserProfile userProfile = new UserProfile();
            userProfile.setUserId(userId);
            userProfile.setRoleId(roleId);
            userProfileRepository.save(userProfile);
        }
    }

    /**
     * Retrieves a user profile based on the given user ID and role ID.
     *
     * @param userId The ID of the user.
     * @param roleId The ID of the role.
     * @return The UserProfile entity matching the user and role, or null if not found.
     */
    public UserProfile findProfileByUserIdAndRoleId(Long userId, Long roleId) {
        return userProfileRepository.findProfileByUserIdAndRoleId(userId, roleId);
    }

    @Transactional
    public void deleteAdminProfiles(Long userId) {
        List<UserProfile> userProfiles = findByUserId(userId);
        if (userProfiles != null && !userProfiles.isEmpty()) {
            userProfileRepository.deleteAdminProfileByUserId(userId);
        }
    }
    
    // Single unassign method for special role locations
    @Transactional
    public void unassignSoSpecialProfiles(Long userId, UserDTO userDTO , Long roleId) {
        userProfileRepository.unassignSoSpecialProfile(userId ,roleId);
        sendSpecialUserRemovalEmail(userDTO);
    }

    // multiple unassign method for special role locations
    @Transactional
    public void unassignSoSpecialProfiles(Long userId, UserDTO userDTO ,List<Long> roleIds) {
        userProfileRepository.unassignSoSpecialProfile(userId ,roleIds);
        sendSpecialUserRemovalEmail(userDTO);
    }

    /**
     * Sends a user deletion email.
     *
     * @param userDTO The user DTO containing user information.
     */
    private void sendSpecialUserRemovalEmail(UserDTO userDTO) {

        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", userDTO.getFirstName());
        params.put("LAST_NAME", userDTO.getLastName());
        params.put("ROLE", userDTO.getRoleLocations().get(0).getRole().getName());
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subject = this.applicationProperties.getEmail().getDeleteSpecialUser().getSubjectspecialuser();
        String body = StringSubstitutor.replace(this.applicationProperties.getEmail().getDeleteSpecialUser().getBodyspecialuser(), params,
                "${", "}");

        sendEmail(
                subject,
                body,
                List.of(userDTO.getEmail()));
    }

    /**
     * Sends an email using the configured email service.
     *
     * @param subject   The subject of the email.
     * @param body      The body content of the email.
     * @param addresses The list of recipient email addresses.
     */
    private void sendEmail(
            String subject,
            String body,
            List<String> addresses) {
        EmailDTO emailDTO = new EmailDTO();

        emailDTO.setSubject(subject);
        emailDTO.setBody(body);
        emailDTO.setAdressee(addresses);

        try {
            emailService.sendEmail(emailDTO);
        } catch (Exception e) {
            log.error("Error while sending email in UserService via MS Graph error: {}",  e.getMessage(), e);
        }
    }
}
