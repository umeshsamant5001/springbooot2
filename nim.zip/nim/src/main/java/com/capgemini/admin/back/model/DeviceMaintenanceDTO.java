package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DeviceMaintenanceDTO {
    private String uuid;

    @JsonProperty("under_maintenance")
    private Boolean underMaintenance; 
}