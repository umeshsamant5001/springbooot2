package com.capgemini.admin.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.AlertMessage;
import com.capgemini.admin.back.model.AlertMessageDTO;

@Mapper(uses = { AlertMessageLocationMapper.class })
public interface AlertMessageMapper {

    AlertMessageMapper INSTANCE = Mappers.getMapper(AlertMessageMapper.class);

    AlertMessageDTO alertMessageToAlertMessageDTO(AlertMessage in, @Context String language);

    AlertMessage alertMessageDTOToAlertMessage(AlertMessageDTO in);

    // To get the response by countryId and buildingId
    AlertMessageDTO alertMessageToAlertMessageDTO(AlertMessage in);

}
