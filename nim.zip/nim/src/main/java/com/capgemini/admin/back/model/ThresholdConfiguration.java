package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import lombok.Data;

@Data
@Entity
@Table(name = "threshold_configuration")
public class ThresholdConfiguration {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ThresholdConfiguration_Generator")
    @SequenceGenerator(name = "ThresholdConfiguration_Generator", sequenceName = "ThresholdConfiguration_Sequence")
    private Long id;
    @Column(name = "country_id")
    private Long countryId;
    @Column(name = "space_type_id")
    private Long spaceTypeId;
    @Enumerated(EnumType.STRING)
    @Column(name = "temperature_unit")
    private TemperatureUnit temperatureUnit;
    @OneToMany(mappedBy = "thresholdConfiguration", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    private List<Threshold> thresholds = new ArrayList<>();
    @OneToMany(mappedBy = "thresholdConfiguration", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    private List<Alert> alerts = new ArrayList<>();
    @Column(name = "modified_at")
    private Long modifiedAt = (new Date()).getTime() / 1000;
}
