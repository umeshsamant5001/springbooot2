package com.capgemini.admin.back.repository.procedure;

import com.capgemini.admin.back.model.procedure.FrontLabel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FrontLabelRepository extends JpaRepository<FrontLabel, Long> {

    @Procedure(name = "GetLanguagetextByCode")
    List<FrontLabel> getLanguagetextByCode(@Param("languagecode") String languageCode);

    @Modifying
    @Query(value = "INSERT INTO mobile_multilang_field (key_id, field_key, language_text, language_code, modified_at) "
            +
            "VALUES (:keyId, :fieldKey, :languageText, :languageCode, :modifiedAt)", nativeQuery = true)
    void insertMobileMultilangField(@Param("keyId") String key_id,
            @Param("fieldKey") String field_key,
            @Param("languageText") String language_text,
            @Param("languageCode") String language_code,
            @Param("modifiedAt") Long modified_at);

}