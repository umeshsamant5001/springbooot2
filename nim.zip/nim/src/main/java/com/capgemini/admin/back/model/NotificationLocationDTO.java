package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class NotificationLocationDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long notificationId;

    private Long cdmKeyId;
    private LevelEnum level;
    private Long countryId;
    private String countryName;
    private String status;
}
