package com.capgemini.admin.utils;

import java.util.function.Function;

public class EnvVariableUtil {

	private EnvVariableUtil() {

	}

	public static String getenv(String variable) {
	    return ((Function<String, String>) System::getenv).apply(variable);
	}

}
