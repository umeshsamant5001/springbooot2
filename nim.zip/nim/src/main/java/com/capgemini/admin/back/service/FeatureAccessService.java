package com.capgemini.admin.back.service;

import com.capgemini.admin.back.mapper.FeatureAccessMapper;
import com.capgemini.admin.back.model.FeatureAccess;
import com.capgemini.admin.back.model.FeatureAccessDTO;
import com.capgemini.admin.back.repository.FeatureAccessRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FeatureAccessService {

    @Autowired
    private FeatureAccessRepository featureRepository;

    /**
     * Converts a list of Feature entities to a list of FeatureDTOs.
     *
     * @return A function to perform the conversion.
     */
    public List<FeatureAccessDTO> listFeatureAccessToFeatureAccessDTOList(List<FeatureAccess> featureAccesses,
            String language) {
        return featureAccesses.stream().map(f -> toFeatureAccessDTO(f, language)).collect(Collectors.toList());
    }

    /**
     * Converts a Feature entity to a FeatureDTO.
     *
     * @return A function to perform the conversion.
     */
    public FeatureAccessDTO toFeatureAccessDTO(FeatureAccess featureAccess, String language) {
        return FeatureAccessMapper.INSTANCE.featureAccessToFeatureAccessDTO(featureAccess, language);
    }

    /**
     * Retrieves all features associated with a given role ID.
     *
     * @param roleId The ID of the role.
     * @return List of features associated with the specified role ID.
     */
    public List<FeatureAccess> getAllByRoleId(Long roleId) {
        List<FeatureAccess> featureAccesses = this.featureRepository.findAllByRoleId(roleId);
        if (CollectionUtils.isEmpty(featureAccesses)) {
            return new ArrayList<FeatureAccess>();
        }
        return featureAccesses;
    }

    /**
     * Retrieves all features.
     *
     * @return List of all features.
     */
    public List<FeatureAccess> getAll() {
        List<FeatureAccess> featureAccesses = this.featureRepository.findAll();
        if (CollectionUtils.isEmpty(featureAccesses)) {
            return new ArrayList<FeatureAccess>();
        }
        return featureAccesses;
    }

}