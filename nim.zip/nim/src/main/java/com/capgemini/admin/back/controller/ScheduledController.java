package com.capgemini.admin.back.controller;

import java.util.Date;
import java.util.Objects;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;
import lombok.extern.slf4j.Slf4j;

/**
 * As we have multiple notification like object wich used the same "pattern",
 * this class
 * is a base for the corresponding controllers.
 */
@Slf4j
public abstract class ScheduledController<N extends Scheduled, S extends ScheduledSent, DTO> {

    /**
     * Get a Scheduled by its Id
     * 
     * @param id The id of the Scheduled
     * @return
     */
    protected abstract N getScheduledById(Long id, String language);

    /**
     * Delete a Scheduled
     * 
     * @param scheduled The scheduled to delete
     */
    protected abstract void deleteScheduled(N scheduled);

    /**
     * Save a Scheduled to database
     * 
     * @param scheduled The Scheduled to save
     * @return The Scheduled as it's saved
     */
    protected abstract N saveScheduled(N scheduled);

    /**
     * Update a Scheduled with data from a ScheduleDTO
     * 
     * @param scheduled    The Scheduled to update
     * @param scheduledDTO The ScheduledDTO with the data
     * @return The Scheduled as it's saved
     */
    protected abstract N updateScheduled(N scheduled, DTO scheduledDTO);

    /**
     * Map a Scheduled to its DTO Object
     * 
     * @param scheduled The scheduled to map
     * @return The scheduled mapped
     */
    protected abstract DTO mapToDTO(N scheduled);

    /**
     * Map a DTO to its Business Object
     * 
     * @param scheduled The scheduled to map
     * @return The scheduled mapped
     */
    protected abstract N mapToBusiness(DTO scheduledDTO);

    /**
     * Retrieves a Scheduled based on its identifier.
     *
     * @param scheduledId The identifier of the Scheduled to retrieve.
     * @return ResponseEntity containing the corresponding ScheduledDTO object for
     *         the found Scheduled.
     *         Returns an HTTP 404 response if the Scheduled is not found.
     */
    @GetMapping("/{scheduledId}")
    public ResponseEntity<DTO> getScheduled(
            @PathVariable Long scheduledId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        N scheduled = this.getScheduledById(scheduledId, language);

        if (Objects.isNull(scheduled)) {
            return ResponseEntity.notFound().build();
        }

        DTO scheduledDTO = this.mapToDTO(scheduled);

        return ResponseEntity.ok(scheduledDTO);
    }

    /**
     * Deletes a Scheduled based on its identifier.
     *
     * @param scheduledId The identifier of the Scheduled to be deleted.
     * @return ResponseEntity with no content if the deletion is successful.
     *         Returns an HTTP 404 response if the Scheduled is not found.
     */
    @DeleteMapping("/{scheduledId}")
    public ResponseEntity<Object> deleteNotification(
            @PathVariable Long scheduledId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        N scheduled = this.getScheduledById(scheduledId, language);

        if (Objects.isNull(scheduled)) {
            return ResponseEntity.notFound().build();
        }

        // Delete the Scheduled
        this.deleteScheduled(scheduled);

        return ResponseEntity.ok().build();
    }

    /**
     * Creates a new Scheduled.
     *
     * @param scheduledDTO The ScheduledDTO object containing the information for
     *                     the new Scheduled.
     * @return ResponseEntity containing the newly created ScheduledDTO object if
     *         successful.
     *         Returns an HTTP 400 response if the request is invalid.
     *         Returns an HTTP 500 response if there was an internal server error
     *         during the process.
     */
    @PostMapping
    public ResponseEntity<DTO> createScheduled(
            @Valid @RequestBody DTO scheduledDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        N scheduled = this.mapToBusiness(scheduledDTO);

        if (Objects.isNull(scheduled)) {
            return ResponseEntity.badRequest().build();
        }

        // Set the last change time to the current time
        scheduled.setLastChange(new Date().getTime() / 1000);

        String sanitizedScheduled = new String(String.valueOf(scheduled)
                .replaceAll("[\r\n\t]", "_")
                .replaceAll("[^\\x20-\\x7E]", ""));
        log.info("scheduled : {}", sanitizedScheduled);

        // Save the new Scheduled
        N scheduledSave = this.saveScheduled(scheduled);
        // Map the saved Scheduled to a ScheduledDTO
        DTO scheduledDTOSave = this.mapToDTO(scheduledSave);

        if (Objects.isNull(scheduledDTOSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.status(HttpStatus.CREATED).body(scheduledDTOSave);
        }
    }

    /**
     * Updates an existing Scheduled based on its identifier.
     *
     * @param scheduledId  The identifier of the Scheduled to be updated.
     * @param scheduledDTO The updated ScheduledDTO object.
     * @return ResponseEntity containing the updated ScheduledDTO object if
     *         successful.
     *         Returns an HTTP 404 response if the Scheduled is not found.
     *         Returns an HTTP 500 response if there was an internal server error
     *         during the process.
     */
    @PutMapping("/{scheduledId}")
    public ResponseEntity<DTO> updateScheduled(
            @PathVariable Long scheduledId,
            @Valid @RequestBody DTO scheduledDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        N scheduled = this.getScheduledById(scheduledId, language);

        if (Objects.isNull(scheduled)) {
            return ResponseEntity.notFound().build();
        }

        // Update the Scheduled and get the updated version
        N scheduledSave = this.updateScheduled(scheduled, scheduledDTO);
        // Map the updated Scheduled to a ScheduledDTO
        DTO scheduledDTOSave = this.mapToDTO(scheduledSave);

        if (Objects.isNull(scheduledDTOSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(scheduledDTOSave);
        }
    }

    /**
     * Update the status of the Scheduled to RUNNING
     * 
     * @param scheduledId The identifier of the Scheduled to be updated.
     * @return The updated Scheduled
     */
    @PutMapping("/{scheduledId}/start")
    public ResponseEntity<DTO> startScheduled(
            @PathVariable Long scheduledId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        return this.changeScheduledStatus(scheduledId, EnumStatusScheduled.RUNNING, language);
    }

    /**
     * Update the status of the Scheduled to STOPPED
     * 
     * @param scheduledId The identifier of the Scheduled to be updated.
     * @return The updated Scheduled
     */
    @PutMapping("/{scheduledId}/stop")
    public ResponseEntity<DTO> stopScheduled(
            @PathVariable Long scheduledId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        return this.changeScheduledStatus(scheduledId, EnumStatusScheduled.STOPPED, language);
    }

    /**
     * Function to change the status of a scheduled
     * 
     * @param scheduledId The identifier of the scheduled to be updated.
     * @param status      The status to apply
     * @return A ResponseEntity of the updated scheduled
     */
    private ResponseEntity<DTO> changeScheduledStatus(Long scheduledId, EnumStatusScheduled status, String language) {
        N scheduled = this.getScheduledById(scheduledId, language);

        if (Objects.isNull(scheduled)) {
            return ResponseEntity.notFound().build();
        }

        // Change the status
        scheduled.setStatus(status);
        // Save the Scheduled
        N scheduledSave = this.saveScheduled(scheduled);
        // Map the updated Scheduled to a ScheduledDTO
        DTO scheduledDTOSave = this.mapToDTO(scheduledSave);

        if (Objects.isNull(scheduledDTOSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(scheduledDTOSave);
        }
    }

}
