package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.TabletImportAudit;

@Repository
public interface TabletImportAuditRepository extends JpaRepository<TabletImportAudit, Long> {

    @Query(value = "SELECT  pa.poi_id AS poiAttrPoiId, pa.att_key AS attKey, pa.att_value AS attValue, d.uuid AS uuid, d.poi_name AS poiName "
            +
            " FROM device d " +
            " INNER JOIN poi p ON d.poi_name = p.name " +
            " INNER JOIN ( SELECT poi_id, att_key, att_value " +
            " FROM (SELECT poi_id, att_key, att_value, " +
            "    ROW_NUMBER() OVER (PARTITION BY att_key ORDER BY poi_id) AS rn " +
            " FROM poi_attributes " +
            " WHERE att_key IN ('bookable','checkIn','checkInDuration','earlyCheckIn','checkOut','showState', " +
            "   'showTemp','showHumidity','showSound','showCo2','showLux','reportAnIssue') " +
            "   AND att_value IS NOT NULL " +
            "   AND att_value <> '' " +
            " ) sub " +
            ") pa ON p.id = pa.poi_id " +
            "WHERE d.poi_name =:poiName  AND d.uuid =:uuId ", nativeQuery = true)
    List<Object[]> fetchTabletImportAuditPoiDeviceAttribute(@Param("poiName") String poiName,
            @Param("uuId") String uuId);

}
