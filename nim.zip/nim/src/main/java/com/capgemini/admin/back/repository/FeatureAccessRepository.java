package com.capgemini.admin.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.FeatureAccess;

@Repository
public interface FeatureAccessRepository extends JpaRepository<FeatureAccess, Long> {

    /**
     * Finds all features associated with a given role ID.
     *
     * @param roleId The ID of the role.
     * @return List of features associated with the specified role ID.
     */
    @Query(value = "SELECT role.featureAccesses " +
            "FROM Role role " +
            "WHERE role.id = :roleId")
    List<FeatureAccess> findAllByRoleId(@Param("roleId") Long roleId);

    /**
     * Deletes all features associated with a given role ID.
     *
     * @param id The ID of the role for which features should be deleted.
     */
    @Query(value = "DELETE FROM feature_access " +
            "WHERE id IN ( " +
            "SELECT feature_access_id " +
            "FROM role_feature_access " +
            "WHERE role_id = :id " +
            ")", nativeQuery = true)
    void deleteAllByRoleId(Long id);

}