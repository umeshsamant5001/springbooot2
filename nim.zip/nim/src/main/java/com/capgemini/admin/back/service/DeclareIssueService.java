package com.capgemini.admin.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.admin.back.mapper.DeclareIssueMapper;
import com.capgemini.admin.back.model.DeclareIssue;
import com.capgemini.admin.back.model.DeclareIssueDTO;
import com.capgemini.admin.back.repository.DeclareIssueRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DeclareIssueService {

    @Autowired
    private DeclareIssueRepository declareIssueRepository;

    /**
     * Retrieves all declared issues from the database.
     *
     * @return list of {@link DeclareIssue} entities
     */
    public List<DeclareIssueDTO> getAllDeclareIssues() {
        List<DeclareIssue> declareIssues = declareIssueRepository.findAll();
        List<DeclareIssueDTO> declareIssueDTOs = declareIssues
                            .stream()
                            .map(issues -> DeclareIssueMapper.INSTANCE.declareIssueToDeclareIssueDTO(issues))
                            .collect(Collectors.toList());
        return declareIssueDTOs;
    }
}