package com.capgemini.admin.back.vecos;

public class VecosConstants {

    public static final String POI_GROUP_LOCKER_NAME = "locker";
    public static final String LOCKER_BANK_ID = "lockerBankId";
    public static final String LOCKER_TENANT = "lockerTenant";
    public static final String LOCKER_FREE_NUMBER = "lockerFreeNumber";
    public static final String GRANT_TYPE = "password";
    public static final String LOGIN_ENDPOINT = "connect/token";
    public static final String VECOS_CONFIG_BASIC = "vecos_%s_basic";
    public static final String VECOS_CONFIG_USERNAME = "vecos_%s_username";
    public static final String LOCKER_BANK_NAME = "lockerBankName";
    public static final String VECOS_LOCATION_ENDPOINT = "api/locations";
    public static final String VECOS_SECTION_ENDPOINT = "/sections";
    public static final String VECOS_SECTION_ENDPOINT_API = "api/sections";
    public static final String VECOS_SECTION_LOCKERBANKS_ENDPOINT = "/lockerbanks";
    public static final String LOCKER_BANK_ENDPOINT = "api/lockerbanks/";
    public static final String STATUS_ENDPOINT = "/status";

}
