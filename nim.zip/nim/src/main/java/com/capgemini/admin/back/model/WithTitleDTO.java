package com.capgemini.admin.back.model;

public interface WithTitleDTO {
    void setTitle(String title);
}
