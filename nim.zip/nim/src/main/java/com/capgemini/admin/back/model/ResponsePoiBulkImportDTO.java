package com.capgemini.admin.back.model;

import java.util.List;
import lombok.Data;
import java.util.Objects;
import java.util.ArrayList;

@Data
public class ResponsePoiBulkImportDTO {
    private List<PoiBulkImportDTO> poiBulkImportDTOs;
    private List<String> errorsInFile;

    public ResponsePoiBulkImportDTO() {
        this.poiBulkImportDTOs = new ArrayList<>();
    }

    public void addError(String error) {
        if (Objects.isNull(this.errorsInFile)) {
            this.errorsInFile = new ArrayList<>();
        }
        this.errorsInFile.add(error);
    }


    public void addPoi(PoiBulkImportDTO poi) {
        this.poiBulkImportDTOs.add(poi);
    }

}
