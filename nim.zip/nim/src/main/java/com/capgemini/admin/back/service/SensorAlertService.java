package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.AlertType;
import com.capgemini.admin.back.model.KeyValueEntry;
import com.capgemini.admin.back.model.ThresholdConfiguration;
import com.capgemini.admin.back.model.ThresholdLevel;
import com.capgemini.admin.back.repository.AlertMessageRepository;
import com.capgemini.admin.back.service.smtp.SMTPSendMail;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@DependsOn("distributedLockService")
public class SensorAlertService {

    List<ThresholdConfiguration> runningAlerts = new ArrayList<>();
    List<KeyValueEntry> devicesCo2Hist = new ArrayList<>();
    List<KeyValueEntry> devicesTempHist = new ArrayList<>();    

    private static final Map<AlertType, ThresholdLevel> ALERT_TYPE_TO_LEVEL_MAP;

    @Autowired
    SMTPSendMail smtpSendMail;

    @Autowired
    AlertMessageRepository alertMessageRepository;

    @Autowired
    DistributedLockService distributedLockService;

    @Autowired
    AlertMessageService alertMessageService;

    static {
        ALERT_TYPE_TO_LEVEL_MAP = new HashMap<>();
        ALERT_TYPE_TO_LEVEL_MAP.put(AlertType.YELLOW, ThresholdLevel.LOWEST);
        ALERT_TYPE_TO_LEVEL_MAP.put(AlertType.ORANGE, ThresholdLevel.MEDIUM);
        ALERT_TYPE_TO_LEVEL_MAP.put(AlertType.RED, ThresholdLevel.HIGH);
    }

    @Autowired
    private ThresholdConfigurationService thresholdConfigurationService;
       
    /**
     * Loads and activates all enabled threshold configurations.
     * Clears any previously running alerts and replaces them with the current active configurations.
     */
    public void launchThresholdConfigurations() {
        List<ThresholdConfiguration> thresholdConfigurations = thresholdConfigurationService
                .getAllThresholdConfigurationsEnabled();
        log.info("Confs size " + thresholdConfigurations.size());
        runningAlerts.clear();
        runningAlerts.addAll(thresholdConfigurations);

    }                     
 
}
