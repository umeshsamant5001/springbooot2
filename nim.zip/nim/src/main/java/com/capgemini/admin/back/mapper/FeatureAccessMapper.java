package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.FeatureAccess;
import com.capgemini.admin.back.model.FeatureAccessDTO;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Named("FeatureAccessMapper")
@Mapper(config = DtoMapperConfig.class)
public interface FeatureAccessMapper {

    FeatureAccessMapper INSTANCE = Mappers.getMapper(FeatureAccessMapper.class);

    /**
     * Maps a Feature entity to a FeatureDTO entity.
     *
     * @param in The input Feature entity.
     * @return The mapped FeatureDTO entity.
     */
    @Named("featureAccessToFeatureAccessDTO")
    FeatureAccessDTO featureAccessToFeatureAccessDTO(FeatureAccess in, @Context String language);

    /**
     * Maps a FeatureDTO entity to a Feature entity.
     *
     * @param in The input FeatureDTO entity.
     * @return The mapped Feature entity.
     */
    @Named("featureAccessDTOToFeatureAccess")
    FeatureAccess featureAccessDTOToFeatureAccess(FeatureAccessDTO in, @Context String language);

}
