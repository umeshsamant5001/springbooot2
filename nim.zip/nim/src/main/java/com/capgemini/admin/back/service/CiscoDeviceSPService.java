package com.capgemini.admin.back.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.CiscoDeviceSP;
import com.capgemini.admin.back.model.SubLevelEnum;
import com.capgemini.admin.back.repository.CiscoDeviceSPRepository;

@Service
public class CiscoDeviceSPService {

    @Autowired
    private CiscoDeviceSPRepository ciscoDeviceSPRepository;

    @Autowired
    private TreeService treeService;
  
    /**
     * Retrieves all CiscoDeviceSP entries for a specific building ID based on a search string.
     * @return a list of CiscoDeviceSP objects matching the criteria
     */
    public List<CiscoDeviceSP> getAllCiscoDeviceSPByBuildingId(String searchString, int buildingId) {
        return ciscoDeviceSPRepository.SO_GetCiscoDeviceInfo(searchString, buildingId, 0);
    }
    
    /**
     * Retrieves all CiscoDeviceSP entries across all buildings based on a search string.
     * This method uses a stored procedure with a flag to indicate global search.
     * @return a list of all CiscoDeviceSP objects matching the search criteria
     */
    public List<CiscoDeviceSP> getAllCiscoDeviceSP(String searchString) {
        return ciscoDeviceSPRepository.SO_GetCiscoDeviceInfo(searchString, 0, 1);
    }
   
    /**
     * Filters a list of CiscoDeviceSP objects based on user access permissions using the site tree.
     * Only devices that the user is authorized to access are returned.
     *
     * @param ciscoDeviceSPs the list of CiscoDeviceSP objects to filter
     * @return a filtered list of CiscoDeviceSP objects the user has access to
     */
    public List<CiscoDeviceSP> filterCiscoDeviceSP(List<CiscoDeviceSP> ciscoDeviceSPs) {
        List<String> ciscoDeviceList = ciscoDeviceSPs.stream()
                .map(CiscoDeviceSP::getDeviceId)
                .collect(Collectors.toList());

        List<String> filteredCiscoDeviceIdList = treeService.filterId(SubLevelEnum.CISCO_DEVICE, ciscoDeviceList);

        return ciscoDeviceSPs
                .stream()
                .filter(ciscoDevice -> filteredCiscoDeviceIdList.contains(ciscoDevice.getDeviceId()))
                .collect(Collectors.toList());
    }

}
