package com.capgemini.admin.back.repository;

import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.query.Param;
import com.capgemini.admin.back.model.UserRoleId;
import com.capgemini.admin.back.model.UserProfile;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, UserRoleId> {

        @Query("SELECT up FROM UserProfile up WHERE userId =:userId and roleId= :roleId")
        List<UserProfile> findAllByUserIdAndRoleId(@Param("userId") Long userId, @Param("roleId") Long roleId);

        @Query("SELECT up FROM UserProfile up WHERE userId =:userId ")
        List<UserProfile> findByUserId(@Param("userId") Long userId);

        @Modifying
        @Transactional
        @Query("DELETE FROM UserProfile up WHERE up.userId = :userId AND up.roleId IN :roleIds")
        void deleteAllByUserIdAndRoleIds(@Param("userId") Long userId, @Param("roleIds") List<Long> roleIds);

        @Query("SELECT up FROM UserProfile up WHERE userId =:userId and roleId= :roleId")
        UserProfile findProfileByUserIdAndRoleId(@Param("userId") Long userId, @Param("roleId") Long roleId);

        @Modifying
        @Transactional
        @Query(value = "DELETE up FROM user_profile up INNER JOIN role r ON up.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR r.is_web_user_profile = 'false') " +
                        "AND up.user_id = :userId", nativeQuery = true)
        public void deleteAdminProfileByUserId(@Param("userId") Long userId);

        // single unassign method for special role locations
        @Modifying
        @Transactional
        @Query(value = "DELETE up FROM user_profile up INNER JOIN role r ON up.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR r.is_web_user_profile = 'true') " +
                        "AND up.user_id = :userId AND up.role_id = :roleId", nativeQuery = true)
        public void unassignSoSpecialProfile(@Param("userId") Long userId , @Param("roleId") Long roleId);

        // multiple unassign method for special role locations
        @Modifying
        @Transactional
        @Query(value = "DELETE up FROM user_profile up INNER JOIN role r ON up.role_id = r.id " +
                        "WHERE (r.is_web_user_profile IS NULL OR r.is_web_user_profile = 'true') " +
                        "AND up.user_id = :userId AND up.role_id in (:roleIds)", nativeQuery = true)
        public void unassignSoSpecialProfile(@Param("userId") Long userId , @Param("roleIds") List<Long> roleIds);

}
