package com.capgemini.admin.back.service;

import com.capgemini.admin.back.mapper.CountrySPMapper;
import com.capgemini.admin.back.model.CountrySP;
import com.capgemini.admin.back.model.CountrySPDTO;
import com.capgemini.admin.back.repository.CountrySPRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CountrySPService {

    @Autowired
    private CountrySPRepository countrySPRepository;

    @Autowired
    private TreeService treeService;

    /**
     * Retrieves a filtered list of countries based on user role, language, asset code,
     * and whether only secure buildings should be included.
     *
     * @param language the language preference for the data
     * @param roleId the role ID of the user for access control
     * @param assetCode optional asset code to filter countries
     * @param onlySecureBuilding flag to include only countries with secure buildings
     * @return a list of filtered CountrySPDTO objects
     */
    @Transactional(readOnly = true)
    public List<CountrySPDTO> getFilteredCountryList(String language, Integer roleId, String assetCode,
            Boolean onlySecureBuilding) {
        List<CountrySP> countries = countrySPRepository.SO_GetSiteTree(language, roleId);
        countries = treeService.filterTree(countries);
        List<CountrySPDTO> filteredCountryList = new ArrayList<>();

        if (Boolean.TRUE.equals(onlySecureBuilding)) {
            filteredCountryList = countries
                    .stream()
                    .filter(countrie -> Objects.nonNull(countrie.getIsSecured())
                            && countrie.getIsSecured().equals(Boolean.TRUE)
                            && checkAssetCode(assetCode, countrie))
                    .map(CountrySPMapper.INSTANCE::countrySPToCountrySPDTO)
                    .collect(Collectors.toList());
        } else {
            filteredCountryList = countries
                    .stream()
                    .filter(countrie -> checkAssetCode(assetCode, countrie))
                    .map(CountrySPMapper.INSTANCE::countrySPToCountrySPDTO)
                    .collect(Collectors.toList());
        }

        return filteredCountryList;
    }

    /**
     * Checks whether the given asset code matches the asset code of the provided CountrySP object.
     *
     * @param assetCode the asset code to check
     * @param countryDTO the CountrySP object to validate
     * @return true if the asset code is null, empty, or matches the country's asset code; false otherwise
     */
    private boolean checkAssetCode(String assetCode, CountrySP countryDTO) {
        return Objects.isNull(assetCode)
                || assetCode.isEmpty()
                || (Objects.nonNull(countryDTO.getAssetCode()) && countryDTO.getAssetCode().equals(assetCode));
    }
}
