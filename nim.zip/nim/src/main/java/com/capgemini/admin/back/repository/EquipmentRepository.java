package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.admin.back.model.Equipment;


@Repository
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {

    public Optional<Equipment> findByName(@Param("name") String name);

    public List<Equipment> findAllByOrderByNameAsc();

    @Modifying
    @Transactional
    @Query(value = "UPDATE poi_equipment SET name = :name, title_en = :titleEn, title_fr = :titleFr WHERE id = :equipmentId", nativeQuery = true)
    int updateEquipmentCoreFields(
            @Param("equipmentId") Long equipmentId,
            @Param("name") String name,
            @Param("titleEn") String titleEn,
            @Param("titleFr") String titleFr);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO poi_equipment (name, title_en, title_fr) VALUES (:name, :titleEn, :titleFr)", nativeQuery = true)
    int insertEquipmentCoreFields(
            @Param("name") String name,
            @Param("titleEn") String titleEn,
            @Param("titleFr") String titleFr);
}
