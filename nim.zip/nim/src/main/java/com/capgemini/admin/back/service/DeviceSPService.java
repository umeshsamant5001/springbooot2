package com.capgemini.admin.back.service;

import com.capgemini.admin.back.model.DeviceSP;
import com.capgemini.admin.back.model.SubLevelEnum;
import com.capgemini.admin.back.repository.DeviceSPRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DeviceSPService {

    @Autowired
    private DeviceSPRepository deviceSPRepository;

    @Autowired
    private TreeService treeService;
    
    /**
     * Retrieves all DeviceSP entries for a specific building ID using a stored procedure.
     *
     * @param searchString the search keyword to filter devices
     * @param buildingId the ID of the building to filter devices by
     * @return a list of DeviceSP objects matching the criteria
     */
    public List<DeviceSP> getAllDeviceSPByBuildingId(String searchString, int buildingId) {
        return this.deviceSPRepository.SO_GetDeviceInfo(searchString, buildingId, 0);
    }
   
    /**
     * Retrieves all DeviceSP entries across all buildings using a stored procedure.
     *
     * @param searchString the search keyword to filter devices
     * @return a list of all DeviceSP objects matching the search criteria
     */
    public List<DeviceSP> getAllDeviceSP(String searchString) {
        return this.deviceSPRepository.SO_GetDeviceInfo(searchString, 0, 1);
    }
   
    /**
     * Filters a list of DeviceSP objects based on user access permissions using the site tree.
     * Only devices that the user is authorized to access are returned.
     *
     * @param deviceSPs the list of DeviceSP objects to filter
     * @return a filtered list of DeviceSP objects the user has access to
     */
    public List<DeviceSP> filterDeviceSP(List<DeviceSP> deviceSPs) {
        List<String> uuidList = deviceSPs.stream()
                .map(DeviceSP::getUuid)
                .collect(Collectors.toList());

        List<String> filteredUuidList = this.treeService.filterId(SubLevelEnum.DEVICE, uuidList);

        return deviceSPs
                .stream()
                .filter(device -> filteredUuidList.contains(device.getUuid()))
                .collect(Collectors.toList());
    }
}