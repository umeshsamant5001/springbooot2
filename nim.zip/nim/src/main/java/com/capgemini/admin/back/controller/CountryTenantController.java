package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.CountryTenant;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.repository.CountryRepository;
import com.capgemini.admin.back.repository.CountryTenantRepository;
import com.capgemini.admin.back.service.CountryTenantService;
import com.capgemini.admin.back.service.TreeService;






@Slf4j
@RestController
@RequestMapping("/api/country-tenants")
public class CountryTenantController {

    @Autowired
    private CountryTenantRepository countryTenantRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private TreeService treeService;

    @Autowired
    private CountryTenantService countryTenantService;


    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    public static class CountryTenantCountryRequest {
        @NotNull
        @Min(1)
        private Long id;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    public static class CountryTenantRequest {
        @NotNull
        @Valid
        private CountryTenantCountryRequest country;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String tenant;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String username;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String password;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String basic;

        public CountryTenantCountryRequest getCountry() {
            return country;
        }

        public void setCountry(CountryTenantCountryRequest country) {
            this.country = country;
        }

        public String getTenant() {
            return tenant;
        }

        public void setTenant(String tenant) {
            this.tenant = tenant;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getBasic() {
            return basic;
        }

        public void setBasic(String basic) {
            this.basic = basic;
        }
    }

    private static class CountryTenantWriteData {
        private final Long countryId;
        private final String tenant;
        private final String username;
        private final String password;
        private final String basic;

        private CountryTenantWriteData(Long countryId, String tenant, String username, String password, String basic) {
            this.countryId = Objects.isNull(countryId) ? null : Long.valueOf(String.valueOf(countryId));
            this.tenant = Objects.isNull(tenant) ? null : new String(String.valueOf(tenant));
            this.username = Objects.isNull(username) ? null : new String(String.valueOf(username));
            this.password = Objects.isNull(password) ? null : new String(String.valueOf(password));
            this.basic = Objects.isNull(basic) ? null : new String(String.valueOf(basic));
        }

        public Long getCountryId() {
            return Objects.isNull(countryId) ? null : Long.valueOf(String.valueOf(countryId));
        }

        public String getTenant() {
            return Objects.isNull(tenant) ? null : new String(String.valueOf(tenant));
        }

        public String getUsername() {
            return Objects.isNull(username) ? null : new String(String.valueOf(username));
        }

        public String getPassword() {
            return Objects.isNull(password) ? null : new String(String.valueOf(password));
        }

        public String getBasic() {
            return Objects.isNull(basic) ? null : new String(String.valueOf(basic));
        }
    }



    public static class CountryTenantCountryResponse {
        private Long id;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
    }

    public static class CountryTenantResponse {

        private Long id;
        private CountryTenantCountryResponse country;
        private String tenant;
        private String username;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public CountryTenantCountryResponse getCountry() {
            return country;
        }

        public void setCountry(CountryTenantCountryResponse country) {
            this.country = country;
        }

        public String getTenant() {
            return tenant;
        }

        public void setTenant(String tenant) {
            this.tenant = tenant;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }


    private Optional<Country> resolveAuthorizedCountry(CountryTenantCountryRequest requestedCountry) {
        if (Objects.isNull(requestedCountry)
                || Objects.isNull(requestedCountry.getId())
                || requestedCountry.getId() <= 0) {
            return Optional.empty();
        }

        Long requestedCountryId = Long.valueOf(requestedCountry.getId());
        List<Long> authorizedCountryIds = treeService.filterId(LevelEnum.COUNTRY, List.of(requestedCountryId));
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return Optional.empty();
        }

        Long authorizedCountryId = Long.valueOf(authorizedCountryIds.get(0));
        try {
            return countryRepository.findById(authorizedCountryId);
        } catch (DataAccessException ex) {
            log.error("Failed to resolve authorized country for countryId {}", authorizedCountryId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to resolve authorized country.");
        }

    }


    private List<Long> resolveAuthorizedCountryIds() {
        try {
            List<Long> allCountryIds = countryRepository.findAll().stream()
                    .map(Country::getId)
                    .filter(Objects::nonNull)
                    .map(countryId -> Long.valueOf(countryId))
                    .collect(Collectors.toList());

            if (CollectionUtils.isEmpty(allCountryIds)) {
                return List.of();
            }

            return treeService.filterId(LevelEnum.COUNTRY, allCountryIds);
        } catch (DataAccessException ex) {
            log.error("Failed to resolve authorized country ids", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to resolve authorized countries.");
        }
    }



    private CountryTenantWriteData toCountryTenantWriteData(CountryTenantRequest countryTenantRequest,
            Country authorizedCountry) {
        Long sanitizedCountryId = this.sanitizeAuthorizedCountryId(authorizedCountry);
        String sanitizedTenant = this.sanitizeCountryTenantText(countryTenantRequest.getTenant());
        String sanitizedUsername = this.sanitizeCountryTenantText(countryTenantRequest.getUsername());
        String sanitizedPassword = this.sanitizeCountryTenantText(countryTenantRequest.getPassword());
        String sanitizedBasic = this.sanitizeCountryTenantText(countryTenantRequest.getBasic());

        return new CountryTenantWriteData(
                Long.valueOf(sanitizedCountryId),
                this.copySanitizedText(sanitizedTenant),
                this.copySanitizedText(sanitizedUsername),
                this.copySanitizedText(sanitizedPassword),
                this.copySanitizedText(sanitizedBasic));

    }

    private Long sanitizeAuthorizedCountryId(Country authorizedCountry) {
        if (Objects.isNull(authorizedCountry)
                || Objects.isNull(authorizedCountry.getId())
                || authorizedCountry.getId() <= 0) {
            throw new IllegalArgumentException("Invalid country input");
        }

        return Long.valueOf(authorizedCountry.getId());
    }


    private String sanitizeCountryTenantText(String value) {
        if (Objects.isNull(value)) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        return new String(validated);
    }

    private String copySanitizedText(String value) {
        if (Objects.isNull(value)) {
            return null;
        }

        return new String(String.valueOf(value));
    }



    private CountryTenantCountryResponse toCountryTenantCountryResponse(Country country) {
        if (Objects.isNull(country) || Objects.isNull(country.getId())) {
            return null;
        }

        CountryTenantCountryResponse countryResponse = new CountryTenantCountryResponse();
        countryResponse.setId(Long.valueOf(String.valueOf(country.getId())));
        return countryResponse;
    }

    private CountryTenantResponse toCountryTenantResponse(CountryTenant countryTenant) {
        CountryTenantResponse response = new CountryTenantResponse();
        response.setId(Objects.isNull(countryTenant.getId()) ? null : Long.valueOf(String.valueOf(countryTenant.getId())));
        response.setCountry(this.toCountryTenantCountryResponse(countryTenant.getCountry()));
        response.setTenant(Objects.nonNull(countryTenant.getTenant()) ? new String(countryTenant.getTenant()) : null);
        response.setUsername(
                Objects.nonNull(countryTenant.getUsername()) ? new String(countryTenant.getUsername()) : null);
        return response;
    }

    private CountryTenantResponse buildCountryTenantResponse(Long tenantId, Country authorizedCountry,
            String tenant, String username) {
        if (Objects.isNull(tenantId) || tenantId <= 0 || Objects.isNull(authorizedCountry)
                || Objects.isNull(authorizedCountry.getId())) {
            throw new IllegalArgumentException("Invalid country tenant response input");
        }

        CountryTenantResponse response = new CountryTenantResponse();
        response.setId(Long.valueOf(String.valueOf(tenantId)));
        response.setCountry(this.toCountryTenantCountryResponse(authorizedCountry));
        response.setTenant(this.copySanitizedText(tenant));
        response.setUsername(this.copySanitizedText(username));
        return response;
    }





    /**
     * Retrieves all country tenant records from the database.
     *
     * This endpoint returns a complete list of CountryTenant entities
     * without any filtering or pagination.
     *
     * @return a list of all CountryTenant objects
     */
    @GetMapping
    public List<CountryTenant> getAllCountryTenants() {
        try {
            return countryTenantRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to fetch country tenants", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch country tenants.");
        }
    }


    /**
     * Retrieves a specific CountryTenant record by its ID.
     *
     * This endpoint looks up a CountryTenant entity using the provided ID.
     * If found, it returns the entity with HTTP 200 status; otherwise, it returns
     * HTTP 404 Not Found.
     *
     * @param id the ID of the CountryTenant to retrieve
     * @return ResponseEntity containing the CountryTenant object if found,
     *         or HTTP 404 Not Found if no matching record exists
     */
    @GetMapping("/{id}")
    public ResponseEntity<CountryTenantResponse> getCountryTenantById(@PathVariable Long id) {
        if (Objects.isNull(id) || id <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCountryIds = this.resolveAuthorizedCountryIds();
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long requestedTenantId = Long.valueOf(id);
        Optional<CountryTenant> countryTenant = countryTenantRepository.findByIdAndCountryIdIn(
                requestedTenantId,
                authorizedCountryIds);
        return countryTenant.map(tenant -> ResponseEntity.ok(this.toCountryTenantResponse(tenant)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }



  
    /**
     * Creates a new CountryTenant record.
     *
     * This endpoint accepts a CountryTenant object in the request body and saves it
     * to the database. It returns the persisted entity after successful creation.
     *
     * @param countryTenant the CountryTenant object to be created
     * @return the saved CountryTenant entity
     */
    @PostMapping
    public ResponseEntity<CountryTenantResponse> createCountryTenant(@Valid @RequestBody CountryTenantRequest countryTenant) {
        Optional<Country> authorizedCountry = resolveAuthorizedCountry(countryTenant.getCountry());
        if (authorizedCountry.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        CountryTenantWriteData sanitizedCountryTenant = this.toCountryTenantWriteData(countryTenant, authorizedCountry.get());
        Long savedCountryTenantId = countryTenantService.createCountryTenant(
                Long.valueOf(String.valueOf(sanitizedCountryTenant.getCountryId())),
                this.copySanitizedText(sanitizedCountryTenant.getTenant()),
                this.copySanitizedText(sanitizedCountryTenant.getUsername()),
                this.copySanitizedText(sanitizedCountryTenant.getPassword()),
                this.copySanitizedText(sanitizedCountryTenant.getBasic()));




        return ResponseEntity.ok(this.buildCountryTenantResponse(savedCountryTenantId, authorizedCountry.get(),
                sanitizedCountryTenant.getTenant(), sanitizedCountryTenant.getUsername()));




    }



    
    /**
     * Updates an existing CountryTenant record identified by its ID.
     *
     * This endpoint retrieves the existing CountryTenant entity and updates its fields
     * with the values provided in the request body. If the entity is found and updated,
     * it returns the updated object with HTTP 200 status. If not found, it returns
     * HTTP 404 Not Found.
     *
     * @param id the ID of the CountryTenant to update
     * @param updatedTenant the CountryTenant object containing updated field values
     * @return ResponseEntity containing the updated CountryTenant object if found,
     *         or HTTP 404 Not Found if no matching record exists
     */
    @PutMapping("/{id}")
    public ResponseEntity<CountryTenantResponse> updateCountryTenant(@PathVariable Long id,
            @Valid @RequestBody CountryTenantRequest updatedTenant) {

        if (Objects.isNull(id) || id <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCountryIds = this.resolveAuthorizedCountryIds();
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Optional<Country> authorizedCountry = resolveAuthorizedCountry(updatedTenant.getCountry());
        if (authorizedCountry.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long requestedTenantId = Long.valueOf(id);
        CountryTenantWriteData sanitizedUpdatedTenant = this.toCountryTenantWriteData(updatedTenant, authorizedCountry.get());

        return countryTenantRepository.findByIdAndCountryIdIn(requestedTenantId, authorizedCountryIds).map(existingTenant -> {
            Long savedTenantId = countryTenantService.updateCountryTenant(
                    existingTenant,
                    Long.valueOf(String.valueOf(sanitizedUpdatedTenant.getCountryId())),
                    this.copySanitizedText(sanitizedUpdatedTenant.getTenant()),
                    this.copySanitizedText(sanitizedUpdatedTenant.getUsername()),
                    this.copySanitizedText(sanitizedUpdatedTenant.getPassword()),
                    this.copySanitizedText(sanitizedUpdatedTenant.getBasic()));




            return ResponseEntity.ok(this.buildCountryTenantResponse(savedTenantId, authorizedCountry.get(),
                    sanitizedUpdatedTenant.getTenant(), sanitizedUpdatedTenant.getUsername()));

        }).orElseGet(() -> ResponseEntity.notFound().build());




    }




    /**
     * Deletes a CountryTenant record identified by its ID.
     *
     * This endpoint checks if the CountryTenant exists and deletes it if found.
     * Returns HTTP 204 No Content upon successful deletion, or HTTP 404 Not Found
     * if the record does not exist.
     *
     * @param id the ID of the CountryTenant to delete
     * @return ResponseEntity with HTTP 204 No Content if deletion is successful,
     *         or HTTP 404 Not Found if no matching record exists
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCountryTenant(@PathVariable Long id) {
        if (Objects.isNull(id) || id <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCountryIds = this.resolveAuthorizedCountryIds();
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long requestedTenantId = Long.valueOf(id);
        Optional<CountryTenant> existingTenant = countryTenantRepository.findByIdAndCountryIdIn(
                requestedTenantId,
                authorizedCountryIds);
        if (existingTenant.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        countryTenantRepository.delete(existingTenant.get());
        return ResponseEntity.noContent().build();
    }


}
