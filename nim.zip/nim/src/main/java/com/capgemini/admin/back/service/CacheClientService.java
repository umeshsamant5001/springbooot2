package com.capgemini.admin.back.service;

import java.nio.charset.StandardCharsets;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.util.Base64;

import com.capgemini.admin.back.config.ApplicationProperties;

import lombok.extern.slf4j.Slf4j;

/*
 * 
 * This class uses a configured REST endpoint to trigger cache invalidation,
 * particularly for building-related data. It retrieves configuration from
 * {@link ApplicationProperties} and uses basic authentication for the request.
 */

@Service
@Slf4j
public class CacheClientService {

    private final RestTemplate restTemplate;
    private final ApplicationProperties applicationProperties;

    /*
     * Constructs a new CacheClient with the required dependencies.
     *
     * @param restTemplate   the RestTemplate used to make HTTP
     * requests
     * 
     * @param applicationProperties  the application configuration properties
     * 
     */
    public CacheClientService(RestTemplate restTemplate, ApplicationProperties applicationProperties) {
        this.restTemplate = restTemplate;
        this.applicationProperties = applicationProperties;
    }

    /*
     * Logs the configured cache clear URL after the bean is initialized.
     * Useful for debugging and verifying configuration.
     * 
     */

    @PostConstruct
    public void debugConfig() {
        log.info("Using Cache URL: " + applicationProperties.getCache().getClear().getUrl());
    }

    /*
     * Sends a DELETE request to the configured cache-clearing endpoint
     * to invalidate building-related cache entries.
     *
     * Uses basic authentication with credentials from configuration.
     * Logs the result or any error encountered during the process.
     * 
     */
    public void clearBuildingsCache() {
        try {
            var cacheProps = applicationProperties.getCache().getClear();
            String auth = Base64.getEncoder().encodeToString(
                    (cacheProps.getUsername() + ":" + cacheProps.getPassword()).getBytes(StandardCharsets.UTF_8));
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Basic " + auth);
            headers.set("Ocp-Apim-Subscription-Key", cacheProps.getSubscriptionKey());
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> entity = new HttpEntity<>(headers);

            log.info("Calling cacheClearUrl at: {}", cacheProps.getUrl());

            ResponseEntity<String> response = restTemplate.exchange(
                    cacheProps.getUrl(),
                    HttpMethod.DELETE,
                    entity,
                    String.class);

            log.info("Cache cleared: {}", response.getBody());
        } catch (Exception e) {
            log.error("Failed to clear cache: {}", e.getMessage(), e);
        }
    }

}