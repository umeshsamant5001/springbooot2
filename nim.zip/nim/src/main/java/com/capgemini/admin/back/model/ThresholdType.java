package com.capgemini.admin.back.model;

public enum ThresholdType {
    CO2, TEMPERATURE;
}
