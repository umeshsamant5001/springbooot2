package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class DeclareIssueBuildingDetailsDTO {
    private Long id;
    private Long declareIssueId;
    private Long buildingId;
    private String emailId;
    private Long modifiedAt;
    private Long createdAt;
    private DeclareIssueDTO declareIssue;
}
