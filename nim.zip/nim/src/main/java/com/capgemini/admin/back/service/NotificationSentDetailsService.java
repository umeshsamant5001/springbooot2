
package com.capgemini.admin.back.service;

import java.time.LocalDateTime;

import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.NotificationSentDetails;
import com.capgemini.admin.back.repository.NotificationSentDetailsRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NotificationSentDetailsService {

    private final NotificationSentDetailsRepository repository;

    public boolean alreadySent(Long notificationId, String token) {
        return repository.existsByNotificationIdAndTokenAndIsSentTrue(notificationId, token);
    }

    public void markSuccess(Long notificationId, String token) {

        // ✅ Create object manually
        NotificationSentDetails log = new NotificationSentDetails();
        log.setNotificationId(notificationId);
        log.setToken(token);
        log.setIsSent(true);
        log.setSentAt(LocalDateTime.now());

        try {
            repository.save(log);
        } catch (Exception e) {
            // Unique constraint violation safe-guard
        }
    }

    public void markFailure(Long notificationId, String token) {

        // ✅ Create object manually
        NotificationSentDetails log = new NotificationSentDetails();
        log.setNotificationId(notificationId);
        log.setToken(token);
        log.setIsSent(false);

        try {
            repository.save(log);
        } catch (Exception e) {
            // ignore duplicate insert
        }
    }

    public void cleanupSuccess(Long notificationId) {
        repository.deleteAll(
                repository.findByNotificationId(notificationId)
                        .stream()
                        .filter(NotificationSentDetails::getIsSent)
                        .collect(Collectors.toList()));

    }
}