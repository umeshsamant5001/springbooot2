package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class TabletImportAuditDTO {
    private Long id;
    private String poiName;
    private String oldValue;
    private String newValue;
    private Long activityDateTime;
    private String action;
    private String email;
}
