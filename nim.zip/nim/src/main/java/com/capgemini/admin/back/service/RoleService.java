package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.capgemini.admin.back.model.EnumAccess;
import com.capgemini.admin.back.model.FeatureAccess;
import com.capgemini.admin.back.model.FrontPage;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.dao.DataAccessException;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.admin.back.mapper.RoleMapper;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.model.RoleDTO;
import com.capgemini.admin.back.repository.RoleRepository;
import com.capgemini.admin.back.web.rest.errors.BadRequestAlertException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private FrontPageService frontPageService;

    static final String HOME_FEATURES = "Home";
    static final String LANGUAGE_FEATURES = "Language";
    static final String ROLE_FEATURES = "Role";
    static final String LOGOUT_FEATURES = "Logout";
    static final String PREFERENCES_FEATURES = "Preferences";

    /**
     * Converts a list of Role entities to a list of RoleDTOs.
     *
     * @return A function to perform the conversion.
     */
    public List<RoleDTO> listRoleToRoleDTOList(List<Role> roles, String language) {
        return roles.stream().map(role -> toRoleDTO(role, language)).collect(Collectors.toList());
    }

    /**
     * Converts a Role entity to a RoleDTO.
     *
     * @return A function to perform the conversion.
     */
    public RoleDTO toRoleDTO(Role role, String language) {
        return RoleMapper.INSTANCE.roleToRoleDTO(role, language);
    }

    /**
     * Retrieves all roles with optional feature details.
     *
     * @param withFeature Flag to include features in the response.
     * @return List of roles with or without features based on the flag.
     */
    @Transactional
    public List<Role> getAllRole(Boolean withFeature) {
        log.info("getAllRole called with withFeature={}", withFeature);
        try {
            List<Role> roles = this.roleRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));
            if (CollectionUtils.isEmpty(roles)) {
                log.info("getAllRole returned empty role list");
                return new ArrayList<Role>();
            }
            if (Boolean.TRUE.equals(withFeature)) {
                roles.forEach(role -> {
                    log.debug("initializing featureAccesses for role id={}", role.getId());
                    Hibernate.initialize(role.getFeatureAccesses());
                });
            }
            log.info("getAllRole returning {} roles, withFeature={}", roles.size(), withFeature);
            return roles;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve all roles withFeature={}", withFeature, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve roles.", ex);
        }
    }

    /**
     * Retrieves a role by its ID with optional feature details.
     *
     * @param id          The ID of the role.
     * @param withFeature Flag to include features in the response.
     * @return The role with or without features based on the flag.
     */
    @Transactional
    public Role getRoleById(Long id, Boolean withFeature) {
        try {
            Role role = this.roleRepository.findById(id).orElse(null);
            if (Objects.isNull(role)) {
                return null;
            }
            if (Boolean.TRUE.equals(withFeature)) {
                Hibernate.initialize(role.getFeatureAccesses());
            }
            return role;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve role by id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve role.");
        }
    }


    /**
     * Creates a new role based on the provided RoleDTO.
     *
     * @param roleDTO The RoleDTO representing the new role.
     * @return The created role with features.
     */
    @Transactional
    public Role createRole(RoleDTO roleDTO) throws BadRequestAlertException {
        log.info("createRole called with name={}, precedence={}, isActive={}, isWebUserProfile={}",
                roleDTO.getName(), roleDTO.getPrecedence(), roleDTO.getIsActive(), roleDTO.getIsWebUserProfile());
        log.info("createRole featureAccessCount={}", roleDTO.getFeatureAccesses() != null ? roleDTO.getFeatureAccesses().size() : 0);
        if (roleDTO.getFeatureAccesses() != null) {
            for (int i = 0; i < roleDTO.getFeatureAccesses().size(); i++) {
                var featureAccess = roleDTO.getFeatureAccesses().get(i);
                log.info("createRole featureAccess[{}] isNull={}, frontPageIsNull={}, frontPageId={}, access={}, isActive={}",
                        i,
                        featureAccess == null,
                        featureAccess != null ? featureAccess.getFrontPage() == null : null,
                        featureAccess != null && featureAccess.getFrontPage() != null
                                ? featureAccess.getFrontPage().getId()
                                : null,
                        featureAccess != null ? featureAccess.getAccess() : null,
                        featureAccess != null ? featureAccess.getIsActive() : null);
            }
        }

        List<Role> rolesByName = this.roleRepository.findAllByName(roleDTO.getName());
        if (!rolesByName.isEmpty()) {
            log.warn("createRole duplicate role name found: {}", roleDTO.getName());
            throw new BadRequestAlertException("Profile with same name already exists", "Role", "name");
        }

        List<Role> rolesByPrecedence = this.roleRepository.findAllByPrecedence(roleDTO.getPrecedence());
        if (!rolesByPrecedence.isEmpty()) {
            log.warn("createRole duplicate role precedence found: {}", roleDTO.getPrecedence());
            throw new BadRequestAlertException(
                    "Precedence value is duplicate with User Profile " + rolesByPrecedence.get(0).getName(), "Role",
                    "precedence");
        }

        Role role = RoleMapper.INSTANCE.roleDTOToRole(roleDTO);

        role.setName(sanitizeRequiredText(roleDTO.getName(), "Role name is required."));
        role.setPrecedence(sanitizeRequiredLong(roleDTO.getPrecedence(), "Role precedence is required."));
        role.setIsActive(roleDTO.getIsActive() == null ? null : Boolean.valueOf(roleDTO.getIsActive()));
        role.setIsWebUserProfile(roleDTO.getIsWebUserProfile() == null
                ? null
                : Boolean.valueOf(roleDTO.getIsWebUserProfile()));

        log.debug("createRole mapped Role entity: id={}, name={}, isActive={}, isWebUserProfile={}",
                role.getId(), role.getName(), role.getIsActive(), role.getIsWebUserProfile());

        List<FeatureAccess> featureAccessesDB = new ArrayList<>();

        role.getFeatureAccesses().stream().forEach(feature -> {
            featureAccessesDB.add(feature);
        });

        // Features to be hidden from features list while creating new User Profiles by
        // default
        List<String> listOfHiddenTitle = Arrays.asList(HOME_FEATURES, LANGUAGE_FEATURES,
                ROLE_FEATURES, LOGOUT_FEATURES, PREFERENCES_FEATURES);

        listOfHiddenTitle.stream().forEach(hiddenFeaturesTitile -> {
            FrontPage frontPage = this.frontPageService.getIdByTitles(hiddenFeaturesTitile);
            FeatureAccess newFeatureAccess = new FeatureAccess();

            if (!frontPage.getTitle().equals(HOME_FEATURES)) {
                newFeatureAccess.setFrontPage(frontPage);
                newFeatureAccess.setAccess(EnumAccess.WRITE);
                newFeatureAccess.setIsActive(false);
            } else {
                newFeatureAccess.setFrontPage(frontPage);
                newFeatureAccess.setAccess(EnumAccess.READ);
                newFeatureAccess.setIsActive(false);
            }

            featureAccessesDB.add(newFeatureAccess);
        });

        role.setFeatureAccesses(featureAccessesDB);
        log.debug("createRole final featureAccesses count={} for role {}", featureAccessesDB.size(), role.getName());

        Role savedRole = this.roleRepository.save(role);
        Hibernate.initialize(savedRole.getFeatureAccesses());
        log.info("createRole saved role id={} name={} with {} featureAccess entries", savedRole.getId(),
                savedRole.getName(), savedRole.getFeatureAccesses() != null ? savedRole.getFeatureAccesses().size() : 0);

        return savedRole;
    }

    /**
     * Updates an existing role based on the provided RoleDTO.
     *
     * @param oldRole The existing role to be updated.
     * @param roleDTO The RoleDTO representing the updated role.
     * @return The updated role with features.
     * @throws BadRequestAlertException
     */
    @Transactional
    public Role updateRole(Role oldRole, RoleDTO roleDTO) throws BadRequestAlertException {
        List<Role> rolesByName = this.roleRepository.findAllByName(roleDTO.getName());
        if (rolesByName.size() > 1
                || rolesByName.size() == 1 && !rolesByName.get(0).getId().equals(roleDTO.getId())) {
            throw new BadRequestAlertException("Profile with same name already exists", "Role", "name");
        }

        List<Role> rolesByPrecedence = this.roleRepository.findAllByPrecedence(roleDTO.getPrecedence());
        if (rolesByPrecedence.size() > 1
                || rolesByPrecedence.size() == 1 && !rolesByPrecedence.get(0).getId().equals(roleDTO.getId())) {
            throw new BadRequestAlertException(
                    "Precedence value is duplicate with User Profile " + rolesByPrecedence.get(0).getName(), "Role",
                    "precedence");
        }

        Role newRole = RoleMapper.INSTANCE.roleDTOToRole(roleDTO);

        oldRole.setName(sanitizeRequiredText(newRole.getName(), "Role name is required."));
        oldRole.setPrecedence(sanitizeRequiredLong(newRole.getPrecedence(), "Role precedence is required."));
        oldRole.setIsActive(newRole.getIsActive() == null ? null : Boolean.valueOf(newRole.getIsActive()));
        oldRole.setFeatureAccesses(newRole.getFeatureAccesses());
        oldRole.setIsWebUserProfile(newRole.getIsWebUserProfile() == null
                ? null
                : Boolean.valueOf(newRole.getIsWebUserProfile()));


        Role savedRole = this.roleRepository.save(oldRole);
        Hibernate.initialize(savedRole.getFeatureAccesses());

        return savedRole;
    }

    /**
     * Deletes a role by its ID.
     *
     * @param id The ID of the role to be deleted.
     */
    public void deleteRole(Long id) {
        this.roleRepository.deleteById(id);
    }

    public List<Role> getAllRoles() {
        try {
            return roleRepository.findAll();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve all roles", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve roles.");
        }
    }


    private String sanitizeRequiredText(String value, String requiredMessage) {
        if (value == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, requiredMessage);
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, requiredMessage);
        }
        return new String(trimmed);
    }

    private Long sanitizeRequiredLong(Long value, String requiredMessage) {
        if (value == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, requiredMessage);
        }
        return Long.valueOf(value);
    }

}