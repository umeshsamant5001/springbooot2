package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.Alert;
import com.capgemini.admin.back.model.AlertDTO;

@Mapper(config = DtoMapperConfig.class)
public interface AlertMapper {

    AlertMapper INSTANCE = Mappers.getMapper(AlertMapper.class);

    Alert AlertDTOToAlert(AlertDTO in);

    @Mapping(target = "thresholdConfigurationId", source = "thresholdConfiguration.id")
    AlertDTO AlertToAlertDTO(Alert in);

}
