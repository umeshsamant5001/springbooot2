package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.admin.back.model.FacilityManager;

public interface FacilityManagerRepository extends JpaRepository<FacilityManager, String> {

    static final String FACILITY_MANAGER = "'Facility Manager'";

    @Query(value = "Select d.uuid, p.name, f.title_en AS title_en_floor, b.title_en AS title_en_building, urloc.level, u.email\r\n"
            + //
            "from \r\n" + //
            "device d inner join poi p on p.name = d.poi_name\r\n" + //
            "inner join floor f on p.floor_id = f.id\r\n" + //
            "inner join building b on f.building_id = b.id\r\n" + //
            "inner join [dbo].[user_role_location] urloc on urloc.cdm_key_id = b.cdm_key_id\r\n" + //
            "inner join role r on r.id = urloc.role_id\r\n" + //
            "inner join users u on u.id = urloc.user_id\r\n" + //
            "where r.name = " +
            FACILITY_MANAGER +
            " and level = 'BUILDING' and d.uuid = :uuid and u.subscribe_alert = 1\r\n" + //
            "UNION\r\n" + //
            "Select d.uuid, p.name, f.title_en AS title_en_floor, b.title_en AS title_en_building, urloc.level, u.email\r\n"
            + //
            "from \r\n" + //
            "device d inner join poi p on p.name = d.poi_name\r\n" + //
            "inner join floor f on p.floor_id = f.id\r\n" + //
            "inner join building b on f.building_id = b.id\r\n" + //
            "inner join site s on b.site_id = s.id\r\n" + //
            "inner join [dbo].[user_role_location] urloc on urloc.cdm_key_id = s.cdm_key_id\r\n" + //
            "inner join role r on r.id = urloc.role_id\r\n" + //
            "inner join users u on u.id = urloc.user_id\r\n" + //
            "where r.name = " +
            FACILITY_MANAGER +
            " and level = 'SITE' and d.uuid = :uuid and u.subscribe_alert = 1\r\n" + //
            "UNION\r\n" + //
            "Select d.uuid, p.name, f.title_en AS title_en_floor, b.title_en AS title_en_building, urloc.level, u.email\r\n"
            + //
            "from \r\n" + //
            "device d inner join poi p on p.name = d.poi_name\r\n" + //
            "inner join floor f on p.floor_id = f.id\r\n" + //
            "inner join building b on f.building_id = b.id\r\n" + //
            "inner join site s on b.site_id = s.id\r\n" + //
            "inner join city c on s.city_id = c.id\r\n" + //
            "inner join [dbo].[user_role_location] urloc on urloc.cdm_key_id = c.cdm_key_id\r\n" + //
            "inner join role r on r.id = urloc.role_id\r\n" + //
            "inner join users u on u.id = urloc.user_id\r\n" + //
            "where r.name = " +
            FACILITY_MANAGER +
            " and level = 'CITY' and d.uuid = :uuid and u.subscribe_alert = 1\r\n" + //
            "UNION\r\n" + //
            "Select d.uuid, p.name, f.title_en AS title_en_floor, b.title_en AS title_en_building, urloc.level, u.email\r\n"
            + //
            "from \r\n" + //
            "device d inner join poi p on p.name = d.poi_name\r\n" + //
            "inner join floor f on p.floor_id = f.id\r\n" + //
            "inner join building b on f.building_id = b.id\r\n" + //
            "inner join site s on b.site_id = s.id\r\n" + //
            "inner join city c on s.city_id = c.id\r\n" + //
            "inner join country co on c.country_id = co.id\r\n" + //
            "inner join [dbo].[user_role_location] urloc on urloc.cdm_key_id = co.cdm_key_id\r\n" + //
            "inner join role r on r.id = urloc.role_id\r\n" + //
            "inner join users u on u.id = urloc.user_id\r\n" + //
            "where r.name = " +
            FACILITY_MANAGER +
            " and level = 'COUNTRY' and d.uuid = :uuid and u.subscribe_alert = 1", nativeQuery = true)
    public List<FacilityManager> getFacilityManagers(@Param("uuid") String uuid);
}
