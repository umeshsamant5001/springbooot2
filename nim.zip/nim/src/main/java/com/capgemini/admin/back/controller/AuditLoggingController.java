package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.Objects;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.mapper.AuditLoggingMapper;
import com.capgemini.admin.back.model.AuditLogging;
import com.capgemini.admin.back.model.AuditLoggingDTO;
import com.capgemini.admin.back.model.EnumAuditType;
import com.capgemini.admin.back.service.AuditLoggingService;
import com.capgemini.admin.back.service.AuditLoggingService.AuditLoggingUpsertInput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import lombok.Data;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@RestController
@RequestMapping(value = AuditLoggingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class AuditLoggingController {

	static final String ROOT_API = "api/auditlogging";
	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	@JsonIgnoreProperties(ignoreUnknown = false)
	@Data
	private static class AuditLoggingCreateInput {
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String moduleName;
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String activity;
		@Size(max = 10000)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String previousData;
		@Size(max = 10000)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String currentData;
		@Min(0)
		private Long activityDate;
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String platform;
		private EnumAuditType auditType;
	}

	@Autowired
	private AuditLoggingService auditloggingService;


	/**
	 * Handles HTTP GET requests to retrieve all audit logging records.
	 * 
	 * This endpoint returns a list of {@link AuditLoggingDTO} objects representing
	 * audit log entries. It supports localization through the "Accept-Language"
	 * header.
	 *
	 * @param language the language preference from the "Accept-Language" request
	 *                 header;
	 *                 defaults to "en" if not provided.
	 * @return a {@link ResponseEntity} containing a list of {@link AuditLoggingDTO}
	 *         objects.
	 */
	@GetMapping
	public ResponseEntity<List<AuditLoggingDTO>> getAll(
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
		return ResponseEntity
				.ok(auditloggingService.auditloggingListToAuditLoggingDTOList().apply(auditloggingService.getAll()));
	}

	/**
	 * Handles HTTP POST requests to create a new audit logging record.
	 * 
	 * This endpoint accepts an {@link AuditLoggingDTO} object in the request body,
	 * converts it to an entity, and persists it using the audit logging service.
	 * It supports localization via the "Accept-Language" header.
	 *
	 * If the input DTO is invalid or cannot be converted, a 400 Bad Request
	 * response is returned.
	 * If the creation fails due to server-side issues, a 500 Internal Server Error
	 * is returned.
	 * On success, the newly created audit logging record is returned as a DTO.
	 *
	 * @param auditloggingDTO the audit logging data to be created, validated from
	 *                        the request body.
	 * @param language        the language preference from the "Accept-Language"
	 *                        request header;
	 *                        defaults to "en" if not provided.
	 * @return a {@link ResponseEntity} containing the created
	 *         {@link AuditLoggingDTO}, or an error response.
	 */
	@PostMapping
	public ResponseEntity<AuditLoggingDTO> createAuditLogging(
			@Valid @RequestBody AuditLoggingCreateInput auditloggingInput,
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

		if (Objects.isNull(auditloggingInput)) {
			return ResponseEntity.badRequest().build();
		}

		AuditLoggingUpsertInput safeAuditLoggingInput = this.toAuditLoggingInput(auditloggingInput);

		AuditLogging auditlogging = this.auditloggingService.createAuditLogging(safeAuditLoggingInput);



		if (Objects.isNull(auditlogging)) {
			return ResponseEntity.internalServerError().build();
		}

		AuditLoggingDTO newAuditLoggingDTO = AuditLoggingMapper.INSTANCE.auditloggingToAuditLoggingDTO(auditlogging);
		return ResponseEntity.ok(newAuditLoggingDTO);
	}

	private AuditLoggingUpsertInput toAuditLoggingInput(AuditLoggingCreateInput auditloggingInput) {
		return new AuditLoggingUpsertInput(
				auditloggingInput.getModuleName() == null
						? null
						: new String(String.valueOf(auditloggingInput.getModuleName())),
				auditloggingInput.getActivity() == null
						? null
						: new String(String.valueOf(auditloggingInput.getActivity())),
				auditloggingInput.getPreviousData() == null
						? null
						: new String(String.valueOf(auditloggingInput.getPreviousData())),
				auditloggingInput.getCurrentData() == null
						? null
						: new String(String.valueOf(auditloggingInput.getCurrentData())),
				auditloggingInput.getActivityDate() == null
						? null
						: Long.valueOf(String.valueOf(auditloggingInput.getActivityDate())),
				auditloggingInput.getPlatform() == null
						? null
						: new String(String.valueOf(auditloggingInput.getPlatform())),
				auditloggingInput.getAuditType() == null
						? null
						: EnumAuditType.valueOf(String.valueOf(auditloggingInput.getAuditType().name())));
	}

}