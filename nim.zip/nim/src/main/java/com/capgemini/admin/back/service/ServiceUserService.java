package com.capgemini.admin.back.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.capgemini.admin.back.model.ServiceUser;
import com.capgemini.admin.back.repository.ServiceUserRepository;

@org.springframework.stereotype.Service
public class ServiceUserService {

    @Autowired
    private ServiceUserRepository serviceUserRepository;

    /**
     * Retrieves all ServiceUser entries associated with a given service ID.
     *
     * @param serviceId The ID of the service.
     * @return List of ServiceUser entities.
     */
    public List<ServiceUser> getServiceById(Long serviceId) {
        return this.serviceUserRepository.findByServiceId(serviceId);
    }

    /**
     * Deletes a list of ServiceUser entities from the repository.
     *
     * @param serviceUsers The list of ServiceUser entities to delete.
     */
    public void deleteAll(List<ServiceUser> serviceUsers) {
        this.serviceUserRepository.deleteAll(serviceUsers);
    }
}
