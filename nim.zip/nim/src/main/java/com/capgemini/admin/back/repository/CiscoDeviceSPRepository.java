package com.capgemini.admin.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.CiscoDeviceSP;

@Repository
public interface CiscoDeviceSPRepository extends JpaRepository<CiscoDeviceSP, Long> {

    @Procedure(name = "SO_GetCiscoDeviceInfo")
    List<CiscoDeviceSP> SO_GetCiscoDeviceInfo(@Param("searchString") String searchString,
            @Param("buildingId") int buildingId,
            @Param("global") int global);
}
