package com.capgemini.admin.back.repository;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.City;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

	long countByCountryId(@Param("countryId") Long countryId);

	City findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	@Query("SELECT country.id as countryId, count(*) as nbCities FROM City city INNER JOIN city.country country GROUP BY country.id")
	List<Tuple> countByCountry();

	@Query("SELECT city.cdmKeyId, city.titleEn AS name FROM City city WHERE city.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);
}
