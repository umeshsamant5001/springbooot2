package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "master_attribute")
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class MasterAttribute {
    private static int MAX_VALUE_NUMBER = 35;

    @Id
    @Column(name = "name")
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "control_type")
    private EnumControlType controlType;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_type")
    private EnumDataType dataType;

    @Column(name = "length")
    private Integer length;

    // Mandatory attributes must be defined and can't be deleted
    @Column(name = "mandatory")
    private Boolean mandatory;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "master_attributes_values", joinColumns = @JoinColumn(name = "master_attributes_id"))
    @Cascade(CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @Column(name = "value")
    private List<String> controlValue = new ArrayList<>();

    public void setControlValue(List<String> controlValue) throws InvalidParameterException {
        // Limit the size of possible value to MAX_VALUE_NUMBER
        if (Objects.nonNull(controlValue) && controlValue.size() > MAX_VALUE_NUMBER) {
            throw new InvalidParameterException(
                    String.format("The ControlType can have %S values maximum.", MAX_VALUE_NUMBER));
        }

        this.controlValue = controlValue;
    }
}
