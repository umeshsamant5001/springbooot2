package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.AuditLogging;

@Repository
public interface AuditLoggingRepository extends JpaRepository<AuditLogging, Long> {

}
