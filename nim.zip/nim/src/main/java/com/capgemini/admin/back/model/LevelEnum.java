package com.capgemini.admin.back.model;

/**
 * Level for the basic tree
 */
public enum LevelEnum {
    GLOBAL(5),
    COUNTRY(4),
    CITY(3),
    SITE(2),
    BUILDING(1);

    private int idx;

    LevelEnum(int idx) {
        this.idx = idx;
    }

    public boolean isGreaterOrEqualsThan(LevelEnum other) {
        return this.idx >= other.idx;
    }
}
