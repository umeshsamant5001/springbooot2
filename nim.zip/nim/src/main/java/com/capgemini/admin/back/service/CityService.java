package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.repository.CityRepository;
import lombok.extern.slf4j.Slf4j;




import javax.persistence.Tuple;



@Service
@Slf4j
public class CityService {

	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	public static class CityUpsertInput {
		private final Long cdmKeyId;
		private final Map<String, String> attributes;
		private final String titleEn;
		private final String titleFr;
		private final Long cdmStateId;

		public CityUpsertInput(Long cdmKeyId, Map<String, String> attributes, String titleEn, String titleFr,
				Long cdmStateId) {
			this.cdmKeyId = cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
			Map<String, String> copiedAttributes = new HashMap<>();
			if (attributes != null) {
				attributes.forEach((key, value) -> {
					if (key != null && value != null) {
						copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
					}
				});
			}
			this.attributes = copiedAttributes;
			this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));
			this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
			this.cdmStateId = cdmStateId == null ? null : Long.valueOf(String.valueOf(cdmStateId));
		}

		public Long getCdmKeyId() {
			return cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
		}


		public Map<String, String> getAttributes() {
			Map<String, String> copiedAttributes = new HashMap<>();
			attributes.forEach((key, value) -> {
				if (key != null && value != null) {
					copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
				}
			});
			return copiedAttributes;
		}

		public String getTitleEn() {
			return titleEn == null ? null : new String(String.valueOf(titleEn));
		}

		public String getTitleFr() {
			return titleFr == null ? null : new String(String.valueOf(titleFr));
		}

		public Long getCdmStateId() {
			return cdmStateId == null ? null : Long.valueOf(String.valueOf(cdmStateId));
		}

	}


	@Autowired
	private CityRepository cityRepository;


	
    /**
     * Retrieves a City by its ID, including its associated sites.
     *
     * @param cityId the ID of the city to retrieve
     * @return the City object if found, otherwise null
     */
	@Transactional
	public City getCity(Long cityId) {
		try {
			City city = cityRepository.findById(cityId).orElse(null);
			if (Objects.nonNull(city)) {
				city.getSites();
			}
			return city;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve city with id {}.", cityId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve city.");
		}
	}

	
    /**
     * Updates an existing City entity with new values.
     *
     * @param cityId the ID of the city to update
     * @param cityInput the restricted validated input payload
     * @return the updated City object, or null if an exception occurs
     */
	public City updateCity(Long cityId, CityUpsertInput cityInput) {

		if (Objects.isNull(cityInput)) {
			return null;
		}

		City oldCity;
		try {
			oldCity = cityRepository.findById(cityId).orElseThrow();
		} catch (DataAccessException ex) {
			log.error("Failed to load city with id {} for update.", cityId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update city.");
		}

		if (Objects.isNull(oldCity)) {
			return null;
		}

		CityUpsertInput scopedCityInput = sanitizeCityUpsertInput(cityInput);

		Long validatedCdmKeyId = sanitizeOptionalNonNegativeLong(scopedCityInput.getCdmKeyId());
		Map<String, String> validatedAttributes = sanitizeAttributes(scopedCityInput.getAttributes());
		String validatedTitleEn = sanitizeOptionalText(scopedCityInput.getTitleEn(), 255);
		String validatedTitleFr = sanitizeOptionalText(scopedCityInput.getTitleFr(), 255);
		Long validatedCdmStateId = sanitizeOptionalNonNegativeLong(scopedCityInput.getCdmStateId());

		oldCity.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));
		oldCity.setAttributes(new HashMap<>(validatedAttributes));
		oldCity.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
		oldCity.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
		oldCity.setCdmStateId(validatedCdmStateId == null ? null : Long.valueOf(validatedCdmStateId));
		oldCity.setModifiedAt(new Date().getTime() / 1000);

		try {
			return cityRepository.saveAndFlush(oldCity);
		} catch (DataAccessException ex) {
			log.error("Failed to persist city with id {}.", cityId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update city.");
		}

	}



	
    /**
     * Retrieves a map of city names by their CDM key IDs.
     *
     * @param cdmKeyIdList list of CDM key IDs
     * @return a map of CDM key ID to city name
     */
	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return cityRepository.getNameByCmdKeyId(cdmKeyIdList)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, Long.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve city names by CDM key IDs.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve city names.");
		}
	}

	
    /**
     * Retrieves all City entities from the database.
     *
     * @return a list of all City objects
     */
	public List<City> getAll() {
		try {
			return cityRepository.findAll();
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve all cities.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve cities.");
		}
	}


    /**
     * Saves and flushes a City entity to the database.
     *
     * @param cityInput the restricted validated input payload
     * @return the saved City object
     */
	public City save(CityUpsertInput cityInput) {

		if (Objects.isNull(cityInput)) {
			return null;
		}

		CityUpsertInput scopedCityInput = sanitizeCityUpsertInput(cityInput);

		Long validatedCdmKeyId = sanitizeOptionalNonNegativeLong(scopedCityInput.getCdmKeyId());
		Map<String, String> validatedAttributes = sanitizeAttributes(scopedCityInput.getAttributes());
		String validatedTitleEn = sanitizeOptionalText(scopedCityInput.getTitleEn(), 255);
		String validatedTitleFr = sanitizeOptionalText(scopedCityInput.getTitleFr(), 255);
		Long validatedCdmStateId = sanitizeOptionalNonNegativeLong(scopedCityInput.getCdmStateId());

		City sanitized = new City();
		sanitized.setId(null);
		sanitized.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));
		sanitized.setAttributes(new HashMap<>(validatedAttributes));
		sanitized.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
		sanitized.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
		sanitized.setCdmStateId(validatedCdmStateId == null ? null : Long.valueOf(validatedCdmStateId));
		sanitized.setModifiedAt((new Date()).getTime() / 1000);

		return cityRepository.saveAndFlush(sanitized);
	}






    /**
     * Deletes a City entity by its ID.
     *
     * @param cityId the ID of the city to delete
     */
	public void deleteById(Long cityId) {
		cityRepository.deleteById(cityId);
	}

    /**
     * Counts the number of cities grouped by country.
     *
     * @return a list of tuples representing country-wise city counts
     */
	public List<Tuple> countByCountry() {
		try {
			return cityRepository.countByCountry();
		} catch (DataAccessException ex) {
			log.error("Failed to count cities by country.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count cities by country.");
		}
	}

	
    /**
     * Counts the number of cities for a specific country ID.
     *
     * @param countryId the ID of the country
     * @return the number of cities in the specified country
     */
	public Long countByCountryId(Long countryId) {
		return cityRepository.countByCountryId(countryId);
	}

	private CityUpsertInput sanitizeCityUpsertInput(CityUpsertInput source) {
		if (source == null) {
			throw new IllegalArgumentException("City input must not be null");
		}

		Long safeCdmKeyId = source.getCdmKeyId() == null ? null : Long.valueOf(String.valueOf(source.getCdmKeyId()));
		Map<String, String> safeAttributes = new HashMap<>();
		Map<String, String> sourceAttributes = source.getAttributes();
		if (sourceAttributes != null) {
			sourceAttributes.forEach((key, value) -> {
				if (Objects.nonNull(key) && Objects.nonNull(value)) {
					safeAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
				}
			});
		}
		String safeTitleEn = source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn()));
		String safeTitleFr = source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr()));
		Long safeCdmStateId = source.getCdmStateId() == null ? null : Long.valueOf(String.valueOf(source.getCdmStateId()));

		return new CityUpsertInput(safeCdmKeyId, safeAttributes, safeTitleEn, safeTitleFr, safeCdmStateId);
	}

	private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
		Map<String, String> sanitized = new HashMap<>();
		if (Objects.isNull(attributes)) {
			return sanitized;
		}

		attributes.forEach((key, value) -> {
			if (Objects.nonNull(key) && Objects.nonNull(value)) {
				String safeKey = sanitizeOptionalText(key, 255);
				String safeValue = sanitizeOptionalText(value, 1000);
				if (Objects.nonNull(safeKey) && Objects.nonNull(safeValue)) {
					sanitized.put(safeKey, safeValue);
				}
			}
		});
		return sanitized;
	}

	private Long sanitizeOptionalNonNegativeLong(Long value) {
		if (Objects.isNull(value)) {
			return null;
		}

		Long validated = Long.valueOf(String.valueOf(value));
		if (validated < 0) {
			throw new IllegalArgumentException("Invalid numeric input");
		}

		return Long.valueOf(validated);
	}

	private String sanitizeOptionalText(String value, int maxLength) {
		if (value == null) {
			return null;
		}
		String trimmed = value.trim();
		if (trimmed.isEmpty()) {
			return null;
		}
		if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
			throw new IllegalArgumentException("Invalid text input");
		}
		return new String(trimmed);
	}
}
