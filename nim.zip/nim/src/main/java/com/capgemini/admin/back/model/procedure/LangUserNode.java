package com.capgemini.admin.back.model.procedure;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.Data;
import javax.persistence.Lob;

@Data
@Entity
@Table(name = "lang_user_node_mapping")
public class LangUserNode {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LangUserNodeMapping_Generator")
    @SequenceGenerator(name = "LangUserNodeMapping_Generator", sequenceName = "LangUserNodeMapping_Sequence")
    private Long id;

    @Column(name = "json_node", length = 500)
    private String jsonNode;

    @Column(name = "xml_node", length = 500)
    private String xmlNode;

    @Lob
    @Column(name = "xml_nodewithdata")
    private String xmlNodewithdata;

}
