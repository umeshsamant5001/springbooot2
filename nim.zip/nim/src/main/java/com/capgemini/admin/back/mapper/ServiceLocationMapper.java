package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.ServiceLocation;
import com.capgemini.admin.back.model.ServiceLocationDTO;

@Mapper(config = DtoMapperConfig.class)
public interface ServiceLocationMapper {
    ServiceLocationMapper INSTANCE = Mappers.getMapper(ServiceLocationMapper.class);

    @Mapping(target = "service", ignore = true)
    ServiceLocation serviceLocationDTOToServiceLocation(ServiceLocationDTO in);

    @Mappings({
            @Mapping(target = "service", ignore = true),
            @Mapping(target = "name", ignore = true)
    })
    ServiceLocationDTO serviceLocationToServiceLocationDTO(ServiceLocation in);

}
