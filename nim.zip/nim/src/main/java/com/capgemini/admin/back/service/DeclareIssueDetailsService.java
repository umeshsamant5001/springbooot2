package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.regex.Pattern;

import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.DeclareIssueBuildingDetailsMapper;
import com.capgemini.admin.back.mapper.DeclareIssueDetailsMapper;
import com.capgemini.admin.back.mapper.DeclareIssueMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.DeclareIssue;
import com.capgemini.admin.back.model.DeclareIssueBuildingDetails;
import com.capgemini.admin.back.model.DeclareIssueBuildingDetailsDTO;
import com.capgemini.admin.back.model.LevelEnum;


import com.capgemini.admin.back.model.DeclareIssueDetails;
import com.capgemini.admin.back.model.DeclareIssueDetailsDTO;

import com.capgemini.admin.back.model.DeclareIssueUpdateEmailRequest;
import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.CountryRepository;
import com.capgemini.admin.back.repository.DeclareIssueBuildingDetailsRepository;
import com.capgemini.admin.back.repository.DeclareIssueDetailsRepository;
import com.capgemini.admin.back.repository.DeclareIssueRepository;



import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DeclareIssueDetailsService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";
    private static final int MAX_EMAIL_ID_LENGTH = 255;

    private static final class SafeDeclareIssueValues {
        private final Long countryId;
        private final Long declareIssueId;
        private final String emailId;

        private SafeDeclareIssueValues(Long countryId, Long declareIssueId, String emailId) {
            this.countryId = countryId == null ? null : Long.valueOf(String.valueOf(countryId));
            this.declareIssueId = declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
            this.emailId = emailId == null ? null : new String(String.valueOf(emailId));
        }
    }

    private static final class SafeDeclareIssueBuildingValues {
        private final Long buildingId;
        private final Long declareIssueId;
        private final String emailId;

        private SafeDeclareIssueBuildingValues(Long buildingId, Long declareIssueId, String emailId) {
            this.buildingId = buildingId == null ? null : Long.valueOf(String.valueOf(buildingId));
            this.declareIssueId = declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
            this.emailId = emailId == null ? null : new String(String.valueOf(emailId));
        }
    }


    public static class DeclareIssueWriteInput {
        private final Long countryId;
        private final Long declareIssueId;
        private final String emailId;

        public DeclareIssueWriteInput(Long countryId, Long declareIssueId, String emailId) {
            this.countryId = countryId == null ? null : Long.valueOf(String.valueOf(countryId));
            this.declareIssueId = declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
            this.emailId = emailId == null ? null : new String(String.valueOf(emailId));
        }

        public Long getCountryId() {
            return countryId == null ? null : Long.valueOf(String.valueOf(countryId));
        }

        public Long getDeclareIssueId() {
            return declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
        }

        public String getEmailId() {
            return emailId == null ? null : new String(String.valueOf(emailId));
        }
    }

    public static class DeclareIssueBuildingWriteInput {
        private final Long buildingId;
        private final Long declareIssueId;
        private final String emailId;

        public DeclareIssueBuildingWriteInput(Long buildingId, Long declareIssueId, String emailId) {
            this.buildingId = buildingId == null ? null : Long.valueOf(String.valueOf(buildingId));
            this.declareIssueId = declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
            this.emailId = emailId == null ? null : new String(String.valueOf(emailId));
        }

        public Long getBuildingId() {
            return buildingId == null ? null : Long.valueOf(String.valueOf(buildingId));
        }

        public Long getDeclareIssueId() {
            return declareIssueId == null ? null : Long.valueOf(String.valueOf(declareIssueId));
        }

        public String getEmailId() {
            return emailId == null ? null : new String(String.valueOf(emailId));
        }
    }


    @Autowired
    private DeclareIssueDetailsRepository declareIssueDetailsRepository;

    @Autowired
    private DeclareIssueBuildingDetailsRepository declareIssueBuildingDetailsRepository;

    @Autowired
    private DeclareIssueRepository declareIssueRepository;

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private BuildingRepository buildingRepository;

    @Autowired
    private TreeService treeService;




    public List<DeclareIssueDetailsDTO> findByCountryId(Long countryId) {



        List<DeclareIssueDetails> detailsList = declareIssueDetailsRepository.findByCountryId(countryId);
        return detailsList.stream()
                .map(detail -> {
                    DeclareIssueDetailsDTO dto = DeclareIssueDetailsMapper.INSTANCE
                            .declareIssueDetailsToDeclareIssueDetailsDTO(detail);
                    dto.setDeclareIssue(
                            DeclareIssueMapper.INSTANCE.declareIssueToDeclareIssueDTO(detail.getDeclareIssue()));
                    return dto;
                })
                .collect(Collectors.toList());
    }

    /**
     * Updates the email IDs for DeclareIssueDetails records based on the provided
     * country ID
     * and list of update requests. This method performs the following steps:
     * 
     * Extracts all DeclareIssueDetails IDs from the request for batch fetching.
     * Validates that each record exists and matches the given country ID.
     * Updates the email ID and modified timestamp for each record.
     * Saves all updated records in a single transaction for efficiency.
     * Fetches updated records along with their parent DeclareIssue entities.
     * Converts the updated entities to DTOs for response.
     *
     * @param countryId           the ID of the country to validate against each
     *                            DeclareIssueDetails record
     * @param emailUpdateRequests list of requests containing IDs and new email IDs
     * @return a list of {@link DeclareIssueDetailsDTO} representing the updated
     *         details
     * @throws RuntimeException if any record is not found or country ID does not
     *                          match
     */
    public List<DeclareIssueDetailsDTO> updateEmailIdsByCountryIdAndDeclareIsuueDetailsId(
            Long countryId,
            List<DeclareIssueUpdateEmailRequest> emailUpdateRequests) {

        Long sanitizedCountryId = sanitizeRequiredPositiveId(countryId, "countryId");
        List<DeclareIssueUpdateEmailRequest> sanitizedEmailUpdateRequests = sanitizeEmailUpdateRequestsForPersistence(
                emailUpdateRequests);


        // Extract all IDs to fetch in a single query for better performance
        List<Long> detailsIds = sanitizedEmailUpdateRequests.stream()
                .map(DeclareIssueUpdateEmailRequest::getId)
                .collect(Collectors.toList());


        // Fetch all records scoped by countryId
        List<DeclareIssueDetails> detailsList = declareIssueDetailsRepository.findByIdInAndCountryId(detailsIds,
                sanitizedCountryId);



        // Create a map for easy lookup
        Map<Long, DeclareIssueDetails> detailsMap = detailsList.stream()
                .collect(Collectors.toMap(DeclareIssueDetails::getId, Function.identity()));

        long uniqueRequestIds = detailsIds.stream().distinct().count();
        if (detailsMap.size() != uniqueRequestIds) {
            throw new RuntimeException(
                    "One or more DeclareIssueDetails IDs are invalid for country ID: " + sanitizedCountryId);
        }


        List<DeclareIssueDetails> updatedDetailsList = new ArrayList<>();

        // Process each update request
        for (DeclareIssueUpdateEmailRequest request : sanitizedEmailUpdateRequests) {
            Long sanitizedDetailsId = sanitizeRequiredPositiveId(request.getId(), "id");
            DeclareIssueDetails details = detailsMap.get(sanitizedDetailsId);

            if (details == null) {
                throw new RuntimeException("DeclareIssueDetails not found with ID: " + sanitizedDetailsId);
            }




            // Update email ID
            String validatedEmailId = sanitizeEmailIdForPersistence(request.getEmailId());
            details.setEmailId(validatedEmailId == null ? null : new String(validatedEmailId));
            details.setModifiedAt(new Date().getTime() / 1000);

            updatedDetailsList.add(details);
        }


        // Save all updated records in a single transaction
        List<DeclareIssueDetails> savedDetails = declareIssueDetailsRepository.saveAll(updatedDetailsList);

        // Fetch the details with their parent DeclareIssue entities
        List<DeclareIssueDetails> detailsWithParents = fetchDetailsWithParents(savedDetails);

        // Convert to DTOs
        return detailsWithParents.stream()
                .map(details -> {
                    DeclareIssueDetailsDTO dto = DeclareIssueDetailsMapper.INSTANCE
                            .declareIssueDetailsToDeclareIssueDetailsDTO(details);
                    if (details.getDeclareIssue() != null) {
                        dto.setDeclareIssue(
                                DeclareIssueMapper.INSTANCE.declareIssueToDeclareIssueDTO(details.getDeclareIssue()));
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    /**
     * Fetches DeclareIssueDetails records along with their parent DeclareIssue
     * entities
     * based on the provided list of details.
     *
     * @param details the list of DeclareIssueDetails whose parent relationships
     *                need to be fetched
     * @return a list of DeclareIssueDetails including their associated parent
     *         DeclareIssue entities
     */
    private List<DeclareIssueDetails> fetchDetailsWithParents(List<DeclareIssueDetails> details) {
        List<Long> ids = details.stream().map(DeclareIssueDetails::getId).collect(Collectors.toList());
        return declareIssueDetailsRepository.findByIdIn(ids);
    }

    /**
     * Extracts all DeclareIssueDetails IDs from the request.
     * Delete DeclareIssueDetails records for all DeclareIssueDetails IDs.
     * 
     * @param countryId                 the ID of the country to validate against
     *                                  each DeclareIssueDetails record
     * @param deleteDeclareIssueRequest list of requests containing IDs and new
     *                                  email IDs
     */
    @Transactional
    public void deleteDeclareIsuueDetailsIdByCountryId(
            Long countryId,
            List<DeclareIssueUpdateEmailRequest> deleteDeclareIssueRequest) {

        // Extract all IDs to fetch in a single query for better performance
        List<Long> detailsIds = deleteDeclareIssueRequest.stream()
                .map(DeclareIssueUpdateEmailRequest::getId)
                .collect(Collectors.toList());

        try {
            declareIssueDetailsRepository.deleteByIdsandCountryId(detailsIds, countryId);
        } catch (DataAccessException ex) {
            log.error("Failed to delete declare issue details for countryId={}", countryId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to process delete request at this time.");
        }

    }

    /**
     * Creates a new DeclareIssueDetails entry in the database.
     * 
     * @param request The request object containing details for the new
     *                DeclareIssueDetails.
     * @return The saved DeclareIssueDetails object.
     * @throws ResponseStatusException if a duplicate entry is found.
     */
    @Transactional
    public DeclareIssueDetails createDeclareIssue(DeclareIssueWriteInput declareIssueWriteInput) {

        SafeDeclareIssueValues safeValues = sanitizeDeclareIssueWriteInputForPersistence(declareIssueWriteInput);


        Long resolvedCountryId = resolveCountryIdForPersistence(safeValues.countryId);

        DeclareIssueDetails existingIssueDetails = declareIssueDetailsRepository.findByCountryId(resolvedCountryId)
                .stream()
                .filter(details -> details != null
                        && details.getDeclareIssue() != null
                        && details.getDeclareIssue().getId() != null
                        && details.getDeclareIssue().getId().equals(safeValues.declareIssueId))
                .findFirst()
                .orElse(null);

        if (Objects.nonNull(existingIssueDetails)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Declare Issue Details already exists.");
        }

        DeclareIssue issue = declareIssueRepository.findAll()
                .stream()
                .filter(candidate -> candidate != null
                        && candidate.getId() != null
                        && candidate.getId().equals(safeValues.declareIssueId))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid declare issue id."));

        DeclareIssueDetails issueDetails = new DeclareIssueDetails();


        issueDetails.setId(null);
        issueDetails.setDeclareIssue(issue);
        issueDetails.setDeclareIssueId(issue.getId() == null ? null : Long.valueOf(String.valueOf(issue.getId())));
        issueDetails.setCountryId(resolvedCountryId == null ? null : Long.valueOf(String.valueOf(resolvedCountryId)));
        issueDetails.setEmailId(safeValues.emailId == null ? null : new String(String.valueOf(safeValues.emailId)));
        issueDetails.setCreatedAt(System.currentTimeMillis() / 1000);
        issueDetails.setModifiedAt(System.currentTimeMillis() / 1000);



        DeclareIssueDetails saved = declareIssueDetailsRepository.saveAndFlush(issueDetails);
        return saved;
    }



    /**
     * Creates a new DeclareIssueBuildingDetails entry in the database.
     * 
     * @param request The request object containing details for the new
     *                DeclareIssueBuildingDetails.
     * @return The saved DeclareIssueBuildingDetails object.
     * @throws ResponseStatusException if a duplicate entry is found.
     */
    @Transactional
    public DeclareIssueBuildingDetails createDeclareIssueBuildingDetails(
            DeclareIssueBuildingWriteInput declareIssueBuildingWriteInput) {

        SafeDeclareIssueBuildingValues safeValues = sanitizeDeclareIssueBuildingWriteInputForPersistence(
                declareIssueBuildingWriteInput);



        Long resolvedBuildingId = resolveBuildingIdForPersistence(safeValues.buildingId);
        Long resolvedCountryId = resolveCountryIdByBuildingIdForPersistence(resolvedBuildingId);

        DeclareIssueBuildingDetails existingIssueBuildingDetails = declareIssueBuildingDetailsRepository
                .findByBuildingId(resolvedBuildingId)
                .stream()
                .filter(details -> details != null
                        && details.getDeclareIssue() != null
                        && details.getDeclareIssue().getId() != null
                        && details.getDeclareIssue().getId().equals(safeValues.declareIssueId))
                .findFirst()
                .orElse(null);

        if (Objects.nonNull(existingIssueBuildingDetails)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Declare Issue Details already exists.");
        }

        DeclareIssue issue = declareIssueDetailsRepository.findByCountryId(resolvedCountryId)
                .stream()
                .map(DeclareIssueDetails::getDeclareIssue)
                .filter(candidate -> candidate != null
                        && candidate.getId() != null
                        && candidate.getId().equals(safeValues.declareIssueId))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid declare issue id."));


        DeclareIssueBuildingDetails issueDetails = new DeclareIssueBuildingDetails();


        issueDetails.setId(null);
        issueDetails.setDeclareIssue(issue);
        issueDetails.setDeclareIssueId(issue.getId() == null ? null : Long.valueOf(String.valueOf(issue.getId())));
        issueDetails.setBuildingId(resolvedBuildingId == null ? null : Long.valueOf(String.valueOf(resolvedBuildingId)));
        issueDetails.setEmailId(safeValues.emailId == null ? null : new String(String.valueOf(safeValues.emailId)));
        issueDetails.setCreatedAt(System.currentTimeMillis() / 1000);
        issueDetails.setModifiedAt(System.currentTimeMillis() / 1000);



        DeclareIssueBuildingDetails saved = declareIssueBuildingDetailsRepository.saveAndFlush(issueDetails);
        return saved;
    }



    // updated for building

    /**
     * Updates the email IDs for DeclareIssueBuildigDetails records based on the
     * provided
     * building ID
     * and list of update requests. This method performs the following steps:
     * 
     * Extracts all DeclareIssueBuildingDetails IDs from the request for batch
     * fetching.
     * Validates that each record exists and matches the given building ID.
     * Updates the email ID and modified timestamp for each record.
     * Saves all updated records in a single transaction for efficiency.
     * Fetches updated records along with their parent DeclareIssue entities.
     * Converts the updated entities to DTOs for response.
     *
     * @param buildingId          the ID of the country to validate against each
     *                            DeclareIssueBuildingDetails record
     * @param emailUpdateRequests list of requests containing IDs and new email IDs
     * @return a list of {@link DeclareIssueBuildingDetailsDTO} representing the
     *         updated
     *         details
     * @throws RuntimeException if any record is not found or building ID does not
     *                          match
     */
    public List<DeclareIssueBuildingDetailsDTO> updateEmailIdsByBuildingIdAndDeclareIsuueDetailsId(
            Long buildingId,
            List<DeclareIssueUpdateEmailRequest> emailUpdateRequests) {

        Long sanitizedBuildingId = sanitizeRequiredPositiveId(buildingId, "buildingId");
        List<DeclareIssueUpdateEmailRequest> sanitizedEmailUpdateRequests = sanitizeEmailUpdateRequestsForPersistence(
                emailUpdateRequests);


        // Extract all IDs to fetch in a single query for better performance
        List<Long> detailsIds = sanitizedEmailUpdateRequests.stream()
                .map(DeclareIssueUpdateEmailRequest::getId)
                .collect(Collectors.toList());


        // Fetch all records scoped by buildingId
        List<DeclareIssueBuildingDetails> detailsList = declareIssueBuildingDetailsRepository
                .findByIdInAndBuildingId(detailsIds, sanitizedBuildingId);



        // Create a map for easy lookup
        Map<Long, DeclareIssueBuildingDetails> detailsMap = detailsList.stream()
                .collect(Collectors.toMap(DeclareIssueBuildingDetails::getId, Function.identity()));

        long uniqueRequestIds = detailsIds.stream().distinct().count();
        if (detailsMap.size() != uniqueRequestIds) {
            throw new RuntimeException(
                    "One or more DeclareIssueBuildingDetails IDs are invalid for building ID: " + sanitizedBuildingId);
        }


        List<DeclareIssueBuildingDetails> updatedDetailsList = new ArrayList<>();

        // Process each update request
        for (DeclareIssueUpdateEmailRequest request : sanitizedEmailUpdateRequests) {
            Long sanitizedDetailsId = sanitizeRequiredPositiveId(request.getId(), "id");
            DeclareIssueBuildingDetails details = detailsMap.get(sanitizedDetailsId);

            if (details == null) {
                throw new RuntimeException("DeclareIssueBuildingDetails not found with ID: " + sanitizedDetailsId);
            }




            // Update email ID
            String validatedEmailId = sanitizeEmailIdForPersistence(request.getEmailId());
            details.setEmailId(validatedEmailId == null ? null : new String(validatedEmailId));
            details.setModifiedAt(new Date().getTime() / 1000);

            updatedDetailsList.add(details);
        }


        // Save all updated records in a single transaction
        List<DeclareIssueBuildingDetails> savedDetails = declareIssueBuildingDetailsRepository
                .saveAll(updatedDetailsList);

        // Fetch the details with their parent DeclareIssue entities
        List<DeclareIssueBuildingDetails> detailsWithParents = fetchBuildingDetailsWithParents(savedDetails);

        // Convert to DTOs
        return detailsWithParents.stream()
                .map(details -> {
                    DeclareIssueBuildingDetailsDTO dto = DeclareIssueBuildingDetailsMapper.INSTANCE
                            .declareIssueBuildingDetailsToDeclareIssueBuildingDetailsDTO(details);
                    if (details.getDeclareIssue() != null) {
                        dto.setDeclareIssue(
                                DeclareIssueMapper.INSTANCE.declareIssueToDeclareIssueDTO(details.getDeclareIssue()));
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    /**
     * Fetches DeclareIssueBuildingDetails records along with their parent
     * DeclareIssue
     * entities
     * based on the provided list of details.
     *
     * @param details the list of DeclareIssueDetails whose parent relationships
     *                need to be fetched
     * @return a list of DeclareIssueBuildingDetails including their associated
     *         parent
     *         DeclareIssue entities
     */
    private List<DeclareIssueBuildingDetails> fetchBuildingDetailsWithParents(
            List<DeclareIssueBuildingDetails> details) {
        List<Long> ids = details.stream().map(DeclareIssueBuildingDetails::getId).collect(Collectors.toList());
        return declareIssueBuildingDetailsRepository.findByIdIn(ids);
    }

    public List<DeclareIssueBuildingDetailsDTO> findByBuildingAndDeclareIssue(Long buildingId) {
        List<DeclareIssueBuildingDetails> detailsList = declareIssueBuildingDetailsRepository
                .findByBuildingId(buildingId);
        return detailsList.stream()
                .map(detail -> {
                    DeclareIssueBuildingDetailsDTO dto = DeclareIssueBuildingDetailsMapper.INSTANCE
                            .declareIssueBuildingDetailsToDeclareIssueBuildingDetailsDTO(detail);
                    dto.setDeclareIssue(
                            DeclareIssueMapper.INSTANCE.declareIssueToDeclareIssueDTO(detail.getDeclareIssue()));
                    return dto;
                })
                .collect(Collectors.toList());
    }

    /**
     * Extracts all DeclareIssueBuildingDetails IDs from the request.
     * Delete DeclareIssueBuildingDetails records for all DeclareIssueBuildingDetails IDs.
     * 
     * @param buildingId                 the ID of the building to validate against
     *                                  each DeclareIssueDetails record
     * @param deleteDeclareIssueRequest list of requests containing IDs and new
     *                                  email IDs
     */
    @Transactional
    public void deleteDeclareIsuueBuildingDetailsIdByBuildingId(
            Long buildingId,
            List<DeclareIssueUpdateEmailRequest> deleteDeclareIssueRequest) {

        // Extract all IDs to fetch in a single query for better performance
        List<Long> detailsIds = deleteDeclareIssueRequest.stream()
                .map(DeclareIssueUpdateEmailRequest::getId)
                .collect(Collectors.toList());

        try {
            declareIssueBuildingDetailsRepository.deleteByIdsandBuildingId(detailsIds, buildingId);
        } catch (DataAccessException ex) {
            log.error("Failed to delete declare issue building details for buildingId={}", buildingId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to process delete request at this time.");
        }

    }

    



    private SafeDeclareIssueValues sanitizeDeclareIssueWriteInputForPersistence(DeclareIssueWriteInput source) {
        if (source == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid request payload.");
        }

        Long copiedCountryId = source.getCountryId() == null
                ? null
                : Long.valueOf(String.valueOf(source.getCountryId()));
        Long copiedDeclareIssueId = source.getDeclareIssueId() == null
                ? null
                : Long.valueOf(String.valueOf(source.getDeclareIssueId()));
        String copiedEmailId = source.getEmailId() == null
                ? null
                : new String(String.valueOf(source.getEmailId()));

        Long validatedCountryId = sanitizeRequiredPositiveId(copiedCountryId, "countryId");
        Long validatedDeclareIssueId = sanitizeRequiredPositiveId(copiedDeclareIssueId, "declareIssueId");
        String validatedEmailId = sanitizeEmailIdForPersistence(copiedEmailId == null
                ? null
                : new String(String.valueOf(copiedEmailId)));

        return new SafeDeclareIssueValues(
                validatedCountryId == null ? null : Long.valueOf(String.valueOf(validatedCountryId)),
                validatedDeclareIssueId == null ? null : Long.valueOf(String.valueOf(validatedDeclareIssueId)),
                validatedEmailId == null ? null : new String(String.valueOf(validatedEmailId)));
    }

    private SafeDeclareIssueBuildingValues sanitizeDeclareIssueBuildingWriteInputForPersistence(
            DeclareIssueBuildingWriteInput source) {
        if (source == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid request payload.");
        }

        Long copiedBuildingId = source.getBuildingId() == null
                ? null
                : Long.valueOf(String.valueOf(source.getBuildingId()));
        Long copiedDeclareIssueId = source.getDeclareIssueId() == null
                ? null
                : Long.valueOf(String.valueOf(source.getDeclareIssueId()));
        String copiedEmailId = source.getEmailId() == null
                ? null
                : new String(String.valueOf(source.getEmailId()));

        Long validatedBuildingId = sanitizeRequiredPositiveId(copiedBuildingId, "buildingId");
        Long validatedDeclareIssueId = sanitizeRequiredPositiveId(copiedDeclareIssueId, "declareIssueId");
        String validatedEmailId = sanitizeEmailIdForPersistence(copiedEmailId == null
                ? null
                : new String(String.valueOf(copiedEmailId)));

        return new SafeDeclareIssueBuildingValues(
                validatedBuildingId == null ? null : Long.valueOf(String.valueOf(validatedBuildingId)),
                validatedDeclareIssueId == null ? null : Long.valueOf(String.valueOf(validatedDeclareIssueId)),
                validatedEmailId == null ? null : new String(String.valueOf(validatedEmailId)));
    }

    private Long resolveCountryIdForPersistence(Long incomingCountryId) {


        Long validatedCountryId = sanitizeRequiredPositiveId(incomingCountryId, "countryId");
        Long authorizedCountryId = resolveAuthorizedLocationId(LevelEnum.COUNTRY, validatedCountryId, "country");
        Country validatedCountry = countryRepository.findById(authorizedCountryId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid country id."));
        return validatedCountry.getId() == null ? null : Long.valueOf(String.valueOf(validatedCountry.getId()));
    }

    private Long resolveBuildingIdForPersistence(Long incomingBuildingId) {
        Long validatedBuildingId = sanitizeRequiredPositiveId(incomingBuildingId, "buildingId");
        Long authorizedBuildingId = resolveAuthorizedLocationId(LevelEnum.BUILDING, validatedBuildingId, "building");
        Building validatedBuilding = buildingRepository.findById(authorizedBuildingId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid building id."));
        return validatedBuilding.getId() == null ? null : Long.valueOf(String.valueOf(validatedBuilding.getId()));
    }

    private Long resolveAuthorizedLocationId(LevelEnum level, Long requestedId, String resourceName) {
        Long sanitizedRequestedId = sanitizeRequiredPositiveId(requestedId, resourceName + "Id");
        List<Long> authorizedIds = treeService.filterId(level, List.of(sanitizedRequestedId));
        if (authorizedIds == null || authorizedIds.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized " + resourceName + " id.");
        }
        Long authorizedId = authorizedIds.get(0);
        return authorizedId == null ? null : Long.valueOf(String.valueOf(authorizedId));
    }


    private Long resolveCountryIdByBuildingIdForPersistence(Long buildingId) {
        Long validatedBuildingId = sanitizeRequiredPositiveId(buildingId, "buildingId");
        Long resolvedCountryId = buildingRepository.findCountryIdByBuildingId(validatedBuildingId);
        if (resolvedCountryId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid building id.");
        }
        return sanitizeRequiredPositiveId(Long.valueOf(String.valueOf(resolvedCountryId)), "countryId");
    }


    private Long sanitizeRequiredPositiveId(Long id, String fieldName) {
        Long sanitized = id == null ? null : Long.valueOf(String.valueOf(id));
        if (sanitized == null || sanitized <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid " + fieldName + ".");
        }
        return sanitized;
    }


    private List<DeclareIssueUpdateEmailRequest> sanitizeEmailUpdateRequestsForPersistence(
            List<DeclareIssueUpdateEmailRequest> emailUpdateRequests) {
        if (emailUpdateRequests == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid email update request list.");
        }

        List<DeclareIssueUpdateEmailRequest> sanitizedRequests = new ArrayList<>();
        for (DeclareIssueUpdateEmailRequest request : emailUpdateRequests) {
            if (request == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid email update request list.");
            }
            DeclareIssueUpdateEmailRequest sanitizedRequest = new DeclareIssueUpdateEmailRequest();
            sanitizedRequest.setId(sanitizeRequiredPositiveId(request.getId(), "id"));
            String validatedEmailId = sanitizeEmailIdForPersistence(request.getEmailId());
            sanitizedRequest.setEmailId(validatedEmailId == null ? null : new String(validatedEmailId));
            sanitizedRequests.add(sanitizedRequest);
        }
        return sanitizedRequests;
    }



    private String sanitizeEmailIdForPersistence(String emailId) {

        if (emailId == null) {
            return null;
        }

        String validated = new String(String.valueOf(emailId).trim());
        if (validated.length() > MAX_EMAIL_ID_LENGTH || !Pattern.matches(SAFE_TEXT_REGEX, validated)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid emailId.");
        }
        return validated;
    }

}
