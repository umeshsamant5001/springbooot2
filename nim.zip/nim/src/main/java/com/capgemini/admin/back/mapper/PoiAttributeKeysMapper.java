package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.PoiAttributeKeys;
import com.capgemini.admin.back.model.PoiAttributeKeysDTO;

@Mapper(config = DtoMapperConfig.class)
public interface PoiAttributeKeysMapper {

    PoiAttributeKeysMapper INSTANCE = Mappers.getMapper(PoiAttributeKeysMapper.class);

    PoiAttributeKeys poiAttributeKeysDTOToPoiAttributeKeys(PoiAttributeKeysDTO in);

    PoiAttributeKeysDTO poiAttributeKeysToPoiAttributeKeysDTO(PoiAttributeKeys in);
}
