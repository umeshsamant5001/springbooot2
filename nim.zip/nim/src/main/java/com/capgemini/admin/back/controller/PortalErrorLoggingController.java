package com.capgemini.admin.back.controller;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.model.PortalErrorLoggingDTO;
import com.capgemini.admin.back.service.PortalErrorLoggingService;
import com.capgemini.admin.back.service.PortalErrorLoggingService.PortalErrorLoggingUpsertInput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping(value = PortalErrorLoggingController.ROOT_API)
public class PortalErrorLoggingController {
      public static final String ROOT_API = "/api/portal-error-logging";
        private static final String SAFE_TEXT_REGEX = "^[\\P{Cntrl}\\r\\n\\t]*$";

        private final PortalErrorLoggingService portalErrorLoggingService;

        public PortalErrorLoggingController(PortalErrorLoggingService portalErrorLoggingService) {
                  this.portalErrorLoggingService = portalErrorLoggingService;
        }

        @JsonIgnoreProperties(ignoreUnknown = false)
      @Data
      private static class PortalErrorLoggingCreateInput {
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String className;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String module;
              @Min(0)
              private Long lineNumber;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String description;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String state;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String errorType;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String data;
              @Min(0)
              private Long loggingDate;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String errorLoggingType;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String userEmail;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String httpMethod;
              @Size(max = 2048)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String requestUrl;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String requestPayload;
              @Min(0)
              private Long responseStatus;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String responseBody;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String stackTrace;
              @Size(max = 10000)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String browserInfo;
              @Size(max = 255)
              @Pattern(regexp = SAFE_TEXT_REGEX)
              private String applicationPortal;
      }

        @PostMapping
        public ResponseEntity<PortalErrorLoggingDTO> createPortalErrorLogging(
                        @Valid @RequestBody PortalErrorLoggingCreateInput portalErrorLoggingInput) {

                if (Objects.isNull(portalErrorLoggingInput)) {
                    return ResponseEntity.badRequest().build();
                }

                PortalErrorLoggingUpsertInput scopedPortalErrorLoggingInput = toPortalErrorLoggingInput(portalErrorLoggingInput);

                String safeLogPayload = sanitizeForLog(String.valueOf(portalErrorLoggingInput));
                log.info("Incoming error log portalErrorLoggingDTO : {}", safeLogPayload);

                PortalErrorLoggingDTO responseDTO = portalErrorLoggingService
                                .createPortalErrorLogging(scopedPortalErrorLoggingInput);



                return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
        }

        private String sanitizeForLog(String input) {
                if (input == null) {
                        return "";
                }
                return input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", "");
        }

        private PortalErrorLoggingUpsertInput toPortalErrorLoggingInput(PortalErrorLoggingCreateInput portalErrorLoggingInput) {
                return new PortalErrorLoggingUpsertInput(
                                portalErrorLoggingInput.getClassName() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getClassName())),
                                portalErrorLoggingInput.getModule() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getModule())),
                                portalErrorLoggingInput.getLineNumber() == null
                                                ? null
                                                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getLineNumber())),
                                portalErrorLoggingInput.getDescription() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getDescription())),
                                portalErrorLoggingInput.getState() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getState())),
                                portalErrorLoggingInput.getErrorType() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getErrorType())),
                                portalErrorLoggingInput.getData() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getData())),
                                portalErrorLoggingInput.getLoggingDate() == null
                                                ? null
                                                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getLoggingDate())),
                                portalErrorLoggingInput.getErrorLoggingType() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getErrorLoggingType())),
                                portalErrorLoggingInput.getUserEmail() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getUserEmail())),
                                portalErrorLoggingInput.getHttpMethod() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getHttpMethod())),
                                portalErrorLoggingInput.getRequestUrl() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getRequestUrl())),
                                portalErrorLoggingInput.getRequestPayload() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getRequestPayload())),
                                portalErrorLoggingInput.getResponseStatus() == null
                                                ? null
                                                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getResponseStatus())),
                                portalErrorLoggingInput.getResponseBody() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getResponseBody())),
                                portalErrorLoggingInput.getStackTrace() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getStackTrace())),
                                portalErrorLoggingInput.getBrowserInfo() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getBrowserInfo())),
                                portalErrorLoggingInput.getApplicationPortal() == null
                                                ? null
                                                : new String(String.valueOf(portalErrorLoggingInput.getApplicationPortal())));
        }


}