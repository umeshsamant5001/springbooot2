package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * Request DTO for updating the email of a DeclareIssueDetails / DeclareIssueBuildingDetails record.
 * Only {@code id} and {@code emailId} are bindable from the client payload. Any other property
 * sent by a caller is rejected to prevent unsafe object binding (mass-assignment) on the
 * downstream persistence sinks (saveAll / saveAndFlush).
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class DeclareIssueUpdateEmailRequest {
    private Long id;
    private String emailId;
}
