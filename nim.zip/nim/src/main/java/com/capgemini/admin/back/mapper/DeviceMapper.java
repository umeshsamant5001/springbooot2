package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.FloorDTO;

import org.mapstruct.BeanMapping;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.DeviceDTO;
import com.capgemini.admin.back.model.DeviceMaintenanceDTO;

@Named("DeviceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface DeviceMapper {

    DeviceMapper INSTANCE = Mappers.getMapper(DeviceMapper.class);

    @Mapping(source = "floor", target = "floor", qualifiedByName = { "floorToFloorDTO" })
    DeviceDTO deviceToDeviceDTO(Device in, @Context String language);

    Device deviceDTOToDevice(DeviceDTO in);

    @Named("floorToFloorDTO")
    default FloorDTO _floorToFloorDTO(Floor floor, @Context String language) {
        return Mappers.getMapper(FloorMapper.class).floorToFloorDTO(floor, language);
    }

    @BeanMapping(ignoreByDefault = true)
    @Mappings({
        @Mapping(target = "uuid", source = "uuid"),
        @Mapping(target = "underMaintenance", source = "underMaintenance")
    })
    DeviceMaintenanceDTO deviceToDeviceMaintenanceDTO(Device device);

    @BeanMapping(ignoreByDefault = true)
    @Mappings({
        @Mapping(target = "uuid", source = "uuid"),
        @Mapping(target = "underMaintenance", source = "underMaintenance")
    })
    Device deviceMaintenanceDTOToDevice(DeviceMaintenanceDTO dto);
}