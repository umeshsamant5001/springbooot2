package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class NewsDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;

    private Category category;
    private String newsMessage;
    private Integer status;
    private String lastModifiedBy;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long lastModifiedDate;
    private String linkText;
}
