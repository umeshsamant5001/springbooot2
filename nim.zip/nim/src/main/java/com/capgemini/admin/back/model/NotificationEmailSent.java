package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@Entity
@Table(name = "notificationEmailSent", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class NotificationEmailSent implements ScheduledSent {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NotificationEmailSent_Generator")
    @SequenceGenerator(name = "NotificationEmailSent_Generator", sequenceName = "NotificationEmailSent_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notificationEmail_id")
    private NotificationEmail notificationEmail;

    @Column(name = "notificationEmail_id", updatable = false, insertable = false)
    private Long notificationEmailId;

    @Column(name = "sent_at")
    private Long sentAt;

    public void setScheduled(Scheduled scheduled) {
        this.setNotificationEmail((NotificationEmail) scheduled);
    }

    public Long getScheduledId() {
        return this.getNotificationEmailId();
    }
}