package com.capgemini.admin.back.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.capgemini.admin.back.mapper.FrontPageMapper;
import com.capgemini.admin.back.service.FrontPageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.model.FrontPage;
import com.capgemini.admin.back.model.FrontPageDTO;
import com.capgemini.admin.back.model.EnumAccess;
import lombok.Data;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@RestController
@RequestMapping(value = FrontPageController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class FrontPageController {

    static final String ROOT_API = "api/frontPages";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class FrontPageWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String title;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String path;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String icon;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String htmlclass;
        private Boolean isExternalLink;
        @Min(0)
        @Max(1000000)
        private Integer index;
        @Min(0)
        private Long parentId;
        @Min(0)
        @Max(1)
        private Integer isheadermenu;
        @Size(max = 1000)
        private List<EnumAccess> access = new ArrayList<>();
    }



    @Autowired
    private FrontPageService frontPageService;

    private FrontPage toFrontPageForCreate(FrontPageWriteRequest frontPageRequest) {
        FrontPage sanitizedFrontPage = new FrontPage();
        sanitizedFrontPage.setTitle(frontPageRequest.getTitle() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getTitle())));
        sanitizedFrontPage.setPath(frontPageRequest.getPath() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getPath())));
        sanitizedFrontPage.setIcon(frontPageRequest.getIcon() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getIcon())));
        sanitizedFrontPage.setHtmlclass(frontPageRequest.getHtmlclass() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getHtmlclass())));
        sanitizedFrontPage.setIsExternalLink(frontPageRequest.getIsExternalLink() == null
                ? null
                : Boolean.valueOf(frontPageRequest.getIsExternalLink()));
        sanitizedFrontPage.setIndex(frontPageRequest.getIndex() == null
                ? null
                : Integer.valueOf(frontPageRequest.getIndex()));
        sanitizedFrontPage.setParentId(frontPageRequest.getParentId() == null
                ? null
                : Long.valueOf(frontPageRequest.getParentId()));
        sanitizedFrontPage.setIsheadermenu(frontPageRequest.getIsheadermenu() == null
                ? null
                : Integer.valueOf(frontPageRequest.getIsheadermenu()));
        sanitizedFrontPage.setAccess(frontPageRequest.getAccess() == null
                ? new ArrayList<>()
                : new ArrayList<>(frontPageRequest.getAccess()));
        return sanitizedFrontPage;
    }


    private void applyUpdatableFields(FrontPage frontPage, FrontPageWriteRequest frontPageRequest) {
        frontPage.setTitle(frontPageRequest.getTitle() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getTitle())));
        frontPage.setPath(frontPageRequest.getPath() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getPath())));
        frontPage.setIcon(frontPageRequest.getIcon() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getIcon())));
        frontPage.setHtmlclass(frontPageRequest.getHtmlclass() == null
                ? null
                : new String(String.valueOf(frontPageRequest.getHtmlclass())));
        frontPage.setIsExternalLink(frontPageRequest.getIsExternalLink() == null
                ? null
                : Boolean.valueOf(frontPageRequest.getIsExternalLink()));
        frontPage.setIndex(frontPageRequest.getIndex() == null
                ? null
                : Integer.valueOf(frontPageRequest.getIndex()));
        frontPage.setParentId(frontPageRequest.getParentId() == null
                ? null
                : Long.valueOf(frontPageRequest.getParentId()));
        frontPage.setIsheadermenu(frontPageRequest.getIsheadermenu() == null
                ? null
                : Integer.valueOf(frontPageRequest.getIsheadermenu()));
        frontPage.setAccess(frontPageRequest.getAccess() == null
                ? new ArrayList<>()
                : new ArrayList<>(frontPageRequest.getAccess()));
    }



    @GetMapping()
    public List<FrontPage> getAllPages() {
        return frontPageService.findAll();
    }

    @GetMapping("/parent/{parentId}")
    public ResponseEntity<List<FrontPageDTO>> getPagesByParentId(
            @PathVariable("parentId") Long parentId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<FrontPage> frontPages = this.frontPageService.getAllByParentId(parentId);
        return ResponseEntity.ok(this.frontPageService.frontPageListToFrontPageDTOList().apply(frontPages));
    }

    @GetMapping("/parent")
    public ResponseEntity<List<FrontPageDTO>> getParentPages(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<FrontPage> frontPages = this.frontPageService.getAllByParentIdIsNull();
        return ResponseEntity.ok(this.frontPageService.frontPageListToFrontPageDTOList().apply(frontPages));
    }

    @PostMapping
    public ResponseEntity<FrontPageDTO> createParentPage(
            @Valid @RequestBody FrontPageWriteRequest frontPageRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        FrontPage frontPage = toFrontPageForCreate(frontPageRequest);
        if (Objects.isNull(frontPage)) {
            return ResponseEntity.badRequest().build();
        }
        frontPage.setId(null);


        frontPage = this.frontPageService.save(frontPage);
        if (Objects.isNull(frontPage)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(FrontPageMapper.INSTANCE.frontPageToFrontPageDTO(frontPage));
        }
    }

    @PutMapping("/{pageId}")
    public ResponseEntity<FrontPageDTO> updatePage(
            @PathVariable("pageId") Long pageId,
            @Valid @RequestBody FrontPageWriteRequest frontPageRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {



        FrontPage frontPage = this.frontPageService.getFrontPage(pageId);
        if (Objects.isNull(frontPage)) {
            return ResponseEntity.notFound().build();
        }

        applyUpdatableFields(frontPage, frontPageRequest);


        frontPage = this.frontPageService.save(frontPage);
        if (Objects.isNull(frontPage)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(FrontPageMapper.INSTANCE.frontPageToFrontPageDTO(frontPage));
        }
    }

    @DeleteMapping("/{pageId}")
    public ResponseEntity<Object> deletePage(@PathVariable("pageId") Long pageId) {
        FrontPage frontPage = this.frontPageService.getFrontPage(pageId);
        if (Objects.isNull(frontPage)) {
            return ResponseEntity.notFound().build();
        }

        this.frontPageService.deleteById(pageId);
        return ResponseEntity.noContent().build();
    }
}
