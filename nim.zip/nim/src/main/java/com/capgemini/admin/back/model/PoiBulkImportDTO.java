package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class PoiBulkImportDTO {
    private String poiName;
    private String confRoomMail;
    private String capacity;
}
