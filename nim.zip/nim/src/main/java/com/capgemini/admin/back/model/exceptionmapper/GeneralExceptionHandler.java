package com.capgemini.admin.back.model.exceptionmapper;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.google.gson.JsonObject;

/**
 * An exception mapper to handle the inherited GeneralExceptions
 * and emit an Http response with
 * custom json body { "errorCode":int, "message":"string debug msg",
 * "exception":"the exception name" }
 *
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class GeneralExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(GeneralException.class)
	@ResponseBody
	protected ResponseEntity<Object> handleException(GeneralException e) {
		return buildResponseEntity(e);
	}

	private ResponseEntity<Object> buildResponseEntity(GeneralException exception) {
		JsonObject json = new JsonObject();
		json.addProperty("errorCode", exception.getErrorCode());
		json.addProperty("message", "An unexpected error occurred");

		return new ResponseEntity<>(json.toString(), HttpStatus.valueOf(exception.getHttpStatus()));
	}

}
