package com.capgemini.admin.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.FloorDTO;

@Named("FloorMapper")
@Mapper(config = DtoMapperConfig.class, uses = CdmAttributesMapper.class)
public interface FloorMapper {

    FloorMapper INSTANCE = Mappers.getMapper(FloorMapper.class);

    @Mapping(source = "in", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributes" })
    Floor floorDTOToFloor(FloorDTO in);

    /**
     * <p>
     * <strong>Do not use directly</strong> : used for @Mapping() decorator.
     * </p>
     *
     * <p>
     * For more information, check BuildingMapper.
     * </p>
     */
    @Named("floorToFloorDTO")
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(source = "building", target = "building", qualifiedByName = {
                    "buildingToBuildingDTOWithoutChildren" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    FloorDTO floorToFloorDTO(Floor in, @Context String language);

    /**
     * <p>
     * <strong>Do not use directly</strong> : used for @Mapping() decorator.
     * </p>
     *
     * <p>
     * For more information, check BuildingMapper.
     * </p>
     */
    @Named("floorToFloorDTOWithoutParent")
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(target = "building", ignore = true),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    FloorDTO _floorToFloorDTOWithoutParent(Floor in, @Context String language);

    @Named("buildingToBuildingDTOWithoutChildren")
    default BuildingDTO _buildingToBuildingDTOWithoutChildren(Building building, @Context String language) {
        return Mappers.getMapper(BuildingMapper.class)._buildingToBuildingDTOWithoutChildren(building, language);
    }

}
