package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.DeclareIssueBuildingDetailsMapper;
import com.capgemini.admin.back.mapper.DeclareIssueDetailsMapper;
import com.capgemini.admin.back.model.DeclareIssueBuildingDetails;
import com.capgemini.admin.back.model.DeclareIssueBuildingDetailsDTO;

import com.capgemini.admin.back.model.DeclareIssueDTO;
import com.capgemini.admin.back.model.DeclareIssueDetails;
import com.capgemini.admin.back.model.DeclareIssueDetailsDTO;

import com.capgemini.admin.back.model.DeclareIssueUpdateEmailRequest;
import com.capgemini.admin.back.service.DeclareIssueDetailsService;
import com.capgemini.admin.back.service.DeclareIssueService;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * REST controller for managing declared issues.
 * Provides endpoints to retrieve issue data globally or by country.
 */
@Slf4j
@RestController
@RequestMapping(value = DeclareIssueController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class DeclareIssueController {

    public static final String ROOT_API = "api/declareIssue";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class DeclareIssueReferenceInput {
        @NotNull
        @Min(1)
        private Long id;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class DeclareIssueCreateInput {
        @NotNull
        @Min(1)
        private Long countryId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String emailId;
        @NotNull
        @Valid
        private DeclareIssueReferenceInput declareIssue;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class DeclareIssueBuildingCreateInput {
        @NotNull
        @Min(1)
        private Long buildingId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String emailId;
        @NotNull
        @Valid
        private DeclareIssueReferenceInput declareIssue;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class DeclareIssueEmailUpdateInput {
        @NotNull
        @Min(1)
        private Long id;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String emailId;
    }

    





    @Autowired
    private DeclareIssueService declareIssueService;

    @Autowired
    private DeclareIssueDetailsService declareIssueDetailsService;

    /**
     * Retrieves all declared issues.
     *
     * @param language the preferred language for the response (default is "en")
     * @return a list of {@link DeclareIssueDTO} objects
     */

    @GetMapping
    public ResponseEntity<List<DeclareIssueDTO>> getAllDeclareIssues() {
        List<DeclareIssueDTO> declareIssueDTOs = new ArrayList<>();
        declareIssueDTOs = declareIssueService.getAllDeclareIssues();
        return ResponseEntity.ok(declareIssueDTOs);
    }

    /**
     * Searches for declare issue items for specific Coubtry Id.
     *
     * @param countryId The ID of the Country to fetch issues.
     * @param language  The language to use for the request (default is English
     *                  if not provided).
     * @return ResponseEntity containing a list of DeclareIssuesDetails objects
     *         matching the search criteria.
     */
    @GetMapping("/country/{countryId}")
    public ResponseEntity<List<DeclareIssueDetailsDTO>> getDeclreIssuesByCountry(
            @PathVariable("countryId") Long countryId) {
        if (Objects.isNull(countryId)) {
            return ResponseEntity.badRequest().build();
        }
        List<DeclareIssueDetailsDTO> result = declareIssueDetailsService.findByCountryId(countryId);
        return ResponseEntity.ok(result);
    }

    /**
     * Updates email IDs for Declare Issue Details based on the given countryId
     *
     * @param countryId           the ID of the country for which emailIds need to
     *                            be updated
     * @param emailUpdateRequests list of requests containing updated emailIds. Each
     *                            request must include an ID that
     *                            exists in the DeclareIssueDetails entity, as this
     *                            ID is used to update the corresponding email ID.
     * @return ResponseEntity containing the updated DeclareIssueDetailsDTO list
     */
    @PutMapping("/country/{countryId}")
    public ResponseEntity<List<DeclareIssueDetailsDTO>> updateEmailIds(
            @PathVariable Long countryId,
            @Valid @RequestBody List<DeclareIssueEmailUpdateInput> emailUpdateRequests) {

        // Defense against unsafe object binding: copy only writable fields expected
        // by this update operation before passing data to the service layer.
        List<DeclareIssueUpdateEmailRequest> sanitizedEmailUpdateRequests = this
                .toSanitizedEmailUpdateRequests(emailUpdateRequests);


        List<DeclareIssueDetailsDTO> updatedDetails = declareIssueDetailsService
                .updateEmailIdsByCountryIdAndDeclareIsuueDetailsId(
                        countryId, sanitizedEmailUpdateRequests);



        return ResponseEntity.ok(updatedDetails);
    }


    /**
     * Delete Declare Issue Details based on the given countryId
     *
     * @param countryId                 the ID of the country for which emailIds
     *                                  need to be updated
     * @param deleteDeclareIssueRequest list of requests containing declare issue
     *                                  Ids
     * @return ResponseEntity with no content if successful.
     */
    @DeleteMapping("/country/{countryId}")
    public ResponseEntity<Object> deleteDeclareIssueDetails(
            @PathVariable Long countryId,
            @RequestBody List<DeclareIssueUpdateEmailRequest> deleteDeclareIssueRequest) {

        declareIssueDetailsService.deleteDeclareIsuueDetailsIdByCountryId(
                countryId, deleteDeclareIssueRequest);

        return ResponseEntity.noContent().build();

    }

    /**
     * Handles HTTP POST requests to create a new DeclareIssueDetails entry.
     * 
     * @param declareIssueRequest The request payload containing issue details.
     * @param language            Optional header to specify response language
     *                            (default is "en").
     * @return ResponseEntity containing the created DeclareIssueDetailsDTO or
     *         appropriate error status.
     */
    @PostMapping
    public ResponseEntity<DeclareIssueDetailsDTO> createDeclareIssue(
            @Valid @RequestBody DeclareIssueCreateInput declareIssueRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (declareIssueRequest == null) {
            return ResponseEntity.badRequest().build();
        }

        // Defense against unsafe object binding: copy only writable scalar fields
        // into a dedicated write-input object before invoking the persistence flow.
        DeclareIssueDetailsService.DeclareIssueWriteInput sanitizedDeclareIssueWriteInput = this
                .toSanitizedDeclareIssueWriteInput(declareIssueRequest);


        DeclareIssueDetails declareIssue = declareIssueDetailsService
                .createDeclareIssue(sanitizedDeclareIssueWriteInput);







        if (declareIssue == null) {
            log.error("Failed to create DeclareIssueDetails");
            return ResponseEntity.internalServerError().build();
        }

        DeclareIssueDetailsDTO responseDTO = DeclareIssueDetailsMapper.INSTANCE
                .declareIssueDetailsToDeclareIssueDetailsDTO(declareIssue);

        return ResponseEntity.ok(responseDTO);
    }

    /**
     * Handles HTTP POST requests to create a new DeclareIssueBuildingDetails entry.
     * 
     * @param declareIssueRequest The request payload containing issue details.
     * @param language            Optional header to specify response language
     *                            (default is "en").
     * @return ResponseEntity containing the created DeclareIssueBuildingDetailsDTO
     *         or
     *         appropriate error status.
     */
    @PostMapping(value = "/building")
    public ResponseEntity<DeclareIssueBuildingDetailsDTO> createDeclareIssueBuildingDetails(
            @Valid @RequestBody DeclareIssueBuildingCreateInput declareIssueBuildingRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (declareIssueBuildingRequest == null) {
            return ResponseEntity.badRequest().build();
        }

        // Defense against unsafe object binding: copy only writable scalar fields
        // into a dedicated write-input object before invoking the persistence flow.
        DeclareIssueDetailsService.DeclareIssueBuildingWriteInput sanitizedDeclareIssueBuildingWriteInput = this
                .toSanitizedDeclareIssueBuildingWriteInput(declareIssueBuildingRequest);


        DeclareIssueBuildingDetails declareIssue = declareIssueDetailsService
                .createDeclareIssueBuildingDetails(sanitizedDeclareIssueBuildingWriteInput);








        if (declareIssue == null) {
            log.error("Failed to create DeclareIssueBuildingDetails");
            return ResponseEntity.internalServerError().build();
        }

        DeclareIssueBuildingDetailsDTO responseDTO = DeclareIssueBuildingDetailsMapper.INSTANCE
                .declareIssueBuildingDetailsToDeclareIssueBuildingDetailsDTO(declareIssue);

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Updates email IDs for Declare Issue for Building Details based on the given
     * buildingId
     *
     * @param buildingId          the ID of the building for which emailIds need to
     *                            be updated
     * @param emailUpdateRequests list of requests containing updated emailIds. Each
     *                            request must include an ID that
     *                            exists in the DeclareIssueBuildingDetails entity,
     *                            as this
     *                            ID is used to update the corresponding email ID.
     * @return ResponseEntity containing the updated DeclareIssueDetailsDTO list
     */
    @PutMapping("/building/{buildingId}")
    public ResponseEntity<List<DeclareIssueBuildingDetailsDTO>> updateEmailIdsForDeclareIssueBuildingDetails(
            @PathVariable Long buildingId,
            @Valid @RequestBody List<DeclareIssueEmailUpdateInput> emailUpdateRequests) {

        // Defense against unsafe object binding: copy only writable fields expected
        // by this update operation before passing data to the service layer.
        List<DeclareIssueUpdateEmailRequest> sanitizedEmailUpdateRequests = this
                .toSanitizedEmailUpdateRequests(emailUpdateRequests);


        List<DeclareIssueBuildingDetailsDTO> updatedDetails = declareIssueDetailsService
                .updateEmailIdsByBuildingIdAndDeclareIsuueDetailsId(
                        buildingId, sanitizedEmailUpdateRequests);



        return ResponseEntity.ok(updatedDetails);
    }


    /**
     * Searches for declare issue items for specific building Id.
     *
     * @param buildingId The ID of the Building to fetch issues.
     * @param language   The language to use for the request (default is English
     *                   if not provided).
     * @return ResponseEntity containing a list of DeclareIssuesBuildingDetails
     *         objects
     *         matching the search criteria.
     */
    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<DeclareIssueBuildingDetailsDTO>> findByBuildingAndDeclareIssue(
            @PathVariable("buildingId") Long buildingId) {
        if (Objects.isNull(buildingId)) {
            return ResponseEntity.badRequest().build();
        }
        List<DeclareIssueBuildingDetailsDTO> result = declareIssueDetailsService
                .findByBuildingAndDeclareIssue(buildingId);
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }

    /**
     * Delete DeclareIssueBuildingDetails based on the given buildingId
     *
     * @param buildingId                 the ID of the buildingId for which emailIds
     *                                  need to be updated
     * @param deleteDeclareIssueRequest list of requests containing declare issue
     *                                  Ids
     * @return ResponseEntity with no content if successful.
     */
    @DeleteMapping("/building/{buildingId}")
    public ResponseEntity<Object> deleteDeclareIssueBuildingDetails(
            @PathVariable Long buildingId,
            @RequestBody List<DeclareIssueUpdateEmailRequest> deleteDeclareIssueRequest) {

        declareIssueDetailsService.deleteDeclareIsuueBuildingDetailsIdByBuildingId(
            buildingId, deleteDeclareIssueRequest);

        return ResponseEntity.noContent().build();

    }

    private DeclareIssueDetailsService.DeclareIssueWriteInput toSanitizedDeclareIssueWriteInput(
            DeclareIssueCreateInput declareIssueRequest) {
        if (declareIssueRequest == null) {
            return new DeclareIssueDetailsService.DeclareIssueWriteInput(null, null, null);
        }

        Long sanitizedCountryId = declareIssueRequest.getCountryId() == null
                ? null
                : Long.valueOf(String.valueOf(declareIssueRequest.getCountryId()));
        Long sanitizedDeclareIssueId = declareIssueRequest.getDeclareIssue() == null
                ? null
                : (declareIssueRequest.getDeclareIssue().getId() == null
                        ? null
                        : Long.valueOf(String.valueOf(declareIssueRequest.getDeclareIssue().getId())));
        String sanitizedEmailId = declareIssueRequest.getEmailId() == null
                ? null
                : new String(String.valueOf(declareIssueRequest.getEmailId()));

        return new DeclareIssueDetailsService.DeclareIssueWriteInput(
                sanitizedCountryId,
                sanitizedDeclareIssueId,
                sanitizedEmailId);
    }

    private DeclareIssueDetailsService.DeclareIssueBuildingWriteInput toSanitizedDeclareIssueBuildingWriteInput(
            DeclareIssueBuildingCreateInput declareIssueBuildingRequest) {
        if (declareIssueBuildingRequest == null) {
            return new DeclareIssueDetailsService.DeclareIssueBuildingWriteInput(null, null, null);
        }

        Long sanitizedBuildingId = declareIssueBuildingRequest.getBuildingId() == null
                ? null
                : Long.valueOf(String.valueOf(declareIssueBuildingRequest.getBuildingId()));
        Long sanitizedDeclareIssueId = declareIssueBuildingRequest.getDeclareIssue() == null
                ? null
                : (declareIssueBuildingRequest.getDeclareIssue().getId() == null
                        ? null
                        : Long.valueOf(String.valueOf(declareIssueBuildingRequest.getDeclareIssue().getId())));
        String sanitizedEmailId = declareIssueBuildingRequest.getEmailId() == null
                ? null
                : new String(String.valueOf(declareIssueBuildingRequest.getEmailId()));

        return new DeclareIssueDetailsService.DeclareIssueBuildingWriteInput(
                sanitizedBuildingId,
                sanitizedDeclareIssueId,
                sanitizedEmailId);
    }

    private List<DeclareIssueUpdateEmailRequest> toSanitizedEmailUpdateRequests(
            List<DeclareIssueEmailUpdateInput> emailUpdateRequests) {
        List<DeclareIssueUpdateEmailRequest> sanitizedRequests = new ArrayList<>();
        if (emailUpdateRequests == null) {
            return sanitizedRequests;
        }

        for (DeclareIssueEmailUpdateInput request : emailUpdateRequests) {
            DeclareIssueUpdateEmailRequest sanitizedRequest = new DeclareIssueUpdateEmailRequest();
            if (request == null) {
                sanitizedRequest.setId(null);
                sanitizedRequest.setEmailId(null);
            } else {
                sanitizedRequest.setId(request.getId() == null ? null : Long.valueOf(request.getId()));
                sanitizedRequest.setEmailId(request.getEmailId() == null
                        ? null
                        : new String(String.valueOf(request.getEmailId())));
            }
            sanitizedRequests.add(sanitizedRequest);
        }


        return sanitizedRequests;
    }


    



}