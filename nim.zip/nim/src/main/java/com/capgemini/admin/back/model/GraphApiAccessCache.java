package com.capgemini.admin.back.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "graph_api_access_cache")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GraphApiAccessCache {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "room_email", unique = true, nullable = false)
    private String roomEmail;

    @Column(name = "access_status", nullable = false) // "Yes" or "No"
    private Boolean accessStatus;

    @Column(name = "last_checked_at", nullable = false)
    private LocalDateTime lastCheckedAt;
}
