package com.capgemini.admin.back.model.procedure;

import lombok.Data;

@Data
public class LogAuditTranslationDTO {
    private Long logId;
    private String description;
    private String status;
    private String createdDate;
    private String translationServiceType;
    private String exception;
}