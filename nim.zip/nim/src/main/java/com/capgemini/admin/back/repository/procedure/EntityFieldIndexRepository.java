package com.capgemini.admin.back.repository.procedure;

import java.util.List;
import com.capgemini.admin.back.model.procedure.FrontLabel;
import com.capgemini.admin.back.model.procedure.EntityFieldIndexDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * we extends FrontLabel because we must have a Entity object
 */
@Repository
public interface EntityFieldIndexRepository extends JpaRepository<FrontLabel, Long> {

    @Procedure(name = "GetEntityMappingByEntity")
    List<EntityFieldIndexDTO> getEntityMappingByEntity(@Param("Entity") String entity);

    @Procedure(name = "GetTranslationEntity")
    List<String> getTranslationEntity();

}
