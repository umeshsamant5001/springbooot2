package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.admin.back.model.FrontPage;

@Repository
public interface FrontPageRepository extends JpaRepository<FrontPage, Long> {

    // Controller only
    @RestResource(exported = false)
    List<FrontPage> findAllByParentId(@Param("parentId") @RequestParam("parentId") Long parentId);

    // Controller only
    @RestResource(exported = false)
    List<FrontPage> findAllByParentIdIsNull();

    @Query("SELECT fp FROM FrontPage fp WHERE fp.title = :title")
    FrontPage findIdByTitles(@Param("title") String title);

}
