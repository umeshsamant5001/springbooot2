package com.capgemini.admin.back.scheduled.scheduled;

import java.util.Objects;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;

/**
 * Class for the type of Scheduled to send "now".
 */
public class NowScheduledAction<N extends Scheduled, S extends ScheduledSent> extends ScheduledAction<N, S> {

    public boolean checkType(N scheduled) {
        return Objects.isNull(scheduled.getStartDate()) && Objects.isNull(scheduled.getEndDate());
    }

    @Override
    public boolean shouldBeSent() {
        // If the Scheduled don't have a ScheduledSent, we should send it.
        return Objects.isNull(this.lastScheduledSent);
    }

    @Override
    public boolean wasLastSent() {
        // Once sent, it is necessarily the last
        return true;
    }

}
