package com.capgemini.admin.back.model;

public enum EnumStatusScheduled {
    RUNNING, STOPPED
}