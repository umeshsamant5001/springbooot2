package com.capgemini.admin.back.config;

import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.http.GraphServiceException;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.requests.EventCollectionPage;
import com.microsoft.graph.requests.GraphServiceClient;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;

import com.microsoft.graph.requests.UserCollectionPage;

@Component
@Slf4j
public class GraphHelper {

    private final ApplicationProperties applicationProperties;
    private GraphServiceClient<okhttp3.Request> graphClient;
    private GraphServiceClient<okhttp3.Request> graphClientForSendEmail;

    @Autowired
    public GraphHelper(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    public GraphServiceClient<okhttp3.Request> getGraphClient() {
        if (graphClient == null) {
            ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getGraphApi().getClientId())
                    .clientSecret(applicationProperties.getAzure().getGraphApi().getClientSecret())
                    .build();
            
            TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(
                    List.of(applicationProperties.getAzure().getGraphApi().getScopeUrl()),
                    credential);

            graphClient = GraphServiceClient.builder()
                    .authenticationProvider(authProvider)
                    .buildClient();
        }
        return graphClient;
    }
    
    public GraphServiceClient<okhttp3.Request> getGraphClientForSendEmail() {
        if (graphClientForSendEmail == null) {
            ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getGraphApiSendEmail().getClientId())
                    .clientSecret(applicationProperties.getAzure().getGraphApiSendEmail().getClientSecret())
                    .build();

            TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(
                    List.of(applicationProperties.getAzure().getGraphApiSendEmail().getScopeUrl()),
                    credential);

            graphClientForSendEmail = GraphServiceClient.builder()
                    .authenticationProvider(authProvider)
                    .buildClient();
        }
        return graphClientForSendEmail;
    }
                
    /**
     * @param roomEmail email associated with meeting room
     * @return true if at least one of the Graph calls succeeds; false if both fail or an unexpected error occurs
    */
    public boolean hasGraphAPIAccess(String roomEmail) {    
        String sanitizedRoomEmail = sanitizeForLog(roomEmail);
        // Get Object ID of the user associated with the room email.
        String objectId = getUserObjectId(roomEmail);
        if (Objects.isNull(objectId)) {
            log.info("Room mailbox {} not found (users() 404/403).", sanitizedRoomEmail);
            return false;
        }
        else{
            log.info("Room mailbox {} found (users() 200).", sanitizedRoomEmail);
        }

        // 2) CalendarView call
        OffsetDateTime startUtc = OffsetDateTime.now(ZoneOffset.UTC);
        OffsetDateTime endUtc = startUtc.plusMinutes(15);
        try {

            var options = List.of(
                new QueryOption("startDateTime", startUtc.toString()),
                new QueryOption("endDateTime",   endUtc.toString()),
                new QueryOption("$orderby", "start/dateTime"),
                new HeaderOption("Prefer", "outlook.timezone=\"UTC\"")
            );

            EventCollectionPage page = getGraphClient()
                .users(objectId)
                .calendarView()
                .buildRequest(options)
                .get();

            int count = (page.getCurrentPage() != null) ? page.getCurrentPage().size() : 0;
            log.info("CalendarView OK for {} ({} events between {} and {})", sanitizedRoomEmail, count, startUtc, endUtc);
            return true;

        } catch (GraphServiceException gse) {
            Integer status = gse.getResponseCode();
            log.warn("CalendarView failed for {}: status={}, message={}",
                    sanitizedRoomEmail, status, gse.getMessage());
            return false;
        } catch (Exception e) {
            log.error("Unexpected error for {}: {}", sanitizedRoomEmail, e.getMessage(), e);
            return false;
        }

    }
    
    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

    //Added new implememtation for filtering instead of using getGraphClient().users(roomEmail).buildRequest().get()in earlier metho
    /*
     * @param roomEmail email associated with meeting room
     * @return the Object ID of the user if found; null if not found or an error occurs.
     */
    private String getUserObjectId(String roomEmail) {
        String sanitizedRoomEmail = sanitizeForLog(roomEmail);
        String escapedEmail = roomEmail.replace("'", "''");

        try {
            UserCollectionPage users = getGraphClient()
                    .users()
                    .buildRequest()
                    .filter("mail eq '" + escapedEmail + "'")
                    .select("id")
                    .get();

            if (users != null
                    && users.getCurrentPage() != null
                    && !users.getCurrentPage().isEmpty()) {

                String objectId = users.getCurrentPage().get(0).id;

                log.info("Found Object ID for {} : {}",
                        sanitizedRoomEmail,
                        objectId);

                return objectId;
            }

            return null;

        } catch (GraphServiceException gse) {
            log.warn("User lookup for {} failed: status={}, message={}",
                    sanitizedRoomEmail,
                    gse.getResponseCode(),
                    gse.getMessage());
            return null;

        } catch (Exception e) {
            log.error("User lookup for {} unexpected error: {}",
                    sanitizedRoomEmail,
                    e.getMessage(),
                    e);
            return null;
        }
    }

    
}
