package com.capgemini.admin.back.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.admin.back.model.AllLocationsByUser;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.UserRoleLocation;
import com.capgemini.admin.back.repository.UserRoleLocationRepository;

@Service
public class UserRoleLocationService {

    @Autowired
    private UserRoleLocationRepository userRoleLocationRepository;

    /**
     * Checks if the user has global access (i.e., unrestricted access to all locations).
     *
     * @param userId The ID of the user.
     * @return true if the user has global access, false otherwise.
     */
    public boolean userIsGlobal(Long userId) {
        Integer result = this.userRoleLocationRepository.userIsGlobal(userId);

        if (Integer.valueOf(1).equals(result)) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    /**
     * Retrieves all authorized locations for a user, grouped by level (COUNTRY, CITY, SITE, BUILDING).
     *
     * @param userId The ID of the user.
     * @return A map of LevelEnum to a map of location IDs and their corresponding levels.
     */
    public Map<LevelEnum, Map<Long, LevelEnum>> getLocationsByUserId(Long userId) {

        List<AllLocationsByUser> allLocationsByUserList = this.userRoleLocationRepository.getAllLocationsByUser(userId);

        Map<LevelEnum, Map<Long, LevelEnum>> result = new HashMap<>();

        for (AllLocationsByUser allLocationsByUser : allLocationsByUserList) {
            LevelEnum fromLevel = this.getFromLevel(allLocationsByUser);

            this.addIdToMap(result, LevelEnum.COUNTRY, allLocationsByUser.getCountryId(), fromLevel);
            this.addIdToMap(result, LevelEnum.CITY, allLocationsByUser.getCityId(), fromLevel);
            this.addIdToMap(result, LevelEnum.SITE, allLocationsByUser.getSiteId(), fromLevel);
            this.addIdToMap(result, LevelEnum.BUILDING, allLocationsByUser.getBuildingId(), fromLevel);
        }

        return result;
    }

    /**
     * Retrieves all UserRoleLocation entries for a given user and initializes their roles.
     *
     * @param userId The ID of the user.
     * @return A list of UserRoleLocation entities.
     */
    @Transactional
    public List<UserRoleLocation> findByUserId(Long userId) {
        List<UserRoleLocation> result = this.userRoleLocationRepository.findByUserId(userId);

        for (UserRoleLocation userRoleLocation : result) {
            Hibernate.initialize(userRoleLocation.getRole());
        }

        return result;
    }

    /**
     * Retrieves all UserRoleLocation entries and initializes their roles.
     *
     * @return A list of all UserRoleLocation entities.
     */
    @Transactional
    public List<UserRoleLocation> getAllWithRole() {
        List<UserRoleLocation> result = this.userRoleLocationRepository.findAll();

        for (UserRoleLocation userRoleLocation : result) {
            Hibernate.initialize(userRoleLocation.getRole());
        }

        return result;
    }

    /**
     * Filters a list of floor IDs based on the user's access rights.
     *
     * @param userId    The ID of the user.
     * @param floorsIds The list of floor IDs to filter.
     * @return A list of authorized floor IDs.
     */
    public List<Long> filterAuthorizedFloorId(Long userId, List<Long> floorsIds) {
        return this.userRoleLocationRepository.filterAuthorizedFloorId(userId, floorsIds);
    }

    /**
     * Filters a list of POI IDs based on the user's access rights.
     *
     * @param userId    The ID of the user.
     * @param floorsIds The list of POI IDs to filter.
     * @return A list of authorized POI IDs.
     */
    public List<Long> filterAuthorizedPoiId(Long userId, List<Long> floorsIds) {
        return this.userRoleLocationRepository.filterAuthorizedPoiId(userId, floorsIds);
    }

    /**
     * Filters a list of device UUIDs based on the user's access rights.
     *
     * @param userId      The ID of the user.
     * @param deviceUuids The list of device UUIDs to filter.
     * @return A list of authorized device UUIDs.
     */
    public List<String> filterAuthorizedDeviceId(Long userId, List<String> deviceUuids) {
        return this.userRoleLocationRepository.filterAuthorizedDeviceId(userId, deviceUuids);
    }

    /**
     * Filters a list of Cisco device IDs based on the user's access rights.
     *
     * @param userId    The ID of the user.
     * @param deviceIds The list of Cisco device IDs to filter.
     * @return A list of authorized Cisco device IDs.
     */
    public List<String> filterAuthorizedCiscoDeviceByDeviceId(Long userId, List<String> deviceIds) {
        return userRoleLocationRepository.filterAuthorizedCiscoDeviceByDeviceId(userId, deviceIds);
    }

    /**
     * 
     * @param map       The map to add information in.
     * @param level     The level of the id.
     * @param id        The id of the object.
     * @param levelFrom The level from where the authorization come from.
     */
    private void addIdToMap(
            Map<LevelEnum, Map<Long, LevelEnum>> map,
            LevelEnum level,
            Long id,
            LevelEnum levelFrom) {
        if (!map.containsKey(level)) {
            map.put(level, new HashMap<Long, LevelEnum>());
        }

        if (Objects.nonNull(id)
                && !map.get(level).containsKey(id)) {
            map.get(level).put(id, levelFrom);
        }
    }

    /**
     * Determines the most specific level (COUNTRY, CITY, SITE, BUILDING) from which the user has access.
     *
     * @param allLocationsByUser The location access record.
     * @return The most specific LevelEnum, or null if none is set.
     */
    private LevelEnum getFromLevel(AllLocationsByUser allLocationsByUser) {
        if (allLocationsByUser.getCountryLevel() == 1) {
            return LevelEnum.COUNTRY;
        }

        if (allLocationsByUser.getCityLevel() == 1) {
            return LevelEnum.CITY;
        }

        if (allLocationsByUser.getSiteLevel() == 1) {
            return LevelEnum.SITE;
        }

        if (allLocationsByUser.getBuildingLevel() == 1) {
            return LevelEnum.BUILDING;
        }

        return null;
    }

    // Single unassign method for special role locations
    @Transactional
    public void unassignSoSpecialRoleLocation(Long userId, Long roleId) {
        userRoleLocationRepository.unassignSoSpecialRoleLocation(userId, roleId);

    }
    // multiple unassign method for special role locations
    @Transactional
    public void unassignSoSpecialRoleLocation(Long userId, List<Long> roleIds) {
        userRoleLocationRepository.unassignSoSpecialRoleLocation(userId, roleIds);
    }
}
