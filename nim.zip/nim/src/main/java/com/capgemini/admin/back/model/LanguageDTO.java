package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class LanguageDTO {
    private String locale;
    private String name;
}
