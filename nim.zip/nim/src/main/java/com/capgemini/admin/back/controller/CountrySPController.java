package com.capgemini.admin.back.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.model.CountrySPDTO;
import com.capgemini.admin.back.service.CountrySPService;
import java.util.List;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = CountrySPController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CountrySPController {

    static final String ROOT_API = "/api/SPcountries";

    @Autowired
    private CountrySPService countrySPService;

    /**
     * Retrieves a filtered list of countries based on language, user role, and optional parameters.
     *
     * This endpoint returns a list of CountrySPDTO objects, filtered according to the specified
     * role ID, asset code, and whether only secure buildings should be included. The results are
     * localized based on the provided language.
     *
     * @param language the language preference for localization
     * @param roleId the role ID used for filtering country access
     * @param assetCode optional asset code used for additional filtering
     * @param onlySecureBuilding optional flag to include only secure buildings (default is false)
     * @return ResponseEntity containing the filtered list of CountrySPDTO objects with HTTP 200 status
     */
    @Transactional(readOnly = true)
    @GetMapping("/{language}/{roleId}")
    public ResponseEntity<List<CountrySPDTO>> getCountryList(
            @PathVariable String language,
            @PathVariable Integer roleId,
            @RequestParam(required = false) String assetCode,
            @RequestParam(required = false, defaultValue = "false") Boolean onlySecureBuilding) {

        List<CountrySPDTO> countrySPDTOs = countrySPService.getFilteredCountryList(language, roleId, assetCode,
                onlySecureBuilding);
        return ResponseEntity.ok(countrySPDTOs);
    }
}
