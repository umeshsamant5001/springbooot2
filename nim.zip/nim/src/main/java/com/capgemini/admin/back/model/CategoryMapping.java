package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "category_mapping")
public class CategoryMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CategoryMapping_Generator")
    @SequenceGenerator(name = "CategoryMapping_Generator", sequenceName = "CategoryMapping_Sequence")
    private Long id;

    @Column(name = "space_type_id")
    private Long spaceTypeId;
    @OneToOne(mappedBy = "categoryMapping")
    private SpaceType spaceType;

    @Column(name = "category")
    private String category;

}
