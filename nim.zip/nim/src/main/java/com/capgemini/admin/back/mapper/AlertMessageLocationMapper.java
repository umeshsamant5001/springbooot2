package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.AlertMessageLocation;
import com.capgemini.admin.back.model.AlertMessageLocationDTO;

@Mapper(config = DtoMapperConfig.class)
public interface AlertMessageLocationMapper {

    AlertMessageLocationMapper INSTANCE = Mappers.getMapper(AlertMessageLocationMapper.class);

    @Mapping(target = "alertMessage", ignore = true)
    AlertMessageLocation alertMessageLocationDTOToAlertMessageLocation(AlertMessageLocationDTO in);

    // setting the alertMessageId from alert_message (table) primary id
    @Mapping(target = "alertMessageId", source = "alertMessage.id")
    AlertMessageLocationDTO alertMessageLocationToAlertMessageLocationDTO(AlertMessageLocation in);

}
