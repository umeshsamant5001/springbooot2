package com.capgemini.admin.back.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.admin.back.service.SiteService;
import com.capgemini.admin.back.service.TreeService;


import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.mapper.CityMapper;
import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.model.CityDTO;
import com.capgemini.admin.back.model.LevelEnum;

import com.capgemini.admin.back.service.CityService;
import com.capgemini.admin.back.service.CityService.CityUpsertInput;





import lombok.Data;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@RestController
@Validated
@RequestMapping(value = CityController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CityController {


    static final String ROOT_API = "api/city";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class CityCreateRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Min(0)
        private Long cdmKeyId;
        @Min(0)
        private Long cdmStateId;
        private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes = new HashMap<>();
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class CityUpdateRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Min(0)
        private Long cdmKeyId;
        @Min(0)
        private Long cdmStateId;
        private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes = new HashMap<>();
    }



    @Autowired
    private SiteService siteService;

    @Autowired
    private CityService cityService;
    @Autowired
    private TreeService treeService;

    /**
     * Retrieves a list of all cities, filtered through a tree structure if applicable.
     * 
     * This endpoint supports internationalization by accepting an optional "Accept-Language" 
     * header to localize the city data accordingly.
     *
     * @param language the language code from the "Accept-Language" header (default is "en")
     * @return ResponseEntity containing a list of CityDTOs without site information,
     *         or a 204 No Content response if no cities are found.
     */
    @GetMapping
    public ResponseEntity<List<CityDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<City> cities = cityService.getAll();
        cities = treeService.filterTree(cities);

        if (CollectionUtils.isEmpty(cities)) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity
                .ok(cities
                        .stream()
                        .map(city -> {
                            return CityMapper.INSTANCE.cityToCityDTONoSites(city, language);
                        })
                        .collect(Collectors.toList()));
    }
    
    /**
     * Retrieves detailed information about a specific city by its ID.
     *
     * This endpoint supports internationalization via the "Accept-Language" header
     * and returns a localized CityDTO. It also filters the city data through a tree
     * structure for access control or hierarchical filtering.
     *
     * If the city is not found, a 404 Not Found response is returned.
     * If the city is filtered out (e.g., due to access restrictions), a 401 Unauthorized response is returned.
     * Otherwise, the response includes the city details along with the number of associated child sites.
     *
     * @param cityId   the ID of the city to retrieve
     * @param language the language code from the "Accept-Language" header (default is "en")
     * @return ResponseEntity containing the CityDTO or an appropriate HTTP status
     */
    @GetMapping("/{cityId}")
    public ResponseEntity<CityDTO> getCity(
            @PathVariable @Min(1) Long cityId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        if (Objects.isNull(cityId) || cityId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCityIds = treeService.filterId(LevelEnum.CITY, List.of(cityId));
        if (CollectionUtils.isEmpty(authorizedCityIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long authorizedCityId = authorizedCityIds.get(0);
        City city = cityService.getCity(authorizedCityId);

        if (Objects.isNull(city)) {
            return ResponseEntity.notFound().build();
        }

        city = treeService.filterTree(city);
        if (Objects.isNull(city)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        CityDTO cityDto = CityMapper.INSTANCE.cityToCityDTO(city, language);
        cityDto.setNbChilds(siteService.countByCityId(cityDto.getId()));
        return ResponseEntity.ok(cityDto);
    }

    /**
     * Creates a new city entry based on the provided CityDTO.
     *
     * This endpoint accepts a JSON payload representing the city details and supports
     * internationalization via the "Accept-Language" header. The city is mapped from DTO
     * to entity, timestamped with the current modification time, and persisted.
     *
     * On successful creation, it returns the created CityDTO with a 201 Created status.
     * If an error occurs during saving, it returns a 500 Internal Server Error.
     *
     * @param cityDTO  the city data to be created, validated from the request body
     * @param language the language code from the "Accept-Language" header (default is "en")
     * @return ResponseEntity containing the created CityDTO or an appropriate HTTP status
     */
    @PostMapping
    public ResponseEntity<CityDTO> postCity(
            @Valid @RequestBody CityCreateRequest cityRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        

        CityUpsertInput safeCityInput = this.toCityInputForCreate(cityRequest);

        try {
            City citySave = cityService.save(safeCityInput);




            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(CityMapper.INSTANCE.cityToCityDTO(citySave, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }


    /**
     * Deletes a city by its ID.
     *
     * This endpoint checks if the city exists before attempting deletion. If the city
     * is not found, it returns a 404 Not Found response. If the city exists, it is deleted,
     * and a 204 No Content response is returned to indicate successful deletion.
     *
     * @param cityId the ID of the city to delete
     * @return ResponseEntity with appropriate HTTP status (404 if not found, 204 if deleted)
     */
    @DeleteMapping("/{cityId}")
    public ResponseEntity<Object> deleteCity(@PathVariable @Min(1) Long cityId) {

        if (Objects.isNull(cityId) || cityId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCityIds = treeService.filterId(LevelEnum.CITY, List.of(cityId));
        if (CollectionUtils.isEmpty(authorizedCityIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long authorizedCityId = authorizedCityIds.get(0);
        City city = cityService.getCity(authorizedCityId);
        if (Objects.isNull(city)) {
            return ResponseEntity.notFound().build();
        }

        cityService.deleteById(authorizedCityId);
        return ResponseEntity.noContent().build();
    }


    /**
     * Updates an existing city identified by its ID with the provided CityDTO data.
     *
     * This endpoint accepts a JSON payload representing the updated city details and supports
     * internationalization via the "Accept-Language" header. The city is mapped from DTO to entity
     * and passed to the service layer for updating.
     *
     * On successful update, it returns the updated CityDTO with a 200 OK status.
     * If an error occurs during the update process, it returns a 500 Internal Server Error.
     *
     * @param cityId   the ID of the city to update
     * @param cityDTO  the updated city data, validated from the request body
     * @param language the language code from the "Accept-Language" header (default is "en")
     * @return ResponseEntity containing the updated CityDTO or an appropriate HTTP status
     */
    @PutMapping("/{cityId}")
    public ResponseEntity<CityDTO> updateCity(
            @PathVariable @Min(1) Long cityId,
            @Valid @RequestBody CityUpdateRequest cityRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {



        if (Objects.isNull(cityId) || cityId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCityIds = treeService.filterId(LevelEnum.CITY, List.of(cityId));
        if (CollectionUtils.isEmpty(authorizedCityIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long authorizedCityId = authorizedCityIds.get(0);
        CityUpsertInput safeCityInput = this.toCityInputForUpdate(cityRequest);

        try {
            City CitySave = cityService.updateCity(
                    authorizedCityId,
                    safeCityInput);




            return ResponseEntity.ok(CityMapper.INSTANCE.cityToCityDTO(CitySave, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }




















    private CityUpsertInput toCityInputForCreate(CityCreateRequest cityRequest) {
        return new CityUpsertInput(
                cityRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(cityRequest.getCdmKeyId())),
                new HashMap<>(this.sanitizeAttributes(cityRequest.getAttributes())),
                cityRequest.getTitleEn() == null
                        ? null
                        : new String(String.valueOf(cityRequest.getTitleEn())),
                cityRequest.getTitleFr() == null
                        ? null
                        : new String(String.valueOf(cityRequest.getTitleFr())),
                cityRequest.getCdmStateId() == null
                        ? null
                        : Long.valueOf(String.valueOf(cityRequest.getCdmStateId())));
    }

    private CityUpsertInput toCityInputForUpdate(CityUpdateRequest cityRequest) {
        return new CityUpsertInput(
                cityRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(cityRequest.getCdmKeyId())),
                new HashMap<>(this.sanitizeAttributes(cityRequest.getAttributes())),
                cityRequest.getTitleEn() == null
                        ? null
                        : new String(String.valueOf(cityRequest.getTitleEn())),
                cityRequest.getTitleFr() == null
                        ? null
                        : new String(String.valueOf(cityRequest.getTitleFr())),
                cityRequest.getCdmStateId() == null
                        ? null
                        : Long.valueOf(String.valueOf(cityRequest.getCdmStateId())));
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {



        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }
}
