package com.capgemini.admin.back.mapper.procedure;

import com.capgemini.admin.back.mapper.DtoMapperConfig;
import com.capgemini.admin.back.model.procedure.LogAuditTranslation;
import com.capgemini.admin.back.model.procedure.LogAuditTranslationDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface LogAuditTranslationMapper {

    LogAuditTranslationMapper INSTANCE = Mappers.getMapper(LogAuditTranslationMapper.class);

    LogAuditTranslationDTO logAuditTranslationToLogAuditTranslationDTO(LogAuditTranslation in);

    LogAuditTranslation logAuditTranslationDTOToLogAuditTranslation(LogAuditTranslationDTO in);

}