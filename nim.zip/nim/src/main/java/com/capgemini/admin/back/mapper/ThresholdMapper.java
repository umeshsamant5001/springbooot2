package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.Threshold;
import com.capgemini.admin.back.model.ThresholdDTO;

@Mapper(config = DtoMapperConfig.class)
public interface ThresholdMapper {

    ThresholdMapper INSTANCE = Mappers.getMapper(ThresholdMapper.class);

    Threshold thresholdDTOToThreshold(ThresholdDTO in);

    // @Mapping(target = "thresholdConfigurationId", source =
    // "thresholdConfiguration.id") // if displayed thresholdConfigurationId in json
    // response, then it uncommented and respectively this ThresholdDTO
    ThresholdDTO thresholdToThresholdDTO(Threshold in);

}
