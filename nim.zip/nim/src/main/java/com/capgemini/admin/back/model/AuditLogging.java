
package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@Entity
@Table(name = "audit_logging", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class AuditLogging {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AuditLogging_Generator")
	@SequenceGenerator(name = "AuditLogging_Generator", sequenceName = "AuditLogging_Sequence")
	private Long id;

	@Column(name = "username")
	private String username;

	@Column(name = "moduleName")
	private String moduleName;

	@Column(name = "activity")
	private String activity;

	@Column(name = "previousData")
	private String previousData;

	@Column(name = "currentData", columnDefinition = "varchar(MAX)")
	private String currentData;

	@Column(name = "activityDate")
	private Long activityDate;

	@Column(name = "platform")
	private String platform;

	@Column(name = "audit_Type")
	private EnumAuditType auditType;

	@Column(name = "user_country")
    private String country;

}
