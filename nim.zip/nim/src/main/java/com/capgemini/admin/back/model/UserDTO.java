package com.capgemini.admin.back.model;

import java.util.List;
import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private Integer userType;
    private boolean enabled;
    private Boolean subscribeAlert;
    private boolean tokenExpired;
    private String country;
    private List<RoleLocationDTO> roleLocations;
}
