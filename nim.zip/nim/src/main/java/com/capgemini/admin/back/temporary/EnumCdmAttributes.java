package com.capgemini.admin.back.temporary;

public enum EnumCdmAttributes {
	UNKNOWN("cdm.unknown"),
	ASSET_ID("cdm.asset_id"), // only used on floors (needed for matching pois and getting base64 maps)
	ACTIVE("cdm.active"),
	ASSET_CODE("cdm.asset_code"),
	ADDRESS("cdm.address"),
	SITE_CODE("cdm.site_code"),
	TYPE("cdm.type"),
	SECURED_FLOOR("cdm.secured_floor"),
	POI_SPACE_TYPE_NAME("cdm.poi_space_type_name"),
	POI_SPACE_CATEGORY_NAME("cdm.poi_space_category_name"),
	HOTELING_SPACE("cdm.hoteling_space"),
	SPECIAL_SECURED_NON_SECURED("cdm.special_secured_non_secured"),
	OPERATION("cdm.operation"),
	AREA_NAME("cdm.area_name"),
	LATITUDE("lat"),
	LONGITUDE("lon"),
	COORD_X("x"),
	COORD_Y("y");

	// add possible attributes here.

	private final String text;

	EnumCdmAttributes(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}
