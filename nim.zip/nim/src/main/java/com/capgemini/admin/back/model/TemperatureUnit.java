package com.capgemini.admin.back.model;

public enum TemperatureUnit {
    CELSIUS, FAHRENHEIT;
}
