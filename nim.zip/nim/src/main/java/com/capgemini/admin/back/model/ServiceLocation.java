package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Table(name = "service_location")
@Entity
@Data
@EqualsAndHashCode
public class ServiceLocation {

        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ServiceLocation_Generator")
        @SequenceGenerator(name = "ServiceLocation_Generator", sequenceName = "ServiceLocation_Sequence")
        private Long id;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "service_id")
        @JsonIgnore
        private Service service;

        @Column(name = "service_id", updatable = false, insertable = false)
        private Long serviceId;

        @Enumerated(EnumType.STRING)
        @Column(name = "level")
        private LevelEnum level;

        @Column(name = "cdm_key_id")
        private Long cdmKeyId;

        @Column(name = "status")
        private String status;
}
