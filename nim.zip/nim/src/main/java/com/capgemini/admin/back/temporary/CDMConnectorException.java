package com.capgemini.admin.back.temporary;

public class CDMConnectorException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 7748650921857496286L;

	public CDMConnectorException(String message) {
		super(500, ErrorCodes.JC_CONNECTOR_UNEXPECTED_ERROR, message);
	}

}
