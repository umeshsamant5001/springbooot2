package com.capgemini.admin.back.scheduled;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;
import com.capgemini.admin.back.scheduled.scheduled.CustomDailyScheduledAction;
import com.capgemini.admin.back.scheduled.scheduled.CustomMonthlyScheduledAction;
import com.capgemini.admin.back.scheduled.scheduled.DateScheduledAction;
import com.capgemini.admin.back.scheduled.scheduled.NowScheduledAction;
import com.capgemini.admin.back.scheduled.scheduled.ScheduledAction;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class ScheduledJob<N extends Scheduled, S extends ScheduledSent> {

    protected List<ScheduledAction<N, S>> actionList = Arrays.asList(
            new NowScheduledAction<N, S>(),
            new DateScheduledAction<N, S>(),
            new CustomDailyScheduledAction<N, S>(),
            new CustomMonthlyScheduledAction<N, S>());

    /**
     * Get all the Scheduled with the state RUNNING. Should lock the lines to avoid
     * another Job to return the same lines.
     * 
     * @return The list of running Scheduled
     */
    protected abstract List<N> getScheduledRunning();

    /**
     * Get all the last ScheduledSent for the running Scheduled
     * 
     * @return The list of the last ScheduledSent
     */
    protected abstract List<S> getLastScheduledSent();

    /**
     * Execute the sending of the Scheduled
     * 
     * @param scheduled The Scheduled to send
     * @return `true` if the sending work, `false` otherwise.
     */
    protected abstract boolean sendScheduled(N scheduled);

    /**
     * Return a new ScheduledSent
     * 
     * @return The new ScheduledSent
     */
    protected abstract S getNewScheduledSent();

    /**
     * Save a ScheduledSent to the database
     * 
     * @param scheduledSent
     */
    protected abstract void saveScheduledSent(S scheduledSent);

    /**
     * Change and save the status of a Scheduled to STOPPED
     * 
     * @param scheduled The Scheduled to update.
     */
    protected abstract void stopScheduled(N scheduled);

    /**
     * Function call at the end of the bacth.
     * Can be used to released the notifications
     * 
     * @param scheduledList
     */
    protected abstract void endJob(List<N> scheduledList);

    public void execJob(Date now) {
        log.info("[ScheduledJob] Start execution | triggerTime={}", now);

        // Get all the "running" scheduleds
        List<N> scheduledList = this.getScheduledRunning();
        log.info("[ScheduledJob] Running scheduled count={}", scheduledList.size());

        try {
            // Get all the last ScheduledSent (for each Scheduled), and map them by
            // Scheduled Id
            List<S> lastSentList = this.getLastScheduledSent();
            log.debug("[ScheduledJob] Last sent records fetched count={}", lastSentList.size());

            Map<Long, S> scheduledSentMap = lastSentList
                    .stream()
                    .collect(Collectors.toMap(
                            scheduledSent -> scheduledSent.getScheduledId(),
                            Function.identity(),
                            // Manage the case of duplicate data
                            (scheduledSent1, scheduledSent2) -> {
                                log.warn("[ScheduledJob] Duplicate sent entry for scheduledId={}, keeping first",
                                        scheduledSent1.getScheduledId());
                                return scheduledSent1;
                            }));

            log.debug("[ScheduledJob] ScheduledSent map built with {} entries", scheduledSentMap.size());

            scheduledList.stream()
                    // Map each Scheduled to a corresponding ScheduledAction (if possible)
                    .map(scheduled -> {
                        log.debug("[ScheduledJob] Resolving action for scheduled id={}", scheduled.getId());

                        // Find the ScheduledAction of the current Scheduled
                        ScheduledAction<N, S> scheduledAction = this.actionList.stream()
                                .map(actionClass -> {
                                    if (actionClass.checkType(scheduled)) {
                                        S scheduledSent = null;
                                        if (scheduledSentMap.containsKey(scheduled.getId())) {
                                            scheduledSent = scheduledSentMap.get(scheduled.getId());
                                        }

                                        return actionClass.getAction(scheduled, scheduledSent, now);
                                    }

                                    return null;
                                })
                                .filter(action -> Objects.nonNull(action))
                                .findFirst()
                                .orElse(null);

                        if (Objects.isNull(scheduledAction)) {
                            // No ScheduledAction found for the current Scheduled : we don't process
                            // it
                            log.warn("[ScheduledJob] Could not resolve action type for scheduled id={}", scheduled.getId());
                            return null;
                        }

                        log.debug("[ScheduledJob] Action resolved for scheduled id={}, shouldBeSent={}",
                                scheduled.getId(), scheduledAction.shouldBeSent());
                        return scheduledAction;
                    })
                    // Filter to keep only the Scheduled we need to send now
                    .filter(scheduledAction -> Objects.nonNull(scheduledAction) && scheduledAction.shouldBeSent())
                    .forEach(scheduledAction -> {
                        N scheduled = scheduledAction.getScheduled();

                        boolean scheduledLaunched = false;
                        try {
                            log.info("[ScheduledJob] Sending scheduled id={}", scheduled.getId());

                            scheduledLaunched = this.sendScheduled(scheduled);

                            if (Boolean.TRUE.equals(scheduledLaunched)) {
                                log.info("[ScheduledJob] Send succeeded for scheduled id={}", scheduled.getId());
                            } else {
                                log.warn("[ScheduledJob] Send failed for scheduled id={}", scheduled.getId());
                            }
                        } catch (Exception e) {
                            log.error("[ScheduledJob] Exception while sending scheduled id={}", scheduled.getId(), e);
                        }

                        if (scheduledLaunched) {
                            // If the Scheduled is sent, we create the corresponding ScheduledSent
                            S scheduledSent = this.getNewScheduledSent();
                            scheduledSent.setScheduled(scheduled);
                            scheduledSent.setSentAt(now.getTime() / 1000);

                            log.debug("[ScheduledJob] Saving ScheduledSent for scheduled id={}", scheduled.getId());
                            this.saveScheduledSent(scheduledSent);

                            if (scheduledAction.wasLastSent()) {
                                log.info("[ScheduledJob] Last send reached for scheduled id={}, stopping", scheduled.getId());
                                this.stopScheduled(scheduled);
                            }
                        }
                    });
        } catch (Exception e) {
            log.error("[ScheduledJob] Unexpected error during processing", e);
        }

        log.info("[ScheduledJob] Processing complete, invoking endJob for count={}", scheduledList.size());
        this.endJob(scheduledList);
        log.info("[ScheduledJob] Job finished");
    }
}
