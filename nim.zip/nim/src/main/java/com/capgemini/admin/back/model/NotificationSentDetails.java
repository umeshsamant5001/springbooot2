package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@Table(name = "notification_Sent_Details", uniqueConstraints = {
        @UniqueConstraint(columnNames = { "notification_id", "token" }) })
public class NotificationSentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ✅ Notification reference
    @Column(name = "notification_id", nullable = false)
    private Long notificationId;

    // ✅ Device token
    @Column(name = "token", nullable = false, length = 500)
    private String token;

    // ✅ Status flag
    @Column(name = "is_sent")
    private Boolean isSent = false;

    // ✅ Timestamp when sent
    @Column(name = "sent_at")
    private LocalDateTime sentAt;
}
