package com.capgemini.admin.back.model;

public enum EnumDeviceType {
	OFFICESENSE_PRESENCE, OFFICESENSE_COMFORT, OFFICESENSE_DESK, DELTADORE, TABLET, UNKNOWN;

	public static EnumDeviceType findByName(String name) {
		EnumDeviceType result = null;
		for (EnumDeviceType deviceType : values()) {
			if (deviceType.name().equalsIgnoreCase(name)) {
				result = deviceType;
				break;
			}
		}
		return result;
	}
}