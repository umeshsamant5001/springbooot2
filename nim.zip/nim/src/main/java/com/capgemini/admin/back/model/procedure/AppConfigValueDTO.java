package com.capgemini.admin.back.model.procedure;

import lombok.Data;

@Data
public class AppConfigValueDTO {
    private String configKey;
    private Boolean isActive;
    private String type;
    private String value;
    private Long lastChange;
}