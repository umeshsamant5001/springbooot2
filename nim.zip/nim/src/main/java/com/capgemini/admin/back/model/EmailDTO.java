package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class EmailDTO {
    private String sender;
    private List<String> adressee = new ArrayList<>();
    private List<String> copies = new ArrayList<>();
    private String subject;
    private String body;
    private String attachment;
    private String fileName;
}
