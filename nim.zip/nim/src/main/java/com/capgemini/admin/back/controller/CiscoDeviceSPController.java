package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.model.CiscoDeviceSP;
import com.capgemini.admin.back.model.CiscoDeviceSPDTO;
import com.capgemini.admin.back.service.CiscoDeviceSPService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = CiscoDeviceSPController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CiscoDeviceSPController {
    public static final String ROOT_API = "api/ciscoDeviceSP";

    @Autowired
    private CiscoDeviceSPService ciscoDeviceSPService;

    /**
     * Searches for items within a specific building based on the given
     * searchstring.
     * 
     * @param buildingId   The ID of the building to search within.
     * @param searchString The search string to use for searching items.
     * @param language     The language to use for the request (default is English
     *                     if not provided).
     * @return ResponseEntity containing a list of DeviceSPDTO objects matching the
     *         search criteria.
     */
    @Transactional(readOnly = true)
    @GetMapping("/search/{buildingId}/{searchString}")
    public ResponseEntity<List<CiscoDeviceSPDTO>> searchItemsForCiscoDevice(
            @PathVariable("buildingId") int buildingId,
            @PathVariable("searchString") String searchString,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Retrieve list of DeviceSP objects based on the building ID and search string
        List<CiscoDeviceSP> ciscoDeviceSPs = ciscoDeviceSPService.getAllCiscoDeviceSPByBuildingId(searchString,
                buildingId);

        ciscoDeviceSPs = this.ciscoDeviceSPService.filterCiscoDeviceSP(ciscoDeviceSPs);

        // Convert the list of CiscoDeviceSP objects to a list of CiscoDeviceSPDTO
        // objects
        List<CiscoDeviceSPDTO> ciscoDeviceSPDTOs = ciscoDeviceSPsTOCiscoDeviceSPDTOs(ciscoDeviceSPs);

        return ResponseEntity.ok(ciscoDeviceSPDTOs);
    }

    /**
     * Searches for items globally based on the given search string.
     * 
     * @param searchString The search string to use for searching items.
     * @param language     The language to use for the request (default is English
     *                     if not provided).
     * @return ResponseEntity containing a list of DeviceSPDTO objects matching the
     *         search criteria.
     */
    @Transactional(readOnly = true)
    @GetMapping("/search/{searchString}")
    public ResponseEntity<List<CiscoDeviceSPDTO>> searchItemGlobalForCiscoDevice(
            @PathVariable("searchString") String searchString,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Retrieve list of DeviceSP objects based on the search string
        List<CiscoDeviceSP> ciscoDeviceSPs = ciscoDeviceSPService.getAllCiscoDeviceSP(searchString);

        ciscoDeviceSPs = ciscoDeviceSPService.filterCiscoDeviceSP(ciscoDeviceSPs);

        // Convert the list of CiscoDeviceSP objects to a list of CiscoDeviceSPDTO
        // objects
        List<CiscoDeviceSPDTO> ciscoDeviceSPDTOs = ciscoDeviceSPsTOCiscoDeviceSPDTOs(ciscoDeviceSPs);

        return ResponseEntity.ok(ciscoDeviceSPDTOs);
    }

    /**
     * Converts a list of CiscoDeviceSP entities into a list of CiscoDeviceSPDTOs.
     * Ensures uniqueness of DTOs based on deviceId and maps nested attributes.
     *
     * @param ciscoDeviceSPs List of CiscoDeviceSP entities from the stored
     *                       procedure
     * @return List of CiscoDeviceSPDTOs for API response
     */
    private List<CiscoDeviceSPDTO> ciscoDeviceSPsTOCiscoDeviceSPDTOs(List<CiscoDeviceSP> ciscoDeviceSPs) {

        // Map to ensure each deviceId is represented only once in the DTO list
        Map<String, CiscoDeviceSPDTO> ciscoDeviceSPDTOMap = new HashMap<>();

        for (CiscoDeviceSP ciscoDeviceSP : ciscoDeviceSPs) {
            String deviceId = ciscoDeviceSP.getDeviceId();

            // Check if DTO for this deviceId already exists
            CiscoDeviceSPDTO ciscoDeviceSPDTO = ciscoDeviceSPDTOMap.get(deviceId);

            if (ciscoDeviceSPDTO == null) {
                // Create new DTO and populate basic fields
                ciscoDeviceSPDTO = new CiscoDeviceSPDTO();
                ciscoDeviceSPDTO.setDeviceId(deviceId);
                ciscoDeviceSPDTO.setPoiName(ciscoDeviceSP.getPoiName());
                ciscoDeviceSPDTO.setPoiTitle(ciscoDeviceSP.getPoiTitle());
                ciscoDeviceSPDTO.setPoiType(ciscoDeviceSP.getPoiType());
                ciscoDeviceSPDTO.setDeviceType(ciscoDeviceSP.getDeviceType());

                // Convert LocalDateTime to epoch milliseconds for frontend compatibility
                ciscoDeviceSPDTO.setLastDataReceived(ciscoDeviceSP.getLastDataReceived() != null
                        ? ciscoDeviceSP.getLastDataReceived().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        : null);

                // Create and populate nested attributes object
                CiscoDeviceSPDTO.CiscoDeviceSPAttributes attributes = new CiscoDeviceSPDTO.CiscoDeviceSPAttributes();
                attributes.setIpAddress(ciscoDeviceSP.getIpAddress());
                attributes.setPeopleCount(ciscoDeviceSP.getPeopleCount());
                attributes.setAmbientNoiseDba(ciscoDeviceSP.getAmbientNoiseDba());
                attributes.setSoundLevelDba(ciscoDeviceSP.getSoundLevelDba());
                attributes.setAmbientTemperature(ciscoDeviceSP.getAmbientTemperature());
                attributes.setRelativeHumidity(ciscoDeviceSP.getRelativeHumidity());
                attributes.setAirQuality(ciscoDeviceSP.getAirQuality());
                // Attach attributes to DTO
                ciscoDeviceSPDTO.setCiscoDeviceAttributes(attributes);

                // Store DTO in map to avoid duplicates
                ciscoDeviceSPDTOMap.put(deviceId, ciscoDeviceSPDTO);
            }
        }
        // Return the list of unique DTOs
        return new ArrayList<>(ciscoDeviceSPDTOMap.values());
    }

}
