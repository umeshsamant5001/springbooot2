package com.capgemini.admin.back.repository.procedure;

import com.capgemini.admin.back.model.procedure.LogAuditTranslation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LogAuditTranslationRepository extends JpaRepository<LogAuditTranslation, Long> {

    @Procedure(name = "InsertExceptionlog_translationservice")
    void insertExceptionlog_translationservice(@Param("Description") String description,
            @Param("Status") String status,
            @Param("CreatedDate") String createdDate,
            @Param("TranslationServiceType") String translationServiceType,
            @Param("Exception") String exception);

}