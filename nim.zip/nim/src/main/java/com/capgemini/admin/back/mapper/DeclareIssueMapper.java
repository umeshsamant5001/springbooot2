package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.DeclareIssue;
import com.capgemini.admin.back.model.DeclareIssueDTO;

@Mapper(uses = { DeclareIssueDetailsMapper.class })
public interface DeclareIssueMapper {

    DeclareIssueMapper INSTANCE = Mappers.getMapper(DeclareIssueMapper.class);
    
    DeclareIssue declareIssueDTOToDeclareIssue(DeclareIssueDTO in);

    DeclareIssueDTO declareIssueToDeclareIssueDTO(DeclareIssue in);
}
