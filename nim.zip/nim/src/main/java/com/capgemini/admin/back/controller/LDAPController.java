package com.capgemini.admin.back.controller;

import java.util.List;

import com.capgemini.admin.back.model.EmployeeDetailDTO;
import com.capgemini.admin.back.service.LDAPData;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@RequestMapping(produces = APPLICATION_JSON_VALUE)
@RestController
public class LDAPController {

    private final LDAPData ldapData;

    public LDAPController(LDAPData ldapData) {
        this.ldapData = ldapData;
    }

    @GetMapping("/api/search/{searchString}")
    public ResponseEntity<List<EmployeeDetailDTO>> getUserDetailsBySearch(
            @PathVariable String searchString,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        try {
            // Fetch from LDAP if user not found
            ldapData.getLdapData();
            List<EmployeeDetailDTO> employeeDetailDTOs = ldapData.getUserDetailsBySearch(searchString);
            return ResponseEntity.ok(employeeDetailDTOs);

        } catch (Exception e) {
            log.error("Failed to fetch LDAP user details by search", e);
            return ResponseEntity.internalServerError().build();
        }
    }

}
