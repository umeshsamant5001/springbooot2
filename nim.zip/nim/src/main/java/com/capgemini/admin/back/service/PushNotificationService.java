package com.capgemini.admin.back.service;

import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.config.FirebaseInitializer;
import com.capgemini.admin.utils.PushNotificationApnsUtil;
import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationLocation;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.net.URI;
import java.util.ArrayList;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Slf4j
public class PushNotificationService {

    @Autowired
    private FirebaseInitializer firebaseInitializer;

    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private ApplicationProperties applicationProperties;
    @Autowired
    private NotificationSentDetailsService notificationSentDetailsService;

    /**
     * Sends notifications based on locations specified in the notification object.
     *
     * @param notification The notification object containing message and target
     *                     locations.
     * @return true if any notification was sent, false otherwise.
     * @throws FirebaseMessagingException if an error occurs while sending
     *                                    notifications.
     */
    public boolean sendByLocations(Notification notification) throws FirebaseMessagingException {

    log.info("PushNotificationService: sendByLocations called for notification ID: {}", notification.getId());
    firebaseInitializer.initialize();

    boolean anySent = false;

    //  NEW: Prevent duplicate GLOBAL execution
    boolean globalProcessed = false;

    for (NotificationLocation loc : notification.getNotificationLocations()) {

        log.info("Processing location: Level = {}, Country = {}", loc.getLevel(), loc.getCountryName());

        List<String> androidTokens = new ArrayList<>();
        List<String> iosTokens = new ArrayList<>();

        if (loc.getLevel() == LevelEnum.GLOBAL) {

            //  FIX: Avoid multiple GLOBAL sends if duplicate rows exist
            if (globalProcessed) {
                log.warn("Skipping duplicate GLOBAL execution for notificationId={}", notification.getId());
                continue;
            }

            log.info("[PUSH] Sending GLOBAL push");
            globalProcessed = true;

            androidTokens = deviceTokenService.getDeviceRegistrationTokens(EnumOsType.ANDROID);
            iosTokens = deviceTokenService.getDeviceRegistrationTokens(EnumOsType.IOS);

        } else {

            log.info("[PUSH] Sending COUNTRY push to {}", loc.getCountryName());

            androidTokens = deviceTokenService.getDeviceTokensByDeviceTypeAndCountry(
                    EnumOsType.ANDROID, loc.getCountryName());

            iosTokens = deviceTokenService.getDeviceTokensByDeviceTypeAndCountry(
                    EnumOsType.IOS, loc.getCountryName());
        }

        // FIX: Deduplicate tokens (prevents same-device multiple push)
        int rawAndroid = androidTokens.size();
        int rawIos = iosTokens.size();

        androidTokens = new ArrayList<>(new HashSet<>(androidTokens));
        iosTokens = new ArrayList<>(new HashSet<>(iosTokens));

        log.info("Retrieved Android tokens: raw={} unique={}", rawAndroid, androidTokens.size());
        log.info("Retrieved iOS tokens: raw={} unique={}", rawIos, iosTokens.size());

        List<String> failedAndroidTokens = new ArrayList<>();
        List<String> failedIosTokens = new ArrayList<>();

        log.info("OS Types in notification: {}", notification.getOsTypes());

        // ANDROID
        if (notification.getOsTypes().contains(EnumOsType.ANDROID)) {

            log.info("Sending Android notifications...");

           for (String token : androidTokens) {

    //  1. Skip already processed tokens
    if (notificationSentDetailsService.alreadySent(notification.getId(), token)) {
        log.info(" Skipping already sent Android token={} for notification={}",
                token, notification.getId());
        continue;
    }

    try {
        // 2. Send push
        sendAndroidPushNotification(notification, token, failedAndroidTokens);

        // 3. Mark success in DB
        notificationSentDetailsService.markSuccess(notification.getId(), token);

        log.info("Android push sent successfully for token={}", token);

    } catch (Exception e) {

        log.error("Android push failed for token={}", token, e);

        //  4. Mark failure (optional but recommended)
        notificationSentDetailsService.markFailure(notification.getId(), token);

        failedAndroidTokens.add(token);
    }
}

            logFailedTokens("ANDROID", failedAndroidTokens);

            //  FIX: don't overwrite, accumulate result
            anySent = anySent || !androidTokens.isEmpty();
        }

        log.info("Checking if iOS push should be sent...");
        log.info("iOS Tokens count: {}", iosTokens.size());

        // IOS
        if (notification.getOsTypes().stream()
        .anyMatch(os -> os.name().equalsIgnoreCase("IOS"))) { 

            log.info("Sending iOS notifications...");

           for (String token : iosTokens) {

    // 1. Skip already processed tokens
    if (notificationSentDetailsService.alreadySent(notification.getId(), token)) {
        log.info(" Skipping already sent iOS token={} for notification={}",
                token, notification.getId());
        continue;
    }

    try {
        log.debug("sending push to iosToken {}", token);

        // 2. Send push
        sendIosPushNotification(notification, token, failedIosTokens);

        // 3. Mark success in DB
       notificationSentDetailsService.markSuccess(notification.getId(), token);

        log.info("iOS push sent successfully for token={}", token);

    } catch (Exception e) {

        log.error(" iOS push failed for token={}", token, e);

        //  4. Mark failure (optional but recommended)
        notificationSentDetailsService.markFailure(notification.getId(), token);

        failedIosTokens.add(token);
    }
}

            logFailedTokens("IOS", failedIosTokens);

            // FIX
            anySent = anySent || !iosTokens.isEmpty();

        } else {
            log.warn("iOS not included in notification Ostypes");
        }
    }

    log.info("Push execution completed for notificationId={} result={}", notification.getId(), anySent);

    return anySent;
}

    /**
     * Sends a push notification to an Android device using Firebase Cloud Messaging
     * (FCM).
     * 
     * @param notification The notification object containing title and message.
     * @param token        The FCM device token to which the notification should be
     *                     sent.
     * @param failedTokens A list to collect tokens for which the notification
     *                     failed to send.
     */
    private void sendAndroidPushNotification(Notification notification, String token, List<String> failedTokens) {
        Map<String, String> androidDataMap = getMapFromNotificationMessage(notification.getTitle(),
                notification.getMessage());
        AndroidConfig androidConfig = AndroidConfig.builder()
                .putAllData(androidDataMap)
                .build();
        Message message = Message.builder()
                .setAndroidConfig(androidConfig)
                .setToken(token)
                .build();
        String response = null;
        try {
            response = FirebaseMessaging
                    .getInstance(FirebaseApp.getInstance("androidApp"))
                    .send(message);
            String safeToken = sanitizeForLog(token);
            String safeResponse = sanitizeForLog(response);
            log.info("[PUSH][ANDROID] Notification sent to token: {} | Response: {}", safeToken, safeResponse);
        } catch (FirebaseMessagingException e) {
            String safeToken = sanitizeForLog(token);
            String safeReason = sanitizeForLog(e.getMessage());
            log.warn("[PUSH][ANDROID] Failed to send to token: {} | Reason: {}", safeToken, safeReason);
            failedTokens.add(token);
        }
    }

    /**
     * Sends a push notification to an iOS device using Apple Push Notification
     * Service (APNs)
     * 
     * @param The          notification object containing the title and message.
     * @param The          APNs device token to which the notification should be
     *                     sent.
     * @param failedTokens A list to collect tokens for which the notification
     *                     failed to send.
     */
    private void sendIosPushNotification(Notification notification, String token, List<String> failedTokens) {
        String safeToken = sanitizeForLog(token);
        log.info("Preparing to send iOS push to token: {}", safeToken);
        String payLoad = null;
        try {
            payLoad = buildApnsJsonPayload(notification.getTitle(), notification.getMessage());
            String safePayload = sanitizeForLog(payLoad);
            log.info("APNs Payload: {}", safePayload);
        } catch (IOException ioe) {
            String safePayload = sanitizeForLog(payLoad);
            log.error("Failed to build APNs payload: {}", safePayload, ioe);
        }
        String teamId = applicationProperties.getPushNotificationApns().getTeamId();
        String keyId = applicationProperties.getPushNotificationApns().getKeyId();
        String base64PrivateKey = applicationProperties.getPushNotificationApns().getBase64PrivateKey();
        String jwtToken = null;
        String response = null;
        try {
            jwtToken = PushNotificationApnsUtil.generateToken(teamId, keyId, base64PrivateKey);
            log.info("JWT Token generated");
        } catch (Exception e) {
            log.error("Error generating token", e);
        }
        if (jwtToken == null) {
            log.error("JWT token is null, skipping iOS push for token: {}", safeToken);
            failedTokens.add(token);
            return;
        }
        try {
            response = sendAPNSNotification(jwtToken, token, payLoad);
            String safeResponse = sanitizeForLog(response);
            log.info("[PUSH][iOS] Notification sent to token: {} | Response: {}", safeToken, safeResponse);
        } catch (Exception e) {
            String safeReason = sanitizeForLog(e.getMessage());
            log.warn("[PUSH][iOS] Failed to send to token: {} | Reason: {}", safeToken, safeReason);
            failedTokens.add(token);
            response = e.getMessage();
        }
    }

    /**
     * Logs all tokens that failed to receive push notifications for a given
     * platform.
     * 
     * @param platform     The platform name (e.g., "iOS", "Android").
     * @param failedTokens The list of tokens that failed to receive the
     *                     notification.
     */
    private void logFailedTokens(String platform, List<String> failedTokens) {
        if (!failedTokens.isEmpty()) {
            log.warn("[PUSH][{}] {} tokens failed: {}", platform, failedTokens.size(), failedTokens);
        }
    }

    /**
     * Creates a JSON payload for APNs notifications.
     * Constructs the payload using the provided notification message data.
     * 
     * @param title               The title for the notification message data.
     * @param notificationMessage The notification message data.
     * @return The JSON payload for APNs notifications.
     * @throws IOException If an error occurs while constructing the payload.
     */
    private String buildApnsJsonPayload(String title, String notificationMessage) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> dataMap = getMapFromNotificationMessage(title, notificationMessage);
        Map<String, Object> aps = new HashMap<>();
        aps.put("alert", dataMap);
        aps.put("sound", "default");
        aps.put("mutable-content", 1);
        Map<String, Object> payload = Map.of("aps", aps);
        return objectMapper.writeValueAsString(payload);
    }

    /**
     * Sends a push notification to an iOS device using APNs.
     * Constructs the HTTP request using the provided JWT token, device token, and
     * payload.
     * 
     * @param jwtToken    The JWT token for authentication with APNs.
     * @param deviceToken The device token to which the notification will be sent.
     * @param payLoad     The JSON payload representing the notification data.
     * @return The response body from the APNs HTTP request.
     */
    private String sendAPNSNotification(String jwtToken, String deviceToken, String payLoad) throws Exception {
        String apnsHost = applicationProperties.getPushNotificationApns().getApnsHost();
        String apnsTopic = applicationProperties.getPushNotificationApns().getApnsTopic();
        HttpClient client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apnsHost + "/3/device/" + deviceToken))
                .POST(HttpRequest.BodyPublishers.ofString(payLoad))
                .setHeader("authorization", "bearer " + jwtToken)
                .setHeader("apns-topic", apnsTopic)
                .setHeader("apns-push-type", "alert") // Required
                .setHeader("Content-Type", "application/json")
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }

    /**
     * Generates a map from the JSON string representing the notification message.
     * 
     * @param title               The title for the notification message data.
     * @param notificationMessage The notification message data.
     * @return A map containing the notification data.
     */
    private Map<String, String> getMapFromNotificationMessage(String title, String notificationMessage) {
        Map<String, String> alert = Map.of(
                "title", title,
                "body", sanitizeHtmlSpacesAndBreaks(notificationMessage.trim()));
        return alert;
    }

    /**
     * Replaces HTML non-breaking spaces (&nbsp;) and <br>
     * tags with normal spaces,
     * collapses multiple spaces into one, and trims the result.
     */
    private String sanitizeHtmlSpacesAndBreaks(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        // Replace &nbsp; with space
        String result = input.replaceAll("&nbsp;", " ");
        result = result.replaceAll("(?i)</?br\\s*/?>|<?i>|</?i>|</?b>|&nbsp;", " ").trim()
                .replaceAll("\\s+", " ");
        result = result.replaceAll("<span[^>]*>.*?</span>", " ");
        // Trim leading and trailing spaces
        return result.trim();
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }


}
