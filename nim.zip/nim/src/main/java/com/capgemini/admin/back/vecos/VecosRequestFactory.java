package com.capgemini.admin.back.vecos;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.capgemini.admin.utils.CheckedFunction;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class VecosRequestFactory {

    private static final int DEFAULT_CONNECT_TIMEOUT = 5000;
    private static final int DEFAULT_TIMEOUT = 30000;

    private RequestConfig config;

    @PostConstruct
    public void init() {
        config = RequestConfig.custom().setConnectTimeout(DEFAULT_CONNECT_TIMEOUT)
                .setConnectionRequestTimeout(DEFAULT_TIMEOUT).setSocketTimeout(DEFAULT_TIMEOUT).build();
    }

    /**
     * GET api call
     * 
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param responseParser the function to apply to read response
     * @return T a custom object defined by function
     */
    public <T> T get(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            CheckedFunction<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }
            HttpGet req = new HttpGet(builder.build());
            if (!CollectionUtils.isEmpty(headers)) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException e) {
            log.error(getUriBuilderErrorMessage(endpoint, e.getMessage()));
            return null;
        }
    }

    /**
     * POST api call with x-www-form-urlencoded query
     * 
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param urlEncodedParams
     * @param responseParser
     * @return
     */
    public <T> T postFormUrlEncoded(String endpoint, Map<String, String> headers, List<NameValuePair> urlEncodedParams,
            CheckedFunction<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            HttpPost req = new HttpPost(builder.build());
            UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
            req.setEntity(urlEncoded);
            if (!CollectionUtils.isEmpty(headers)) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException | UnsupportedEncodingException e) {
            log.error("Error posting :" + getUriBuilderErrorMessage(endpoint, e.getMessage()));
            return null;
        }
    }

    /**
     * Execute an http call and before closures,
     * apply a function to manage response
     * 
     * @param <T>
     * @param req
     * @param responseParserFunc the function to parse the HttpResponse
     * @return an object defined by responseParserFunc
     */
    private <T> T execute(HttpUriRequest req,
            CheckedFunction<CloseableHttpResponse, T> responseParserFunc) {
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
                CloseableHttpResponse res = httpClient.execute(req)) {
            return responseParserFunc.apply(res);
        } catch (IOException e) {
            String message = String.format("Impossible to access Vecos API on endpoint:[%s], error:[%s]", req.getURI(),
                    e.getMessage());
            log.error(message);
            return null;
        }
    }

    /**
     * Converts a map of query parameters into a list of NameValuePair objects.
     * This is typically used to build URL query strings for HTTP requests.
     * 
     * @param mapParams A map containing query parameter names and their
     *                  corresponding values.
     * @return A list of NameValuePair objects representing the query parameters.
     */
    private List<NameValuePair> convertQueryParams(final Map<String, String> mapParams) {
        return mapParams.entrySet().stream()
                .map(e -> new BasicNameValuePair(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    /**
     * Converts a map of headers into an array of Header objects.
     * Useful for setting HTTP headers in a request.
     *
     * @param mapHeaders A map containing header names and their corresponding
     *                   values.
     * @return An array of Header objects representing the HTTP headers.
     */
    private Header[] convertHeaders(final Map<String, String> mapHeaders) {
        return mapHeaders.entrySet().stream()
                .map(e -> new BasicHeader(e.getKey(), e.getValue()))
                .toArray(Header[]::new);
    }

    /**
     * Constructs a formatted error message for URI building failures.
     * 
     * @param endpoint The endpoint that was being used to build the URI.
     * @param message  The specific error message encountered.
     * @return A formatted string describing the URI building error.
     */
    private String getUriBuilderErrorMessage(String endpoint, String message) {
        return String.format("Unable to build Vecos URI - endpoint:[%s] - error:[%s]", endpoint, message);
    }
}