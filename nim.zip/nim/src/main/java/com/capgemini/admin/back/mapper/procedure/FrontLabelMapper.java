package com.capgemini.admin.back.mapper.procedure;

import com.capgemini.admin.back.mapper.DtoMapperConfig;
import com.capgemini.admin.back.model.procedure.FrontLabel;
import com.capgemini.admin.back.model.procedure.FrontLabelDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface FrontLabelMapper {

    FrontLabelMapper INSTANCE = Mappers.getMapper(FrontLabelMapper.class);

    FrontLabelDTO frontLabelToFrontLabelDTO(FrontLabel in);

    FrontLabel frontLabelDTOToFrontLabel(FrontLabelDTO in);

}