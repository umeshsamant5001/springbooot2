package com.capgemini.admin.back.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DevicePoiDTO {

	private String uuid;
	private String poiName;
	private String deviceType;
	private Long lastChange;
	private String status;
	private Long floorId;
	private String titleEn;
	private String titleFr;
	private String attKey;
	private String attValue;
}
