package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.CountrySP;

@Repository
public interface CountrySPRepository extends JpaRepository<CountrySP, Long> {

    @Procedure(name = "SO_GetSiteTree")
    List<CountrySP> SO_GetSiteTree(@Param("Langauge") String language, @Param("RoleID") int roleId);
}
