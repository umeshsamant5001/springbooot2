package com.capgemini.admin.back.security.jwt.model;

import com.capgemini.admin.back.model.errorcodes.ErrorCodes;
import com.capgemini.admin.back.model.exceptionmapper.GeneralException;

public class AuthFailureException extends GeneralException {

	private static final long serialVersionUID = 5383016634683861626L;

	public AuthFailureException(String message) {
		super(401, ErrorCodes.AUTHENTICATION_FAILED, message);
	}

}
