package com.capgemini.admin.utils;

public class SensorUtil {
    /**
     * Calcul the apparent temperature.
     * @param temp The temperature
     * @param humidity The humidity (a value from 0 to 100)
     * @return The apparent temperature.
     */
    static public double calculApparentTemp(double temp, double humidity) {
		return -8.78469475556
			+ 1.61139411 * temp
			+ 2.33854883889 * humidity
			- 0.14611605 * humidity * temp
			- 0.012308094 * Math.pow(temp, 2)
			- 0.0164248277778 * Math.pow(humidity, 2)
			+ 0.00211732 * Math.pow(temp, 2) * humidity
			+ 0.00072546 * temp * Math.pow(humidity, 2)
			- 0.000003582 * Math.pow(temp, 2) * Math.pow(humidity, 2);
	}
}
