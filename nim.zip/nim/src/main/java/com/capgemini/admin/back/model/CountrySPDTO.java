package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class CountrySPDTO {
    private int rowId;
    private Long countryId;
    private String countryTitle;
    private String countryTitleFr;
    private int cityCount;
    private Long cityId;
    private String cityTitle;
    private String cityTitleFr;
    private int siteCount;
    private Long siteId;
    private String siteTitle;
    private String siteTitleFr;
    private int buildingCount;
    private Long buildingId;
    private String buildingTitle;
    private String buildingTitleFr;
    private int floorCount;
    private String assetCode;
    private Long countryCdmKeyId;
    private Long cityCdmKeyId;
    private Long siteCdmKeyId;
    private Long buildingCdmKeyId;
    private Boolean isSecured;
}
