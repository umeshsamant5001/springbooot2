package com.capgemini.admin.back.model;

public interface AllLocationsByUser {

    Long getCountryId();

    Long getCityId();

    Long getSiteId();

    Long getBuildingId();

    Integer getCountryLevel();

    Integer getCityLevel();

    Integer getSiteLevel();

    Integer getBuildingLevel();

}
