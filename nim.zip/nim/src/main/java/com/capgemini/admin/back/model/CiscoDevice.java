package com.capgemini.admin.back.model;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "cisco_device")
public class CiscoDevice {
    @Id
    @Column(name = "mac_address")
    private String deviceId;
    @Column(name = "hour", nullable = false)
    private LocalDateTime hour;
    @Column(name = "familiar_name")
    private String familiarName;
    @Column(name = "ip_address")
    private String ipAddress;
    @Column(name = "location")
    private String location;
    @Column(name = "tags")
    private String tags;
    @Column(name = "zone")
    private String zone;
    @Column(name = "workspace")
    private String workspace;
    @Column(name = "site")
    private String site;
    @Column(name = "building")
    private String building;
    @Column(name = "city")
    private String city;
    @Column(name = "country")
    private String country;
    @Column(name = "region")
    private String region;
    @Column(name = "people_count")
    private Integer peopleCount;
    @Column(name = "ambient_noise_dBA")
    private Double ambientNoiseDBA;
    @Column(name = "sound_level_dBA")
    private Double soundLevelDBA;
    @Column(name = "ambient_temperature")
    private Double ambientTemperature;
    @Column(name = "relative_humidity")
    private Double relativeHumidity;
    @Column(name = "air_quality")
    private Double airQuality;
    @Column(name = "email_id")
    private String emailId;
    @Column(name = "device_type")
    private String deviceType;
}