package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class DeviceSPDTO {
    private String uuid;
    private String poiName;
    private String poiTitle;
    private String spaceTypeName;
    private String deviceType;
    private String status;
    private long lastChange;
    private int floorId;

    private Map<String, String> attributes = new HashMap<>();

    @JsonAnySetter
    public void setAttribute(String key, String value) {
        attributes.put(key, value);

    }
}