package com.capgemini.admin.back.model;

import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = false)
@Data
public class PoiGroupSpaceTypeInput {

    @Min(1)
    private Long id;
}
