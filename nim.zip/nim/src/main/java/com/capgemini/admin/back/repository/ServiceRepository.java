package com.capgemini.admin.back.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.Service;

@Repository
public interface ServiceRepository extends JpaRepository<Service, Long> {

   Optional<Service> findByName(@Param("name") String name);

}
