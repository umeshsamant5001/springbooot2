package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.ThresholdConfigurationMapper;
import com.capgemini.admin.back.model.Alert;
import com.capgemini.admin.back.model.AlertType;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.TemperatureUnit;
import com.capgemini.admin.back.model.Threshold;
import com.capgemini.admin.back.model.ThresholdConfiguration;
import com.capgemini.admin.back.model.ThresholdConfigurationDTO;
import com.capgemini.admin.back.model.ThresholdLevel;
import com.capgemini.admin.back.model.ThresholdType;
import com.capgemini.admin.back.repository.CountryRepository;

import com.capgemini.admin.back.service.SpaceTypeService;
import com.capgemini.admin.back.service.CountryService;
import com.capgemini.admin.back.service.SensorAlertService;
import com.capgemini.admin.back.service.ThresholdConfigurationService;
import com.capgemini.admin.back.service.TreeService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@Validated
@RequestMapping(value = ThresholdConfigurationController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ThresholdConfigurationController {

    static final String ROOT_API = "api/thresholdConfiguration";
    @Autowired
    private ThresholdConfigurationService thresholdConfigurationService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private SpaceTypeService spaceTypeService;
    @Autowired
    private SensorAlertService sensorAlertService;
    @Autowired
    private TreeService treeService;
    @Autowired
    private CountryRepository countryRepository;

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class ThresholdWriteInput {
        @NotNull
        private ThresholdType type;

        @NotNull
        private ThresholdLevel level;

        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String value;

        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String unit;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class AlertWriteInput {
        @NotNull
        @Min(0)
        private Integer interval;

        @NotNull
        private AlertType alertType;

        @NotNull
        private Boolean enabled;

        @Min(1)
        private Long thresholdConfigurationId;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class ThresholdConfigurationWriteInput {
        @Min(1)
        private Long id;

        @NotNull
        @Min(1)
        private Long countryId;

        @NotNull
        @Min(1)
        private Long spaceTypeId;

        @NotNull
        private TemperatureUnit temperatureUnit;

        @NotNull
        @Size(min = 1)
        private List<@Valid ThresholdWriteInput> thresholds = new ArrayList<>();

        @NotNull
        @Size(min = 1)
        private List<@Valid AlertWriteInput> alerts = new ArrayList<>();
    }


    /**
     * Delete a thresholdConfiguration by ID.
     *
     * @param thresholdConfigurationId The ID of the thresholdConfigurationId to
     *                                 delete.
     * @return ResponseEntity with no content if successful, else not found
     *         response.
     */
    @DeleteMapping("/{thresholdConfigurationId}")
    public ResponseEntity<Object> deleteThresholdConfiguration(@PathVariable Long thresholdConfigurationId) {

        if (Objects.isNull(thresholdConfigurationId) || thresholdConfigurationId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCountryIds = this.resolveAuthorizedCountryIds();
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long requestedThresholdConfigurationId = Long.valueOf(thresholdConfigurationId);
        ThresholdConfiguration thresholdConfiguration = this.thresholdConfigurationService
                .findByIdAndCountryIdIn(requestedThresholdConfigurationId, authorizedCountryIds);

        if (Objects.isNull(thresholdConfiguration)) {
            return ResponseEntity.notFound().build();
        }
        this.thresholdConfigurationService.deleteThresholdConfiguration(thresholdConfiguration);
        sensorAlertService.launchThresholdConfigurations();
        return ResponseEntity.noContent().build();

    }


    /**
     * Retrieves a thresholdConfiguration by its countryId.
     *
     * @param countryId The countryId of the thresholdConfiguration to retrieve.
     * @return ResponseEntity with a ThresholdConfigurationDTO if successful, else
     *         not found response.
     */
    @GetMapping("/{countryId}")
    public ResponseEntity<List<ThresholdConfigurationDTO>> getThresholdConfigurationByCountryId(
            @PathVariable Long countryId) {

        if (Objects.isNull(countryId)) {
            return ResponseEntity.notFound().build();
        }
        List<ThresholdConfigurationDTO> thresholdConfigurationDTOs = new ArrayList<>();
        thresholdConfigurationDTOs = this.thresholdConfigurationService.getThresholdConfigurationByCountryId(countryId);

        return ResponseEntity.ok(thresholdConfigurationDTOs);
    }

    /**
     * Retrieves all thresholdConfiguration.
     * 
     * @return ResponseEntity with a list of ThresholdConfigurationDTO if
     *         successful, else appropriate error responses.
     */
    @GetMapping
    public ResponseEntity<List<ThresholdConfigurationDTO>> getAllThresholdConfiguration() {
        List<ThresholdConfigurationDTO> thresholdConfigurationDTOs = new ArrayList<>();
        thresholdConfigurationDTOs = this.thresholdConfigurationService.getAllThresholdConfiguration();
        return ResponseEntity.ok(thresholdConfigurationDTOs);
    }

    /**
     * Saves or updates a list of ThresholdConfiguration entities based on the
     * provided DTOs.
     * 
     * In RequestBody thresholdId (id) is present then need to Update
     * OR
     * if threhosdId(id) is not present then need to insert
     * 
     * For each DTO:
     * - If an ID is present, it attempts to update the existing entity.
     * - If no ID is present, it creates a new entity.
     * - Validates the existence of associated Country and SpaceType entities.
     * - Maps the DTO to the entity and persists it.
     *
     * After processing all configurations, it triggers the sensor alert service to
     * launch
     * threshold configurations.
     *
     * @param thresholdConfigurationDTOs List of ThresholdConfigurationDTOs to be
     *                                   saved or updated.
     * @return ResponseEntity containing the list of saved or updated
     *         ThresholdConfigurationDTOs,
     *         or a bad request response if validation fails.
     */
    @PutMapping(value = "/saveOrUpdateAll")
    public ResponseEntity<List<ThresholdConfigurationDTO>> saveOrUpdateThresholdConfigurations(
            @Valid @RequestBody List<@Valid ThresholdConfigurationWriteInput> thresholdConfigurationInputs) {

        if (CollectionUtils.isEmpty(thresholdConfigurationInputs)) {
            return ResponseEntity.badRequest().build();
        }

        List<Long> authorizedCountryIds = this.resolveAuthorizedCountryIds();
        if (CollectionUtils.isEmpty(authorizedCountryIds)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        List<ThresholdConfigurationDTO> resultThresholdConfigurations = new ArrayList<>();

        for (ThresholdConfigurationWriteInput thresholdConfigurationInput : thresholdConfigurationInputs) {
            if (Objects.isNull(thresholdConfigurationInput)) {
                return ResponseEntity.badRequest().build();
            }

            ThresholdConfiguration existingThresholdConfiguration = null;
            if (Objects.nonNull(thresholdConfigurationInput.getId())) {
                Long scopedThresholdConfigurationId = Long.valueOf(thresholdConfigurationInput.getId());
                existingThresholdConfiguration = this.thresholdConfigurationService
                        .findByIdAndCountryIdIn(scopedThresholdConfigurationId, authorizedCountryIds);

                if (Objects.isNull(existingThresholdConfiguration)) {
                    return ResponseEntity.badRequest().build();
                }
            }

            Long scopedCountryId = Long.valueOf(thresholdConfigurationInput.getCountryId());
            if (!authorizedCountryIds.contains(scopedCountryId)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            ThresholdConfiguration sanitizedThresholdConfiguration = this
                    .toSanitizedThresholdConfiguration(thresholdConfigurationInput);

            if (Objects.nonNull(existingThresholdConfiguration)) {
                sanitizedThresholdConfiguration
                        .setId(Long.valueOf(existingThresholdConfiguration.getId()));
            }

            Country country = this.countryService.getCountry(sanitizedThresholdConfiguration.getCountryId());
            SpaceType spaceType = this.spaceTypeService.getSpaceTypeById(sanitizedThresholdConfiguration.getSpaceTypeId());

            if (Objects.nonNull(country) && Objects.nonNull(spaceType)) {
                sanitizedThresholdConfiguration.setModifiedAt((new Date()).getTime() / 1000);

                ThresholdConfiguration savedOrUpdatedThresholdConfiguration = this.thresholdConfigurationService
                        .updateThresholdConfiguration(sanitizedThresholdConfiguration);

                resultThresholdConfigurations.add(ThresholdConfigurationMapper.INSTANCE
                        .thresholdConfigurationToThresholdConfigurationDTO(savedOrUpdatedThresholdConfiguration));
            } else {
                return ResponseEntity.badRequest().build();
            }
        }
        sensorAlertService.launchThresholdConfigurations();
        return ResponseEntity.ok(resultThresholdConfigurations);
    }

    private List<Long> resolveAuthorizedCountryIds() {
        List<Long> allCountryIds = this.countryRepository.findAll().stream()
                .map(Country::getId)
                .filter(Objects::nonNull)
                .map(countryId -> Long.valueOf(countryId))
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(allCountryIds)) {
            return List.of();
        }

        return this.treeService.filterId(LevelEnum.COUNTRY, allCountryIds);
    }

    private ThresholdConfiguration toSanitizedThresholdConfiguration(ThresholdConfigurationWriteInput thresholdConfigurationInput) {
        ThresholdConfiguration sanitizedThresholdConfiguration = new ThresholdConfiguration();
        sanitizedThresholdConfiguration.setId(thresholdConfigurationInput.getId() == null
                ? null
                : Long.valueOf(thresholdConfigurationInput.getId()));
        sanitizedThresholdConfiguration.setCountryId(Long.valueOf(thresholdConfigurationInput.getCountryId()));
        sanitizedThresholdConfiguration.setSpaceTypeId(Long.valueOf(thresholdConfigurationInput.getSpaceTypeId()));
        sanitizedThresholdConfiguration.setTemperatureUnit(thresholdConfigurationInput.getTemperatureUnit() == null
                ? null
                : TemperatureUnit.valueOf(String.valueOf(thresholdConfigurationInput.getTemperatureUnit().name())));

        List<Threshold> sanitizedThresholds = new ArrayList<>();
        for (ThresholdWriteInput thresholdWriteInput : thresholdConfigurationInput.getThresholds()) {
            Threshold sanitizedThreshold = new Threshold();
            sanitizedThreshold.setType(thresholdWriteInput.getType() == null
                    ? null
                    : ThresholdType.valueOf(String.valueOf(thresholdWriteInput.getType().name())));
            sanitizedThreshold.setLevel(thresholdWriteInput.getLevel() == null
                    ? null
                    : ThresholdLevel.valueOf(String.valueOf(thresholdWriteInput.getLevel().name())));
            sanitizedThreshold.setValue(thresholdWriteInput.getValue() == null
                    ? null
                    : new String(String.valueOf(thresholdWriteInput.getValue())));
            sanitizedThreshold.setUnit(thresholdWriteInput.getUnit() == null
                    ? null
                    : new String(String.valueOf(thresholdWriteInput.getUnit())));
            sanitizedThresholds.add(sanitizedThreshold);
        }
        sanitizedThresholdConfiguration.setThresholds(sanitizedThresholds);

        List<Alert> sanitizedAlerts = new ArrayList<>();
        for (AlertWriteInput alertWriteInput : thresholdConfigurationInput.getAlerts()) {
            Alert sanitizedAlert = new Alert();
            sanitizedAlert.setInterval(alertWriteInput.getInterval() == null
                    ? null
                    : Integer.valueOf(alertWriteInput.getInterval()));
            sanitizedAlert.setAlertType(alertWriteInput.getAlertType() == null
                    ? null
                    : AlertType.valueOf(String.valueOf(alertWriteInput.getAlertType().name())));
            sanitizedAlert.setEnabled(alertWriteInput.getEnabled() == null
                    ? null
                    : Boolean.valueOf(String.valueOf(alertWriteInput.getEnabled())));
            sanitizedAlerts.add(sanitizedAlert);
        }
        sanitizedThresholdConfiguration.setAlerts(sanitizedAlerts);

        return sanitizedThresholdConfiguration;
    }

}
