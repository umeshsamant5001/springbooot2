package com.capgemini.admin.back.config;

import java.net.URI;

/**
 * Application constants.
 */
public final class Constants {

    public static final String SYSTEM = "system";
    public static final Integer ACTIVE = 1;
    public static final String ANDROID = "ANDROID";
    public static final String ANDROIDAPP = "androidApp";
    public static final String SMARTOFFICE = "SMARTOFFICE";
    public static final String OFFICEPASS = "OFFICEPASS";
    public static final String INVITE_CATEGORY = "INVITE_CATEGORY";
    public static final String SCHEDULER = "SCHEDULER";
    public static final String IOS = "IOS";
    public static final String SUCCESS = "SUCCESS";
    public static final String PARTIALSUCCESS = "PARTIALSUCCESS";
    public static final Integer ADMIN = 2;
    public static final Integer USER = 1;
    public static final String NULLSTRING = "null";
    public static final String FACILITY_MANAGER = "Facility Manager";
    public static final String MONTH_FILTER_FIRST = "First";
    public static final String MONTH_FILTER_SECOND = "Second";
    public static final String MONTH_FILTER_THIRD = "Third";
    public static final String MONTH_FILTER_FOURTH = "Fourth";
    public static final String MONTH_FILTER_LAST = "Last";
    public static final String CERTIFICATE_NAME = "tablet-smartoffice";
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String COOKIE = "Cookie";
    public static final String TOKEN_PARAM = "token";
    public static final String HEADER_NAME = "Name";
    public static final String HEADER_EMAIL_ID = "Email";
    public static final String HEADER_ROLE_NAME = "Role";
    public static final String HEADER_BUILDING_TITLE = "Location";
    public static final String PLATFORM_KEY = "platform";
    public static final int IDX_NAME = 0;
    public static final int IDX_EMAIL_ID = 1;
    public static final int IDX_ROLE_NAME = 2;
    public static final int IDX_BUILDING_TITLE = 3;
    public static final int SECURED_USER_COLUMN_COUNT = 4;
    // Maximum number of data rows allowed in secured-user CSV import (header excluded).
    // Keeps line-processing loops bounded even when attacker supplies oversized content.
    public static final int MAX_SECURED_USER_IMPORT_DATA_LINES = 10000;
    public static final String SECURED_USER = "Secured User";
    public static final String BETA_USER = "Beta User";

    public static final String API_FIRST_PACKAGE = "com.capgemini.admin.back.web.api";
    public static final String ASSET_CODE = "cdm.asset_code";
    public static final String HIDDEN = "hidden";
    public static final String CONFIG_PATH_NOTIFICATION = "application.notification.push";
    public static final String CONFIG_PATH_NOTIFICATION_EMAIL = "application.notification.email";
    public static final String NOTIFICATION_EMAIL_VALUE = "notification_email_value";
    public static final String FIELD_ERRORS_KEY = "fieldErrors";
    public static final String MESSAGE_KEY = "message";
    public static final String PATH_KEY = "path";
    public static final String VIOLATIONS_KEY = "violations";
    public static final String ERR_CONCURRENCY_FAILURE = "error.concurrencyFailure";
    public static final String ERR_VALIDATION = "error.validation";
    public static final String PROBLEM_BASE_URL = "https://www.jhipster.tech/problem";
    public static final URI DEFAULT_TYPE = URI.create(PROBLEM_BASE_URL + "/problem-with-message");
    public static final URI CONSTRAINT_VIOLATION_TYPE = URI.create(PROBLEM_BASE_URL + "/constraint-violation");
    public static final String BIGINT_DEFAULT_DEFINITION="bigint DEFAULT SELECT DATEDIFF_BIG(MILLISECOND, '1970-01-01', GETUTCDATE())";
    public static final String INVALID_TOKENS_METER_NAME = "security.authentication.invalid-tokens";
    public static final String INVALID_TOKENS_METER_DESCRIPTION = "Indicates validation error count of the tokens presented by the clients.";
    public static final String INVALID_TOKENS_METER_BASE_UNIT = "errors";
    public static final String INVALID_TOKENS_METER_CAUSE_DIMENSION = "cause";
    public static final String CREATEUSER = "createUser";
    public static final String UPDATEUSER = "updateUser";
    public static final String ASSIGNPROFILE = "assignProfile";
    public static final String UPDATE_USER_LOCATIONS = "UPDATE_USER_LOCATIONS";

    private Constants() {}
}
