/**
 * View Models used by Spring MVC REST controllers.
 */
package com.capgemini.admin.back.web.rest.vm;
