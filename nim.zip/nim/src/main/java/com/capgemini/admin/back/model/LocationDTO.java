package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class LocationDTO {
    private Long id;
    private LevelEnum level;
    private Long cdmKeyId;
    private Boolean alertStatus;
}