package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.News;
import org.springframework.data.repository.query.Param;
@Repository
public interface NewsRepository extends JpaRepository<News, Long> {

    @Modifying
    @Query(value = "Update news set status =0  where status=1 AND id <> :id", nativeQuery = true)
    void updatedNews(@Param("id") Long id);

}
