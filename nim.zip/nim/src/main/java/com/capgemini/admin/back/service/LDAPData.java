package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Pattern;



import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.stereotype.Service;

import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.model.EmployeeDetailDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LDAPData implements AutoCloseable {

    private DirContext context;
    private final ApplicationProperties.LDAP ldapConfig;
    private static final Pattern EMAIL_SEARCH_PATTERN = Pattern
            .compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    public LDAPData(ApplicationProperties applicationProperties) {
        this.ldapConfig = applicationProperties.getLdap();
    }


    /**
     * Establishes and returns an LDAP directory context using service account credentials.
     * This method initializes the static `context` variable if not already set.
     *
     * @return the initialized DirContext object, or null if connection fails
     */
     public DirContext getLdapData() {
        if (ldapConfig == null) {
            throw new IllegalStateException("LDAP configuration is not initialized");
        }

        String serviceUserName = ldapConfig.getServiceUserName();
        String servicePassword = ldapConfig.getServicePassword();
        String serverURL = ldapConfig.getServerURL();
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, serverURL);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, serviceUserName);
        env.put(Context.SECURITY_CREDENTIALS, servicePassword);

        try {
            context = new InitialDirContext(env);
        } catch (NamingException e) {
            log.error("Failed to initialize LDAP directory context", e);
        }
        return context;
    }
    // public static DirContext getLdapData() {
    //     String serviceUserName = "SVC-IN-MOBILE@capgemini.com";
    //     String servicePasswordEnv = null;
    //     char[] servicePassword = null;

    //     try {
    //         servicePasswordEnv = System.getenv("LDAP_SERVICE_PASSWORD");
    //         if (servicePasswordEnv == null || servicePasswordEnv.isEmpty()) {
    //             throw new IllegalStateException("LDAP service credential is not configured");
    //         }
    //         servicePassword = servicePasswordEnv.toCharArray();

    //         String serverURL = "ldap://ldapinmum.capgemini.com";
    //         Hashtable<String, Object> env = new Hashtable<>();
    //         env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    //         env.put(Context.PROVIDER_URL, serverURL);
    //         env.put(Context.SECURITY_AUTHENTICATION, "simple");
    //         env.put(Context.SECURITY_PRINCIPAL, serviceUserName);
    //         env.put(Context.SECURITY_CREDENTIALS, servicePassword);

    //         context = new InitialDirContext(env);
    //         return context;
    //     } catch (NamingException e) {
    //         log.error("Failed to initialize LDAP directory context", e);
    //         throw new IllegalStateException("Unable to initialize LDAP context");
    //     } finally {
    //         if (servicePassword != null) {
    //             Arrays.fill(servicePassword, '\0');
    //         }
    //         servicePasswordEnv = null;
    //     }
    // }
    


    /**
     * Searches the LDAP directory for user details based on the provided search string (typically an email).
     * Extracts attributes like country, email, first name, full name, last name, and NT login ID.
     *
     * @param searchString the email or identifier to search for
     * @return a list of EmployeeDetailDTOs containing user details
     * @throws Exception if the LDAP search fails
     */
    public List<EmployeeDetailDTO> getUserDetailsBySearch(String searchString) throws Exception {
        String normalizedSearchString = searchString == null ? null : searchString.trim();
        if (normalizedSearchString == null || !EMAIL_SEARCH_PATTERN.matcher(normalizedSearchString).matches()) {
            throw new IllegalArgumentException("Invalid LDAP search input");
        }
        String escapedSearchString = this.escapeLDAPSearchFilter(normalizedSearchString);

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);


        String filter = "(&(objectClass=user)(|(mail={0})))";
        log.info("Performing LDAP search with base DN: OU=Employees,DC=corp,DC=capgemini,DC=com and filter template: {}",
                filter);
        NamingEnumeration<SearchResult> results = context.search("OU=Employees,DC=corp,DC=capgemini,DC=com", filter,
                new Object[] { escapedSearchString }, searchControls);
        List<EmployeeDetailDTO> employeeDetailDTOs = new ArrayList<>();

        while (results.hasMoreElements()) {
            SearchResult result = results.nextElement();
            EmployeeDetailDTO employeeDetailDTO = new EmployeeDetailDTO();

            Attribute countryAttribute = result.getAttributes().get("co");
            String country = countryAttribute != null ? countryAttribute.get().toString() : null;
            if (country != null && !country.isEmpty()) {
                employeeDetailDTO.setCountry(country);
            }

            Attribute emailAttribute = result.getAttributes().get("mail");
            String emailID = emailAttribute != null ? emailAttribute.get().toString() : null;
            if (emailID != null && !emailID.isEmpty()) {
                employeeDetailDTO.setEmailID(emailID);
            }

            Attribute firstNameAttribute = result.getAttributes().get("givenname");
            String firstName = firstNameAttribute != null ? firstNameAttribute.get().toString() : null;
            if (firstName != null && !firstName.isEmpty()) {
                employeeDetailDTO.setFirstName(firstName);
            }

            Attribute fullNameAttribute = result.getAttributes().get("displayname");
            String fullName = fullNameAttribute != null ? fullNameAttribute.get().toString() : null;
            if (fullName != null && !fullName.isEmpty()) {
                employeeDetailDTO.setFullName(fullName);
            }

            Attribute lastNameAttribute = result.getAttributes().get("sn");
            String lastName = lastNameAttribute != null ? lastNameAttribute.get().toString() : null;
            if (lastName != null && !lastName.isEmpty()) {
                employeeDetailDTO.setLastName(lastName);
            }

            Attribute ntLoginIDAttribute = result.getAttributes().get("cn");
            String ntLoginID = ntLoginIDAttribute != null ? ntLoginIDAttribute.get().toString() : null;
            if (ntLoginID != null && !ntLoginID.isEmpty()) {
                employeeDetailDTO.setNtLoginID(ntLoginID);
            }

            employeeDetailDTOs.add(employeeDetailDTO);
        }

        return employeeDetailDTOs;
    }

    private  String escapeLDAPSearchFilter(String value) {
        StringBuilder escaped = new StringBuilder();
        for (char c : value.toCharArray()) {
            switch (c) {
            case '\\':
                escaped.append("\\5c");
                break;
            case '*':
                escaped.append("\\2a");
                break;
            case '(':
                escaped.append("\\28");
                break;
            case ')':
                escaped.append("\\29");
                break;
            case '\u0000':
                escaped.append("\\00");
                break;
            case '/':
                escaped.append("\\2f");
                break;
            default:
                escaped.append(c);
            }
        }
        return escaped.toString();
    }

    @Override
    public void close() throws Exception {
        // Implement the closing logic here
        if (context != null) {
            context.close();
        }
    }


}
