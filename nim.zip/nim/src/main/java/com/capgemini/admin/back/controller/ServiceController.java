package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.collections4.CollectionUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.mapper.MasterAttributeMapper;
import com.capgemini.admin.back.mapper.ServiceMapper;
import com.capgemini.admin.back.model.EnumControlType;
import com.capgemini.admin.back.model.EnumDataType;
import com.capgemini.admin.back.model.InvalidParameterException;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.MasterAttribute;
import com.capgemini.admin.back.model.MasterAttributeDTO;
import com.capgemini.admin.back.model.Preference;
import com.capgemini.admin.back.model.Service;
import com.capgemini.admin.back.model.ServiceDTO;
import com.capgemini.admin.back.model.ServiceLocationDTO;
import com.capgemini.admin.back.model.ServiceTranslationDTO;

import com.capgemini.admin.back.model.ServiceUser;
import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.CityService;
import com.capgemini.admin.back.service.CountryService;
import com.capgemini.admin.back.service.MasterAttributeService;
import com.capgemini.admin.back.service.PreferenceService;
import com.capgemini.admin.back.service.ServiceService;
import com.capgemini.admin.back.service.ServiceUserService;
import com.capgemini.admin.back.service.SiteService;
import com.capgemini.admin.back.config.Constants;

import lombok.Data;


@RestController
@RequestMapping(value = ServiceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ServiceController {

    static final String ROOT_API = "api/services";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class ServiceLocationWriteRequest {
        @NotNull
        private LevelEnum level;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String status;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class ServiceTranslationWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String key;
        @Size(max = 10000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String value;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String locale;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class ServiceWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String image;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String name;
        @Min(0)
        private Integer priority;
        @NotNull
        @Size(max = 1000)
        private Map<String, String> attributes = new HashMap<String, String>();
        @NotNull
        @Valid
        @Size(max = 1000)
        private List<ServiceLocationWriteRequest> locations = new ArrayList<>();
        @NotNull
        @Valid
        @Size(max = 1000)
        private List<ServiceTranslationWriteRequest> translations = new ArrayList<>();
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class MasterAttributeWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String name;
        private EnumControlType controlType;
        private EnumDataType dataType;
        @Min(0)
        private Integer length;
        private Boolean mandatory;
        @Size(max = 35)
        private List<String> controlValue = new ArrayList<>();
    }


    @Autowired
    private ServiceService serviceService;


    @Autowired
    private MasterAttributeService masterAttributeService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private CityService cityService;

    @Autowired
    private SiteService siteService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private PreferenceService preferenceService;

    @Autowired
    private ServiceUserService serviceUserService;

    @GetMapping
    public ResponseEntity<List<ServiceDTO>> getAll(
            @RequestParam(defaultValue = "false") boolean withLocationName) {

        List<Service> lServices = this.serviceService.findAll();
        if (CollectionUtils.isEmpty(lServices)) {
            return ResponseEntity.noContent().build();
        }

        List<ServiceDTO> lServiceDTOs = lServices
                .stream()
                .map(service -> ServiceMapper.INSTANCE.serviceToServiceDTO(service))
                .collect(Collectors.toList());

        if (withLocationName) {
            this.addNameOnLocation(lServiceDTOs);
        }

        return ResponseEntity.ok(lServiceDTOs);
    }

    @PostMapping()
    public ResponseEntity<ServiceDTO> createService(
            @Valid @RequestBody ServiceWriteRequest serviceRequest) {

        if (Objects.isNull(serviceRequest)) {
            return ResponseEntity.badRequest().build();
        }

        ServiceDTO sanitizedServiceDTO = this.toSanitizedServiceDTO(serviceRequest, null);
        Service service = ServiceMapper.INSTANCE.serviceDTOToService(sanitizedServiceDTO);


        if (!Objects.isNull(this.serviceService.findByName(service.getName()))) {
            return ResponseEntity.badRequest().build();
        }


        if (Boolean.FALSE.equals(this.checkServiceAttributs(service))) {
            return ResponseEntity.badRequest().build();
        }
        if (Boolean.FALSE.equals(this.serviceService.checkServiceLocation(service))) {
            return ResponseEntity.badRequest().build();
        }
        this.serviceService.setServiceTranslation(service);
        if (Objects.nonNull(service.getId())) {
            return ResponseEntity.badRequest().build();
        }

        // Defense against unsafe object binding: persist only a server-built,
        // sanitized entity instance (never the bound request object).
        Service savedService = this.serviceService.save(service);

        return ResponseEntity.ok(ServiceMapper.INSTANCE.serviceToServiceDTO(savedService));
    }

    @GetMapping("/{serviceId}")
    public ResponseEntity<ServiceDTO> getServiceById(
            @PathVariable Long serviceId,
            @RequestParam(defaultValue = "false") boolean withLocationName) {
        Service service = this.serviceService.findById(serviceId);

        if (Objects.isNull(service)) {
            return ResponseEntity.notFound().build();
        }

        ServiceDTO serviceDTO = ServiceMapper.INSTANCE.serviceToServiceDTO(service);

        if (withLocationName) {
            this.addNameOnLocation(Arrays.asList(serviceDTO));
        }

        return ResponseEntity.ok(serviceDTO);
    }

    @PutMapping("/{serviceId}")
    public ResponseEntity<ServiceDTO> updateServiceById(
            @PathVariable Long serviceId,
            @Valid @RequestBody ServiceWriteRequest serviceRequest) {

        Service service = this.serviceService.findById(serviceId);

        if (Objects.isNull(service)) {
            return ResponseEntity.notFound().build();
        }

        if (Objects.isNull(serviceRequest)) {
            return ResponseEntity.badRequest().build();
        }

        ServiceDTO sanitizedServiceDTO = this.toSanitizedServiceDTO(serviceRequest, serviceId);
        service = ServiceMapper.INSTANCE.serviceDTOToService(sanitizedServiceDTO);



        if (Boolean.FALSE.equals(this.checkServiceAttributs(service))) {

            return ResponseEntity.badRequest().build();
        }

        if (Boolean.FALSE.equals(this.serviceService.checkServiceLocation(service))) {
            return ResponseEntity.badRequest().build();
        }
        this.serviceService.setServiceTranslation(service);

        // Defense against unsafe object binding: persist only a server-built,
        // sanitized entity instance (never the bound request object).
        Service savedService = this.serviceService.save(service);


        return ResponseEntity.ok(ServiceMapper.INSTANCE.serviceToServiceDTO(savedService));
    }

    @Transactional
    @DeleteMapping("/{serviceId}")
    public ResponseEntity<Object> deleteServiceById(@PathVariable Long serviceId) {
        Service service = this.serviceService.findById(serviceId);

        if (Objects.isNull(service)) {
            return ResponseEntity.notFound().build();
        }
        List<Preference> preferences = this.preferenceService.getFavoriteService(service);

        if (preferences != null && !preferences.isEmpty()) {
            for (Preference preference : preferences) {
                preference.getFavoriteServices().remove(service);
                this.preferenceService.save(preference);
            }
        }

        List<ServiceUser> serviceUsers = this.serviceUserService.getServiceById(serviceId);
        if (serviceUsers != null && !serviceUsers.isEmpty()) {
            this.serviceUserService.deleteAll(serviceUsers);
        }

        this.serviceService.delete(service);

        return ResponseEntity.ok().build();
    }

    @GetMapping("/attributes/master")
    public ResponseEntity<List<MasterAttributeDTO>> getAllMasterAttributes() throws InvalidParameterException {
        // Specification changed so now we only return mandatory and that's all
        List<MasterAttribute> lMasterAttribute = this.masterAttributeService.findAllMandatory();
        if (CollectionUtils.isEmpty(lMasterAttribute)) {
            return ResponseEntity.noContent().build();
        }
        List<MasterAttributeDTO> dtosList = new ArrayList<>();
        for (MasterAttribute masterAttribute : lMasterAttribute) {
            MasterAttributeDTO dto = MasterAttributeMapper.INSTANCE
                    .masterAttributeToMasterAttributeDTO(masterAttribute);
            dtosList.add(dto);
        }
        return ResponseEntity.ok(dtosList);
    }

    @PostMapping("/attributes/master")
    public ResponseEntity<MasterAttributeDTO> createMasterAttributes(
            @Valid @RequestBody MasterAttributeWriteRequest masterAttributeRequest) {

        if (Objects.isNull(masterAttributeRequest)) {
            return ResponseEntity.badRequest().build();
        }

        try {
            if (Objects.isNull(masterAttributeRequest.getName())) {
                // The name must be present
                return ResponseEntity.badRequest().build();
            }

            MasterAttribute existingMasterAttribute = this.masterAttributeService.findByName(masterAttributeRequest.getName());

            if (Objects.nonNull(existingMasterAttribute)) {
                // An attribut already exist with this name
                return ResponseEntity.badRequest().build();
            }

            // Defense against unsafe object binding: create a new persistence model
            // using value-creating copies so the bound request reference never reaches
            // the repository save sink.
            MasterAttribute masterAttribute = this.toSanitizedMasterAttribute(masterAttributeRequest, null);



            MasterAttribute savedMasterAttribute = this.masterAttributeService.save(masterAttribute);

            return ResponseEntity
                    .ok(MasterAttributeMapper.INSTANCE.masterAttributeToMasterAttributeDTO(savedMasterAttribute));
        } catch (InvalidParameterException e) {
            return ResponseEntity.badRequest().build();
        }

    }

    @GetMapping("/attributes/master/{name}")
    public ResponseEntity<MasterAttributeDTO> getMasterAttributeByName(@PathVariable String name)
            throws InvalidParameterException {
        MasterAttribute masterAttribute = this.masterAttributeService.findByName(name);

        if (Objects.isNull(masterAttribute)) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(MasterAttributeMapper.INSTANCE.masterAttributeToMasterAttributeDTO(masterAttribute));
    }

    @PutMapping("/attributes/master/{name}")
    public ResponseEntity<MasterAttributeDTO> updateMasterAttributeByName(
            @PathVariable String name,
            @Valid @RequestBody MasterAttributeWriteRequest masterAttributeRequest) throws InvalidParameterException {

        MasterAttribute masterAttribute = this.masterAttributeService.findByName(name);

        if (Objects.isNull(masterAttribute)) {
            return ResponseEntity.notFound().build();
        }

        if (Objects.isNull(masterAttributeRequest)) {
            return ResponseEntity.badRequest().build();
        }

        // Defense against unsafe object binding: create a fresh model from allowed
        // fields only. The identifier is re-derived from the path variable.
        masterAttribute = this.toSanitizedMasterAttribute(masterAttributeRequest, name);



        MasterAttribute savedMasterAttribute = this.masterAttributeService.save(masterAttribute);

        return ResponseEntity
                .ok(MasterAttributeMapper.INSTANCE.masterAttributeToMasterAttributeDTO(savedMasterAttribute));
    }

    @DeleteMapping("/attributes/master/{name}")
    public ResponseEntity<Object> deleteMasterAttributeByName(@PathVariable String name) {
        MasterAttribute masterAttribute = this.masterAttributeService.findByName(name);

        if (Objects.isNull(masterAttribute)) {
            return ResponseEntity.notFound().build();
        }

        this.masterAttributeService.delete(masterAttribute);

        return ResponseEntity.ok().build();
    }

    /**
     * Check if all the attributs, and their values, are defined in the
     * MasterAttributs.
     * 
     * @param service The service to check
     * @return `true` if the name of the attributs and the values are correct.
     *         `false` otherwise
     */
    private boolean checkServiceAttributs(Service service) {
        // Check if all mandatory attributs is present
        boolean allMandatory = this.masterAttributeService.findAllMandatory()
                .stream()
                .allMatch(masterAttribute -> {
                    String masterName = masterAttribute.getName();

                    return service.getAttributes().containsKey(masterName);
                });

        if (!allMandatory) {
            return false;
        }

        // Check if all attributs is present in masterAttribut with correct value
        return service.getAttributes().keySet().stream()
                .allMatch(name -> {
                    String value = service.getAttributes().get(name);

                    if (Objects.isNull(value)) {
                        // No null value autorised
                        return false;
                    }

                    MasterAttribute masterAttribute = this.masterAttributeService.findByName(name);

                    if (Objects.isNull(masterAttribute)) {
                        return false;
                    }
                    // There was a late change in specification , platform values shouldn't be
                    // restricted to enum...
                    if (name.equals(Constants.PLATFORM_KEY)) {
                        return true;
                    }
                    if (EnumControlType.INPUT.equals(masterAttribute.getControlType())
                            || EnumControlType.TEXTAREA.equals(masterAttribute.getControlType())) {
                        // In case of user input field, no value is tested.
                        return true;
                    }

                    return masterAttribute.getControlValue()
                            .stream()
                            .anyMatch(masterValue -> value.equals(masterValue));
                });
    }

    private Service toSanitizedService(ServiceWriteRequest serviceRequest, Long serviceId) {
        Service service = new Service();
        service.setId(serviceId == null ? null : Long.valueOf(serviceId));
        service.setImage(serviceRequest.getImage() == null ? null : new String(String.valueOf(serviceRequest.getImage())));
        service.setName(serviceRequest.getName() == null ? null : new String(String.valueOf(serviceRequest.getName())));
        service.setPriority(serviceRequest.getPriority() == null ? null : Integer.valueOf(serviceRequest.getPriority()));
        service.setAttributes(this.sanitizeServiceAttributes(serviceRequest.getAttributes()));
        service.setLocations(this.toSanitizedServiceLocations(serviceRequest.getLocations(), service));
        service.setTranslations(this.toSanitizedServiceTranslations(serviceRequest.getTranslations(), service));
        return service;
    }

    private ServiceDTO toSanitizedServiceDTO(ServiceWriteRequest serviceRequest, Long serviceId) {
        ServiceDTO serviceDTO = new ServiceDTO();
        serviceDTO.setId(serviceId == null ? null : Long.valueOf(serviceId));
        serviceDTO.setImage(serviceRequest.getImage() == null ? null : new String(String.valueOf(serviceRequest.getImage())));
        serviceDTO.setName(serviceRequest.getName() == null ? null : new String(String.valueOf(serviceRequest.getName())));
        serviceDTO.setPriority(serviceRequest.getPriority() == null ? null : Integer.valueOf(serviceRequest.getPriority()));
        serviceDTO.setAttributes(this.sanitizeServiceAttributes(serviceRequest.getAttributes()));
        serviceDTO.setLocations(this.toSanitizedServiceLocationDTOs(serviceRequest.getLocations()));
        serviceDTO.setTranslations(this.toSanitizedServiceTranslationDTOs(serviceRequest.getTranslations()));
        return serviceDTO;
    }

    private List<ServiceLocationDTO> toSanitizedServiceLocationDTOs(List<ServiceLocationWriteRequest> locations) {
        List<ServiceLocationDTO> sanitizedLocations = new ArrayList<>();
        if (locations == null) {
            return sanitizedLocations;
        }

        for (ServiceLocationWriteRequest locationInput : locations) {
            if (locationInput == null) {
                continue;
            }
            ServiceLocationDTO location = new ServiceLocationDTO();
            location.setLevel(locationInput.getLevel() == null
                    ? null
                    : LevelEnum.valueOf(String.valueOf(locationInput.getLevel().name())));
            location.setCdmKeyId(locationInput.getCdmKeyId() == null ? null : Long.valueOf(locationInput.getCdmKeyId()));
            location.setStatus(locationInput.getStatus() == null
                    ? null
                    : new String(String.valueOf(locationInput.getStatus())));
            sanitizedLocations.add(location);
        }

        return sanitizedLocations;
    }

    private List<ServiceTranslationDTO> toSanitizedServiceTranslationDTOs(
            List<ServiceTranslationWriteRequest> translations) {
        List<ServiceTranslationDTO> sanitizedTranslations = new ArrayList<>();
        if (translations == null) {
            return sanitizedTranslations;
        }

        for (ServiceTranslationWriteRequest translationInput : translations) {
            if (translationInput == null) {
                continue;
            }
            ServiceTranslationDTO translation = new ServiceTranslationDTO();
            translation.setKey(translationInput.getKey() == null
                    ? null
                    : new String(String.valueOf(translationInput.getKey())));
            translation.setValue(translationInput.getValue() == null
                    ? null
                    : new String(String.valueOf(translationInput.getValue())));
            translation.setLocale(translationInput.getLocale() == null
                    ? null
                    : new String(String.valueOf(translationInput.getLocale())));
            sanitizedTranslations.add(translation);
        }

        return sanitizedTranslations;
    }

    


    

    private List<com.capgemini.admin.back.model.ServiceLocation> toSanitizedServiceLocations(
            List<ServiceLocationWriteRequest> locations,
            Service service) {
        List<com.capgemini.admin.back.model.ServiceLocation> sanitizedLocations = new ArrayList<>();
        if (locations == null) {
            return sanitizedLocations;
        }

        for (ServiceLocationWriteRequest locationInput : locations) {
            if (locationInput == null) {
                continue;
            }
            com.capgemini.admin.back.model.ServiceLocation location = new com.capgemini.admin.back.model.ServiceLocation();
            location.setLevel(locationInput.getLevel() == null
                    ? null
                    : LevelEnum.valueOf(String.valueOf(locationInput.getLevel().name())));

            location.setCdmKeyId(locationInput.getCdmKeyId() == null ? null : Long.valueOf(locationInput.getCdmKeyId()));
            location.setStatus(locationInput.getStatus() == null
                    ? null
                    : new String(String.valueOf(locationInput.getStatus())));
            location.setService(service);
            sanitizedLocations.add(location);
        }

        return sanitizedLocations;
    }

    private List<com.capgemini.admin.back.model.ServiceTranslation> toSanitizedServiceTranslations(
            List<ServiceTranslationWriteRequest> translations,
            Service service) {
        List<com.capgemini.admin.back.model.ServiceTranslation> sanitizedTranslations = new ArrayList<>();
        if (translations == null) {
            return sanitizedTranslations;
        }

        for (ServiceTranslationWriteRequest translationInput : translations) {
            if (translationInput == null) {
                continue;
            }
            com.capgemini.admin.back.model.ServiceTranslation translation = new com.capgemini.admin.back.model.ServiceTranslation();
            translation.setKey(translationInput.getKey() == null
                    ? null
                    : new String(String.valueOf(translationInput.getKey())));
            translation.setValue(translationInput.getValue() == null
                    ? null
                    : new String(String.valueOf(translationInput.getValue())));
            translation.setLocale(translationInput.getLocale() == null
                    ? null
                    : new String(String.valueOf(translationInput.getLocale())));
            translation.setService(service);
            sanitizedTranslations.add(translation);
        }

        return sanitizedTranslations;
    }

    private Map<String, String> sanitizeServiceAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<String, String>();

        if (attributes == null) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

    private MasterAttribute toSanitizedMasterAttribute(MasterAttributeWriteRequest masterAttributeRequest, String name)
            throws InvalidParameterException {
        MasterAttribute masterAttribute = new MasterAttribute();
        masterAttribute.setName(name == null
                ? (masterAttributeRequest.getName() == null
                        ? null
                        : new String(String.valueOf(masterAttributeRequest.getName())))
                : new String(String.valueOf(name)));
        masterAttribute.setControlType(masterAttributeRequest.getControlType() == null
                ? null
                : EnumControlType.valueOf(String.valueOf(masterAttributeRequest.getControlType().name())));
        masterAttribute.setDataType(masterAttributeRequest.getDataType() == null
                ? null
                : EnumDataType.valueOf(String.valueOf(masterAttributeRequest.getDataType().name())));
        masterAttribute.setLength(masterAttributeRequest.getLength() == null
                ? null
                : Integer.valueOf(masterAttributeRequest.getLength()));
        masterAttribute.setMandatory(masterAttributeRequest.getMandatory() == null
                ? null
                : Boolean.valueOf(String.valueOf(masterAttributeRequest.getMandatory())));

        List<String> sanitizedControlValues = new ArrayList<>();
        if (masterAttributeRequest.getControlValue() != null) {
            for (String controlValue : masterAttributeRequest.getControlValue()) {
                sanitizedControlValues.add(controlValue == null ? null : new String(String.valueOf(controlValue)));
            }
        }
        masterAttribute.setControlValue(sanitizedControlValues);
        return masterAttribute;
    }

    /**
     * Add the name on all the Location of Services
     * 
     * @param services The list of ServiceDTO
     */
    private void addNameOnLocation(List<ServiceDTO> services) {

        Map<LevelEnum, List<ServiceLocationDTO>> mapLocations = services.stream()
                // We flat the stream to have only one stream of locations
                .flatMap(service -> service.getLocations().stream())
                // We convert the stream to a map of locations based by level
                .collect(Collectors.toMap(
                        ServiceLocationDTO::getLevel,
                        location -> new ArrayList<>(Arrays.asList(location)),
                        (location1, location2) -> {
                            location1.addAll(location2);
                            return location1;
                        }));

        if (mapLocations.containsKey(LevelEnum.COUNTRY)) {
            this.addNameOnLocationByLevel(
                    LevelEnum.COUNTRY,
                    mapLocations.get(LevelEnum.COUNTRY),
                    cdmKeyList -> this.countryService.getNameByCmdKeyId(cdmKeyList));
        }

        if (mapLocations.containsKey(LevelEnum.CITY)) {
            this.addNameOnLocationByLevel(
                    LevelEnum.CITY,
                    mapLocations.get(LevelEnum.CITY),
                    cdmKeyList -> this.cityService.getNameByCmdKeyId(cdmKeyList));
        }

        if (mapLocations.containsKey(LevelEnum.SITE)) {
            this.addNameOnLocationByLevel(
                    LevelEnum.SITE,
                    mapLocations.get(LevelEnum.SITE),
                    cdmKeyList -> this.siteService.getNameByCmdKeyId(cdmKeyList));
        }

        if (mapLocations.containsKey(LevelEnum.BUILDING)) {
            this.addNameOnLocationByLevel(
                    LevelEnum.BUILDING,
                    mapLocations.get(LevelEnum.BUILDING),
                    cdmKeyList -> this.buildingService.getNameByCmdKeyId(cdmKeyList));
        }
    }

    /**
     * Add the name of all the Locations, based on the level.
     * 
     * @param level        The level for all the locations
     * @param locations    The list of location
     * @param nameProvider The function which returns a map of name based on the
     *                     cdmKeyId.
     */
    private void addNameOnLocationByLevel(
            LevelEnum level,
            List<ServiceLocationDTO> locations,
            Function<List<Long>, Map<Long, String>> nameProvider) {
        // Get all the cdmKeyId
        List<Long> cmdKeyList = locations
                .stream()
                .map(ServiceLocationDTO::getCdmKeyId)
                .collect(Collectors.toList());
        // Get the name for each cdmKeyId
        Map<Long, String> mapName = nameProvider.apply(cmdKeyList);

        // Associate the name to the location
        locations
                .stream()
                .forEach(location -> {
                    Long cmdKeyId = location.getCdmKeyId();
                    if (mapName.containsKey(cmdKeyId)) {
                        location.setName(mapName.get(cmdKeyId));
                    }
                });
    }
}
