package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.PortalErrorLogging;
import com.capgemini.admin.back.model.PortalErrorLoggingDTO;

@Mapper(config = DtoMapperConfig.class)
public interface PortalErrorLoggingMapper {

    PortalErrorLoggingMapper INSTANCE = Mappers.getMapper(PortalErrorLoggingMapper.class);

    PortalErrorLogging portalErrorLoggingDTOToEntity(PortalErrorLoggingDTO in);

    PortalErrorLoggingDTO portalErrorLoggingToDTO(PortalErrorLogging in);
}
