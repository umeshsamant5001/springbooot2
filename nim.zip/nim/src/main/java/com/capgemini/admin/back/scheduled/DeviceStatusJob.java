package com.capgemini.admin.back.scheduled;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.capgemini.admin.back.service.DeviceService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DeviceStatusJob {

    @Autowired
    private DeviceService deviceService;

    @Scheduled(cron = "0 0 0,12 * * ?") // Runs every day at midnight or 0 */24 * * *
    public void updateStatusDevices() {
        this.deviceService.updateDeviceStatuses();
    }

    @Scheduled(cron = "0 0 * * * ?") // Runs every hour
    public void updateTabletStatusDevices() {
        log.info(" Scheduled task triggered: updateTabletStatusDevices");
        try {
            deviceService.updateTabletDeviceStatuses();
            log.info("Tablet device status update task completed successfully.");
        } catch (Exception ex) {
            log.error("Error during scheduled tablet device status update", ex);
        }
    }

    @Scheduled(cron = "0 0 3 * * ?") // Runs every day at 3 am
    public void cleanObsoletePoiSensorLinks() {
        this.deviceService.cleanObsoletePoiSensorLinks();
    }

}
