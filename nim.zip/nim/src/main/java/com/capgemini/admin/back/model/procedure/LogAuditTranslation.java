package com.capgemini.admin.back.model.procedure;

import lombok.Data;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.GenerationType;
import javax.persistence.Column;
import javax.persistence.Lob;

@Data
@Entity
@Table(name = "logaudit_translationservice")
public class LogAuditTranslation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LogAuditTranslation_Generator")
    @SequenceGenerator(name = "LogAuditTranslation_Generator", sequenceName = "LogAuditTranslation_Sequence")
    private Long logId;

    @Lob
    @Column(name = "Description")
    private String description;

    @Column(name = "Status")
    private String status;

    @Column(name = "CreatedDate")
    private String createdDate;

    @Column(name = "TranslationServiceType")
    private String translationServiceType;

    @Lob
    @Column(name = "Exception")
    private String exception;
}