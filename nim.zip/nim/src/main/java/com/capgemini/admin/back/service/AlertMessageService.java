package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.AlertMessageMapper;
import com.capgemini.admin.back.model.AlertMessage;
import com.capgemini.admin.back.model.AlertMessageDTO;
import com.capgemini.admin.back.model.AlertMessageLocation;
import com.capgemini.admin.back.model.AlertType;
import com.capgemini.admin.back.model.FacilityManager;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.ThresholdType;

import com.capgemini.admin.back.repository.AlertMessageRepository;
import com.capgemini.admin.back.repository.FacilityManagerRepository;
import com.capgemini.admin.back.web.rest.errors.BadRequestAlertException;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AlertMessageService {

    @Data
    public static class AlertMessageLocationUpsertInput {
        private LevelEnum level;
        private Long cdmKeyId;
        private String status;
        private Long countryId;
        private String countryName;
    }

    @Data
    public static class AlertMessageUpsertInput {
        private Long spaceTypeId;
        private String spaceTypeName;
        private ThresholdType thresholdType;
        private AlertType alertCategory;
        private String title;
        private String message;
        private List<AlertMessageLocationUpsertInput> alertMessageLocations = new ArrayList<>();
    }

    @Autowired
    private AlertMessageRepository alertMessageRepository;


    @Autowired
    private FacilityManagerRepository facilityManagerRepository;

    @Transactional
    public AlertMessage createAlertMessage(AlertMessageUpsertInput alertMessageInput) throws BadRequestAlertException {
        AlertMessage savedAlertMessage = new AlertMessage();
        try {
            AlertMessage sanitizedForSave = sanitizeForPersistence(alertMessageInput);
            savedAlertMessage = this.alertMessageRepository.saveAndFlush(sanitizedForSave);
        } catch (Exception e) {
            log.info("CreatealertMessage >> {}", sanitizeForLog(e.getMessage()));
        }
        return savedAlertMessage;
    }


    /**
     * Retrieves a alertMessage by its ID.
     *
     * @param id The ID of the alertMessage.
     * @return The alertMessage response.
     */
    @Transactional
    public AlertMessage getAlertMessageById(Long id) {
        AlertMessage alertMessage = this.alertMessageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AlertMessage not found with ID :: " + id));
        if (Objects.isNull(alertMessage)) {
            return null;
        }
        return alertMessage;
    }

    /**
     * Updates an existing alertMessage based on the provided AlertMessageDTO.
     *
     * @param oldAlertMessage The existing alertMessage to be updated.
     * @param alertMessageDTO The AlertMessageDTO representing the updated
     *                        alertMessage.
     * @return The updated alertMessage.
     * @throws BadRequestAlertException
     */
    @Transactional
    public AlertMessage updateAlertMessage(AlertMessageUpsertInput alertMessageInput, Long id) throws BadRequestAlertException {
        AlertMessage oldAlertMessage = this.alertMessageRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("AlertMessage not found with id: " + id));

        AlertMessage sanitizedForUpdate = sanitizeForPersistence(alertMessageInput);


        oldAlertMessage.setModifiedAt(System.currentTimeMillis() / 1000);
        oldAlertMessage.setSpaceTypeId(sanitizedForUpdate.getSpaceTypeId() == null
                ? null
                : Long.valueOf(sanitizedForUpdate.getSpaceTypeId()));
        oldAlertMessage.setSpaceTypeName(sanitizedForUpdate.getSpaceTypeName() == null
                ? null
                : new String(sanitizedForUpdate.getSpaceTypeName().trim()));
        oldAlertMessage.setThresholdType(sanitizedForUpdate.getThresholdType() == null
                ? null
                : ThresholdType.valueOf(String.valueOf(sanitizedForUpdate.getThresholdType().name())));
        oldAlertMessage.setAlertCategory(sanitizedForUpdate.getAlertCategory() == null
                ? null
                : AlertType.valueOf(String.valueOf(sanitizedForUpdate.getAlertCategory().name())));
        oldAlertMessage.setTitle(sanitizedForUpdate.getTitle() == null
                ? null
                : new String(sanitizedForUpdate.getTitle().trim()));
        oldAlertMessage.setMessage(sanitizedForUpdate.getMessage() == null
                ? null
                : new String(sanitizedForUpdate.getMessage().trim()));

        // Update AlertMessageLocations with value-creating copies only.
        oldAlertMessage.getAlertMessageLocations().clear();
        if (sanitizedForUpdate.getAlertMessageLocations() != null) {
            sanitizedForUpdate.getAlertMessageLocations().forEach(inLocation -> {
                if (inLocation == null) {
                    return;
                }
                AlertMessageLocation safeLocation = new AlertMessageLocation();
                safeLocation.setId(null);
                safeLocation.setAlertMessageId(null);
                safeLocation.setLevel(inLocation.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(inLocation.getLevel().name())));
                safeLocation.setCdmKeyId(inLocation.getCdmKeyId() == null ? null : Long.valueOf(inLocation.getCdmKeyId()));
                safeLocation.setStatus(inLocation.getStatus() == null ? null : new String(inLocation.getStatus().trim()));
                safeLocation.setCountryId(inLocation.getCountryId() == null ? null : Long.valueOf(inLocation.getCountryId()));
                safeLocation.setCountryName(inLocation.getCountryName() == null
                        ? null
                        : new String(inLocation.getCountryName().trim()));
                safeLocation.setAlertMessage(oldAlertMessage);
                oldAlertMessage.getAlertMessageLocations().add(safeLocation);
            });
        }

        AlertMessage savedAlertMessage = this.alertMessageRepository.save(oldAlertMessage);

        return savedAlertMessage;
    }


    /**
     * Deletes a alertMessage by its ID.
     *
     * @param id The ID of the alertMessage to be deleted.
     */
    public void deleteRole(Long id) {
        this.alertMessageRepository.deleteById(id);
    }

    public List<AlertMessageDTO> getListOfAlertNotification() {
        List<AlertMessage> alertMessages = new ArrayList<>();
        alertMessages = this.alertMessageRepository.getListOfAlertNotification();
        List<AlertMessageDTO> alertMessageDTOs = alertMessages
                .stream()
                .map(alertMessage -> AlertMessageMapper.INSTANCE.alertMessageToAlertMessageDTO(alertMessage))
                .collect(Collectors.toList());
        return alertMessageDTOs;
    }

    /**
     * Retrieves a facilityManager by its uuid.
     *
     * @param uuid The facilityManager of the facilityManager.
     * @return The list of uuid facilityManager response.
     */
    @Transactional
    public List<FacilityManager> getFacilityManagers(String uuid) {
        List<FacilityManager> facilityManager = this.facilityManagerRepository.getFacilityManagers(uuid);
        return facilityManager;
    }

    /**
     * Update an existing alertMessage with alert sent at.
     * 
     * @param id The existing alertMessage to be updated.
     * @return The updated alertMessage.
     */
    @Transactional
    public void updateAlertStatus(Long id) {
        Long sentAlertAtTime = System.currentTimeMillis() / 1000;
        try {
            alertMessageRepository.updateAlertStatus(id, sentAlertAtTime);
        } catch (DataAccessException ex) {
            String safeIdForLog = sanitizeForLog(id == null ? null : String.valueOf(id));
            log.error("Failed to update alert status for id {}", safeIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update alert status.");
        }
    }


    /**
     * Fetches alert messages for a specific space type and alert configuration
     * where the location level is GLOBAL (i.e., not country-specific).
     *
     * @param spaceTypeId   the ID of the space type
     * @param spaceTypeName the name of the space type
     * @param thresholdType the type of threshold (e.g., TEMPERATURE, HUMIDITY)
     * @param alertType     the type of alert (e.g., ORANGE, RED)
     * @return a list of Object arrays containing alert message data and associated
     *         country info
    */
    public List<Object[]> getAlertMessagesWithCountry(Long spaceTypeId, String speaceTypeName, String thresholdType,
            String alertType) {
        try {
            return alertMessageRepository.findAlertMessagesWithCountry(spaceTypeId, speaceTypeName, thresholdType,
                    alertType);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve alert messages with country.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve alert messages.");
        }
    }


    /**
     * Fetches alert messages for a specific space type and alert configuration
     * that are targeted to specific countries.
     *
     * @param spaceTypeId   the ID of the space type
     * @param spaceTypeName the name of the space type
     * @param thresholdType the type of threshold (e.g., TEMPERATURE, HUMIDITY)
     * @param alertType     the type of alert (e.g., ORANGE, RED)
     * @param countries     a list of country names to filter alert messages by
     * @return a list of Object arrays containing alert message data and associated
     *         country info
    */
    public List<Object[]> getAlertMessagesWithCountries(Long spaceTypeId, String speaceTypeName, String thresholdType,
            String alertType, List<String> countries) {
        try {
            return alertMessageRepository.findAlertMessagesWithCountries(spaceTypeId, speaceTypeName, thresholdType,
                    alertType, countries);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve alert messages with countries.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve alert messages.");
        }
    }


    /**
     * Checks whether an AlertMessage already exists based on its location level and
     * associated countries.
     *
     * @param alertMessage the AlertMessage object to check
     * @return true if a matching AlertMessage exists, false otherwise
    */
    public boolean isAlertMessageExist(AlertMessage alertMessage) {

        boolean isDataExist = false;
        if (Objects.nonNull(alertMessage.getAlertMessageLocations()) &&
                alertMessage.getAlertMessageLocations().size() == 1
                && alertMessage.getAlertMessageLocations().get(0).getLevel().equals(LevelEnum.GLOBAL)) {
            List<Object[]> messageLocationCountryList = getAlertMessagesWithCountry(alertMessage.getSpaceTypeId(),
                    alertMessage.getSpaceTypeName(),
                    alertMessage.getThresholdType().toString(), alertMessage.getAlertCategory().toString());

            String safeGlobalSpaceTypeName = sanitizeForLog(alertMessage.getSpaceTypeName());
            String safeGlobalThresholdType = sanitizeForLog(
                    alertMessage.getThresholdType() == null ? null : alertMessage.getThresholdType().toString());
            String safeGlobalAlertCategory = sanitizeForLog(
                    alertMessage.getAlertCategory() == null ? null : alertMessage.getAlertCategory().toString());
            String safeGlobalSpaceTypeId = sanitizeForLog(
                    alertMessage.getSpaceTypeId() == null ? null : String.valueOf(alertMessage.getSpaceTypeId()));
            log.info(
                    "AlertMessage details Global: spaceTypeId: {}, spaceTypeName: {}, thresholdType: {}, alertCategory: {}",
                    safeGlobalSpaceTypeId,
                    safeGlobalSpaceTypeName,
                    safeGlobalThresholdType,
                    safeGlobalAlertCategory);

            log.info("AlertMessage details Global: messageLocationCountryList size: {}", safeGlobalSpaceTypeId);

            if (Objects.nonNull(messageLocationCountryList) && !messageLocationCountryList.isEmpty()) {
                isDataExist = true;
            }
        } else {

            List<String> countryNamesList = alertMessage.getAlertMessageLocations().stream()
                    .map(AlertMessageLocation::getCountryName)
                    .filter(Objects::nonNull)
                    .distinct() // removes duplicates
                    .collect(Collectors.toList());
            String safeCountrySpaceTypeName = sanitizeForLog(alertMessage.getSpaceTypeName());
            String safeCountryThresholdType = sanitizeForLog(
                    alertMessage.getThresholdType() == null ? null : alertMessage.getThresholdType().toString());
            String safeCountryAlertCategory = sanitizeForLog(
                    alertMessage.getAlertCategory() == null ? null : alertMessage.getAlertCategory().toString());
            String safeCountrySpaceTypeId = sanitizeForLog(
                    alertMessage.getSpaceTypeId() == null ? null : String.valueOf(alertMessage.getSpaceTypeId()));
            log.info(
                    "AlertMessage details for countries: spaceTypeId: {}, spaceTypeName: {}, thresholdType: {}, alertCategory: {}",
                    safeCountrySpaceTypeId,
                    safeCountrySpaceTypeName,
                    safeCountryThresholdType,
                    safeCountryAlertCategory);


            List<Object[]> messageLocationContriesList = getAlertMessagesWithCountries(alertMessage.getSpaceTypeId(),
                    alertMessage.getSpaceTypeName(),
                    alertMessage.getThresholdType().toString(), alertMessage.getAlertCategory().toString(),
                    countryNamesList);
            String safeContriesSize = sanitizeForLog(String.valueOf(messageLocationContriesList.size()));
            log.info("AlertMessage details for countries: messageLocationContriesList size: {}",
                    safeContriesSize);


            if (Objects.nonNull(messageLocationContriesList) && !messageLocationContriesList.isEmpty()) {
                isDataExist = true;
            }
        }
        return isDataExist;
    }

    private AlertMessage sanitizeForPersistence(AlertMessageUpsertInput alertMessageInput) {
        if (alertMessageInput == null) {
            throw new IllegalArgumentException("AlertMessage payload is required");
        }
        if (alertMessageInput.getSpaceTypeId() == null
                || alertMessageInput.getSpaceTypeName() == null
                || alertMessageInput.getThresholdType() == null
                || alertMessageInput.getAlertCategory() == null
                || alertMessageInput.getTitle() == null
                || alertMessageInput.getMessage() == null) {
            throw new IllegalArgumentException("AlertMessage payload contains null required fields");
        }

        AlertMessage sanitized = new AlertMessage();
        sanitized.setId(null);
        sanitized.setModifiedAt(System.currentTimeMillis() / 1000);
        sanitized.setAlertSentAt(null);
        sanitized.setSpaceTypeId(Long.valueOf(alertMessageInput.getSpaceTypeId()));
        sanitized.setSpaceTypeName(new String(alertMessageInput.getSpaceTypeName().trim()));
        sanitized.setThresholdType(alertMessageInput.getThresholdType() == null
                ? null
                : ThresholdType.valueOf(String.valueOf(alertMessageInput.getThresholdType().name())));
        sanitized.setAlertCategory(alertMessageInput.getAlertCategory() == null
                ? null
                : AlertType.valueOf(String.valueOf(alertMessageInput.getAlertCategory().name())));

        sanitized.setTitle(new String(alertMessageInput.getTitle().trim()));
        sanitized.setMessage(new String(alertMessageInput.getMessage().trim()));

        List<AlertMessageLocation> safeLocations = new ArrayList<>();
        if (alertMessageInput.getAlertMessageLocations() != null) {
            for (AlertMessageLocationUpsertInput inLocation : alertMessageInput.getAlertMessageLocations()) {
                if (inLocation == null) {
                    continue;
                }
                if (inLocation.getLevel() == null) {
                    throw new IllegalArgumentException("AlertMessage location level is required");
                }
                AlertMessageLocation safeLocation = new AlertMessageLocation();
                safeLocation.setId(null);
                safeLocation.setAlertMessageId(null);
                safeLocation.setLevel(inLocation.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(inLocation.getLevel().name())));

                safeLocation.setCdmKeyId(inLocation.getCdmKeyId() == null ? null : Long.valueOf(inLocation.getCdmKeyId()));
                safeLocation.setStatus(inLocation.getStatus() == null ? null : new String(inLocation.getStatus().trim()));
                safeLocation.setCountryId(inLocation.getCountryId() == null ? null : Long.valueOf(inLocation.getCountryId()));
                safeLocation.setCountryName(inLocation.getCountryName() == null
                        ? null
                        : new String(inLocation.getCountryName().trim()));
                safeLocation.setAlertMessage(sanitized);
                safeLocations.add(safeLocation);
            }
        }
        sanitized.setAlertMessageLocations(safeLocations);
        return sanitized;
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
