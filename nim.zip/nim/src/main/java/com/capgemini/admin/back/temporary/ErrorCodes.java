package com.capgemini.admin.back.temporary;

public final class ErrorCodes {
	// clean and remove useless for ADMIN portal
	public static final Integer WRONG_BOOKING_SLOT_STATUS = 1;

	public static final Integer USER_NOT_FOUND = 2;

	public static final Integer PENALTY_NOT_FOUND = 3;

	public static final Integer CAR_NOT_FOUND = 4;

	public static final Integer FORBIDDEN_BOOKING_SLOT_ACTION = 5;

	public static final Integer BOOKING_SLOT_CONFLICT = 6;

	public static final Integer NOTIFICATION_NOT_FOUND = 7;

	public static final Integer CANNOT_CANCEL_RELEASE_LATE = 8;

	public static final Integer BOOKING_SLOT_NOT_FOUND = 9;

	public static final Integer BOOKING_SLOT_INVALID = 10;

	public static final Integer POI_NOT_FOUND = 11;

	public static final Integer POI_CONFLICT = 12;

	public static final Integer NO_PARKING_SPOT_AVAILABLE = 13;

	public static final Integer BOOKING_SAME_DAY_FORBIDDEN = 14;

	public static final Integer USER_BOOKING_SLOT_CONFLICT = 15;

	public static final Integer JC_CONNECTOR_UNEXPECTED_ERROR = 500;

	public static final Integer AUTHENTICATION_FAILED = 1000;

	// Prevent instantiation
	private ErrorCodes() {
		throw new IllegalAccessError();
	}
}
