package com.capgemini.admin.back.security.jwt;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URI;

import java.security.PublicKey;

import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;


import javax.servlet.http.HttpServletRequest;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;


import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;

import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.RSAKeyProvider;
import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.security.jwt.model.AuthFailureException;
import com.capgemini.admin.back.security.jwt.model.Base64;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JWTSignatureValidation {

    @Autowired
    private ApplicationProperties applicationProperties;

    private static final String TOKEN = "token";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";
    private static final String JWKS_CERTIFICATES_CONTENT_FIELD = "x5c";
    private static final String JWKS_CERTIFICATES_KEYS_FIELD = "keys";
    private static final String JWKS_CERTIFICATE_KEY_ID_FIELD = "kid";
    private static final String AUTH_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final Pattern SAFE_REMOTE_TOKEN_PATTERN = Pattern.compile("^[A-Za-z0-9._~+/=\\-]+$");



    public DecodedJWT verifyJWT(String token, String discoveryKeysURL) {
        DecodedJWT decodedToken;
        try {
            decodedToken = JWT.decode(token);
        } catch (JWTDecodeException e) {
            throw new AuthFailureException(e.getMessage());
        }
        discoveryKeysURL = this.applicationProperties.getJwks().getUrl();

        Map<String, String> certifs = getJWKSCertificate(discoveryKeysURL);
        Claim kidClaim = decodedToken.getHeaderClaim(JWKS_CERTIFICATE_KEY_ID_FIELD);
        if (kidClaim.isNull()) {
            log.error("Provided token do not have expected claim " + JWKS_CERTIFICATE_KEY_ID_FIELD);
            throw new AuthFailureException(
                    "Provided token do not have expected claim " + JWKS_CERTIFICATE_KEY_ID_FIELD);
        }
        String tokenKeyId = kidClaim.asString();
        try {
            DecodedJWT decodedJWT = decodeJWT(token, certifs.get(tokenKeyId));
            if (Objects.nonNull(decodedJWT)) {
                return decodedJWT;
            }
        } catch (AuthFailureException e) {
            throw e;
        }
        return null;
    }

    public JSONObject validateWithPingId(String token) {
    token = new String(validateTokenForRemoteValidation(token));

    try (CloseableHttpClient client = buildTlsHttpClient()) {
        HttpContext context = new BasicHttpContext();


        URI validateUri = URI.create(
                requireHttpsUrl(this.applicationProperties.getPing().getValidateUrl(),
                        "ping.validateUrl"));

        HttpPost requestPost = new HttpPost(buildRelativeRequestUri(validateUri));

        // Keep only token in request body
        List<NameValuePair> urlEncodedParams = new ArrayList<>();
        urlEncodedParams.add(new BasicNameValuePair(TOKEN, token));

        UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
        requestPost.setEntity(urlEncoded);
        requestPost.addHeader("Content-Type", "application/x-www-form-urlencoded");

        // Send credentials in Authorization header
        String clientId = this.applicationProperties.getPing().getClientId();
        String clientSecret = this.applicationProperties.getPing().getClientSecret();

        String credentials = clientId + ":" + clientSecret;

        String encoded = java.util.Base64.getEncoder()
                .encodeToString(credentials.getBytes());

        requestPost.setHeader("Authorization", "Basic " + encoded);

        CloseableHttpResponse response =
                executeSecurePost(client, validateUri, requestPost, context);

        HttpEntity entity = response.getEntity();

        if (response.getStatusLine().getStatusCode() == 200) {
            String json = EntityUtils.toString(entity);
            JSONObject result = new JSONObject(json);

            Boolean activeValue = (Boolean) result.get("active");

            if (Boolean.FALSE.equals(activeValue)) {
                throw new AuthFailureException("Token invalid");
            }

            return result;
        }

    } catch (Exception e) {
        throw new AuthFailureException(e.getMessage());
    }

    return null;
}

    private Map<String, String> getJWKSCertificate(String discoveryKeysURL) {
        Map<String, String> certifByKey = new HashMap<String, String>();

        try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
            HttpContext context = new BasicHttpContext();
            HttpGet request = new HttpGet(discoveryKeysURL);
            try (CloseableHttpResponse response = client.execute(request, context)) {
                HttpEntity entity = response.getEntity();
                if (Integer.valueOf(200).equals(Integer.valueOf(response.getStatusLine().getStatusCode()))) {
                    String json = EntityUtils.toString(entity);
                    JSONObject result = new JSONObject(json);
                    JSONArray keys = result.getJSONArray(JWKS_CERTIFICATES_KEYS_FIELD);
                    for (int i = 0; i < keys.length(); i++) {
                        JSONObject o = keys.getJSONObject(i);
                        if (o.isNull(JWKS_CERTIFICATES_CONTENT_FIELD)) {
                            continue;
                        }
                        certifByKey.put(
                                o.getString(JWKS_CERTIFICATE_KEY_ID_FIELD),
                                o.getJSONArray(JWKS_CERTIFICATES_CONTENT_FIELD).getString(0));
                    }
                }
            }
        } catch (Exception e) {
            throw new AuthFailureException(e.getMessage());
        }
        return certifByKey;
    }

    public String getAuthHeader(HttpServletRequest request) {
        String authHeader = request.getHeader(AUTH_HEADER);
        if (Objects.isNull(authHeader)) {
            return null;
        }
        String token = authHeader.startsWith(BEARER_PREFIX)
                ? authHeader.substring(BEARER_PREFIX.length()).trim()
                : authHeader.trim();
        return new String(validateTokenForRemoteValidation(token));

    }


    private String validateTokenForRemoteValidation(String token) {
        if (Objects.isNull(token)) {
            throw new AuthFailureException("Invalid token format");
        }
        String normalizedToken = token.trim();
        String lowerCaseToken = normalizedToken.toLowerCase(Locale.ROOT);
        boolean hasInvalidLength = normalizedToken.isEmpty() || normalizedToken.length() > 4096;
        boolean hasInvalidControlChars = !hasInvalidLength
                && (normalizedToken.contains("\r") || normalizedToken.contains("\n"));
        boolean isUrlValue = !hasInvalidLength
                && (lowerCaseToken.startsWith("http://") || lowerCaseToken.startsWith("https://"));
        boolean hasUnsafeCharacters = !hasInvalidLength
                && !SAFE_REMOTE_TOKEN_PATTERN.matcher(normalizedToken).matches();
        if (hasInvalidLength || hasInvalidControlChars || isUrlValue || hasUnsafeCharacters) {
            throw new AuthFailureException("Invalid token format");
        }
        return normalizedToken;
    }



    private String requireHttpsUrl(String url, String propertyName) {
        if (Objects.isNull(url) || url.trim().isEmpty()) {
            throw new AuthFailureException("Missing configuration for " + propertyName);
        }
        URI uri;
        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException e) {
            throw new AuthFailureException("Invalid URL configuration for " + propertyName);
        }
        if (!"https".equalsIgnoreCase(uri.getScheme()) || Objects.isNull(uri.getHost())) {
            throw new AuthFailureException("Only HTTPS URL is allowed for " + propertyName);
        }
        return uri.toString();
    }

    private CloseableHttpResponse executeSecurePost(CloseableHttpClient client, URI endpointUri, HttpPost requestPost, HttpContext context)
            throws Exception {
        if (Objects.isNull(endpointUri)) {
            throw new AuthFailureException("Only HTTPS remote validation endpoint is allowed");
        }

        String requestUriString = endpointUri.toString();
        String requestScheme = endpointUri.getScheme();
        if (Objects.isNull(requestScheme)
                || !"https".equalsIgnoreCase(requestScheme)
                || !requestUriString.toLowerCase(Locale.ROOT).startsWith("https://")) {
            throw new AuthFailureException("Only HTTPS remote validation endpoint is allowed");
        }

        URI secureRequestUri = URI.create(requireHttpsUrl(requestUriString, "remote validation endpoint"));
        String requestHost = secureRequestUri.getHost();
        if (isBlockedRemoteHost(requestHost)) {
            throw new AuthFailureException("Remote validation endpoint host is not allowed");
        }

        Set<String> allowedHosts = getAllowedHttpsHosts();
        if (Objects.isNull(requestHost) || !allowedHosts.contains(requestHost.toLowerCase(Locale.ROOT))) {
            throw new AuthFailureException("Remote validation endpoint host is not allowed");
        }

        URI configuredValidateUri = toHttpsUriOrNull(this.applicationProperties.getPing().getValidateUrl());
        URI configuredValidateOfficePassUri = toHttpsUriOrNull(this.applicationProperties.getPing().getValidateUrlOfficePass());


        boolean matchesConfiguredEndpoint = isSameHttpsEndpoint(secureRequestUri, configuredValidateUri)
                || isSameHttpsEndpoint(secureRequestUri, configuredValidateOfficePassUri);
        if (!matchesConfiguredEndpoint) {
            throw new AuthFailureException("Remote validation endpoint host is not allowed");
        }

        if (!secureRequestUri.toString().toLowerCase(Locale.ROOT).startsWith("https://")) {
            throw new AuthFailureException("Only HTTPS remote validation endpoint is allowed");
        }

        int requestPort = secureRequestUri.getPort() == -1 ? 443 : secureRequestUri.getPort();
        HttpHost secureTarget = new HttpHost(requestHost, requestPort, "https");
        requestPost.setURI(buildRelativeRequestUri(secureRequestUri));
        return client.execute(secureTarget, requestPost, context);

    }

    private CloseableHttpClient buildTlsHttpClient() {
        try {
            SSLConnectionSocketFactory tlsSocketFactory = new SSLConnectionSocketFactory(
                    SSLContexts.createSystemDefault(),
                    SSLConnectionSocketFactory.getDefaultHostnameVerifier());
            return HttpClientBuilder.create().setSSLSocketFactory(tlsSocketFactory).build();
        } catch (Exception e) {
            throw new AuthFailureException("Failed to initialize TLS HTTP client");
        }
    }


    private URI buildRelativeRequestUri(URI secureRequestUri) {
        String path = secureRequestUri.getRawPath();
        if (Objects.isNull(path) || path.isEmpty()) {
            path = "/";
        }
        String query = secureRequestUri.getRawQuery();
        if (Objects.nonNull(query) && !query.isEmpty()) {
            return URI.create(path + "?" + query);
        }
        return URI.create(path);
    }

    private boolean isSameHttpsEndpoint(URI requestUri, URI allowedUri) {

        if (Objects.isNull(requestUri) || Objects.isNull(allowedUri)) {
            return false;
        }
        if (!"https".equalsIgnoreCase(requestUri.getScheme()) || !"https".equalsIgnoreCase(allowedUri.getScheme())) {
            return false;
        }
        String requestHost = requestUri.getHost();
        String allowedHost = allowedUri.getHost();
        if (Objects.isNull(requestHost) || Objects.isNull(allowedHost)) {
            return false;
        }
        int requestPort = requestUri.getPort() == -1 ? 443 : requestUri.getPort();
        int allowedPort = allowedUri.getPort() == -1 ? 443 : allowedUri.getPort();
        String requestPath = Objects.isNull(requestUri.getPath()) ? "" : requestUri.getPath();
        String allowedPath = Objects.isNull(allowedUri.getPath()) ? "" : allowedUri.getPath();
        return requestHost.equalsIgnoreCase(allowedHost)
                && requestPort == allowedPort
                && requestPath.equals(allowedPath);
    }

    private Set<String> getAllowedHttpsHosts() {
        Set<String> allowedHosts = new HashSet<>();
        URI configuredValidateUri = toHttpsUriOrNull(this.applicationProperties.getPing().getValidateUrl());
        URI configuredValidateOfficePassUri = toHttpsUriOrNull(this.applicationProperties.getPing().getValidateUrlOfficePass());
        if (Objects.nonNull(configuredValidateUri) && Objects.nonNull(configuredValidateUri.getHost())) {
            allowedHosts.add(configuredValidateUri.getHost().toLowerCase(Locale.ROOT));
        }
        if (Objects.nonNull(configuredValidateOfficePassUri) && Objects.nonNull(configuredValidateOfficePassUri.getHost())) {
            allowedHosts.add(configuredValidateOfficePassUri.getHost().toLowerCase(Locale.ROOT));
        }
        return allowedHosts;
    }

    private URI toHttpsUriOrNull(String url) {

        if (Objects.isNull(url) || url.trim().isEmpty()) {
            return null;
        }
        try {
            URI uri = URI.create(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || Objects.isNull(uri.getHost())) {
                return null;
            }
            return uri;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private boolean isBlockedRemoteHost(String host) {

        if (Objects.isNull(host) || host.trim().isEmpty()) {
            return true;
        }
        if ("localhost".equalsIgnoreCase(host)
                || "metadata.google.internal".equalsIgnoreCase(host)) {
            return true;
        }
        try {
            InetAddress inetAddress = InetAddress.getByName(host);
            if (inetAddress.isAnyLocalAddress()
                    || inetAddress.isLoopbackAddress()
                    || inetAddress.isLinkLocalAddress()
                    || inetAddress.isSiteLocalAddress()
                    || inetAddress.isMulticastAddress()) {
                return true;
            }
            String hostAddress = inetAddress.getHostAddress();
            return "169.254.169.254".equals(hostAddress)
                    || "169.254.170.2".equals(hostAddress)
                    || "100.100.100.200".equals(hostAddress);
        } catch (Exception e) {
            return true;
        }
    }



    public DecodedJWT decodeJWT(String token, String key) {

        if (Objects.isNull(key)) {
            throw new AuthFailureException("The token signature isn't matching");
        }
        final RSAPrivateKey privateKey = null;
        final String privateKeyId = null;
        final PublicKey publicKey = getKey(key);
        final RSAPublicKey rsaPublicKey = (RSAPublicKey) publicKey;
        RSAKeyProvider keyProvider = new RSAKeyProvider() {
            @Override
            public RSAPublicKey getPublicKeyById(String kid) {
                return rsaPublicKey;
            }

            @Override
            public RSAPrivateKey getPrivateKey() {
                return privateKey;
            }

            @Override
            public String getPrivateKeyId() {
                return privateKeyId;
            }
        };
        Algorithm algorithm = Algorithm.RSA256(keyProvider);
        try {
            JWTVerifier verifier = JWT.require(algorithm).build();
            return verifier.verify(token);
        } catch (JWTVerificationException e) {
            log.info("JWTVerificationException" + e.getMessage());
            throw new AuthFailureException(e.getMessage());
        }
    }

    /**
     *
     * @param key
     *            Extract public Key from x509 certificate
     * @return
     */
    public static PublicKey getKey(String key) {
        try {
            byte[] decodedPK = Base64.decode(key);
            InputStream in = new ByteArrayInputStream(decodedPK);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) certFactory.generateCertificate(in);
            PublicKey pk = cert.getPublicKey();
            return pk;
        } catch (Exception e) {
            log.error("Failed to extract public key from X.509 certificate");
        }
        return null;
    }

    // For external applications like : OP
public void validateWithPingIdForExternalApp(String token) {
    token = new String(validateTokenForRemoteValidation(token));

    try (CloseableHttpClient client = buildTlsHttpClient()) {
        HttpContext context = new BasicHttpContext();

        URI validateUrlOfficePass = URI.create(
                requireHttpsUrl(
                        applicationProperties.getPing().getValidateUrlOfficePass(),
                        "ping.validateUrlOfficePass"));

        HttpPost requestPost = new HttpPost(buildRelativeRequestUri(validateUrlOfficePass));

        // Keep only token in request body
        List<NameValuePair> urlEncodedParams = new ArrayList<>();
        urlEncodedParams.add(new BasicNameValuePair(TOKEN, token));

        UrlEncodedFormEntity urlEncoded =
                new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");

        requestPost.setEntity(urlEncoded);
        requestPost.addHeader("Content-Type", "application/x-www-form-urlencoded");

        // Send client credentials via Authorization header
        String clientId =
                applicationProperties.getPing().getClientIdForOfficePass();
        String clientSecret =
                applicationProperties.getPing().getClientSecretForOfficePass();

        String credentials = clientId + ":" + clientSecret;

        String encoded = java.util.Base64.getEncoder()
                .encodeToString(credentials.getBytes());

        requestPost.setHeader("Authorization", "Basic " + encoded);

        CloseableHttpResponse response =
                executeSecurePost(client, validateUrlOfficePass, requestPost, context);

        HttpEntity entity = response.getEntity();

        if (response.getStatusLine().getStatusCode() == 200) {

            String json = EntityUtils.toString(entity);
            JSONObject result = new JSONObject(json);

            Boolean activeValue = (Boolean) result.get("active");
            String responseClientId = (String) result.get(CLIENT_ID);

            log.info("clientId {}", responseClientId);

            boolean isInactive = Boolean.FALSE.equals(activeValue);

            boolean isClientIdMismatch =
                    !Objects.equals(
                            responseClientId,
                            applicationProperties.getPing().getClientIdForOfficePass());

            if (isInactive || isClientIdMismatch) {
                throw new AuthFailureException("Token invalid");
            }

        } else {
            throw new AuthFailureException("Token invalid");
        }

    } catch (Exception e) {
        throw new AuthFailureException(e.getMessage());
    }
}

}
