package com.capgemini.admin.back.model;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Entity
@Data
@Table(name = "users")
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "password")
    private String password;

    @Column(unique = true, name = "email")
    private String email;

    @Column(name = "user_type")
    private Integer userType;

    @Column(name = "enabled")
    private boolean enabled;

    @Column(name = "subscribe_alert")
    private Boolean subscribeAlert;

    @Column(name = "token_expired")
    private boolean tokenExpired;

    @Column(name = "deleted")
    private boolean deleted;
    
    @Column(name = "user_country")
    private String country;
    
    @OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
    @JoinColumn(name = "preference_id", referencedColumnName = "id")
    private Preference preference;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "users_secured_building", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "building_id", referencedColumnName = "id"), uniqueConstraints = @UniqueConstraint(columnNames = {
            "user_id", "building_id" }) // Add uniqueness constraint
    )
    private Collection<Building> userSecuredBuildings;
}
