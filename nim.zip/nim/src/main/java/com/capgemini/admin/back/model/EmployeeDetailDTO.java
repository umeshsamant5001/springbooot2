package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class EmployeeDetailDTO {
    private String firstName;
    private String emailID;
    private String fullName;
    private String lastName;
    private String ntLoginID;
    private String country;
}