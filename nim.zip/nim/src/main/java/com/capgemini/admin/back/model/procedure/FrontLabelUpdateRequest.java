package com.capgemini.admin.back.model.procedure;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = false)
public class FrontLabelUpdateRequest {
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String keyId;

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String fieldKey;

    @NotNull
    @Size(min = 1, max = 4000)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String languageText;

    @NotNull
    @Size(min = 2, max = 16)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String languageCode;
}
