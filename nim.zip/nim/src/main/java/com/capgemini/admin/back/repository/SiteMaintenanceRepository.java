package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.admin.back.model.SiteMaintenance;
import com.capgemini.admin.back.model.Platform;

@Repository
public interface SiteMaintenanceRepository extends JpaRepository<SiteMaintenance, Long> {

    @Modifying
    @Transactional
    @Query("UPDATE SiteMaintenance sm SET sm.isActive = false WHERE sm.platform = :platform AND sm.isActive = true")
    void deactivateActiveByPlatform(@Param("platform") Platform platform);

    @Modifying
    @Query("UPDATE SiteMaintenance sm SET sm.isActive = false WHERE sm.platform = :platform AND sm.id <> :id")
    void deactivateOtherRecords(@Param("platform") Platform platform, @Param("id") Long id);

}
