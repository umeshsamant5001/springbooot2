package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class PoiAttributeKeysDTO {
    private Long id;
    private String poiAttributeKey;
}
