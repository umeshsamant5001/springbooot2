package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.ThresholdConfiguration;

@Repository
public interface ThresholdConfigurationRepository extends JpaRepository<ThresholdConfiguration, Long> {

    public List<ThresholdConfiguration> getThresholdConfigurationByCountryId(Long countryId);

    Optional<ThresholdConfiguration> findByIdAndCountryIdIn(Long id, List<Long> countryIds);

    @Query(value = "SELECT tc from ThresholdConfiguration tc")
    public List<ThresholdConfiguration> getAllThresholdConfiguration();

    @Query(value = "SELECT DISTINCT tc.* FROM threshold_configuration tc " +
            "JOIN alert a ON tc.id = a.threshold_configuration_id " +
            "WHERE a.enabled = 1", nativeQuery = true)
    List<ThresholdConfiguration> findAllWithEnabledAlerts();
}
