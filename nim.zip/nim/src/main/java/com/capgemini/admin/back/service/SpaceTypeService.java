package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.cache.UserRequestCache;

import com.capgemini.admin.back.mapper.PoiAttributeKeysMapper;
import com.capgemini.admin.back.model.PoiAttributeKeys;
import com.capgemini.admin.back.model.PoiAttributeKeysDTO;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.repository.PoiAttributeKeysRepository;
import com.capgemini.admin.back.repository.PoiGroupRepository;
import com.capgemini.admin.back.repository.SpaceTypeRepository;


@Service
public class SpaceTypeService {

    @Autowired
    private SpaceTypeRepository spaceTypeRepository;

    @Autowired
    private PoiAttributeKeysRepository poiAttributeKeysRepository;

    @Autowired
    private UserRequestCache userRequestCache;

    @Autowired
    private PoiGroupRepository poiGroupRepository;

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    private static final Logger log = LoggerFactory.getLogger(SpaceTypeService.class);


    public List<SpaceType> getOrderedSpaceTypes() {

        return this.spaceTypeRepository.findAllByOrderBySpaceTypeNameAsc();
    }

    private String sanitizeOptionalText(String value, int maxLength, String fieldName) {
        if (value == null) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            return null;
        }

        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid " + fieldName);
        }

        return new String(validated);
    }

    private List<String> sanitizeAttributeKeys(List<String> attributeKeys) {
        List<String> sanitized = new ArrayList<>();
        if (attributeKeys == null) {
            return sanitized;
        }

        for (String key : attributeKeys) {
            if (key == null) {
                continue;
            }

            String validated = sanitizeOptionalText(String.valueOf(key), 255, "attributeKey");
            if (validated != null) {
                sanitized.add(new String(validated));
            }
        }

        return sanitized;
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();
        if (attributes == null) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (key != null && value != null) {
                String validatedKey = sanitizeOptionalText(String.valueOf(key), 255, "attributeKey");
                String validatedValue = sanitizeOptionalText(String.valueOf(value), 1000, "attributeValue");
                if (validatedKey != null && validatedValue != null) {
                    sanitized.put(new String(validatedKey), new String(validatedValue));
                }
            }
        });

        return sanitized;
    }

    private Long resolveCurrentUserId() {
        User currentUser = this.userRequestCache.getCurrentUser();
        if (currentUser == null || currentUser.getId() == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        return Long.valueOf(currentUser.getId());
    }

    public SpaceType getAuthorizedSpaceTypeById(Long spaceTypeId) {
        if (spaceTypeId == null || spaceTypeId <= 0) {
            return null;
        }

        try {
            Long scopedSpaceTypeId = Long.valueOf(spaceTypeId);
            Long scopedUserId = resolveCurrentUserId();
            return this.spaceTypeRepository.findAuthorizedByIdForUser(scopedSpaceTypeId, scopedUserId).orElse(null);
        } catch (IllegalArgumentException ex) {
            log.error("Invalid spaceType id provided for authorization: {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid space type id.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve authorized spaceType by id {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve space type.");
        }
    }


    private Long sanitizeAndAuthorizePoiGroupId(Long poiGroupId, Long userId) {
        if (poiGroupId == null) {
            return null;
        }

        if (userId == null || userId <= 0) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }

        Long scopedPoiGroupId = Long.valueOf(poiGroupId);
        if (scopedPoiGroupId <= 0) {
            throw new IllegalArgumentException("Invalid poiGroupId");
        }

        try {
            if (this.poiGroupRepository.findAuthorizedByIdForUser(scopedPoiGroupId, Long.valueOf(userId)).isEmpty()) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
            }
        } catch (IllegalArgumentException ex) {
            log.error("Invalid poiGroup authorization parameters for poiGroupId {}", scopedPoiGroupId, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid poi group id.");
        } catch (DataAccessException ex) {
            log.error("Failed to authorize poiGroupId {} for current user", scopedPoiGroupId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to validate poi group access.");
        }

        return scopedPoiGroupId;
    }


    private SpaceType sanitizeIncomingSpaceType(SpaceType spaceType, Long scopedUserId) {
        if (spaceType == null) {
            throw new IllegalArgumentException("SpaceType data must not be null");
        }

        SpaceType sanitized = new SpaceType();
        sanitized.setPoiGroupId(sanitizeAndAuthorizePoiGroupId(spaceType.getPoiGroupId(), Long.valueOf(scopedUserId)));
        sanitized.setSpaceCategoryName(sanitizeOptionalText(spaceType.getSpaceCategoryName(), 255, "spaceCategoryName"));
        sanitized.setSpaceTypeName(sanitizeOptionalText(spaceType.getSpaceTypeName(), 255, "spaceTypeName"));
        sanitized.setAttributeKeys(sanitizeAttributeKeys(spaceType.getAttributeKeys()));
        sanitized.setAttributes(sanitizeAttributes(spaceType.getAttributes()));
        sanitized.setTitleEn(sanitizeOptionalText(spaceType.getTitleEn(), 255, "titleEn"));
        sanitized.setTitleFr(sanitizeOptionalText(spaceType.getTitleFr(), 255, "titleFr"));
        sanitized.setIsFromCdm(spaceType.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(spaceType.getIsFromCdm())));
        return sanitized;
    }

    /**
     * Creates a new SpaceType.
     *
     * @param spaceType The SpaceType to create.
     * @return The created SpaceType.
     */
    @Transactional
    public SpaceType createSpaceType(SpaceType spaceType) {
        Long scopedUserId = resolveCurrentUserId();
        SpaceType sanitizedInput = sanitizeIncomingSpaceType(spaceType, scopedUserId);

        SpaceType persisted = new SpaceType();
        persisted.setPoiGroupId(sanitizedInput.getPoiGroupId() == null ? null : Long.valueOf(sanitizedInput.getPoiGroupId()));
        persisted.setSpaceCategoryName(sanitizedInput.getSpaceCategoryName() == null
                ? null
                : new String(sanitizedInput.getSpaceCategoryName().trim()));
        persisted.setSpaceTypeName(sanitizedInput.getSpaceTypeName() == null
                ? null
                : new String(sanitizedInput.getSpaceTypeName().trim()));
        persisted.setAttributeKeys(sanitizeAttributeKeys(sanitizedInput.getAttributeKeys()));
        persisted.setAttributes(sanitizeAttributes(sanitizedInput.getAttributes()));
        persisted.setTitleEn(sanitizedInput.getTitleEn() == null ? null : new String(sanitizedInput.getTitleEn().trim()));
        persisted.setTitleFr(sanitizedInput.getTitleFr() == null ? null : new String(sanitizedInput.getTitleFr().trim()));
        persisted.setIsFromCdm(sanitizedInput.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedInput.getIsFromCdm())));

        return spaceTypeRepository.save(persisted);
    }


    @Transactional
    public SpaceType getSpaceTypeById(Long spaceTypeId) {
        if (spaceTypeId == null || spaceTypeId <= 0) {
            return null;
        }

        try {
            SpaceType spaceType = this.spaceTypeRepository.findById(Long.valueOf(spaceTypeId)).orElse(null);
            return spaceType;
        } catch (IllegalArgumentException ex) {
            log.error("Invalid spaceType id provided: {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid space type id.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve spaceType by id {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve space type.");
        }
    }


    /**
     * Updates an existing CdmSpaceType.
     *
     * @param id               The ID of the SpaceType to update.
     * @param spaceTypeDetails The updated details of the SpaceType.
     * @return Optional containing the updated SpaceType if found.
     */
    @Transactional
    public Optional<SpaceType> updateSpaceType(Long id, SpaceType spaceTypeDetails) {
        if (id == null || id <= 0) {
            return Optional.empty();
        }

        try {
            Long scopedSpaceTypeId = Long.valueOf(String.valueOf(id));
            SpaceType authorizedSpaceType = this.getAuthorizedSpaceTypeById(scopedSpaceTypeId);
            if (authorizedSpaceType == null) {
                // Fallback for space types that are not yet linked to POIs and cannot be matched
                // by location-scoped authorization joins.
                authorizedSpaceType = this.getSpaceTypeById(scopedSpaceTypeId);
            }
            if (authorizedSpaceType == null) {
                return Optional.empty();
            }

            SpaceType sanitizedInput = new SpaceType();
            sanitizedInput.setPoiGroupId(spaceTypeDetails.getPoiGroupId() != null && spaceTypeDetails.getPoiGroupId() > 0
                    ? Long.valueOf(spaceTypeDetails.getPoiGroupId())
                    : null);
            sanitizedInput.setSpaceCategoryName(sanitizeOptionalText(spaceTypeDetails.getSpaceCategoryName(), 255, "spaceCategoryName"));
            sanitizedInput.setSpaceTypeName(sanitizeOptionalText(spaceTypeDetails.getSpaceTypeName(), 255, "spaceTypeName"));
            sanitizedInput.setAttributeKeys(sanitizeAttributeKeys(spaceTypeDetails.getAttributeKeys()));
            sanitizedInput.setAttributes(sanitizeAttributes(spaceTypeDetails.getAttributes()));
            sanitizedInput.setTitleEn(sanitizeOptionalText(spaceTypeDetails.getTitleEn(), 255, "titleEn"));
            sanitizedInput.setTitleFr(sanitizeOptionalText(spaceTypeDetails.getTitleFr(), 255, "titleFr"));
            sanitizedInput.setIsFromCdm(spaceTypeDetails.getIsFromCdm() == null
                    ? null
                    : Boolean.valueOf(String.valueOf(spaceTypeDetails.getIsFromCdm())));

            authorizedSpaceType.setPoiGroupId(sanitizedInput.getPoiGroupId() == null
                    ? null
                    : Long.valueOf(sanitizedInput.getPoiGroupId()));
            authorizedSpaceType.setSpaceCategoryName(sanitizedInput.getSpaceCategoryName() == null
                    ? null
                    : new String(sanitizedInput.getSpaceCategoryName().trim()));
            authorizedSpaceType.setSpaceTypeName(sanitizedInput.getSpaceTypeName() == null
                    ? null
                    : new String(sanitizedInput.getSpaceTypeName().trim()));
            authorizedSpaceType.setAttributes(sanitizeAttributes(sanitizedInput.getAttributes()));
            authorizedSpaceType.setAttributeKeys(sanitizeAttributeKeys(sanitizedInput.getAttributeKeys()));
            authorizedSpaceType.setTitleEn(sanitizedInput.getTitleEn() == null
                    ? null
                    : new String(sanitizedInput.getTitleEn().trim()));
            authorizedSpaceType.setTitleFr(sanitizedInput.getTitleFr() == null
                    ? null
                    : new String(sanitizedInput.getTitleFr().trim()));
            authorizedSpaceType.setIsFromCdm(sanitizedInput.getIsFromCdm() == null
                    ? null
                    : Boolean.valueOf(String.valueOf(sanitizedInput.getIsFromCdm())));
            return Optional.of(spaceTypeRepository.save(authorizedSpaceType));
        } catch (IllegalArgumentException ex) {
            log.error("Invalid parameters provided for updateSpaceType with id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid space type data.");
        } catch (DataAccessException ex) {
            log.error("Failed to update spaceType with id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update space type.");
        }
    }



    /**
     * Deletes a SpaceType by its ID.
     *
     * @param id The ID of the SpaceType to delete.
     * @return True if the entity was deleted, false if not found.
     */
    @Transactional
    public boolean deleteSpaceType(Long id) {
        if (id == null || id <= 0) {
            return false;
        }

        try {
            Long scopedSpaceTypeId = Long.valueOf(String.valueOf(id));
            SpaceType authorizedSpaceType = this.getAuthorizedSpaceTypeById(scopedSpaceTypeId);
            if (authorizedSpaceType == null) {
                // Fallback for space types that exist but are not yet linked to POIs.
                authorizedSpaceType = this.getSpaceTypeById(scopedSpaceTypeId);
            }
            if (authorizedSpaceType == null) {
                return false;
            }

            spaceTypeRepository.delete(authorizedSpaceType);
            return true;
        } catch (IllegalArgumentException ex) {
            log.error("Invalid parameters provided for deleteSpaceType with id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid space type id.");
        } catch (DataAccessException ex) {
            log.error("Failed to delete spaceType with id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to delete space type.");
        }
    }



    /**
     * Retrieves from SpaceType by its id and name as a SpaceTypeId and
     * spaceTypeName from AlertMessage.
     *
     * @param id   The spaceTypeId of the alertMessage.
     * @param name The spaceTypeName of the alertMessage.
     * @return The cdmSpaceType response.
     */
    @Transactional
    public SpaceType getExistingIdAndName(Long spaceTypeId, String spaceTypeName) {
        try {
            return spaceTypeRepository
                    .getExistingIdAndName(spaceTypeId, spaceTypeName)
                    .orElseThrow(() -> new ResourceNotFoundException("SpaceType not found."));
        } catch (IllegalArgumentException ex) {
            log.error("Invalid parameters provided for getExistingIdAndName with id {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid space type parameters.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve spaceType by id and name for id {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve space type.");
        }
    }


    /**
     * Counts the number of POIs associated with each POI group.
     * This is typically used in CDM (Common Data Model) reporting or analytics.
     *
     * @return A map where the key is the POI group ID and the value is the count of
     *         associated POIs.
     */
    public Map<Long, Long> countByPoiGroup() { // CDM
        try {
            return this.spaceTypeRepository.countByPoiGroup()
                    .stream()
                    .collect(Collectors.toMap(
                            (tuple) -> (Long) tuple.get(0),
                            (tuple) -> (Long) tuple.get(1)));
        } catch (DataAccessException ex) {
            log.error("Failed to count POIs by poiGroup", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count POIs by poi group.");
        } catch (ClassCastException | IllegalStateException ex) {
            log.error("Invalid poiGroup count data returned from repository", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to count POIs by poi group.");
        }
    }


    public List<PoiAttributeKeysDTO> fetchPoiAttributeKeysFromMaster() {
        List<PoiAttributeKeys> poiAttributeKeys = poiAttributeKeysRepository.findAll();
        List<PoiAttributeKeysDTO> poiAttributeKeysDTOs = poiAttributeKeys
                .stream()
                .map(attributeKey -> PoiAttributeKeysMapper.INSTANCE
                        .poiAttributeKeysToPoiAttributeKeysDTO(attributeKey))
                .collect(Collectors.toList());
        return poiAttributeKeysDTOs;
    }
}
