package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.NotificationLocationMapper;
import com.capgemini.admin.back.mapper.NotificationMapper;
import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationDTO;
import com.capgemini.admin.back.model.NotificationLocation;
import com.capgemini.admin.back.model.NotificationLocationDTO;

import com.capgemini.admin.back.repository.NotificationRepository;

import com.capgemini.admin.back.repository.NotificationSentRepository;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.ApnsConfig;
import com.google.firebase.messaging.ApnsFcmOptions;
import com.google.firebase.messaging.Aps;
import com.google.firebase.messaging.ApsAlert;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class NotificationService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";
    private static final int MAX_NOTIFICATION_OS_TYPES = 10;


    @Data
    public static class NotificationSanitizedInput {
        private String title;
        private String message;
        private String messageType;
        private String image;
        private EnumPriorityType priorityType;
        private Long startDate;
        private Long endDate;
        private Map<String, String> attributes = new HashMap<>();
        private List<EnumOsType> osTypes = new ArrayList<>();
        private List<NotificationLocationSanitizedInput> notificationLocations = new ArrayList<>();

        @Data
        public static class NotificationLocationSanitizedInput {
            private Long cdmKeyId;
            private LevelEnum level;
            private Long countryId;
            private String countryName;
            private String status;
        }
    }


    @Autowired
    private NotificationRepository notificationRepository;


    @Autowired
    private DeviceTokenService deviceTokenService;

    @Autowired
    private PushNotificationService pushNotificationService;

    @Autowired
    private NotificationSentRepository notificationSentRepository;

    /**
     * Retrieves a notification from the repository based on the provided
     * notification ID.
     *
     * @param notificationId The unique identifier of the notification to be
     *                       retrieved.
     * @return The Notification object corresponding to the provided ID if found in
     *         the repository.
     *         Returns null if the notification with the specified ID is not found.
     */
    public Notification getNotification(long notificationId) {
        log.debug("Fetching notification by id={}", notificationId);
        Notification notification = this.notificationRepository.findById(notificationId).orElse(null);
        if (Objects.nonNull(notification)) {
            log.debug("Notification found for id={}", notificationId);
        } else {
            log.warn("Notification not found for id={}", notificationId);
        }
        return notification;
    }

    /**
     * Retrieves a list of notifications based on the specified filters.
     *
     * @param osTypes       The list of operating system types for filtering
     *                      notifications.
     * @param priorityTypes The list of priority types for filtering notifications.
     * @param status        The list of status types for filtering notifications.
     * @return List of notifications matching the specified filters.
     */
    public List<Notification> getNotifications(List<EnumOsType> osTypes, List<EnumPriorityType> priorityTypes,
            List<EnumStatusScheduled> status) {
        log.debug("Fetching notifications with filters osTypes={}, priorityTypes={}, status={}", osTypes,
            priorityTypes, status);
        List<Notification> notifications = this.notificationRepository
            .findDistinctByPriorityTypeInAndStatusInAndOsTypesIn(priorityTypes, status,
                osTypes);
        log.info("Fetched {} notifications for provided filters", notifications.size());
        return notifications;
    }

    public Function<List<Notification>, List<NotificationDTO>> listNotificationToNotificationDTOList() {
        return in -> in.stream().map(toNotificationDTO()).collect(Collectors.toList());
    }

    private Function<Notification, NotificationDTO> toNotificationDTO() {
        return NotificationMapper.INSTANCE::NotificationToNotificationDTO;
    }

    /**
     * Deletes a notification from the repository.
     *
     * @param notification The Notification object to be deleted from the
     *                     repository.
     */
    public void delete(Notification notification) {
        if (Objects.isNull(notification)) {
            log.warn("Delete skipped because notification is null");
            return;
        }
        log.info("Deleting notification id={}", notification.getId());
        this.notificationRepository.delete(notification);
        log.info("Deleted notification id={}", notification.getId());
    }

    /**
     * Saves a notification to the repository.
     *
     * @param notification The Notification object to be saved in the repository.
     * @return The saved Notification object.
     */
    public Notification save(Notification notification) {
        if (Objects.isNull(notification)) {
            log.warn("Save skipped because notification is null");
            return null;
        }

        int locationCount = notification.getNotificationLocations() != null
                ? notification.getNotificationLocations().size()
                : 0;
        log.info("Saving notification id={}, title={}, locationCount={}", notification.getId(), notification.getTitle(),
                locationCount);

        if (notification.getNotificationLocations() != null) {
            for (NotificationLocation loc : notification.getNotificationLocations()) {
                loc.setNotification(notification);
            }
        }
        Notification savedNotification = this.notificationRepository.save(notification);
        log.info("Notification saved successfully with id={}", savedNotification.getId());
        return savedNotification;
    }

    public Notification saveFromSanitizedInput(NotificationSanitizedInput notificationInput, EnumStatusScheduled defaultStatus) {

        if (notificationInput == null) {
            throw new IllegalArgumentException("Notification input is required");
        }

        Notification safeNotification = new Notification();

        String validatedTitle = validateAndCloneText(notificationInput.getTitle(), 255);
        String validatedMessage = validateAndCloneText(notificationInput.getMessage(), 5000);
        String validatedMessageType = validateAndCloneText(notificationInput.getMessageType(), 128);
        String validatedImage = validateAndCloneText(notificationInput.getImage(), 1000);

        safeNotification.setId(null);
        safeNotification.setTitle(validatedTitle == null ? null : new String(validatedTitle));
        safeNotification.setMessage(validatedMessage == null ? null : new String(validatedMessage));
        safeNotification.setMessageType(validatedMessageType == null ? null : new String(validatedMessageType));
        safeNotification.setImage(validatedImage == null ? null : new String(validatedImage));

        if (notificationInput.getPriorityType() != null) {
            EnumPriorityType validatedPriorityType = EnumPriorityType
                    .valueOf(String.valueOf(notificationInput.getPriorityType().name()));
            safeNotification.setPriorityType(EnumPriorityType.valueOf(String.valueOf(validatedPriorityType.name())));
        }
        if (notificationInput.getStartDate() != null) {
            Long validatedStartDate = Long.valueOf(notificationInput.getStartDate());
            safeNotification.setStartDate(Long.valueOf(validatedStartDate));
        }
        if (notificationInput.getEndDate() != null) {
            Long validatedEndDate = Long.valueOf(notificationInput.getEndDate());
            safeNotification.setEndDate(Long.valueOf(validatedEndDate));
        }

        safeNotification.setStatus(
                defaultStatus == null ? null : EnumStatusScheduled.valueOf(String.valueOf(defaultStatus.name())));


        safeNotification.setLastChange(Long.valueOf(System.currentTimeMillis() / 1000));

        List<EnumOsType> safeOsTypes = sanitizeAndBoundOsTypes(notificationInput.getOsTypes());
        safeNotification.setOsTypes(safeOsTypes);


        Map<String, String> safeAttributes = new HashMap<>();
        if (notificationInput.getAttributes() != null) {
            notificationInput.getAttributes().forEach((key, value) -> {
                String validatedKey = validateAndCloneText(key, 255);
                String validatedValue = validateAndCloneText(value, 1000);
                if (validatedKey != null) {
                    String safeKey = new String(validatedKey);
                    String safeValue = validatedValue == null ? null : new String(validatedValue);
                    safeAttributes.put(safeKey, safeValue);
                }
            });
        }
        safeNotification.setAttributes(new HashMap<>(safeAttributes));

        List<NotificationLocation> safeLocations = new ArrayList<>();
        if (notificationInput.getNotificationLocations() != null) {
            for (NotificationSanitizedInput.NotificationLocationSanitizedInput locationInput : notificationInput.getNotificationLocations()) {

                if (locationInput == null) {
                    continue;
                }
                NotificationLocation safeLocation = new NotificationLocation();
                safeLocation.setId(null);
                safeLocation.setNotificationId(null);
                if (locationInput.getCdmKeyId() != null) {
                    Long validatedCdmKeyId = Long.valueOf(locationInput.getCdmKeyId());
                    safeLocation.setCdmKeyId(Long.valueOf(validatedCdmKeyId));
                }
                if (locationInput.getCountryId() != null) {
                    Long validatedCountryId = Long.valueOf(locationInput.getCountryId());
                    safeLocation.setCountryId(Long.valueOf(validatedCountryId));
                }
                if (locationInput.getLevel() != null) {
                    LevelEnum validatedLevel = LevelEnum.valueOf(String.valueOf(locationInput.getLevel().name()));
                    safeLocation.setLevel(LevelEnum.valueOf(String.valueOf(validatedLevel.name())));
                }
                String validatedCountryName = validateAndCloneText(locationInput.getCountryName(), 255);
                String validatedStatus = validateAndCloneText(locationInput.getStatus(), 64);
                safeLocation.setCountryName(validatedCountryName == null ? null : new String(validatedCountryName));
                safeLocation.setStatus(validatedStatus == null ? null : new String(validatedStatus));
                safeLocation.setNotification(safeNotification);
                safeLocations.add(safeLocation);
            }
        }
        safeNotification.setNotificationLocations(new ArrayList<>(safeLocations));

        return this.notificationRepository.save(safeNotification);
    }




    /**
     * Updates an existing notification based on the provided NotificationDTO
     * object.
     *
     * @param oldNotification The existing Notification object to be updated.
     * @param notificationDTO The NotificationDTO object containing the updated
     *                        information.
     * @return The updated Notification object after the changes have been applied
     *         and saved in the repository.
     */
    @Transactional
    public Notification update(Notification oldNotification, NotificationDTO notificationDTO) {
        if (Objects.isNull(oldNotification) || Objects.isNull(notificationDTO)) {
            log.warn("Update skipped because oldNotification or notificationDTO is null");
            return oldNotification;
        }

        log.info("Updating notification id={} with new status={}", oldNotification.getId(), notificationDTO.getStatus());
        oldNotification.setTitle(notificationDTO.getTitle());
        oldNotification.setMessage(notificationDTO.getMessage());
        oldNotification.setMessageType(notificationDTO.getMessageType());
        oldNotification.setImage(notificationDTO.getImage());
        oldNotification.setOsTypes(notificationDTO.getOsTypes());
        oldNotification.setPriorityType(notificationDTO.getPriorityType());
        oldNotification.setStartDate(notificationDTO.getStartDate());
        oldNotification.setEndDate(notificationDTO.getEndDate());
        oldNotification.setLastChange(new Date().getTime() / 1000);
        oldNotification.setStatus(notificationDTO.getStatus());
        oldNotification.setAttributes(new HashMap<>(notificationDTO.getAttributes()));
        List<NotificationLocation> newLocations = NotificationLocationMapper.INSTANCE.toEntityList(
                notificationDTO.getNotificationLocations());

        for (NotificationLocation loc : newLocations) {
            loc.setNotification(oldNotification); // Set parent for cascade
        }
        // Replace old with new
        oldNotification.getNotificationLocations().clear();
        oldNotification.getNotificationLocations().addAll(newLocations);
        notificationSentRepository.update(oldNotification.getId());
        Notification updatedNotification = this.notificationRepository.save(oldNotification);
        log.info("Notification updated successfully id={}, locationCount={}", updatedNotification.getId(),
            updatedNotification.getNotificationLocations().size());
        return updatedNotification;
    }

   
    /**
     * Retrieves all Notification entries with status RUNNING.
     * If any are found, it marks them as 'processing' to avoid duplicate handling.
     *
     * @return List of Notification objects currently running.
     */
    @Transactional
    public List<Notification> findAllRunning() {
        log.info("Fetching notifications with status: {}", EnumStatusScheduled.RUNNING);

        // Get the notifications with a lock on it
        List<Notification> listNotification = this.notificationRepository.findAllByStatus(EnumStatusScheduled.RUNNING);
        //List<Notification> listNotification = this.notificationRepository.findAllByIds(List.of(7405L));
        int runningNotificationCount = listNotification.size();
        log.info("Found {} running notifications", runningNotificationCount);

        if (runningNotificationCount > 0) {
            // Get the id of the notifications
            List<Long> listId = listNotification.stream()
                    .map(notification -> notification.getId())
                    .collect(Collectors.toList());

            // Set the processing attribut to TRUE on the notifications
            this.notificationRepository.setProcessing(listId);
            log.info("Marked {} running notifications as processing", listId.size());
        }

        return listNotification;
    }

    
    /**
     * Stops a given Notification by setting its status to STOPPED.
     *
     * @param notification The Notification object to be stopped.
     */
    public void stop(Notification notification) {
        if (Objects.isNull(notification)) {
            log.warn("Stop skipped because notification is null");
            return;
        }

        log.info("Stopping notification id={}", notification.getId());
        Notification notificationDB = this.notificationRepository.findById(notification.getId()).orElse(null);

        if (Objects.nonNull(notificationDB)) {
            notificationDB.setStatus(EnumStatusScheduled.STOPPED);
            this.notificationRepository.save(notificationDB);
            log.info("Notification id={} stopped successfully", notification.getId());
        } else {
            log.warn("Stop skipped because notification id={} was not found", notification.getId());
        }

    }
   
    /**
     * Marks the given list of Notification entries as PROCESSED.
     *
     * @param scheduledList List of Notification objects to be marked as processed.
     */
    @Transactional
    public void setProcessed(List<Notification> scheduledList) {
        int scheduledCount = scheduledList != null ? scheduledList.size() : 0;
        log.info("Marking notifications as processed, count={}", scheduledCount);

        if (scheduledList != null && scheduledCount > 0) {
            List<Long> listId = scheduledList.stream()
                    .map(notification -> notification.getId())
                    .collect(Collectors.toList());

            this.notificationRepository.setProcessed(listId);
            log.info("Marked {} notifications as processed", listId.size());
        } else {
            log.debug("No notifications to mark as processed");
        }
    }


    /**
     * Send a notification to a topic through Firebase applications
     * 
     * @param notification The notification to send
     * @throws FirebaseMessagingException If an error occurs while handing the
     *                                    message off to FCM for delivery
     */
    public boolean send(Notification notification) throws FirebaseMessagingException {
        if (Objects.isNull(notification)) {
            log.warn("Send skipped because notification is null");
            return false;
        }

        log.info("Sending notification id={}, title={}, osTypes={}", notification.getId(), notification.getTitle(),
                notification.getOsTypes());
        this.deviceTokenService.initialize();

        String androidResponse = null;
        String iosResponse = null;

        List<EnumOsType> osTypes = notification.getOsTypes();

        if (osTypes.contains(EnumOsType.ANDROID)) {
            String androidBody = removeHtmlTags(notification.getMessage());
            Message androidMessage = Message.builder()
                    .setAndroidConfig(AndroidConfig.builder()
                            .setNotification(AndroidNotification.builder()
                                    .setTitle(notification.getTitle())
                                    .setBody(androidBody)
                                    .setImage(notification.getImage())
                                    .build())
                            .build())
                    .setTopic("SmartOffice")
                    .build();

            // Send Android notifications
            androidResponse = FirebaseMessaging.getInstance(FirebaseApp.getInstance("androidApp")).send(androidMessage);
            log.info("Android notification sent successfully, response={}", androidResponse);
        }

        if (osTypes.contains(EnumOsType.IOS)) {
            String iosBody = removeHtmlTags(notification.getMessage());
            Message iosMessage = Message.builder()
                    .setApnsConfig(ApnsConfig.builder()
                            .setAps(Aps.builder()
                                    .setContentAvailable(true)
                                    .setMutableContent(true)
                                    .setAlert(ApsAlert.builder()
                                            .setTitle(notification.getTitle())
                                            .setBody(iosBody)
                                            .setLaunchImage(notification.getImage())
                                            .build())
                                    .build())
                            .setFcmOptions(ApnsFcmOptions.builder().setImage(notification.getImage()).build())
                            .build())
                    .setTopic("SmartOffice")
                    .build();

            // Send iOS notifications
            iosResponse = FirebaseMessaging.getInstance(FirebaseApp.getInstance("iosApp")).send(iosMessage);
            log.info("iOS notification sent successfully, response={}", iosResponse);
        }

        boolean isSent = osTypes.contains(EnumOsType.ANDROID) && (Objects.nonNull(androidResponse))
                || osTypes.contains(EnumOsType.IOS) && (Objects.nonNull(iosResponse));
        log.info("Notification send result for id={}: {}", notification.getId(), isSent);
        return isSent;
    }

    /**
     * Sends a notification by delegating to the push notification service.
     *
     * @param notification the notification to send
     * @return true if the notification was sent successfully; false otherwise
     */

    public boolean sendNotification(Notification notification) {
        try {
            if (Objects.isNull(notification)) {
                log.warn("sendNotification skipped because notification is null");
                return false;
            }

            log.info("Delegating push notification send for notification id={}", notification.getId());
            boolean sent = pushNotificationService.sendByLocations(notification);
            log.info("Push notification delegation completed for id={}, result={}", notification.getId(), sent);
            return sent;
        } catch (FirebaseMessagingException e) {
            log.error("Firebase push failed for notification id={}",
                    notification != null ? notification.getId() : null, e);
            return false;
        }
    }
   
    /**
     * Removes specific HTML tags from the input string.
     *
     * @param input The input string possibly containing HTML tags.
     * @return A cleaned string with specified HTML tags removed.
     */
    private String removeHtmlTags(String input) {
        return input.replaceAll("<div>", " ").replaceAll("</div>", " ").replaceAll("<br>", "").replaceAll("</br>", "");
    }

    private List<EnumOsType> sanitizeAndBoundOsTypes(List<EnumOsType> incomingOsTypes) {
        List<EnumOsType> safeOsTypes = new ArrayList<>(MAX_NOTIFICATION_OS_TYPES);
        if (incomingOsTypes == null) {
            return safeOsTypes;
        }

        int processedCount = 0;
        for (EnumOsType osType : incomingOsTypes) {
            processedCount++;
            if (processedCount > MAX_NOTIFICATION_OS_TYPES) {
                throw new IllegalArgumentException("Invalid notification osTypes input");
            }
            if (osType != null) {
                EnumOsType validatedOsType = EnumOsType.valueOf(String.valueOf(osType.name()));
                safeOsTypes.add(EnumOsType.valueOf(String.valueOf(validatedOsType.name())));
            }
        }

        return safeOsTypes;
    }

    private String validateAndCloneText(String input, int maxLength) {
        if (input == null) {
            return null;
        }
        String trimmed = input.trim();
        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid notification text input");
        }
        return new String(trimmed);
    }


}