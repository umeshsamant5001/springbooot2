package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.Preference;
import com.capgemini.admin.back.model.Service;
import java.util.List;
import java.util.Optional;

@Repository
public interface PreferenceRepository extends JpaRepository<Preference, Long> {

    List<Preference> findByFavoriteServicesContaining(Service service);

    Optional<Preference> findByUserEmail(@Param("userEmail") String userEmail);
}