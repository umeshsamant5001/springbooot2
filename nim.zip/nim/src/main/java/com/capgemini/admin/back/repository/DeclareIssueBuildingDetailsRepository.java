package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.DeclareIssueBuildingDetails;

@Repository
public interface DeclareIssueBuildingDetailsRepository extends JpaRepository<DeclareIssueBuildingDetails, Long> {

    DeclareIssueBuildingDetails findByBuildingIdAndDeclareIssueId(Long buildingId, Long declareIssueId);

    List<DeclareIssueBuildingDetails> findByIdInAndBuildingId(List<Long> ids, Long buildingId);

    @EntityGraph(attributePaths = { "declareIssue" })
    List<DeclareIssueBuildingDetails> findByIdIn(List<Long> ids);


    @Query("SELECT d FROM DeclareIssueBuildingDetails d JOIN FETCH d.declareIssue WHERE d.buildingId = :buildingId")
    List<DeclareIssueBuildingDetails> findByBuildingId(@Param("buildingId") Long buildingId);

    @Modifying
    @Query("DELETE FROM DeclareIssueBuildingDetails d WHERE d.id IN :ids AND d.buildingId = :buildingId")
    void deleteByIdsandBuildingId(@Param("ids") List<Long> ids, @Param("buildingId") Long buildingId);

}
