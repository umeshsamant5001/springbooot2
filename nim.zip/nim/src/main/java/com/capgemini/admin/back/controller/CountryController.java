package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.admin.back.mapper.CountryMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingInformation;

import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.CountryDTO;
import com.capgemini.admin.back.model.OpeningHours;
import com.capgemini.admin.back.model.TemperatureUnit;
import com.capgemini.admin.back.model.TimeFormat;
import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.CityService;
import com.capgemini.admin.back.service.CountryService;
import com.capgemini.admin.back.service.CountryService.CountryUpsertInput;
import com.capgemini.admin.back.service.TreeService;





import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(value = CountryController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CountryController {

    static final String ROOT_API = "api/country";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class CountryWriteRequest {
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String countryIsoAlpha2;
        private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes = new HashMap<>();
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
    }


    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class OpeningHoursWriteRequest {
        @Min(0)
        private Long from;
        @Min(0)
        private Long to;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class BuildingInformationWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String address;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String city;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String country;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String phone;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String receptionMail;
        @Size(max = 500)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String infoUrl;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String ldapName;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String capacity;
        @Valid
        private OpeningHoursWriteRequest openingHours;
        @Min(0)
        private Long limitInDay;
        private Boolean global;
        @Min(0)
        private Long deskLimitCrowded;
        @DecimalMin("0.0")
        private Double minimumDeskArea;
        private Integer minTemp;
        private Integer maxTemp;
        private TemperatureUnit tempFormat;
        private TimeFormat timeFormat;
    }


    @Autowired
    private CountryService countryService;

    @Autowired
    private CityService cityService;
    @Autowired
    private TreeService treeService;
    @Autowired
    private BuildingService buildingService;

    /**
     * Retrieves a list of all countries with the number of associated cities.
     *
     * This endpoint supports internationalization via the "Accept-Language" header.
     * It fetches all countries, applies tree-based filtering (e.g., for access control or hierarchy),
     * and enriches each country DTO with the number of child cities.
     *
     * If no countries are found after filtering, it returns a 204 No Content response.
     * Otherwise, it returns a list of CountryDTOs (excluding city details) with a 200 OK status.
     *
     * @param language the language code from the "Accept-Language" header (default is "en")
     * @return ResponseEntity containing a list of CountryDTOs or an appropriate HTTP status
     */
    @GetMapping
    public ResponseEntity<List<CountryDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Country> countries = countryService.getAll();
        countries = treeService.filterTree(countries);
        if (CollectionUtils.isEmpty(countries)) {
            return ResponseEntity.noContent().build();
        }

        Map<Long, Long> nbCityByCountry = cityService.countByCountry()
                .stream()
                .collect(Collectors.toMap(
                        (tuple) -> (Long) tuple.get(0),
                        (tuple) -> (Long) tuple.get(1)));

        return ResponseEntity.ok(countries
                .stream()
                .map(country -> CountryMapper.INSTANCE.countryToCountryDTONoCities(country, language))
                .peek(countryDTO -> {
                    countryDTO.setNbChilds(nbCityByCountry.getOrDefault(countryDTO.getId(), 0L));
                })
                .collect(Collectors.toList()));
    }

    /**
     * Retrieves detailed information about a specific country by its ID.
     *
     * This endpoint supports localization via the "Accept-Language" header.
     * It filters the country tree structure and fetches building information
     * (global or local) to populate opening hours and daily limits.
     * Also includes the number of child cities associated with the country.
     *
     * @param countryId the ID of the country to retrieve
     * @param language the language preference for localization (default is "en")
     * @return ResponseEntity containing the CountryDTO if found and authorized,
     *         404 Not Found if the country does not exist,
     *         or 401 Unauthorized if the country is filtered out
     */
    @GetMapping("/{countryId}")
    public ResponseEntity<CountryDTO> getCountry(
            @PathVariable Long countryId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Country country = countryService.getCountry(countryId);

        if (Objects.isNull(country)) {
            return ResponseEntity.notFound().build();
        }
        country = treeService.filterTree(country);
        if (Objects.isNull(country)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        List<Building> buildingsGlobal = countryService.getBuildingsGlobal(countryId);
        List<Building> buildingsLocal = countryService.getBuildingsLocal(countryId);
        CountryDTO countryDTO = CountryMapper.INSTANCE.countryToCountryDTO(country, language);
        if (Objects.nonNull(buildingsGlobal) && !buildingsGlobal.isEmpty()) {
            BuildingInformation information = buildingsGlobal.get(0).getInformation();
            countryDTO.setOpeningHours(information.getOpeningHours());
            countryDTO.setLimitInDay(information.getLimitInDay());
        } else {
            BuildingInformation information = buildingsLocal.get(0).getInformation();
            countryDTO.setOpeningHours(information.getOpeningHours());
            countryDTO.setLimitInDay(information.getLimitInDay());
        }
        countryDTO.setNbChilds(cityService.countByCountryId(countryDTO.getId()));
        return ResponseEntity.ok(countryDTO);
    }

    /**
     * Creates a new country entry based on the provided CountryDTO.
     *
     * This endpoint accepts a JSON payload representing the country details,
     * converts it to a Country entity, sets the modification timestamp, and saves it.
     * The response includes the newly created country data, localized according to
     * the "Accept-Language" header.
     *
     * @param countryDTO the DTO containing country details to be created
     * @param language the language preference for localization (default is "en")
     * @return ResponseEntity containing the created CountryDTO with HTTP 201 status,
     *         or HTTP 500 Internal Server Error if the save operation fails
     */
    @PostMapping
    public ResponseEntity<CountryDTO> createCountry(
            @Valid @RequestBody CountryWriteRequest countryRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        CountryUpsertInput safeCountryInput = new CountryUpsertInput(
                countryRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(countryRequest.getCdmKeyId())),
                countryRequest.getCountryIsoAlpha2() == null
                        ? null
                        : new String(String.valueOf(countryRequest.getCountryIsoAlpha2())),
                countryRequest.getTitleFr() == null
                        ? null
                        : new String(String.valueOf(countryRequest.getTitleFr())),
                countryRequest.getTitleEn() == null
                        ? null
                        : new String(String.valueOf(countryRequest.getTitleEn())),
                new HashMap<>(this.sanitizeAttributes(countryRequest.getAttributes())));

        try {
            Country countrySave = countryService.save(safeCountryInput);





            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(CountryMapper.INSTANCE.countryToCountryDTO(countrySave, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Updates an existing country entry identified by its ID.
     *
     * This endpoint receives a CountryDTO payload, validates it, and updates the
     * corresponding country entity. The response includes the updated country data,
     * localized according to the "Accept-Language" header.
     *
     * @param countryId the ID of the country to update
     * @param countryDTO the DTO containing updated country details
     * @param language the language preference for localization (default is "en")
     * @return ResponseEntity containing the updated CountryDTO with HTTP 200 status,
     *         404 Not Found if the country does not exist,
     *         or 500 Internal Server Error if the update operation fails
     */
    @PutMapping("/{countryId}")
    public ResponseEntity<CountryDTO> updateCountry(
            @PathVariable Long countryId,
            @Valid @RequestBody CountryWriteRequest countryRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        Country country = this.countryService.getCountry(countryId);
        if (Objects.isNull(country)) {
            return ResponseEntity.notFound().build();
        }

        Long safeCdmKeyId = countryRequest.getCdmKeyId() == null
                ? null
                : Long.valueOf(String.valueOf(countryRequest.getCdmKeyId()));
        String safeTitleFr = countryRequest.getTitleFr() == null
                ? null
                : new String(String.valueOf(countryRequest.getTitleFr()));
        String safeTitleEn = countryRequest.getTitleEn() == null
                ? null
                : new String(String.valueOf(countryRequest.getTitleEn()));
        Map<String, String> safeAttributes = new HashMap<>(this.sanitizeAttributes(countryRequest.getAttributes()));

        Country newCountry = this.countryService.updateCountry(countryId, safeCdmKeyId, safeTitleFr, safeTitleEn,
                safeAttributes);






        if (Objects.isNull(newCountry)) {
            return ResponseEntity.internalServerError().build();
        }
        return ResponseEntity.ok(CountryMapper.INSTANCE.countryToCountryDTO(newCountry, language));
    }

    /**
     * Deletes an existing country identified by its ID.
     *
     * This endpoint checks if the country exists and, if found, deletes it from the system.
     * If the country does not exist, it returns a 404 Not Found response.
     *
     * @param countryId the ID of the country to delete
     * @return ResponseEntity with HTTP 204 No Content if deletion is successful,
     *         or HTTP 404 Not Found if the country does not exist
     */
    @DeleteMapping("/{countryId}")
    public ResponseEntity<Object> deleteCountry(@PathVariable Long countryId) {
        Country country = countryService.getCountry(countryId);
        if (Objects.isNull(country)) {
            return ResponseEntity.notFound().build();
        }

        countryService.deleteById(countryId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Updates building-related configuration attributes for a specific country.
     *
     * This endpoint receives a BuildingInformationDTO payload and updates various
     * country-level attributes such as desk limits, temperature settings, and format preferences.
     * It also updates the building information for all buildings associated with the country.
     * Localization is supported via the "Accept-Language" header.
     *
     * @param countryId the ID of the country whose building information is to be updated
     * @param buildingInformationDTO the DTO containing updated building configuration details
     * @param language the language preference for localization (default is "en")
     * @return ResponseEntity with HTTP 200 status (no body) once the update is applied.
     *         The underlying BuildingInformation entity is intentionally NOT exposed in the
     *         response payload to avoid leaking sensitive/internal fields (excessive data exposure).
     */
    @PutMapping("/building/{countryId}")
    public ResponseEntity<Void> updateBuilding(
            @PathVariable Long countryId,
            @Valid @RequestBody BuildingInformationWriteRequest buildingInformationRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Country country = countryService.getCountry(countryId);
        BuildingInformation sanitizedBuildingInformation = new BuildingInformation();
        sanitizedBuildingInformation.setAddress(buildingInformationRequest.getAddress() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getAddress())));
        sanitizedBuildingInformation.setCity(buildingInformationRequest.getCity() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getCity())));
        sanitizedBuildingInformation.setCountry(buildingInformationRequest.getCountry() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getCountry())));
        sanitizedBuildingInformation.setPhone(buildingInformationRequest.getPhone() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getPhone())));
        sanitizedBuildingInformation.setReceptionMail(buildingInformationRequest.getReceptionMail() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getReceptionMail())));
        sanitizedBuildingInformation.setInfoUrl(buildingInformationRequest.getInfoUrl() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getInfoUrl())));
        sanitizedBuildingInformation.setLdapName(buildingInformationRequest.getLdapName() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getLdapName())));
        sanitizedBuildingInformation.setCapacity(buildingInformationRequest.getCapacity() == null
                ? null
                : new String(String.valueOf(buildingInformationRequest.getCapacity())));

        OpeningHours sanitizedOpeningHours = null;
        if (Objects.nonNull(buildingInformationRequest.getOpeningHours())) {
            sanitizedOpeningHours = new OpeningHours();
            sanitizedOpeningHours.setFrom(buildingInformationRequest.getOpeningHours().getFrom() == null
                    ? null
                    : Long.valueOf(buildingInformationRequest.getOpeningHours().getFrom()));
            sanitizedOpeningHours.setTo(buildingInformationRequest.getOpeningHours().getTo() == null
                    ? null
                    : Long.valueOf(buildingInformationRequest.getOpeningHours().getTo()));
        }
        sanitizedBuildingInformation.setOpeningHours(sanitizedOpeningHours);

        sanitizedBuildingInformation.setLimitInDay(buildingInformationRequest.getLimitInDay() == null
                ? null
                : Long.valueOf(buildingInformationRequest.getLimitInDay()));
        sanitizedBuildingInformation.setGlobal(buildingInformationRequest.getGlobal() == null
                ? null
                : Boolean.valueOf(buildingInformationRequest.getGlobal().booleanValue()));
        sanitizedBuildingInformation.setDeskLimitCrowded(buildingInformationRequest.getDeskLimitCrowded() == null
                ? null
                : Long.valueOf(buildingInformationRequest.getDeskLimitCrowded()));
        sanitizedBuildingInformation.setMinimumDeskArea(buildingInformationRequest.getMinimumDeskArea() == null
                ? null
                : Double.valueOf(buildingInformationRequest.getMinimumDeskArea()));
        sanitizedBuildingInformation.setMinTemp(buildingInformationRequest.getMinTemp() == null
                ? null
                : Integer.valueOf(buildingInformationRequest.getMinTemp()));
        sanitizedBuildingInformation.setMaxTemp(buildingInformationRequest.getMaxTemp() == null
                ? null
                : Integer.valueOf(buildingInformationRequest.getMaxTemp()));
        sanitizedBuildingInformation.setTempFormat(buildingInformationRequest.getTempFormat() == null
                ? null
                : TemperatureUnit.valueOf(String.valueOf(buildingInformationRequest.getTempFormat())));
        sanitizedBuildingInformation.setTimeFormat(buildingInformationRequest.getTimeFormat() == null
                ? null
                : TimeFormat.valueOf(String.valueOf(buildingInformationRequest.getTimeFormat())));



        Map<String, String> sanitizedCountryAttributes = this.sanitizeAttributes(country.getAttributes());

        if (sanitizedBuildingInformation.getDeskLimitCrowded() != null) {
            sanitizedCountryAttributes.put("desk_limit_crowded",
                    new String(String.valueOf(sanitizedBuildingInformation.getDeskLimitCrowded())));
        }

        if (sanitizedBuildingInformation.getMinimumDeskArea() != null) {
            sanitizedCountryAttributes.put("minimum_desk_area",
                    new String(String.valueOf(sanitizedBuildingInformation.getMinimumDeskArea())));
        }

        if (sanitizedBuildingInformation.getMinTemp() != null) {
            sanitizedCountryAttributes.put("min_temp",
                    new String(String.valueOf(sanitizedBuildingInformation.getMinTemp())));
        }

        if (sanitizedBuildingInformation.getMaxTemp() != null) {
            sanitizedCountryAttributes.put("max_temp",
                    new String(String.valueOf(sanitizedBuildingInformation.getMaxTemp())));
        }

        if (sanitizedBuildingInformation.getTempFormat() != null) {
            sanitizedCountryAttributes.put("temp_format",
                    new String(String.valueOf(sanitizedBuildingInformation.getTempFormat())));
        }

        if (sanitizedBuildingInformation.getTimeFormat() != null) {
            sanitizedCountryAttributes.put("time_format",
                    new String(String.valueOf(sanitizedBuildingInformation.getTimeFormat())));
        }


        Country sanitizedCountryForSave = new Country();
        sanitizedCountryForSave.setId(country.getId() == null ? null : Long.valueOf(country.getId()));
        sanitizedCountryForSave.setCdmKeyId(country.getCdmKeyId() == null ? null : Long.valueOf(country.getCdmKeyId()));
        sanitizedCountryForSave.setCountryIsoAlpha2(country.getCountryIsoAlpha2() == null
                ? null
                : new String(String.valueOf(country.getCountryIsoAlpha2())));
        sanitizedCountryForSave.setTitleEn(country.getTitleEn() == null
                ? null
                : new String(String.valueOf(country.getTitleEn())));
        sanitizedCountryForSave.setTitleFr(country.getTitleFr() == null
                ? null
                : new String(String.valueOf(country.getTitleFr())));
        sanitizedCountryForSave.setAttributes(sanitizedCountryAttributes);
        sanitizedCountryForSave.setModifiedAt(country.getModifiedAt() == null
                ? null
                : Long.valueOf(country.getModifiedAt()));

        countryService.saveSanitizedCountry(sanitizedCountryForSave);

        List<Building> getBuildings = this.countryService.getBuildings(countryId);

        



        if (Objects.nonNull(getBuildings) && !getBuildings.isEmpty()) {
            getBuildings.forEach(building -> {
                BuildingInformation safeBuildingInformationForUpdate = new BuildingInformation();
                safeBuildingInformationForUpdate.setAddress(sanitizedBuildingInformation.getAddress() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getAddress())));
                safeBuildingInformationForUpdate.setCity(sanitizedBuildingInformation.getCity() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getCity())));
                safeBuildingInformationForUpdate.setCountry(sanitizedBuildingInformation.getCountry() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getCountry())));
                safeBuildingInformationForUpdate.setPhone(sanitizedBuildingInformation.getPhone() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getPhone())));
                safeBuildingInformationForUpdate.setReceptionMail(sanitizedBuildingInformation.getReceptionMail() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getReceptionMail())));
                safeBuildingInformationForUpdate.setInfoUrl(sanitizedBuildingInformation.getInfoUrl() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getInfoUrl())));
                safeBuildingInformationForUpdate.setLdapName(sanitizedBuildingInformation.getLdapName() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getLdapName())));
                safeBuildingInformationForUpdate.setCapacity(sanitizedBuildingInformation.getCapacity() == null
                        ? null
                        : new String(String.valueOf(sanitizedBuildingInformation.getCapacity())));
                safeBuildingInformationForUpdate.setLimitInDay(sanitizedBuildingInformation.getLimitInDay() == null
                        ? null
                        : Long.valueOf(sanitizedBuildingInformation.getLimitInDay()));
                safeBuildingInformationForUpdate.setGlobal(sanitizedBuildingInformation.getGlobal() == null
                        ? null
                        : Boolean.valueOf(sanitizedBuildingInformation.getGlobal().booleanValue()));
                safeBuildingInformationForUpdate.setDeskLimitCrowded(sanitizedBuildingInformation.getDeskLimitCrowded() == null
                        ? null
                        : Long.valueOf(sanitizedBuildingInformation.getDeskLimitCrowded()));
                safeBuildingInformationForUpdate.setMinimumDeskArea(sanitizedBuildingInformation.getMinimumDeskArea() == null
                        ? null
                        : Double.valueOf(sanitizedBuildingInformation.getMinimumDeskArea()));
                safeBuildingInformationForUpdate.setMinTemp(sanitizedBuildingInformation.getMinTemp() == null
                        ? null
                        : Integer.valueOf(sanitizedBuildingInformation.getMinTemp()));
                safeBuildingInformationForUpdate.setMaxTemp(sanitizedBuildingInformation.getMaxTemp() == null
                        ? null
                        : Integer.valueOf(sanitizedBuildingInformation.getMaxTemp()));
                safeBuildingInformationForUpdate.setTempFormat(sanitizedBuildingInformation.getTempFormat() == null
                        ? null
                        : TemperatureUnit.valueOf(String.valueOf(sanitizedBuildingInformation.getTempFormat())));
                safeBuildingInformationForUpdate.setTimeFormat(sanitizedBuildingInformation.getTimeFormat() == null
                        ? null
                        : TimeFormat.valueOf(String.valueOf(sanitizedBuildingInformation.getTimeFormat())));

                OpeningHours safeOpeningHoursForUpdate = null;
                if (Objects.nonNull(sanitizedBuildingInformation.getOpeningHours())) {
                    safeOpeningHoursForUpdate = new OpeningHours();
                    safeOpeningHoursForUpdate.setFrom(sanitizedBuildingInformation.getOpeningHours().getFrom() == null
                            ? null
                            : Long.valueOf(sanitizedBuildingInformation.getOpeningHours().getFrom()));
                    safeOpeningHoursForUpdate.setTo(sanitizedBuildingInformation.getOpeningHours().getTo() == null
                            ? null
                            : Long.valueOf(sanitizedBuildingInformation.getOpeningHours().getTo()));
                }
                safeBuildingInformationForUpdate.setOpeningHours(safeOpeningHoursForUpdate);

                buildingService.updateBuildingInformation(building, safeBuildingInformationForUpdate);
            });


        }


        return ResponseEntity.ok().build();
    }

    




    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }
}
