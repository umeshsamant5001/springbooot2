package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "notificationEmail", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class NotificationEmail implements Scheduled {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NotificationEmail_Generator")
    @SequenceGenerator(name = "NotificationEmail_Generator", sequenceName = "NotificationEmail_Sequence")
    private Long id;

    @Column(name = "title")
    private String title;

    @Column(name = "message")
    private String message;

    @Column(name = "messageType")
    private String messageType;

    @Column(name = "priority_type")
    @Enumerated(EnumType.STRING)
    private EnumPriorityType priorityType;

    @Column(name = "start_date", nullable = true)
    private Long startDate;

    @Column(name = "end_date", nullable = true)
    private Long endDate;

    @Column(name = "last_change")
    private Long lastChange;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private EnumStatusScheduled status;

    @Column(name = "processing", nullable = false)
    @ColumnDefault("0")
    private Boolean processing = Boolean.FALSE;

    @CollectionTable(name = "notificationEmail_attributes", joinColumns = @JoinColumn(name = "notificationEmail_id", referencedColumnName = "id"))
    @ElementCollection(fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    @MapKeyColumn(name = "att_key")
    @Column(name = "att_value")
    private Map<String, String> attributes = new HashMap<>();

    @OneToMany(mappedBy = "notificationEmail", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @Fetch(FetchMode.SUBSELECT)
    private List<NotificationEmailSent> notificationSent = new ArrayList<>();
}