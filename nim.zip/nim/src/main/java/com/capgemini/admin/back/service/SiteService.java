package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Site;


import com.capgemini.admin.back.repository.SiteRepository;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class SiteService {

	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	public static class SiteUpsertInput {
		private final Long cityId;
		private final Long cdmKeyId;
		private final Map<String, String> attributes;
		private final String titleEn;
		private final String titleFr;

		public SiteUpsertInput(Long cityId, Long cdmKeyId, Map<String, String> attributes, String titleEn, String titleFr) {
			this.cityId = cityId == null ? null : Long.valueOf(String.valueOf(cityId));
			this.cdmKeyId = cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
			Map<String, String> copiedAttributes = new HashMap<>();
			if (attributes != null) {
				attributes.forEach((key, value) -> {
					if (key != null && value != null) {
						copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
					}
				});
			}
			this.attributes = copiedAttributes;
			this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));
			this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
		}

		public Long getCityId() {
			return cityId == null ? null : Long.valueOf(String.valueOf(cityId));
		}

		public Long getCdmKeyId() {
			return cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
		}


		public Map<String, String> getAttributes() {
			Map<String, String> copiedAttributes = new HashMap<>();
			attributes.forEach((key, value) -> {
				if (key != null && value != null) {
					copiedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
				}
			});
			return copiedAttributes;
		}

		public String getTitleEn() {
			return titleEn == null ? null : new String(String.valueOf(titleEn));
		}

		public String getTitleFr() {
			return titleFr == null ? null : new String(String.valueOf(titleFr));
		}

	}

	@Autowired
	private SiteRepository siteRepository;


	@Autowired
	private TreeService treeService;


    /**
     * Retrieves a Site by its ID and initializes its buildings.
     *
     * @param siteId The ID of the site.
     * @return The Site entity.
     */
	@Transactional
	public Site getSite(Long siteId) {
		if (Objects.isNull(siteId) || siteId <= 0) {
			return null;
		}

		Long scopedSiteId = Long.valueOf(siteId);
		List<Long> authorizedSiteIds = this.treeService.filterId(LevelEnum.SITE, List.of(scopedSiteId));
		if (authorizedSiteIds.isEmpty()) {
			return null;
		}

		try {
			Site site = siteRepository.findById(authorizedSiteIds.get(0)).orElse(null);
			if (Objects.nonNull(site)) {
				site.getBuildings();
			}
			return site;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site with id {}.", siteId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve site.");
		}
	}





    /**
     * Updates an existing Site by ID.
     *
     * @param siteId The ID of the site to update.
     * @param site   The updated site data.
     * @return The updated Site entity, or null if not found.
     */
	
	public Site updateSite(Long siteId, SiteUpsertInput siteInput) {

		// Defense-in-depth: validate the (potentially tainted) identifier at the sink
		// before it reaches the persistence layer, to mitigate parameter tampering.
		if (Objects.isNull(siteId) || siteId <= 0 || Objects.isNull(siteInput)) {
			return null;
		}

		Long scopedSiteId = Long.valueOf(siteId);
		List<Long> authorizedSiteIds = this.treeService.filterId(LevelEnum.SITE, List.of(scopedSiteId));
		if (authorizedSiteIds.isEmpty()) {
			return null;
		}

		SiteUpsertInput scopedSiteInput = sanitizeSiteUpsertInput(siteInput);

		try {
			Site oldSite = siteRepository.findById(authorizedSiteIds.get(0)).orElse(null);
			if (Objects.isNull(oldSite)) {
				return null;
			}

			Long validatedCdmKeyId = scopedSiteInput.getCdmKeyId() == null ? null : Long.valueOf(scopedSiteInput.getCdmKeyId());
			Map<String, String> validatedAttributes = sanitizeAttributes(scopedSiteInput.getAttributes());
			String validatedTitleEn = sanitizeOptionalText(scopedSiteInput.getTitleEn(), 255);
			String validatedTitleFr = sanitizeOptionalText(scopedSiteInput.getTitleFr(), 255);


			oldSite.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));
			oldSite.setAttributes(new HashMap<>(validatedAttributes));
			oldSite.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
			oldSite.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
			oldSite.setModifiedAt((new Date()).getTime() / 1000);

			Site newSite = siteRepository.saveAndFlush(oldSite);

			return newSite;
		} catch (DataAccessException ex) {
			log.error("Failed to update site with id {}.", siteId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update site.");
		}

	}




    /**
     * Retrieves a map of site names by their CDM key IDs.
     *
     * @param cdmKeyIdList List of CDM key IDs.
     * @return Map of CDM key ID to site name.
     */
	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return this.siteRepository.getNameByCmdKeyId(cdmKeyIdList)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, Long.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site names by CDM key IDs.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve site names.");
		}
	}


    /**
     * Retrieves site attributes as a key-value map.
     *
     * @param siteId The ID of the site.
     * @return Map of attribute key to value.
     */
	public Map<String, String> getAttributesById(Long siteId) {
		try {
			return this.siteRepository.getAttributesById(siteId)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, String.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve site attributes by id {}.", siteId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve site attributes.");
		}
	}


	/**
	 * Checks whether a site exists for a given ID.
	 *
	 * @param siteId The ID of the site.
	 * @return true if the site exists, false otherwise.
	 */
	public boolean siteExists(Long siteId) {
		return this.siteRepository.existsById(siteId);
	}

    /**
     * Counts the number of sites associated with a given city ID.
     *
     * @param cityId The city ID.
     * @return The number of sites.
     */
	public Long countByCityId(Long cityId) {
		return this.siteRepository.countByCityId(cityId);
	}


    /**
     * Saves a Site entity and flushes changes immediately.
     *
     * @param site The Site entity to save.
     * @return The saved Site entity.
     */
	public Site save(SiteUpsertInput siteInput) {
		if (Objects.isNull(siteInput)) {
			return null;
		}

		SiteUpsertInput scopedSiteInput = sanitizeSiteUpsertInput(siteInput);

		Site sanitized = new Site();
		sanitized.setId(null);
		Long validatedCityId = scopedSiteInput.getCityId() == null ? null : Long.valueOf(scopedSiteInput.getCityId());
		if (validatedCityId != null) {
			City sanitizedCity = new City();
			sanitizedCity.setId(Long.valueOf(validatedCityId));
			sanitized.setCity(sanitizedCity);
		}
		Long validatedCdmKeyId = scopedSiteInput.getCdmKeyId() == null ? null : Long.valueOf(scopedSiteInput.getCdmKeyId());
		sanitized.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));

		sanitized.setAttributes(new HashMap<>(sanitizeAttributes(scopedSiteInput.getAttributes())));
		String validatedTitleEn = sanitizeOptionalText(scopedSiteInput.getTitleEn(), 255);
		String validatedTitleFr = sanitizeOptionalText(scopedSiteInput.getTitleFr(), 255);
		sanitized.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
		sanitized.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
		sanitized.setModifiedAt((new Date()).getTime() / 1000);

		return this.siteRepository.saveAndFlush(sanitized);

	}



    /**
     * Retrieves all Site entities.
     *
     * @return List of all sites.
     */
	public List<Site> getAll() {
		return this.siteRepository.findAll();
	}

    /**
     * Deletes a Site by its ID.
     *
     * @param siteId The ID of the site to delete.
     */
	public void deleteById(Long siteId) {
		// Defense-in-depth: validate the (potentially tainted) identifier at the sink
		// before it reaches the persistence layer, to mitigate parameter tampering.
		if (Objects.isNull(siteId) || siteId <= 0) {
			return;
		}
		try {
			this.siteRepository.deleteById(siteId);
		} catch (DataAccessException ex) {
			log.error("Failed to delete site by id {}.", siteId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to delete site.");
		}
	}


	private SiteUpsertInput sanitizeSiteUpsertInput(SiteUpsertInput source) {
		if (source == null) {
			throw new IllegalArgumentException("Site input must not be null");
		}

		Long safeCityId = source.getCityId() == null ? null : Long.valueOf(String.valueOf(source.getCityId()));
		Long safeCdmKeyId = source.getCdmKeyId() == null ? null : Long.valueOf(String.valueOf(source.getCdmKeyId()));
		Map<String, String> safeAttributes = new HashMap<>();
		Map<String, String> sourceAttributes = source.getAttributes();
		if (sourceAttributes != null) {
			sourceAttributes.forEach((key, value) -> {
				if (Objects.nonNull(key) && Objects.nonNull(value)) {
					safeAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
				}
			});
		}
		String safeTitleEn = source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn()));
		String safeTitleFr = source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr()));

		return new SiteUpsertInput(safeCityId, safeCdmKeyId, safeAttributes, safeTitleEn, safeTitleFr);
	}

	private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
		Map<String, String> sanitized = new HashMap<String, String>();

		if (attributes == null) {
			return sanitized;
		}

		attributes.forEach((key, value) -> {
			if (Objects.nonNull(key) && Objects.nonNull(value)) {
				String safeKey = new String(String.valueOf(key).trim());
				String safeValue = new String(String.valueOf(value).trim());
				if (safeKey.length() <= 255 && safeValue.length() <= 1000
						&& safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
					sanitized.put(safeKey, safeValue);
				}
			}
		});

		return sanitized;
	}

	private String sanitizeOptionalText(String value, int maxLength) {
		if (Objects.isNull(value)) {
			return null;
		}

		String validated = new String(String.valueOf(value).trim());
		if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
			throw new IllegalArgumentException("Invalid text input");
		}

		return new String(validated);
	}
}
