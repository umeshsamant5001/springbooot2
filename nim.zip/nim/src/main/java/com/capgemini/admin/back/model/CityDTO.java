package com.capgemini.admin.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class CityDTO implements WithTitleDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long modifiedAt;
    private String titleFr;
    private String titleEn;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String title;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private CountryDTO country;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private List<SiteDTO> sites;
    private Long cdmKeyId;
    private Long cdmStateId;
    private Map<String, String> attributes = new HashMap<String, String>();
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long nbChilds;
}
