package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.model.CiscoDeviceDTO;
import com.capgemini.admin.back.model.CiscoDeviceResponseDTO;
import com.capgemini.admin.back.model.EnumOrderBy;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.service.CiscoDeviceService;
import com.capgemini.admin.back.service.TreeService;

@RestController
@RequestMapping(value = CiscoDeviceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CiscoDeviceController {
    public static final String ROOT_API = "/api/ciscoDevices";
    @Autowired
    private CiscoDeviceService ciscoDeviceService;

    @Autowired
    private TreeService treeService;

    @GetMapping(value = "/poiName/{poiName}")
    public ResponseEntity<List<CiscoDeviceResponseDTO>> getCiscoDevices(@PathVariable String poiName) {
        if (poiName == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyList());
        }
        List<CiscoDeviceResponseDTO> responseDTO = ciscoDeviceService.findCiscoDevicesByPoiName(poiName);
        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Retrieves a list of Cisco devices associated with the specified floor ID.
     *
     * @param floorId the ID of the floor to fetch devices for
     * @return HTTP 200 with the list of devices if found,
     *         or HTTP 400 with an empty list if the floor ID is null
     */
    @GetMapping("/floor/{floorId}")
    public ResponseEntity<List<CiscoDeviceDTO>> getCiscoDevicesByFloorId(@PathVariable Long floorId) {
        if (floorId == null) {
            return ResponseEntity.badRequest().body(Collections.emptyList());
        }
        List<CiscoDeviceDTO> devices = ciscoDeviceService.getCiscoDevicesByFloorId(floorId);
        return ResponseEntity.ok(devices);
    }

    /**
     * REST endpoint to fetch paginated Cisco devices for a specific building.
     *
     * @param buildingId The ID of the building for which devices are requested.
     * @param first      The starting index for pagination.
     * @param last       The ending index for pagination.
     * @param column     (Optional) The column name to sort the results by.
     * @param orderBy    (Optional) The sort direction (ASC or DESC).
     * @param language   The preferred language from the request header (default is
     *                   "en").
     * @return A ResponseEntity containing the paginated device data or an
     *         unauthorized status.
     */
    @GetMapping("/paged")
    public ResponseEntity<Map<String, Object>> getPagedCiscoDevices(
            @RequestParam Long buildingId,
            @RequestParam int first,
            @RequestParam int last,
            @RequestParam(required = false) String column,
            @RequestParam(required = false) EnumOrderBy orderBy,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        // Authorization check
        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Map<String, Object> response = ciscoDeviceService.getPaginatedCiscoDevices(buildingId, first, last, column,
                orderBy);
        return ResponseEntity.ok(response);
    }

    /**
     * Exports all ciscoDevice data in CSV format.
     *
     * This endpoint is intended for SuperAdmin users and does not apply
     * location-based restrictions.
     * It retrieves all device records and returns them as a downloadable CSV
     * string.
     *
     * @return a ResponseEntity containing the CSV-formatted device data with:
     *         - Content-Type: text/csv
     *         - 200 OK if the export is successful
     */
    @GetMapping(value = "/export", produces = "text/csv")
    public ResponseEntity<String> exportCiscoDevices() {
        // No Location limition because only SuperAdmin should access it

        // Retrieving a list of device data associated.
        List<List<String>> data = ciscoDeviceService.fetchExportCiscoDevices();
        return ciscoDeviceService.exportCiscoDevice(data);
    }
}
