package com.capgemini.admin.back.repository;

import java.util.List;

import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.NotificationEmail;

@Repository
public interface NotificationEmailRepository extends JpaRepository<NotificationEmail, Long> {

  public List<NotificationEmail> findDistinctByPriorityTypeInAndStatusIn(List<EnumPriorityType> priorityTypes,
      List<EnumStatusScheduled> status);

  /**
   * Return the list of notification to process and add a lock on them
   */
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("SELECT notificationEmail FROM NotificationEmail notificationEmail WHERE status = :status AND processing != TRUE")
  public List<NotificationEmail> findAllByStatus(@Param("status") EnumStatusScheduled status);

  @Modifying
  @Query("UPDATE NotificationEmail SET processing = true WHERE id IN (:ids) ")
  public void setProcessing(@Param("ids") List<Long> ids);

  @Modifying
  @Query("UPDATE NotificationEmail SET processing = false WHERE id IN (:ids) ")
  public void setProcessed(@Param("ids") List<Long> ids);

}