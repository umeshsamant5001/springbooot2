package com.capgemini.admin.back.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.ThresholdConfiguration;
import com.capgemini.admin.back.model.ThresholdConfigurationDTO;

@Mapper(uses = { ThresholdMapper.class, AlertMapper.class })
public interface ThresholdConfigurationMapper {

    ThresholdConfigurationMapper INSTANCE = Mappers.getMapper(ThresholdConfigurationMapper.class);

    ThresholdConfiguration thresholdConfigurationDTOToThresholdConfiguration(ThresholdConfigurationDTO in);

    ThresholdConfigurationDTO thresholdConfigurationToThresholdConfigurationDTO(ThresholdConfiguration in);

    List<ThresholdConfiguration> thresholdConfigurationDTOToThresholdConfigurationList(
            List<ThresholdConfigurationDTO> in);

    List<ThresholdConfigurationDTO> thresholdConfigurationToThresholdConfigurationDTOList(
            List<ThresholdConfiguration> in);

}
