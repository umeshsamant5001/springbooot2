package com.capgemini.admin.back.repository;

import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.DeviceSpaceTypeDTO;
import com.capgemini.admin.back.model.EnumDeviceStatus;
import com.capgemini.admin.back.model.EnumDeviceType;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

        public Device findByUuid(@Param("uuid") String uuid);

        public List<Device> findAllByPoiName(@Param("poiName") String poiName);

        @Query("SELECT device FROM Device device INNER JOIN FETCH device.floor floor INNER JOIN FETCH floor.building WHERE floor.id = :floorId")
        public List<Device> findAllByFloorId(@Param("floorId") long floorId);

        public final String BASE_QUERY_AVG = "SELECT AVG(CAST(attributes AS float)) FROM Poi poi JOIN poi.spaceType spaceType JOIN Device device ON device.poiName = poi.name JOIN device.attributes attributes ";
        public final String BASE_QUERY_WHERE_AVG = "AND INDEX(attributes) = :attributeName AND attributes is not null AND attributes != '' AND attributes like '[0-9]%' AND spaceType.spaceTypeName in :spaceTypes";
        public final String BASE_QUERY_COUNT = "SELECT COUNT(DISTINCT(device.uuid)) FROM Poi poi JOIN poi.spaceType spaceType JOIN Device device ON device.poiName = poi.name JOIN device.attributes attributes ";

        @Query(BASE_QUERY_AVG + "JOIN poi.floor floor WHERE floor.building.id = :buildingId " + BASE_QUERY_WHERE_AVG)
        public Float findAverageTempByBuildingId(
                        @Param("buildingId") Long buildingId,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query(BASE_QUERY_AVG + "WHERE poi.floor.id in :floorIds " + BASE_QUERY_WHERE_AVG)
        public Float findAverageTempByFloorIds(
                        @Param("floorIds") List<Long> floorIds,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query(BASE_QUERY_COUNT +
                        "WHERE poi.floor.id in :floorIds AND INDEX(attributes) = :attributeName AND spaceType.spaceTypeName in :spaceTypes AND attributes = 'free' ")
        public int countStateFreeByFloorIds(
                        @Param("floorIds") List<Long> floorIds,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query(BASE_QUERY_COUNT +
                        "WHERE poi.floor.id in :floorIds AND INDEX(attributes) = :attributeName AND spaceType.spaceTypeName in :spaceTypes ")
        public int countStateAttributeByFloorIds(
                        @Param("floorIds") List<Long> floorIds,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query(BASE_QUERY_COUNT +
                        "JOIN poi.floor floor WHERE floor.building.id = :buildingId AND INDEX(attributes) = :attributeName AND spaceType.spaceTypeName in :spaceTypes AND attributes = 'free' ")
        public int countStateFreeByBuildingId(
                        @Param("buildingId") Long buildingId,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query(BASE_QUERY_COUNT +
                        "JOIN poi.floor floor WHERE floor.building.id = :buildingId AND INDEX(attributes) = :attributeName AND spaceType.spaceTypeName in :spaceTypes ")
        public int countStateAttributeByBuildingId(
                        @Param("buildingId") Long buildingId,
                        @Param("attributeName") String attributeName,
                        @Param("spaceTypes") List<String> spaceTypes);

        @Query("SELECT device FROM Device device WHERE device.poiName IN (" +
                        "   SELECT poi.name FROM Poi poi " +
                        "   JOIN poi.spaceType spaceType " +
                        "   JOIN spaceType.poiGroup poiGroup " +
                        "   JOIN poi.floor floor " +
                        "   WHERE floor.id = :floorId AND poiGroup.id = :groupId" +
                        ")")
        List<Device> findAllViaPoiByTypeIdAndFloorId(@Param("groupId") Long groupId, @Param("floorId") Long floorId);

        @Query("SELECT device FROM Device device WHERE device.poiName IN (" +
                        "   SELECT poi.name FROM Poi poi " +
                        "   JOIN poi.spaceType spaceType " +
                        "   JOIN spaceType.poiGroup poiGroup " +
                        "   JOIN poi.floor floor " +
                        "   WHERE floor.id = :floorId" +
                        ")")
        List<Device> findAllViaPoiByFloorId(@Param("floorId") Long floorId);

        static final String BASE_QUERY_FIND_ALL = "SELECT device FROM Device device WHERE device.poiName IN ( " +
                        " SELECT poi.name FROM Poi poi INNER JOIN poi.spaceType spaceType " +
                        " INNER JOIN poi.floor floor INNER JOIN floor.building building ";

        @Query(BASE_QUERY_FIND_ALL
                        + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId) AND floor.id IN (:floorId))")
        List<Device> findAllViaPoiByTypeIdAndBuildingIdAndFloorId(
                        @Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId))")
        List<Device> findAllViaPoiByTypeIdAndBuildingId(
                        @Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND floor.id IN (:floorId))")
        List<Device> findAllViaPoiByBuildingIdAndFloorId(@Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId))")
        List<Device> findAllViaPoiByBuildingId(@Param("buildingId") List<Long> buildingId);

        @Query(value = "SELECT country.title_en AS country, city.title_en AS city, site.title_en AS site, building.title_en AS building, "
                        +
                        "poi.title_en AS poi, poi.name, attributes.conf_room_mail, attributes.capacity, device.uuid, deviceattributes.ip,  deviceattributes.app_version, device.status, "
                        +
                        "attributes.bookable, attributes.checkIn, attributes.checkInDuration," +
                        "COALESCE(attributes.earlyCheckIn, 5) AS earlyCheckIn," +
                        "attributes.checkOut, attributes.showState, attributes.showTemp, attributes.showHumidity, " +
                        "attributes.showSound, attributes.showCo2, attributes.showLux, attributes.reportAnIssue " +
                        "FROM poi " +
                        "INNER JOIN device ON (poi.name = device.poi_name) " +
                        "INNER JOIN floor on (floor.id = poi.floor_id) " +
                        "INNER JOIN building on (building.id = floor.building_id) " +
                        "INNER JOIN site on (site.id = building.site_id) " +
                        "INNER JOIN city on (city.id = site.city_id) " +
                        "INNER JOIN country on (country.id = city.country_id) " +
                        "LEFT JOIN ( SELECT * FROM ( SELECT poi_id, att_key, att_value FROM poi_attributes ) AS attributes_source "
                        +
                        "PIVOT ( MAX(att_value) FOR att_key IN (bookable, checkIn, checkInDuration,earlyCheckIn, checkOut, conf_room_mail, showState, "
                        +
                        "capacity, showTemp, showHumidity, showSound, showCo2, showLux, reportAnIssue) ) AS result_attributes ) AS attributes "
                        +
                        "ON (attributes.poi_id = poi.id) " +
                        "LEFT JOIN ( SELECT * FROM ( SELECT device_uuid, att_key, att_value FROM device_attributes ) AS device_attributes_source "
                        +
                        "PIVOT ( MAX(att_value) FOR att_key IN (ip, app_version) ) AS device_result_attributes ) AS deviceattributes "
                        +
                        "ON (deviceattributes.device_uuid = device.uuid) " +
                        "WHERE device.device_type = 'TABLET'", nativeQuery = true)
        public List<List<String>> findExport();

        // ordey by poiName
        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByPoiNameAsc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByPoiNameDesc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        // ordey by uuid
        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByUuidAsc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByUuidDesc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        // order by lastChange
        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByLastChangeAsc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByLastChangeDesc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        // order by status
        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByStatusAsc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByStatusDesc(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        // without order by
        public Page<Device> findAllByFloorBuildingIdAndDeviceTypeInAndStatusIn(
                        Long buildingId,
                        List<EnumDeviceType> deviceType,
                        List<EnumDeviceStatus> status,
                        Pageable paging);

        @Query(value = "SELECT DISTINCT country.title_en AS country, city.title_en AS city, site.title_en AS site, " +
                        "building.title_en AS building, poi.name, poi.title_en AS poi, attributes.conf_room_mail, " +
                        "CASE WHEN access.access_status = 1 THEN 'Yes' " +
                        "     WHEN access.access_status = 0 THEN 'No' " +
                        "     ELSE 'EmailNotAvailable' " +
                        "END AS graph_api_access, " +
                        "attributes.capacity " +
                        "FROM poi " +
                        "INNER JOIN floor ON (floor.id = poi.floor_id) " +
                        "INNER JOIN building ON (building.id = floor.building_id) " +
                        "INNER JOIN site ON (site.id = building.site_id) " +
                        "INNER JOIN city ON (city.id = site.city_id) " +
                        "INNER JOIN country ON (country.id = city.country_id) " +
                        "INNER JOIN ( " +
                        "    SELECT * FROM ( SELECT poi_id, att_key, att_value " +
                        "    FROM poi_attributes WHERE att_key IN ('conf_room_mail', 'capacity') ) AS attributes_source "
                        +
                        "    PIVOT ( MAX(att_value) FOR att_key IN (conf_room_mail, capacity)) AS result_attributes " +
                        ") AS attributes ON (attributes.poi_id = poi.id) " +
                        "LEFT JOIN graph_api_access_cache access ON access.room_email = attributes.conf_room_mail", nativeQuery = true)
        List<List<String>> findEmailExport();

        @Modifying
        @Transactional
        @Query(value = "UPDATE device SET status = :newStatus, last_status_change = :currentTime " +
                        "WHERE status = :currentStatus " +
                        "AND last_change <= :oneDayPrior", nativeQuery = true)
        int updateDeviceStatuses(
                        @Param("currentStatus") String currentStatus,
                        @Param("newStatus") String newStatus,
                        @Param("oneDayPrior") long oneDayPrior,
                        @Param("currentTime") long currentTime);

        @Modifying
        @Transactional
        @Query(value = "UPDATE device SET status = :newStatus, last_status_change = :currentTime " +
                        "WHERE status = :currentStatus " +
                        "AND last_change <= :oneHourPrior " +
                        "AND device_type = :deviceType", nativeQuery = true)
        int updateDeviceStatusesByType(
                        @Param("currentStatus") String currentStatus,
                        @Param("newStatus") String newStatus,
                        @Param("oneHourPrior") long oneHourPrior,
                        @Param("currentTime") long currentTime,
                        @Param("deviceType") String deviceType);

        @Query(value = "SELECT * FROM device d WHERE d.poi_name NOT IN (SELECT p.name FROM poi p)", nativeQuery = true)
        List<Device> findDevicesWithNonExistentPoi();

        @Query(value = "SELECT d.* FROM device d " +
                        "JOIN device_attributes da ON d.uuid = da.device_uuid " +
                        "WHERE d.poi_name IN (:poiNames) " +
                        "AND da.att_key IN ('co2', 'tempC') " +
                        "AND d.last_change >= DATEDIFF(SECOND, '1970-01-01', GETDATE()) - 7200", // Adjust for Unix
                                                                                                 // timestamp
                        nativeQuery = true)
        List<Device> findDevicesByPoiNames(@Param("poiNames") List<String> poiNames);

        @Query(value = "SELECT b.title_en " +
                        "FROM device d " +
                        "INNER JOIN poi p ON p.name = d.poi_name " +
                        "INNER JOIN floor f ON p.floor_id = f.id " +
                        "INNER JOIN building b ON f.building_id = b.id " +
                        "WHERE d.uuid = :uuid", nativeQuery = true)
        String findBuildingTitleByDeviceUuid(@Param("uuid") String uuid);

        @Query(value = "SELECT DISTINCT att_value FROM poi_attributes WHERE att_key = 'conf_room_mail'", nativeQuery = true)
        List<String> findDistinctRoomEmails();

        @Query("SELECT new com.capgemini.admin.back.model.DeviceSpaceTypeDTO( " +
                        "d.uuid, d.deviceType, d.lastChange, d.poiName, d.status, " +
                        "d.floor.id, d.lastStatusChange, p.id) " +
                        "FROM Device d " +
                        "LEFT JOIN Poi p ON d.poiName = p.name " +
                        "WHERE d.floor.id = :floorId")
        List<DeviceSpaceTypeDTO> findDevicesByFloorId(@Param("floorId") Long floorId);

        @Query("SELECT new com.capgemini.admin.back.model.DeviceSpaceTypeDTO( " +
                        "d.uuid, d.deviceType, d.lastChange, d.poiName, d.status, " +
                        "d.floor.id, d.lastStatusChange, p.id) " +
                        "FROM Device d " +
                        "JOIN Poi p ON d.poiName = p.name " +
                        "WHERE p.floor.id = :floorId " +
                        "AND p.spaceType.id IN (:spaceTypeIds)")
        List<DeviceSpaceTypeDTO> findDevicesBySpaceTypeAndFloorId(
                        @Param("spaceTypeIds") List<Long> spaceTypeIds,
                        @Param("floorId") Long floorId);
       
        @Modifying
        @Transactional
        @Query(value = "UPDATE device SET under_maintenance = :underMaintenance WHERE uuid = :uuid", 
               nativeQuery = true)
        int updateUnderMaintenance(
                @Param("uuid") String uuid,
                @Param("underMaintenance") boolean underMaintenance
        );
                

}
