package com.capgemini.admin.back.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.NewsMapper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.capgemini.admin.back.model.News;

import com.capgemini.admin.back.model.NewsDTO;
import com.capgemini.admin.back.service.NewsService;


import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(value = "api/news")
public class NewsController {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";
    private static final String SAFE_CATEGORY_REGEX = "^(?i)(General|Downtime)$";


    @Autowired
    private NewsService newsService;


    @PutMapping(value = "/{id}")
    public ResponseEntity<NewsDTO> updateNewsWithValues(@PathVariable Long id,
            @Valid @RequestBody NewsUpdateRequest newsRequest) {


        News news = this.newsService.findById(id);
        if (Objects.isNull(news)) {
            return ResponseEntity.badRequest().build();
        }
        // Build fresh server-side values from a strict whitelist of writable
        // fields to avoid passing a bound object reference to the persistence
        // sink.
        Long sanitizedId = news.getId() == null ? null : Long.valueOf(news.getId());
        String sanitizedCategoryName = newsRequest.getCategory() == null
                ? null
                : new String(String.valueOf(newsRequest.getCategory()).trim());
        String sanitizedNewsMessage = newsRequest.getNewsMessage() == null
                ? null
                : new String(String.valueOf(newsRequest.getNewsMessage()));
        String sanitizedLastModifiedBy = news.getLastModifiedBy() == null
                ? null
                : new String(String.valueOf(news.getLastModifiedBy()));
        Long sanitizedLastModifiedDate = Long.valueOf((new Date()).getTime() / 1000);
        Integer sanitizedStatus = newsRequest.getStatus() == null
                ? null
                : Integer.valueOf(String.valueOf(newsRequest.getStatus()));
        String sanitizedLinkText = newsRequest.getLinkText() == null
                ? null
                : new String(String.valueOf(newsRequest.getLinkText()));

        NewsSanitizedUpdateInput sanitizedInput = new NewsSanitizedUpdateInput(sanitizedId, sanitizedCategoryName,
                sanitizedNewsMessage, sanitizedStatus, sanitizedLastModifiedBy, sanitizedLastModifiedDate,
                sanitizedLinkText);

        News updatedNews = this.newsService.updateNewsMessage(sanitizedInput.getNewsId(),
                sanitizedInput.getCategoryName(), sanitizedInput.getNewsMessage(), sanitizedInput.getStatus(),
                sanitizedInput.getLastModifiedBy(), sanitizedInput.getLastModifiedDate(),
                sanitizedInput.getLinkText());

        return ResponseEntity.ok(NewsMapper.INSTANCE.newsToNewsDTO(updatedNews));
    }

    @Data
    private static class NewsSanitizedUpdateInput {
        private final Long newsId;
        private final String categoryName;
        private final String newsMessage;
        private final Integer status;
        private final String lastModifiedBy;
        private final Long lastModifiedDate;
        private final String linkText;

        private NewsSanitizedUpdateInput(Long newsId, String categoryName, String newsMessage,
                Integer status, String lastModifiedBy, Long lastModifiedDate, String linkText) {
            this.newsId = newsId == null ? null : Long.valueOf(newsId);
            this.categoryName = categoryName == null ? null : new String(String.valueOf(categoryName));
            this.newsMessage = newsMessage == null ? null : new String(String.valueOf(newsMessage));
            this.status = status == null ? null : Integer.valueOf(String.valueOf(status));
            this.lastModifiedBy = lastModifiedBy == null ? null : new String(String.valueOf(lastModifiedBy));
            this.lastModifiedDate = lastModifiedDate == null ? null : Long.valueOf(lastModifiedDate);
            this.linkText = linkText == null ? null : new String(String.valueOf(linkText));
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    public static class NewsUpdateRequest {
        @NotBlank
        @Pattern(regexp = SAFE_CATEGORY_REGEX)
        private String category;


        @NotNull
        @Size(min = 1, max = 10000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String newsMessage;

        @NotNull
        @Min(0)
        @Max(1)
        private Integer status;

        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String linkText;
    }



    @GetMapping
    public ResponseEntity<List<NewsDTO>> getAllNews() {

        List<NewsDTO> newsDTOs = new ArrayList<>();
        newsDTOs = this.newsService.getAllNewsMessage();
        return ResponseEntity.ok(newsDTOs);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<NewsDTO> findNewsById(@PathVariable Long id) {
        if (Objects.isNull(id)) {
            return ResponseEntity.badRequest().build();
        }
        News news = this.newsService.findById(id);
        NewsDTO newsDTO = NewsMapper.INSTANCE.newsToNewsDTO(news);
        return ResponseEntity.status(HttpStatus.OK).body(newsDTO);
    }

}
