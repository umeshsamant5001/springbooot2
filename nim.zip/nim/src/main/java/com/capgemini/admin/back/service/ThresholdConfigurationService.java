package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.ThresholdConfigurationMapper;
import com.capgemini.admin.back.model.Alert;
import com.capgemini.admin.back.model.Threshold;
import com.capgemini.admin.back.model.ThresholdConfiguration;
import com.capgemini.admin.back.model.ThresholdConfigurationDTO;
import com.capgemini.admin.back.repository.ThresholdConfigurationRepository;

@Service
public class ThresholdConfigurationService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    private static final Logger log = LoggerFactory.getLogger(ThresholdConfigurationService.class);

    @Autowired
    private ThresholdConfigurationRepository thresholdConfigurationRepository;



    /**
     * Retrieves a ThresholdConfiguration by its ID.
     *
     * @param thresholdConfigurationId The ID of the ThresholdConfiguration.
     * @return The ThresholdConfiguration entity.
     * @throws ResourceNotFoundException if no configuration is found with the given ID.
     */
    public ThresholdConfiguration findById(Long thresholdConfigurationId) {
        try {
            ThresholdConfiguration existingThresholdConfiguration = thresholdConfigurationRepository
                    .findById(thresholdConfigurationId)
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "ThresholdConfiguration not found with existingThresholdConfiguration ID :: "
                                    + thresholdConfigurationId));
            return existingThresholdConfiguration;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve threshold configuration for id {}", thresholdConfigurationId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve threshold configuration.");
        }
    }


    public ThresholdConfiguration findByIdAndCountryIdIn(Long thresholdConfigurationId, List<Long> countryIds) {
        if (thresholdConfigurationId == null || thresholdConfigurationId <= 0 || countryIds == null || countryIds.isEmpty()) {
            return null;
        }

        Long scopedThresholdConfigurationId = Long.valueOf(thresholdConfigurationId);
        Optional<ThresholdConfiguration> existingThresholdConfiguration = thresholdConfigurationRepository
                .findByIdAndCountryIdIn(scopedThresholdConfigurationId, countryIds);
        return existingThresholdConfiguration.orElse(null);
    }


    /**
     * Updates a ThresholdConfiguration along with its associated thresholds and alerts.
     * Ensures that each threshold and alert is linked back to the parent configuration.
     *
     * @param thresholdConfiguration The updated ThresholdConfiguration entity.
     * @return The saved ThresholdConfiguration entity.
     */
    @Transactional
    public ThresholdConfiguration updateThresholdConfiguration(ThresholdConfiguration thresholdConfiguration) {

        if (thresholdConfiguration == null) {
            throw new IllegalArgumentException("ThresholdConfiguration must not be null");
        }

        ThresholdConfiguration sanitizedConfiguration = new ThresholdConfiguration();
        sanitizedConfiguration.setId(thresholdConfiguration.getId() == null ? null : Long.valueOf(thresholdConfiguration.getId()));
        sanitizedConfiguration.setCountryId(thresholdConfiguration.getCountryId() == null
                ? null
                : Long.valueOf(thresholdConfiguration.getCountryId()));
        sanitizedConfiguration.setSpaceTypeId(thresholdConfiguration.getSpaceTypeId() == null
                ? null
                : Long.valueOf(thresholdConfiguration.getSpaceTypeId()));
        sanitizedConfiguration.setTemperatureUnit(thresholdConfiguration.getTemperatureUnit() == null
                ? null
                : com.capgemini.admin.back.model.TemperatureUnit
                        .valueOf(String.valueOf(thresholdConfiguration.getTemperatureUnit().name())));
        sanitizedConfiguration.setModifiedAt(thresholdConfiguration.getModifiedAt() == null
                ? null
                : Long.valueOf(thresholdConfiguration.getModifiedAt()));

        List<Threshold> sanitizedThresholds = sanitizeThresholds(thresholdConfiguration.getThresholds(), sanitizedConfiguration);
        sanitizedConfiguration.setThresholds(sanitizedThresholds);

        List<Alert> sanitizedAlerts = sanitizeAlerts(thresholdConfiguration.getAlerts(), sanitizedConfiguration);
        sanitizedConfiguration.setAlerts(sanitizedAlerts);

        return thresholdConfigurationRepository.save(sanitizedConfiguration);
    }


    /**
     * Deletes a given ThresholdConfiguration from the repository.
     *
     * @param thresholdConfiguration The ThresholdConfiguration entity to delete.
     */
    public void deleteThresholdConfiguration(ThresholdConfiguration thresholdConfiguration) {
        this.thresholdConfigurationRepository.delete(thresholdConfiguration);
    }

    /**
     * Retrieves all ThresholdConfiguration records associated with a specific country ID
     * and maps them to DTOs.
     *
     * @param countryId The ID of the country.
     * @return A list of ThresholdConfigurationDTOs.
     */
    public List<ThresholdConfigurationDTO> getThresholdConfigurationByCountryId(Long countryId) {
        List<ThresholdConfiguration> thresholdConfigurations = this.thresholdConfigurationRepository
                .getThresholdConfigurationByCountryId(countryId);
        List<ThresholdConfigurationDTO> thresholdConfigurationDTOs = thresholdConfigurations
                .stream()
                .map(thresholdConfig -> ThresholdConfigurationMapper.INSTANCE
                        .thresholdConfigurationToThresholdConfigurationDTO(thresholdConfig))
                .collect(Collectors.toList());
        return thresholdConfigurationDTOs;
    }

    /**
     * Retrieves all ThresholdConfiguration records and maps them to DTOs.
     *
     * @return A list of all ThresholdConfigurationDTOs.
     */
    public List<ThresholdConfigurationDTO> getAllThresholdConfiguration() {

        List<ThresholdConfiguration> thresholdConfigurations = this.thresholdConfigurationRepository
                .getAllThresholdConfiguration();

        List<ThresholdConfigurationDTO> thresholdConfigurationDTOs = thresholdConfigurations
                .stream()
                .map(thresholdConfig -> ThresholdConfigurationMapper.INSTANCE
                        .thresholdConfigurationToThresholdConfigurationDTO(thresholdConfig))
                .collect(Collectors.toList());
        return thresholdConfigurationDTOs;

    }

    /**
     * Retrieves all ThresholdConfiguration records that have at least one enabled alert.
     *
     * @return A list of ThresholdConfiguration entities with enabled alerts.
     */
    public List<ThresholdConfiguration> getAllThresholdConfigurationsEnabled() {
        try {
            return thresholdConfigurationRepository.findAllWithEnabledAlerts();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve threshold configurations with enabled alerts", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve threshold configurations.");
        }
    }


    private List<Threshold> sanitizeThresholds(List<Threshold> thresholds, ThresholdConfiguration parentConfiguration) {
        List<Threshold> sanitizedThresholds = new ArrayList<>();
        if (thresholds == null) {
            return sanitizedThresholds;
        }

        for (Threshold threshold : thresholds) {
            if (threshold == null) {
                continue;
            }

            Threshold sanitizedThreshold = new Threshold();
            sanitizedThreshold.setId(threshold.getId() == null ? null : Long.valueOf(threshold.getId()));
            sanitizedThreshold.setType(threshold.getType() == null
                    ? null
                    : com.capgemini.admin.back.model.ThresholdType.valueOf(String.valueOf(threshold.getType().name())));
            sanitizedThreshold.setLevel(threshold.getLevel() == null
                    ? null
                    : com.capgemini.admin.back.model.ThresholdLevel.valueOf(String.valueOf(threshold.getLevel().name())));
            sanitizedThreshold.setValue(sanitizeOptionalText(threshold.getValue(), 255, "threshold value"));
            sanitizedThreshold.setUnit(sanitizeOptionalText(threshold.getUnit(), 255, "threshold unit"));
            sanitizedThreshold.setThresholdConfiguration(parentConfiguration);
            sanitizedThresholds.add(sanitizedThreshold);
        }

        return sanitizedThresholds;
    }

    private List<Alert> sanitizeAlerts(List<Alert> alerts, ThresholdConfiguration parentConfiguration) {
        List<Alert> sanitizedAlerts = new ArrayList<>();
        if (alerts == null) {
            return sanitizedAlerts;
        }

        for (Alert alert : alerts) {
            if (alert == null) {
                continue;
            }

            Alert sanitizedAlert = new Alert();
            sanitizedAlert.setId(alert.getId() == null ? null : Long.valueOf(alert.getId()));
            sanitizedAlert.setInterval(alert.getInterval() == null ? null : Integer.valueOf(alert.getInterval()));
            sanitizedAlert.setAlertType(alert.getAlertType() == null
                    ? null
                    : com.capgemini.admin.back.model.AlertType.valueOf(String.valueOf(alert.getAlertType().name())));
            sanitizedAlert.setEnabled(alert.getEnabled() == null ? null : Boolean.valueOf(String.valueOf(alert.getEnabled())));
            sanitizedAlert.setThresholdConfiguration(parentConfiguration);
            sanitizedAlerts.add(sanitizedAlert);
        }

        return sanitizedAlerts;
    }

    private String sanitizeOptionalText(String value, int maxLength, String fieldName) {
        if (value == null) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            return null;
        }

        if (validated.length() > maxLength || !Pattern.matches(SAFE_TEXT_REGEX, validated)) {
            throw new IllegalArgumentException("Invalid " + fieldName + ".");
        }

        return new String(validated);
    }

}
