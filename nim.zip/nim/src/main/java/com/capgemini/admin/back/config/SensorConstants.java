package com.capgemini.admin.back.config;

public class SensorConstants {
    public static final int MILLIS_IN_SECOND = 1000;
    public static final String FREE_STATE = "free";
    public static final String BUSY_STATE = "busy";
    public static final String DEFAULT_STATE = "unknown";
    public static final Integer DESK_LOCKING_TIME_MINUTES = 60;
    public static final String HEADER_UUID = "Uuid";
    public static final String HEADER_DEVICE_TYPE = "DeviceType";
    public static final String HEADER_POI_NAME = "PoiName";
    public static final String HEADER_FLOOR_CDM_KEY_ID = "FloorCdmKeyId";
    public static final int IDX_UUID = 0;
    public static final int IDX_DEVICE_TYPE = 1;
    public static final int IDX_POI_NAME = 2;
    public static final int IDX_FLOOR_CDM_KEY_ID = 3;
    public static final int SENSOR_APP_COLUMN_COUNT = 4;

    // Safety bounds for CSV import to prevent unbounded loops on attacker-controlled input.
    public static final int CSV_MAX_LINES = 100_000;
    public static final int CSV_MAX_LINE_LENGTH = 10_000;

}
