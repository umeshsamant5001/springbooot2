package com.capgemini.admin.back.service.procedure;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Objects;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.capgemini.admin.back.model.procedure.AppConfigValue;
import com.capgemini.admin.back.model.procedure.EntityDataDTO;
import com.capgemini.admin.back.model.procedure.EntityFieldIndexDTO;
import com.capgemini.admin.back.model.procedure.FrontLabel;
import com.capgemini.admin.back.model.procedure.LangAdminNode;



import com.capgemini.admin.back.model.procedure.LangUserNode;
import com.capgemini.admin.back.model.procedure.LogAuditTranslation;
import com.capgemini.admin.back.model.procedure.TranslatedEntityDTO;
import com.capgemini.admin.back.repository.procedure.AppConfigValueRepository;
import com.capgemini.admin.back.repository.procedure.EntityDataRepository;
import com.capgemini.admin.back.repository.procedure.EntityFieldIndexRepository;
import com.capgemini.admin.back.repository.procedure.FrontLabelRepository;
import com.capgemini.admin.back.repository.procedure.LangAdminNodeRepository;
import com.capgemini.admin.back.repository.procedure.LangUserNodeRepository;
import com.capgemini.admin.back.repository.procedure.LogAuditTranslationRepository;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nimbusds.oauth2.sdk.GeneralException;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@Service
public class ProcedureService {
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    public static class FrontLabelWriteInput {
        private final String keyId;
        private final String fieldKey;
        private final String languageText;
        private final String languageCode;

        public FrontLabelWriteInput(String keyId, String fieldKey, String languageText, String languageCode) {
            this.keyId = keyId == null ? null : new String(String.valueOf(keyId));
            this.fieldKey = fieldKey == null ? null : new String(String.valueOf(fieldKey));
            this.languageText = languageText == null ? null : new String(String.valueOf(languageText));
            this.languageCode = languageCode == null ? null : new String(String.valueOf(languageCode));
        }

        public String getKeyId() {
            return keyId == null ? null : new String(String.valueOf(keyId));
        }

        public String getFieldKey() {
            return fieldKey == null ? null : new String(String.valueOf(fieldKey));
        }

        public String getLanguageText() {
            return languageText == null ? null : new String(String.valueOf(languageText));
        }

        public String getLanguageCode() {
            return languageCode == null ? null : new String(String.valueOf(languageCode));
        }
    }

    private static final class SafeFrontLabelValues {



        private final String keyId;
        private final String fieldKey;
        private final String languageText;
        private final String languageCode;

        private SafeFrontLabelValues(String keyId, String fieldKey, String languageText, String languageCode) {
            this.keyId = keyId;
            this.fieldKey = fieldKey;
            this.languageText = languageText;
            this.languageCode = languageCode;
        }
    }


    @Autowired
    DataSource dataSource;


    @Autowired
    private FrontLabelRepository frontLabelRepository;

    @Autowired
    private LangAdminNodeRepository langAdminNodeRepository;

    @Autowired
    private LangUserNodeRepository langUserNodeRepository;

    @Autowired
    private EntityDataRepository entityDataRepository;

    @Autowired
    private EntityFieldIndexRepository entityFieldIndexRepository;

    @Autowired
    private AppConfigValueRepository appConfigValueRepository;

    @Autowired
    private LogAuditTranslationRepository logAuditTranslationRepository;

    @Transactional(readOnly = true)
    public List<FrontLabel> getMobileDataByLanguageCode(String languageCode) {
        return this.frontLabelRepository.getLanguagetextByCode(languageCode);
    }

    @Transactional(readOnly = true)
    public List<LangAdminNode> getLangAdminNode() {
        return this.langAdminNodeRepository.getLangAdminNodeMapping();
    }

    @Transactional(readOnly = true)
    public List<LangUserNode> getLangUserNode() {
        return this.langUserNodeRepository.getLangUserNodeMapping();
    }

    @Transactional(readOnly = true)
    public List<EntityDataDTO> getEntityData(String entityName) {
        return this.entityDataRepository.getEntityData(entityName);
    }

    @Transactional(readOnly = true)
    public List<EntityFieldIndexDTO> getEntityByEntity(String entity) {
        return this.entityFieldIndexRepository.getEntityMappingByEntity(entity);
    }

    @Transactional(readOnly = true)
    public List<String> getTranslationEntity() {
        return this.entityFieldIndexRepository.getTranslationEntity();
    }

    @Transactional(readOnly = true)
    public AppConfigValue getAppConfigByConfigkey(String configKey) {
        return this.appConfigValueRepository.getAppConfigByConfigkey(configKey);
    }

    @Transactional
    public void saveMobileData(List<FrontLabelWriteInput> frontLabelWriteInputs) {
        try {
            validateMobileDataCollections(frontLabelWriteInputs);

            for (FrontLabelWriteInput frontLabelWriteInput : frontLabelWriteInputs) {
                SafeFrontLabelValues safeFrontLabelValues = sanitizeAndCopyValues(
                        frontLabelWriteInput.getKeyId(),
                        frontLabelWriteInput.getFieldKey(),
                        frontLabelWriteInput.getLanguageText(),
                        frontLabelWriteInput.getLanguageCode());
                Long safeModifiedAt = Long.valueOf((new Date()).getTime() / 1000);

                String persistedKeyId = safeFrontLabelValues.keyId == null
                        ? null
                        : new String(String.valueOf(safeFrontLabelValues.keyId));
                String persistedFieldKey = safeFrontLabelValues.fieldKey == null
                        ? null
                        : new String(String.valueOf(safeFrontLabelValues.fieldKey));
                String persistedLanguageText = safeFrontLabelValues.languageText == null
                        ? null
                        : new String(String.valueOf(safeFrontLabelValues.languageText));
                String persistedLanguageCode = safeFrontLabelValues.languageCode == null
                        ? null
                        : new String(String.valueOf(safeFrontLabelValues.languageCode));
                Long persistedModifiedAt = safeModifiedAt == null
                        ? null
                        : Long.valueOf(String.valueOf(safeModifiedAt));

                this.frontLabelRepository.insertMobileMultilangField(
                        persistedKeyId,
                        persistedFieldKey,
                        persistedLanguageText,
                        persistedLanguageCode,
                        persistedModifiedAt);
            }

        } catch (IllegalArgumentException ex) {
            log.warn("Invalid mobile data payload in saveMobileData", ex);
            throw new IllegalArgumentException("Invalid mobile data payload.");
        } catch (DataAccessException ex) {
            log.error("Database error in saveMobileData", ex);
            throw new IllegalStateException("Unable to persist mobile data.");
        }
    }

    private void validateMobileDataCollections(List<FrontLabelWriteInput> frontLabelWriteInputs) {
        if (Objects.isNull(frontLabelWriteInputs)) {
            throw new IllegalArgumentException("mobile data collections must not be null");
        }

        for (FrontLabelWriteInput frontLabelWriteInput : frontLabelWriteInputs) {
            if (Objects.isNull(frontLabelWriteInput)) {
                throw new IllegalArgumentException("mobile data collection entry must not be null");
            }
        }
    }



    private SafeFrontLabelValues sanitizeAndCopyValues(
            String keyId,
            String fieldKey,
            String languageText,
            String languageCode) {

        String validatedKeyId = new String(validateAndCopyText(
                keyId == null ? null : new String(String.valueOf(keyId)),
                1,
                255,
                "keyId"));
        String validatedFieldKey = new String(validateAndCopyText(
                fieldKey == null ? null : new String(String.valueOf(fieldKey)),
                1,
                255,
                "fieldKey"));
        String validatedLanguageText = new String(validateAndCopyText(
                languageText == null ? null : new String(String.valueOf(languageText)),
                1,
                4000,
                "languageText"));
        String validatedLanguageCode = new String(validateAndCopyText(
                languageCode == null ? null : new String(String.valueOf(languageCode)),
                2,
                16,
                "languageCode"));

        return new SafeFrontLabelValues(
                new String(String.valueOf(validatedKeyId)),
                new String(String.valueOf(validatedFieldKey)),
                new String(String.valueOf(validatedLanguageText)),
                new String(String.valueOf(validatedLanguageCode)));
    }




    private String validateAndCopyText(String value, int minLength, int maxLength, String fieldName) {

        if (value == null) {
            throw new IllegalArgumentException(fieldName + " must not be null");
        }

        String trimmedValue = value.trim();
        if (trimmedValue.length() < minLength || trimmedValue.length() > maxLength) {
            throw new IllegalArgumentException(fieldName + " length is invalid");
        }

        if (!trimmedValue.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException(fieldName + " contains invalid characters");
        }

        return new String(trimmedValue);
    }


    @Transactional
    public void saveLogAudit(LogAuditTranslation logAuditTranslation) {
        this.logAuditTranslationRepository.insertExceptionlog_translationservice(logAuditTranslation.getDescription(),
                logAuditTranslation.getStatus(),
                logAuditTranslation.getCreatedDate(),
                logAuditTranslation.getTranslationServiceType(),
                logAuditTranslation.getException());
    }

    @Transactional
    public void saveEntityData(List<TranslatedEntityDTO> entities, String entityName, String languageCode)
            throws GeneralException {
        try {
            SQLServerDataTable dataTable = new SQLServerDataTable();

            dataTable.addColumnMetadata("id", Types.INTEGER);
            dataTable.addColumnMetadata("title_en", Types.VARCHAR);
            dataTable.addColumnMetadata("title", Types.VARCHAR);

            for (TranslatedEntityDTO entity : entities) {
                dataTable.addRow(entity.getId(), entity.getTitleEn(), entity.getTitle());
            }

            try (Connection connection = this.dataSource.getConnection();
                 PreparedStatement statement = connection.prepareStatement("{call dbo.Insert_translated_entitydata(?,?,?)}")) {
                SQLServerPreparedStatement sqlServerStatement = statement.unwrap(SQLServerPreparedStatement.class);
                sqlServerStatement.setStructured(1, "tbl_translated_entities", dataTable);
                sqlServerStatement.setString(2, entityName);
                sqlServerStatement.setString(3, languageCode);

                sqlServerStatement.execute();
            }
        } catch (SQLException e) {
            log.error("Error while executing the procedure Insert_translated_entitydata", e);
            throw new GeneralException("Error while executing the procedure Insert_translated_entitydata");
        }
    }
}