package com.capgemini.admin.back.service;

import com.capgemini.admin.back.repository.UserCleanupRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserDeletionService {

    private final UserCleanupRepository cleanupRepo;

    /**
     * Deletes a user and all related records by email.
     * All operations execute in a single transaction.
     * @param email User email Id
     */
    @Transactional
    public void deleteAdminUserCompletely(String email) {
        String safeEmailForLog = sanitizeForLog(email);
        log.info("Starting deleteUserCompletely for email={}", safeEmailForLog);

        // Preference children
        int deleteFromVisitedBuildings = cleanupRepo.deleteFromVisitedBuildingsByEmail(email);
        int deleteFromPrefService      = cleanupRepo.deleteFromPreferenceServiceByEmail(email);
        int deleteFromPrefLanguage     = cleanupRepo.deleteFromPreferenceLanguageByEmail(email);

        // Preference parent
        int deleteFromPreference       = cleanupRepo.deleteFromPreferenceByEmail(email);

        // User children
        int deleteFromUserRoleLocation = cleanupRepo.deleteFromUserRoleLocationByEmail(email);
        int deleteFromServiceUser      = cleanupRepo.deleteFromServiceUserByEmail(email);
        int deleteFromUserProfile      = cleanupRepo.deleteFromUserProfileByEmail(email);

        int deleteFromUserBuildingMapping = cleanupRepo.deleteFromUserBuildingMapping(email);
        int deleteFromUserRoles      = cleanupRepo.deleteFromUserRoles(email);
        int deleteFromUserSecuredBuilding      = cleanupRepo.deleteFromUserSecuredBuilding(email);
      
        //Users parent
        int deleteFromUsers            = cleanupRepo.deleteFromUserByEmail(email);

        log.info("Deletion done for email={}. Summary: deleteFromVisitedBuildings={}, "+
        "deleteFromPrefService={}, deleteFromPrefLanguage={}, deleteFromPreference={}, "+
        "deleteFromUserRoleLocation={}, deleteFromUserviceUser={}, deleteFromUserProfile={}, "+
        "deleteFromUserBuildingMapping={},deleteFromUserRoles={}, deleteFromUserSecuredBuilding={}, "+
        "deleteFromUsers={}",
         safeEmailForLog, deleteFromVisitedBuildings, deleteFromPrefService, deleteFromPrefLanguage, 
         deleteFromPreference, deleteFromUserRoleLocation, deleteFromServiceUser, 
         deleteFromUserProfile, deleteFromUserBuildingMapping,deleteFromUserRoles,
         deleteFromUserSecuredBuilding,deleteFromUsers);
        
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }
}
