package com.capgemini.admin.utils;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class EnvironmentService {

	private static final String PROFILE_LOCAL = "local";
	private static final String PROFILE_DEV = "dev";
	private static final String PROFILE_PREPROD = "preprod";
	private static final String PROFILE_PROD = "prod";

	@Autowired
	private Environment environment;

	public boolean isLocal() {
		return Arrays.stream(environment.getActiveProfiles()).anyMatch(PROFILE_LOCAL::equals);
	}

	public boolean isDev() {
		return Arrays.stream(environment.getActiveProfiles()).anyMatch(PROFILE_DEV::equals);
	}

	public boolean isPreprod() {
		return Arrays.stream(environment.getActiveProfiles()).anyMatch(PROFILE_PREPROD::equals);
	}

	public boolean isProd() {
		return Arrays.stream(environment.getActiveProfiles()).anyMatch(PROFILE_PROD::equals);
	}
}
