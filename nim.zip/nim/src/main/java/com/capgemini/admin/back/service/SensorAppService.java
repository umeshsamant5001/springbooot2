package com.capgemini.admin.back.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.EnumDeviceType;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.SensorAppImportDTO;
import com.capgemini.admin.back.model.SensorAppImport;
import com.capgemini.admin.back.repository.FloorRepository;
import com.capgemini.admin.back.repository.SensorAppRepository;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.admin.back.config.SensorConstants;

@Slf4j
@Service
public class SensorAppService {

    @Autowired
    private SensorAppRepository sensorAppRepository;

    @Autowired
    private FloorRepository floorRepository;

    /**
     * Checks the format of the CSV file and returns any structural errors found.
     * 
     * @param file The CSV file to be checked
     * @return A list of structural errors found during the check
     */
    public List<String> checkCSVFormat(MultipartFile file) {
        List<String> structuralErrors = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while (lineNumber < SensorConstants.CSV_MAX_LINES) {
                line = br.readLine();
                if (Objects.isNull(line)) {
                    break;
                }
                lineNumber++;


                // Bound the length of a single line to prevent excessive processing.
                if (line.length() > SensorConstants.CSV_MAX_LINE_LENGTH) {
                    structuralErrors.add(String.format(
                            "Line %s: exceeds the maximum allowed length of %s characters.",
                            lineNumber, SensorConstants.CSV_MAX_LINE_LENGTH));
                    return structuralErrors;
                }
                line = line.trim();
                // Strip trailing commas in a single bounded operation (no input-driven loop).
                line = StringUtils.stripEnd(line, ",");
                String[] infos = line.split(",");
                // Check if it's the header line and verify its format
                if (lineNumber == 1) {
                    if (checkHeader(infos)) {
                        continue;
                    } else {
                        structuralErrors.add("Incorrect header format. Please use the correct headers.");
                        return structuralErrors;
                    }
                }
                int length = infos.length;
                // Check the number of variables in each line
                if (length != SensorConstants.SENSOR_APP_COLUMN_COUNT) {
                    structuralErrors.add(
                            String.format(
                                    "Line %s: must contain %s variables - this line contains %s variables",
                                    lineNumber,
                                    SensorConstants.SENSOR_APP_COLUMN_COUNT,
                                    length));
                }
            }

            if (lineNumber == SensorConstants.CSV_MAX_LINES && Objects.nonNull(br.readLine())) {
                structuralErrors.add(String.format(
                        "The file exceeds the maximum allowed number of lines (%s).",
                        SensorConstants.CSV_MAX_LINES));
                return structuralErrors;
            }

            if (lineNumber == 0) {

                structuralErrors.add("The file is empty.");
            } else if (lineNumber == 1) {
                structuralErrors.add("No data present in the file.");
            }
        } catch (IOException e) {
            structuralErrors.add("Error while reading the file: " + e.getMessage() + ".");
        }
        return structuralErrors;
    }

    /**
     * Checks if the provided line matches the expected header format.
     * 
     * @param line The line to be checked
     * @return true if the line matches the expected header format, false otherwise
     */
    private boolean checkHeader(String[] line) {
        return (line.length == SensorConstants.SENSOR_APP_COLUMN_COUNT &&
                SensorConstants.HEADER_UUID.equalsIgnoreCase(line[SensorConstants.IDX_UUID]) &&
                SensorConstants.HEADER_DEVICE_TYPE.equalsIgnoreCase(line[SensorConstants.IDX_DEVICE_TYPE]) &&
                SensorConstants.HEADER_POI_NAME.equalsIgnoreCase(line[SensorConstants.IDX_POI_NAME]) &&
                SensorConstants.HEADER_FLOOR_CDM_KEY_ID.equalsIgnoreCase(line[SensorConstants.IDX_FLOOR_CDM_KEY_ID]));
    }

    /**
     * Generates a SensorAppImportDTOResponse from the provided CSV file, adding
     * SensorApp and errors as needed.
     * 
     * @param file The CSV file from which to generate the response DTO
     * @return The SensorAppImportDTOResponse containing the imported SensorApp and
     *         any errors encountered
     */
    public SensorAppImport generateSensorAppImportDTORequest(MultipartFile file) {
        SensorAppImport sensorAppImportDTOResponse = new SensorAppImport();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                // Bound the number of iterations to prevent attackers from supplying
                // an arbitrarily large file (unchecked input for loop condition).
                if (lineNumber > SensorConstants.CSV_MAX_LINES) {
                    sensorAppImportDTOResponse.addError(String.format(
                            "The file exceeds the maximum allowed number of lines (%s).",
                            SensorConstants.CSV_MAX_LINES));
                    break;
                }
                // Skip the header line
                if (lineNumber == 1) {
                    continue;
                }
                // Bound the length of a single line to prevent excessive processing.
                if (line.length() > SensorConstants.CSV_MAX_LINE_LENGTH) {
                    sensorAppImportDTOResponse.addError(String.format(
                            "Line %s: exceeds the maximum allowed length of %s characters.",
                            lineNumber, SensorConstants.CSV_MAX_LINE_LENGTH));
                    continue;
                }
                // Clean trailing commas in a single bounded operation (no input-driven loop).
                line = line.trim();
                line = StringUtils.stripEnd(line, ",");

                String[] sensorAppFromCsv = line.split(",");
                int length = sensorAppFromCsv.length;
                // Check the number of columns in each line
                if (length != SensorConstants.SENSOR_APP_COLUMN_COUNT) {
                    String error = String.format("Line %s: must contain %s columns - found %s", lineNumber,
                            SensorConstants.SENSOR_APP_COLUMN_COUNT, length);
                    sensorAppImportDTOResponse.addError(error);
                    continue; // Skip the rest of the processing for this line
                }

                if (Objects.isNull(sensorAppFromCsv[SensorConstants.IDX_UUID])
                        
                        || sensorAppFromCsv[SensorConstants.IDX_UUID].isEmpty()) {
                    sensorAppImportDTOResponse
                            .addError(String.format("Line %s: Uuid column shouldn't be empty.", lineNumber));
                }
                        
                if (Objects.isNull(sensorAppFromCsv[SensorConstants.IDX_DEVICE_TYPE])
                        || sensorAppFromCsv[SensorConstants.IDX_DEVICE_TYPE].isEmpty()) {
                    sensorAppImportDTOResponse
                            .addError(String.format("Line %s: DeviceType column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(sensorAppFromCsv[SensorConstants.IDX_POI_NAME])
                        || sensorAppFromCsv[SensorConstants.IDX_POI_NAME].isEmpty()) {
                    sensorAppImportDTOResponse
                            .addError(String.format("Line %s: PoiName column shouldn't be empty.", lineNumber));
                }

                if (Objects.isNull(sensorAppFromCsv[SensorConstants.IDX_FLOOR_CDM_KEY_ID])
                        || sensorAppFromCsv[SensorConstants.IDX_FLOOR_CDM_KEY_ID].isEmpty()) {
                    try {
                        Integer.parseInt(sensorAppFromCsv[SensorConstants.IDX_FLOOR_CDM_KEY_ID]);
                    } catch (NumberFormatException nfe) {
                        sensorAppImportDTOResponse.addError(
                                String.format("Line %s: FloorCdmKeyId column values should be an integer (or empty).",
                                        lineNumber));
                    }
                }

                if (Objects.isNull(sensorAppImportDTOResponse.getErrorsInFile())
                        || sensorAppImportDTOResponse.getErrorsInFile().isEmpty()) {
                    try {
                        // Create SensorAppImportDTO from the line
                        SensorAppImportDTO sensorAppImportDTO = createSensorAppImportDTO(sensorAppFromCsv);
                        sensorAppImportDTOResponse.addSensorApp(sensorAppImportDTO);
                    } catch (NumberFormatException e) {
                        String error = String.format("Line %s: Error while parsing information - %s", lineNumber,
                                e.getMessage());
                        sensorAppImportDTOResponse.addError(error);
                    } catch (Exception e) {
                        String error = String.format("Line %s: Error while importing sensorApp - %s", lineNumber,
                                e.getMessage());
                        sensorAppImportDTOResponse.addError(error);
                    }
                }
            }
        } catch (IOException e) {
            String error = "Error while reading the file: " + e.getMessage();
            sensorAppImportDTOResponse.addError(error);
        }
        return sensorAppImportDTOResponse;
    }

    /**
     * Creates a SensorAppImportDTO object from the provided CSV data.
     *
     * @param sensorAppFromCsv The array containing the CSV data for the Smart
     *                         office DB
     * @return The SensorAppImportDTO object created from the CSV data
     * @throws NumberFormatException if there is an error in number parsing
     */
    private SensorAppImportDTO createSensorAppImportDTO(String[] sensorAppFromCsv) throws NumberFormatException {
        SensorAppImportDTO sensorAppImportDTO = new SensorAppImportDTO();
        sensorAppImportDTO.setUuid(sensorAppFromCsv[SensorConstants.IDX_UUID]);
        // sensorAppImportDTO.setDeviceType(sensorAppFromCsv[IDX_DEVICE_TYPE]);
        sensorAppImportDTO.setDeviceType(EnumDeviceType.findByName(sensorAppFromCsv[SensorConstants.IDX_DEVICE_TYPE]));
        sensorAppImportDTO.setPoiName(sensorAppFromCsv[SensorConstants.IDX_POI_NAME]);
        sensorAppImportDTO.setFloorCdmKeyId(Long.valueOf(sensorAppFromCsv[SensorConstants.IDX_FLOOR_CDM_KEY_ID]));
        return sensorAppImportDTO;
    }

    public Device findByUuid(String uuid) {
        return sensorAppRepository.findByUuid(uuid);
    }

    /**
     * Updates the list of sensor devices based on the provided import data.
     * For each DTO, it finds the existing device by UUID and updates its data.
     * All updated devices are saved in bulk.
     *
     * @param sensorAppImportResponse The import data containing sensor device
     *                                updates.
     * @return The same import object after processing.
     */
    public SensorAppImport updateSensorAppList(SensorAppImport sensorAppImportResponse) {
        List<Device> updatedDeviceList = new ArrayList<>();
        for (SensorAppImportDTO sensorAppImportDTO : sensorAppImportResponse.getSensorAppImportDTOs()) {
            Device updatedDevice = new Device();
            String uuid = sensorAppImportDTO.getUuid();
            Device device = findByUuid(uuid);
            if (Objects.nonNull(device)) {
                updatedDevice = updateSensorData(sensorAppImportDTO, device);
            }
            updatedDeviceList.add(updatedDevice);
        }
        sensorAppRepository.saveAll(updatedDeviceList);
        return sensorAppImportResponse;
    }

    /**
     * Updates an existing device's data using values from the import DTO.
     * If the floor is found using the CDM key, it is also updated.
     *
     * @param sensorAppImportDTO The DTO containing new sensor data.
     * @param existingDevice     The existing device entity to update.
     * @return A new Device object with updated values.
     */
    public Device updateSensorData(SensorAppImportDTO sensorAppImportDTO, Device existingDevice) {
        Device device = new Device();
        if (Objects.nonNull(sensorAppImportDTO) && Objects.nonNull(existingDevice)) {
            device.setUuid(sensorAppImportDTO.getUuid());
            device.setDeviceType(sensorAppImportDTO.getDeviceType());
            device.setPoiName(sensorAppImportDTO.getPoiName());
            device.setLastChange(System.currentTimeMillis() / 1000);
            device.setStatus(existingDevice.getStatus());
            device.setLastStatusChange(existingDevice.getLastStatusChange());
            // device.setFloor(existingDevice.getFloor());
            Floor floor = floorRepository.findByCdmKeyId(sensorAppImportDTO.getFloorCdmKeyId());
            if (Objects.nonNull(floor)) {
                device.setFloor(floor);
            } else {
                log.warn("Floor not found for cdmKeyId: {}", sensorAppImportDTO.getFloorCdmKeyId());
            }
        }
        return device;
    }

}
