package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class ThresholdLevelDuration {
    private ThresholdLevel level;
    private Integer interval;
}
