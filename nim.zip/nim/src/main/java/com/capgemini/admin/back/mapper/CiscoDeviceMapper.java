package com.capgemini.admin.back.mapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.CiscoDeviceAttributesDTO;
import com.capgemini.admin.back.model.CiscoDeviceDTO;
import com.capgemini.admin.back.model.CiscoDeviceResponseDTO;

@Mapper(config = DtoMapperConfig.class)
public interface CiscoDeviceMapper {

    CiscoDeviceMapper INSTANCE = Mappers.getMapper(CiscoDeviceMapper.class);

    @Mapping(target = "deviceId", expression = "java(toString(map.get(\"deviceId\")))")
    @Mapping(target = "poiName", expression = "java(toString(map.get(\"poiName\")))")
    @Mapping(target = "poiTitle", expression = "java(toString(map.get(\"poiTitle\")))")
    @Mapping(target = "poiType", expression = "java(toString(map.get(\"poiType\")))")
    @Mapping(target = "deviceType", expression = "java(toString(map.get(\"deviceType\")))")
    @Mapping(target = "lastDataReceived", expression = "java(toEpochSeconds(map.get(\"lastDataReceived\")))")
    @Mapping(target = "ciscoDeviceAttributes", expression = "java(mapAttributes(map))")
    CiscoDeviceResponseDTO mapToDTO(Map<String, Object> map);

    default CiscoDeviceAttributesDTO mapAttributes(Map<String, Object> map) {
        CiscoDeviceAttributesDTO attributes = new CiscoDeviceAttributesDTO();
        attributes.setIpAddress(toString(map.get("ipAddress")));
        attributes.setPeopleCount(toInteger(map.get("peopleCount")));
        attributes.setAmbientNoiseDba(toDouble(map.get("ambientNoiseDba")));
        attributes.setSoundLevelDba(toDouble(map.get("soundLevelDba")));
        attributes.setAmbientTemperature(toDouble(map.get("ambientTemperature")));
        attributes.setRelativeHumidity(toDouble(map.get("relativeHumidity")));
        attributes.setAirQuality(toDouble(map.get("airQuality")));
        return attributes;
    }

    @Named("mapToCiscoDeviceDTO")
    @Mapping(target = "uuid", expression = "java(toString(map.get(\"uuid\")))")
    @Mapping(target = "deviceType", expression = "java(toString(map.get(\"deviceType\")))")
    @Mapping(target = "lastChange", expression = "java(toLong(map.get(\"lastChange\")))")
    @Mapping(target = "poiName", expression = "java(toString(map.get(\"poiName\")))")
    @Mapping(target = "floorId", expression = "java(toLong(map.get(\"floorId\")))")
    @Mapping(target = "poiId", expression = "java(toLong(map.get(\"poiId\")))")
    CiscoDeviceDTO mapToCiscoDeviceDTO(Map<String, Object> map);

    default String toString(Object value) {
        return value != null ? value.toString() : null;
    }

    default Long toLong(Object value) {
        return value instanceof Number ? ((Number) value).longValue() : null;
    }

    default Integer toInteger(Object value) {
        return value instanceof Number ? ((Number) value).intValue() : null;
    }

    default Double toDouble(Object value) {
        return value instanceof Number ? ((Number) value).doubleValue() : null;
    }

    default Long toEpochSeconds(Object value) {
        if (value instanceof Timestamp) {
            return ((Timestamp) value).toInstant().getEpochSecond();
        } else if (value instanceof LocalDateTime) {
            return ((LocalDateTime) value).toEpochSecond(ZoneOffset.UTC);
        }
        return null;
    }

}
