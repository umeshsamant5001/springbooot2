package com.capgemini.admin.back.model;

public enum AlertType {
    BLUE, YELLOW, ORANGE, RED;
}
