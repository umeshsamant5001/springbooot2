package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.Notification;

import javax.persistence.LockModeType;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

  public List<Notification> findDistinctByPriorityTypeInAndStatusInAndOsTypesIn(List<EnumPriorityType> priorityTypes,
      List<EnumStatusScheduled> status,
      List<EnumOsType> osTypes);

  /**
   * Return the list of notification to process and add a lock on them
   */
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("SELECT notification FROM Notification notification WHERE status = :status AND processing != TRUE")
  public List<Notification> findAllByStatus(@Param("status") EnumStatusScheduled status);

  @Query("SELECT notification FROM Notification notification WHERE id IN (:ids) ")
  public List<Notification> findAllByIds(@Param("ids") List<Long> ids);

  @Modifying
  @Query("UPDATE Notification SET processing = true WHERE id IN (:ids) ")
  public void setProcessing(@Param("ids") List<Long> ids);

  @Modifying
  @Query("UPDATE Notification SET processing = false WHERE id IN (:ids) ")
  public void setProcessed(@Param("ids") List<Long> ids);

}