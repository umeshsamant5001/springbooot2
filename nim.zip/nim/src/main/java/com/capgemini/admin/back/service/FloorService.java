package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.FloorRepository;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class FloorService {

	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	public static final class FloorUpdateWriteInput {
		private final Integer index;
		private final Long cdmKeyId;
		private final Map<String, String> attributes;
		private final String titleEn;
		private final String titleFr;

		public FloorUpdateWriteInput(Integer index, Long cdmKeyId, Map<String, String> attributes, String titleEn,
				String titleFr) {
			this.index = index == null ? null : Integer.valueOf(String.valueOf(index));
			this.cdmKeyId = cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
			this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));
			this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
			this.attributes = new HashMap<>();
			if (attributes != null) {
				attributes.forEach((key, value) -> {
					if (key != null && value != null) {
						this.attributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
					}
				});
			}
		}

		public Integer getIndex() {
			return index == null ? null : Integer.valueOf(String.valueOf(index));
		}

		public Long getCdmKeyId() {
			return cdmKeyId == null ? null : Long.valueOf(String.valueOf(cdmKeyId));
		}

		public String getTitleEn() {
			return titleEn == null ? null : new String(String.valueOf(titleEn));
		}

		public String getTitleFr() {
			return titleFr == null ? null : new String(String.valueOf(titleFr));
		}

		public Map<String, String> getAttributes() {
			Map<String, String> safeAttributes = new HashMap<>();
			this.attributes.forEach((key, value) -> safeAttributes.put(
					new String(String.valueOf(key)),
					new String(String.valueOf(value))));
			return safeAttributes;
		}
	}

	@Autowired
	private FloorRepository floorRepository;



	@Autowired
	private BuildingRepository buildingRepository;

	


	
    /**
     * Updates an existing Floor entity with validated input values.
     *
     * @param floorId the ID of the floor to update
     * @param floorUpdateInput validated floor update payload
     * @return the updated Floor object, or null if an exception occurs
     */
	public Floor updateFloor(Long floorId, FloorUpdateWriteInput floorUpdateInput) {

		if (Objects.isNull(floorId) || floorId <= 0 || Objects.isNull(floorUpdateInput)) {
			return null;
		}

		Long validatedFloorId = Long.valueOf(floorId);
		FloorUpdateWriteInput scopedFloorUpdateInput = sanitizeFloorUpdateWriteInput(floorUpdateInput);
		Integer validatedIndex = scopedFloorUpdateInput.getIndex() == null
				? null
				: Integer.valueOf(String.valueOf(scopedFloorUpdateInput.getIndex()));
		Long validatedCdmKeyId = scopedFloorUpdateInput.getCdmKeyId() == null
				? null
				: Long.valueOf(String.valueOf(scopedFloorUpdateInput.getCdmKeyId()));
		Map<String, String> validatedAttributes = sanitizeAttributes(scopedFloorUpdateInput.getAttributes());
		String validatedTitleEn = sanitizeOptionalText(
				scopedFloorUpdateInput.getTitleEn() == null ? null : new String(String.valueOf(scopedFloorUpdateInput.getTitleEn())),
				255);
		String validatedTitleFr = sanitizeOptionalText(
				scopedFloorUpdateInput.getTitleFr() == null ? null : new String(String.valueOf(scopedFloorUpdateInput.getTitleFr())),
				255);



		try {

			Floor oldFloor = this.floorRepository.findById(validatedFloorId).orElse(null);
			if (Objects.isNull(oldFloor)) {
				return null;
			}

			oldFloor.setIndex(validatedIndex == null ? null : Integer.valueOf(validatedIndex));
			oldFloor.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));
			oldFloor.setAttributes(new HashMap<>(validatedAttributes));
			oldFloor.setModifiedAt(new Date().getTime() / 1000);
			oldFloor.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
			oldFloor.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));

			return this.floorRepository.saveAndFlush(oldFloor);
		} catch (DataAccessException ex) {
			log.error("Failed to update floor for floorId {}", validatedFloorId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update floor.");
		}
	}




	
    /**
     * Retrieves a Floor by its ID, including its associated Building.
     *
     * @param floorId the ID of the floor to retrieve
     * @return the Floor object if found, otherwise null
     */
	@Transactional
	public Floor getFloor(long floorId) {
		try {
			Floor floor = this.floorRepository.findById(floorId).orElse(null);
			if (Objects.nonNull(floor)) {
				floor.getBuilding();
			}
			return floor;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve floor for floorId {}", floorId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve floor.");
		}
	}


    /**
     * Retrieves a map of attribute key-value pairs for a given floor ID.
     *
     * @param floorId the ID of the floor
     * @return a map of attribute keys and values
     */
	public Map<String, String> getAttributesById(Long floorId) {
		try {
			return this.floorRepository.getAttributesById(floorId)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, String.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve floor attributes for floorId {}", floorId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve floor attributes.");
		}
	}


	public Long countByBuildingId(Long buildingId) {
		return this.floorRepository.countByBuildingId(buildingId);
	}

	public List<Floor> getFloors() {
		try {
			return this.floorRepository.findAll();
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve floors.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve floors.");
		}
	}


	public List<Floor> getAllByBuildingIdOrderByIndex(Long buildingId) {
		return this.floorRepository.findAllByBuildingIdOrderByIndex(buildingId);
	}

	public Floor save(Floor floor) {
		if (Objects.isNull(floor)) {
			return null;
		}

		Long validatedId = floor.getId() == null ? null : Long.valueOf(floor.getId());
		Integer validatedIndex = floor.getIndex() == null ? null : Integer.valueOf(floor.getIndex());
		Long validatedBuildingId = floor.getBuildingId() == null ? null : Long.valueOf(floor.getBuildingId());
		Long validatedCdmKeyId = floor.getCdmKeyId() == null ? null : Long.valueOf(floor.getCdmKeyId());
		Map<String, String> validatedAttributes = sanitizeAttributes(floor.getAttributes());
		String validatedTitleEn = sanitizeOptionalText(floor.getTitleEn(), 255);
		String validatedTitleFr = sanitizeOptionalText(floor.getTitleFr(), 255);
		Long validatedModifiedAt = floor.getModifiedAt() == null
				? Long.valueOf((new Date()).getTime() / 1000)
				: Long.valueOf(floor.getModifiedAt());

		Floor sanitized = new Floor();
		sanitized.setId(validatedId == null ? null : Long.valueOf(validatedId));
		sanitized.setIndex(validatedIndex == null ? null : Integer.valueOf(validatedIndex));
		sanitized.setBuildingId(validatedBuildingId == null ? null : Long.valueOf(validatedBuildingId));
		sanitized.setCdmKeyId(validatedCdmKeyId == null ? null : Long.valueOf(validatedCdmKeyId));
		sanitized.setAttributes(new HashMap<>(validatedAttributes));
		sanitized.setTitleEn(validatedTitleEn == null ? null : new String(validatedTitleEn));
		sanitized.setTitleFr(validatedTitleFr == null ? null : new String(validatedTitleFr));
		sanitized.setModifiedAt(Long.valueOf(validatedModifiedAt));

		if (Objects.nonNull(validatedBuildingId)) {
			Building building = this.buildingRepository.findById(validatedBuildingId).orElseThrow();
			sanitized.setBuilding(building);
		}

		return this.floorRepository.saveAndFlush(sanitized);
	}



	public void deleteById(Long floorId) {
		this.floorRepository.deleteById(floorId);
	}

	

	private FloorUpdateWriteInput sanitizeFloorUpdateWriteInput(FloorUpdateWriteInput source) {
		if (source == null) {
			throw new IllegalArgumentException("Floor input must not be null");
		}

		Integer safeIndex = source.getIndex() == null ? null : Integer.valueOf(String.valueOf(source.getIndex()));
		Long safeCdmKeyId = source.getCdmKeyId() == null ? null : Long.valueOf(String.valueOf(source.getCdmKeyId()));
		Map<String, String> safeAttributes = new HashMap<>();
		Map<String, String> sourceAttributes = source.getAttributes();
		if (sourceAttributes != null) {
			sourceAttributes.forEach((key, value) -> {
				if (Objects.nonNull(key) && Objects.nonNull(value)) {
					safeAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
				}
			});
		}
		String safeTitleEn = source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn()));
		String safeTitleFr = source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr()));

		return new FloorUpdateWriteInput(safeIndex, safeCdmKeyId, safeAttributes, safeTitleEn, safeTitleFr);
	}

	private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {

		Map<String, String> sanitized = new HashMap<>();
		if (Objects.isNull(attributes)) {
			return sanitized;
		}

		attributes.forEach((key, value) -> {
			if (Objects.nonNull(key) && Objects.nonNull(value)) {
				String safeKey = sanitizeOptionalText(key, 255);
				String safeValue = sanitizeOptionalText(value, 1000);
				if (Objects.nonNull(safeKey) && Objects.nonNull(safeValue)) {
					sanitized.put(safeKey, safeValue);
				}
			}
		});
		return sanitized;
	}

	private String sanitizeOptionalText(String value, int maxLength) {
		if (value == null) {
			return null;
		}
		String trimmed = value.trim();
		if (trimmed.isEmpty()) {
			return null;
		}
		if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
			throw new IllegalArgumentException("Invalid text input");
		}
		return new String(trimmed);
	}

}
