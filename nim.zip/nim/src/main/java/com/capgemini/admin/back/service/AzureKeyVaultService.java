package com.capgemini.admin.back.service;

import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.capgemini.admin.back.config.ApplicationProperties;

@Slf4j
@Service
public class AzureKeyVaultService {

    @Autowired
    private ApplicationProperties applicationProperties;
    private SecretClient secretClient;

    /**
     * Retrieves a secret from Azure Key Vault by its name.
     * 
     * @param secretName the name of the secret to retrieve
     * @return the KeyVaultSecret object, or null if not found
     * 
     */
    public KeyVaultSecret getSecret(String secretName) {
        KeyVaultSecret kvSecret = getSecretClient().getSecret(secretName);
        if (Objects.isNull(kvSecret)) {
            return null;
        }

        log.info("Success to the secret");
        return kvSecret;
    }

    /**
     * Lazily initializes and returns the SecretClient for accessing secrets
     * in Azure Key Vault.
     * 
     * @return the initialized SecretClient
     * 
     */
    private SecretClient getSecretClient() {
        log.info("connection to the keyVault");
        if (Objects.isNull(secretClient)) {
            ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
                    .tenantId(applicationProperties.getAzure().getTenantId())
                    .clientId(applicationProperties.getAzure().getKeyVault().getClientId())
                    .clientSecret(applicationProperties.getAzure().getKeyVault().getClientSecret())
                    .build();

            secretClient = new SecretClientBuilder()
                    .vaultUrl(applicationProperties.getAzure().getKeyVault().getUrl())
                    .credential(clientSecretCredential)
                    .buildClient();
        }
        return secretClient;
    }

}
