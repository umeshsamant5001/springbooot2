package com.capgemini.admin.back.model;

public enum Platform {
    WEB, MOBILE;
}
