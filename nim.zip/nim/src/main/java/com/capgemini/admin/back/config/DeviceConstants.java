package com.capgemini.admin.back.config;

import java.util.Set;

public class DeviceConstants {

    public static final String HEADER_POI_NAME = "POINAME";
    public static final String HEADER_UUID = "Uuid";
    public static final String HEADER_BOOKABLE = "Bookable";
    public static final String HEADER_CHECK_IN = "CheckIn";
    public static final String HEADER_CHECK_IN_DURATION = "CheckInDuration";
    public static final String HEADER_EARLY_CHECK_IN = "Early Check-In";
    public static final String HEADER_CHECK_OUT = "CheckOut";
    public static final String HEADER_SHOW_STATE = "ShowState";
    public static final String HEADER_SHOW_TEMP = "ShowTemp";
    public static final String HEADER_SHOW_HUMIDITY = "ShowHumidity";
    public static final String HEADER_SHOW_SOUND = "ShowSound";
    public static final String HEADER_SHOW_CO2 = "ShowCo2";
    public static final String HEADER_SHOW_LUX = "ShowLux";
    public static final int TABLET_COLUMN_COUNT = 14;
    public static final int MAX_TABLET_IMPORT_DATA_LINES = 10000;

    public static final String DEFAULT_CERTIFICATE_NAME = "certificateDefaultName";
    public static final String BOOKABLE = "bookable";
    public static final String CHECKIN = "checkIn";
    public static final String CHECKIN_DURATION = "checkInDuration";
    public static final String EARLY_CHECK_IN = "earlyCheckIn";
    public static final String CHECKOUT = "checkOut";
    public static final String SHOW_STATE = "showState";
    public static final String SHOW_TEMP = "showTemp";
    public static final String SHOW_HUMIDITY = "showHumidity";
    public static final String SHOW_SOUND = "showSound";
    public static final String SHOW_CO2 = "showCo2";
    public static final String SHOW_LUX = "showLux";
    public static final String REPORT_AN_ISSUE = "reportAnIssue";
    public static final int IDX_POI_NAME = 0;
    public static final int IDX_DEVICE_UUID = 1;
    public static final int IDX_BOOKABLE = 2;
    public static final int IDX_CHECKIN = 3;
    public static final int IDX_CHECKIN_DURATION = 4;
    public static final int IDX_EARLY_CHECK_IN = 5;
    public static final int IDX_CHECK_OUT = 6;
    public static final int IDX_SHOW_STATE = 7;
    public static final int IDX_SHOW_TEMP = 8;
    public static final int IDX_SHOW_HUMIDITY = 9;
    public static final int IDX_SHOW_SOUND = 10;
    public static final int IDX_SHOW_CO2 = 11;
    public static final int IDX_SHOW_LUX = 12;
    public static final String DEVICE_TYPE = "tablet";

    public static final Set<String> KEYS_TO_RETAIN = Set.of("pcbID", "swVersion", "vdd", "vddPct");

    public static final int IDX_REPORT_AN_ISSUE = 13;

    
}
