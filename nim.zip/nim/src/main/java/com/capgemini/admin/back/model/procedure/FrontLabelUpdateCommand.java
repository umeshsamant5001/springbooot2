package com.capgemini.admin.back.model.procedure;

public class FrontLabelUpdateCommand {
    private final String keyId;
    private final String fieldKey;
    private final String languageText;
    private final String languageCode;

    public FrontLabelUpdateCommand(String keyId, String fieldKey, String languageText, String languageCode) {
        this.keyId = keyId == null ? null : new String(String.valueOf(keyId));
        this.fieldKey = fieldKey == null ? null : new String(String.valueOf(fieldKey));
        this.languageText = languageText == null ? null : new String(String.valueOf(languageText));
        this.languageCode = languageCode == null ? null : new String(String.valueOf(languageCode));
    }

    public String getKeyId() {
        return keyId == null ? null : new String(String.valueOf(keyId));
    }

    public String getFieldKey() {
        return fieldKey == null ? null : new String(String.valueOf(fieldKey));
    }

    public String getLanguageText() {
        return languageText == null ? null : new String(String.valueOf(languageText));
    }

    public String getLanguageCode() {
        return languageCode == null ? null : new String(String.valueOf(languageCode));
    }
}
