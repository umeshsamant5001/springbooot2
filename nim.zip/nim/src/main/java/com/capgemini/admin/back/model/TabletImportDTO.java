package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class TabletImportDTO {
    private String poiName;
    private String uuid;
    private boolean bookable;
    private boolean checkIn;
    private Integer checkInDuration;
    private Integer earlyCheckIn;
    private boolean checkOut;
    private boolean showState;
    private boolean showTemp;
    private boolean showHumidity;
    private boolean showSound;
    private boolean showCo2;
    private boolean showLux;
    private boolean reportAnIssue;
}
