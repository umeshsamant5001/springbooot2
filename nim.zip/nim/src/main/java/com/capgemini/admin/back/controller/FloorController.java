package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.admin.back.service.BuildingService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.mapper.BuildingMapper;
import com.capgemini.admin.back.mapper.FloorMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.FloorDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.service.FloorService;

import com.capgemini.admin.back.service.TreeService;
import com.capgemini.admin.back.temporary.Base64FloorMap;
import com.capgemini.admin.back.temporary.CDMBatchExceptionReport;
import com.capgemini.admin.back.temporary.CDMClient;
import com.capgemini.admin.back.temporary.CDMFloor;
import com.capgemini.admin.back.temporary.EnumCdmAttributes;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.admin.back.config.Constants;



@Slf4j
@RestController
@RequestMapping(value = FloorController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class FloorController {

    static final String ROOT_API = "api/floors";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class FloorCreateRequest {
        @Min(0)
        private Integer index;
        @Min(1)
        private Long buildingId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 1000)
        private Map<String, String> attributes;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class FloorUpdateRequest {
        @Min(0)
        private Integer index;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 1000)
        private Map<String, String> attributes;
    }



    


    

    @Autowired
    private CDMClient cdm;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private FloorService floorService;

    @Autowired
    private TreeService treeService;

    @GetMapping("/{floorId}")
    public ResponseEntity<FloorDTO> getFloor(
            @PathVariable Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        if (!this.treeService.isAuthorized(LevelEnum.BUILDING, floor.getBuildingId())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        FloorDTO floorDto = FloorMapper.INSTANCE.floorToFloorDTO(floor, language);
        floorDto.setAssetCode(floor.getBuilding().getAttributes().get(Constants.ASSET_CODE));
        return ResponseEntity.ok(floorDto);
    }

    @GetMapping
    public ResponseEntity<List<FloorDTO>> getAllFloors(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<Floor> floors = this.floorService.getFloors();
        if (CollectionUtils.isEmpty(floors)) {
            return ResponseEntity.noContent().build();
        }

        floors = floors.stream()
                .filter(floor -> this.treeService.isAuthorized(LevelEnum.BUILDING, floor.getBuildingId()))
                .collect(Collectors.toList());

        return ResponseEntity.ok(floors.stream().map(floor -> FloorMapper.INSTANCE.floorToFloorDTO(floor, language))
                .collect(Collectors.toList()));
    }

    @GetMapping("/search/findAllByBuildingIdOrderByIndex")
    public ResponseEntity<List<FloorDTO>> getfindAllByBuildingIdOrderByIndex(
            @RequestParam Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Floor> floors = this.floorService.getAllByBuildingIdOrderByIndex(buildingId);
        if (CollectionUtils.isEmpty(floors)) {
            return ResponseEntity.notFound().build();
        }

        floors = floors.stream()
                .filter(floor -> this.treeService.isAuthorized(LevelEnum.BUILDING, floor.getBuildingId()))
                .collect(Collectors.toList());

        return ResponseEntity.ok(floors.stream().map(floor -> FloorMapper.INSTANCE.floorToFloorDTO(floor, language))
                .collect(Collectors.toList()));
    }

    @GetMapping("/{floorId}/building")
    public ResponseEntity<BuildingDTO> getBuildingByFloorId(
            @PathVariable Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        Building building = null;
        if (Objects.nonNull(floor.getBuildingId())) {
            building = this.buildingService.getBuilding(floor.getBuildingId());
            if (Objects.isNull(building)) {
                return ResponseEntity.notFound().build();
            }

            building = this.treeService.filterTree(building);

            if (Objects.isNull(building)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }
        }

        return ResponseEntity.ok(BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language));
    }

    @PostMapping
    public ResponseEntity<FloorDTO> createFloor(
            @Valid @RequestBody FloorCreateRequest floorDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        Floor floor = new Floor();
        floor.setIndex(floorDTO.getIndex() == null ? null : Integer.valueOf(floorDTO.getIndex()));
        floor.setBuildingId(floorDTO.getBuildingId() == null ? null : Long.valueOf(floorDTO.getBuildingId()));
        floor.setTitleEn(floorDTO.getTitleEn() == null ? null : new String(String.valueOf(floorDTO.getTitleEn())));
        floor.setTitleFr(floorDTO.getTitleFr() == null ? null : new String(String.valueOf(floorDTO.getTitleFr())));
        floor.setCdmKeyId(floorDTO.getCdmKeyId() == null ? null : Long.valueOf(floorDTO.getCdmKeyId()));
        floor.setAttributes(this.sanitizeAttributes(floorDTO.getAttributes()));

        // Defense-in-depth against unsafe object binding: explicitly clear
        // server-managed / identity fields before persistence.
        floor.setId(null);
        floor.setBuilding(null);
        floor.setModifiedAt(new Date().getTime() / 1000);


        try {
            floor = this.floorService.save(floor);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(FloorMapper.INSTANCE.floorToFloorDTO(floor, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Update method for a floor (The building association can't be updated)
     *
     * @param floorId
     * @param floorDTO
     * @return floorDTO
     */
    @PutMapping("/{floorId}")
    public ResponseEntity<FloorDTO> updateFloor(
            @PathVariable Long floorId,
            @Valid @RequestBody FloorUpdateRequest floorDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        FloorService.FloorUpdateWriteInput safeFloorUpdateInput = this.toFloorUpdateWriteInput(floorDTO);

        try {
            Floor newFloor = this.floorService.updateFloor(
                    floorId,
                    safeFloorUpdateInput);
            return ResponseEntity.ok(FloorMapper.INSTANCE.floorToFloorDTO(newFloor, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }

    }

    @PutMapping("/{floorId}/building")
    public ResponseEntity<FloorDTO> associateBuildingToFloor(
            @PathVariable Long floorId,
            @RequestBody BuildingDTO buildingDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (Objects.isNull(buildingDTO) || Objects.isNull(buildingDTO.getId())) {
            return ResponseEntity.notFound().build();
        }

        Building building = this.buildingService.getBuilding(buildingDTO.getId());
        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }

        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        floor.setBuilding(building);
        floor.setBuildingId(building.getId());
        floor.setModifiedAt(new Date().getTime() / 1000);

        try {
            floor = this.floorService.save(floor);
            return ResponseEntity.ok(FloorMapper.INSTANCE.floorToFloorDTO(floor, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @DeleteMapping("/{floorId}")
    public ResponseEntity<Object> deleteFloor(@PathVariable Long floorId) {
        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        this.floorService.deleteById(floorId);
        return ResponseEntity.ok().build();
    }








    private FloorService.FloorUpdateWriteInput toFloorUpdateWriteInput(FloorUpdateRequest floorDTO) {
        if (Objects.isNull(floorDTO)) {
            return new FloorService.FloorUpdateWriteInput(null, null, new HashMap<>(), null, null);
        }

        Integer safeIndex = floorDTO.getIndex() == null
                ? null
                : Integer.valueOf(String.valueOf(floorDTO.getIndex()));
        Long safeCdmKeyId = floorDTO.getCdmKeyId() == null
                ? null
                : Long.valueOf(String.valueOf(floorDTO.getCdmKeyId()));
        Map<String, String> safeAttributes = new HashMap<>(this.sanitizeAttributes(floorDTO.getAttributes()));
        String safeTitleEn = floorDTO.getTitleEn() == null
                ? null
                : new String(String.valueOf(floorDTO.getTitleEn()));
        String safeTitleFr = floorDTO.getTitleFr() == null
                ? null
                : new String(String.valueOf(floorDTO.getTitleFr()));

        return new FloorService.FloorUpdateWriteInput(
                safeIndex,
                safeCdmKeyId,
                new HashMap<>(safeAttributes),
                safeTitleEn == null ? null : new String(String.valueOf(safeTitleEn)),
                safeTitleFr == null ? null : new String(String.valueOf(safeTitleFr)));
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {

        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

    @GetMapping("/{floorId}/getFloorMap")
    public ResponseEntity<Base64FloorMap> getFloorMapByFloorId(
            HttpServletRequest request,
            @PathVariable Long floorId) {

        Floor floor = this.floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            return ResponseEntity.notFound().build();
        }

        Building building = floor.getBuilding();
        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }

        building = this.treeService.filterTree(building);

        if (Objects.isNull(building)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Base64FloorMap map = new Base64FloorMap();
        CDMBatchExceptionReport cdmBatchExceptionReport = new CDMBatchExceptionReport();
        try {
            List<CDMFloor> res = cdm.getPoiFloorCDM(
                    building.getAttributes().get(EnumCdmAttributes.ASSET_ID.toString()),
                    floor.getCdmKeyId(),
                    cdmBatchExceptionReport);
            map.setFloorId(String.valueOf(floor.getId()));
            map.setBase64map(res.get(0).getBase64Map());
        } catch (Exception ex) {
            log.info(ex.getMessage());
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(map);
    }
}
