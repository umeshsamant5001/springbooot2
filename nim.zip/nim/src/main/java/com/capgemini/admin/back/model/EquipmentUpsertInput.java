package com.capgemini.admin.back.model;

public class EquipmentUpsertInput {

    private final String name;
    private final String titleEn;
    private final String titleFr;

    public EquipmentUpsertInput(String name, String titleEn, String titleFr) {
        this.name = name == null ? null : new String(String.valueOf(name));
        this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));
        this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
    }

    public String getName() {
        return name == null ? null : new String(String.valueOf(name));
    }

    public String getTitleEn() {
        return titleEn == null ? null : new String(String.valueOf(titleEn));
    }

    public String getTitleFr() {
        return titleFr == null ? null : new String(String.valueOf(titleFr));
    }
}
