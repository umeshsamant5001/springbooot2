package com.capgemini.admin.back.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class NotificationDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;

    private String title;
    private String message;
    private String messageType;
    private String image;
    private List<EnumOsType> osTypes;
    private EnumPriorityType priorityType;
    private Long startDate;
    private Long endDate;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long lastChange;

    private EnumStatusScheduled status;
    private Map<String, String> attributes;
    private List<NotificationLocationDTO> notificationLocations;
}