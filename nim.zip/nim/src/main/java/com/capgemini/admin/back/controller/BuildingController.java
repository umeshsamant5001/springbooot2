package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.helper.DateTimeUtils;
import com.capgemini.admin.back.mapper.BuildingMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.BuildingInformationDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.OpeningHours;
import com.capgemini.admin.back.model.TemperatureUnit;
import com.capgemini.admin.back.model.TimeFormat;
import com.capgemini.admin.back.service.BuildingService;

import com.capgemini.admin.back.service.CacheClientService;
import com.capgemini.admin.back.service.FloorService;
import com.capgemini.admin.back.service.TreeService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@Validated
@RequestMapping(value = BuildingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class BuildingController {


    static final String ROOT_API = "api/building";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class OpeningHoursWriteRequest {
        @Min(0)
        @Max(86400)
        private Long from;
        @Min(0)
        @Max(86400)
        private Long to;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class BuildingInformationWriteRequest {
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String address;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String city;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String country;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String phone;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String receptionMail;
        @Size(max = 500)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String infoUrl;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String ldapName;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String capacity;
        @Valid
        private OpeningHoursWriteRequest openingHours;
        @Min(0)
        private Long limitInDay;
        @Min(0)
        private Long deskLimitCrowded;
        @DecimalMin("0.0")
        private Double minimumDeskArea;
        @Min(-100)
        @Max(100)
        private Integer minTemp;
        @Min(-100)
        @Max(100)
        private Integer maxTemp;
        private TemperatureUnit tempFormat;
        private TimeFormat timeFormat;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class BuildingWriteRequest {
        @Min(1)
        private Long siteId;
        private Boolean deployed;
        private Boolean secured;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 1000)
        private Map<String, String> attributes;
        @Valid
        private BuildingInformationWriteRequest information;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
    }




    @Autowired
    private FloorService floorService;

    @Autowired
    private BuildingService buildingService;

    @Autowired
    private TreeService treeService;

    @Autowired
    private CacheClientService cacheClient;

    /**
     * Retrieves a specific building by its ID.
     *
     * @param buildingId the ID of the building to retrieve
     * @param language   the preferred language for the response (optional, defaults
     *                   to "en")
     * @return a ResponseEntity containing the BuildingDTO if found and authorized,
     *         404 Not Found if the building doesn't exist, or 401 Unauthorized if
     *         the building is filtered out
     */
    @GetMapping("/{buildingId}")
    @Transactional
    public ResponseEntity<BuildingDTO> getBuilding(
            @PathVariable String buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        if (Objects.isNull(buildingId) || !buildingId.matches("^\\d+$")) {
            return ResponseEntity.badRequest().build();
        }

        Long sanitizedBuildingId;
        try {
            sanitizedBuildingId = Long.valueOf(buildingId);
        } catch (NumberFormatException ex) {
            return ResponseEntity.badRequest().build();
        }

        if (sanitizedBuildingId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Building building = buildingService.getBuilding(sanitizedBuildingId);



        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }

        building = treeService.filterTree(building);

        if (Objects.isNull(building)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        BuildingDTO buildingDTO = BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language);
        buildingDTO.setNbChilds(floorService.countByBuildingId(buildingDTO.getId()));
        return ResponseEntity.ok(buildingDTO);
    }

    /**
     * Retrieves all buildings available to the user.
     *
     * @param language the preferred language for the response (optional, defaults
     *                 to "en")
     * @return a ResponseEntity containing a list of BuildingDTOs,
     *         or 204 No Content if no buildings are available
     */
    @GetMapping
    public ResponseEntity<List<BuildingDTO>> getAllBuildings(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Building> buildings = buildingService.getAll();
        buildings = treeService.filterTree(buildings);

        if (CollectionUtils.isEmpty(buildings)) {
            return ResponseEntity.noContent().build();
        }

        List<BuildingDTO> buildingsDTOs = buildings
                .stream()
                .map(building -> {
                    return BuildingMapper.INSTANCE.buildingToBuildingDTONoFloors(building, language);
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(buildingsDTOs);
    }

    /**
     * Creates a new building.
     *
     * @param buildingDTO the building data to be created
     * @param language    the preferred language for the response (optional,
     *                    defaults to "en")
     * @return a ResponseEntity containing the created BuildingDTO with HTTP 201
     *         status,
     *         or HTTP 500 if an error occurs during creation
     */
    @PostMapping
    public ResponseEntity<BuildingDTO> createBuilding(
            @Valid @RequestBody BuildingWriteRequest buildingRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        try {
            BuildingDTO sanitizedBuildingDTO = new BuildingDTO();
            sanitizedBuildingDTO.setSiteId(buildingRequest.getSiteId() == null ? null : Long.valueOf(buildingRequest.getSiteId()));
            sanitizedBuildingDTO.setCdmKeyId(buildingRequest.getCdmKeyId() == null ? null : Long.valueOf(buildingRequest.getCdmKeyId()));
            sanitizedBuildingDTO.setDeployed(buildingRequest.getDeployed() == null ? null : Boolean.valueOf(buildingRequest.getDeployed().booleanValue()));
            sanitizedBuildingDTO.setSecured(buildingRequest.getSecured() == null ? null : Boolean.valueOf(buildingRequest.getSecured().booleanValue()));
            sanitizedBuildingDTO.setAttributes(this.sanitizeAttributes(buildingRequest.getAttributes()));
            sanitizedBuildingDTO.setInformation(this.sanitizeBuildingInformation(buildingRequest.getInformation()));
            sanitizedBuildingDTO.setTitleEn(buildingRequest.getTitleEn() == null ? null : String.valueOf(buildingRequest.getTitleEn()));
            sanitizedBuildingDTO.setTitleFr(buildingRequest.getTitleFr() == null ? null : String.valueOf(buildingRequest.getTitleFr()));



            Building building = BuildingMapper.INSTANCE.buildingDTOToBuilding(sanitizedBuildingDTO);
            // Defense against unsafe object binding: never trust an id supplied by the client on create.
            building.setId(null);

            ZoneId zone = !building.hasCoordinates()
                    ? DateTimeUtils.UTC_ZONE_ID
                    : DateTimeUtils.getZone(
                            Double.parseDouble(building.getAttributes().get("lat")),
                            Double.parseDouble(building.getAttributes().get("lon")));

            building.setTimezoneWindows(this.calculateTimezone(zone));
            building.setTimezoneJava(zone.getId());
            building.setModifiedAt(new Date().getTime() / 1000);

            building = buildingService.save(building);

            if (building.getDeployed()) {
                cacheClient.clearBuildingsCache();
            }
            BuildingDTO responseDto = BuildingMapper.INSTANCE.buildingToBuildingDTO(building, language);
            return ResponseEntity.status(HttpStatus.CREATED).body(responseDto);
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Updates an existing building.
     *
     * @param buildingId  the ID of the building to update
     * @param buildingDTO the updated building data
     * @param language    the preferred language for the response (optional,
     *                    defaults to "en")
     * @return a ResponseEntity containing the updated BuildingDTO,
     *         or 404 Not Found if the building does not exist
     */
    @PutMapping("/{buildingId}")
    public ResponseEntity<BuildingDTO> updateBuilding(
            @PathVariable @Min(1) Long buildingId,
            @Valid @RequestBody BuildingWriteRequest buildingRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {



        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        if (!buildingService.buidingExists(buildingId)) {
            return ResponseEntity.notFound().build();
        }

        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Building oldBuilding = buildingService.getAuthorizedBuilding(Long.valueOf(buildingId));


        BuildingDTO sanitizedBuildingDTO = new BuildingDTO();
        // Set id so that CdmAttributesMapper.mapAttributes can fetch and re-attach
        // CDM attributes from the DB, preventing them from being silently deleted.
        sanitizedBuildingDTO.setId(buildingId);

        sanitizedBuildingDTO.setCdmKeyId(buildingRequest.getCdmKeyId() == null ? null : Long.valueOf(buildingRequest.getCdmKeyId()));
        sanitizedBuildingDTO.setDeployed(buildingRequest.getDeployed() == null ? null : Boolean.valueOf(buildingRequest.getDeployed().booleanValue()));
        sanitizedBuildingDTO.setSecured(buildingRequest.getSecured() == null ? null : Boolean.valueOf(buildingRequest.getSecured().booleanValue()));
        sanitizedBuildingDTO.setAttributes(
            buildingRequest.getAttributes() == null
                ? null
                : this.sanitizeAttributes(buildingRequest.getAttributes()));
        sanitizedBuildingDTO.setInformation(this.sanitizeBuildingInformation(buildingRequest.getInformation()));
        sanitizedBuildingDTO.setTitleEn(buildingRequest.getTitleEn() == null ? null : String.valueOf(buildingRequest.getTitleEn()));
        sanitizedBuildingDTO.setTitleFr(buildingRequest.getTitleFr() == null ? null : String.valueOf(buildingRequest.getTitleFr()));



        Building building = BuildingMapper.INSTANCE.buildingDTOToBuilding(sanitizedBuildingDTO);
        // Defense against unsafe object binding: ignore any id provided in the request body;
        // the target entity is identified solely by the validated path variable buildingId.
        building.setId(null);
        if (buildingRequest.getAttributes() == null) {
            // Preserve existing building_attribute rows when attributes are omitted in PUT payload.
            building.setAttributes(null);
        }
        
        Building newBuilding = buildingService.updateBuilding(buildingId, building);
        if (Objects.isNull(newBuilding)) {
            return ResponseEntity.notFound().build();
        }

        if (Objects.nonNull(oldBuilding) && !Objects.equals(oldBuilding.getDeployed(), newBuilding.getDeployed())) {
            cacheClient.clearBuildingsCache();
        }

        BuildingDTO responseDto = BuildingMapper.INSTANCE.buildingToBuildingDTO(newBuilding, language);


        return ResponseEntity.ok(responseDto);
    }

    /**
     * Deletes a building by its ID.
     *
     * @param buildingId the ID of the building to delete
     * @return a ResponseEntity with HTTP 204 No Content if deleted,
     *         or 404 Not Found if the building does not exist.
     */
    @DeleteMapping("/{buildingId}")
    public ResponseEntity<Object> deleteBuilding(@PathVariable @Min(1) Long buildingId) {

        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        if (!buildingService.buidingExists(buildingId)) {
            return ResponseEntity.notFound().build();
        }

        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        buildingService.delete(buildingId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Updates or adds attributes to a specific building.
     * 
     * @param buildingId    the ID of the building to update
     * @param newAttributes a map of new or updated attributes
     * @param language      the language preference from the request header
     *                      (optional)
     * @return a ResponseEntity containing the updated attributes
     * 
     */
    @PutMapping("/{buildingId}/attributes")
    public ResponseEntity<Map<String, String>> editOrAddBuildingAttributes(
            @PathVariable @Min(1) Long buildingId,
            @Valid @RequestBody Map<String, String> newAttributes,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {


        if (Objects.isNull(buildingId) || buildingId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        if (!buildingService.buidingExists(buildingId)) {
            return ResponseEntity.notFound().build();
        }

        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Building building = buildingService.getAuthorizedBuilding(Long.valueOf(buildingId));

        if (Objects.isNull(building)) {
            return ResponseEntity.notFound().build();
        }


        Map<String, String> sanitizedAttributes = new HashMap<>();
        if (Objects.nonNull(newAttributes)) {
            newAttributes.forEach((key, value) -> {
                if (Objects.nonNull(key) && Objects.nonNull(value)) {
                    sanitizedAttributes.put(key, value);
                }
            });
        }

        Map<String, String> buildingAttributes = building.getAttributes();

        buildingAttributes.putAll(sanitizedAttributes);

        building.setAttributes(buildingAttributes);
        buildingService.save(building);
        return ResponseEntity.ok(buildingAttributes);
    }

    /**
     * Exports all building data.
     * 
     * @return a ResponseEntity containing the exported data as a string
     */
    @GetMapping("/export")
    ResponseEntity<String> exportAll() {
        List<List<String>> data = buildingService.getExportAll();

        return buildingService.export(data);
    }

    private BuildingInformationDTO sanitizeBuildingInformation(BuildingInformationWriteRequest informationRequest) {
        if (Objects.isNull(informationRequest)) {
            return null;
        }

        BuildingInformationDTO sanitizedInformation = new BuildingInformationDTO();
        sanitizedInformation.setAddress(informationRequest.getAddress() == null ? null : String.valueOf(informationRequest.getAddress()));
        sanitizedInformation.setCity(informationRequest.getCity() == null ? null : String.valueOf(informationRequest.getCity()));
        sanitizedInformation.setCountry(informationRequest.getCountry() == null ? null : String.valueOf(informationRequest.getCountry()));
        sanitizedInformation.setPhone(informationRequest.getPhone() == null ? null : String.valueOf(informationRequest.getPhone()));
        sanitizedInformation.setReceptionMail(informationRequest.getReceptionMail() == null ? null : String.valueOf(informationRequest.getReceptionMail()));
        sanitizedInformation.setInfoUrl(informationRequest.getInfoUrl() == null ? null : String.valueOf(informationRequest.getInfoUrl()));
        sanitizedInformation.setLdapName(informationRequest.getLdapName() == null ? null : String.valueOf(informationRequest.getLdapName()));
        sanitizedInformation.setCapacity(informationRequest.getCapacity() == null ? null : String.valueOf(informationRequest.getCapacity()));

        OpeningHours sanitizedOpeningHours = null;
        if (Objects.nonNull(informationRequest.getOpeningHours())) {
            sanitizedOpeningHours = new OpeningHours();
            sanitizedOpeningHours.setFrom(informationRequest.getOpeningHours().getFrom() == null
                    ? null
                    : Long.valueOf(informationRequest.getOpeningHours().getFrom()));
            sanitizedOpeningHours.setTo(informationRequest.getOpeningHours().getTo() == null
                    ? null
                    : Long.valueOf(informationRequest.getOpeningHours().getTo()));
        }
        sanitizedInformation.setOpeningHours(sanitizedOpeningHours);

        sanitizedInformation.setLimitInDay(informationRequest.getLimitInDay() == null
                ? null
                : Long.valueOf(informationRequest.getLimitInDay()));
        sanitizedInformation.setDeskLimitCrowded(informationRequest.getDeskLimitCrowded() == null
                ? null
                : Long.valueOf(informationRequest.getDeskLimitCrowded()));
        sanitizedInformation.setMinimumDeskArea(informationRequest.getMinimumDeskArea() == null
                ? null
                : Double.valueOf(informationRequest.getMinimumDeskArea()));
        sanitizedInformation.setMinTemp(informationRequest.getMinTemp() == null ? null : Integer.valueOf(informationRequest.getMinTemp()));
        sanitizedInformation.setMaxTemp(informationRequest.getMaxTemp() == null ? null : Integer.valueOf(informationRequest.getMaxTemp()));
        sanitizedInformation.setTempFormat(informationRequest.getTempFormat());
        sanitizedInformation.setTimeFormat(informationRequest.getTimeFormat());


        return sanitizedInformation;
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitizedAttributes = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitizedAttributes;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                sanitizedAttributes.put(String.valueOf(key), String.valueOf(value));
            }
        });

        return sanitizedAttributes;
    }

    /**
     * Converts a ZoneId to a Windows-compatible timezone string.
     * 
     * @param zone the ZoneId to convert
     * @return the corresponding Windows timezone string
     * 
     */
    private String calculateTimezone(ZoneId zone) {
        return DateTimeUtils.getWindowsTimezoneFromZoneId(zone);
    }


}
