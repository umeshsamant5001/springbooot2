package com.capgemini.admin.back.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CiscoDeviceDTO {
   private String uuid;
   private String deviceType;
   private Long lastChange;
   private String poiName;
   private Long floorId;
   private Long poiId;
}
