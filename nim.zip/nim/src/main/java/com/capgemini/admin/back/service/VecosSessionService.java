package com.capgemini.admin.back.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.VecosSession;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VecosSessionService {

    private final Map<String, VecosSession> session = new ConcurrentHashMap<>();

    /**
     * Retrieves the Vecos session associated with the given tenant.
     *
     * @param tenant The tenant identifier.
     * @return The VecosSession object if found, otherwise null.
     */
    public VecosSession getSession(String tenant) {
        return this.session.getOrDefault(tenant, null);
    }

    /**
     * Stores or updates the Vecos session for the specified tenant.
     *
     * @param tenant  The tenant identifier.
     * @param session The VecosSession object to store.
     */
    public void setSession(String tenant, VecosSession session) {
        this.session.put(tenant, session);
    }

    /**
     * Removes the cached session for the specified tenant.
     *
     * @param tenant The tenant identifier.
     */
    public void clearSession(String tenant) {
        this.session.remove(tenant);
    }
}