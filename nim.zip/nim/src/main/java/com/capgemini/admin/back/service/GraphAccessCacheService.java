package com.capgemini.admin.back.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.capgemini.admin.back.config.GraphHelper;
import com.capgemini.admin.back.model.GraphApiAccessCache;
import com.capgemini.admin.back.repository.GraphApiAccessCacheRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GraphAccessCacheService {

    private final GraphApiAccessCacheRepository cacheRepo;

    private final GraphHelper graphHelper;

    /**
     * Constructor for GraphAccessCacheService.
     *
     * @param cacheRepo the repository used to store and retrieve Graph API access cache entries
     * @param graphHelper the helper class used to check Graph API access for a given email
     */
    public GraphAccessCacheService(GraphApiAccessCacheRepository cacheRepo, GraphHelper graphHelper) {
        this.cacheRepo = cacheRepo;
        this.graphHelper = graphHelper;
    }

    /**
     * Asynchronously schedules access status checks for a list of room emails using a thread pool.
     * Each email is processed in a separate thread to improve performance.
     *
     * @param emails the list of room emails to check access for
     */
    @Async
    public void AccessStatusesScheduler(List<String> emails) {
        ExecutorService executor = Executors.newFixedThreadPool(20);
        for (String email : emails) {
            executor.submit(() -> {
                if (email != null && !email.trim().isEmpty()) {
                    refreshSingleStatus(email);

                }
            });
        }
        executor.shutdown();
    }

    /**
     * Refreshes the Graph API access status for a single email.
     * Updates or creates a cache entry with the latest access status and timestamp.
     *
     * @param email the room email to check and update
     */
    private void refreshSingleStatus(String email) {
        String sanitizedEmail = sanitizeForLog(email);
        log.info("Updating access status for {}", sanitizedEmail);
        boolean hasAccess = graphHelper.hasGraphAPIAccess(email);


        GraphApiAccessCache entry = cacheRepo.findByRoomEmail(email)
                .orElseGet(() -> {
                    GraphApiAccessCache newEntry = new GraphApiAccessCache();
                    newEntry.setRoomEmail(email);
                    return newEntry;
                });

        entry.setAccessStatus(hasAccess);
        entry.setLastCheckedAt(LocalDateTime.now());
        cacheRepo.save(entry);

    }

    /**
     * @param emails List of email associated with meeting rooms
    */
    public void graphAccessStatuses(List<String> emails) {
        ExecutorService executor = Executors.newFixedThreadPool(20);
        for (String email : emails) {
            executor.submit(() -> {
                if (email != null && !email.trim().isEmpty()) {
                    refreshSingleStatus(email);

                }
            });
        }
        executor.shutdown();
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

}
