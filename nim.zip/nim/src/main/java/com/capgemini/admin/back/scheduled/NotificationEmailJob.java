package com.capgemini.admin.back.scheduled;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.capgemini.admin.back.mapper.NotificationEmailMapper;
import com.capgemini.admin.back.model.ConfigValue;
import com.capgemini.admin.back.model.NotificationEmail;
import com.capgemini.admin.back.model.NotificationEmailDTO;
import com.capgemini.admin.back.model.NotificationEmailSent;
import com.capgemini.admin.back.service.ConfigService;
import com.capgemini.admin.back.service.NotificationEmailSentService;
import com.capgemini.admin.back.service.NotificationEmailService;
import com.capgemini.admin.back.config.Constants;
import java.util.concurrent.atomic.AtomicBoolean;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class NotificationEmailJob extends ScheduledJob<NotificationEmail, NotificationEmailSent> {

    @Autowired
    private NotificationEmailService notificationEmailService;

    @Autowired
    private NotificationEmailSentService notificationEmailSentService;

    @Autowired
    private ConfigService configService;

    
//  Prevent parallel execution
    private static final AtomicBoolean running = new AtomicBoolean(false);


    /**
     * Executes the scheduled job based on the specified cron expression and time
     * zone.
     */
    @Scheduled(cron = "${" + Constants.CONFIG_PATH_NOTIFICATION_EMAIL + ".cron}", zone = "${"
            + Constants.CONFIG_PATH_NOTIFICATION_EMAIL + ".tz}")
    
 public void execJob() {

        String jobName = "NotificationEmailJob";

        // LOCK
        if (!running.compareAndSet(false, true)) {
            log.warn(">>> [{}] already running → skipping | Thread={}",
                    jobName, Thread.currentThread().getName());
            return;
        }

        log.info(">>> [{}] START | Thread={}", jobName, Thread.currentThread().getName());
        
try {
            super.execJob(new Date());
        } finally {
            running.set(false);
            log.info("<<< [{}] END | Thread={}", jobName, Thread.currentThread().getName());
        }
    }



    /**
     * Retrieves a list of running scheduled notification emails.
     *
     * @return A List of NotificationEmail objects representing the running
     *         scheduled notification emails.
     */
    @Override
    protected List<NotificationEmail> getScheduledRunning() {
        return this.notificationEmailService.findAllRunning();
    }

    /**
     * Retrieves a list of the last sent scheduled notification emails.
     *
     * @return A List of NotificationEmailSent objects representing the last sent
     *         scheduled notification emails.
     */
    @Override
    protected List<NotificationEmailSent> getLastScheduledSent() {
        return this.notificationEmailSentService.findAllLast();
    }

    /**
     * Sends a scheduled notification email.
     *
     * @param notificationEmail The NotificationEmail to be sent.
     * @return true if the email is successfully sent, false otherwise.
     */
    @Override
    protected boolean sendScheduled(NotificationEmail notificationEmail) {
        // Convert NotificationEmail to NotificationEmailDTO using the Mapper
        NotificationEmailDTO notificationEmailDTO = NotificationEmailMapper.INSTANCE
                .NotificationEmailToNotificationEmailDTO(notificationEmail);
        // Define the recipient addresses
        ConfigValue configValue = this.configService.findByKeyName(Constants.NOTIFICATION_EMAIL_VALUE);
        // Check if notificationEmailDTO is not null before proceeding
        if (Objects.nonNull(notificationEmailDTO) && Objects.nonNull(configValue)) {
            List<String> addresses = List.of(configValue.getValue());
            // Attempt to send the email using the notificationEmailService
            return this.notificationEmailService.sendMail(notificationEmailDTO, addresses);
        } else {
            log.error("notificationEmailDTO is null");
            return Boolean.FALSE;
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }

    /**
     * Creates a new instance of NotificationEmailSent.
     *
     * @return A new NotificationEmailSent object.
     */
    @Override
    protected NotificationEmailSent getNewScheduledSent() {
        return new NotificationEmailSent();
    }

    /**
     * Saves a scheduled sent notification email.
     *
     * @param notificationEmailSent The NotificationEmailSent to be saved.
     */
    @Override
    protected void saveScheduledSent(NotificationEmailSent notificationEmailSent) {
        this.notificationEmailSentService.save(notificationEmailSent);
    }

    /**
     * Stops a scheduled notification email.
     *
     * @param notificationEmail The NotificationEmail to be stopped.
     */
    @Override
    protected void stopScheduled(NotificationEmail notificationEmail) {
        this.notificationEmailService.stop(notificationEmail);
    }

    @Override
    protected void endJob(List<NotificationEmail> scheduledList) {
        this.notificationEmailService.setProcessed(scheduledList);
    }

}