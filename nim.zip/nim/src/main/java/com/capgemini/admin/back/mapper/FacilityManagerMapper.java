package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.FacilityManager;
import com.capgemini.admin.back.model.FacilityManagerDTO;

@Named("FacilityManagerMapper")
@Mapper(config = DtoMapperConfig.class)
public interface FacilityManagerMapper {

    FacilityManagerMapper INSTANCE = Mappers.getMapper(FacilityManagerMapper.class);

    FacilityManager facilityManagerDTOToFacilityManager(FacilityManagerDTO in);

    FacilityManagerDTO facilityManagerToFacilityManagerDTO(FacilityManager in);

}
