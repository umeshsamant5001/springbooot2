package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.SpaceType;

@Repository
public interface SpaceTypeRepository extends JpaRepository<SpaceType, Long> {

    // Find all SpaceTypes ordered by name ascending
    public List<SpaceType> findAllByOrderBySpaceTypeNameAsc();

    // Query to get an existing SpaceType by ID and name using native SQL
    @Query(value = "SELECT * FROM space_type WHERE id = :spaceTypeId AND space_type_name = :spaceTypeName", nativeQuery = true)
    public Optional<SpaceType> getExistingIdAndName(@Param("spaceTypeId") Long spaceTypeId,
            @Param("spaceTypeName") String spaceTypeName);

    @Query(value = "SELECT * FROM space_type WHERE id = :id", nativeQuery = true)
    Optional<SpaceType> findById(@Param("id") Long id);

    @Query(value = "SELECT st.* FROM space_type st " +
            " WHERE st.id = :spaceTypeId " +
            " AND EXISTS (" +
            "   SELECT 1 FROM poi p " +
            "   LEFT JOIN floor f ON f.id = p.floor_id " +
            "   LEFT JOIN building b ON b.id = f.building_id " +
            "   LEFT JOIN site s ON s.id = b.site_id " +
            "   LEFT JOIN city c ON c.id = s.city_id " +
            "   LEFT JOIN country co ON co.id = c.country_id " +
            "   WHERE p.space_type_id = st.id " +
            "   AND (co.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) " +
            "   OR c.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) " +
            "   OR s.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) " +
            "   OR b.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)))", nativeQuery = true)
    Optional<SpaceType> findAuthorizedByIdForUser(@Param("spaceTypeId") Long spaceTypeId, @Param("userId") Long userId);


    @Query("SELECT poiGroup.id as poiGroupId, COUNT(*) as nbSpaceTypes " +
            "FROM SpaceType spaceType " +
            "INNER JOIN spaceType.poiGroup poiGroup " +
            "GROUP BY poiGroup.id")
    List<Tuple> countByPoiGroup();


    @Query(value = "SELECT st.* FROM space_type st " +
            "JOIN category_mapping cm ON st.id = cm.space_type_id " +
            "WHERE LOWER(cm.category) IN (:categories)", nativeQuery = true)
    List<SpaceType> findByCategory(
            @Param("categories") List<String> categories);

}
