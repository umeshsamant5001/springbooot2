package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.NotificationLocation;
import com.capgemini.admin.back.model.NotificationLocationDTO;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface NotificationLocationMapper {
    NotificationLocationMapper INSTANCE = Mappers.getMapper(NotificationLocationMapper.class);

    @Mapping(source = "notificationId", target = "notification.id")
    NotificationLocation toEntity(NotificationLocationDTO dto);

    List<NotificationLocation> toEntityList(List<NotificationLocationDTO> notificationLocationsDto);
}
