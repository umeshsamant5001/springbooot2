package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Map;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.CiscoDevice;

@Repository
public interface CiscoDeviceRepository extends JpaRepository<CiscoDevice, Long> {

        @Query(value = "SELECT cd.ip_address AS ipAddress, cd.people_count AS peopleCount, " +
                        "cd.ambient_noise_dBA AS ambientNoiseDba, cd.sound_level_dBA AS soundLevelDba, " +
                        "cd.ambient_temperature AS ambientTemperature, cd.relative_humidity AS relativeHumidity, " +
                        "cd.air_quality AS airQuality, cd.mac_address AS deviceId, " +
                        "cd.device_type AS deviceType, cd.hour AS lastDataReceived, p.name AS poiName, " +
                        "p.title_en AS poiTitle, st.space_type_name  AS poiType " +
                        "FROM poi p " +
                        "INNER JOIN poi_attributes pa ON p.id = pa.poi_id " +
                        "INNER JOIN cisco_device cd ON cd.email_id = pa.att_value  " +
                        "INNER JOIN space_type st ON p.space_type_id = st.id " +
                        "WHERE p.name = :poiName", nativeQuery = true)
        List<Map<String, Object>> findCiscoDevicesByPoiName(@Param("poiName") String poiName);

        /**
         * Executes a native SQL query to retrieve Cisco device details for a given
         * floor ID.
         * The query joins POI, POI attributes, Cisco device mapping, and Cisco device
         * tables.
         *
         * @param floorId the ID of the floor to filter devices by
         * @return a list of maps containing device details such as UUID, device type,
         *         last change timestamp,
         *         POI name, POI ID, and floor ID
         */
        @Query(value = "SELECT cd.mac_address AS uuid, cd.device_type AS deviceType, " +
                        "DATEDIFF(SECOND, '1970-01-01', cd.hour) AS lastChange, " +
                        "p.name AS poiName, p.id AS poiId, p.floor_id AS floorId " +
                        "FROM poi p " +
                        "INNER JOIN poi_attributes pa ON p.id = pa.poi_id " +
                        "INNER JOIN cisco_device cd ON cd.email_id = pa.att_value " +
                        "WHERE p.floor_id = :floorId", nativeQuery = true)
        public List<Map<String, Object>> getCiscoDevicesByFloorId(@Param("floorId") Long floorId);

        @Query(value = "SELECT " +
                        "cd.mac_address AS deviceId, cd.ip_address AS ipAddress, cd.device_type AS deviceType, " +
                        "cd.people_count AS peopleCount, cd.ambient_noise_dBA AS ambientNoiseDba, " +
                        "cd.sound_level_dBA AS soundLevelDba, cd.ambient_temperature AS ambientTemperature, " +
                        "cd.relative_humidity AS relativeHumidity, cd.air_quality AS airQuality, cd.hour AS lastDataReceived, "
                        + // Added macAddress as deviceId
                        "p.name AS poiName, p.title_en AS poiTitle, s.space_type_name AS poiType " +
                        "FROM cisco_device cd " +
                        "JOIN poi_attributes pa ON cd.email_id = pa.att_value " +
                        "JOIN poi p ON pa.poi_id = p.id " +
                        "JOIN space_type s ON p.space_type_id = s.id " +
                        "JOIN floor f ON p.floor_id = f.id " +
                        "WHERE (:buildingId IS NULL OR f.building_id = :buildingId) " +
                        "ORDER BY cd.mac_address ASC ", nativeQuery = true)
        List<Map<String, Object>> getPaginatedCiscoDevices(@Param("buildingId") Long buildingId);

        @Query(value = "SELECT COUNT(*) FROM cisco_device cd " +
                        "JOIN poi_attributes pa ON cd.email_id = pa.att_value " +
                        "JOIN poi p ON pa.poi_id = p.id " +
                        "JOIN space_type s ON p.space_type_id = s.id " +
                        "JOIN floor f ON p.floor_id = f.id " +
                        "WHERE (:buildingId IS NULL OR f.building_id = :buildingId) ", nativeQuery = true)
        Long countCiscoDevices(@Param("buildingId") Long buildingId);

        @Query(value = "SELECT cd.country AS country,cd.city AS city, cd.site AS site, cd.building AS building, " + 
                "cd.mac_address AS deviceId,cd.device_type deviceType, "+
                "p.name AS poiName, p.title_en AS poiTitle, " + 
                "cd.email_id AS emailId , attributes.capacity AS capacity " + 
                "FROM cisco_device AS cd " + 
                "LEFT JOIN poi_attributes AS pa ON cd.email_id = pa.att_value " +
                "LEFT JOIN poi AS p ON pa.poi_id = p.id " + 
                "LEFT JOIN( SELECT * FROM ( SELECT poi_id, att_key, att_value FROM poi_attributes ) AS attributes_source " + 
                                "PIVOT( MAX(att_value) FOR att_key IN (capacity) ) AS result_attributes " + 
                        " ) AS attributes ON (attributes.poi_id = p.id)", nativeQuery = true)
        List<List<String>> fetchExportCiscoDevices();
}
