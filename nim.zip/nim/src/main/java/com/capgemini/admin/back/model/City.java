package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "city", indexes = { @Index(name = "IDX_MODIFIED_CITY", columnList = "modified_at") })
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class City implements WithTitle {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "City_Generator")
	@SequenceGenerator(name = "City_Generator", sequenceName = "City_Sequence")
	private Long id;

	@OneToMany(mappedBy = "city", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<Site> sites = new ArrayList<>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_id")
	@JsonIgnore
	private Country country;

	@Column(name = "country_id", updatable = false, insertable = false)
	private Long countryId;

	@Column(name = "modified_at", nullable = false, columnDefinition = Constants.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime() / 1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;

	@Column(name = "title_fr")
	private String titleFr;

	@Column(name = "title_en")
	private String titleEn;

	@Column(name = "cdm_state_id")
	private Long cdmStateId;

	@CollectionTable(name = "city_attribute", joinColumns = @JoinColumn(name = "city_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

	@Override
	public String toString() {
		return "City{" +
				"id=" + id +
				", titleFr='" + titleFr + '\'' +
				", titleEn='" + titleEn + '\'' +
				// Exclude lazy association
				'}';
	}

}
