package com.capgemini.admin.back.service;

import com.capgemini.admin.back.model.AppRegistrationManagement;
import com.capgemini.admin.back.model.EnumOsType;
import com.capgemini.admin.back.repository.DeviceTokenRepository;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.BatchResponse;
import com.google.firebase.messaging.SendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.core.env.Environment;
import java.util.Arrays;


@Service
@Slf4j
public class DeviceTokenService {

  private boolean isInitialize = false;

  @Autowired
  private DeviceTokenRepository deviceTokenRepository;

  @Autowired
  private Environment environment;

  /**
   * Initializes Firebase apps for Android and iOS using environment-specific service account credentials.
   * Ensures initialization is performed only once per application lifecycle.
   */
  public void initialize() {
    if (this.isInitialize) {
      return;
    }

    this.isInitialize = true;
    String androidServiceAccountFile = null;
    String iosServiceAccountFile = null;

    try {
      if (isDev() || isLocal()) {
        androidServiceAccountFile = "service-account_android.json";
        iosServiceAccountFile = "service-account_ios.json";
      } else if (isSit()) {
        androidServiceAccountFile = "service-account_android_sit.json";
        iosServiceAccountFile = "service-account_ios_sit.json";
      } else if (isUat()) {
        androidServiceAccountFile = "service-account_android_uat.json";
        iosServiceAccountFile = "service-account_ios_uat.json";
      } else if (isProd()) {
        androidServiceAccountFile = "service-account_android_prod.json";
        iosServiceAccountFile = "service-account_ios_prod.json";
      }

      try (InputStream androidServiceAccount = getResolvedServiceAccountStream(androidServiceAccountFile);
           InputStream iosServiceAccount = getResolvedServiceAccountStream(iosServiceAccountFile)) {

        FirebaseOptions androidOptions = FirebaseOptions.builder()
            .setCredentials(GoogleCredentials.fromStream(androidServiceAccount))
            .build();

        FirebaseOptions iosOptions = FirebaseOptions.builder()
            .setCredentials(GoogleCredentials.fromStream(iosServiceAccount))
            .build();


        // Initialize the Android app with the name "androidApp"
        FirebaseApp.initializeApp(androidOptions, "androidApp");

        // Initialize the iOS app with the name "iosApp"
        FirebaseApp.initializeApp(iosOptions, "iosApp");
      }

      log.info("Initialization done");
    } catch (Exception e) {
      log.error("Error while initalized {}", e);
    }
  }


  /**
   * Retrieves all device registration tokens for a given OS type (Android or iOS).
   *
   * @param deviceType the type of device (EnumOsType)
   * @return a list of registration tokens for the specified device type
   */
  public List<String> getDeviceRegistrationTokens(EnumOsType deviceType) {
    log.info("[GLOBAL TOKENS FETCH] OS={}", deviceType);
    List<AppRegistrationManagement> tokens = this.deviceTokenRepository.findByDeviceType(deviceType);
    if (tokens.isEmpty()) {
      return Collections.emptyList();
    }
    List<String> uniquetokens = tokens.stream()
        .map(AppRegistrationManagement::getDeviceRegistrationToken)
        .distinct()
        .collect(Collectors.toList());
        
        log.info("[GLOBAL TOKENS] total={}, unique={}",
            tokens.size(), uniquetokens.size());

    return uniquetokens;
  }

  /**
   * Handles failed push notification tokens from a Firebase BatchResponse.
   * Logs and returns the list of tokens that failed to receive the notification.
   *
   * @param response the Firebase BatchResponse containing individual send results
   * @param registrationTokens the original list of tokens used in the request
   * @param platform the platform name (e.g., "Android", "iOS") for logging purposes
   * @return a list of tokens that failed to receive the notification
   */
  public List<String> handleFailedTokens(BatchResponse response, List<String> registrationTokens, String platform) {
    List<SendResponse> responses = response.getResponses();
    List<String> failedTokens = new ArrayList<>();
    for (int i = 0; i < responses.size(); i++) {
      if (!responses.get(i).isSuccessful()) {
        failedTokens.add(registrationTokens.get(i));
        log.info("List of tokens that caused failures for " + platform + ": " + failedTokens);
      }
    }
    return failedTokens;
  }

  /**
   * Retrieves a list of device tokens filtered by the specified device type and
   * country.
   * 
   * @param deviceType the type of device operating system (e.g., ANDROID, IOS)
   * @param country    the country code or name used to filter device tokens
   * @return a list of device tokens matching the specified criteria
   */
  public List<String> getDeviceTokensByDeviceTypeAndCountry(EnumOsType deviceType, String country) {
    String safeCountry = sanitizeForLog(country);
    log.info("[TOKEN FETCH] Getting tokens for OS={} and country='{}'", deviceType, safeCountry);
    List<String> tokens = deviceTokenRepository.findDeviceTokensByDeviceTypeAndCountry(deviceType.toString(), country);
    log.info("[TOKEN FETCH] Found {} tokens", tokens.size());
    
 List<String> uniqueTokens = tokens.stream()
            .distinct() 
            .collect(Collectors.toList());

    log.info("[COUNTRY TOKENS] total={}, unique={}",
            tokens.size(), uniqueTokens.size());

    return uniqueTokens;
  }


  private String sanitizeForLog(String input) {
    if (input == null) {
      return "";
    }
    return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
  }

  private InputStream getResolvedServiceAccountStream(String serviceAccountFile) throws Exception {
    try (InputStream rawStream = new ClassPathResource(serviceAccountFile).getInputStream()) {
      String content = new String(rawStream.readAllBytes(), StandardCharsets.UTF_8);
      String resolvedContent = this.environment.resolveRequiredPlaceholders(content);
      return new ByteArrayInputStream(resolvedContent.getBytes(StandardCharsets.UTF_8));
    }
  }


  public boolean isLocal() {
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("local"::equals);
  }


  public boolean isDev() {
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("develop"::equals);
  }

  public boolean isSit() {
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("sit"::equals);
  }

  public boolean isUat() {
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("uat"::equals);
  }

  public boolean isProd() {
    return Arrays.stream(this.environment.getActiveProfiles()).anyMatch("production"::equals);
  }
}