package com.capgemini.admin.back.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.ColumnDefault;

import lombok.Data;

@Data
@Embeddable
public class BuildingInformation implements Serializable {

	@Column(name = "address")
	private String address;

	@Column(name = "city")
	private String city;

	@Column(name = "country")
	private String country;

	@Column(name = "phone")
	private transient String phone;

	@Column(name = "reception_mail")
	private String receptionMail;

	@Transient
	private String infoUrl;

	@Column(name = "ldap_name")
	private String ldapName;

	@Column(name = "capacity")
	private String capacity;

	@Column(name = "desk_limit_crowded")
	private Long deskLimitCrowded;

	@Column(name = "minimum_desk_area")
	private Double minimumDeskArea;

	@Column(name = "minTemp")
	private Integer minTemp;

	@Column(name = "maxTemp")
	private Integer maxTemp;

	@Enumerated(EnumType.STRING)
	@Column(name = "tempFormat")
	private TemperatureUnit tempFormat;

	@Enumerated(EnumType.STRING)
	@Column(name = "timeFormat")
	private TimeFormat timeFormat;

	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_opening_hours")
	private OpeningHours openingHours;

	@Column(name = "limit_in_day")
	private Long limitInDay = 15L;

	@Column(name = "global", nullable = false)
	@ColumnDefault("0")
	private Boolean global = Boolean.FALSE;

	public void format() {
		this.phone = "".equals(this.phone) ? null : this.phone;
		this.receptionMail = "".equals(this.receptionMail) ? null : this.receptionMail;
	}

}
