package com.capgemini.admin.back.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "device_sp")
public class DeviceSP {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int rowId;
    private String uuid;
    private String poiName;
    private String poiTitle;
    private String deviceType;
    private String spaceTypeName;
    private String status;
    private long lastChange;
    private int floorId;
    private String attKey;
    private String attValue;
}
