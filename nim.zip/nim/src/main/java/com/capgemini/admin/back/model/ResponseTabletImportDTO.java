package com.capgemini.admin.back.model;

import java.util.List;
import lombok.Data;
import java.util.Objects;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;


@Data
@Slf4j
public class ResponseTabletImportDTO {

    private List<TabletImportDTO> tabletImportDTOs;
    private List<String> errorsInFile;

    public ResponseTabletImportDTO() {
        this.tabletImportDTOs = new ArrayList<>();
    }

    public void addError(String error) {
        log.debug("Tablet import validation error recorded");
        if (Objects.isNull(this.errorsInFile)) {
            this.errorsInFile = new ArrayList<>();
        }
        this.errorsInFile.add(error);
    }


    public void addTablet(TabletImportDTO tablet) {
        this.tabletImportDTOs.add(tablet);
    }
}
