package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;


import javax.persistence.EntityNotFoundException;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;



import com.capgemini.admin.back.model.PoiGroup;
import com.capgemini.admin.back.model.PoiGroupUpsertInput;
import com.capgemini.admin.back.model.SpaceType;

import com.capgemini.admin.back.repository.PoiGroupRepository;
import com.capgemini.admin.back.repository.SpaceTypeRepository;


@Service
public class PoiGroupService {

    private static final Logger log = LoggerFactory.getLogger(PoiGroupService.class);
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";


    @Autowired
    private PoiGroupRepository poiGroupRepository;


    @Autowired
    private SpaceTypeRepository spaceTypeRepository;

    public List<PoiGroup> getOrderedPoiGroups() {
        return this.poiGroupRepository.findAllByOrderByNameAsc();
    }

   
    /**
     * Retrieves a PoiGroup by its ID along with its associated SpaceTypes.
     * Ensures that the SpaceTypes are initialized if they are lazily loaded.
     *
     * @param id The ID of the PoiGroup to retrieve.
     * @return The PoiGroup entity with its SpaceTypes initialized.
     */
    @Transactional
    public PoiGroup getPoiGroupById(Long id) {
        try {
            PoiGroup poiGroup = poiGroupRepository.findByIdWithSpaceTypes(id)
                    .orElseThrow(() -> new ResourceNotFoundException("PoiGroup not found"));
            // Force initialization of spaceTypes if lazy-loaded
            if (poiGroup.getSpaceTypes() != null) {
                poiGroup.getSpaceTypes().size();
            }

            return poiGroup;
        } catch (IllegalArgumentException ex) {
            log.error("Invalid PoiGroup id provided: {}", id, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid PoiGroup id.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve PoiGroup by id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve PoiGroup.");
        }
    }

   
    /**
     * Updates an existing PoiGroup with new data, including its associated SpaceTypes.
     * Handles reassignment and detachment of SpaceTypes as needed.
     *
     * @param id The ID of the PoiGroup to update.
     * @param updatedData The new data to update the PoiGroup with.
     * @return The updated PoiGroup entity.
     */
    @Transactional
    public PoiGroup updatePoiGroup(Long id, PoiGroupUpsertInput updatedData) {
        PoiGroup existingGroup = poiGroupRepository.findByIdWithSpaceTypes(id)
                .orElseThrow(() -> new EntityNotFoundException("PoiGroup not found with id: " + id));

        PoiGroupUpsertInput sanitizedInput = this.sanitizePoiGroupUpsertInput(updatedData);

        // Update basic fields
        existingGroup.setName(sanitizedInput.getName() == null ? null : new String(sanitizedInput.getName()));
        existingGroup.setAttributeKeys(this.sanitizeAttributeKeys(sanitizedInput.getAttributeKeys()));
        existingGroup.setAttributes(this.sanitizeAttributes(sanitizedInput.getAttributes()));
        existingGroup.setTitleFr(sanitizedInput.getTitleFr() == null ? null : new String(sanitizedInput.getTitleFr()));
        existingGroup.setTitleEn(sanitizedInput.getTitleEn() == null ? null : new String(sanitizedInput.getTitleEn()));
        existingGroup.setIsFromCdm(sanitizedInput.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedInput.getIsFromCdm())));
        existingGroup.setIsVisibleOnPWA(sanitizedInput.getIsVisibleOnPWA() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedInput.getIsVisibleOnPWA())));

        // Set default value for icon if it's not provided
        if (sanitizedInput.getIcon() == null || sanitizedInput.getIcon().isEmpty()) {
            existingGroup.setIcon("default.svg");
        } else if (sanitizedInput.getIcon().matches(".*\\.svg$")) {
            existingGroup.setIcon(new String(sanitizedInput.getIcon()));
        }

        // Get existing SpaceTypes from the database
        List<SpaceType> existingSpaceTypes = existingGroup.getSpaceTypes();
        List<Long> updatedSpaceTypeIds = sanitizedInput.getSpaceTypeIds().stream()
                .filter(spaceTypeId -> spaceTypeId != null)
                .map(spaceTypeId -> Long.valueOf(spaceTypeId))
                .collect(Collectors.toList());

        // Detach SpaceTypes that are no longer in the update request
        List<SpaceType> spaceTypesToDetach = existingSpaceTypes.stream()
                .filter(spaceType -> !updatedSpaceTypeIds.contains(spaceType.getId()))
                .collect(Collectors.toList());

        for (SpaceType spaceType : spaceTypesToDetach) {
            spaceType.setPoiGroup(null);
        }
        spaceTypeRepository.saveAll(spaceTypesToDetach);

        if (!updatedSpaceTypeIds.isEmpty()) {
            List<SpaceType> updatedSpaceTypes = updatedSpaceTypeIds.stream()
                    .map(spaceTypeId -> {
                        SpaceType existingSpaceType = spaceTypeRepository.findById(spaceTypeId)
                                .orElseThrow(() -> new EntityNotFoundException(
                                        "SpaceType not found with id: " + spaceTypeId));
                        existingSpaceType.setPoiGroup(existingGroup);
                        return existingSpaceType;
                    })
                    .collect(Collectors.toList());
            spaceTypeRepository.saveAll(updatedSpaceTypes);
            existingGroup.setSpaceTypes(updatedSpaceTypes);
        } else {
            existingGroup.setSpaceTypes(new ArrayList<>());
        }
        return poiGroupRepository.save(existingGroup);
    }


   
    /**
     * Deletes a PoiGroup by its ID and detaches all associated SpaceTypes.
     *
     * @param poiGroupId The ID of the PoiGroup to delete.
     */
    @Transactional
    public void deletePoiGroupById(Long poiGroupId) {
        if (poiGroupId == null || poiGroupId <= 0) {
            throw new IllegalArgumentException("Invalid PoiGroup id");
        }

        Long scopedPoiGroupId = Long.valueOf(poiGroupId);

        try {
            PoiGroup poiGroup = poiGroupRepository.findByIdWithSpaceTypes(scopedPoiGroupId)
                    .orElseThrow(() -> new RuntimeException("PoiGroup not found"));

            for (SpaceType spaceType : poiGroup.getSpaceTypes()) {
                spaceType.setPoiGroup(null);
                spaceTypeRepository.save(spaceType);
            }
    
            poiGroupRepository.delete(poiGroup);
    
        } catch (DataAccessException ex) {
            log.error("Failed to delete PoiGroup with id {}", poiGroupId, ex);
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete PoiGroup.");
        }
    }

  
    /**
     * Retrieves a PoiGroup by its name.
     * @param name The name of the PoiGroup.
     * @return The PoiGroup entity if found, otherwise null.
     */
    public PoiGroup getByName(String name) {
        return this.poiGroupRepository.findByName(name).orElse(null);
    }

    /**
     * Creates a new PoiGroup and associates it with the provided SpaceTypes.
     *
     * @param poiGroupInput The PoiGroup create input.
     * @return The saved PoiGroup entity.
     */
    @Transactional
    public PoiGroup createPoiGroup(PoiGroupUpsertInput poiGroupInput) {
        PoiGroupUpsertInput sanitizedInput = this.sanitizePoiGroupUpsertInput(poiGroupInput);

        PoiGroup persistedPoiGroup = new PoiGroup();
        persistedPoiGroup.setId(null);
        persistedPoiGroup.setName(sanitizedInput.getName() == null ? null : new String(sanitizedInput.getName()));
        persistedPoiGroup.setAttributeKeys(this.sanitizeAttributeKeys(sanitizedInput.getAttributeKeys()));
        persistedPoiGroup.setAttributes(this.sanitizeAttributes(sanitizedInput.getAttributes()));
        persistedPoiGroup.setTitleFr(sanitizedInput.getTitleFr() == null ? null : new String(sanitizedInput.getTitleFr()));
        persistedPoiGroup.setTitleEn(sanitizedInput.getTitleEn() == null ? null : new String(sanitizedInput.getTitleEn()));
        persistedPoiGroup.setIsFromCdm(sanitizedInput.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedInput.getIsFromCdm())));
        persistedPoiGroup.setIsVisibleOnPWA(sanitizedInput.getIsVisibleOnPWA() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedInput.getIsVisibleOnPWA())));

        if (sanitizedInput.getIcon() == null || sanitizedInput.getIcon().isEmpty()) {
            persistedPoiGroup.setIcon("default.svg");
        } else if (sanitizedInput.getIcon().matches(".*\\.svg$")) {
            persistedPoiGroup.setIcon(new String(sanitizedInput.getIcon()));
        }

        PoiGroup savedPoiGroup = poiGroupRepository.save(persistedPoiGroup);

        if (sanitizedInput.getSpaceTypeIds() != null && !sanitizedInput.getSpaceTypeIds().isEmpty()) {
            List<SpaceType> updatedSpaceTypes = sanitizedInput.getSpaceTypeIds().stream()
                    .filter(spaceTypeId -> spaceTypeId != null)
                    .map(spaceTypeId -> {
                        Optional<SpaceType> existingSpaceTypeOpt = spaceTypeRepository
                                .findById(spaceTypeId);

                        if (existingSpaceTypeOpt.isPresent()) {
                            SpaceType existingSpaceType = existingSpaceTypeOpt.get();
                            existingSpaceType.setPoiGroup(savedPoiGroup);
                            existingSpaceType.setPoiGroupId(savedPoiGroup.getId());

                            return existingSpaceType;
                        } else {
                            throw new IllegalArgumentException(
                                    "SpaceType with ID " + spaceTypeId + " not found.");
                        }
                    })
                    .collect(Collectors.toList());
            spaceTypeRepository.saveAll(updatedSpaceTypes);
        }

        return savedPoiGroup;
    }

   
    /**
     * Finds the name of the PoiGroup associated with a given SpaceType ID.
     *
     * @param spaceTypeId The ID of the SpaceType.
     * @return An Optional containing the PoiGroup name if found.
     */
    public Optional<String> findBySpaceTypeId(Long spaceTypeId) {
        try {
            return this.poiGroupRepository.findBySpaceTypeId(spaceTypeId);
        } catch (IllegalArgumentException ex) {
            log.error("Invalid SpaceType id provided: {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid SpaceType id.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve PoiGroup by SpaceType id {}", spaceTypeId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve PoiGroup.");
        }
    }

    private PoiGroupUpsertInput sanitizePoiGroupUpsertInput(PoiGroupUpsertInput source) {
        if (source == null) {
            throw new IllegalArgumentException("PoiGroup input must not be null");
        }

        PoiGroupUpsertInput sanitized = new PoiGroupUpsertInput();
        sanitized.setName(validateOptionalText(source.getName(), 255, "name"));
        sanitized.setAttributeKeys(sanitizeAttributeKeys(source.getAttributeKeys()));
        sanitized.setAttributes(sanitizeAttributes(source.getAttributes()));
        sanitized.setTitleFr(validateOptionalText(source.getTitleFr(), 255, "titleFr"));
        sanitized.setTitleEn(validateOptionalText(source.getTitleEn(), 255, "titleEn"));
        sanitized.setIsFromCdm(source.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(source.getIsFromCdm())));
        sanitized.setIsVisibleOnPWA(source.getIsVisibleOnPWA() == null
                ? null
                : Boolean.valueOf(String.valueOf(source.getIsVisibleOnPWA())));
        sanitized.setIcon(validateOptionalIcon(source.getIcon()));

        List<Long> safeSpaceTypeIds = new ArrayList<>();
        if (source.getSpaceTypeIds() != null) {
            source.getSpaceTypeIds().forEach(spaceTypeId -> {
                if (spaceTypeId != null && spaceTypeId > 0) {
                    safeSpaceTypeIds.add(Long.valueOf(spaceTypeId));
                }
            });
        }
        sanitized.setSpaceTypeIds(safeSpaceTypeIds);

        return sanitized;
    }

    private String validateOptionalText(String value, int maxLength, String fieldName) {
        if (value == null) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            return null;
        }

        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid " + fieldName + ".");
        }

        return new String(validated);
    }

    private String validateOptionalIcon(String icon) {
        if (icon == null) {
            return null;
        }

        String validated = new String(String.valueOf(icon).trim());
        if (validated.isEmpty()) {
            return null;
        }

        if (validated.length() > 255 || !validated.matches("^[^\\r\\n\\t\\p{Cntrl}]*\\.svg$")) {
            throw new IllegalArgumentException("Invalid icon.");
        }

        return new String(validated);
    }

    private List<String> sanitizeAttributeKeys(List<String> attributeKeys) {
        List<String> sanitized = new ArrayList<>();
        if (attributeKeys == null) {
            return sanitized;
        }

        for (String key : attributeKeys) {
            String validated = validateOptionalText(key, 255, "attributeKey");
            if (validated != null) {
                sanitized.add(new String(validated));
            }
        }

        return sanitized;
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<>();
        if (attributes == null) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            String validatedKey = validateOptionalText(key, 255, "attributeKey");
            String validatedValue = validateOptionalText(value, 1000, "attributeValue");
            if (validatedKey != null && validatedValue != null) {
                sanitized.put(new String(validatedKey), new String(validatedValue));
            }
        });

        return sanitized;
    }
}
