package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.Objects;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.mapper.ErrorLoggingMapper;
import com.capgemini.admin.back.model.EnumErrorLoggingType;
import com.capgemini.admin.back.model.EnumErrorType;
import com.capgemini.admin.back.model.ErrorLogging;
import com.capgemini.admin.back.model.ErrorLoggingDTO;
import com.capgemini.admin.back.service.ErrorLoggingService;
import com.capgemini.admin.back.service.ErrorLoggingService.ErrorLoggingUpsertInput;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@RestController
@RequestMapping(value = ErrorLoggingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class ErrorLoggingController {

	static final String ROOT_API = "api/errorlogging";
	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	@JsonIgnoreProperties(ignoreUnknown = false)
	@Data
	private static class ErrorLoggingCreateInput {
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String className;
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String module;
		@Min(0)
		private Integer lineNumber;
		@Size(max = 10000)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String description;
		@Size(max = 255)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String state;
		private EnumErrorType errorType;
		@Size(max = 10000)
		@Pattern(regexp = SAFE_TEXT_REGEX)
		private String data;
		@Min(0)
		private Long loggingDate;
		private EnumErrorLoggingType errorLoggingType;
	}

	@Autowired
	private ErrorLoggingService errorloggingService;


	@GetMapping
	public ResponseEntity<List<ErrorLoggingDTO>> getAll(
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
		return ResponseEntity.ok(this.errorloggingService.errorloggingListToErrorLoggingDTOList()
				.apply(this.errorloggingService.getAll()));
	}

	@PostMapping
	public ResponseEntity<ErrorLoggingDTO> createErrorLogging(
			@Valid @RequestBody ErrorLoggingCreateInput errorloggingInput,
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

		if (Objects.isNull(errorloggingInput)) {
			return ResponseEntity.badRequest().build();
		}

		ErrorLoggingUpsertInput safeErrorLoggingInput = this.toErrorLoggingInput(errorloggingInput);

		ErrorLogging errorlogging = this.errorloggingService.createErrorLogging(safeErrorLoggingInput);



		if (Objects.isNull(errorlogging)) {
			return ResponseEntity.internalServerError().build();
		}

		ErrorLoggingDTO newErrorLoggingDTO = ErrorLoggingMapper.INSTANCE.errorloggingToErrorLoggingDTO(errorlogging);
		return ResponseEntity.ok(newErrorLoggingDTO);
	}

	private ErrorLoggingUpsertInput toErrorLoggingInput(ErrorLoggingCreateInput errorloggingInput) {
		return new ErrorLoggingUpsertInput(
				errorloggingInput.getClassName() == null
						? null
						: new String(String.valueOf(errorloggingInput.getClassName())),
				errorloggingInput.getModule() == null
						? null
						: new String(String.valueOf(errorloggingInput.getModule())),
				errorloggingInput.getLineNumber() == null
						? null
						: Integer.valueOf(String.valueOf(errorloggingInput.getLineNumber())),
				errorloggingInput.getDescription() == null
						? null
						: new String(String.valueOf(errorloggingInput.getDescription())),
				errorloggingInput.getState() == null
						? null
						: new String(String.valueOf(errorloggingInput.getState())),
				errorloggingInput.getErrorType() == null
						? null
						: EnumErrorType.valueOf(String.valueOf(errorloggingInput.getErrorType().name())),
				errorloggingInput.getData() == null
						? null
						: new String(String.valueOf(errorloggingInput.getData())),
				errorloggingInput.getLoggingDate() == null
						? null
						: Long.valueOf(String.valueOf(errorloggingInput.getLoggingDate())),
				errorloggingInput.getErrorLoggingType() == null
						? null
						: EnumErrorLoggingType.valueOf(String.valueOf(errorloggingInput.getErrorLoggingType().name())));
	}

}