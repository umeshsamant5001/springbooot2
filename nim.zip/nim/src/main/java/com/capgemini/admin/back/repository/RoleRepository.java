package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(String name);

    List<Role> findAllByName(String name);

    List<Role> findAllByPrecedence(Long precedence);

    List<Role> findAll();

    @Query("SELECT r FROM Role r WHERE r.id = :id AND r.name = :roleName")
    Role findByIdAndRoleName(@Param("id") Long id, @Param("roleName") String roleName);
}
