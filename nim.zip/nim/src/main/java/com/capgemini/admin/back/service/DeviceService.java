package com.capgemini.admin.back.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.Locale;
import javax.persistence.criteria.Join;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.threeten.bp.LocalDateTime;

import com.capgemini.admin.back.mapper.DeviceMapper;
import com.capgemini.admin.back.mapper.SpaceTypeMapper;
import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.DeviceDTO;
import com.capgemini.admin.back.model.DeviceSpaceTypeDTO;
import com.capgemini.admin.back.model.EnumDeviceAttribute;
import com.capgemini.admin.back.model.EnumDeviceStatus;
import com.capgemini.admin.back.model.EnumDeviceType;
import com.capgemini.admin.back.model.EnumOrderBy;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.Poi;
import com.capgemini.admin.back.model.ResponseTabletImportDTO;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.TabletImportDTO;
import com.capgemini.admin.back.model.ThresholdConfiguration;
import com.capgemini.admin.back.repository.DeviceRepository;
import com.capgemini.admin.back.repository.FloorRepository;
import com.capgemini.admin.back.repository.PoiRepository;
import com.capgemini.admin.back.repository.SpaceTypeRepository;
import com.capgemini.admin.back.repository.ThresholdConfigurationRepository;
import com.capgemini.admin.utils.ExportCsv;
import com.capgemini.admin.back.config.DeviceConstants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DeviceService {

    @Autowired
    PoiRepository poiRepository;

    @Autowired
    DeviceRepository deviceRepository;

    @Autowired
    FloorRepository floorRepository;

    @Autowired
    ThresholdConfigurationRepository thresholdConfigurationRepository;

    @Autowired
    private SpaceTypeRepository spaceTypeRepository;

    @Autowired
    private GraphAccessCacheService graphAccessCacheService;

    /**
     * Converts a list of Device entities to DeviceDTOs, applying language-specific
     * mapping
     * and filtering attributes if the device's last change was more than a day ago.
     *
     * @param language the language to use for DTO mapping
     * @return a Function that maps List<Device> to List<DeviceDTO>
     */
    public Function<List<Device>, List<DeviceDTO>> listDeviceToDeviceDTOList(String language) {
        return in -> in
                .stream()
                .map(d -> {
                    DeviceDTO deviceDTO = DeviceMapper.INSTANCE.deviceToDeviceDTO(d, language);
                    long timestampInSeconds = Instant.now().minus(1, ChronoUnit.DAYS).getEpochSecond();
                    // Check the condition and retain only the desired keys if applicable
                    if (deviceDTO.getLastChange() != null &&
                            deviceDTO.getLastChange() <= timestampInSeconds &&
                            deviceDTO.getAttributes() != null &&
                            !deviceDTO.getAttributes().isEmpty()) {
                                deviceDTO.getAttributes().keySet().retainAll(DeviceConstants.KEYS_TO_RETAIN);

                    }
                    return deviceDTO;
                })
                .collect(Collectors.toList());
    }

    // This is absolute garbage and it shouldn't have been requested.
    public List<DeviceDTO> addTitlesToDTOs(List<DeviceDTO> dtosList) {
        // Get all poiName
        List<String> poiNameList = dtosList
                .stream()
                .filter(dto -> Objects.nonNull(dto.getPoiName()))
                .map(dto -> dto.getPoiName())
                .distinct()
                .collect(Collectors.toList());

        // Load all Poi based on the poiName
        List<Poi> poiList = poiRepository.findAllByNameIn(poiNameList);

        return dtosList
                .stream()
                .peek(dto -> {
                    String poiName = dto.getPoiName();

                    if (Objects.isNull(poiName)) {
                        return;
                    }

                    poiList
                            .stream()
                            // Find the poi with the corresponding poiName
                            .filter(poi -> poiName.equals(poi.getName()))
                            .findFirst()
                            // If the poi is found, we put the title to the Device
                            .ifPresent(poiFound -> dto.setPoiTitle(poiFound.getTitleEn()));
                })
                .collect(Collectors.toList());
    }

    /**
     * Counts the number of devices in a building filtered by device types and
     * optionally by status.
     *
     * @param buildingId the ID of the building
     * @param deviceType the list of device types to include
     * @param status     optional device status to filter by
     * @return the count of matching devices
     */
    public Long countDevice(Long buildingId, List<EnumDeviceType> deviceType, EnumDeviceStatus status) {
        Specification<Device> spec1 = (root, criteriaQuery, criteriaBuilder) -> {
            Join<Device, Floor> floorRelation = root.join("floor");
            return criteriaBuilder.equal(floorRelation.get("buildingId"), buildingId);
        };
        Specification<Device> spec2 = (root, criteriaQuery, criteriaBuilder) -> {
            return root.get("deviceType").in(deviceType);
        };
        Specification<Device> specs = Specification.where(spec1).and(spec2);
        if (Objects.nonNull(status)) {
            Specification<Device> spec3 = (root, criteriaQuery, criteriaBuilder) -> {
                return root.get("status").in(status);
            };
            specs = Specification.where(spec1).and(spec2).and(spec3);
        }
        return deviceRepository.count(specs);
    }

    /**
     * Calculates the average value of a specific attribute (e.g., temperature or
     * state)
     * for devices in a given building, filtered by space type categories.
     *
     * @param buildingId    the ID of the building
     * @param attributeName the attribute to calculate the average for (e.g.,
     *                      "tempC", "state")
     * @param category      the list of space type categories to filter by
     * @return a map containing the average and related values
     */
    public Map<String, Float> calculAverageByBuildingId(Long buildingId, String attributeName, List<String> category) {
        List<SpaceType> spaceTypeList;
        spaceTypeList = spaceTypeRepository.findByCategory(category);

        List<String> spaceTypeNameList = spaceTypeList.stream().map(SpaceType::getSpaceTypeName)
                .collect(Collectors.toList());
        try {
            return calculAverage(
                    attributeName,
                    () -> deviceRepository.findAverageTempByBuildingId(buildingId, attributeName, spaceTypeNameList),
                    () -> deviceRepository.countStateFreeByBuildingId(buildingId, attributeName, spaceTypeNameList),
                    () -> deviceRepository.countStateAttributeByBuildingId(buildingId, attributeName,
                            spaceTypeNameList));
        } catch (DataAccessException ex) {
            log.error("Failed to calculate device average by buildingId {}", buildingId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to calculate device average.");
        }
    }

    /**
     * Calculates the average value of a specific attribute for devices across
     * multiple floors,
     * filtered by space type categories.
     *
     * @param floorIds      the list of floor IDs
     * @param attributeName the attribute to calculate the average for
     * @param category      the list of space type categories to filter by
     * @return a map containing the average and related values
     */
    public Map<String, Float> calculAverageByFloorIds(List<Long> floorIds, String attributeName,
            List<String> category) {
        List<SpaceType> spaceTypeList;
        spaceTypeList = spaceTypeRepository.findByCategory(category);
        List<String> spaceTypeNameList = spaceTypeList.stream().map(SpaceType::getSpaceTypeName)
                .collect(Collectors.toList());
        try {
            return calculAverage(
                    attributeName,
                    () -> deviceRepository.findAverageTempByFloorIds(floorIds, attributeName, spaceTypeNameList),
                    () -> deviceRepository.countStateFreeByFloorIds(floorIds, attributeName, spaceTypeNameList),
                    () -> deviceRepository.countStateAttributeByFloorIds(floorIds, attributeName, spaceTypeNameList));
        } catch (DataAccessException ex) {
            log.error("Failed to calculate device average by floorIds {}", floorIds, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to calculate device average.");
        }
    }

    /**
     * Helper method to compute average values based on the attribute type.
     * Supports temperature and state-based calculations.
     *
     * @param attributeName      the attribute to calculate
     * @param supplierTemp       supplier for temperature average
     * @param supplierStateFree  supplier for free state count
     * @param supplierStateTotal supplier for total state count
     * @return a map with calculated average and related metrics
     */
    private Map<String, Float> calculAverage(
            String attributeName,
            Supplier<Float> supplierTemp,
            Supplier<Integer> supplierStateFree,
            Supplier<Integer> supplierStateTotal) {
        if (attributeName.equals("tempC") || attributeName.equals("apparentTemp")) {
            Float average = supplierTemp.get();
            if (Objects.isNull(average)) {
                return null;
            }

            Map<String, Float> result = new HashMap<>();
            result.put("average", average);

            return result;
        }

        if (attributeName.equals("state")) {
            int nbFree = supplierStateFree.get();
            int nbDeviceWithStateAttribute = supplierStateTotal.get();

            float average = 0;
            if (nbDeviceWithStateAttribute > 0) {
                average = (1 - ((float) (nbFree) / (float) nbDeviceWithStateAttribute)) * 100;
            }

            Map<String, Float> result = new HashMap<>();
            result.put("free", (float) nbFree);
            result.put("total", (float) nbDeviceWithStateAttribute);
            result.put("average", average);

            return result;
        }

        return null;
    }

    /**
     * Retrieves all devices associated with a specific floor and device type via
     * POI.
     * 
     * @return a list of matching Device entities
     */
    public List<Device> findAllViaPoiByTypeIdAndFloorId(Long typeId, Long floorId) {
        try {
            return deviceRepository.findAllViaPoiByTypeIdAndFloorId(typeId, floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices via poi by typeId {} and floorId {}", typeId, floorId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve devices.");
        }
    }


    /**
     * Retrieves all devices associated with a specific floor via POI.
     * 
     * @return a list of Device entities
     */
    public List<Device> findAllViaPoiByFloorId(Long floorId) {
        try {
            return deviceRepository.findAllViaPoiByFloorId(floorId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices via poi by floorId {}", floorId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve devices.");
        }
    }

    /**
     * Retrieves all devices via POI based on combinations of type IDs, building
     * IDs, and floor IDs.
     * Applies conditional logic to determine the appropriate repository method to
     * call.
     * 
     * @return a list of matching Device entities
     */
    public List<Device> findAllViaPoiByTypeIdAndBuildingIdAndFloorId(List<Long> typeId, List<Long> buildingId,
            List<Long> floorId) {
        try {
            if (Objects.nonNull(typeId) && !typeId.isEmpty()) {
                if (Objects.nonNull(floorId) && !floorId.isEmpty()) {
                    return deviceRepository.findAllViaPoiByTypeIdAndBuildingIdAndFloorId(typeId, buildingId, floorId);
                }

                return deviceRepository.findAllViaPoiByTypeIdAndBuildingId(typeId, buildingId);
            }

            if (Objects.nonNull(floorId) && !floorId.isEmpty()) {
                return deviceRepository.findAllViaPoiByBuildingIdAndFloorId(buildingId, floorId);
            }

            return deviceRepository.findAllViaPoiByBuildingId(buildingId);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices via poi by typeIds {}, buildingIds {}, and floorIds {}", typeId, buildingId, floorId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve devices.");
        }
    }


    /**
     * Checks the format of the CSV file and returns any structural errors found.
     *
     * @param file The CSV file to be checked
     * @return A list of structural errors found during the check
     */
    public List<String> checkCSVFormat(MultipartFile file) {
        List<String> structuralErrors = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while (lineNumber <= DeviceConstants.MAX_TABLET_IMPORT_DATA_LINES + 1
                    && Objects.nonNull((line = br.readLine()))) {
                lineNumber++;
                if (lineNumber > DeviceConstants.MAX_TABLET_IMPORT_DATA_LINES + 1) {
                    structuralErrors.add(String.format(
                            "The file contains too many data lines. Maximum allowed is %s.",
                            DeviceConstants.MAX_TABLET_IMPORT_DATA_LINES));
                    return structuralErrors;
                }
                line = line.trim();

                // Strip trailing commas in a single bounded operation (avoids an
                // iteration count controlled by attacker-supplied file contents).
                line = line.replaceAll(",+$", "");
                String[] infos = line.split(",");
                // Check if it's the header line and verify its format
                if (lineNumber == 1) {
                    if (checkHeader(infos)) {
                        continue;
                    } else {
                        structuralErrors.add("Incorrect header format. Please use the correct headers.");
                        return structuralErrors;
                    }
                }
                int length = infos.length;
                // Check the number of variables in each line
                if (length != DeviceConstants.TABLET_COLUMN_COUNT) {
                    structuralErrors.add(
                            String.format(
                                    "Line %s: must contain %s variables - this line contains %s variables",
                                    lineNumber,
                                    DeviceConstants.TABLET_COLUMN_COUNT,
                                    length));
                }
            }

            if (lineNumber == 0) {
                structuralErrors.add("The file is empty.");
            } else if (lineNumber == 1) {
                structuralErrors.add("No data present in the file.");
            }
        } catch (IOException e) {
            structuralErrors.add("Error while reading the file: " + e.getMessage() + ".");
        }
        return structuralErrors;
    }

    /**
     * Generates a ResponseTabletImportDTO from the provided CSV file, adding
     * tablets and errors as needed.
     *
     * @param file The CSV file from which to generate the response DTO
     * @return The ResponseTabletImportDTO containing the imported tablets and any
     *         errors encountered
     */
    public ResponseTabletImportDTO generateResponseTabletImportDTO(MultipartFile file) {
        ResponseTabletImportDTO responseTabletImportDTO = new ResponseTabletImportDTO();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (lineNumber > DeviceConstants.MAX_TABLET_IMPORT_DATA_LINES + 1) {
                    responseTabletImportDTO.addError(String.format(
                            "The file contains too many data lines. Maximum allowed is %s.",
                            DeviceConstants.MAX_TABLET_IMPORT_DATA_LINES));
                    return responseTabletImportDTO;
                }
                // Skip the header line

                if (lineNumber == 1) {
                    continue;
                }
                // Clean trailing commas in a single bounded operation (avoids an
                // iteration count controlled by attacker-supplied file contents).
                line = line.trim();
                line = line.replaceAll(",+$", "");

                String[] tabletFromCsv = line.split(",");
                int length = tabletFromCsv.length;
                // Check the number of columns in each line
                if (length != DeviceConstants.TABLET_COLUMN_COUNT) {
                    String error = String.format("Line %s: must contain %s columns - found %s", lineNumber,
                            DeviceConstants.TABLET_COLUMN_COUNT, length);
                    responseTabletImportDTO.addError(error);
                    continue; // Skip the rest of the processing for this line
                }

                if (Objects.isNull(tabletFromCsv[DeviceConstants.IDX_POI_NAME])
                        || tabletFromCsv[DeviceConstants.IDX_POI_NAME].isEmpty()) {
                    responseTabletImportDTO
                            .addError(String.format("Line %s: Poi's name column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(tabletFromCsv[DeviceConstants.IDX_DEVICE_UUID])
                        || tabletFromCsv[DeviceConstants.IDX_DEVICE_UUID].isEmpty()) {
                    responseTabletImportDTO
                            .addError(String.format("Line %s: Device UUID column shouldn't be empty.", lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_BOOKABLE]) &&
                        !tabletFromCsv[DeviceConstants.IDX_BOOKABLE].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_BOOKABLE]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_BOOKABLE])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: Bookable column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_CHECKIN]) &&
                        !tabletFromCsv[DeviceConstants.IDX_CHECKIN].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_CHECKIN]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_CHECKIN])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: Checkin column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_CHECKIN_DURATION])
                        && !tabletFromCsv[DeviceConstants.IDX_CHECKIN_DURATION].isEmpty()) {
                    try {
                        Integer.parseInt(tabletFromCsv[DeviceConstants.IDX_CHECKIN_DURATION]);
                    } catch (NumberFormatException nfe) {
                        responseTabletImportDTO.addError(
                                String.format("Line %s: CheckInDuration column values should be an integer (or empty).",
                                        lineNumber));
                    }
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_EARLY_CHECK_IN])
                        && !tabletFromCsv[DeviceConstants.IDX_EARLY_CHECK_IN].isEmpty()) {
                    try {
                        Integer.parseInt(tabletFromCsv[DeviceConstants.IDX_EARLY_CHECK_IN]);
                    } catch (NumberFormatException nfe) {
                        responseTabletImportDTO.addError(
                                String.format("Line %s: EarlyCheckIn column values should be an integer (or empty).",
                                        lineNumber));
                    }
                }

                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_CHECK_OUT]) &&
                        !tabletFromCsv[DeviceConstants.IDX_CHECK_OUT].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_CHECK_OUT]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_CHECK_OUT])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: CheckOut column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_STATE]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_STATE].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_STATE]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_STATE])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowState column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_TEMP]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_TEMP].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_TEMP]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_TEMP])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowTemp column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_HUMIDITY]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_HUMIDITY].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_HUMIDITY]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_HUMIDITY])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowHumidity column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_SOUND]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_SOUND].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_SOUND]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_SOUND])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowSound column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_CO2]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_CO2].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_CO2]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_CO2])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowCo2 column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_SHOW_LUX]) &&
                        !tabletFromCsv[DeviceConstants.IDX_SHOW_LUX].isEmpty() &&
                        !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_LUX]) &&
                        !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_SHOW_LUX])) {
                    responseTabletImportDTO.addError(
                            String.format("Line %s: ShowLux column values should be False/True (or empty).",
                                    lineNumber));
                }
                if (Objects.nonNull(tabletFromCsv[DeviceConstants.IDX_REPORT_AN_ISSUE])
                        && !tabletFromCsv[DeviceConstants.IDX_REPORT_AN_ISSUE].isEmpty()
                        && !"true".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_REPORT_AN_ISSUE])
                        && !"false".equalsIgnoreCase(tabletFromCsv[DeviceConstants.IDX_REPORT_AN_ISSUE])) {
                    responseTabletImportDTO.addError(String.format(
                            "Line %s: REPORT AN ISSUE column values should be False/True (or empty).", lineNumber));
                }

                if (Objects.isNull(responseTabletImportDTO.getErrorsInFile())
                        || responseTabletImportDTO.getErrorsInFile().isEmpty()) {
                    try {
                        // Create TabletImportDTO from the line
                        TabletImportDTO tabletImportDTO = createTabletImportDTO(tabletFromCsv);
                        responseTabletImportDTO.addTablet(tabletImportDTO);
                    } catch (NumberFormatException e) {
                        log.error("Line {}: Error while parsing tablet import information", lineNumber, e);
                        responseTabletImportDTO
                                .addError(String.format("Line %s: Error while parsing information.", lineNumber));
                    } catch (Exception e) {
                        log.error("Line {}: Error while importing tablet", lineNumber, e);
                        responseTabletImportDTO
                                .addError(String.format("Line %s: Error while importing tablet.", lineNumber));
                    }
                }
            }
        } catch (IOException e) {
            log.error("Error while reading tablet import file", e);
            responseTabletImportDTO.addError("Error while reading the file.");
        }
        return responseTabletImportDTO;
    }

    /**
     * Checks if the provided line matches the expected header format.
     *
     * @param line The line to be checked
     * @return true if the line matches the expected header format, false otherwise
     */
    private boolean checkHeader(String[] line) {
        return (line.length == DeviceConstants.TABLET_COLUMN_COUNT &&
                DeviceConstants.HEADER_POI_NAME.equalsIgnoreCase(line[DeviceConstants.IDX_POI_NAME]) &&
                DeviceConstants.HEADER_UUID.equalsIgnoreCase(line[DeviceConstants.IDX_DEVICE_UUID]) &&
                DeviceConstants.HEADER_BOOKABLE.equalsIgnoreCase(line[DeviceConstants.IDX_BOOKABLE]) &&
                DeviceConstants.HEADER_CHECK_IN.equalsIgnoreCase(line[DeviceConstants.IDX_CHECKIN]) &&
                DeviceConstants.HEADER_CHECK_IN_DURATION.equalsIgnoreCase(line[DeviceConstants.IDX_CHECKIN_DURATION]) &&
                DeviceConstants.HEADER_EARLY_CHECK_IN.equalsIgnoreCase(line[DeviceConstants.IDX_EARLY_CHECK_IN]) &&
                DeviceConstants.HEADER_CHECK_OUT.equalsIgnoreCase(line[DeviceConstants.IDX_CHECK_OUT]) &&
                DeviceConstants.HEADER_SHOW_STATE.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_STATE]) &&
                DeviceConstants.HEADER_SHOW_TEMP.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_TEMP]) &&
                DeviceConstants.HEADER_SHOW_HUMIDITY.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_HUMIDITY]) &&
                DeviceConstants.HEADER_SHOW_SOUND.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_SOUND]) &&
                DeviceConstants.HEADER_SHOW_CO2.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_CO2]) &&
                DeviceConstants.HEADER_SHOW_LUX.equalsIgnoreCase(line[DeviceConstants.IDX_SHOW_LUX]) &&
                DeviceConstants.REPORT_AN_ISSUE.equalsIgnoreCase(line[DeviceConstants.IDX_REPORT_AN_ISSUE]));

    }

    /**
     * Creates a TabletImportDTO object from the provided CSV data.
     *
     * @param tabletFromCsv The array containing the CSV data for the tablet
     * @return The TabletImportDTO object created from the CSV data
     * @throws NumberFormatException if there is an error in number parsing
     */
    private TabletImportDTO createTabletImportDTO(String[] tabletFromCsv) throws NumberFormatException {
        TabletImportDTO tabletImportDTO = new TabletImportDTO();

        tabletImportDTO.setPoiName(tabletFromCsv[DeviceConstants.IDX_POI_NAME]);
        tabletImportDTO.setUuid(tabletFromCsv[DeviceConstants.IDX_DEVICE_UUID]);
        tabletImportDTO.setBookable(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_BOOKABLE]));
        tabletImportDTO.setCheckIn(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_CHECKIN]));
        tabletImportDTO.setCheckInDuration(Integer.valueOf(tabletFromCsv[DeviceConstants.IDX_CHECKIN_DURATION]));
        tabletImportDTO.setEarlyCheckIn(Integer.valueOf(tabletFromCsv[DeviceConstants.IDX_EARLY_CHECK_IN]));
        tabletImportDTO.setCheckOut(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_CHECK_OUT]));
        tabletImportDTO.setShowState(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_STATE]));
        tabletImportDTO.setShowTemp(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_TEMP]));
        tabletImportDTO.setShowHumidity(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_HUMIDITY]));
        tabletImportDTO.setShowSound(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_SOUND]));
        tabletImportDTO.setShowCo2(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_CO2]));
        tabletImportDTO.setShowLux(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_SHOW_LUX]));
        tabletImportDTO.setReportAnIssue(Boolean.parseBoolean(tabletFromCsv[DeviceConstants.IDX_REPORT_AN_ISSUE]));

        return tabletImportDTO;
    }

    public List<Device> findAllByPoiName(String poiName) {
        return deviceRepository.findAllByPoiName(poiName);
    }

    public Device findByUuid(String uuid) {
        return deviceRepository.findByUuid(uuid);
    }

    public Page<Device> findAll(Specification<Device> specs, Pageable paging) {
        try {
            return deviceRepository.findAll(specs, paging);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices with provided specification and paging", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve devices.");
        }
    }


    public Device save(Device device) {
        return deviceRepository.saveAndFlush(device);
    }

    /**
     * Creates or updates a tablet device based on the provided TabletImportDTO and
     * Poi.
     *
     * @param tabletImportDTO The TabletImportDTO containing the tablet import data
     * @param poi             The Poi associated with the tablet
     */
    public void createOrUpdateTablet(TabletImportDTO tabletImportDTO, Poi poi) {
        // Check if device already exists
        Device device = deviceRepository.findByUuid(tabletImportDTO.getUuid());

        // If the device does not exist, initialize a new device
        if (Objects.isNull(device)) {
            device = new Device();
            device.setUuid(tabletImportDTO.getUuid());
            device.setStatus(EnumDeviceStatus.INACTIVE);
        }

        // Set device properties
        device.setFloor(poi.getFloor());
        device.setPoiName(tabletImportDTO.getPoiName());
        device.setLastChange(new Date().getTime() / 1000);
        device.setDeviceType(EnumDeviceType.TABLET);
        device.setAttributes(this.setTabletDefaultCertificate(device));

        // Save the device
        this.deviceRepository.save(device);

        // Update POI attributes if the Poi is not null
        if (Objects.nonNull(poi)) {
            if (Objects.nonNull(tabletImportDTO.isBookable()) &&
                    Objects.nonNull(tabletImportDTO.isCheckIn()) &&
                    Objects.nonNull(tabletImportDTO.getCheckInDuration()) &&
                    tabletImportDTO.getCheckInDuration() >= 0) {
                if (Objects.nonNull(poi.getAttributes())) {
                    poi.getAttributes().put(DeviceConstants.BOOKABLE, String.valueOf(tabletImportDTO.isBookable()));
                    poi.getAttributes().put(DeviceConstants.CHECKIN, String.valueOf(tabletImportDTO.isCheckIn()));
                    poi.getAttributes().put(DeviceConstants.CHECKIN_DURATION,
                            String.valueOf(tabletImportDTO.getCheckInDuration()));
                    poi.getAttributes().put(DeviceConstants.EARLY_CHECK_IN,
                            String.valueOf(tabletImportDTO.getEarlyCheckIn()));
                    poi.getAttributes().put(DeviceConstants.CHECKOUT, String.valueOf(tabletImportDTO.isCheckOut()));
                    poi.getAttributes().put(DeviceConstants.SHOW_STATE, String.valueOf(tabletImportDTO.isShowState()));
                    poi.getAttributes().put(DeviceConstants.SHOW_TEMP, String.valueOf(tabletImportDTO.isShowTemp()));
                    poi.getAttributes().put(DeviceConstants.SHOW_HUMIDITY,
                            String.valueOf(tabletImportDTO.isShowHumidity()));
                    poi.getAttributes().put(DeviceConstants.SHOW_SOUND, String.valueOf(tabletImportDTO.isShowSound()));
                    poi.getAttributes().put(DeviceConstants.SHOW_CO2, String.valueOf(tabletImportDTO.isShowCo2()));
                    poi.getAttributes().put(DeviceConstants.SHOW_LUX, String.valueOf(tabletImportDTO.isShowLux()));
                    poi.getAttributes().put(DeviceConstants.REPORT_AN_ISSUE,
                            String.valueOf(tabletImportDTO.isReportAnIssue()));

                } else {
                    Map<String, String> attributes = new HashMap<>();
                    attributes.put(DeviceConstants.BOOKABLE, String.valueOf(tabletImportDTO.isBookable()));
                    attributes.put(DeviceConstants.CHECKIN, String.valueOf(tabletImportDTO.isCheckIn()));
                    attributes.put(DeviceConstants.CHECKIN_DURATION,
                            String.valueOf(tabletImportDTO.getCheckInDuration()));
                    attributes.put(DeviceConstants.EARLY_CHECK_IN, String.valueOf(tabletImportDTO.getEarlyCheckIn()));
                    attributes.put(DeviceConstants.CHECKOUT, String.valueOf(tabletImportDTO.isCheckOut()));
                    attributes.put(DeviceConstants.SHOW_STATE, String.valueOf(tabletImportDTO.isShowState()));
                    attributes.put(DeviceConstants.SHOW_TEMP, String.valueOf(tabletImportDTO.isShowTemp()));
                    attributes.put(DeviceConstants.SHOW_HUMIDITY, String.valueOf(tabletImportDTO.isShowHumidity()));
                    attributes.put(DeviceConstants.SHOW_SOUND, String.valueOf(tabletImportDTO.isShowSound()));
                    attributes.put(DeviceConstants.SHOW_CO2, String.valueOf(tabletImportDTO.isShowCo2()));
                    attributes.put(DeviceConstants.SHOW_LUX, String.valueOf(tabletImportDTO.isShowLux()));
                    attributes.put(DeviceConstants.REPORT_AN_ISSUE, String.valueOf(tabletImportDTO.isReportAnIssue()));
                    poi.setAttributes(attributes);
                }
                poi.setModifiedAt((new Date()).getTime() / 1000);
                poiRepository.saveAndFlush(poi);
            }
        }
    }

    /**
     * Sets the default certificate for the tablet device.
     *
     * @param device The device for which the default certificate is to be set
     * @return The map of attributes with the default certificate
     */
    private Map<String, String> setTabletDefaultCertificate(Device device) {
        Map<String, String> attributes;
        // Check if the device already has attributes
        if (Objects.nonNull(device.getAttributes())) {
            attributes = device.getAttributes();
        } else {
            attributes = new HashMap<>();
        }
        // Set the default certificate for the tablet device
        attributes.put(EnumDeviceAttribute.CERTIFICATE.toString(), DeviceConstants.DEFAULT_CERTIFICATE_NAME);
        return attributes;
    }

    public void delete(Device device) {
        deviceRepository.delete(device);
    }

    /**
     * Retrieves the device data to be exported
     *
     * @return A list of device data to be exported.
     */
    public List<List<String>> getExportDevices() {
        try {
            return deviceRepository.findExport();
        } catch (DataAccessException ex) {
            log.error("Failed to export devices data", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export devices.");
        }
    }

    /**
     * Exports the device data to a CSV file.
     *
     * @param data The list of device data to be exported.
     */
    public ResponseEntity<String> exportDevice(List<List<String>> data) {
        List<String> headers = Arrays.asList(
                "Country",
                "City",
                "Site",
                "Building",
                "Poi Title",
                "Poi Name",
                "Conf_room_mail",
                "Capacity",
                "Uuid",
                "Ip Address",
                "App Version",
                "Status",
                "Bookable",
                "CheckIn",
                "CheckInDuration",
                "Early Check-In",
                "CheckOut",
                "ShowState",
                "ShowTemp",
                "ShowHumidity",
                "ShowSound",
                "ShowCo2",
                "ShowLux",
                "ReportAnIssue");

        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();
        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity
                .ok()
                .header("Content-Disposition", "attachment; filename=Devices.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    /**
     * Retrieves a page of devices based on specific parameters and a specified
     * ordering.
     *
     * @param buildingId   The ID of the building
     * @param deviceType   The list of device types
     * @param deviceStatus The list of device statuses
     * @param orderBy      The order by which to sort the devices
     * @param column       The column by which to order the devices
     * @param paging       The page information for pagination
     * @return A page of devices sorted by the specified column and order
     */
    public Page<Device> getDevicesWithSpecificOrderBy(
            Long buildingId,
            List<EnumDeviceType> deviceType,
            List<EnumDeviceStatus> deviceStatus,
            EnumOrderBy orderBy,
            String column,
            Pageable paging) {
        switch (column) {
            case "PoiName":
                Pageable poiNamePaging = PageRequest.of(
                        paging.getPageNumber(),
                        paging.getPageSize(),
                        Sort.by(orderBy.equals(EnumOrderBy.ASC) ? Sort.Direction.ASC : Sort.Direction.DESC,
                                "poiName"));
                return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusIn(
                        buildingId,
                        deviceType,
                        deviceStatus,
                        poiNamePaging);
            case "Uuid":
                if (orderBy.equals(EnumOrderBy.ASC)) {
                    return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByUuidAsc(
                            buildingId,
                            deviceType,
                            deviceStatus,
                            paging);
                }
                return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByUuidDesc(
                        buildingId,
                        deviceType,
                        deviceStatus,
                        paging);
            case "LastChange":
                Pageable lastChangePaging = PageRequest.of(
                        paging.getPageNumber(),
                        paging.getPageSize(),
                        Sort.by(orderBy.equals(EnumOrderBy.ASC) ? Sort.Direction.ASC : Sort.Direction.DESC,
                                "lastChange"));
                return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusIn(
                        buildingId,
                        deviceType,
                        deviceStatus,
                        lastChangePaging);
            case "Status":
                if (orderBy.equals(EnumOrderBy.ASC)) {
                    return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByStatusAsc(
                            buildingId,
                            deviceType,
                            deviceStatus,
                            paging);
                }
                return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusInOrderByStatusDesc(
                        buildingId,
                        deviceType,
                        deviceStatus,
                        paging);
            default:
                return deviceRepository.findAllByFloorBuildingIdAndDeviceTypeInAndStatusIn(
                        buildingId,
                        deviceType,
                        deviceStatus,
                        paging);
        }
    }

    /**
     * Sorts a list of DeviceDTO objects based on the poiTitle attribute and the
     * specified order.
     *
     * @param deviceDTOs The list of DeviceDTO objects to be sorted
     * @param orderBy    The order by which to sort the DeviceDTO objects
     */
    public void sortByPoiTitle(List<DeviceDTO> deviceDTOs, EnumOrderBy orderBy) {
        if (Objects.nonNull(orderBy)) {
            if (orderBy.equals(EnumOrderBy.ASC)) {
                deviceDTOs.sort(Comparator.comparing(DeviceDTO::getPoiTitle, Comparator.nullsLast(String::compareTo)));
            } else {
                deviceDTOs.sort(Comparator.comparing(DeviceDTO::getPoiTitle, Comparator.nullsLast(String::compareTo))
                        .reversed());
            }
        }
    }

    /**
     * Sorts the list of DeviceDTO objects by their 'ip' attribute, with the option
     * to specify the sort order.
     *
     * @param deviceDTOs The list of DeviceDTO objects to be sorted.
     * @param orderBy    The sorting order, which can be either ASC or DESC.
     */
    public void sortByDeviceIp(List<DeviceDTO> deviceDTOs, EnumOrderBy orderBy) {
        deviceDTOs.sort(
                new Comparator<DeviceDTO>() {
                    @Override
                    public int compare(DeviceDTO device1, DeviceDTO device2) {
                        Map<String, String> attributes1 = device1.getAttributes();
                        Map<String, String> attributes2 = device2.getAttributes();

                        String ip1 = attributes1.containsKey("Ip") ? replaceIfContains(attributes1.get("Ip"), "::")
                                : null;
                        String ip2 = attributes2.containsKey("Ip") ? replaceIfContains(attributes2.get("Ip"), "::")
                                : null;

                        // Gère les cas où l'attribut 'ip' est null
                        if (Objects.isNull(ip1) && Objects.isNull(ip2)) {
                            return 0;
                        } else if (Objects.isNull(ip1)) {
                            return orderBy == EnumOrderBy.ASC ? 1 : -1;
                        } else if (Objects.isNull(ip2)) {
                            return orderBy == EnumOrderBy.ASC ? -1 : 1;
                        } else {
                            int comparisonResult = ip1.toLowerCase(Locale.ROOT)
                                    .compareTo(ip2.toLowerCase(Locale.ROOT));
                            return orderBy == EnumOrderBy.ASC ? comparisonResult : -comparisonResult;

                        }
                    }
                });

        if (orderBy.equals(EnumOrderBy.DESC)) {
            Collections.reverse(deviceDTOs);
        }
    }

    /**
     * Replaces the given pattern in the string with an empty string if the string
     * contains the pattern.
     *
     * @param str     The string in which to perform the replacement.
     * @param pattern The pattern to search for and replace.
     * @return The modified string with the pattern replaced if found, or the
     *         original string if the pattern
     *         is not found or if the input string is null.
     */
    private String replaceIfContains(String str, String pattern) {
        return Objects.nonNull(str) && str.contains(pattern) ? str.replace(pattern, "") : str;
    }

    /**
     * Adds Point of Interest (POI) types to a list of DeviceDTOs based on the POI
     * names.
     *
     * @param deviceDTOs List of DeviceDTO objects to which POI types will be added.
     * @return A new list of DeviceDTOs with added POI types.
     */
    public List<DeviceDTO> addPoiTypeToDTOs(List<DeviceDTO> deviceDTOs, String language) {
        // Extract distinct POI names from the provided list of DeviceDTOs
        List<String> poiNameList = deviceDTOs
                .stream()
                .filter(dto -> Objects.nonNull(dto.getPoiName()))
                .map(dto -> dto.getPoiName())
                .distinct()
                .collect(Collectors.toList());

        // Retrieve POIs from the repository based on the extracted POI names
        List<Poi> pois = poiRepository.findAllByNameIn(poiNameList);

        // Update DeviceDTOs with corresponding POI types
        return deviceDTOs
                .stream()
                .peek(dto -> {
                    String poiName = dto.getPoiName();
                    if (Objects.isNull(poiName)) {
                        return; // Skip if POI name is null
                    }

                    // Find the first matching POI and set its type to the DeviceDTO
                    pois
                            .stream()
                            .filter(poi -> poiName.equals(poi.getName()))
                            .findFirst()
                            // .ifPresent(poiFound ->
                            // dto.setPoiType(PoiTypeMapper.INSTANCE.poiTypeToPoiTypeDTO(poiFound.getType(),
                            // language))); // old code
                            .ifPresent(poiFound -> {

                                // dto.setPoiGroupDTO(PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiFound.getPoiGroup(),
                                // language))
                                // dto.setPoiGroupDTO(PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiFound.getSpaceType().getPoiGroup(),
                                // language));
                                dto.setSpaceTypeDTO(
                                        SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(poiFound.getSpaceType()));
                            });
                })
                .collect(Collectors.toList());
    }

    /**
     * Sorts a list of DeviceDTOs by their associated POI type (PoiGroup name),
     * in ascending or descending order based on the provided EnumOrderBy.
     *
     * @param devices the list of DeviceDTOs to sort
     * @param orderBy the sorting order (ASC or DESC)
     */
    public void sortByPoiType(List<DeviceDTO> devices, EnumOrderBy orderBy) {
        devices.sort((device1, device2) -> {
            String name1 = (device1.getPoiGroupDTO() != null) ? device1.getPoiGroupDTO().getName() : "";
            String name2 = (device2.getPoiGroupDTO() != null) ? device2.getPoiGroupDTO().getName() : "";

            if (orderBy == EnumOrderBy.ASC) {
                return name1.compareTo(name2);
            } else {
                return name2.compareTo(name1);
            }
        });
    }

    /**
     * Sorts a list of DeviceDTOs by their associated CDM type (SpaceType name),
     * in ascending or descending order based on the provided EnumOrderBy.
     *
     * @param devices the list of DeviceDTOs to sort
     * @param orderBy the sorting order (ASC or DESC)
     */
    public void sortByCdmType(List<DeviceDTO> devices, EnumOrderBy orderBy) {
        devices.sort((device1, device2) -> {
            String name1 = (device1.getSpaceTypeDTO() != null) ? device1.getSpaceTypeDTO().getSpaceTypeName() : "";
            String name2 = (device2.getSpaceTypeDTO() != null) ? device2.getSpaceTypeDTO().getSpaceTypeName() : "";

            if (orderBy == EnumOrderBy.ASC) {
                return name1.compareTo(name2);
            } else {
                return name2.compareTo(name1);
            }
        });
    }

    public List<List<String>> getExportEmail() {
        try {
            return deviceRepository.findEmailExport();
        } catch (DataAccessException ex) {
            log.error("Failed to export email data", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to export email data.");
        }
    }

    /**
     * Scheduled task that runs daily at midnight (Europe/Paris timezone) to refresh
     * Graph API access statuses for distinct room emails.
     */
    @Scheduled(cron = "0 0 0 * * * ", zone = "Europe/Paris")
    @Async
    public void getAccessStatus() {
        log.info("Scheduler triggered to refresh Graph API access statuses at {}", LocalDateTime.now());
        List<String> roomEmails = deviceRepository.findDistinctRoomEmails();
        graphAccessCacheService.AccessStatusesScheduler(roomEmails);
    }

    /**
     * Exports the provided email data to a CSV file with UTF-8 BOM for Excel
     * compatibility.
     *
     * @param data the list of rows to export
     * @return a ResponseEntity containing the CSV content as a downloadable file
     */
    public ResponseEntity<String> exportEmail(List<List<String>> data) {
        List<String> headers = Arrays.asList("Country", "City", "Site", "Building", "Poi Name", "Poi Title",
                "Conf_room_mail", "GraphAPI Access", "Capacity");
        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=EmailExport.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    // Scheduler for every 24 hours.
    public void updateDeviceStatuses() {
        System.out.println("Called Service method updateDeviceStatuses");
        try {
            Instant now = Instant.now();
            // Subtract 24 hours (24 * 60 * 60 seconds)
            Instant minus24Hours = now.minusSeconds(24 * 60 * 60);
            // Convert the time to a Unix timestamp (seconds since epoch)
            long currentTime = now.getEpochSecond();
            long timestampInSeconds = minus24Hours.getEpochSecond();
            int devicesUpdated = this.deviceRepository.updateDeviceStatuses(
                    EnumDeviceStatus.ACTIVE.name(),
                    EnumDeviceStatus.INACTIVE.name(),
                    timestampInSeconds,
                    currentTime); // Example: find devices with ACTIVE status
            log.info("updated devices" + devicesUpdated);
        } catch (Exception ex) {
            log.error("Error while updating device statuses", ex);
        }

    }

    /**
     * Updates the status of tablet devices that have been inactive for more than
     * one hour.
     * 
     * This method:
     * 1. Calculates the current time and the timestamp for one hour ago (in epoch
     * seconds).
     * 2. Logs the current time and threshold for debugging.
     * 3. Executes an update query to set devices from ACTIVE to INACTIVE if their
     * last_change
     * is older than one hour.
     * 4. Logs the result and handles any exceptions.
     */

    public void updateTabletDeviceStatuses() {
        log.info("Starting tablet device status update...");

        try {
            Instant now = Instant.now();
            Instant minusHour = now.minusSeconds(1 * 60 * 60);

            long currentTime = now.getEpochSecond();
            long timestampInSeconds = minusHour.getEpochSecond();

            log.debug("Current Time (epoch): {}", currentTime);
            log.debug("Checking devices with last_change <= {}", timestampInSeconds);

            int devicesUpdated = deviceRepository.updateDeviceStatusesByType(
                    EnumDeviceStatus.ACTIVE.name(),
                    EnumDeviceStatus.INACTIVE.name(),
                    timestampInSeconds,
                    currentTime,
                    DeviceConstants.DEVICE_TYPE);

            log.info("Tablet device status update completed.");
            log.info("Total devices updated: {}", devicesUpdated);
        } catch (Exception ex) {
            log.error("Error during tablet device status update", ex);
        }
    }

    /**
     * Unlinks devices from POIs and floors if the associated POI no longer exists.
     * This helps maintain data integrity by cleaning up obsolete relationships.
     */
    public void cleanObsoletePoiSensorLinks() {
        List<Device> devicesToUnlink = deviceRepository.findDevicesWithNonExistentPoi();
        for (Device device : devicesToUnlink) {
            device.setPoiName(null);
            device.setFloor(null);
        }
        deviceRepository.saveAll(devicesToUnlink);
    }

    /**
     * Retrieves all devices associated with a given ThresholdConfiguration.
     * It fetches the configuration to determine the space type and country,
     * then finds all POIs matching those criteria and retrieves devices linked to
     * them.
     * Handles large POI lists by batching to avoid SQL parameter limits.
     *
     * @param thresholdConfigurationId the ID of the ThresholdConfiguration
     * @return a list of Device entities associated with the configuration
     * @throws ResourceNotFoundException if the configuration is not found
     */
    public List<Device> getDevicesForThresholdConfiguration(Long thresholdConfigurationId) {
        try {
            // Fetch the ThresholdConfiguration to get the poiTypeId and countryId
            ThresholdConfiguration thresholdConfiguration = thresholdConfigurationRepository
                    .findById(thresholdConfigurationId)
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "ThresholdConfiguration not found with ID :: " + thresholdConfigurationId));

            Long spaceTypeId = thresholdConfiguration.getSpaceTypeId();
            Long countryId = thresholdConfiguration.getCountryId();

            // Fetch POIs with the given poiGroupId and countryId
            List<Poi> pois = poiRepository.findByPoiGroupIdAndCountryId(spaceTypeId, countryId);
            List<String> poiNames = pois.stream().map(Poi::getName).collect(Collectors.toList());

            if (poiNames.isEmpty()) {
                return Collections.emptyList(); // No matching POIs, return an empty list
            }

            // Limit for SQL IN clause
            int maxInClauseSize = 2000;

            // Initialize a list to collect all devices
            List<Device> allDevices = new ArrayList<>();

            // Split the poiNames list into smaller chunks to avoid exceeding SQL parameter
            // limits
            for (int i = 0; i < poiNames.size(); i += maxInClauseSize) {
                // Get a sublist of poiNames within the allowed limit
                List<String> chunk = poiNames.subList(i, Math.min(i + maxInClauseSize, poiNames.size()));

                // Fetch devices based on the chunk of POI names
                List<Device> devicesChunk = deviceRepository.findDevicesByPoiNames(chunk);

                // Add the results to the overall list
                allDevices.addAll(devicesChunk);
            }

            return allDevices;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve devices for thresholdConfigurationId {}", thresholdConfigurationId, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve devices for threshold configuration.");
        }
    }


    /**
     * Retrieves devices on a specific floor, optionally filtered by space type IDs.
     * If no space type IDs are provided, it returns all devices on the floor.
     *
     * @param floorId      the ID of the floor (required)
     * @param spaceTypeIds optional list of space type IDs to filter devices
     * @return a list of DeviceSpaceTypeDTOs matching the criteria
     * @throws IllegalArgumentException if floorId is null
     */
    public List<DeviceSpaceTypeDTO> getDevicesBySpaceType(Long floorId, List<Long> spaceTypeIds) {
        if (floorId == null) {
            throw new IllegalArgumentException("Floor ID is required");
        }
        try {
            if (spaceTypeIds == null || spaceTypeIds.isEmpty() && floorId != null) {
                return deviceRepository.findDevicesByFloorId(floorId);
            } else if (spaceTypeIds != null && !spaceTypeIds.isEmpty() && floorId != null) {
                return deviceRepository.findDevicesBySpaceTypeAndFloorId(spaceTypeIds, floorId);
            }
            return Collections.emptyList();
        } catch (DataAccessException ex) {
            log.error("Failed to get devices by space type for floorId {} and spaceTypeIds {}", floorId, spaceTypeIds, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve devices by space type.");
        }
    }

    /**
     * Retrieves Read access on MS Graph for email of meeting rooms and save in DB.
    */
    public void getGraphAccessStatus() {
        List<String> roomEmails = deviceRepository.findDistinctRoomEmails();
        graphAccessCacheService.graphAccessStatuses(roomEmails);
    }
    
    /**
     * Sets under_maintenance (0/1) for the device identified by uuid.
     *
     * @return true if a row was updated; false if the device doesn't exist.
     */    
    public Device updateUnderMaintenance(String uuid, Boolean underMaintenance) {
        Device device = findByUuid(uuid);
        if (device == null) {
            return null;
        }
        // Accept null as 'no change' or enforce non-null at controller/DTO validation as needed
        device.setUnderMaintenance(underMaintenance);
        return save(device);
    }


}
