package com.capgemini.admin.back.model;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
public class ResponseSecuredUserImportDTO {
    private List<SecuredUserImportDTO> securedUserImportDTOs;
    private List<String> errorsInFile;

    public ResponseSecuredUserImportDTO() {
        this.securedUserImportDTOs = new ArrayList<>();
        this.errorsInFile = new ArrayList<>();
    }

    public void addError(String error) {
        if (Objects.isNull(this.errorsInFile)) {
            this.errorsInFile = new ArrayList<>();
        }
        this.errorsInFile.add(error);
    }


    public void addSecuredUser(SecuredUserImportDTO securedUser) {
        this.securedUserImportDTOs.add(securedUser);
    }
}
