package com.capgemini.admin.back.service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.DistributedLock;
import com.capgemini.admin.back.repository.DistributedLockRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DistributedLockService {

    @Autowired
    private DistributedLockRepository lockRepository;

    private String lockedBy; // This will store the unique lockedBy string for the instance

    public static String LOCK_NAME = "SENSOR_LOCK";
   
    /**
     * Initializes the distributed lock mechanism for the current instance.
     * Generates a unique `lockedBy` identifier and attempts to acquire the lock.
     * This method is triggered automatically after bean construction.
     */
    @PostConstruct
    public void initLock() {
        // Create the unique lockedBy string
        this.lockedBy = createLockedByString();
        log.info("lockedBy" + lockedBy);
        // Acquire the lock for the current instance
        boolean lockAcquired = acquireLock();
        if (!lockAcquired) {
            log.info("Lock already exists");
        }
    }
    
    /**
     * Releases the distributed lock when the application is shutting down.
     * This method is triggered automatically before bean destruction.
     */
    @PreDestroy
    public void releaseLockOnShutdown() {
        // Release the lock before the service is destroyed
        releaseLock();
        log.info("Lock " + LOCK_NAME + " released.");
    }
    
    /**
     * Checks if the lock with the predefined name exists in the database.
     *
     * @return true if the lock exists, false otherwise
    */
    public boolean isLockExists() {
        Long count = lockRepository.countByLockName(LOCK_NAME);
        return count != null && count > 0;
    }
   
    /**
     * Attempts to acquire the distributed lock.
     * If the lock already exists, it checks if it's held by the current instance.
     * If not, it creates a new lock entry in the database.
     *
     * @return true if the lock is acquired or already held by this instance, false otherwise
     */
    public boolean acquireLock() {
        if (isLockExists()) {
            // If lock exists, check if it is already held by the current instance
            DistributedLock lock = lockRepository.findByLockName(LOCK_NAME);
            if (isLockedByCurrentInstance(lock.getLockedBy())) {
                log.info("I'm here");
                return true; // Lock is held by the current instance
            }
            return false; // Lock is held by another instance
        } else {
            log.info("creating new lock");
            // Create a new lock
            DistributedLock newLock = new DistributedLock();
            newLock.setLockName(LOCK_NAME);
            newLock.setLockedAt(LocalDateTime.now());
            log.info("creating new lock2: " + lockedBy);
            newLock.setLockedBy(lockedBy);
            lockRepository.save(newLock);
            return true;
        }
    }
    
    /**
     * Releases the distributed lock by deleting it from the database.
     */
    public void releaseLock() {
        // Release the lock by deleting it from the database
        try {
            lockRepository.deleteByLockName(LOCK_NAME);
        } catch (DataAccessException ex) {
            log.error("Failed to release distributed lock {}", LOCK_NAME, ex);
            throw ex;
        }
    }
   
    /**
     * Generates a unique identifier for the current instance using hostname and a random UUID.
     *
     * @return a unique string representing the current instance
     */
    public static String createLockedByString() {
        try {
            String hostname = InetAddress.getLocalHost().getHostName();
            String randomValue = UUID.randomUUID().toString(); // Generate a random UUID
            return hostname + "-" + randomValue;
        } catch (UnknownHostException e) {
            throw new RuntimeException("Failed to retrieve hostname", e);
        }
    }
   
    /**
     * Checks whether the lock in the database is held by the current instance.
     *
     * @param lockedByfromDb the `lockedBy` value stored in the database
     * @return true if the current instance holds the lock, false otherwise
     */
    // Method to check if the current instance holds the lock
    public boolean isLockedByCurrentInstance(String lockedByfromDb) {
        String sanitizedLockedByfromDb = new String(String.valueOf(lockedByfromDb).replaceAll("[\r\n\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
        log.info("lockedByfromDb {}", sanitizedLockedByfromDb);
        return this.lockedBy.equals(lockedByfromDb);
    }
}
