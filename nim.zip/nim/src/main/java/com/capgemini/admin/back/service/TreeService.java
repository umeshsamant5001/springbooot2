package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.admin.back.cache.UserRequestCache;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.CountrySP;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Site;
import com.capgemini.admin.back.model.SubLevelEnum;
import com.capgemini.admin.back.model.User;

@Service
public class TreeService {

    @Autowired
    private UserRequestCache userRequestCache;

    @Autowired
    private UserRoleLocationService userRoleLocationService;

    /**
     * Filter object from the tree of location
     * 
     * @param <T>
     * @param root A Country, a City, a Site, a Building or a List of them
     * @return If only one object is pass, rturn the object if authorized, or null.
     *         If a List is pass, return the list filter with only authorized ones.
     */
    public <T> T filterTree(T root) {
        User currentUser = this.userRequestCache.getCurrentUser();

        if (this.userRoleLocationService.userIsGlobal(currentUser.getId())) {
            // The user as a "global" access : no filter needed
            return root;
        }

        Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations = this.getAuthorizedLocations();

        if (authorizedLocations.size() == 0) {
            // The user don't have access to any location
            if (root instanceof Collection) {
                return (T) new ArrayList<>();
            } else {
                return null;
            }
        }

        if (root instanceof Collection) {
            return (T) this.filterCollection(authorizedLocations, (Collection) root);
        }

        return this.filterOne(authorizedLocations, root);
    }

    /**
     * Check if an object is authorized by Id
     * 
     * @param level The Level of the id
     * @param id    The id
     * @return True if the id is authorized
     */
    public boolean isAuthorized(LevelEnum level, Long id) {
        return this.filterId(level, List.of(id)).size() > 0;
    }

    public <T> boolean isAuthorized(SubLevelEnum level, T id) {
        return this.filterId(level, List.of(id)).size() > 0;
    }

    /**
     * Filter a List of id to keep only authorized ones
     * 
     * @param level The level of the ids
     * @param ids   The list of ids
     * @return A list of authorized ids only
     */
    public List<Long> filterId(LevelEnum level, List<Long> ids) {
        User currentUser = this.userRequestCache.getCurrentUser();

        if (this.userRoleLocationService.userIsGlobal(currentUser.getId())) {
            // The user as a "global" access : no filter needed
            return ids;
        }

        Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations = this.getAuthorizedLocations();

        if (authorizedLocations.size() == 0) {
            // The user don't have access to any location
            return List.of();
        }

        return ids.stream()
                .filter(id -> authorizedLocations.get(level).containsKey(id)
                        && authorizedLocations.get(level).get(id).isGreaterOrEqualsThan(level))
                .collect(Collectors.toList());
    }

    /**
     * Filters a list of IDs based on the current user's access level and the specified sub-level.
     * If the user has global access, the original list is returned unfiltered.
     *
     * @param level The sub-level (e.g., FLOOR, POI, DEVICE, CISCO_DEVICE) to filter by.
     * @param ids   The list of IDs to filter.
     * @param <T>   The type of ID (Long or String).
     * @return A filtered list of IDs the user is authorized to access.
     */
    public <T> List<T> filterId(SubLevelEnum level, List<T> ids) {
        User currentUser = this.userRequestCache.getCurrentUser();

        if (this.userRoleLocationService.userIsGlobal(currentUser.getId())) {
            // The user as a "global" access : no filter needed
            return ids;
        }

        switch (level) {
            case FLOOR:
                return (List<T>) this.userRoleLocationService.filterAuthorizedFloorId(currentUser.getId(),
                        (List<Long>) ids);
            case POI:
                return (List<T>) this.userRoleLocationService.filterAuthorizedPoiId(currentUser.getId(),
                        (List<Long>) ids);
            case DEVICE:
                return (List<T>) this.userRoleLocationService.filterAuthorizedDeviceId(currentUser.getId(),
                        (List<String>) ids);
            case CISCO_DEVICE:
                return (List<T>) this.userRoleLocationService.filterAuthorizedCiscoDeviceByDeviceId(currentUser.getId(),
                        (List<String>) ids);
            default:
                return new ArrayList<>();
        }
    }

    /**
     * Filters a collection of hierarchical location objects (Country, City, Site, etc.)
     * based on the user's authorized locations.
     *
     * @param authorizedLocations The map of authorized locations by level.
     * @param root                The collection to filter.
     * @param <T>                 The type of collection (e.g., List<Country>).
     * @return A filtered collection containing only authorized elements.
     */
    private <T extends Collection<?>> T filterCollection(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations,
            T root) {
        return (T) root.stream()
                .map(item -> this.filterOne(authorizedLocations, item))
                .filter(item -> Objects.nonNull(item))
                .collect(Collectors.toList());
    }

    /**
     * Filters a single hierarchical object based on its type and the user's authorized locations.
     *
     * @param authorizedLocations The map of authorized locations by level.
     * @param root                The object to filter.
     * @param <T>                 The type of the object.
     * @return The filtered object if authorized, otherwise null.
     */
    @SuppressWarnings("unchecked")
    private <T> T filterOne(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, T root) {
        if (root instanceof Country) {
            return (T) this.filterCountry(authorizedLocations, (Country) root);
        } else if (root instanceof City) {
            return (T) this.filterCity(authorizedLocations, (City) root);
        } else if (root instanceof Site) {
            return (T) this.filterSite(authorizedLocations, (Site) root);
        } else if (root instanceof Building) {
            return (T) this.filterBuilding(authorizedLocations, (Building) root);
        } else if (root instanceof CountrySP) {
            return (T) this.filterCountrySP(authorizedLocations, (CountrySP) root);
        }

        return null;
    }

    /**
     * Retrieves the current user's authorized locations grouped by level.
     *
     * @return A map of LevelEnum to a map of location IDs and their levels.
     */
    private Map<LevelEnum, Map<Long, LevelEnum>> getAuthorizedLocations() {
        User currentUser = this.userRequestCache.getCurrentUser();

        if (Objects.isNull(currentUser)) {
            return new HashMap<>();
        }

        return this.userRoleLocationService.getLocationsByUserId(currentUser.getId());
    }


    private Country filterCountry(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, Country country) {
        return this.<Country, City>filter(
                authorizedLocations,
                country,
                LevelEnum.COUNTRY,
                root -> root.getId(),
                root -> root.getCities(),
                cities -> this.filterCity(authorizedLocations, cities),
                (root, cities) -> root.setCities(cities));
    }

    private City filterCity(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, City city) {
        return this.<City, Site>filter(
                authorizedLocations,
                city,
                LevelEnum.CITY,
                root -> root.getId(),
                root -> root.getSites(),
                sites -> this.filterSite(authorizedLocations, sites),
                (root, sites) -> root.setSites(sites));
    }

    private Site filterSite(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, Site site) {
        return this.<Site, Building>filter(
                authorizedLocations,
                site,
                LevelEnum.SITE,
                root -> root.getId(),
                root -> root.getBuildings(),
                buildings -> this.filterBuilding(authorizedLocations, buildings),
                (root, buildings) -> root.setBuildings(buildings));
    }

    private Building filterBuilding(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, Building building) {
        return this.<Building, Floor>filter(
                authorizedLocations,
                building,
                LevelEnum.BUILDING,
                root -> root.getId(),
                // No need to filter the floors
                root -> new ArrayList<Floor>(),
                floors -> floors,
                (root, floors) -> {
                });
    }
    /**
     * Special-case filtering for CountrySP objects, which are not hierarchical.
     * Determines access based on the most specific non-null level available.
     *
     * @param authorizedLocations The user's authorized locations.
     * @param countrySP           The CountrySP object to filter.
     * @return The CountrySP if authorized, otherwise null.
     */
    private CountrySP filterCountrySP(Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations, CountrySP countrySP) {
        // Special case for CountrySP : it's not in a tree form

        Long countryId = countrySP.getCountryId();
        Long cityId = countrySP.getCityId();
        Long siteId = countrySP.getSiteId();
        Long buildingId = countrySP.getBuildingId();

        if (!this.isNullSP(buildingId) && authorizedLocations.get(LevelEnum.BUILDING).containsKey(buildingId)
                || this.isNullSP(buildingId) && !this.isNullSP(siteId)
                        && authorizedLocations.get(LevelEnum.SITE).containsKey(siteId)
                || this.isNullSP(buildingId) && this.isNullSP(siteId) && !this.isNullSP(cityId)
                        && authorizedLocations.get(LevelEnum.CITY).containsKey(cityId)
                || this.isNullSP(buildingId) && this.isNullSP(siteId) && this.isNullSP(cityId)
                        && !this.isNullSP(countryId)
                        && authorizedLocations.get(LevelEnum.COUNTRY).containsKey(countryId)) {
            return countrySP;
        }

        return null;
    }

    /**
     * The procedure have '0' for the Buiding id instead of null.
     * So we need a special function to test the 'null' of id.
     */
    private boolean isNullSP(Long id) {
        return Objects.isNull(id) || id.equals(0L);
    }

    private <T, U> T filter(
            /** Map of information of authorized locations */
            Map<LevelEnum, Map<Long, LevelEnum>> authorizedLocations,
            /** Object to filter */
            T root,
            /** Level of the object */
            LevelEnum level,
            /** Return the id of the Object */
            Function<T, Long> getterId,
            /** Return the child of the root */
            Function<T, List<U>> getterChild,
            /** THD */
            Function<U, U> mapperChild,
            /** Setter for the childs (to apply the news list) */
            BiConsumer<T, List<U>> setterChild) {
        Long id = getterId.apply(root);

        if (!authorizedLocations.get(level).containsKey(id)
                || !authorizedLocations.get(level).get(id).isGreaterOrEqualsThan(level)) {
            return null;
        }

        if (Hibernate.isInitialized(getterChild.apply(root))) {
            List<U> list = getterChild.apply(root)
                    .stream()
                    .map(child -> mapperChild.apply(child))
                    .filter(child -> Objects.nonNull(child))
                    .collect(Collectors.toList());

            setterChild.accept(root, list);
        }

        return root;
    }
}
