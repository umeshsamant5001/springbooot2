package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.capgemini.admin.back.model.CountryTenant;

@Repository
public interface CountryTenantRepository extends JpaRepository<CountryTenant, Long> {
    Optional<CountryTenant> findByTenant(String tenant);
    Optional<CountryTenant> findByIdAndCountryIdIn(Long id, List<Long> countryIds);
}
