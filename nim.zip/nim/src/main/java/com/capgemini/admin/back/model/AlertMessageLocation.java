package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "alert_message_location")
public class AlertMessageLocation {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AlertMessageLocation_Generator")
    @SequenceGenerator(name = "AlertMessageLocation_Generator", sequenceName = "AlertMessageLocation_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "alert_message_id")
    @JsonIgnore
    private AlertMessage alertMessage;

    @Column(name = "alert_message_id", updatable = false, insertable = false)
    private Long alertMessageId;

    @Enumerated(EnumType.STRING)
    @Column(name = "level")
    private LevelEnum level;
    @Column(name = "cdm_key_id")
    private Long cdmKeyId;
    @Column(name = "status")
    private String status;
    @Column(name = "country_id")
    private Long countryId;
    @Column(name = "country_name")
    private String countryName;
}
