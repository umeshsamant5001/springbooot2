package com.capgemini.admin.back.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.mapper.SiteMapper;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Site;
import com.capgemini.admin.back.model.SiteDTO;



import com.capgemini.admin.back.service.BuildingService;
import com.capgemini.admin.back.service.SiteService;
import com.capgemini.admin.back.service.SiteService.SiteUpsertInput;
import com.capgemini.admin.back.service.TreeService;

import lombok.Data;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@RestController
@Validated
@RequestMapping(value = SiteController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class SiteController {

    public static final String ROOT_API = "api/site";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class SiteCreateRequest {
        @Min(1)
        private Long cityId;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Size(max = 1000)
        private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class SiteUpdateRequest {
        @Min(1)
        private Long cityId;
        @Min(0)
        private Long cdmKeyId;

        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;
        @Size(max = 1000)
        private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes;
    }




    @Autowired
    private BuildingService buildingService;

    @Autowired
    private SiteService siteService;

    @Autowired
    private TreeService treeService;

    @PostMapping
    public ResponseEntity<SiteDTO> postSite(
            @Valid @RequestBody SiteCreateRequest siteRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        SiteUpsertInput safeSiteInput = this.toSiteInputForCreate(siteRequest);


        try {
            Site postedSite = this.siteService.save(safeSiteInput);


            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(SiteMapper.INSTANCE.siteToSiteDTO(postedSite, language));
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/{siteId}")
    public ResponseEntity<SiteDTO> getSite(
            @PathVariable @Min(1) Long siteId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (Objects.isNull(siteId) || siteId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Long authorizedSiteId = Long.valueOf(siteId);

        if (!this.treeService.isAuthorized(LevelEnum.SITE, authorizedSiteId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Site site = siteService.getSite(authorizedSiteId);


        if (Objects.isNull(site)) {
            return ResponseEntity.notFound().build();
        }

        site = this.treeService.filterTree(site);
        if (Objects.isNull(site)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        SiteDTO siteDto = SiteMapper.INSTANCE.siteToSiteDTO(site, language);
        siteDto.setNbChilds(this.buildingService.countBySiteId(siteDto.getId()));
        return ResponseEntity.ok(siteDto);
    }

    @GetMapping
    public ResponseEntity<List<SiteDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Site> sites = this.siteService.getAll();
        sites = this.treeService.filterTree(sites);
        if (CollectionUtils.isEmpty(sites)) {
            return ResponseEntity.noContent().build();
        }

        List<SiteDTO> siteDTOs = sites
                .stream()
                .map(site -> {
                    return SiteMapper.INSTANCE.siteToSiteDTONoBuildings(site, language);
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(siteDTOs);
    }

    @PutMapping("/{siteId}")
    public ResponseEntity<SiteDTO> updatesite(
            @PathVariable @Min(1) Long siteId,
            @Valid @RequestBody SiteUpdateRequest siteRequest,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {



        if (Objects.isNull(siteId) || siteId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Long authorizedSiteId = Long.valueOf(siteId);

        if (!this.siteService.siteExists(authorizedSiteId)) {
            return ResponseEntity.notFound().build();
        }

        if (!this.treeService.isAuthorized(LevelEnum.SITE, authorizedSiteId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        SiteUpsertInput safeSiteInput = this.toSiteInputForUpdate(siteRequest);


        Site newsite = this.siteService.updateSite(
                authorizedSiteId,
                safeSiteInput);


        return ResponseEntity.ok(SiteMapper.INSTANCE.siteToSiteDTO(newsite, language));
    }


    @DeleteMapping("/{siteId}")
    public ResponseEntity<Site> deleteSite(@PathVariable @Min(1) Long siteId) {
        if (Objects.isNull(siteId) || siteId <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Long authorizedSiteId = Long.valueOf(siteId);

        if (!this.siteService.siteExists(authorizedSiteId)) {
            return ResponseEntity.notFound().build();
        }

        if (!this.treeService.isAuthorized(LevelEnum.SITE, authorizedSiteId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        this.siteService.deleteById(authorizedSiteId);
        return ResponseEntity.noContent().build();
    }

    

    private SiteUpsertInput toSiteInputForCreate(SiteCreateRequest siteRequest) {
        return new SiteUpsertInput(
                siteRequest.getCityId() == null
                        ? null
                        : Long.valueOf(String.valueOf(siteRequest.getCityId())),
                siteRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(siteRequest.getCdmKeyId())),
                new HashMap<>(this.sanitizeAttributes(siteRequest.getAttributes())),
                siteRequest.getTitleEn() == null
                        ? null
                        : new String(String.valueOf(siteRequest.getTitleEn())),
                siteRequest.getTitleFr() == null
                        ? null
                        : new String(String.valueOf(siteRequest.getTitleFr())));
    }

    private SiteUpsertInput toSiteInputForUpdate(SiteUpdateRequest siteRequest) {
        return new SiteUpsertInput(
                null,
                siteRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(siteRequest.getCdmKeyId())),
                new HashMap<>(this.sanitizeAttributes(siteRequest.getAttributes())),
                siteRequest.getTitleEn() == null
                        ? null
                        : new String(String.valueOf(siteRequest.getTitleEn())),
                siteRequest.getTitleFr() == null
                        ? null
                        : new String(String.valueOf(siteRequest.getTitleFr())));
    }

    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {


        Map<String, String> sanitized = new HashMap<>();
        if (Objects.isNull(attributes)) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

}
