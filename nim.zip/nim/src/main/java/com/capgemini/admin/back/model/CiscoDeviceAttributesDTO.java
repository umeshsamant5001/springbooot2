package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class CiscoDeviceAttributesDTO {
    private String ipAddress;
    private Integer peopleCount;
    private Double ambientNoiseDba;
    private Double soundLevelDba;
    private Double ambientTemperature;
    private Double relativeHumidity;
    private Double airQuality;
}
