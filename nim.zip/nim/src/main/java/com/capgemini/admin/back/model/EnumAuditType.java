
package com.capgemini.admin.back.model;

public enum EnumAuditType {

	LOGIN, ACTION, MODULE, EVENT, SESSION, REQUEST, WORKFLOW;

	public static EnumAuditType findByName(String name) {
		EnumAuditType result = null;
		for (EnumAuditType auditType : values()) {
			if (auditType.name().equalsIgnoreCase(name)) {
				result = auditType;
				break;
			}
		}
		return result;
	}

}