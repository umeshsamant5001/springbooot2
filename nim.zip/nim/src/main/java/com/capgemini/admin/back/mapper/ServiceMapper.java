package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.Service;
import com.capgemini.admin.back.model.ServiceDTO;

@Mapper(uses = { ServiceTranslationMapper.class, ServiceLocationMapper.class })
public interface ServiceMapper {
    ServiceMapper INSTANCE = Mappers.getMapper(ServiceMapper.class);

    Service serviceDTOToService(ServiceDTO in);

    ServiceDTO serviceToServiceDTO(Service in);

}
