package com.capgemini.admin.back.temporary;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CDMFloor {
	private String name;
	private Long keyId;
	private String assetId;
	private Integer totalSpaceArea;
	private String unitOfMeasurementCode;
	private String productionUnit;
	private String type;
	private Boolean securedFloor;
	private String mapId;
	private String base64Map;
	private Long floorIndex;
}
