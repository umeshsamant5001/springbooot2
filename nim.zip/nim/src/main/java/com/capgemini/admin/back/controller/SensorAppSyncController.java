package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.admin.back.model.SensorAppImport;
import com.capgemini.admin.back.service.SensorAppService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = SensorAppSyncController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class SensorAppSyncController {

    public static final String ROOT_API = "/api/sensorApp";

    @Autowired
    private SensorAppService sensorAppService;

    /**
     * Imports missing Smart office data from SensorApp data using CSV file.
     * 
     * @param file The CSV file to be imported.
     * @return Response containing import status and any errors encountered.
     */

    @PutMapping("/import/sync-devices")
    public ResponseEntity<SensorAppImport> importSensorAppSyncDevice(@RequestParam("file") MultipartFile file) {

        SensorAppImport sensorAppImportResponse = new SensorAppImport();

        // Validate CSV format
        sensorAppImportResponse.setErrorsInFile(sensorAppService.checkCSVFormat(file));
        if (!CollectionUtils.isEmpty(sensorAppImportResponse.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(sensorAppImportResponse);
        }
        // Parse CSV and validate data
        sensorAppImportResponse = sensorAppService.generateSensorAppImportDTORequest(file);
        sensorAppImportResponse = sensorAppService.updateSensorAppList(sensorAppImportResponse);
        return ResponseEntity.status(HttpStatus.OK).body(sensorAppImportResponse);
    }

}
