package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import com.capgemini.admin.back.mapper.LanguageMapper;
import com.capgemini.admin.back.model.Language;
import com.capgemini.admin.back.model.LanguageDTO;
import com.capgemini.admin.back.service.LanguageService;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = LanguageController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class LanguageController {

    static final String ROOT_API = "api/languages";

    @Autowired
    LanguageService languageService;

    @GetMapping
    public ResponseEntity<List<LanguageDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Language> languages = this.languageService.findAll();
        if (CollectionUtils.isEmpty(languages)) {
            return ResponseEntity.noContent().build();
        }

        List<LanguageDTO> languageDTOs = languages
                .stream()
                .map(LanguageMapper.INSTANCE::languageToLanguageDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(languageDTOs);
    }

}
