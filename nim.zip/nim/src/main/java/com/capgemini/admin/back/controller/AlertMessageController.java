package com.capgemini.admin.back.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.admin.back.mapper.AlertMessageMapper;

import com.capgemini.admin.back.model.AlertMessage;
import com.capgemini.admin.back.model.AlertMessageDTO;
import com.capgemini.admin.back.model.AlertMessageLocation;
import com.capgemini.admin.back.model.AlertMessageLocationDTO;
import com.capgemini.admin.back.model.AlertType;

import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.ThresholdType;
import com.capgemini.admin.back.service.AlertMessageService;
import com.capgemini.admin.back.service.AlertMessageService.AlertMessageLocationUpsertInput;
import com.capgemini.admin.back.service.AlertMessageService.AlertMessageUpsertInput;
import com.capgemini.admin.back.service.CountryService;

import com.capgemini.admin.back.service.SpaceTypeService;
import com.capgemini.admin.back.service.SensorAlertService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("api/alertMessage")
public class AlertMessageController {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class AlertMessageLocationWriteRequest {
        @NotNull
        private LevelEnum level;
        @Min(0)
        private Long cdmKeyId;
        @Size(max = 64)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String status;
        @Min(0)
        private Long countryId;
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String countryName;
    }

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class AlertMessageWriteRequest {
        @NotNull
        @Min(1)
        private Long spaceTypeId;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String spaceTypeName;
        @NotNull
        private ThresholdType thresholdType;
        @NotNull
        private AlertType alertCategory;
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String title;
        @NotNull
        @Size(max = 5000)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String message;
        @NotNull
        @Valid
        @Size(min = 1, max = 1000)
        private List<AlertMessageLocationWriteRequest> alertMessageLocations = new ArrayList<>();
    }


    @Autowired
    private AlertMessageService alertMessageService;


    @Autowired
    private SpaceTypeService spaceTypeService;

    @Autowired
    private SensorAlertService sensorAlertService;

    @Autowired
    private CountryService countryService;

    /**
     * Creates a new AlertMessage entity based on the provided AlertMessageDTO.
     * 
     * Validates the input DTO and maps it to the entity. It also checks for the
     * existence
     * of related SpaceType and Country entities before saving. If validation
     * passes,
     * the alert message is persisted and returned as a DTO.
     *
     * @param alertMessageDTO The DTO containing alert message data to be created.
     * @param language        The language preference for the response (default is
     *                        "en").
     * @return ResponseEntity containing the created AlertMessageDTO or an error
     *         response.
     */
    @PostMapping
    public ResponseEntity<AlertMessageDTO> createAlertMessage(
            @Valid @RequestBody AlertMessageWriteRequest alertMessageRequest,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {


        if (alertMessageRequest == null) {
            return ResponseEntity.badRequest().build();
        }

        AlertMessageDTO sanitizedAlertMessageDTO = sanitizeAlertMessageDTO(alertMessageRequest);
        AlertMessage sanitizedAlertMessage = AlertMessageMapper.INSTANCE
                .alertMessageDTOToAlertMessage(sanitizedAlertMessageDTO);

        if (alertMessageService.isAlertMessageExist(sanitizedAlertMessage)) {

            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        try {
            AlertMessage alertMessage = prepareAlertMessage(sanitizedAlertMessage);
            AlertMessageUpsertInput safeAlertMessageInput = toAlertMessageUpsertInput(alertMessage);

            AlertMessage saved = alertMessageService.createAlertMessage(safeAlertMessageInput);
            AlertMessageDTO resultDTO = AlertMessageMapper.INSTANCE.alertMessageToAlertMessageDTO(saved, language);



            return ResponseEntity.status(HttpStatus.CREATED).body(resultDTO);
        } catch (Exception e) {
            log.error("Error creating alert message: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Updates an existing AlertMessage entity based on the provided ID and DTO.
     * 
     * Validates the input ID and maps the DTO to the entity. It also checks for the
     * existence
     * of related SpaceType and Country entities before performing the update. If
     * validation passes,
     * the alert message is updated and returned as a DTO in the requested language.
     *
     * @param id              The ID of the AlertMessage to update.
     * @param alertMessageDTO The DTO containing updated alert message data.
     * @param language        The language preference for the response (default is
     *                        "en").
     * @return ResponseEntity containing the updated AlertMessageDTO or an error
     *         response.
     */
    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<AlertMessageDTO> updateAlertMessage(
            @PathVariable Long id,
            @Valid @RequestBody AlertMessageWriteRequest alertMessageRequest,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {


        if (id == null || alertMessageRequest == null) {
            return ResponseEntity.badRequest().build();
        }

        try {
            AlertMessageDTO sanitizedAlertMessageDTO = sanitizeAlertMessageDTO(alertMessageRequest);

            AlertMessage alertMessage = prepareAlertMessage(sanitizedAlertMessageDTO);
            AlertMessageUpsertInput safeAlertMessageInput = toAlertMessageUpsertInput(alertMessage);

            AlertMessage updated = alertMessageService.updateAlertMessage(safeAlertMessageInput, id);
            AlertMessageDTO resultDTO = AlertMessageMapper.INSTANCE.alertMessageToAlertMessageDTO(updated, language);

            return ResponseEntity.ok(resultDTO);
        } catch (Exception e) {
            log.error("Error updating alert message with ID {}: {}", id, e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Creates a sanitized copy of AlertMessageDTO with only allowlisted writable
     * fields.
     *
     * @param alertMessageDTO the incoming request payload DTO
     * @return sanitized DTO safe for mapping to persistence entity
     */
    private AlertMessageDTO sanitizeAlertMessageDTO(AlertMessageWriteRequest alertMessageRequest) {
        AlertMessageDTO sanitized = new AlertMessageDTO();
        sanitized.setSpaceTypeId(alertMessageRequest.getSpaceTypeId() == null
                ? null
                : Long.valueOf(alertMessageRequest.getSpaceTypeId()));
        sanitized.setSpaceTypeName(alertMessageRequest.getSpaceTypeName() == null
                ? null
                : new String(String.valueOf(alertMessageRequest.getSpaceTypeName())));
        sanitized.setThresholdType(alertMessageRequest.getThresholdType() == null
                ? null
                : ThresholdType.valueOf(String.valueOf(alertMessageRequest.getThresholdType().name())));
        sanitized.setAlertCategory(alertMessageRequest.getAlertCategory() == null
                ? null
                : AlertType.valueOf(String.valueOf(alertMessageRequest.getAlertCategory().name())));
        sanitized.setTitle(alertMessageRequest.getTitle() == null
                ? null
                : new String(String.valueOf(alertMessageRequest.getTitle())));
        sanitized.setMessage(alertMessageRequest.getMessage() == null
                ? null
                : new String(String.valueOf(alertMessageRequest.getMessage())));

        if (alertMessageRequest.getAlertMessageLocations() != null) {
            for (AlertMessageLocationWriteRequest locationRequest : alertMessageRequest.getAlertMessageLocations()) {
                if (locationRequest == null) {
                    continue;
                }
                AlertMessageLocationDTO sanitizedLocationDTO = new AlertMessageLocationDTO();
                sanitizedLocationDTO.setLevel(locationRequest.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(locationRequest.getLevel().name())));
                sanitizedLocationDTO.setCdmKeyId(locationRequest.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(locationRequest.getCdmKeyId()));
                sanitizedLocationDTO.setStatus(locationRequest.getStatus() == null
                        ? null
                        : new String(String.valueOf(locationRequest.getStatus())));
                sanitizedLocationDTO.setCountryId(locationRequest.getCountryId() == null
                        ? null
                        : Long.valueOf(locationRequest.getCountryId()));
                sanitizedLocationDTO.setCountryName(locationRequest.getCountryName() == null
                        ? null
                        : new String(String.valueOf(locationRequest.getCountryName())));
                sanitized.getAlertMessageLocations().add(sanitizedLocationDTO);
            }
        }

        return sanitized;
    }

    



    /**
     * Prepares an AlertMessage entity from the provided DTO by performing necessary
     * validations
     * and setting relationships.
     *
     * - Maps the DTO to an entity.

     * - Validates the existence of the associated SpaceType.
     * - Iterates through AlertMessageLocations:
     * - For GLOBAL level, clears country-specific fields.
     * - For other levels, validates the existence of the associated Country.
     * - Sets the AlertMessage reference in each location.
     *
     * @param alertMessageDTO The DTO containing alert message data.
     * @return A fully prepared and validated AlertMessage entity.
     * @throws IllegalArgumentException if SpaceType or Country validation fails.
     */
    private AlertMessage prepareAlertMessage(AlertMessageDTO alertMessageDTO) {
        AlertMessage alertMessage = AlertMessageMapper.INSTANCE.alertMessageDTOToAlertMessage(alertMessageDTO);
        return prepareAlertMessage(alertMessage);
    }

    private AlertMessageUpsertInput toAlertMessageUpsertInput(AlertMessage alertMessage) {
        AlertMessageUpsertInput safeInput = new AlertMessageUpsertInput();
        safeInput.setSpaceTypeId(alertMessage.getSpaceTypeId() == null
                ? null
                : Long.valueOf(String.valueOf(alertMessage.getSpaceTypeId())));
        safeInput.setSpaceTypeName(alertMessage.getSpaceTypeName() == null
                ? null
                : new String(String.valueOf(alertMessage.getSpaceTypeName())));
        safeInput.setThresholdType(alertMessage.getThresholdType() == null
                ? null
                : ThresholdType.valueOf(String.valueOf(alertMessage.getThresholdType().name())));
        safeInput.setAlertCategory(alertMessage.getAlertCategory() == null
                ? null
                : AlertType.valueOf(String.valueOf(alertMessage.getAlertCategory().name())));
        safeInput.setTitle(alertMessage.getTitle() == null
                ? null
                : new String(String.valueOf(alertMessage.getTitle())));
        safeInput.setMessage(alertMessage.getMessage() == null
                ? null
                : new String(String.valueOf(alertMessage.getMessage())));

        if (alertMessage.getAlertMessageLocations() != null) {
            for (AlertMessageLocation location : alertMessage.getAlertMessageLocations()) {
                if (location == null) {
                    continue;
                }
                AlertMessageLocationUpsertInput safeLocation = new AlertMessageLocationUpsertInput();
                safeLocation.setLevel(location.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(location.getLevel().name())));
                safeLocation.setCdmKeyId(location.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(String.valueOf(location.getCdmKeyId())));
                safeLocation.setStatus(location.getStatus() == null
                        ? null
                        : new String(String.valueOf(location.getStatus())));
                safeLocation.setCountryId(location.getCountryId() == null
                        ? null
                        : Long.valueOf(String.valueOf(location.getCountryId())));
                safeLocation.setCountryName(location.getCountryName() == null
                        ? null
                        : new String(String.valueOf(location.getCountryName())));
                safeInput.getAlertMessageLocations().add(safeLocation);
            }
        }

        return safeInput;
    }

    private AlertMessage prepareAlertMessage(AlertMessage alertMessage) {


        // Defensive: explicitly clear server-managed / sensitive fields that must
        // never be settable from the request payload (mitigates Unsafe Object
        // Binding when the entity is later passed to JPA save/saveAndFlush).
        alertMessage.setId(null);
        alertMessage.setModifiedAt(null);
        alertMessage.setAlertSentAt(null);
        if (alertMessage.getAlertMessageLocations() != null) {
            for (AlertMessageLocation loc : alertMessage.getAlertMessageLocations()) {
                loc.setId(null);
                loc.setAlertMessageId(null);
            }
        }

        // Validate SpaceType
        SpaceType existSpaceType = spaceTypeService.getExistingIdAndName(
                alertMessage.getSpaceTypeId(), alertMessage.getSpaceTypeName());

        if (existSpaceType == null) {
            throw new IllegalArgumentException("Invalid SpaceType");
        }

        // Validate and associate AlertMessageLocations
        for (AlertMessageLocation alertMsgLocation : alertMessage.getAlertMessageLocations()) {
            if (alertMsgLocation.getLevel() == LevelEnum.GLOBAL) {
                alertMsgLocation.setCountryId(null);
                alertMsgLocation.setCdmKeyId(null);
                alertMsgLocation.setCountryName(null);
            } else {
                Country existCountry = countryService.existsByCountryIdAndCdmKeyIdAndCountryName(
                        alertMsgLocation.getCountryId(),
                        alertMsgLocation.getCdmKeyId(),
                        alertMsgLocation.getCountryName());

                if (existCountry == null ||
                        existCountry.getId() == null ||
                        existCountry.getCdmKeyId() == null ||
                        existCountry.getTitleEn() == null) {
                    throw new IllegalArgumentException("Invalid Country");
                }
            }

            alertMsgLocation.setAlertMessage(alertMessage);
        }

        return alertMessage;
    }


    /**
     * Retrieves a alertMessage by its ID.
     *
     * @param id The ID of the alertMessage to retrieve.
     * @return ResponseEntity with a AlertMessageDTO if successful, else not found
     *         response.
     */
    @GetMapping("/{id}")
    public ResponseEntity<AlertMessageDTO> getAlertMessageById(
            @PathVariable Long id,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {

        AlertMessage alertMessage = alertMessageService.getAlertMessageById(id);

        if (alertMessage == null) {
            return ResponseEntity.notFound().build();
        }

        AlertMessageDTO resultDTO = AlertMessageMapper.INSTANCE
                .alertMessageToAlertMessageDTO(alertMessage, language);

        return ResponseEntity.ok(resultDTO);
    }

    /**
     * Deletes a alertMessage by ID.
     *
     * @param id The ID of the alertMessage to delete.
     * @return ResponseEntity with no content if successful, else not found
     *         response.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAlertMessage(@PathVariable Long id) {
        alertMessageService.deleteRole(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/thresholdTypes")
    public ResponseEntity<List<ThresholdType>> getThresholdTypes() {
        List<ThresholdType> thresholdTypes = Arrays.asList(ThresholdType.values());
        return ResponseEntity.ok(thresholdTypes);
    }

    @GetMapping("/alertTypes")
    public ResponseEntity<List<AlertType>> getAlertTypes() {
        List<AlertType> alertTypes = Arrays.asList(AlertType.values());
        return ResponseEntity.ok(alertTypes);
    }

    @GetMapping
    public ResponseEntity<List<AlertMessageDTO>> getListOfAlertNotification() {
        List<AlertMessageDTO> alertMessageDTOs = alertMessageService.getListOfAlertNotification();

        if (alertMessageDTOs == null || alertMessageDTOs.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(alertMessageDTOs);
    }

    @GetMapping("/startBatch")
    public ResponseEntity<Void> startBatch() {
        sensorAlertService.launchThresholdConfigurations();
        return ResponseEntity.accepted().build();
    }

    /**
     * Updates an existing alertMessage with alert sent flag.
     * 
     * @param id The ID of the alertMessage to update. *
     * @return ResponseEntity with the updated AlertMessageDTO if successful, else
     *         not found or internal server error response.
     */
    @PutMapping("/status/{id}")
    @Transactional
    public ResponseEntity<Void> updateAlertStatus(@PathVariable Long id) {
        alertMessageService.updateAlertStatus(id);
        return ResponseEntity.ok().build();
    }
}
