package com.capgemini.admin.back.model;

import java.util.List;
import lombok.Data;

@Data
public class PreferenceDTO {
    private String userEmailId;
    private String currentCityName;
    private Long favoriteBuilding;
    private Long favoriteFloorId;
    private List<BuildingDTO> visitedBuildings;
    private List<ServiceDTO> favoriteServices;
    private List<LanguageDTO> selectedLanguages;
}
