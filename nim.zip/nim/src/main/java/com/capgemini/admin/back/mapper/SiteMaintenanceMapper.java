package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.SiteMaintenance;
import com.capgemini.admin.back.model.SiteMaintenanceDTO;

@Named("SiteMaintenanceMapper")
@Mapper(config = DtoMapperConfig.class)
public interface SiteMaintenanceMapper {

    SiteMaintenanceMapper INSTANCE = Mappers.getMapper(SiteMaintenanceMapper.class);

    SiteMaintenance siteMaintenanceDTOToSiteMaintenance(SiteMaintenanceDTO in);

    SiteMaintenanceDTO siteMaintenanceToSiteMaintenanceDTO(SiteMaintenance in);
}
