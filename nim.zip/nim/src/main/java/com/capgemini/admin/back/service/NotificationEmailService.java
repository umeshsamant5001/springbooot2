package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.NotificationEmailMapper;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.EnumStatusScheduled;
import com.capgemini.admin.back.model.NotificationEmail;
import com.capgemini.admin.back.model.NotificationEmailDTO;
import com.capgemini.admin.back.repository.NotificationEmailRepository;
import com.capgemini.admin.back.service.smtp.SMTPSendMail;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NotificationEmailService {

    @Autowired
    private SMTPSendMail smtpSendMail;

    @Autowired
    private NotificationEmailRepository notificationEmailRepository;

    /**
     * Sends an email using SMTP with the provided notification email data to the
     * specified list of recipients.
     *
     * @param notificationEmailDTO The data object containing information for the
     *                             email, such as subject, content, etc.
     * @param addresses            A list of email addresses to which the email will
     *                             be sent.
     * @return True if the email was sent successfully, false otherwise.
     */
    public Boolean sendMail(NotificationEmailDTO notificationEmailDTO, List<String> addresses) {
        try {
            smtpSendMail.sendEmail(notificationEmailDTO, addresses);
        } catch (Exception e) {
            log.error("Error while sending email in NotificationEmailServce via MS Graph error: {}",  e.getMessage(), e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }
   
    /**
     * Retrieves all NotificationEmail entries with status RUNNING.
     * If any are found, it marks them as 'processing' to avoid duplicate handling.
     *
     * @return List of NotificationEmail objects currently running.
     */
    @Transactional
    public List<NotificationEmail> findAllRunning() {
        try {
            // Get the notifications with a lock on it
            List<NotificationEmail> listNotification = this.notificationEmailRepository
                    .findAllByStatus(EnumStatusScheduled.RUNNING);

            if (listNotification.size() > 0) {
                // Get the id of the notifications
                List<Long> listId = listNotification.stream()
                        .map(notification -> notification.getId())
                        .collect(Collectors.toList());

                // Set the processing attribut to TRUE on the notifications
                this.notificationEmailRepository.setProcessing(listId);
            }

            return listNotification;
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve running notification emails.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve running notification emails.");
        }
    }


    /**
     * Stops a running notification email by updating its status to
     * EnumStatusScheduled.STOPPED.
     *
     * @param notificationEmail The NotificationEmail object to be stopped.
     */
    public void stop(NotificationEmail notificationEmail) {
        NotificationEmail notificationEmailDB = this.notificationEmailRepository.findById(notificationEmail.getId())
                .orElse(null);

        if (Objects.nonNull(notificationEmailDB)) {
            notificationEmailDB.setStatus(EnumStatusScheduled.STOPPED);
            this.notificationEmailRepository.save(notificationEmailDB);
        }

    }
   
    /**
     * Marks the given list of NotificationEmail entries as PROCESSED.
     *
     * @param scheduledList List of NotificationEmail objects to be marked as processed.
     */
    @Transactional
    public void setProcessed(List<NotificationEmail> scheduledList) {
        try {
            if (scheduledList.size() > 0) {
                List<Long> listId = scheduledList.stream()
                        .map(notification -> notification.getId())
                        .collect(Collectors.toList());

                this.notificationEmailRepository.setProcessed(listId);
            }
        } catch (DataAccessException ex) {
            log.error("Failed to mark notification emails as processed.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update notification email status.");
        }
    }


    /**
     * Retrieves a notificationEmail from the repository based on the provided
     * notificationEmail ID.
     *
     * @param notificationEmailId The unique identifier of the notificationEmail to
     *                            be retrieved.
     * @return The NotificationEmail object corresponding to the provided ID if
     *         found in the repository.
     *         Returns null if the notificationEmail with the specified ID is not
     *         found.
     */
    public NotificationEmail getNotificationEmail(long notificationEmailId) {
        return this.notificationEmailRepository.findById(notificationEmailId).orElse(null);
    }

    /**
     * Deletes a notificationEmail from the repository.
     *
     * @param notificationEmail The Notification object to be deleted from the
     *                          repository.
     */
    public void delete(NotificationEmail notificationEmail) {
        this.notificationEmailRepository.delete(notificationEmail);
    }

    /**
     * Saves a notificationEmail to the repository.
     *
     * @param notificationEmail The NotificationEmail object to be saved in the
     *                          repository.
     * @return The saved NotificationEmail object.
     */
    public NotificationEmail save(NotificationEmail notificationEmail) {
        return this.notificationEmailRepository.save(notificationEmail);
    }

    /**
     * Updates an existing notificationEmail based on the provided
     * NotificationEmailDTO object.
     *
     * @param oldNotificationEmail The existing NotificationEmail object to be
     *                             updated.
     * @param notificationEmailDTO The NotificationEmailDTO object containing the
     *                             updated information.
     * @return The updated NotificationEmail object after the changes have been
     *         applied and saved in the repository.
     */
    public NotificationEmail update(NotificationEmail oldNotificationEmail, NotificationEmailDTO notificationEmailDTO) {
        oldNotificationEmail.setTitle(notificationEmailDTO.getTitle());
        oldNotificationEmail.setMessage(notificationEmailDTO.getMessage());
        oldNotificationEmail.setMessageType(notificationEmailDTO.getMessageType());
        oldNotificationEmail.setPriorityType(notificationEmailDTO.getPriorityType());
        oldNotificationEmail.setStartDate(notificationEmailDTO.getStartDate());
        oldNotificationEmail.setEndDate(notificationEmailDTO.getEndDate());
        oldNotificationEmail.setLastChange(new Date().getTime() / 1000);
        oldNotificationEmail.setStatus(notificationEmailDTO.getStatus());
        oldNotificationEmail.setAttributes(new HashMap<>(notificationEmailDTO.getAttributes()));
        return this.notificationEmailRepository.save(oldNotificationEmail);
    }

    /**
     * Retrieves a list of notificationEmails based on the specified filters.
     *
     * @param status The list of status types for filtering notificationsEmail.
     * @return List of notificationEmails matching the specified filters.
     */
    public List<NotificationEmail> getNotificationEmails(List<EnumPriorityType> priorityTypes,
            List<EnumStatusScheduled> status) {
        return this.notificationEmailRepository.findDistinctByPriorityTypeInAndStatusIn(priorityTypes, status);
    }

    /**
     * Returns a function that converts a List of NotificationEmail objects to a
     * List of NotificationEmailDTO objects.
     *
     * @return A Function taking a List of NotificationEmail and returning a List of
     *         NotificationEmailDTO.
     */
    public Function<List<NotificationEmail>, List<NotificationEmailDTO>> listNotificationEmailToNotificationEmailDTOList() {
        return in -> in.stream().map(toNotificationEmailDTO()).collect(Collectors.toList());
    }

    /**
     * Returns a function that converts a single NotificationEmail object to a
     * NotificationEmailDTO object.
     *
     * @return A Function taking a NotificationEmail and returning a
     *         NotificationEmailDTO.
     */
    private Function<NotificationEmail, NotificationEmailDTO> toNotificationEmailDTO() {
        return NotificationEmailMapper.INSTANCE::NotificationEmailToNotificationEmailDTO;
    }
}