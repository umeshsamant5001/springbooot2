package com.capgemini.admin.back.cache;

public class CacheEventLogger /* implements CacheEventListener<Object, Object> */ {

	// private static final Logger LOGGER =
	// LoggerFactory.getLogger(SmartOfficeCacheManager.class);
	/*
	 * @Override
	 * public void onEvent(Cache<? extends Object, ? extends Object> cacheEvent) {
	 * LOGGER.trace(String.format("key: %s - Old: %s - New: %s",
	 * cacheEvent.getKey(), cacheEvent.getOldValue(),
	 * cacheEvent.getNewValue()));
	 * }
	 */
}
