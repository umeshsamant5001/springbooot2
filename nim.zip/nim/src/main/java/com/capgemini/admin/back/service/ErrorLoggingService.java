package com.capgemini.admin.back.service;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.admin.back.mapper.ErrorLoggingMapper;
import com.capgemini.admin.back.model.EnumErrorLoggingType;
import com.capgemini.admin.back.model.EnumErrorType;
import com.capgemini.admin.back.model.ErrorLogging;
import com.capgemini.admin.back.model.ErrorLoggingDTO;
import com.capgemini.admin.back.repository.ErrorLoggingRepository;
import lombok.extern.slf4j.Slf4j;



@Service
@Slf4j
public class ErrorLoggingService {

	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";


	public static class ErrorLoggingUpsertInput {
		private final String className;
		private final String module;
		private final Integer lineNumber;
		private final String description;
		private final String state;
		private final EnumErrorType errorType;
		private final String data;
		private final Long loggingDate;
		private final EnumErrorLoggingType errorLoggingType;

		public ErrorLoggingUpsertInput(String className, String module, Integer lineNumber, String description,
				String state, EnumErrorType errorType, String data, Long loggingDate,
				EnumErrorLoggingType errorLoggingType) {
			this.className = className == null ? null : new String(String.valueOf(className));
			this.module = module == null ? null : new String(String.valueOf(module));
			this.lineNumber = lineNumber == null ? null : Integer.valueOf(String.valueOf(lineNumber));
			this.description = description == null ? null : new String(String.valueOf(description));
			this.state = state == null ? null : new String(String.valueOf(state));
			this.errorType = errorType == null
					? null
					: EnumErrorType.valueOf(String.valueOf(errorType.name()));
			this.data = data == null ? null : new String(String.valueOf(data));
			this.loggingDate = loggingDate == null ? null : Long.valueOf(String.valueOf(loggingDate));
			this.errorLoggingType = errorLoggingType == null
					? null
					: EnumErrorLoggingType.valueOf(String.valueOf(errorLoggingType.name()));
		}

		public String getClassName() {
			return className == null ? null : new String(String.valueOf(className));
		}

		public String getModule() {
			return module == null ? null : new String(String.valueOf(module));
		}

		public Integer getLineNumber() {
			return lineNumber == null ? null : Integer.valueOf(String.valueOf(lineNumber));
		}

		public String getDescription() {
			return description == null ? null : new String(String.valueOf(description));
		}

		public String getState() {
			return state == null ? null : new String(String.valueOf(state));
		}

		public EnumErrorType getErrorType() {
			return errorType == null
					? null
					: EnumErrorType.valueOf(String.valueOf(errorType.name()));
		}

		public String getData() {
			return data == null ? null : new String(String.valueOf(data));
		}

		public Long getLoggingDate() {
			return loggingDate == null ? null : Long.valueOf(String.valueOf(loggingDate));
		}

		public EnumErrorLoggingType getErrorLoggingType() {
			return errorLoggingType == null
					? null
					: EnumErrorLoggingType.valueOf(String.valueOf(errorLoggingType.name()));
		}
	}

	@Autowired
	private ErrorLoggingRepository errorloggingRepository;

	
    /**
     * Persists a new ErrorLogging entity to the database.
     *
     * @return the saved ErrorLogging object, or null if an exception occurs
     */
	public ErrorLogging createErrorLogging(ErrorLoggingUpsertInput errorLoggingInput) {
		if (Objects.isNull(errorLoggingInput)) {
			return null;
		}
		ErrorLogging save = null;
		try {
			ErrorLoggingUpsertInput scopedErrorLoggingInput = sanitizeErrorLoggingUpsertInput(errorLoggingInput);
			ErrorLogging sanitizedErrorLogging = sanitizeForPersistence(scopedErrorLoggingInput);
			save = this.errorloggingRepository.save(sanitizedErrorLogging);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return save;
	}


	private ErrorLogging sanitizeForPersistence(ErrorLoggingUpsertInput errorLoggingInput) {
		ErrorLogging sanitizedErrorLogging = new ErrorLogging();


		sanitizedErrorLogging.setId(null);
		String validatedClassName = validateAndSanitizeText(errorLoggingInput.getClassName(), 255, "className");
		String validatedModule = validateAndSanitizeText(errorLoggingInput.getModule(), 255, "module");
		Integer validatedLineNumber = errorLoggingInput.getLineNumber() == null
				? null
				: Integer.valueOf(errorLoggingInput.getLineNumber());
		String validatedDescription = validateAndSanitizeText(errorLoggingInput.getDescription(), 10000, "description");
		String validatedState = validateAndSanitizeText(errorLoggingInput.getState(), 255, "state");
		EnumErrorType validatedErrorType = errorLoggingInput.getErrorType() == null
				? null
				: EnumErrorType.valueOf(String.valueOf(errorLoggingInput.getErrorType().name()));
		String validatedData = validateAndSanitizeText(errorLoggingInput.getData(), 10000, "data");
		Long validatedLoggingDate = errorLoggingInput.getLoggingDate() == null
				? null
				: Long.valueOf(errorLoggingInput.getLoggingDate());
		EnumErrorLoggingType validatedErrorLoggingType = errorLoggingInput.getErrorLoggingType() == null
				? null
				: EnumErrorLoggingType.valueOf(String.valueOf(errorLoggingInput.getErrorLoggingType().name()));

		sanitizedErrorLogging.setClassName(validatedClassName == null ? null : new String(validatedClassName));
		sanitizedErrorLogging.setModule(validatedModule == null ? null : new String(validatedModule));
		sanitizedErrorLogging.setLineNumber(validatedLineNumber == null
				? null
				: Integer.valueOf(validatedLineNumber));
		sanitizedErrorLogging.setDescription(validatedDescription == null ? null : new String(validatedDescription));
		sanitizedErrorLogging.setState(validatedState == null ? null : new String(validatedState));
		sanitizedErrorLogging.setErrorType(validatedErrorType == null
				? null
				: EnumErrorType.valueOf(String.valueOf(validatedErrorType.name())));
		sanitizedErrorLogging.setData(validatedData == null ? null : new String(validatedData));
		sanitizedErrorLogging.setLoggingDate(validatedLoggingDate == null
				? null
				: Long.valueOf(validatedLoggingDate));
		sanitizedErrorLogging.setErrorLoggingType(validatedErrorLoggingType == null
				? null
				: EnumErrorLoggingType.valueOf(String.valueOf(validatedErrorLoggingType.name())));
		return sanitizedErrorLogging;
	}


	private ErrorLoggingUpsertInput sanitizeErrorLoggingUpsertInput(ErrorLoggingUpsertInput source) {
		if (source == null) {
			throw new IllegalArgumentException("Error logging input must not be null");
		}

		String safeClassName = source.getClassName() == null ? null : new String(String.valueOf(source.getClassName()));
		String safeModule = source.getModule() == null ? null : new String(String.valueOf(source.getModule()));
		Integer safeLineNumber = source.getLineNumber() == null ? null : Integer.valueOf(String.valueOf(source.getLineNumber()));
		String safeDescription = source.getDescription() == null ? null : new String(String.valueOf(source.getDescription()));
		String safeState = source.getState() == null ? null : new String(String.valueOf(source.getState()));
		EnumErrorType safeErrorType = source.getErrorType() == null
				? null
				: EnumErrorType.valueOf(String.valueOf(source.getErrorType().name()));
		String safeData = source.getData() == null ? null : new String(String.valueOf(source.getData()));
		Long safeLoggingDate = source.getLoggingDate() == null ? null : Long.valueOf(String.valueOf(source.getLoggingDate()));
		EnumErrorLoggingType safeErrorLoggingType = source.getErrorLoggingType() == null
				? null
				: EnumErrorLoggingType.valueOf(String.valueOf(source.getErrorLoggingType().name()));

		return new ErrorLoggingUpsertInput(safeClassName, safeModule, safeLineNumber, safeDescription,
				safeState, safeErrorType, safeData, safeLoggingDate, safeErrorLoggingType);
	}

	private String validateAndSanitizeText(String value, int maxLength, String fieldName) {

		if (Objects.isNull(value)) {
			return null;
		}
		String trimmed = value.trim();
		if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid " + fieldName + " value.");
		}
		return new String(trimmed);
	}

	
    /**
     * Converts a list of ErrorLogging entities to a list of ErrorLoggingDTOs.
     *
     * @return a Function that maps List<ErrorLogging> to List<ErrorLoggingDTO>
     */
	public Function<List<ErrorLogging>, List<ErrorLoggingDTO>> errorloggingListToErrorLoggingDTOList() {
		return in -> in.stream().map(toErrorLoggingDTO()).collect(Collectors.toList());
	}

	public Function<ErrorLogging, ErrorLoggingDTO> toErrorLoggingDTO() {
		return ErrorLoggingMapper.INSTANCE::errorloggingToErrorLoggingDTO;
	}

	public List<ErrorLogging> getAll() {
		return this.errorloggingRepository.findAll();
	}
}