package com.capgemini.admin.back.config;

import com.capgemini.admin.back.service.AzureKeyVaultService;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Initializes Firebase applications for Android and iOS based on the active
 * Spring profile.
 * <p>
 * This class was separated from {@code DeviceTokenService} to improve
 * modularity and follow
 * the single responsibility principle. It encapsulates all Firebase setup
 * logic, making the
 * codebase cleaner and easier to maintain.
 * </p>
 *
 * <p>
 * <b>Impact on existing code:</b> Any previous calls to
 * {@code deviceTokenService.initialize()}
 * for Firebase setup should now be replaced with
 * {@code FirebaseInitializer.initialize()}.and then
 * we can remove the firebase initializing code from devicetokenaervice safely.
 * Since this class is annotated with {@code @Component} and uses
 * {@code @PostConstruct},
 * initialization will happen automatically at application startup.
 * </p>
 */

@Component
@Slf4j
public class FirebaseInitializer {

    private final Environment environment;
    private boolean initialized = false;

    @Autowired
    AzureKeyVaultService azureKeyVaultService;

    public FirebaseInitializer(Environment environment) {
        this.environment = environment;
    }

    @PostConstruct
    public void initialize() {
        if (initialized)
            return;
        try {
            String androidFile = getServiceAccountFile("android");
            String iosFile = getServiceAccountFile("ios");
            String privateKey = null;
            String privateKeyId = null;
            if (isProfile("develop") || isProfile("dev") || isProfile("sit")) {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKeySit").getValue();
                privateKey = privateKey.replace("\\n", "\n");
                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyIdSit").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n"); // decode escaped newlines
            } else if (isProfile("uat") || isProfile("perf")) {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKeyUat").getValue();
                privateKey = privateKey.replace("\\n", "\n"); // decode escaped newlines
                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyIdUat").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n"); // decode escaped newlines
            } else {
                privateKey = azureKeyVaultService.getSecret("fcmPrivateKey").getValue();
                privateKey = privateKey.replace("\\n", "\n");
                privateKeyId = azureKeyVaultService.getSecret("fcmPrivateKeyId").getValue();
                privateKeyId = privateKeyId.replace("\\n", "\n");
            }
            initializeFirebaseApp("androidApp", androidFile, privateKey, privateKeyId);
            initializeFirebaseApp("iosApp", iosFile, privateKey, privateKeyId);
            initialized = true;
            log.info("[Firebase] Initialized for environment.");
        } catch (Exception e) {
            log.error("[Firebase] Initialization error", e);
        }
    }

    private void initializeFirebaseApp(String appName, String fileName, String privateKey, String privateKeyId)
            throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        try (InputStream serviceAccount = new ClassPathResource(fileName).getInputStream()) {
            Map<String, Object> credentialsMap = mapper.readValue(serviceAccount, Map.class);
            // Inject values from Azure Key Vault and resolve static placeholders
            credentialsMap.put("type", "service_account");
            credentialsMap.put("private_key", privateKey);
            credentialsMap.put("private_key_id", privateKeyId);
            // Convert back to InputStream
            byte[] updatedJson = mapper.writeValueAsBytes(credentialsMap);
            InputStream updatedStream = new java.io.ByteArrayInputStream(updatedJson);
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(updatedStream))
                    .build();
            FirebaseApp.initializeApp(options, appName);
            log.info("[Firebase] {} initialized with {}", appName, fileName);
        }
    }


    private String getServiceAccountFile(String platform) {
        if (isProfile("develop") || isProfile("dev"))
            return "service-account_" + platform + ".json";
        if (isProfile("sit"))
            return "service-account_" + platform + "_sit.json";
        if (isProfile("perf"))
            return "service-account_" + platform + "_perf.json";
        if (isProfile("uat"))
            return "service-account_" + platform + "_uat.json";
        if (isProfile("production"))
            return "service-account_" + platform + "_prod.json";
        throw new IllegalStateException("Unknown profile");
    }

    private boolean isProfile(String profile) {
        return Arrays.stream(environment.getActiveProfiles()).anyMatch(profile::equalsIgnoreCase);
    }
}
