package com.capgemini.admin.back.model;

import java.util.List;
import lombok.Data;

@Data
public class UserRoleLocationDTO {
    private Long userId;
    private Boolean subscribeAlert;
    private Long roleId;
    private String roleName;
    private List<LocationDTO> locations;
}
