package com.capgemini.admin.back.service;

import java.util.List;
import java.util.stream.Collectors;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.back.mapper.NewsMapper;
import com.capgemini.admin.back.model.Category;
import com.capgemini.admin.back.model.News;
import com.capgemini.admin.back.model.NewsDTO;

import com.capgemini.admin.back.repository.NewsRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NewsService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @Autowired
    private NewsRepository newsRepository;
 
 
    /**
     * Updates a news message in the database.
     * 
     * If the provided news object has a status of 'Active', this method ensures that
     * all other news entries are marked as 'Inactive' before saving the new one.
     * 
     * @param news The News object containing updated information.
     * @return The saved News object after persistence.
     */
    @Transactional
    public News updateNewsMessage(Long newsId, String categoryInput, String newsMessageInput,
            Integer statusInput, String lastModifiedByInput, Long lastModifiedDateInput,
            String linkTextInput) {

                log.info("===== UPDATE NEWS START =====");
                log.info("Request values -> id={}, status={}, category={}, linkText={}",newsId, statusInput, categoryInput, linkTextInput);
        if (newsId == null) {
            throw new IllegalArgumentException("Invalid news input");
        }

        Long validatedId = Long.valueOf(newsId);
        News existingNews = this.newsRepository.findById(validatedId)
                .orElseThrow(() -> new ResourceNotFoundException("News not found with existingNews ID :: " + validatedId));

        log.info("DB Before Update -> id={}, status={}, lastModifiedBy={}, lastModifiedDate={}", existingNews.getId(), existingNews.getStatus(), existingNews.getLastModifiedBy(), existingNews.getLastModifiedDate());
        Category validatedCategory = validateCategory(categoryInput);

        String validatedNewsMessage = sanitizeRequiredText(newsMessageInput, 10000);
        Integer validatedStatus = validateStatus(statusInput);
        String validatedLastModifiedBy = sanitizeOptionalText(lastModifiedByInput, 255);
        Long validatedLastModifiedDate = lastModifiedDateInput == null
                ? null
                : Long.valueOf(lastModifiedDateInput);
        String validatedLinkText = sanitizeOptionalText(linkTextInput, 255);

        existingNews.setCategory(validatedCategory == null
                ? null
                : Category.findByName(new String(String.valueOf(validatedCategory.name()))));
        existingNews.setNewsMessage(validatedNewsMessage == null ? null : new String(validatedNewsMessage));
        log.info("Status before force update = {}", existingNews.getStatus());

        existingNews.setStatus(validatedStatus == null ? null : Integer.valueOf(String.valueOf(validatedStatus)));
        
        log.info("Status after force update = {}", existingNews.getStatus());
        existingNews.setLastModifiedBy(validatedLastModifiedBy == null ? null : new String(validatedLastModifiedBy));
        existingNews.setLastModifiedDate(validatedLastModifiedDate == null ? null : Long.valueOf(validatedLastModifiedDate));
        existingNews.setLinkText(validatedLinkText == null ? null : new String(validatedLinkText));


        log.info("Before updatedNews() -> id={}, status={}",existingNews.getId(),existingNews.getStatus());
        try {
            // if status=Active then other should InActive
            if (existingNews.getStatus().equals(Constants.ACTIVE)) {      
                log.info("Status is ACTIVE. Executing updatedNews() query.");          
                newsRepository.updatedNews(existingNews.getId());            
                log.info("updatedNews() executed successfully.");        
            }        log.info("Before save() -> id={}, status={}",existingNews.getId(),existingNews.getStatus());        
            News savedNews = newsRepository.saveAndFlush(existingNews);
            log.info("After saveAndFlush() -> id={}, status={}",savedNews.getId(),savedNews.getStatus());
            News dbRecord = newsRepository.findById(savedNews.getId()).orElse(null);    
            if (dbRecord != null) {          
                log.info("DB After Save Reload -> id={}, status={}, lastModifiedDate={}",dbRecord.getId(),dbRecord.getStatus(),dbRecord.getLastModifiedDate());      
            }      
                log.info("===== UPDATE NEWS END =====");        
            return savedNews;   
        } catch (DataAccessException ex) {
            log.error("Database error while updating news message for id {}", validatedId, ex);
            throw new IllegalStateException("Unable to update news message at this time.");
        }

    }



    public News findById(Long id) {
        News existingNews = this.newsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("News not found with existingNews ID :: " + id));
        return existingNews;
    }

    public List<NewsDTO> getAllNewsMessage() {
        List<News> news = this.newsRepository.findAll();
        List<NewsDTO> newsDTOs = news.stream().map(newsMsg -> NewsMapper.INSTANCE.newsToNewsDTO(newsMsg))
                .collect(Collectors.toList());
        return newsDTOs;

    }

    private Category validateCategory(String category) {
        if (category == null) {
            throw new IllegalArgumentException("Invalid category input");
        }
        String validatedCategoryName = new String(String.valueOf(category).trim());
        if (validatedCategoryName.isEmpty()) {
            throw new IllegalArgumentException("Invalid category input");
        }
        Category validated = Category.findByName(new String(validatedCategoryName));
        if (validated == null) {
            throw new IllegalArgumentException("Invalid category input");
        }
        return validated;
    }

    private Integer validateStatus(Integer status) {

        if (status == null || !(status.equals(0) || status.equals(1))) {
            throw new IllegalArgumentException("Invalid status input");
        }
        return Integer.valueOf(String.valueOf(status));
    }

    private String sanitizeRequiredText(String value, int maxLength) {
        if (value == null) {
            throw new IllegalArgumentException("Required text input is missing");
        }
        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            throw new IllegalArgumentException("Required text input is blank");
        }
        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(validated);
    }

    private String sanitizeOptionalText(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            return null;
        }
        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(validated);
    }

    

}
