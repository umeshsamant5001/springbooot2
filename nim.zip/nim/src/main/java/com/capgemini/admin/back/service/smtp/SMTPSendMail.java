package com.capgemini.admin.back.service.smtp;


import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.model.EmailDTO;
import com.capgemini.admin.back.model.EnumPriorityType;
import com.capgemini.admin.back.model.NotificationEmailDTO;
import com.microsoft.graph.models.BodyType;
import com.microsoft.graph.models.EmailAddress;
import com.microsoft.graph.models.ItemBody;
import com.microsoft.graph.models.UserSendMailParameterSet;
import com.capgemini.admin.back.config.GraphHelper;
import com.microsoft.graph.models.Importance;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.models.Recipient;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SMTPSendMail {
         
    @Autowired
    ApplicationProperties applicationProperties;    
    
    @Autowired
    GraphHelper graphHelper;
 
    
    // Simplified notification email method    
    /**
     * Sends an email using NotificationEmailDTO and a list of recipient email addresses.
     * <p>
     * This method:
     * <ul>
     *   <li>Creates a Microsoft Graph Message object</li>
     *   <li>Sets the email priority</li>
     *   <li>Sends the email using Microsoft Graph</li>
     *   <li>Logs the execution time</li>
     * </ul>
     *
     * @param notificationEmailDTO DTO containing email title, body, and priority
     * @param addresses List of recipient email addresses
    */
    public void sendEmail(NotificationEmailDTO notificationEmailDTO,
                        List<String> addresses) {
        long start = System.currentTimeMillis();
        Message message = createGraphMessage(
                notificationEmailDTO.getTitle(),
                notificationEmailDTO.getMessage(),
                addresses
        );
        setPriority(message, notificationEmailDTO.getPriorityType());

        sendEmailViaGraph(message);
        logExecutionTime(start);
            
    }
    
    /**
     * Sends an email using EmailDTO via Microsoft Graph.
     * <p>
     * This method builds the email message, sets HTML content,
     * assigns recipients, sends the email, and logs execution time.
     * @param emailDTO DTO containing subject, body, recipients, and CC list
     */
    public void sendEmail(EmailDTO emailDTO) {

        long start = System.currentTimeMillis();
        Message message = new Message();
        message.subject = emailDTO.getSubject();

        // HTML Body
        ItemBody body = new ItemBody();
        body.contentType = BodyType.HTML;
        body.content = emailDTO.getBody();
        message.body = body;
        log.info("Email body: {}", body.toString());


        message.toRecipients = emailDTO.getAdressee().stream()
            .map(addr -> {
                Recipient r = new Recipient();
                r.emailAddress = new EmailAddress();
                r.emailAddress.address = addr;
                return r;
            })
            .collect(Collectors.toList());

        // CC recipients (if any)
        if (emailDTO.getCopies() != null && !emailDTO.getCopies().isEmpty()) {
            message.ccRecipients = emailDTO.getCopies().stream()
            .map(addr -> {
                Recipient r = new Recipient();
                r.emailAddress = new EmailAddress();
                r.emailAddress.address = addr;
                return r;
            })
            .collect(Collectors.toList());
        }
        
        logExecutionTime(start);
        // 2. Send via Microsoft Graph
        log.info("Sending email via Microsoft Graph...");
        log.info("Sending email via Microsoft Graph... message subject: {}, body: {}, toRecipients: {}, ccRecipients: {}",
                message.subject,message.body.content,
                message.toRecipients.stream().map(r -> r.emailAddress.address).collect(Collectors.joining(", ")),
                (message.ccRecipients != null) ? message.ccRecipients.stream().map(r -> r.emailAddress.address).collect(Collectors.joining(", ")) : "None"
        );
        graphHelper.getGraphClientForSendEmail()
            .users(applicationProperties.getSmtp().getEmail())
            .sendMail(
                UserSendMailParameterSet
                    .newBuilder()
                    .withMessage(message)
                    .withSaveToSentItems(true)
                    .build()
            )
            .buildRequest()
            .post();

        long execTimeInMs = System.currentTimeMillis() - start;
        log.info("Execution time : {} millisec.", execTimeInMs);
    }
    
    /**
     * Creates a Microsoft Graph Message object with subject, HTML body,
     * and recipient email addresses.
     * @param title Email subject
     * @param bodyContent HTML body content
     * @param addresses List of recipient email addresses
     * @return Configured Message object
     */
    private Message createGraphMessage(String title,
                                    String bodyContent,
                                    List<String> addresses) {

        Message message = new Message();
        message.subject = title;

        // HTML body (no MimeBodyPart needed)
        ItemBody body = new ItemBody();
        body.contentType = BodyType.HTML;
        body.content = bodyContent;
        message.body = body;

        // Recipients
        message.toRecipients = addresses.stream()
            .map(addr -> {
                Recipient r = new Recipient();
                r.emailAddress = new EmailAddress();
                r.emailAddress.address = addr;
                return r;
            })
            .collect(Collectors.toList());
        
        return message;
    }

    /**
     * Sends the given Message via Microsoft Graph API using
     * the configured SMTP email account.
     * @param message Email message to be sent
     */
    private void sendEmailViaGraph(Message message) {        
        graphHelper.getGraphClientForSendEmail()           
            .users(applicationProperties.getSmtp().getEmail())        
            .sendMail(
                UserSendMailParameterSet
                    .newBuilder()
                    .withMessage(message)
                    .withSaveToSentItems(true)
                    .build()
            )
            .buildRequest()
            .post();
    }    
        
    // Helper method to log execution time    
    /**
     * Logs the execution time for a method.
     * @param startTime Start time in milliseconds
     */
    private void logExecutionTime(long startTime) {
        long executionTime = System.currentTimeMillis() - startTime;
        log.info("Execution time: " + executionTime + " ms.");
    }

    // Helper method to set email priority    
    /**
     * Sets the email importance based on the given priority type.
     * @param message Email message
     * @param priority Priority level (HIGH, LOW, NORMAL)
     */
    private void setPriority(Message message, EnumPriorityType priority) {
        if (priority == EnumPriorityType.HIGH) {
            message.importance = Importance.HIGH;
        } else if (priority == EnumPriorityType.LOW) {
            message.importance = Importance.LOW;
        } else {
            message.importance = Importance.NORMAL;
        }
    }
}
