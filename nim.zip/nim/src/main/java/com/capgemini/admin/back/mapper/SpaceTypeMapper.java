package com.capgemini.admin.back.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.SpaceTypeDTO;

@Named("SpaceTypeMapper")
@Mapper(config = DtoMapperConfig.class)
public interface SpaceTypeMapper {

    SpaceTypeMapper INSTANCE = Mappers.getMapper(SpaceTypeMapper.class);

    @Mapping(source = "poiGroup.id", target = "poiGroupId") // Explicitly map poiGroupId
    SpaceTypeDTO spaceTypeToSpaceTypeDTO(SpaceType spaceType);

    @Mapping(target = "poiGroup", ignore = true) // Ignore full PoiGroup in the reverse mapping
    SpaceType spaceTypeDTOToSpaceType(SpaceTypeDTO spaceTypeDTO);

    List<SpaceTypeDTO> spaceTypesToSpaceTypeDTOs(List<SpaceType> spaceTypes);
}
