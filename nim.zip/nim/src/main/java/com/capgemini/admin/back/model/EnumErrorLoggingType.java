package com.capgemini.admin.back.model;

public enum EnumErrorLoggingType {

	NONE, DEFAULT, INFORMATION, WARNING, CRITICAL, USER;

	public static EnumErrorLoggingType findByName(String name) {
		EnumErrorLoggingType result = null;
		for (EnumErrorLoggingType errorLoggingType : values()) {
			if (errorLoggingType.name().equalsIgnoreCase(name)) {
				result = errorLoggingType;
				break;
			}
		}
		return result;
	}

}
