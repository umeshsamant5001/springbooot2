package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = false)
@Data
public class PoiGroupWriteRequest {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String name;

    @Size(max = 1000)
    private List<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributeKeys = new ArrayList<>();

    private Map<@Size(max = 255) @Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @Pattern(regexp = SAFE_TEXT_REGEX) String> attributes = new HashMap<>();

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String titleFr;

    @Size(max = 255)
    @Pattern(regexp = SAFE_TEXT_REGEX)
    private String titleEn;

    private Boolean isFromCdm;

    @Valid
    @Size(max = 1000)
    private List<PoiGroupSpaceTypeInput> spaceTypes = new ArrayList<>();

    private Boolean isVisibleOnPWA;

    @Size(max = 255)
    @Pattern(regexp = "(^$)|(^[^\\r\\n\\t\\p{Cntrl}]*\\.svg$)")
    private String icon;
}