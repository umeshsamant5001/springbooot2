package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class SecuredUserImportDTO {
    private String firstName;
    private String lastName;
    private String roleName;
    private String emailId;
    private String buildingTitleEn;
}
