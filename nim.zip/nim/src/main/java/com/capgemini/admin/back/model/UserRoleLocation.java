package com.capgemini.admin.back.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import javax.persistence.SequenceGenerator;
import javax.persistence.GenerationType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Enumerated;
import javax.persistence.EnumType;

@Table(name = "user_role_location")
@Entity
@Data
@EqualsAndHashCode
public class UserRoleLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "UserRoleLocation_Generator")
    @SequenceGenerator(name = "UserRoleLocation_Generator", sequenceName = "UserRoleLocation_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "role_id", updatable = false, insertable = false)
    private Long roleId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "user_id", updatable = false, insertable = false)
    private Long userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "level")
    private LevelEnum level;

    @Column(name = "cdm_key_id")
    private Long cdmKeyId;

    @Column(name = "alert_status")
    private Boolean alertStatus;

}