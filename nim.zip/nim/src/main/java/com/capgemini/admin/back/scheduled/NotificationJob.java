package com.capgemini.admin.back.scheduled;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgemini.admin.back.model.Notification;
import com.capgemini.admin.back.model.NotificationSent;
import com.capgemini.admin.back.service.NotificationSentDetailsService;

import com.capgemini.admin.back.service.NotificationSentService;
import com.capgemini.admin.back.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

import com.capgemini.admin.back.config.Constants;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
@Slf4j
public class NotificationJob extends ScheduledJob<Notification, NotificationSent> {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private NotificationSentService notificationSentService;

    @Autowired
    private NotificationSentDetailsService notificationSentDetailsService;
    // Prevent parallel execution
    private static final AtomicBoolean running = new AtomicBoolean(false);

    @Scheduled(
        cron = "${" + Constants.CONFIG_PATH_NOTIFICATION + ".cron}",
        zone = "${" + Constants.CONFIG_PATH_NOTIFICATION + ".tz}"
    )
       @SchedulerLock(
        name = "notificationJobLock",
        lockAtLeastFor = "PT50S",  // prevent rapid re-trigger
        lockAtMostFor = "PT5M"     // safety timeout
    )
    public void execJob() {

        String jobName = "NotificationJob";
        String threadName = Thread.currentThread().getName();
        long startTime = System.currentTimeMillis();

        // LOCK
        if (!running.compareAndSet(false, true)) {
            log.warn("[{}] Skip execution because previous run is still active | thread={}",
                    jobName, threadName);
            return;
        }

        log.info("[{}] Start execution | thread={} | triggerTime={}", jobName, threadName, new Date());

        try {
            super.execJob(new Date());
            log.info("[{}] Scheduler execution completed successfully", jobName);
        } catch (Exception e) {
            log.error("[{}] Scheduler execution failed", jobName, e);
        } finally {
            running.set(false);
            long durationMs = System.currentTimeMillis() - startTime;
            log.info("[{}] End execution | thread={} | durationMs={}", jobName, threadName, durationMs);
        }
    }

    @Override
    protected List<Notification> getScheduledRunning() {
        log.debug("[NotificationJob] Fetching running notifications");
        List<Notification> runningNotifications = this.notificationService.findAllRunning();
        log.info("[NotificationJob] Retrieved running notifications count={}", runningNotifications.size());
        return runningNotifications;
    }

    @Override
    protected List<NotificationSent> getLastScheduledSent() {
        log.debug("[NotificationJob] Fetching last sent notifications snapshot");
        List<NotificationSent> lastSentList = this.notificationSentService.findAllLast();
        log.info("[NotificationJob] Retrieved last sent notifications count={}", lastSentList.size());
        return lastSentList;
    }

    @Override
    protected boolean sendScheduled(Notification notification) {
        try {
            if (notification == null) {
                log.warn("[NotificationJob] sendScheduled skipped because notification is null");
                return false;
            }

            log.info("[NotificationJob] Sending notification id={} | thread={}",
                    notification.getId(), Thread.currentThread().getName());

            boolean sent = this.notificationService.sendNotification(notification);
            log.info("[NotificationJob] Send result for notification id={} => {}", notification.getId(), sent);
            return sent;

        } catch (Exception e) {
            log.error("[NotificationJob] Error while sending notification id={}",
                    notification != null ? notification.getId() : null, e);
            return false;
        }
    }

    @Override
    protected NotificationSent getNewScheduledSent() {
        return new NotificationSent();
    }

    @Override
    protected void saveScheduledSent(NotificationSent notificationSent) {
        if (notificationSent == null) {
            log.warn("[NotificationJob] saveScheduledSent skipped because notificationSent is null");
            return;
        }
        log.debug("[NotificationJob] Persisting NotificationSent entry for notificationId={}", notificationSent.getNotificationId());
        this.notificationSentService.save(notificationSent);
        log.debug("[NotificationJob] NotificationSent entry persisted for notificationId={}", notificationSent.getNotificationId());
    }

    @Override
    protected void stopScheduled(Notification notification) {
        if (notification == null) {
            log.warn("[NotificationJob] stopScheduled skipped because notification is null");
            return;
        }
        log.info("[NotificationJob] Stopping notification id={}", notification.getId());
        this.notificationService.stop(notification);
    }

    @Override
    protected void endJob(List<Notification> scheduledList) {
        int scheduledCount = scheduledList != null ? scheduledList.size() : 0;
        log.info("[NotificationJob] Finalizing job for notifications count={}", scheduledCount);

        this.notificationService.setProcessed(scheduledList);
        log.info("[NotificationJob] Processed status updated for notifications count={}", scheduledCount);

        // Cleanup sent details after full cycle completes successfully
        if (scheduledList != null && !scheduledList.isEmpty()) {
            for (Notification notification : scheduledList) {
                log.debug("[NotificationJob] Cleaning up sent details for notification id={}", notification.getId());
                notificationSentDetailsService.cleanupSuccess(notification.getId());
            }
            log.info("[NotificationJob] Cleanup completed for {} notifications", scheduledCount);
        }
    }
}
