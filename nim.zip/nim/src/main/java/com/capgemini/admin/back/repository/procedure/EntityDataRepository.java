package com.capgemini.admin.back.repository.procedure;

import com.capgemini.admin.back.model.procedure.EntityDataDTO;
import com.capgemini.admin.back.model.procedure.FrontLabel;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * we extends FrontLabel because we must have a Entity object
 */
@Repository
public interface EntityDataRepository extends JpaRepository<FrontLabel, Long> {

    @Procedure(name = "GetEntityData")
    List<EntityDataDTO> getEntityData(@Param("Entityname") String entityName);

}