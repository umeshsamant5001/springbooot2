package com.capgemini.admin.back.repository;

import java.util.List;

import javax.persistence.Tuple;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.admin.back.model.Poi;

@Repository
public interface PoiRepository extends JpaRepository<Poi, Long> {

        static final String BASE_QUERY_FIND_ALL = "SELECT poi FROM Poi poi " +
                        " INNER JOIN FETCH poi.spaceType spaceType " +
                        " LEFT JOIN FETCH spaceType.poiGroup poiGroup " +
                        " INNER JOIN FETCH poi.floor floor " +
                        " INNER JOIN floor.building building ";

        static final String BASE_QUERY_FIND_ALL_CDM = "SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType "
                        + " INNER JOIN FETCH poi.floor floor INNER JOIN floor.building building ";

        @RestResource(exported = false)
        @Query(BASE_QUERY_FIND_ALL_CDM
                        + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId) AND floor.id IN (:floorId)")
        List<Poi> findAllByTypeIdAndBuildingIdAndFloorId(
                        @Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @RestResource(exported = false)
        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND spaceType.id IN (:spaceTypeId)")
        List<Poi> findAllByTypeIdAndBuildingId(@Param("spaceTypeId") List<Long> spaceTypeId,
                        @Param("buildingId") List<Long> buildingId);

        @RestResource(exported = false)
        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId) AND floor.id IN (:floorId)")
        List<Poi> findAllByBuildingIdAndFloorId(@Param("buildingId") List<Long> buildingId,
                        @Param("floorId") List<Long> floorId);

        @RestResource(exported = false)
        @Query(BASE_QUERY_FIND_ALL + " WHERE building.id IN (:buildingId)")
        List<Poi> findAllByBuildingId(@Param("buildingId") List<Long> buildingId);

        @RestResource(exported = false)
        @Query("SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType " +
                        " INNER JOIN FETCH poi.floor floor " +
                        " WHERE floor.id = :floorId ANd spaceType.id = :spaceTypeId")
        List<Poi> findAllByTypeIdAndFloorId(@Param("spaceTypeId") Long spaceTypeId, @Param("floorId") Long floorId);

        @RestResource(exported = false)
        @Query("SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType " +
                        " INNER JOIN FETCH poi.floor floor " +
                        " WHERE floor.id = :floorId AND spaceType.id = :spaceTypeId")
        List<Poi> findAllBySpaceTypeIdAndFloorId(@Param("spaceTypeId") Long spaceTypeId,
                        @Param("floorId") Long floorId);

        @RestResource(exported = false)
        @Query("SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType " +
                        " INNER JOIN FETCH poi.floor floor " +
                        " WHERE floor.id = :floorId ORDER BY poi.name")
        List<Poi> findAllByFloorIdOrderByName(@Param("floorId") Long floorId);

        @RestResource(exported = false)
        @Query("SELECT poi FROM Poi poi INNER JOIN FETCH poi.spaceType spaceType " +
                        " INNER JOIN FETCH poi.floor floor " +
                        " WHERE floor.id = :floorId ORDER BY poi.name")
        List<Poi> findAllByFloorIdOrderByNameCDM(@Param("floorId") Long floorId);

        @RestResource(exported = false)
        Poi findByName(@Param("name") String name);

        @RestResource(exported = false)
        Poi findByFloorIdAndName(@Param("floorId") Long floorId, @Param("name") String name);

        long countBySpaceTypeId(@Param("spaceTypeId") @RequestParam("spaceTypeId") Long spaceTypeId);

        long countByEquipmentsId(@Param("equipmentId") Long equipmentId);

        @Query("SELECT spaceType.id as spaceTypeId, count(*) as nbPoi FROM Poi poi INNER JOIN poi.spaceType spaceType GROUP BY spaceType.id")
        List<Tuple> countByType();

        @Query("SELECT spaceType.id as spaceTypeId, count(*) as nbPoi FROM Poi poi INNER JOIN poi.spaceType spaceType GROUP BY spaceType.id")
        List<Tuple> countBySpaceType();

        @Query("SELECT equipment.id as equipmentId, count(*) as nbPoi FROM Poi poi INNER JOIN poi.equipments equipment GROUP BY equipment.id")
        List<Tuple> countByEquipment();

        List<Poi> findAllByNameIn(@Param("name") List<String> name);

        @Query("SELECT spaceType.id as typeId, count(*) as nbPoi FROM Poi poi INNER JOIN poi.spaceType spaceType " +
                        "WHERE poi.floor.building.id = :buildingId GROUP BY spaceType.id")
        List<Tuple> countByTypeAndBuilding(@Param("buildingId") Long buildingId);

        @Query("SELECT spaceType.id as spaceTypeId, count(*) as nbPoi FROM Poi poi INNER JOIN poi.spaceType spaceType "
                        +
                        "WHERE poi.floor.building.id = :buildingId GROUP BY spaceType.id")
        List<Tuple> countBySpaceTypeAndBuilding(@Param("buildingId") Long buildingId);

        @Query("SELECT spaceType.id as typeId, count(*) as nbPoi FROM Poi poi " +
                        "INNER JOIN poi.spaceType spaceType " +
                        "WHERE poi.floor.building.id = :buildingId AND poi.floor.id = :floorId " +
                        "GROUP BY spaceType.id")
        List<Tuple> countByTypeAndBuildingAndFloor(@Param("buildingId") Long buildingId,
                        @Param("floorId") Long floorId);

        @Query("SELECT spaceType.id as typeId, count(*) as nbPoi FROM Poi poi " +
                        "INNER JOIN poi.spaceType spaceType " +
                        "WHERE poi.floor.building.id = :buildingId AND poi.floor.id = :floorId " +
                        "GROUP BY spaceType.id")
        List<Tuple> countBySpaceTypeAndBuildingAndFloor(@Param("buildingId") Long buildingId,
                        @Param("floorId") Long floorId);

        // Base of a SQL query to export device with attributes values
        static final String EXPORT_BASE_QUERY = "SELECT country.title_en as countryTitle, " +
                        "city.title_en as cityTitle,  " +
                        "site.title_en as siteTile, " +
                        "building.title_en as buildingTitle, " +
                        "poi.title_en as poiTitle,  " +
                        "poi.name AS poi_name, " +
                        "poiGroup.name AS poiGroupName, " +
                        "space_type.space_type_name AS spaceTypeName, " +
                        "attributes.tempC AS tempC, " +
                        "attributes.humidity AS humidity, " +
                        "UPPER(attributes.state) AS state, " +
                        "floor.floor_index AS poi_floor_index, " +
                        "attributes.lux AS lux, " +
                        "attributes.sound AS sound, " +
                        "attributes.co2 AS co2, " +
                        "attributes_b.[cdm.asset_code] AS asset_code " +
                        "FROM poi  " +
                        "INNER JOIN device ON (poi.name = device.poi_name)  " +
                        "INNER JOIN floor ON (poi.floor_id = floor.id)  " +
                        "INNER JOIN space_type ON (poi.space_type_id = space_type.id)   " + // -- Join SpaceType
                        "INNER JOIN poi_group AS poiGroup ON (space_type.poi_group_id = poiGroup.id)  " + // -- Join
                                                                                                          // PoiGroup
                                                                                                          // via
                                                                                                          // SpaceType
                        "INNER JOIN building ON (floor.building_id = building.id)  " +
                        "INNER JOIN site ON (building.site_id = site.id)  " +
                        "INNER JOIN city ON (site.city_id = city.id)  " +
                        "INNER JOIN country ON (city.country_id = country.id)  " +
                        "INNER JOIN (SELECT * FROM (SELECT building_id, att_key, att_value FROM building_attribute) AS attributes_b_source  "
                        +
                        "PIVOT (MAX(att_value) FOR att_key IN ([cdm.asset_code])) AS result_b_attributes ) AS attributes_b  "
                        +
                        "ON building.id = attributes_b.building_id  " +
                        "LEFT JOIN (SELECT * FROM (SELECT device_uuid, att_key, att_value FROM device_attributes) AS attributes_source  "
                        +
                        "PIVOT (MAX(att_value) FOR att_key IN (tempC, humidity, state, lux, sound, co2)) AS result_attributes ) AS attributes  "
                        +
                        "ON (attributes.device_uuid = device.uuid)";

        static final String EXPORT_ORDER_BY = " ORDER BY poi.name";

        // Base of a SQL query to export device with attributes values
        static final String EXPORT_BASE_QUERY_CDM = "SELECT " +
                        "    country.title_en AS countryTitle, " +
                        "    city.title_en AS cityTitle, " +
                        "    site.title_en AS siteTitle, " +
                        "    building.title_en AS buildingTitle, " +
                        "    poi.title_en AS poiTitle, " +
                        "    poi.name AS poi_name, " +
                        "    poiGroup.name AS poiGroupName, " +
                        "    spaceType.space_type_name AS spaceTypeName, " +
                        "    attributes.tempC, " +
                        "    attributes.humidity, " +
                        "    UPPER(attributes.state) AS state, " +
                        "    floor.floor_index AS poi_floor_index, " +
                        "    attributes.lux, " +
                        "    attributes.sound, " +
                        "    attributes.co2, " +
                        "    attributes_b.[cdm.asset_code] " +
                        "FROM poi " +
                        "    INNER JOIN device ON poi.name = device.poi_name " +
                        "    INNER JOIN floor ON poi.floor_id = floor.id " +
                        "    INNER JOIN space_type AS spaceType ON poi.space_type_id = spaceType.id " +
                        "    INNER JOIN poi_group AS poiGroup ON spaceType.poi_group_id = poiGroup.id " +
                        "    INNER JOIN building ON floor.building_id = building.id " +
                        "    INNER JOIN site ON building.site_id = site.id " +
                        "    INNER JOIN city ON site.city_id = city.id " +
                        "    INNER JOIN country ON city.country_id = country.id " +
                        "    INNER JOIN ( " +
                        "        SELECT * FROM ( " +
                        "            SELECT building_id, att_key, att_value " +
                        "            FROM building_attribute " +
                        "        ) AS attributes_b_source " +
                        "        PIVOT ( " +
                        "            MAX(att_value) FOR att_key IN ([cdm.asset_code]) " +
                        "        ) AS result_b_attributes " +
                        "    ) AS attributes_b ON building.id = attributes_b.building_id " +
                        "    LEFT JOIN ( " +
                        "        SELECT * FROM ( " +
                        "            SELECT device_uuid, att_key, att_value " +
                        "            FROM device_attributes " +
                        "        ) AS attributes_source " +
                        "        PIVOT ( " +
                        "            MAX(att_value) FOR att_key IN (tempC, humidity, state, lux, sound, co2) " +
                        "        ) AS result_attributes " +
                        "    ) AS attributes ON (attributes.device_uuid = device.uuid) ";

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE country.id = :countryId " + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataByCountryIdCDM(@Param("countryId") Long countryId);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findAllExportDataCDM();

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE spaceType.id IN (:spaceTypeIds) "
                        + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataBySpaceTypeId(@Param("spaceTypeIds") List<Long> spaceTypeIds);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE country.id = :countryId AND spaceType.id IN (:spaceTypeIds) "
                        + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataByCountryIdAndSpaceTypeId(@Param("countryId") Long countryId,
                        @Param("spaceTypeIds") List<Long> spaceTypeIds);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE city.id = :cityId " + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataByCityIdCDM(@Param("cityId") Long cityId);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE city.id = :cityId AND spaceType.id IN (:spaceTypeIds) "
                        + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataByCityIdAndSpaceTypeId(@Param("cityId") Long cityId,
                        @Param("spaceTypeIds") List<Long> spaceTypeIds);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE site.id = :siteId " + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataBySiteIdCDM(@Param("siteId") Long siteId);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_CDM + " WHERE site.id = :siteId AND spaceType.id IN (:spaceTypeIds) "
                        + EXPORT_ORDER_BY, nativeQuery = true)
        List<List<String>> findExportDataBySiteIdAndSpaceTypeId(@Param("siteId") Long siteId,
                        @Param("spaceTypeIds") List<Long> spaceTypeIds);

        static final String EXPORT_BASE_QUERY_BUILDING = "SELECT building_attribute.att_value AS buildingName, floor.title_en AS floorTitle, poi.name AS poiName, poi.title_en AS poiTitle, poi_group.name AS poiGroupName, "
                        +
                        " attributes.x, attributes.y, attributes.conf_room_mail, attributes.capacity, attributes.hidePoi, "
                        +
                        " device.uuid AS deviceUuid, device.status AS deviceStatus,device.device_type AS deviceType " +
                        " FROM building INNER JOIN floor ON (building.id = floor.building_id) " +
                        " INNER JOIN poi ON (floor.id = poi.floor_id) " +
                        "INNER JOIN space_type ON (poi.space_type_id = space_type.id) " +
                        "INNER JOIN poi_group ON (space_type.poi_group_id = poi_group.id) " +
                        " LEFT JOIN ( SELECT * FROM ( SELECT poi_id, att_key, att_value FROM poi_attributes ) AS attributes_source "
                        +
                        " PIVOT ( MAX(att_value) FOR att_key IN (x, y, conf_room_mail, capacity, hidePoi) ) AS result_attributes ) AS attributes "
                        +
                        " ON (attributes.poi_id = poi.id) " +
                        " LEFT JOIN building_attribute ON (building.id = building_attribute.building_id AND building_attribute.att_key = 'cdm.asset_code') "
                        +
                        " LEFT JOIN device ON (poi.name = device.poi_name)";

        // FOR CDM
        static final String EXPORT_BASE_QUERY_BUILDING_CDM = "SELECT building_attribute.att_value AS buildingName, " +
                        "floor.title_en AS floorTitle, " +
                        "poi.name AS poiName, " +
                        "poi.title_en AS poiTitle, " +
                        "poi_group.name AS poiGroupName," +
                        "space_type.space_type_name AS spaceTypeName," +
                        "attributes.x, " +
                        "attributes.y, " +
                        "attributes.conf_room_mail, " +
                        "attributes.capacity, " +
                        "attributes.hidePoi, " +
                        "device.uuid AS deviceUuid, " +
                        "CASE WHEN device.last_change BETWEEN 0 AND 253402300799 THEN " +
                        "DATEADD(SECOND, device.last_change, '1970-01-01 00:00:00') ELSE NULL END AS lastDataReceived, "
                        +
                        "device.status AS deviceStatus, " +
                        "device.device_type AS deviceType ," +
                        "device_attributes.swVersion AS swVersion , " +
                        "device_attributes.vddPct AS vddPct " +
                        "FROM building " +
                        "INNER JOIN floor ON (building.id = floor.building_id) " +
                        "INNER JOIN poi ON (floor.id = poi.floor_id) " +
                        "INNER JOIN space_type ON (poi.space_type_id = space_type.id) " +
                        " INNER JOIN poi_group ON (space_type.poi_group_id = poi_group.id) " +
                        "LEFT JOIN ( " +
                        "    SELECT * FROM ( " +
                        "        SELECT poi_id, att_key, att_value FROM poi_attributes " +
                        "    ) AS attributes_source " +
                        "    PIVOT (MAX(att_value) FOR att_key IN (x, y, conf_room_mail, capacity, hidePoi)) AS result_attributes "
                        +
                        ") AS attributes ON (attributes.poi_id = poi.id) " +
                        "LEFT JOIN building_attribute ON (building.id = building_attribute.building_id AND building_attribute.att_key = 'cdm.asset_code') "
                        +
                        "LEFT JOIN device ON (poi.name = device.poi_name) " +
                        "LEFT JOIN ( " +
                        "    SELECT * FROM ( " +
                        "   	SELECT device_uuid, att_key, att_value FROM device_attributes " +
                        "	) AS device_attr_source " +
                        "	PIVOT (MAX(att_value) FOR att_key IN (swVersion, vddPct)) AS pivoted_device_attributes " +
                        ") AS device_attributes ON (device.uuid = device_attributes.device_uuid)";

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_BUILDING_CDM
                        + " WHERE building.id = :buildingId order by poiName ASC", nativeQuery = true)
        List<List<String>> findExportDataByBuildingIdCDM(@Param("buildingId") Long buildingId);

        @RestResource(exported = false)
        @Query(value = EXPORT_BASE_QUERY_BUILDING_CDM
                        + " WHERE floor.id = :floorId order by poiName ASC", nativeQuery = true)
        List<List<String>> findExportDataByFloorIdCDM(@Param("floorId") Long floorId);

        @Query("SELECT INDEX(attributes), attributes FROM Poi poi INNER JOIN poi.attributes attributes WHERE poi.id = :poiId")
        List<Tuple> getAttributesById(@Param("poiId") Long poiId);

        @Modifying
        @Query(value = "UPDATE poi_attributes SET att_value = :value WHERE att_key = :key", nativeQuery = true)
        void setShowAttribute(@Param("value") String value, @Param("key") String key);

        // for cdm
        @Modifying
        @Transactional
        @Query(value = "INSERT INTO poi_attributes (poi_id, att_key, att_value) " +
                        "SELECT p.id, :attKey, :attValue FROM poi p " +
                        "WHERE p.space_type_id = :spaceTypeId AND NOT EXISTS (" +
                        "SELECT 1 FROM poi_attributes pa WHERE pa.poi_id = p.id AND pa.att_key = :attKey)", nativeQuery = true)
        int addAttributeToPoisWithoutItCDM(@Param("spaceTypeId") Long spaceTypeId, @Param("attKey") String attKey,
                        @Param("attValue") String attValue);

        // for cdm
        @Modifying
        @Transactional
        @Query(value = "DELETE FROM poi_attributes " +
                        "WHERE poi_id IN (SELECT p.id FROM poi p WHERE p.space_type_id = :spaceTypeId) " +
                        "AND att_key = :attKey", nativeQuery = true)
        int deleteAttributeFromPoisCDM(@Param("spaceTypeId") Long spaceTypeId, @Param("attKey") String attKey);

        @Query("SELECT p FROM Poi p " +
                        "JOIN p.floor f " +
                        "JOIN p.spaceType st " +
                        "JOIN st.poiGroup pg " +
                        "JOIN f.building b " +
                        "JOIN b.site s " +
                        "JOIN s.city c " +
                        "JOIN c.country co " +
                        "WHERE pg.id = :poiGroupId AND co.id = :countryId")

        List<Poi> findByPoiGroupIdAndCountryId(@Param("poiGroupId") Long poiGroupId,
                        @Param("countryId") Long countryId);

        @Query(value = "SELECT NEXT VALUE FOR Poi_Sequence", nativeQuery = true)
        Integer findByNextPoiSequence();

}
