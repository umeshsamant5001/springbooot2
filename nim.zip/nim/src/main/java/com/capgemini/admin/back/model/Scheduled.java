package com.capgemini.admin.back.model;

import java.util.Map;

public interface Scheduled {
    public Long getId();

    public Long getStartDate();

    public Long getEndDate();

    public Long getLastChange();

    public void setLastChange(Long lastChange);

    public EnumStatusScheduled getStatus();

    public void setStatus(EnumStatusScheduled status);

    public Map<String, String> getAttributes();
}