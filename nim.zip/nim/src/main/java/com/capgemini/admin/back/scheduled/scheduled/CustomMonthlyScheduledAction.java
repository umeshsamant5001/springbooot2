package com.capgemini.admin.back.scheduled.scheduled;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.time.DateUtils;

import com.capgemini.admin.back.model.Scheduled;
import com.capgemini.admin.back.model.ScheduledSent;
import com.capgemini.admin.back.config.Constants;

/**
 * Class for the type of Scheduled to send "custom monthly".
 */
public class CustomMonthlyScheduledAction<N extends Scheduled, S extends ScheduledSent> extends ScheduledAction<N, S> {

    public boolean checkType(N scheduled) {
        return scheduled.getAttributes().containsKey("month");
    }

    @Override
    public boolean shouldBeSent() {
        // Get the start date
        Date startDate = this.getRealStartDate();
        // If present, get the end date
        Date endDate = this.getRealEndDate();
        if (DateUtils.truncatedCompareTo(this.now, startDate, Calendar.MONTH) < 0
                || Objects.nonNull(endDate) && DateUtils.truncatedCompareTo(this.now, endDate, Calendar.MONTH) > 0) {
            // We are outside of the date range
            return false;
        }

        if (Objects.nonNull(this.lastScheduledSent)) {
            Date sentAt = new Date(this.lastScheduledSent.getSentAt() * 1000);
            if (DateUtils.truncatedCompareTo(this.now, sentAt, Calendar.MONTH) == 0) {
                // A Scheduled was already sent for this month
                return false;
            }
        }

        // Get the recurence (send every X month)
        Integer recur = Integer.parseInt(scheduled.getAttributes().get("month"));

        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        // We search the month of the futur send of Scheduled
        while (DateUtils.truncatedCompareTo(cal.getTime(), this.now, Calendar.MONTH) < 0) {
            cal.add(Calendar.MONTH, recur);
        }

        if (DateUtils.truncatedCompareTo(cal.getTime(), this.now, Calendar.MONTH) != 0) {
            // The next send is not this month
            return false;
        }

        if (DateUtils.truncatedCompareTo(this.now, this.findTheDayInMonth(this.now), Calendar.DAY_OF_MONTH) != 0) {
            // The next send is not today
            return false;
        }

        return true;
    }

    @Override
    public boolean wasLastSent() {
        // Get the real end date
        Date endDate = this.getRealEndDate();

        if (Objects.isNull(endDate)) {
            return false;
        }

        return DateUtils.truncatedCompareTo(this.now, endDate, Calendar.DAY_OF_MONTH) == 0;
    }

    /**
     * Calcul the start date base on the day, specificDay, specificFilter
     * 
     * @return
     */
    private Date getRealStartDate() {
        Date startDate = new Date(this.scheduled.getStartDate() * 1000);

        Date dayInMonth = this.findTheDayInMonth(startDate);

        if (DateUtils.truncatedCompareTo(startDate, dayInMonth, Calendar.DAY_OF_MONTH) > 0) {
            // If the dayInMonth is before the startDate, so the real startDate is the next
            // month
            Calendar cal = Calendar.getInstance();
            cal.setTime(startDate);
            cal.add(Calendar.MONTH, 1);
            return this.findTheDayInMonth(cal.getTime());
        }

        return startDate;
    }

    /**
     * Calcul the end date based on the start date, the recurence, the occurence and
     * the end date.
     * 
     * @return
     */
    private Date getRealEndDate() {
        // Get the recurence (send every X month)
        Integer recur = Integer.parseInt(scheduled.getAttributes().get("month"));

        // Get the start date
        Date startDate = this.getRealStartDate();
        // If present, get the end date
        Date endDate = null;
        if (Objects.nonNull(this.scheduled.getEndDate())) {
            endDate = new Date(this.scheduled.getEndDate() * 1000);

            Calendar endCal = Calendar.getInstance();
            endCal.setTime(startDate);
            Date prevDate = startDate;
            while (DateUtils.truncatedCompareTo(endCal.getTime(), endDate, Calendar.MONTH) <= 0) {
                prevDate = endCal.getTime();
                endCal.add(Calendar.MONTH, recur);
            }

            endDate = prevDate;
        } else if (this.scheduled.getAttributes().containsKey("occurence")) {
            // Else get the "occurence"
            Integer occurence = Integer.parseInt(this.scheduled.getAttributes().get("occurence"));
            // Calcul the end date base on the "startDate", "recur" and "occurrence"
            Calendar endCal = Calendar.getInstance();
            endCal.setTime(startDate);
            endCal.add(Calendar.MONTH, occurence * recur - 1);
            endDate = endCal.getTime();
        } else {
            // No End date
        }

        if (Objects.nonNull(endDate)) {
            endDate = this.findTheDayInMonth(endDate);
        }

        return endDate;
    }

    private Integer parseDay(String day) {
        switch (day) {
            case "Monday":
                return Calendar.MONDAY;
            case "Tuesday":
                return Calendar.TUESDAY;
            case "Wednesday":
                return Calendar.WEDNESDAY;
            case "Thursday":
                return Calendar.THURSDAY;
            case "Friday":
                return Calendar.FRIDAY;
            case "Saturday":
                return Calendar.SATURDAY;
            case "Sunday":
                return Calendar.SUNDAY;
            default:
                return null;
        }
    }

    /**
     * Count the number of days of week in the month.
     * 
     * For example : the number of monday in a month.
     * 
     * @param date      The date to extract the Month
     * @param weekOfDay The day of week to count (like Calendar.MONDAY)
     * @return
     */
    private int countNbDayOfTheWeek(Date date, int weekOfDay) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        int maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        int count = 0;
        for (int i = 1; i <= maxDays; i++) {
            cal.set(Calendar.DAY_OF_MONTH, i);
            if (cal.get(Calendar.DAY_OF_WEEK) == weekOfDay) {
                count++;
            }
        }

        return count;
    }

    /**
     * Return the day of the month in which the Scheduled should send.
     * 
     * @param date
     * @return
     */
    private Date findTheDayInMonth(Date date) {
        if (scheduled.getAttributes().containsKey("day")) {
            Integer dayOfMonth = Integer.parseInt(scheduled.getAttributes().get("day"));
            Integer nbDaysOfMonth = this.countNbDaysInMonth(date);

            Calendar calDay = Calendar.getInstance();
            calDay.setTime(date);
            calDay.set(Calendar.DAY_OF_MONTH, Math.min(dayOfMonth, nbDaysOfMonth));

            return calDay.getTime();
        } else {
            String specificFilter = scheduled.getAttributes().get("specificFilter");
            Integer specificDay = this.parseDay(scheduled.getAttributes().get("specificDay"));

            if (Objects.isNull(specificDay)) {
                // Throw ?
                return null;
            }

            Calendar calDay = Calendar.getInstance();
            calDay.setTime(date);
            calDay.set(Calendar.DAY_OF_WEEK, specificDay);

            if (Constants.MONTH_FILTER_FIRST.equals(specificFilter)) {
                calDay.set(Calendar.DAY_OF_WEEK_IN_MONTH, 1);
            } else if (Constants.MONTH_FILTER_SECOND.equals(specificFilter)) {
                calDay.set(Calendar.DAY_OF_WEEK_IN_MONTH, 2);
            } else if (Constants.MONTH_FILTER_THIRD.equals(specificFilter)) {
                calDay.set(Calendar.DAY_OF_WEEK_IN_MONTH, 3);
            } else if (Constants.MONTH_FILTER_FOURTH.equals(specificFilter)) {
                calDay.set(Calendar.DAY_OF_WEEK_IN_MONTH, 4);
            } else if (Constants.MONTH_FILTER_LAST.equals(specificFilter)) {
                int nbDay = this.countNbDayOfTheWeek(date, specificDay);
                calDay.set(Calendar.DAY_OF_WEEK_IN_MONTH, nbDay);
            }

            return calDay.getTime();
        }
    }

    private int countNbDaysInMonth(Date date) {
        Calendar calDay = Calendar.getInstance();
        calDay.setTime(date);
        // We're going to the next month
        calDay.add(Calendar.MONTH, 1);
        // Then, the first day of the month
        calDay.set(Calendar.DAY_OF_MONTH, 1);
        // Finaly, on e day before to go to the last day of the previous month.
        calDay.add(Calendar.DAY_OF_MONTH, -1);

        return calDay.get(Calendar.DAY_OF_MONTH);
    }
}
