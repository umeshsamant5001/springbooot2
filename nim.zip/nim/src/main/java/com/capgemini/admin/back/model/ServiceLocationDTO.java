package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class ServiceLocationDTO {
        private Long id;
        private ServiceDTO service;
        private Long serviceId;
        private LevelEnum level;
        private Long cdmKeyId;
        private String status;
        // Only present on DTO
        private String name;
}
