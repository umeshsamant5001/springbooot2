package com.capgemini.admin.back.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.model.ConfigValue;
import com.capgemini.admin.back.repository.ConfigRepository;

@Service
public class ConfigService {

    @Autowired
    private ConfigRepository configRepository;
  
    /**
     * Retrieves a configuration value by its key name.
     *
     * @param keyName the name of the configuration key to search for
     * @return the ConfigValue object associated with the given key name, or null if not found
     */
    public ConfigValue findByKeyName(String keyName) {
        return this.configRepository.findByKeyName(keyName);
    }
}
