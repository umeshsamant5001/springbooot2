package com.capgemini.admin.back.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DevicePOJO implements Serializable {

    private static final long serialVersionUID = -1427568101793065203L;

    private String poiName;

    private String deviceType;

    private String uuid;

    private String poiSpaceTypeName;

    private int poiSpaceTypeKeyId;

}
