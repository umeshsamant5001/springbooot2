package com.capgemini.admin.back.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;


import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.CountryTenant;
import com.capgemini.admin.back.repository.CountryRepository;
import com.capgemini.admin.back.repository.CountryTenantRepository;


@Service
@Slf4j
public class CountryTenantService {


    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @Autowired
    CountryTenantRepository countryTenantRepository;

    @Autowired
    CountryRepository countryRepository;

    private static final class CountryTenantPersistData {
        private final Long countryId;
        private final String tenant;
        private final String username;
        private final String password;
        private final String basic;

        private CountryTenantPersistData(Long countryId, String tenant, String username, String password, String basic) {
            this.countryId = countryId == null ? null : Long.valueOf(String.valueOf(countryId));
            this.tenant = tenant == null ? null : new String(String.valueOf(tenant));
            this.username = username == null ? null : new String(String.valueOf(username));
            this.password = password == null ? null : new String(String.valueOf(password));
            this.basic = basic == null ? null : new String(String.valueOf(basic));
        }

        public Long getCountryId() {
            return countryId == null ? null : Long.valueOf(String.valueOf(countryId));
        }

        public String getTenant() {
            return tenant == null ? null : new String(String.valueOf(tenant));
        }

        public String getUsername() {
            return username == null ? null : new String(String.valueOf(username));
        }

        public String getPassword() {
            return password == null ? null : new String(String.valueOf(password));
        }

        public String getBasic() {
            return basic == null ? null : new String(String.valueOf(basic));
        }
    }


    /**
     * Retrieves a CountryTenant entity based on the provided tenant name.
     *
     * @param tenant the tenant name to search for
     * @return the CountryTenant object if found, otherwise null
     */
    public CountryTenant findByTenannt(String tenant) {
        CountryTenant countryTenant = countryTenantRepository.findByTenant(tenant)
                .orElse(null);
        return countryTenant;
    }

    public Long createCountryTenant(Long countryId, String tenant, String username, String password,
            String basic) {
        CountryTenantPersistData sanitizedCountryTenant = this.sanitizeForPersistence(countryId, tenant, username, password, basic);
        CountryTenant countryTenantToSave = this.buildCountryTenantForSave(null, sanitizedCountryTenant);
        CountryTenant savedCountryTenant = countryTenantRepository.save(countryTenantToSave);
        if (Objects.isNull(savedCountryTenant) || Objects.isNull(savedCountryTenant.getId()) || savedCountryTenant.getId() <= 0) {
            throw new IllegalStateException("Unable to persist country tenant");
        }
        return Long.valueOf(String.valueOf(savedCountryTenant.getId()));
    }




    public Long updateCountryTenant(CountryTenant existingTenant,
            Long countryId,
            String tenant,
            String username,
            String password,
            String basic) {
        if (Objects.isNull(existingTenant) || Objects.isNull(existingTenant.getId()) || existingTenant.getId() <= 0) {
            throw new IllegalArgumentException("Existing country tenant is required");
        }

        CountryTenantPersistData sanitizedCountryTenant = this.sanitizeForPersistence(countryId, tenant, username, password, basic);
        Long validatedExistingTenantId = Long.valueOf(String.valueOf(existingTenant.getId()));

        CountryTenant countryTenantToSave = this.buildCountryTenantForSave(validatedExistingTenantId, sanitizedCountryTenant);

        CountryTenant savedCountryTenant = countryTenantRepository.save(countryTenantToSave);
        if (Objects.isNull(savedCountryTenant) || Objects.isNull(savedCountryTenant.getId()) || savedCountryTenant.getId() <= 0) {
            throw new IllegalStateException("Unable to persist country tenant");
        }
        return Long.valueOf(String.valueOf(savedCountryTenant.getId()));
    }





    private CountryTenantPersistData sanitizeForPersistence(Long countryId, String tenant, String username, String password,
            String basic) {
        Long validatedCountryId = Objects.isNull(countryId)
                ? null
                : Long.valueOf(String.valueOf(countryId));
        String validatedTenantInput = Objects.isNull(tenant)
                ? null
                : new String(String.valueOf(tenant));
        String validatedUsernameInput = Objects.isNull(username)
                ? null
                : new String(String.valueOf(username));
        String validatedPasswordInput = Objects.isNull(password)
                ? null
                : new String(String.valueOf(password));
        String validatedBasicInput = Objects.isNull(basic)
                ? null
                : new String(String.valueOf(basic));


        Country sanitizedCountry = this.sanitizeAndResolveCountryId(validatedCountryId);
        String validatedTenant = this.sanitizeRequiredText(validatedTenantInput);
        String validatedUsername = this.sanitizeRequiredText(validatedUsernameInput);
        String validatedPassword = this.sanitizeRequiredText(validatedPasswordInput);
        String validatedBasic = this.sanitizeRequiredText(validatedBasicInput);

        return new CountryTenantPersistData(
                Long.valueOf(String.valueOf(sanitizedCountry.getId())),
                new String(validatedTenant.trim()),
                new String(validatedUsername.trim()),
                new String(validatedPassword.trim()),
                new String(validatedBasic.trim()));
    }

    private CountryTenant buildCountryTenantForSave(Long tenantId, CountryTenantPersistData persistData) {
        if (Objects.isNull(persistData)
                || Objects.isNull(persistData.getCountryId())
                || persistData.getCountryId() <= 0) {
            throw new IllegalArgumentException("Invalid country tenant input");
        }

        CountryTenant countryTenantToSave = new CountryTenant();
        countryTenantToSave.setId(Objects.isNull(tenantId) ? null : Long.valueOf(String.valueOf(tenantId)));

        Country sanitizedCountry = new Country();
        sanitizedCountry.setId(Long.valueOf(String.valueOf(persistData.getCountryId())));
        countryTenantToSave.setCountry(sanitizedCountry);
        countryTenantToSave.setTenant(new String(this.copyRequiredText(persistData.getTenant()).trim()));
        countryTenantToSave.setUsername(new String(this.copyRequiredText(persistData.getUsername()).trim()));
        countryTenantToSave.setPassword(new String(this.copyRequiredText(persistData.getPassword()).trim()));
        countryTenantToSave.setBasic(new String(this.copyRequiredText(persistData.getBasic()).trim()));

        return countryTenantToSave;
    }



    private Country sanitizeAndResolveCountryId(Long incomingCountryId) {

        if (Objects.isNull(incomingCountryId) || incomingCountryId <= 0) {
            throw new IllegalArgumentException("Invalid country input");
        }

        Long validatedCountryId = Long.valueOf(incomingCountryId);
        try {
            Country validatedCountry = countryRepository.findById(validatedCountryId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid country input"));

            Country sanitizedCountry = new Country();
            sanitizedCountry.setId(Long.valueOf(validatedCountry.getId()));
            return sanitizedCountry;
        } catch (DataAccessException ex) {
            log.error("Failed to resolve country for countryId {}", validatedCountryId, ex);
            throw new IllegalStateException("Unable to resolve country input", ex);
        }

    }


    private String sanitizeRequiredText(String value) {
        if (Objects.isNull(value)) {
            throw new IllegalArgumentException("Required text input is missing");
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty() || validated.length() > 255 || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }

        return new String(validated);
    }

    private String copyRequiredText(String value) {
        if (Objects.isNull(value)) {
            throw new IllegalArgumentException("Required text input is missing");
        }

        return new String(String.valueOf(value));
    }

}
