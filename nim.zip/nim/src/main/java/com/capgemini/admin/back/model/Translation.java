package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.Data;

@Data
@MappedSuperclass
public class Translation {

    @Column(name = "locale")
    private String locale; // could be an enum here

    @Column(name = "type")
    private String translationType; // could be an enum (e.g : title, adress, etc.)

    @Column(name = "content")
    private String content;
}
