package com.capgemini.admin.back.model.procedure;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FrontLabelDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    private String fieldKey;
    private String keyId;
    private String languageText;
    private String languageCode;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long modifiedAt;
}
