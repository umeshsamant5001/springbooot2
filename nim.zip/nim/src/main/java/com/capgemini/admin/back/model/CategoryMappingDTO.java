package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class CategoryMappingDTO {
    private Long id;
    private Long spaceTypeId;
    private String category;

}
