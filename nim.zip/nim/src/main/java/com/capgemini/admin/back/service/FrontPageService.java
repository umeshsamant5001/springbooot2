package com.capgemini.admin.back.service;

import com.capgemini.admin.back.mapper.FrontPageMapper;
import com.capgemini.admin.back.model.FrontPage;
import com.capgemini.admin.back.model.FrontPageDTO;
import com.capgemini.admin.back.repository.FrontPageRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import java.util.function.Function;
import java.util.stream.Collectors;



@Service
public class FrontPageService {

    private static final Logger log = LoggerFactory.getLogger(FrontPageService.class);
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";


    @Autowired
    private FrontPageRepository frontPageRepository;


    public List<FrontPage> getAllByParentId(Long parentId) {
        return this.frontPageRepository.findAllByParentId(parentId);
    }

    public Function<List<FrontPage>, List<FrontPageDTO>> frontPageListToFrontPageDTOList() {
        return in -> in.stream().map(toFrontPageDTO()).collect(Collectors.toList());
    }

    public Function<FrontPage, FrontPageDTO> toFrontPageDTO() {
        return FrontPageMapper.INSTANCE::frontPageToFrontPageDTO;
    }

    public List<FrontPage> getAllByParentIdIsNull() {
        return this.frontPageRepository.findAllByParentIdIsNull();
    }

    public FrontPage save(FrontPage frontPage) {
        if (Objects.isNull(frontPage)) {
            return null;
        }

        FrontPage sanitized = new FrontPage();
        sanitized.setId(frontPage.getId() == null ? null : Long.valueOf(frontPage.getId()));
        sanitized.setTitle(sanitizeOptionalText(frontPage.getTitle(), 255));
        sanitized.setPath(sanitizeOptionalText(frontPage.getPath(), 255));
        sanitized.setIcon(sanitizeOptionalText(frontPage.getIcon(), 255));
        sanitized.setHtmlclass(sanitizeOptionalText(frontPage.getHtmlclass(), 255));
        sanitized.setIsExternalLink(frontPage.getIsExternalLink() == null
                ? null
                : Boolean.valueOf(frontPage.getIsExternalLink()));
        sanitized.setIndex(frontPage.getIndex() == null ? 50 : Integer.valueOf(frontPage.getIndex()));
        sanitized.setParentId(frontPage.getParentId() == null ? null : Long.valueOf(frontPage.getParentId()));
        sanitized.setIsheadermenu(frontPage.getIsheadermenu() == null ? null : Integer.valueOf(frontPage.getIsheadermenu()));
        sanitized.setAccess(frontPage.getAccess() == null ? new ArrayList<>() : new ArrayList<>(frontPage.getAccess()));

        return this.frontPageRepository.saveAndFlush(sanitized);
    }


    public FrontPage getFrontPage(Long frontPageId) {
        return this.frontPageRepository.findById(frontPageId).orElse(null);
    }

    public void deleteById(Long frontPageId) {
        this.frontPageRepository.deleteById(frontPageId);
    }

    public List<FrontPage> findAll() {
        return this.frontPageRepository.findAll();
    }

    public FrontPage getIdByTitles(String title) {
        try {
            return this.frontPageRepository.findIdByTitles(title);
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve front page by title.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve front page.");
        }
    }


    private String sanitizeOptionalText(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        String validated = new String(String.valueOf(value).trim());
        if (validated.isEmpty()) {
            return null;
        }
        if (validated.length() > maxLength || !validated.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(validated);
    }
}