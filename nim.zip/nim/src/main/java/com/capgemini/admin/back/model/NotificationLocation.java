package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "notification_location")
public class NotificationLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NotificationLocation_Generator")
    @SequenceGenerator(name = "NotificationLocation_Generator", sequenceName = "NotificationLocation_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notification_id")
    private Notification notification;

    @Column(name = "notification_id", updatable = false, insertable = false)
    private Long notificationId;

    @Column(name = "country_id")
    private Long countryId;

    @Enumerated(EnumType.STRING)
    @Column(name = "level")
    private LevelEnum level;

    @Column(name = "country_name")
    private String countryName;

    @Column(name = "cdm_key_id")
    private Long cdmKeyId;

    @Column(name = "status")
    private String status;
}
