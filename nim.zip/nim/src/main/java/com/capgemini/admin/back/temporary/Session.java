package com.capgemini.admin.back.temporary;

import lombok.Data;

/**
 * A simple POJO to represent a CDM session
 *
 */
@Data
public class Session {
	private String cookie;
	private String tokenId;
	private String code;
	private String token;

}
