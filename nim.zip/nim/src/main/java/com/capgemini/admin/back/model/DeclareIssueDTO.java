package com.capgemini.admin.back.model;
import lombok.Data;

@Data
public class DeclareIssueDTO {
    private Long id;
    private String issueName;
}