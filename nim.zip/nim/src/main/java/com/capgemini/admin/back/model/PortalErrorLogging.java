package com.capgemini.admin.back.model;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "admin_portal_error_logging")
public class PortalErrorLogging {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PortalErrorLogging_Generator")
	  @SequenceGenerator(name = "PortalErrorLogging_Generator", sequenceName = "PortalErrorLogging_Sequence")
    private Long id;
    @Column(name = "class_name")
    private String className;
    @Column(name = "module")
    private String module;
    @Column(name = "line_number")
    private Long lineNumber;
    @Column(name = "description")
    private String description;
    @Column(name = "state")
    private String state;
    @Column(name = "error_type")
    private String errorType;
    @Column(name = "data", columnDefinition = "TEXT")
    private String data;
    @Column(name = "created_date")
    private Long createdDate;
    @Column(name = "logging_date")
    private Long loggingDate;
    @Column(name = "error_logging_type")
    private String errorLoggingType;
    @Column(name = "user_email")
    private String userEmail;
    @Column(name = "http_method")
    private String httpMethod;
    @Column(name = "request_url")
    private String requestUrl;
    @Column(name = "request_payload")
    private String requestPayload;
    @Column(name = "response_status")
    private Long responseStatus;
    @Column(name = "response_body")
    private String responseBody;
    @Column(name = "stack_trace", columnDefinition = "TEXT")
    private String stackTrace;
    @Column(name = "browser_info", columnDefinition = "TEXT")
    private String browserInfo;
    @Column(name = "application_portal")
    private String applicationPortal;
}