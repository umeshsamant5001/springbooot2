package com.capgemini.admin.back.model.procedure;

public interface EntityDataDTO {
    Long getId();

    String getTitle();

    String getMessage();
}