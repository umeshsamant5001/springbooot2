package com.capgemini.admin.back.service;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import java.util.Objects;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingInformation;
import com.capgemini.admin.back.model.BuildingInformationDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.OpeningHours;


import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.utils.ExportCsv;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BuildingService {

	@Autowired
	private BuildingRepository buildingRepository;

	@Autowired
	private TreeService treeService;


	/**
	 * Retrieves a Building by its ID, including its associated floors.
	 *
	 * @param buildingId the ID of the building to retrieve
	 * @return the Building entity, or null if not found
	 */
	@Transactional
	public Building getBuilding(Long buildingId) {
		if (Objects.isNull(buildingId) || buildingId <= 0) {
			return null;
		}

		try {
			Long sanitizedBuildingId = Long.valueOf(buildingId);
			Building building = buildingRepository.findById(sanitizedBuildingId).orElse(null);
			if (Objects.nonNull(building)) {
				building.getFloors();
			}
			return building;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building by id {}.", buildingId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve building.");
		}
	}


	@Transactional
	public Building getAuthorizedBuilding(Long buildingId) {
		if (Objects.isNull(buildingId) || buildingId <= 0) {
			return null;
		}

		try {
			Long scopedBuildingId = Long.valueOf(buildingId);
			List<Long> authorizedBuildingIds = treeService.filterId(LevelEnum.BUILDING, List.of(scopedBuildingId));
			if (authorizedBuildingIds.isEmpty()) {
				return null;
			}

			Building building = buildingRepository.findById(authorizedBuildingIds.get(0)).orElse(null);
			if (Objects.nonNull(building)) {
				building.getFloors();
			}
			return building;
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve authorized building by id {}.", buildingId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve building.");
		}
	}



	



	
    /**
     * Updates an existing Building with new data and updates associated floor attributes if applicable.
     *
     * @param buildingId the ID of the building to update
     * @param building the new building data
     * @return the updated Building entity, or null if the building does not exist
     */
	public Building updateBuilding(Long buildingId, Building building) {
		if (Objects.isNull(buildingId) || buildingId <= 0 || Objects.isNull(building)) {
			return null;
		}

		try {
			Long scopedBuildingId = Long.valueOf(buildingId);
			List<Long> authorizedBuildingIds = treeService.filterId(LevelEnum.BUILDING, List.of(scopedBuildingId));
			if (authorizedBuildingIds.isEmpty()) {
				return null;
			}

			Building oldBuilding = buildingRepository.findById(authorizedBuildingIds.get(0)).orElse(null);
			Building newBuilding = null;
			if (Objects.isNull(oldBuilding)) {
				return null;
			}


			Map<String, String> sanitizedAttributes = null;
			if (Objects.nonNull(building.getAttributes())) {
				sanitizedAttributes = sanitizeAttributes(building.getAttributes());
				if (sanitizedAttributes.get(Constants.HIDDEN) != null) {
					String hiddenValue = new String(sanitizedAttributes.get(Constants.HIDDEN).trim());
					// Directly modify floors only when hidden is explicitly updated.
					oldBuilding
							.getFloors()
							.forEach(floor -> {
								floor.getAttributes().put(Constants.HIDDEN, hiddenValue);
							});
				}
			}
			oldBuilding.setCdmKeyId(building.getCdmKeyId() == null ? null : Long.valueOf(building.getCdmKeyId()));
			oldBuilding.setDeployed(building.getDeployed() == null ? null : Boolean.valueOf(building.getDeployed().booleanValue()));
			oldBuilding.setSecured(building.getSecured() == null ? null : Boolean.valueOf(building.getSecured().booleanValue()));

			if (Objects.nonNull(sanitizedAttributes)) {
				// Replace all attributes (CDM attrs are already re-merged by CdmAttributesMapper).
				// An empty map is valid — it clears all non-CDM attributes.
				oldBuilding.setAttributes(sanitizedAttributes);
			}
			oldBuilding.setInformation(sanitizeBuildingInformation(building.getInformation()));
			oldBuilding.setTitleEn(sanitizeOptionalText(building.getTitleEn(), 255));
			oldBuilding.setTitleFr(sanitizeOptionalText(building.getTitleFr(), 255));

			oldBuilding.setModifiedAt(new Date().getTime() / 1000);
			BuildingInformation newBuildingInformation = oldBuilding.getInformation();
			if (Objects.isNull(newBuildingInformation)) {
				newBuildingInformation = new BuildingInformation();
			}
			newBuildingInformation.setGlobal(false);
			oldBuilding.setInformation(newBuildingInformation);

			newBuilding = buildingRepository.saveAndFlush(oldBuilding);

			return newBuilding;
		} catch (DataAccessException ex) {
			log.error("Failed to update building by id {}.", buildingId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update building.");
		}

	}



    	
    /**
     * Retrieves a map of building names by their CDM key IDs.
     *
     * @param cdmKeyIdList list of CDM key IDs
     * @return a map of CDM key ID to building name
     */
	public Map<Long, String> getNameByCmdKeyId(List<Long> cdmKeyIdList) {
		try {
			return buildingRepository.getNameByCmdKeyId(cdmKeyIdList)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, Long.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building names by CDM key IDs.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve building names.");
		}
	}


	
    /**
     * Retrieves a map of attribute key-value pairs for a given building ID.
     *
     * @param buildingId the ID of the building
     * @return a map of attribute keys and values
     */
	public Map<String, String> getAttributesById(Long buildingId) {
		try {
			return buildingRepository.getAttributesById(buildingId)
					.stream()
					.collect(Collectors.toMap(
							(tuple) -> tuple.get(0, String.class),
							(tuple) -> tuple.get(1, String.class)));
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building attributes by id {}.", buildingId, ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve building attributes.");
		}
	}



	/**
     * Retrieves a map of attribute key-value pairs for a given building ID.
     *
     * @param buildingId the ID of the building
     * @return a map of attribute keys and values
     */
	public boolean buidingExists(Long buildingId) {
		return buildingRepository.existsById(buildingId);
	}

    /**
     * Retrieves all buildings from the repository.
     *
     * @return a list of all Building entities
     */
	public List<Building> getAll() {
		try {
			return buildingRepository.findAll();
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve all buildings.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve buildings.");
		}
	}



    /**
     * Saves and flushes a Building entity to the database.
     *
     * @param building the Building entity to save
     * @return the saved Building entity
     */
	public Building save(Building building) {
		if (Objects.isNull(building)) {
			return null;
		}

		building.setCdmKeyId(building.getCdmKeyId() == null ? null : Long.valueOf(building.getCdmKeyId()));
		building.setDeployed(building.getDeployed() == null ? null : Boolean.valueOf(building.getDeployed().booleanValue()));
		building.setSecured(building.getSecured() == null ? null : Boolean.valueOf(building.getSecured().booleanValue()));
		building.setAttributes(sanitizeAttributes(building.getAttributes()));
		building.setInformation(sanitizeBuildingInformation(building.getInformation()));
		building.setTitleEn(sanitizeOptionalText(building.getTitleEn(), 255));
		building.setTitleFr(sanitizeOptionalText(building.getTitleFr(), 255));
		building.setTimezoneWindows(sanitizeOptionalText(building.getTimezoneWindows(), 255));
		building.setTimezoneJava(sanitizeOptionalText(building.getTimezoneJava(), 255));

		return buildingRepository.saveAndFlush(building);
	}

	
    /**
     * Deletes a building by its ID.
     *
     * @param buildingId the ID of the building to delete
     */
	public void delete(Long buildingId) {
		if (Objects.isNull(buildingId) || buildingId <= 0) {
			return;
		}

		Long scopedBuildingId = Long.valueOf(buildingId);
		List<Long> authorizedBuildingIds = treeService.filterId(LevelEnum.BUILDING, List.of(scopedBuildingId));
		if (authorizedBuildingIds.isEmpty()) {
			return;
		}

		buildingRepository.deleteById(authorizedBuildingIds.get(0));
	}

	
    /**
     * Counts the number of buildings associated with a given site ID.
     *
     * @param siteId the ID of the site
     * @return the number of buildings for the site
     */
	public Long countBySiteId(Long siteId) {
		return buildingRepository.countBySiteId(siteId);
	}
	
    /**
    * Retrieves all building data formatted for export and applies formatting to specific fields.
    *
    * @return a list of rows representing building data for export
    */
	public List<List<String>> getExportAll() {
		List<List<String>> result = buildingRepository.getExportAll();
		for (List<String> row : result) {
			row.set(4, this.convertBooleanString(row.get(4)));
			row.set(5, this.convertBooleanString(row.get(5)));
			row.set(6, this.convertBooleanString(row.get(6)));
			row.set(7, this.convertHourString(row.get(7)));
			row.set(8, this.convertHourString(row.get(8)));
		}

		return result;
	}
	
    /**
     * Exports building data to a CSV file with headers and UTF-8 BOM for Excel compatibility.
     *
     * @param data the data to export
     * @return a ResponseEntity containing the CSV content
     */
	public ResponseEntity<String> export(List<List<String>> data) {
		List<String> headers = Arrays.asList(
				"Country",
				"City",
				"Site",
				"Building",
				"Roll-Out",
				"Secured",
				"Check-in Alert",
				"Building Opening Time",
				"Building Closing Time",
				"Booking in Advance Days",
				"Capacity");

		data.add(0, headers);

		ExportCsv exportCsv = new ExportCsv();
		// Add a BOM to the content to tell Excel that the file is in UTF-8
		String content = "\ufeff" + exportCsv.export(data);

		return ResponseEntity.ok()
				.header("Content-Disposition", "attachment; filename=Devices.csv")
				.contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
				.body(content);
	}
	
    /**
     * Converts a string representing a boolean value to "True" or "False".
     *
     * @param data the string to convert
     * @return "True" or "False" based on the input
     */
	private String convertBooleanString(String data) {
		if (Objects.isNull(data)) {
			return "False";
		}

		String lowerCaseData = data.trim().toLowerCase(Locale.ROOT);


		if ("0".equals(lowerCaseData) || "false".equals(lowerCaseData)) {
			return "False";
		} else if ("1".equals(lowerCaseData) || "true".equals(lowerCaseData)) {
			return "True";
		} else {
			// Handle unrecognized formats here, if needed
			return "False"; // Default to False if unrecognized
		}

	}

    /**
     * Converts a numeric string representing seconds into HH:mm format.
     *
     * @param data the string to convert
     * @return the formatted time string
     */
	private String convertHourString(String data) {
		if (Objects.isNull(data)) {
			return "";
		}

		int num = Integer.valueOf(data);

		return String.format("%02d:%02d", (num / 3600), (num % 3600 / 60));
	}
	
    /**
     * Updates the building information section of a building entity.
     *
     * @param building the building to update
     * @param buildingInformation the new building information to apply
     */
	public void updateBuildingInformation(Building building, BuildingInformationDTO buildingInformationDTO) {
		if (Objects.isNull(buildingInformationDTO)) {
			updateBuildingInformation(building, (BuildingInformation) null);
			return;
		}

		BuildingInformation sanitizedBuildingInformation = new BuildingInformation();
		sanitizedBuildingInformation.setLimitInDay(buildingInformationDTO.getLimitInDay() == null
				? null
				: Long.valueOf(buildingInformationDTO.getLimitInDay()));

		OpeningHours sanitizedOpeningHours = null;
		if (buildingInformationDTO.getOpeningHours() != null) {
			sanitizedOpeningHours = new OpeningHours();
			sanitizedOpeningHours.setFrom(buildingInformationDTO.getOpeningHours().getFrom() == null
					? null
					: Long.valueOf(buildingInformationDTO.getOpeningHours().getFrom()));
			sanitizedOpeningHours.setTo(buildingInformationDTO.getOpeningHours().getTo() == null
					? null
					: Long.valueOf(buildingInformationDTO.getOpeningHours().getTo()));
		}
		sanitizedBuildingInformation.setOpeningHours(sanitizedOpeningHours);

		sanitizedBuildingInformation.setAddress(buildingInformationDTO.getAddress() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getAddress())));
		sanitizedBuildingInformation.setCity(buildingInformationDTO.getCity() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getCity())));
		sanitizedBuildingInformation.setCountry(buildingInformationDTO.getCountry() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getCountry())));
		sanitizedBuildingInformation.setPhone(buildingInformationDTO.getPhone() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getPhone())));
		sanitizedBuildingInformation.setReceptionMail(buildingInformationDTO.getReceptionMail() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getReceptionMail())));
		sanitizedBuildingInformation.setInfoUrl(buildingInformationDTO.getInfoUrl() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getInfoUrl())));
		sanitizedBuildingInformation.setLdapName(buildingInformationDTO.getLdapName() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getLdapName())));
		sanitizedBuildingInformation.setCapacity(buildingInformationDTO.getCapacity() == null
				? null
				: new String(String.valueOf(buildingInformationDTO.getCapacity())));
		sanitizedBuildingInformation.setDeskLimitCrowded(buildingInformationDTO.getDeskLimitCrowded() == null
				? null
				: Long.valueOf(buildingInformationDTO.getDeskLimitCrowded()));
		sanitizedBuildingInformation.setMinimumDeskArea(buildingInformationDTO.getMinimumDeskArea() == null
				? null
				: Double.valueOf(buildingInformationDTO.getMinimumDeskArea()));
		sanitizedBuildingInformation.setMinTemp(buildingInformationDTO.getMinTemp() == null
				? null
				: Integer.valueOf(buildingInformationDTO.getMinTemp()));
		sanitizedBuildingInformation.setMaxTemp(buildingInformationDTO.getMaxTemp() == null
				? null
				: Integer.valueOf(buildingInformationDTO.getMaxTemp()));
		sanitizedBuildingInformation.setTempFormat(buildingInformationDTO.getTempFormat() == null
				? null
				: com.capgemini.admin.back.model.TemperatureUnit.valueOf(String.valueOf(buildingInformationDTO.getTempFormat())));
		sanitizedBuildingInformation.setTimeFormat(buildingInformationDTO.getTimeFormat() == null
				? null
				: com.capgemini.admin.back.model.TimeFormat.valueOf(String.valueOf(buildingInformationDTO.getTimeFormat())));
		sanitizedBuildingInformation.setGlobal(buildingInformationDTO.getGlobal() == null
				? null
				: Boolean.valueOf(buildingInformationDTO.getGlobal().booleanValue()));

		updateBuildingInformation(building, sanitizedBuildingInformation);
	}

	public void updateBuildingInformation(Building building, BuildingInformation buildingInformation) {
		if (Objects.isNull(building) || Objects.isNull(building.getId())) {
			return;
		}

		try {
			Building oldBuilding = buildingRepository.findById(Long.valueOf(building.getId())).orElse(null);

			if (oldBuilding != null) {
				BuildingInformation newBuildingInformation = oldBuilding.getInformation();
				if (newBuildingInformation == null) {
					newBuildingInformation = new BuildingInformation();
				}

				if (buildingInformation != null) {
					if (buildingInformation.getAddress() != null) {
						newBuildingInformation.setAddress(sanitizeOptionalText(buildingInformation.getAddress(), 255));
					}
					if (buildingInformation.getCity() != null) {
						newBuildingInformation.setCity(sanitizeOptionalText(buildingInformation.getCity(), 255));
					}
					if (buildingInformation.getCountry() != null) {
						newBuildingInformation.setCountry(sanitizeOptionalText(buildingInformation.getCountry(), 255));
					}
					if (buildingInformation.getPhone() != null) {
						newBuildingInformation.setPhone(sanitizeOptionalText(buildingInformation.getPhone(), 255));
					}
					if (buildingInformation.getReceptionMail() != null) {
						newBuildingInformation.setReceptionMail(sanitizeOptionalText(buildingInformation.getReceptionMail(), 255));
					}
					if (buildingInformation.getInfoUrl() != null) {
						newBuildingInformation.setInfoUrl(sanitizeOptionalText(buildingInformation.getInfoUrl(), 500));
					}
					if (buildingInformation.getLdapName() != null) {
						newBuildingInformation.setLdapName(sanitizeOptionalText(buildingInformation.getLdapName(), 255));
					}
					if (buildingInformation.getCapacity() != null) {
						newBuildingInformation.setCapacity(sanitizeOptionalText(buildingInformation.getCapacity(), 255));
					}

					if (buildingInformation.getLimitInDay() != null) {
						newBuildingInformation.setLimitInDay(Long.valueOf(buildingInformation.getLimitInDay()));
					}

					OpeningHours sanitizedOpeningHours = null;
					if (buildingInformation.getOpeningHours() != null) {
						sanitizedOpeningHours = new OpeningHours();
						sanitizedOpeningHours.setFrom(buildingInformation.getOpeningHours().getFrom() == null
								? null
								: Long.valueOf(buildingInformation.getOpeningHours().getFrom()));
						sanitizedOpeningHours.setTo(buildingInformation.getOpeningHours().getTo() == null
								? null
								: Long.valueOf(buildingInformation.getOpeningHours().getTo()));
					}
					if (buildingInformation.getOpeningHours() != null) {
						newBuildingInformation.setOpeningHours(sanitizedOpeningHours);
					}
					if (buildingInformation.getDeskLimitCrowded() != null) {
						newBuildingInformation.setDeskLimitCrowded(Long.valueOf(buildingInformation.getDeskLimitCrowded()));
					}
					if (buildingInformation.getMinimumDeskArea() != null) {
						newBuildingInformation.setMinimumDeskArea(Double.valueOf(buildingInformation.getMinimumDeskArea()));
					}
					newBuildingInformation.setGlobal(Boolean.TRUE);
					if (buildingInformation.getMaxTemp() != null) {
						newBuildingInformation.setMaxTemp(Integer.valueOf(buildingInformation.getMaxTemp()));
					}
					if (buildingInformation.getMinTemp() != null) {
						newBuildingInformation.setMinTemp(Integer.valueOf(buildingInformation.getMinTemp()));
					}
					if (buildingInformation.getTempFormat() != null) {
						newBuildingInformation.setTempFormat(buildingInformation.getTempFormat());
					}
					if (buildingInformation.getTimeFormat() != null) {
						newBuildingInformation.setTimeFormat(buildingInformation.getTimeFormat());
					}

				}

				oldBuilding.setInformation(newBuildingInformation);
				buildingRepository.saveAndFlush(oldBuilding);
			}
		} catch (DataAccessException ex) {
			log.error("Failed to update building information for id {}.", building.getId(), ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update building information.");
		}
	}


	
	private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
		Map<String, String> sanitized = new HashMap<>();
		if (Objects.isNull(attributes)) {
			return sanitized;
		}

		attributes.forEach((key, value) -> {
			if (Objects.nonNull(key) && Objects.nonNull(value)) {
				sanitized.put(new String(key.trim()), new String(value.trim()));
			}
		});
		return sanitized;
	}

	private BuildingInformation sanitizeBuildingInformation(BuildingInformation buildingInformation) {
		if (Objects.isNull(buildingInformation)) {
			return null;
		}

		BuildingInformation sanitized = new BuildingInformation();
		sanitized.setAddress(sanitizeOptionalText(buildingInformation.getAddress(), 255));
		sanitized.setCity(sanitizeOptionalText(buildingInformation.getCity(), 255));
		sanitized.setCountry(sanitizeOptionalText(buildingInformation.getCountry(), 255));
		sanitized.setPhone(sanitizeOptionalText(buildingInformation.getPhone(), 255));
		sanitized.setReceptionMail(sanitizeOptionalText(buildingInformation.getReceptionMail(), 255));
		sanitized.setInfoUrl(sanitizeOptionalText(buildingInformation.getInfoUrl(), 500));
		sanitized.setLdapName(sanitizeOptionalText(buildingInformation.getLdapName(), 255));
		sanitized.setCapacity(sanitizeOptionalText(buildingInformation.getCapacity(), 255));
		sanitized.setLimitInDay(buildingInformation.getLimitInDay() == null
				? null
				: Long.valueOf(buildingInformation.getLimitInDay()));
		sanitized.setDeskLimitCrowded(buildingInformation.getDeskLimitCrowded() == null
				? null
				: Long.valueOf(buildingInformation.getDeskLimitCrowded()));
		sanitized.setMinimumDeskArea(buildingInformation.getMinimumDeskArea() == null
				? null
				: Double.valueOf(buildingInformation.getMinimumDeskArea()));
		sanitized.setMinTemp(buildingInformation.getMinTemp() == null
				? null
				: Integer.valueOf(buildingInformation.getMinTemp()));
		sanitized.setMaxTemp(buildingInformation.getMaxTemp() == null
				? null
				: Integer.valueOf(buildingInformation.getMaxTemp()));
		sanitized.setTempFormat(buildingInformation.getTempFormat());
		sanitized.setTimeFormat(buildingInformation.getTimeFormat());
		sanitized.setGlobal(buildingInformation.getGlobal() == null
				? null
				: Boolean.valueOf(buildingInformation.getGlobal().booleanValue()));

		OpeningHours sanitizedOpeningHours = null;
		if (Objects.nonNull(buildingInformation.getOpeningHours())) {
			sanitizedOpeningHours = new OpeningHours();
			sanitizedOpeningHours.setFrom(buildingInformation.getOpeningHours().getFrom() == null
					? null
					: Long.valueOf(buildingInformation.getOpeningHours().getFrom()));
			sanitizedOpeningHours.setTo(buildingInformation.getOpeningHours().getTo() == null
					? null
					: Long.valueOf(buildingInformation.getOpeningHours().getTo()));
		}
		sanitized.setOpeningHours(sanitizedOpeningHours);

		return sanitized;
	}

	private String sanitizeOptionalText(String value, int maxLength) {
		if (value == null) {
			return null;
		}
		String trimmed = value.trim();
		if (trimmed.isEmpty()) {
			return null;
		}
		if (trimmed.length() > maxLength || !trimmed.matches("^[^\\r\\n\\t\\p{Cntrl}]*$")) {
			throw new IllegalArgumentException("Invalid text input");
		}
		return new String(trimmed);
	}

	/**
	 * Retrieves a list of building locations that have lockers.
	 *
	 * @return a list of building location names
	 */
	public List<String> getBuildingLocations() {
		try {
			return buildingRepository.findllBuildingsWithLockers();
		} catch (DataAccessException ex) {
			log.error("Failed to retrieve building locations with lockers.", ex);
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve building locations.");
		}
	}


}
