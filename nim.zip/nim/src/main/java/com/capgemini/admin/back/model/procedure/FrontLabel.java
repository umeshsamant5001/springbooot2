package com.capgemini.admin.back.model.procedure;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "mobile_multilang_field")
public class FrontLabel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Label_Generator")
    @SequenceGenerator(name = "Label_Generator", sequenceName = "Label_Sequence")
    private Long id;

    @Column(name = "key_id")
    private String keyId;

    @Column(name = "field_key")
    private String fieldKey;

    @Column(name = "language_text")
    private String languageText;

    @Column(name = "language_code")
    private String languageCode;

    @Column(name = "modified_at")
    private Long modifiedAt;

}
