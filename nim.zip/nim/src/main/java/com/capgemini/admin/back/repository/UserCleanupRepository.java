package com.capgemini.admin.back.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserCleanupRepository {

     private static final Logger log = LoggerFactory.getLogger(UserCleanupRepository.class);

     private final JdbcTemplate jdbcTemplate;

     public UserCleanupRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
     }
    
     @Transactional
     public int deleteFromVisitedBuildingsByEmail(String email) {          
          String sql = "DELETE FROM user_visited_buildings "+
                              "WHERE preference_id IN ( "+ 
                              "SELECT p.id FROM preference p WHERE p.user_email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from user_visited_buildings for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete visited buildings.", ex);
          }
          
     }

     @Transactional
     public int deleteFromPreferenceServiceByEmail(String email) {         
          String sql = "DELETE FROM preference_service " +
                               "WHERE preference_id IN ( " +
                         "SELECT p.id FROM preference p WHERE p.user_email = ?)";
           
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from preference_service for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete preference services.", ex);
          }
          
     }

     @Transactional
     public int deleteFromPreferenceLanguageByEmail(String email) {         
          String sql = "DELETE FROM preference_language " +
                               "WHERE preference_id IN ( " +
                         "SELECT p.id FROM preference p WHERE p.user_email = ?)";    

          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from preference_language for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete preference languages.", ex);
          }
     }

     @Transactional
     public int deleteFromPreferenceByEmail(String email) {

          
          String nullify = " UPDATE users "+
               "SET preference_id = NULL "+
               "WHERE preference_id IN ( "+
                    "SELECT id FROM preference WHERE user_email = ?)";

          String delete = "DELETE FROM preference WHERE user_email = ?";
          try {
               jdbcTemplate.update(nullify, email);
               return jdbcTemplate.update(delete, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from preference for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete preference data.", ex);
          }
     }

     @Transactional
     public int deleteFromUserRoleLocationByEmail(String email) {          
          String sql = "DELETE FROM user_role_location " +
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
        
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from user_role_location for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user role locations.", ex);
          }
        
     }

     @Transactional
     public int deleteFromServiceUserByEmail(String email) {
          String sql = "DELETE FROM service_user "+
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from service_user for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete service user data.", ex);
          }
         
     }

     @Transactional
     public int deleteFromUserProfileByEmail(String email) {
          String sql = "DELETE FROM user_profile " +
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from user_profile for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user profile data.", ex);
          }
         
     }

     @Transactional
     public int deleteFromUserBuildingMapping(String email) {
          String sql = "DELETE FROM user_building_mapping " +
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from user_building_mapping for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user building mappings.", ex);
          }
         
     }


     @Transactional
     public int deleteFromUserRoles(String email) {
          String sql = "DELETE FROM users_roles " +
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from users_roles for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user roles.", ex);
          }
         
     }


     @Transactional
     public int deleteFromUserSecuredBuilding(String email) {
          String sql = "DELETE FROM users_secured_building " +
                              "WHERE user_id IN (SELECT u.id FROM users u WHERE u.email = ?)";
         
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete from users_secured_building for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user secured buildings.", ex);
          }
         
     }


     @Transactional
     public int deleteFromUserByEmail(String email) {
          String sql = "DELETE FROM users WHERE email = ?";
     
          try {
               return jdbcTemplate.update(sql, email);
          } catch (DataAccessException ex) {
               log.error("Failed to delete user for provided email", ex);
               throw new DataRetrievalFailureException("Unable to delete user.", ex);
          }
        
     }

    
}