package com.capgemini.admin.back.mapper;

import com.capgemini.admin.back.model.NotificationEmail;
import com.capgemini.admin.back.model.NotificationEmailDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(config = DtoMapperConfig.class)
public interface NotificationEmailMapper {
    NotificationEmailMapper INSTANCE = Mappers.getMapper(NotificationEmailMapper.class);

    NotificationEmailDTO NotificationEmailToNotificationEmailDTO(NotificationEmail in);

    NotificationEmail NotificationEmailDTOToNotificationEmail(NotificationEmailDTO in);
}