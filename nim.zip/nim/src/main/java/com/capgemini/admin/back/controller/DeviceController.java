package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;


import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.admin.back.mapper.DeviceMapper;
import com.capgemini.admin.back.model.Device;
import com.capgemini.admin.back.model.DeviceDTO;
import com.capgemini.admin.back.model.DeviceMaintenanceDTO;
import com.capgemini.admin.back.model.DeviceSpaceTypeDTO;
import com.capgemini.admin.back.model.EnumDeviceStatus;
import com.capgemini.admin.back.model.EnumDeviceType;
import com.capgemini.admin.back.model.EnumOrderBy;
import com.capgemini.admin.back.model.Floor;
import com.capgemini.admin.back.model.InvalidParameterException;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.Poi;
import com.capgemini.admin.back.model.ResponseTabletImportDTO;
import com.capgemini.admin.back.model.SubLevelEnum;
import com.capgemini.admin.back.model.TabletImportDTO;
import com.capgemini.admin.back.service.DeviceService;
import com.capgemini.admin.back.service.FloorService;
import com.capgemini.admin.back.service.PoiService;
import com.capgemini.admin.back.service.TabletImportAuditService;
import com.capgemini.admin.back.service.TreeService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Validated
@RequestMapping(value = DeviceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
@Slf4j
public class DeviceController {


    public static final String ROOT_API = "api/device";
    @Autowired
    private DeviceService deviceService;
    @Autowired
    private PoiService poiService;
    @Autowired
    private FloorService floorService;
    @Autowired
    private TreeService treeService;
    @Autowired
    private TabletImportAuditService tabletImportAuditService;

    /**
     * Retrieves a list of DeviceDTOs associated with a given POI name.
     *
     * This endpoint filters devices based on their UUIDs and maps them to DTOs
     * using the specified language for localization.
     *
     * @param poiName  the name of the Point of Interest (POI) to search devices for
     * @param language the language code for localization (default is "en")
     * @return a ResponseEntity containing the filtered list of DeviceDTOs or a 404
     *         if no devices are found
     */
    @GetMapping("/poiName/{poiName}")
    public ResponseEntity<List<DeviceDTO>> getDevicesByPoiName(
            @PathVariable String poiName,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Device> devices = deviceService.findAllByPoiName(poiName);

        if (Objects.isNull(devices)) {
            return ResponseEntity.notFound().build();
        }

        List<String> uuidList = devices.stream()
                .map(device -> device.getUuid())
                .collect(Collectors.toList());

        List<String> filteredUuidList = treeService.filterId(SubLevelEnum.DEVICE, uuidList);

        List<DeviceDTO> devicesDTO = devices
                .stream()
                .filter(device -> filteredUuidList.contains(device.getUuid()))
                .map(device -> DeviceMapper.INSTANCE.deviceToDeviceDTO(device, language))
                .collect(Collectors.toList());

        return ResponseEntity.ok(devicesDTO);
    }

    /**
     * Get a device with is id (deviceId or mac adress) Use for by the 147 tablet
     * next to bookable room
     *
     * This endpoint checks authorization for the requested device ID and returns
     * the device details localized to the specified language.
     *
     * @param deviceId the UUID of the device to retrieve
     * @param language the language code for localization (default is "en")
     * @return a ResponseEntity containing the DeviceDTO if authorized and found,
     *         or appropriate HTTP status codes:
     *         - 401 Unauthorized if access is denied
     *         - 404 Not Found if the device does not exist
     */
    @GetMapping("/{deviceId}")
    public ResponseEntity<DeviceDTO> getDevice(
            @PathVariable String deviceId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        if (!treeService.isAuthorized(SubLevelEnum.DEVICE, deviceId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Device device = deviceService.findByUuid(deviceId);
        if (Objects.isNull(device)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(DeviceMapper.INSTANCE.deviceToDeviceDTO(device, language));
    }

    /**
     * Retrieves the count of devices for a given building, filtered by device types
     * and optionally by device status.
     *
     * This endpoint checks authorization for the specified building ID and returns
     * the number of matching devices.
     *
     * @param buildingId   the ID of the building to count devices for
     * @param deviceType   the list of device types to filter the count
     * @param deviceStatus (optional) the status of the devices to filter the count
     * @return a ResponseEntity containing the count of devices if authorized,
     *         or a 401 Unauthorized status if access is denied
     */
    @GetMapping("/count")
    public ResponseEntity<Long> getDeviceCount(
            @RequestParam Long buildingId,
            @RequestParam List<EnumDeviceType> deviceType,
            @RequestParam(required = false) EnumDeviceStatus deviceStatus) {

        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Long count = deviceService.countDevice(buildingId, deviceType, deviceStatus);

        return ResponseEntity.ok(count);
    }

    /**
     * Retrieves a list of devices.
     *
     * @param buildingId   The ID of the building
     * @param deviceType   The list of device types
     * @param deviceStatus The status of the device (optional)
     * @param orderBy      The order by which to sort the devices (optional)
     * @param column       The column to order by (optional)
     * @param first        The first parameter for pagination
     * @param last         The last parameter for pagination
     * @return A ResponseEntity containing the requested list of devices
     *         Possibly the worst code in all the project
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getDevices(
            @RequestParam Long buildingId,
            @RequestParam List<EnumDeviceType> deviceType,
            @RequestParam(required = false) EnumDeviceStatus deviceStatus,
            @RequestParam(required = false) EnumOrderBy orderBy,
            @RequestParam(required = false) String column,
            @RequestParam @Min(0) int first,
            @RequestParam @Min(0) int last,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {


        // Authorization check
        if (!treeService.isAuthorized(LevelEnum.BUILDING, buildingId)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        // Pagination setup
        boolean retrieveAll = (first == 0 && last == 9999);
        if (!retrieveAll && first >= last) {
            return ResponseEntity.badRequest().build();
        }

        int size;
        int pageNumber;
        if (retrieveAll) {
            size = deviceService.countDevice(buildingId, deviceType, deviceStatus).intValue();
            pageNumber = 0;
        } else {
            try {
                size = Math.subtractExact(last, first);
                pageNumber = Math.subtractExact(last / size, 1);
            } catch (ArithmeticException ex) {
                return ResponseEntity.badRequest().build();
            }
            if (size <= 0 || pageNumber < 0) {
                return ResponseEntity.badRequest().build();
            }
        }

        Pageable paging = PageRequest.of(pageNumber, size);


        // Device status list
        List<EnumDeviceStatus> deviceStatusList = (deviceStatus == null)
                ? Arrays.asList(EnumDeviceStatus.ACTIVE, EnumDeviceStatus.INACTIVE)
                : Collections.singletonList(deviceStatus);

        // Fetch devices
        String sortColumn = (column == null || orderBy == null) ? "withoutOrderBy" : column;
        Page<Device> pagedDevices = deviceService.getDevicesWithSpecificOrderBy(
                buildingId, deviceType, deviceStatusList, orderBy, sortColumn, paging);

        // Convert and enrich DTOs
        List<DeviceDTO> ldevices = deviceService.listDeviceToDeviceDTOList(language)
                .apply(pagedDevices.getContent());
        ldevices = deviceService.addTitlesToDTOs(ldevices);
        ldevices = deviceService.addPoiTypeToDTOs(ldevices, language);

        // Sorting logic
        if (column != null) {
            switch (column) {
                case "PoiTitle":
                    deviceService.sortByPoiTitle(ldevices, orderBy);
                    break;
                case "Ip":
                    deviceService.sortByDeviceIp(ldevices, orderBy);
                    break;
                case "PoiType":
                    deviceService.sortByPoiType(ldevices, orderBy);
                    break;
                case "SpaceType": // previously "CdmType"
                    deviceService.sortByCdmType(ldevices, orderBy);
                    break;
                default:
                    // No sorting applied
                    break;
            }
        }

        // Prepare response
        if (CollectionUtils.isEmpty(ldevices)) {
            return ResponseEntity.notFound().build();
        }

        //  Temperature conversion for US, preserving other attributes
        //  Prefer ISO-2 code if available; otherwise be null-safe + case-insensitive.
        for (DeviceDTO deviceDTO : ldevices) {
            String countryName = null;
            try {
                countryName = deviceDTO.getFloor()
                        .getBuilding()
                        .getInformation()
                        .getCountry();
            } catch (Exception ignored) {
                // fall through
            }

            boolean isUS = countryName != null && countryName.equalsIgnoreCase("United States");
            
            Map<String, String> attrs = deviceDTO.getAttributes();
            if (attrs == null || attrs.isEmpty()) {
                continue;
            }

            // Clone map to avoid mutating original
            Map<String, String> newMap = new LinkedHashMap<>(attrs);

            if (isUS) {
                // US → tempF only
                String tempCStr = newMap.get("tempC");
                if (tempCStr != null && !tempCStr.isBlank()) {
                    try {
                        double cVal = Double.parseDouble(tempCStr);
                        double fVal = cVal * 9.0 / 5.0 + 32.0;
        
                        newMap.put("tempF", String.valueOf(fVal));
                        newMap.remove("tempC"); // remove Celsius
                    } catch (NumberFormatException ignored) {
                        // keep original values if parsing fails
                    }
                }
            } else {
                //  Non‑US → tempC only
                if (newMap.containsKey("tempF")) {
                        // remove tempF (don’t set to null)
                    newMap.remove("tempF");   
                }
            }
        
            deviceDTO.setAttributes(newMap);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("ldevices", ldevices);
        response.put("currentPage", pagedDevices.getNumber());
        response.put("totalItems", pagedDevices.getTotalElements());
        response.put("totalPages", pagedDevices.getTotalPages());

        return ResponseEntity.ok(response);
    }

    /**
     * Retrieves a paginated list of orphan devices (devices not linked to any POI)
     * filtered by device types.
     *
     * This endpoint returns devices that do not have a POI name assigned, filtered
     * by the specified device types.
     * It supports pagination using `first` and `last` indices and localizes the
     * device data based on the provided language.
     *
     * @param deviceType the list of device types to filter orphan devices
     * @param first      the starting index for pagination
     * @param last       the ending index for pagination
     * @param language   the language code for localization (default is "en")
     * @return a ResponseEntity containing a paginated list of DeviceDTOs and
     *         metadata,
     *         or a 404 Not Found status if no orphan devices are found
     */
    @GetMapping("/orphans")
    public ResponseEntity<Map<String, Object>> getOrphansDevices(
            @RequestParam List<EnumDeviceType> deviceType,
            @RequestParam @Min(0) int first,
            @RequestParam @Min(0) int last,
            @RequestHeader(value = "Accept-Language", defaultValue = "en") String language) {

        if (first >= last) {
            return ResponseEntity.badRequest().build();
        }

        int size;
        int pageNumber;
        try {
            size = Math.subtractExact(last, first);
            pageNumber = Math.subtractExact(last / size, 1);
        } catch (ArithmeticException ex) {
            return ResponseEntity.badRequest().build();
        }
        if (size <= 0 || pageNumber < 0) {
            return ResponseEntity.badRequest().build();
        }

        Pageable pageable = PageRequest.of(pageNumber, size);


        Specification<Device> spec1 = (root, query, cb) -> cb.isNull(root.get("poiName"));
        Specification<Device> spec2 = (root, query, cb) -> root.get("deviceType").in(deviceType);
        Specification<Device> specs = Specification.where(spec1).and(spec2);

        Page<Device> pagedDevices = deviceService.findAll(specs, pageable);
        List<DeviceDTO> ldevices = deviceService.listDeviceToDeviceDTOList(language).apply(pagedDevices.getContent());

        if (ldevices.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Map<String, Object> response = new HashMap<>();
        response.put("ldevices", ldevices);
        response.put("currentPage", pagedDevices.getNumber());
        response.put("totalItems", pagedDevices.getTotalElements());
        response.put("totalPages", pagedDevices.getTotalPages());

        return ResponseEntity.ok(response);
    }

    /**
     * Deletes a device by its UUID.
     *
     * <p>
     * This endpoint locates the device using the provided ID and deletes it if
     * found.
     * If the device does not exist, it returns a 404 Not Found status. Logs an
     * error if the device is missing.
     * </p>
     *
     * @param deviceId the UUID of the device to delete
     * @return a ResponseEntity with:
     *         - 200 OK if the device was successfully deleted
     *         - 404 Not Found if the device does not exist
     */
    @DeleteMapping(value = "/{deviceId}")
    public ResponseEntity<Object> deleteDevice(@PathVariable String deviceId) {
        Device device = deviceService.findByUuid(deviceId);
        if (Objects.isNull(device)) {
            String sanitizedDeviceId = new String(
                    deviceId.replaceAll("[\r\n\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
            log.error("Device with id {} not found", sanitizedDeviceId);
            return ResponseEntity.notFound().build();
        }


        deviceService.delete(device);
        return ResponseEntity.ok().build();
    }

    /**
     * Updates the POI and related attributes of a device identified by its UUID.
     *
     * This endpoint validates the existence of the device, POI, and associated
     * floor before updating the device's
     * POI name, status, type, and floor. The updated device information is returned
     * in the specified language.
     *
     * @param deviceId the UUID of the device to update
     * @param device   the DeviceDTO containing updated POI name, status, and device
     *                 type
     * @param language the language code for localization (default is "en")
     * @return a ResponseEntity containing the updated DeviceDTO if successful,
     *         or appropriate HTTP status codes:
     *         - 404 Not Found if the device or POI does not exist
     *         - 500 Internal Server Error if the update fails
     * @throws InvalidParameterException if the associated floor is not found
     */
    @PutMapping(value = "/{deviceId}")
    public ResponseEntity<DeviceDTO> updateDevicePoi(
            @PathVariable String deviceId,
            @RequestBody DeviceDTO device,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language)
            throws InvalidParameterException {
        Device oldDevice = deviceService.findByUuid(deviceId);
        if (Objects.isNull(oldDevice)) {
            return ResponseEntity.notFound().build();
        }

        String poiName = device.getPoiName();
        Poi poi = poiService.findByName(poiName);
        if (Objects.isNull(poi)) {
            return ResponseEntity.notFound().build();
        }

        Long floorId = poi.getFloor().getId();
        Floor floor = floorService.getFloor(floorId);
        if (Objects.isNull(floor)) {
            log.error("Floor not found");
            throw new InvalidParameterException(String.format("The Floor (id: %s) don't exist.", floorId));
        }

        oldDevice.setPoiName(device.getPoiName());
        oldDevice.setStatus(device.getStatus());
        oldDevice.setDeviceType(device.getDeviceType());
        oldDevice.setFloor(floor);

        Device deviceSave = deviceService.save(oldDevice);

        if (Objects.isNull(deviceSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(DeviceMapper.INSTANCE.deviceToDeviceDTO(deviceSave, language));
        }
    }

    /**
     * Removes the POI association and floor reference from a device identified by
     * its UUID.
     *
     * This endpoint sets the POI name and floor of the specified device to null,
     * effectively disassociating it
     * from any location. The updated device information is returned in the
     * specified language.
     *
     * @param deviceId the UUID of the device to update
     * @param language the language code for localization (default is "en")
     * @return a ResponseEntity containing the updated DeviceDTO if successful,
     *         or appropriate HTTP status codes:
     *         - 404 Not Found if the device does not exist
     *         - 500 Internal Server Error if the update fails
     */
    @PutMapping(value = "/removePoi/{deviceId}")
    public ResponseEntity<DeviceDTO> removePoi(
            @PathVariable String deviceId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Device oldDevice = deviceService.findByUuid(deviceId);
        if (Objects.isNull(oldDevice)) {
            return ResponseEntity.notFound().build();
        }

        oldDevice.setPoiName(null);
        oldDevice.setFloor(null);

        Device deviceSave = deviceService.save(oldDevice);

        if (Objects.isNull(deviceSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.ok(DeviceMapper.INSTANCE.deviceToDeviceDTO(deviceSave, language));
        }
    }

    /**
     * Creates a new device with the provided details.
     *
     * This endpoint validates the input device data, ensures the associated floor
     * and POI exist,
     * and then persists the new device. The created device is returned in the
     * specified language.
     *
     * @param device   the DeviceDTO containing the details of the device to be
     *                 created
     * @param language the language code for localization (default is "en")
     * @return a ResponseEntity containing the created DeviceDTO if successful,
     *         or appropriate HTTP status codes:
     *         - 400 Bad Request if the input is invalid or required entities
     *         (floor/POI) are missing
     *         - 500 Internal Server Error if the device creation fails
     *         - 201 Created if the device is successfully created
     */
    @PostMapping
    public ResponseEntity<DeviceDTO> createDevice(
            @Valid @RequestBody DeviceDTO device,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Device newDevice = DeviceMapper.INSTANCE.deviceDTOToDevice(device);
        if (Objects.isNull(newDevice)) {
            return ResponseEntity.badRequest().build();
        }

        Floor floor = floorService.getFloor(device.getFloor().getId());
        if (Objects.isNull(floor)) {
            return ResponseEntity.badRequest().build();
        }
        newDevice.setFloor(floor);

        Poi poi = poiService.findByFloorIdAndName(floor.getId(), device.getPoiName());
        if (Objects.isNull(poi)) {
            return ResponseEntity.badRequest().build();
        }

        newDevice.setLastChange(new Date().getTime() / 1000);

        Device deviceSave = deviceService.save(newDevice);

        if (Objects.isNull(deviceSave)) {
            return ResponseEntity.internalServerError().build();
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(DeviceMapper.INSTANCE.deviceToDeviceDTO(deviceSave, language));
        }
    }

    /**
     * Imports tablet devices from a CSV file and associates them with POIs.
     *
     * This endpoint validates the structure and content of the uploaded CSV file,
     * checks for POI existence,
     * and creates or updates tablet devices accordingly. Errors encountered during
     * validation or processing
     * are returned in the response.
     *
     * @param language the language code for localization (default is "en")
     * @param file     the CSV file containing tablet import data
     * @return a ResponseEntity containing a ResponseTabletImportDTO with:
     *         - validation errors if the file format or content is incorrect (422
     *         Unprocessable Entity or 400 Bad Request)
     *         - 200 OK if the import is successful
     */
    // Hard upper-bound on the uploaded CSV size to prevent unbounded loop iterations
    // downstream (checkCSVFormat / generateResponseTabletImportDTO). With
    // MAX_TABLET_IMPORT_DATA_LINES = 10000 and TABLET_COLUMN_COUNT = 14 short values
    // per line, 5 MiB is far above any legitimate import file size.
    private static final long MAX_TABLET_IMPORT_FILE_SIZE_BYTES = 5L * 1024L * 1024L;

    @PostMapping("/import/tablets")
    public ResponseEntity<ResponseTabletImportDTO> importTablets(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "email") String email) {

        // Initialize the response object for the tablet import operation
        ResponseTabletImportDTO responseTabletImportDTO = new ResponseTabletImportDTO();

        // Validate the uploaded file range before any downstream processing to avoid
        // unbounded loop iterations driven by attacker-controlled file contents.
        if (Objects.isNull(file) || file.isEmpty()) {
            responseTabletImportDTO.addError("The file is empty.");
            return ResponseEntity.unprocessableEntity().body(responseTabletImportDTO);
        }
        if (file.getSize() > MAX_TABLET_IMPORT_FILE_SIZE_BYTES) {
            responseTabletImportDTO.addError(String.format(
                    "The file is too large. Maximum allowed size is %d bytes.",
                    MAX_TABLET_IMPORT_FILE_SIZE_BYTES));
            return ResponseEntity.unprocessableEntity().body(responseTabletImportDTO);
        }

        // Check the format of the CSV file and store any structural errors in the response
        responseTabletImportDTO.setErrorsInFile(deviceService.checkCSVFormat(file));

        // Check if there are errors while reading the CSV file and return a response in
        // case of error
        if (!CollectionUtils.isEmpty(responseTabletImportDTO.getErrorsInFile())) {
            return ResponseEntity.unprocessableEntity().body(responseTabletImportDTO);
        }

        responseTabletImportDTO = deviceService.generateResponseTabletImportDTO(file);
        if (!CollectionUtils.isEmpty(responseTabletImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responseTabletImportDTO);
        }

        Map<String, Poi> poiByName = new HashMap<>();
        String[] headersArray  = tabletImportAuditService.getHeaders(new TabletImportDTO());
        
        // Iterate through each TabletImportDTO in the response
        for (TabletImportDTO tabletImportDTO : responseTabletImportDTO.getTabletImportDTOs()) {
            // Find the Poi based on the POI name in the file
            Poi poi = null;
            String poiName = tabletImportDTO.getPoiName();
            if (poiByName.containsKey(poiName)) {
                poi = poiByName.get(poiName);
            } else {
                poi = this.poiService.findByName(tabletImportDTO.getPoiName());
                poiByName.put(poiName, poi);
            }

            if (Objects.isNull(poi)) {
                String message = String.format("No poi with this name (poiName: %S)", tabletImportDTO.getPoiName());
                responseTabletImportDTO.addError(message);
            }

            tabletImportAuditService.tabletImportAuditBeforeUpdate(tabletImportDTO,headersArray,email);
        }

        if (!CollectionUtils.isEmpty(responseTabletImportDTO.getErrorsInFile())) {
            return ResponseEntity.badRequest().body(responseTabletImportDTO);
        }

        // Process the import
        for (TabletImportDTO tabletImportDTO : responseTabletImportDTO.getTabletImportDTOs()) {
            String poiName = tabletImportDTO.getPoiName();
            Poi poi = poiByName.get(poiName);

            // Create or update the tablet based on the imported data and the associated Poi
            deviceService.createOrUpdateTablet(tabletImportDTO, poi);
        }

        return ResponseEntity.ok(responseTabletImportDTO);
    }

    /**
     * Exports all device data in CSV format.
     *
     * This endpoint is intended for SuperAdmin users and does not apply
     * location-based restrictions.
     * It retrieves all device records and returns them as a downloadable CSV
     * string.
     *
     * @return a ResponseEntity containing the CSV-formatted device data with:
     *         - Content-Type: text/csv
     *         - 200 OK if the export is successful
     */
    @GetMapping(value = "/export", produces = "text/csv")
    public ResponseEntity<String> exportDevices() {
        // No Location limition because only SuperAdmin should access it

        // Retrieving a list of device data associated.
        List<List<String>> data = deviceService.getExportDevices();
        return deviceService.exportDevice(data);
    }

    /**
     * Exports bulk email data of devices in CSV format.
     *
     * This endpoint retrieves email-related information for devices and returns it
     * as a downloadable CSV string. It is typically used for bulk operations or
     * reporting.
     *
     * @return a ResponseEntity containing the CSV-formatted email data with:
     *         - Content-Type: text/csv
     *         - 200 OK if the export is successful
     */
    @GetMapping(value = "/exportEmail", produces = "text/csv")
    public ResponseEntity<String> exportEmailBulk() {

        List<List<String>> data = deviceService.getExportEmail();
        return deviceService.exportEmail(data);
    }

    /**
     * Triggers a manual update of device statuses via the scheduler logic.
     *
     * This endpoint is intended for testing or administrative purposes. It invokes
     * the device status update
     * mechanism without returning any response body.
     *
     * @return void (no content returned)
     */
    @GetMapping(value = "/getSchedulerDeviceStatusTest")
    public void getSchedulerDeviceStatusTest() {
        deviceService.updateDeviceStatuses();
    }

    /**
     * Retrieves a list of devices grouped by space types for a given floor.
     *
     * This endpoint returns devices associated with the specified floor, optionally
     * filtered
     * by a list of space type IDs. The result is grouped into DeviceSpaceTypeDTOs.
     *
     * @param spaceTypeIds (optional) list of space type IDs to filter devices
     * @param floorId      the ID of the floor to retrieve devices from
     * @return a list of DeviceSpaceTypeDTOs representing devices grouped by space
     *         type
     */
    @GetMapping("/getDevicesBySpaceType")
    public List<DeviceSpaceTypeDTO> getDevicesBySpaceType(
            @RequestParam(required = false) List<Long> spaceTypeIds,
            @RequestParam Long floorId) {
        return deviceService.getDevicesBySpaceType(floorId, spaceTypeIds);
    }

    @GetMapping(value = "/getGaphAccessStatusTest")
    public void getAccessStatusTest() {
        deviceService.getGraphAccessStatus();
    }
    
    
    @PutMapping("/maintenance")
    public ResponseEntity<DeviceMaintenanceDTO> updateMaintenance(
            @RequestBody DeviceMaintenanceDTO dto,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en")
            String language
    ) {

        Device updatedDevice = deviceService.updateUnderMaintenance(dto.getUuid(), dto.getUnderMaintenance());
    
        if (Objects.isNull(updatedDevice)) {
                return ResponseEntity.notFound().build();
            }
    
        // Map entity → DeviceMaintenanceDTO using existing DeviceMapper
        DeviceMaintenanceDTO response = DeviceMapper.INSTANCE.deviceToDeviceMaintenanceDTO(updatedDevice);
    
        // Return JSON object
        return ResponseEntity.ok(response);
    }

}
