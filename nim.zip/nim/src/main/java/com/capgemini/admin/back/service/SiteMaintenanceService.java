package com.capgemini.admin.back.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;



import com.capgemini.admin.back.mapper.SiteMaintenanceMapper;
import com.capgemini.admin.back.model.Platform;
import com.capgemini.admin.back.model.SiteMaintenance;
import com.capgemini.admin.back.model.SiteMaintenanceDTO;
import com.capgemini.admin.back.repository.SiteMaintenanceRepository;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SiteMaintenanceService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @Autowired
    private SiteMaintenanceRepository siteMaintenanceRepository;


    /**
     * Creates a new SiteMaintenance record.
     * If the new record is marked as active, it deactivates other active records for the same platform.
     *
     * @param siteMaintenance The SiteMaintenance entity to create.
     * @return The saved SiteMaintenance entity.
     */
    public SiteMaintenance createSiteMaintenance(SiteMaintenance siteMaintenance) {
        SiteMaintenance sanitizedSiteMaintenance = sanitizeForPersistence(siteMaintenance);

        try {
            // If the new record is active, deactivate others for the same platform
            if (Boolean.TRUE.equals(sanitizedSiteMaintenance.getIsActive())) {
                siteMaintenanceRepository.deactivateActiveByPlatform(sanitizedSiteMaintenance.getPlatform());
            }

            return siteMaintenanceRepository.save(sanitizedSiteMaintenance);
        } catch (DataAccessException ex) {
            String sanitizedPlatformForLog = sanitizedSiteMaintenance.getPlatform() == null
                    ? "null"
                    : new String(String.valueOf(sanitizedSiteMaintenance.getPlatform())
                            .replaceAll("[\r\n\t]", "_")
                            .replaceAll("[^\\x20-\\x7E]", ""));
            log.error("Failed to create site maintenance for platform {}", sanitizedPlatformForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to create site maintenance.");
        }
    }



    /**
     * Updates an existing SiteMaintenance record by ID.
     * If the updated record is marked as active, it deactivates other records for the same platform.
     *
     * @param siteMaintenance The updated data.
     * @param id              The ID of the record to update.
     * @return The updated SiteMaintenance entity.
     */
    @Transactional
    public SiteMaintenance updateSiteMaintenance(SiteMaintenance siteMaintenance, Long id) {
        SiteMaintenance sanitizedForUpdate = sanitizeForPersistence(siteMaintenance);

        try {
            SiteMaintenance oldSiteMaintenance = this.siteMaintenanceRepository.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("SiteMaintenance not found with id: " + id));

            // Case 1: If setting current record as active, deactivate all others for the
            // same platform
            if (Boolean.TRUE.equals(sanitizedForUpdate.getIsActive())) {
                siteMaintenanceRepository.deactivateOtherRecords(sanitizedForUpdate.getPlatform(), id);
            }

            // Case 2 (or general): Update the current record with provided data
            oldSiteMaintenance.setCreatedBy(sanitizedForUpdate.getCreatedBy() == null
                    ? null
                    : new String(sanitizedForUpdate.getCreatedBy().trim()));
            oldSiteMaintenance.setCreatedDateTime((new Date()).getTime() / 1000);
            oldSiteMaintenance.setStartDateTime(sanitizedForUpdate.getStartDateTime() == null
                    ? null
                    : Long.valueOf(sanitizedForUpdate.getStartDateTime()));
            oldSiteMaintenance.setEndDateTime(sanitizedForUpdate.getEndDateTime() == null
                    ? null
                    : Long.valueOf(sanitizedForUpdate.getEndDateTime()));
            oldSiteMaintenance.setIsActive(sanitizedForUpdate.getIsActive() == null
                    ? null
                    : Boolean.valueOf(sanitizedForUpdate.getIsActive()));
            oldSiteMaintenance.setMessage(sanitizedForUpdate.getMessage() == null
                    ? null
                    : new String(sanitizedForUpdate.getMessage().trim()));
            oldSiteMaintenance.setPlatform(sanitizedForUpdate.getPlatform() == null
                    ? null
                    : sanitizedForUpdate.getPlatform());

            SiteMaintenance newSiteMaintenance = this.siteMaintenanceRepository.save(oldSiteMaintenance);

            return newSiteMaintenance;
        } catch (DataAccessException ex) {
            log.error("Failed to update site maintenance for id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update site maintenance.");
        }
    }



    /**
     * Retrieves all SiteMaintenance records and maps them to DTOs.
     *
     * @return List of SiteMaintenanceDTOs.
     */
    public List<SiteMaintenanceDTO> getAllSiteMaintenance() {

        // Get all records for all the platform
        List<SiteMaintenance> applications = siteMaintenanceRepository.findAll();

        return applications
                .stream()
                .map(SiteMaintenanceMapper.INSTANCE::siteMaintenanceToSiteMaintenanceDTO)
                .collect(Collectors.toList());
    }

    /**
     * Retrieves a SiteMaintenance record by its ID.
     *
     * @param id The ID of the record.
     * @return The SiteMaintenance entity.
     */
    public SiteMaintenance getByIdSiteMaintenance(Long id) {
        // Get records by id for all the platform
        return this.siteMaintenanceRepository
                .findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Record not found with id " + id));
    }

    private SiteMaintenance sanitizeForPersistence(SiteMaintenance siteMaintenance) {
        if (siteMaintenance == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "SiteMaintenance payload is required.");
        }

        SiteMaintenance sanitizedSiteMaintenance = new SiteMaintenance();
        sanitizedSiteMaintenance.setId(null);
        sanitizedSiteMaintenance.setCreatedBy(validateOptionalText(siteMaintenance.getCreatedBy(), 255));
        sanitizedSiteMaintenance.setStartDateTime(validateOptionalEpoch(siteMaintenance.getStartDateTime(), "startDateTime"));
        sanitizedSiteMaintenance.setEndDateTime(validateOptionalEpoch(siteMaintenance.getEndDateTime(), "endDateTime"));
        sanitizedSiteMaintenance.setIsActive(validateRequiredBoolean(siteMaintenance.getIsActive(), "isActive"));
        sanitizedSiteMaintenance.setMessage(validateOptionalText(siteMaintenance.getMessage(), 10000));
        sanitizedSiteMaintenance.setPlatform(validateRequiredPlatform(siteMaintenance.getPlatform()));
        sanitizedSiteMaintenance.setCreatedDateTime((new Date()).getTime() / 1000);


        return sanitizedSiteMaintenance;
    }

    private String validateOptionalText(String value, int maxLength) {
        if (value == null) {
            return null;
        }

        String trimmed = new String(String.valueOf(value).trim());
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid text input");
        }

        return new String(trimmed);
    }

    private Long validateOptionalEpoch(Long value, String fieldName) {
        if (value == null) {
            return null;
        }
        Long safeValue = Long.valueOf(value);
        if (safeValue.longValue() < 0L) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid " + fieldName + " value.");
        }
        return Long.valueOf(safeValue);
    }

    private Boolean validateRequiredBoolean(Boolean value, String fieldName) {
        if (value == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, fieldName + " is required.");
        }
        return Boolean.valueOf(value);
    }

    private Platform validateRequiredPlatform(Platform value) {
        if (value == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "platform is required.");
        }
        return Platform.valueOf(String.valueOf(value.name()));
    }
}
