package com.capgemini.admin.back.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;
import javax.persistence.Tuple;
import javax.transaction.Transactional;

import org.apache.commons.text.StringSubstitutor;
import org.hibernate.Hibernate;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;

import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.admin.back.config.ApplicationProperties;
import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.back.mapper.RoleMapper;
import com.capgemini.admin.back.mapper.UserMapper;
import com.capgemini.admin.back.model.Building;
import com.capgemini.admin.back.model.BuildingDTO;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.EmailDTO;
import com.capgemini.admin.back.model.EmployeeDetailDTO;
import com.capgemini.admin.back.model.FeatureAccessDTO;
import com.capgemini.admin.back.model.LevelEnum;
import com.capgemini.admin.back.model.LocationDTO;
import com.capgemini.admin.back.model.Preference;
import com.capgemini.admin.back.model.ResponseSecuredUserImportDTO;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.model.RoleLocationDTO;
import com.capgemini.admin.back.model.SecuredUserImportDTO;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.model.UserAlreadyExistsException;
import com.capgemini.admin.back.model.UserDTO;
import com.capgemini.admin.back.model.UserProfile;
import com.capgemini.admin.back.model.UserRoleLocation;
import com.capgemini.admin.back.model.UserRoleLocationDTO;
import com.capgemini.admin.back.model.EmailContentDTO;
import com.capgemini.admin.back.security.jwt.model.UserInformation;
import com.capgemini.admin.back.repository.BuildingRepository;

import com.capgemini.admin.back.repository.CountryRepository;
import com.capgemini.admin.back.repository.CityRepository;
import com.capgemini.admin.back.repository.SiteRepository;
import com.capgemini.admin.back.repository.RoleRepository;
import com.capgemini.admin.back.repository.UserRepository;
import com.capgemini.admin.back.repository.UserRoleLocationRepository;
import com.capgemini.admin.back.repository.CountryMappingRepository;
import  com.capgemini.admin.back.model.CountryMapping;
import com.capgemini.admin.back.service.smtp.SMTPSendMail;
import com.capgemini.admin.utils.ExportCsv;
import org.apache.commons.text.StringEscapeUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

    // Column indices based on the SELECT order
    private static final int IDX_EMAIL = 0;
    private static final int IDX_ROLE_NAME = 1;
    private static final int IDX_CDM_KEY_ID = 2;
    private static final int IDX_LEVEL = 3;
    private static final int IDX_ROLE_ID = 4;
    private static final int IDX_USER_ID = 5;
    private static final int IDX_COUNTRY_ID = 6;
    private static final int IDX_COUNTRY_NAME = 7;
    private static final int IDX_CITY_ID = 8;
    private static final int IDX_CITY_NAME = 9;
    private static final int IDX_SITE_ID = 10;
    private static final int IDX_SITE_NAME = 11;
    private static final int IDX_BUILDING_ID = 12;
    private static final int IDX_BUILDING_NAME = 13;

    private static final List<String> ORDER_AFTER_FIRST =
            Arrays.asList("CITY", "SITE", "BUILDING");

    private enum EmailMode { SINGLE, COMBINED }        

    @Autowired
    private SMTPSendMail emailService;

    @Autowired
    private BuildingRepository buildingRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserRoleLocationRepository userRoleLocationRepository;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private PreferenceService preferenceService;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private UserInformationService userInformationService;

    @Autowired
    private CountryRepository countryRepository;

    
    @Autowired 
    private CityRepository cityRepository;

    @Autowired 
    private SiteRepository siteRepository;

    @Autowired
    private CountryMappingRepository countryMappingRepository;

    @Autowired
    private LDAPData ldapData;


    /**
     * Retrieves a user by their ID.
     *
     * @param id The ID of the user.
     * @return The User entity.
     * @throws ResourceNotFoundException if the user is not found.
     */
    public User getUserById(Long id) {
        if (id == null || id <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User id is required.");
        }
        try {
            return this.userRepository
                    .findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        } catch (IllegalArgumentException ex) {
            log.error("Invalid user id provided: {}", id, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user id.");
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve user by id {}", id, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve user.");
        }
    }


    /**
     * Retrieves a user by ID, even if the user is marked as deleted.
     *
     * @param id The ID of the user.
     * @return The User entity, including deleted users.
     */
    public User getUserEveifDeleted(Long id) {
        try {
            return this.userRepository
                    .findByIdEvenIfIsDeleted(id);
        } catch (IllegalArgumentException ex) {
            String safeIdForLog = sanitizeForLog(String.valueOf(id));
            log.error("Invalid user id provided for getUserEveifDeleted: {}", safeIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user id.");
        } catch (DataAccessException ex) {
            String safeIdForLog = sanitizeForLog(String.valueOf(id));
            log.error("Failed to retrieve user (including deleted) by id {}", safeIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve user.");
        }
    }


    /**
     * Retrieves a user by email, including deleted users.
     *
     * @param email The email address of the user.
     * @return The User entity, or null if not found.
     */
    public User getUserByEmail(String email) {
        try {
            return userRepository.findByEmailEvenIfDeleted(email); // findByEmail
        } catch (IllegalArgumentException ex) {
            String safeEmailForLog = sanitizeForLog(email);
            log.error("Invalid user email provided for getUserByEmail: {}", safeEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user email.");
        } catch (DataAccessException ex) {
            String safeEmailForLog = sanitizeForLog(email);
            log.error("Failed to retrieve user (including deleted) by email {}", safeEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve user.");
        }
    }


    /**
     * Updates the list of secured buildings assigned to a user.
     *
     * @param userId                  The ID of the user.
     * @param userSecuredBuildingDTOs The list of buildings to assign.
     * @return The updated User entity.
     * @throws ResourceNotFoundException if the user or any building is not found.
     */
    public User updateUserSecuredBuilding(Long userId, List<Long> userSecuredBuildingIds) {
        User existingUser = this.getUserById(userId);


        List<Building> userSecuredBuildings = new ArrayList<>();
        if (userSecuredBuildingIds != null) {
            for (Long buildingIdInput : userSecuredBuildingIds) {
                Long buildingId = buildingIdInput == null ? null : Long.valueOf(buildingIdInput);
                if (buildingId == null || buildingId <= 0) {
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Building id is required.");
                }
                Building building = this.buildingRepository
                        .findById(buildingId)
                        .orElseThrow(() -> new ResourceNotFoundException("Building not found with id " + buildingId));
                userSecuredBuildings.add(building);
            }
        }

        existingUser.setUserSecuredBuildings(userSecuredBuildings);
        return this.userRepository.save(existingUser);
    }

    private User restoreDeletedUser(User deletedUser, UserDTO userDTO, Long roleId) {
        User restoredUser = new User();
        restoredUser.setId(deletedUser.getId());
        restoredUser.setEmail(sanitizeRequiredText(userDTO.getEmail(), "Email is required."));
        restoredUser.setFirstName(sanitizeOptionalText(userDTO.getFirstName()));
        restoredUser.setLastName(sanitizeOptionalText(userDTO.getLastName()));
        restoredUser.setSubscribeAlert(userDTO.getSubscribeAlert() == null
                ? null
                : Boolean.valueOf(userDTO.getSubscribeAlert().booleanValue()));
        restoredUser.setDeleted(false); // Restore the user
        restoredUser.setEnabled(true);
        restoredUser.setTokenExpired(false);
        restoredUser.setUserType(Constants.ADMIN); // Set user type to ADMIN

        String incomingCountry = sanitizeOptionalText(userDTO.getCountry());
        // When an existing user (often created via user portal with userType=1) is created via admin
        if (incomingCountry == null || incomingCountry.isEmpty()) {
            String country = getCountryFromLDAP(userDTO.getEmail());
            restoredUser.setCountry(country == null ? null : new String(country.trim()));
        } else {
            restoredUser.setCountry(new String(incomingCountry));
        }

        // Set or update preference
        setDefaultPreference(restoredUser);

        // Update role-location mappings
        updateUserRoleLocation(userDTO, restoredUser, roleId);

        // Save the restored user first
        User userSave = userRepository.save(restoredUser);
        userProfileService.saveUserProfile(userSave.getId(), roleId);
        String safeRestoredEmail = sanitizeForLog(userDTO.getEmail());
        log.info("User restored and updated successfully for email: {}", safeRestoredEmail);
        return userSave;
    }


    private User createNewUser(UserDTO userDTO, Long roleId) {
        User newUser = new User();
        newUser.setEmail(sanitizeRequiredText(userDTO.getEmail(), "Email is required."));
        newUser.setFirstName(sanitizeOptionalText(userDTO.getFirstName()));
        newUser.setLastName(sanitizeOptionalText(userDTO.getLastName()));
        newUser.setSubscribeAlert(userDTO.getSubscribeAlert() == null
                ? null
                : Boolean.valueOf(userDTO.getSubscribeAlert().booleanValue()));

        // Fetch country from LDAP and map it to corresponding Graph API country value before saving
        String country = getMappedCountryFromLDAP(userDTO.getEmail());
        newUser.setCountry(country == null ? null : new String(country.trim()));

        newUser.setDeleted(false);
        newUser.setEnabled(true);
        newUser.setTokenExpired(false);
        newUser.setUserType(Constants.ADMIN);
        setDefaultPreference(newUser);
        User savedUser = userRepository.save(newUser);
        updateUserRoleLocation(userDTO, savedUser, roleId);
        userProfileService.saveUserProfile(savedUser.getId(), roleId);
        return savedUser;
    }


    private String sanitizeRequiredText(String value, String requiredMessage) {
        if (value == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, requiredMessage);
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, requiredMessage);
        }
        return new String(trimmed);
    }

    private String sanitizeOptionalText(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        return new String(trimmed);
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }


    /**
     * Sets the default preference for a user if none exists.
     *
     * @param user The user entity to update.
     */
    private void setDefaultPreference(User user) {

        Preference preference = preferenceService.getUserPreference(user.getEmail());
        if (preference == null) {
            preference = new Preference();
            preference.setUserEmail(user.getEmail());
        }
        preference.setUser(user);
        user.setPreference(preference);
    }

    /**
     * Updates an existing user's basic information and role-location mappings.
     * If a new role is assigned, sends a modification email.
     *
     * @param userId      The ID of the user to update.
     * @param updatedUser The updated user data.
     * @return The updated User entity.
     * @throws ResourceNotFoundException if the user is not found.
     * @throws ResponseStatusException   if role update fails.
     */
    @Transactional
    public User updateUser(Long userId, UserDTO updatedUser) throws ResourceNotFoundException, ResponseStatusException {

        UserDTO sanitizedUpdatedUser = sanitizeUserForUpdate(updatedUser);
        validateRoleLocations(sanitizedUpdatedUser);

        User user = this.userRepository

                .findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + userId));
        user.setEmail(sanitizeRequiredText(sanitizedUpdatedUser.getEmail(), "Email is required."));
        user.setFirstName(sanitizeOptionalText(sanitizedUpdatedUser.getFirstName()));
        user.setLastName(sanitizeOptionalText(sanitizedUpdatedUser.getLastName()));
        if (Objects.nonNull(sanitizedUpdatedUser.getSubscribeAlert())) {
            user.setSubscribeAlert(Boolean.valueOf(String.valueOf(sanitizedUpdatedUser.getSubscribeAlert())));
        }

        User userSave = this.userRepository.save(user);

        List<Long> savedRoleId = this.userRoleLocationRepository.findByUserId(userSave.getId())
                .stream()
                .map(roleLocation -> roleLocation.getRole().getId())
                .collect(Collectors.toList());
        String safeUserIdForLog = sanitizeForLog(String.valueOf(userSave.getId()));
        String safeSavedRoleIds = sanitizeForLog(String.valueOf(savedRoleId));
        log.info("updateUser: existing roles from DB: userId={}, savedRoleIds={}", safeUserIdForLog, safeSavedRoleIds);

        String newRoleName = sanitizedUpdatedUser.getRoleLocations()
                .stream()
                .map(roleLocation -> roleLocation.getRole())
                .filter(role -> !savedRoleId.contains(role.getId()))
                .map(role -> role.getName())
                .findFirst()
                .orElse(null);
        String safeNewRoleName = sanitizeForLog(newRoleName);
        log.info("updateUser: userId={}, newRoleName={}", safeUserIdForLog, safeNewRoleName);


        List<RoleEmailInfo> emailsToSend = planExistingRoleLocationEmails(userSave.getId(), sanitizedUpdatedUser, savedRoleId);
        log.info("Planned emails for changed existing roles: count={}", emailsToSend.size());

        this.userRoleLocationRepository.deleteAllByUserId(userSave.getId());

        try {
            this.updateUserRoleLocation(sanitizedUpdatedUser, userSave);
            updateUserProfile(sanitizedUpdatedUser, userSave);
        } catch (Exception e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Role Not Found", e);
        }
        if (Objects.nonNull(newRoleName)) {
            // To get role and roleLocation details for speicfic role
            // Object[] emailContentArray = sendEmailContentDetails(user, newRoleName);
            // sendEmailContentCreation(user, newRoleName, emailContentArray);
            Map<String, List<String>> emailContentMap = getEmailContentDetailsMap(user, newRoleName);
            // action = "UPDATEUSER";
            sendEmailContentForActions(userSave, newRoleName, emailContentMap,Constants.UPDATEUSER);
        }
        
        if (!emailsToSend.isEmpty()) {
                log.info("updateUser: sending LOCATION-UPDATE emails for existing roles");
                sendLocationUpdateEmailsForExistingRoles(userSave, emailsToSend);
            }

        // Feature need removed below only return vlue
        return this.userRepository.save(userSave);
    }

    /**
     * Soft-deletes a user by marking them as deleted and performing related cleanup
     * operations.
     * This method performs the following actions:
     * Checks if the user is null and exits early if so.
     * Marks the user as deleted by setting the 'deleted' flag to true.
     * Saves the updated user entity to the database.
     * Removes all associated admin role-location mappings for the user.
     * Deletes all service-user relationships linked to the user.
     * Sends a notification email about the deletion.
     * This operation is transactional to ensure all changes are committed
     * atomically.
     *
     * @param user the user entity to be soft-deleted
     */
    @Transactional
    public void deleteUser(Long id) {
        User user = getUserById(id);
        if (Objects.isNull(user)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with this id." + id);
        }
        user.setDeleted(true);
        user.setEnabled(false);
        user.setUserType(Constants.USER);
        user.setSubscribeAlert(null);
        userRepository.save(user);
        sendEmailDeletion(user);
    }

    /**
     * Retrieves all users along with their roles.
     *
     * @return List of users with roles.
     */
    public List<User> getAllUserWithRole() {
        try {
            return this.userRepository.findAllWithRole();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve users with roles.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve users.");
        }
    }

    /**
     * Retrieves users who have a web user profile.
     *
     * @return List of users with web profiles.
     */
    public List<User> getUsersWithWebUserProfile() {
        try {
            return this.userRepository.findUsersWithWebUserProfile();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve users with web user profiles.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve users.");
        }
    }

    /**
     * Retrieves users who either do not have a web profile or have an admin role.
     *
     * @return List of matching users.
     */
    public List<User> getUsersWithoutWebUserProfileOrWithAdminRole() {
        try {
            return this.userRepository.findUsersWithoutWebUserProfileOrWithAdminRole();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve users without web user profile or with admin role.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve users.");
        }
    }


    /**
     * Converts a User entity to a UserDTO and populates role-location mappings.
     *
     * @param user     The User entity.
     * @param language The language for localization.
     * @return A populated UserDTO with role-location data.
     */
    @Transactional
    public UserDTO toUserDTOWithRoleLocations(User user, String language) {
        if (user == null)
            return null;
        Preference preference = null;
        UserDTO userDTO = UserMapper.INSTANCE.userToUserDTO(user);
        try {
            preference = preferenceService.getUserPreference(user.getEmail());
        } catch (Exception e) {
            log.info("Exception >>> " + e);
        }

        List<UserRoleLocation> userRoleLocations = userRoleLocationRepository.findByUserId(user.getId());
        List<RoleLocationDTO> roleLocationList = new ArrayList<>();

        for (UserRoleLocation url : userRoleLocations) {
            Long roleId = url.getRole().getId();
            RoleLocationDTO roleLocationDTO = findRoleLocationById(roleLocationList, roleId);
            if (roleLocationDTO == null) {
                roleLocationDTO = createRoleLocationDTO(url, language, preference);
                roleLocationList.add(roleLocationDTO);
            }

            roleLocationDTO.getLocations().add(createLocationDTO(url));
        }

        userDTO.setRoleLocations(roleLocationList);
        return userDTO;
    }

    /**
     * Creates a RoleLocationDTO from a UserRoleLocation entity.
     * Initializes role and its feature accesses, and filters features based on user
     * preferences.
     *
     * @param url        The UserRoleLocation entity.
     * @param language   The language for localization.
     * @param preference The user's preference for filtering features.
     * @return A populated RoleLocationDTO.
     */
    private RoleLocationDTO createRoleLocationDTO(UserRoleLocation url, String language, Preference preference) {
        Hibernate.initialize(url.getRole());
        Hibernate.initialize(url.getRole().getFeatureAccesses());

        RoleLocationDTO dto = new RoleLocationDTO();
        dto.setRole(RoleMapper.INSTANCE.roleToRoleDTO(url.getRole(), language));
        dto.setLocations(new ArrayList<>());

        if (dto.getRole() != null && dto.getRole().getFeatureAccesses() != null) {
            List<FeatureAccessDTO> featuresToRemove = getFilteredFeatures(dto.getRole().getFeatureAccesses(),
                    preference);
            dto.getRole().getFeatureAccesses().removeAll(featuresToRemove);
        }

        return dto;
    }

    /**
     * Filters out feature accesses based on the user's selected language
     * preference.
     *
     * @param features   The list of feature accesses.
     * @param preference The user's language preference.
     * @return A list of features to remove.
     */
    private List<FeatureAccessDTO> getFilteredFeatures(List<FeatureAccessDTO> features, Preference preference) {
        List<FeatureAccessDTO> toRemove = new ArrayList<>();

        if (preference == null || preference.getSelectedLanguages().isEmpty()) {
            for (FeatureAccessDTO feature : features) {
                if (isRemovableFeature(feature, "French")) {
                    toRemove.add(feature);
                }
            }
        } else if (preference.getSelectedLanguages().size() == 1) {
            String selectedLang = preference.getSelectedLanguages().get(0).getName();
            String oppositeLang = "English".equals(selectedLang) ? "French" : "English";

            for (FeatureAccessDTO feature : features) {
                if (isRemovableFeature(feature, oppositeLang)) {
                    toRemove.add(feature);
                }
            }
        }

        return toRemove;
    }

    /**
     * Determines if a feature should be removed based on its front page title.
     *
     * @param feature       The feature access DTO.
     * @param titleToRemove The title to match for removal.
     * @return true if the feature should be removed, false otherwise.
     */
    private boolean isRemovableFeature(FeatureAccessDTO feature, String titleToRemove) {
        return feature.getFrontPage() != null &&
                feature.getFrontPage().getParentId() != null &&
                titleToRemove.equals(feature.getFrontPage().getTitle());
    }

    /**
     * Creates a LocationDTO from a UserRoleLocation entity.
     *
     * @param url The UserRoleLocation entity.
     * @return A populated LocationDTO.
     */
    private LocationDTO createLocationDTO(UserRoleLocation url) {
        Hibernate.initialize(url.getUser());
        LocationDTO locationDTO = new LocationDTO();
        locationDTO.setId(url.getId());
        locationDTO.setLevel(url.getLevel());
        locationDTO.setCdmKeyId(url.getCdmKeyId());
        locationDTO.setAlertStatus(url.getAlertStatus());
        return locationDTO;
    }

    /**
     * Finds a RoleLocationDTO in a list by role ID.
     *
     * @param roleLocationList The list of RoleLocationDTOs.
     * @param roleId           The role ID to search for.
     * @return The matching RoleLocationDTO, or null if not found.
     */
    private RoleLocationDTO findRoleLocationById(List<RoleLocationDTO> roleLocationList, Long roleId) {
        for (RoleLocationDTO roleLocationDTO : roleLocationList) {
            if (roleLocationDTO.getRole().getId().equals(roleId)) {
                return roleLocationDTO;
            }
        }
        return null;
    }

    /**
     * Updates the user's role-location mappings based on the provided UserDTO.
     *
     * @param userDTO The user data containing role-location mappings.
     * @param user    The user entity to update.
     */
    private void updateUserRoleLocation(UserDTO userDTO, User user) {
        if (Objects.nonNull(userDTO.getRoleLocations())) {
            userDTO.getRoleLocations()
                    .forEach(roleLocationDTO -> {
                        Long roleId = roleLocationDTO.getRole().getId();
                        Role role;
                        try {
                            role = this.roleRepository
                                    .findById(roleId)
                                    .orElseThrow(() -> new ResourceNotFoundException(
                                            "Role not found with id " + roleId));
                        } catch (IllegalArgumentException ex) {
                            String safeRoleIdForLog = sanitizeForLog(String.valueOf(roleId));
                            log.error("Invalid role id provided for updateUserRoleLocation: {}", safeRoleIdForLog, ex);
                            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid role id.");
                        } catch (DataAccessException ex) {
                            String safeRoleIdForLog = sanitizeForLog(String.valueOf(roleId));
                            log.error("Failed to retrieve role for updateUserRoleLocation with id {}", safeRoleIdForLog,
                                    ex);
                            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                                    "Unable to process role assignment.");
                        }
                        roleLocationDTO.getLocations()
                                .forEach(location -> {
                                    UserRoleLocation userRoleLocation = new UserRoleLocation();
                                    userRoleLocation.setRole(role);
                                    userRoleLocation.setUser(user);
                                    userRoleLocation.setLevel(location.getLevel() == null
                                            ? null
                                            : LevelEnum.valueOf(String.valueOf(location.getLevel().name())));
                                    userRoleLocation.setCdmKeyId(location.getCdmKeyId() == null
                                            ? null
                                            : Long.valueOf(location.getCdmKeyId()));
                                    userRoleLocation.setAlertStatus(userDTO.getSubscribeAlert() == null
                                            ? null
                                            : Boolean.valueOf(String.valueOf(userDTO.getSubscribeAlert())));
                                    log.info("updateUser");
                                    setAlertStatusIfFacilityManager(user, userRoleLocation);
                                    this.userRoleLocationRepository.save(userRoleLocation);
                                });
                    });
        }
    }



    /**
     * Converts a User entity to a UserDTO with roles but without location mappings.
     *
     * @param user              The user entity.
     * @param userRoleLocations The list of UserRoleLocation entities.
     * @param language          The language for localization.
     * @return A UserDTO with role information only.
     */
    public UserDTO toUserDTOWithRoleWithoutRoleLocations(User user, List<UserRoleLocation> userRoleLocations,
            String language) {

        UserDTO userDTO = UserMapper.INSTANCE.userToUserDTO(user);

        List<RoleLocationDTO> roleLocationList = new ArrayList<RoleLocationDTO>();
        userRoleLocations
                .stream()
                .filter(userRoleLocation -> user.getId().equals(userRoleLocation.getUserId()))
                .forEach(userRoleLocation -> {
                    Long roleId = userRoleLocation.getRole().getId();
                    RoleLocationDTO roleLocationDTO = findRoleLocationById(roleLocationList, roleId);

                    if (Objects.isNull(roleLocationDTO)) {
                        roleLocationDTO = new RoleLocationDTO();
                        roleLocationDTO
                                .setRole(RoleMapper.INSTANCE.roleToRoleDTO(userRoleLocation.getRole(), language));
                        roleLocationList.add(roleLocationDTO);
                    }
                });

        userDTO.setRoleLocations(roleLocationList);
        return userDTO;
    }

    /**
     * Sends a user creation email with role information.
     *
     * @param user     The user entity.
     * @param roleName The name of the assigned role.
     */
    public void sendEmailCreation(User user, String roleName) {
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);

        String subject = StringSubstitutor.replace(this.applicationProperties.getEmail().getCreateUser().getSubject(),
                params, "${", "}");
        String body = StringSubstitutor.replace(this.applicationProperties.getEmail().getCreateUser().getBody(), params,
                "${", "}");

        this.sendEmail(
                subject,
                body,
                List.of(user.getEmail()));
    }

    /**
     * Sends a user deletion email.
     *
     * @param user The user entity.
     */
    public void sendEmailDeletion(User user) {
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subject = this.applicationProperties.getEmail().getDeleteUser().getSubject();
        String body = StringSubstitutor.replace(this.applicationProperties.getEmail().getDeleteUser().getBody(), params,
                "${", "}");

        this.sendEmail(
                subject,
                body,
                List.of(user.getEmail()));
    }

    /**
     * Sends an email notification to the user when their role is modified.
     *
     * @param user     The user whose role was updated.
     * @param roleName The new role assigned to the user.
     */
    public void sendEmailModification(User user, String roleName) {
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);

        String subject = StringSubstitutor.replace(this.applicationProperties.getEmail().getUpdateUser().getSubject(),
                params, "${", "}");
        String body = StringSubstitutor.replace(this.applicationProperties.getEmail().getUpdateUser().getBody(), params,
                "${", "}");

        this.sendEmail(
                subject,
                body,
                List.of(user.getEmail()));
    }

    /**
     * Sends an email notification when a new role is assigned to a user.
     *
     * <p>
     * This method builds an HTML representation of the role and its associated
     * locations,
     * substitutes dynamic values into the email subject and body templates, and
     * sends the email
     * to the specified user.
     *
     * <p>
     * Steps performed:
     * <ul>
     * <li>Generates HTML rows for role-location details using
     * {@code buildRoleLocationRowsHtml}.</li>
     * <li>Prepares template parameters such as first name, last name, role, and
     * SmartOffice admin URL.</li>
     * <li>Substitutes placeholders in subject and body templates using
     * {@link StringSubstitutor}.</li>
     * <li>Sends the email to the user's email address.</li>
     * </ul>
     *
     * @param user      the user who has been assigned a new role; must not be null
     * @param roleName  the name of the newly assigned role; must not be null
     * @param locations an Object[] containing location details for the role;
     *                  expected format aligns with HTML builder
     */
    public void sendEmailContentCreation(User user, String roleName, Object[] locations) {
        // Build HTML rows with proper rowspan
        String roleLocationsRows = buildRoleLocationRowsHtml(roleName, locations);
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);
        params.put("ROLE_LOCATIONS_ROWS", roleLocationsRows);
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subjectTemplate = this.applicationProperties.getEmail().getCreateUser().getSubject();
        String bodyTemplate = this.applicationProperties.getEmail().getCreateUser().getBody().replace("LOCATION_HEADER",
                locations[0].toString());

        String subject = StringSubstitutor.replace(subjectTemplate, params, "${", "}");
        String substitutedBody = StringSubstitutor.replace(bodyTemplate, params, "${", "}");

        // NOTE : Replace line feed (this is not underscore code ( _ _ ))
        String body = substitutedBody.replaceAll("\\R+", " ").replace('\n', ' ');

        this.sendEmail(subject, body, List.of(user.getEmail()));
    }

    /**
     * Sends an email notification when a user's role locations are modified.
     *
     * <p>
     * This method builds an HTML representation of the updated role and its
     * associated locations,
     * substitutes dynamic values into the email subject and body templates, and
     * sends the email
     * to the specified user.
     *
     * <p>
     * Steps performed:
     * <ul>
     * <li>Generates HTML rows for role-location details using
     * {@code buildRoleLocationRowsHtml}.</li>
     * <li>Prepares template parameters such as first name, last name, role, and
     * SmartOffice admin URL.</li>
     * <li>Substitutes placeholders in subject and body templates using
     * {@link StringSubstitutor}.</li>
     * <li>Sends the email to the user's email address.</li>
     * </ul>
     *
     * @param user      the user whose role locations have been modified; must not
     *                  be null
     * @param roleName  the name of the role that was updated; must not be null
     * @param locations an Object[] containing location details for the role;
     *                  expected format aligns with HTML builder
     */
    public void sendEmailContentModification(User user, String roleName, Object[] locations) {
        // Build HTML rows with proper rowspan
        String roleLocationsRows = buildRoleLocationRowsHtml(roleName, locations);
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);
        params.put("ROLE_LOCATIONS_ROWS", roleLocationsRows);
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subjectTemplate = this.applicationProperties.getEmail().getUpdateUser().getSubject();
        String bodyTemplate = this.applicationProperties.getEmail().getUpdateUser().getBody().replace("LOCATION_HEADER",
                locations[0].toString());

        String subject = StringSubstitutor.replace(subjectTemplate, params, "${", "}");
        String substitutedBody = StringSubstitutor.replace(bodyTemplate, params, "${", "}");

        // NOTE : Replace line feed (this is not underscore code ( _ _ ))
        String body = substitutedBody.replaceAll("\\R+", " ").replace('\n', ' ');

        this.sendEmail(subject, body, List.of(user.getEmail()));
    }

    private String buildRoleLocationRowsHtml(String roleName, Object[] locations) {
        final String safeRole = StringEscapeUtils.escapeHtml4(roleName == null ? "" : roleName);
        if (locations == null) {
            return "";
        }
        
        // Case A: Single location at index 1, list absent
        if (locations != null && locations[0] != null && locations[1] != null && locations[2] == null) {
            String safeLoc = StringEscapeUtils.escapeHtml4(String.valueOf(locations[1]));
            return new StringBuilder()
                    .append("<tr>")
                    .append("<td><strong>").append(safeRole).append("</strong></td>")
                    .append("<td><strong>").append(safeLoc).append("</strong></td>")
                    .append("</tr>")
                    .toString();
        }
        // Case B: List of locations at index 2, single location absent
        if (locations[0] != null && locations[1] == null && locations[2] != null) {
            if (locations[2] instanceof List<?>) {
                @SuppressWarnings("unchecked")
                List<String> locationList = (List<String>) locations[2];
                if (locationList == null || locationList.isEmpty()) {
                    return "";
                }
                StringBuilder sb = new StringBuilder();
                int n = locationList.size();

                for (int i = 0; i < n; i++) {
                    String loc = locationList.get(i);
                    String safeLoc = StringEscapeUtils.escapeHtml4(loc == null ? "" : loc);

                    sb.append("<tr>");
                    if (i == 0) {
                        sb.append("<td rowspan=\"").append(n).append("\"><strong>")
                                .append(safeRole)
                                .append("</strong></td>");
                    }
                    sb.append("<td>").append(safeLoc).append("</td>");
                    sb.append("</tr>");
                }
                return sb.toString();
            }
            // If not a List, nothing to render
            return "";
        }
        // No matching case
        return "";
    }

    /**
     * Sends an email using the configured email service.
     *
     * @param subject   The subject of the email.
     * @param body      The body content of the email.
     * @param addresses The list of recipient email addresses.
     */
    private void sendEmail(
            String subject,
            String body,
            List<String> addresses) {
        EmailDTO emailDTO = new EmailDTO();

        emailDTO.setSubject(subject);
        emailDTO.setBody(body);
        emailDTO.setAdressee(addresses);

        try {
            emailService.sendEmail(emailDTO);
        } catch (Exception e) {
            log.error("Error while sending email in UserService via MS Graph error: {}",  e.getMessage(), e);
        }
    }

    @Transactional
    public void assignUserToBuilding(User user, Building securedBuilding) {
        try {
            User userWithBuildings = userRepository.findUserWithBuildings(user.getId())
                    .orElseThrow(() -> new EntityNotFoundException("User not found"));
            log.info("securedBuilding IN assignUserToBuilding : {} {} {}", securedBuilding.getId(), securedBuilding.getTitleEn(), securedBuilding.getCdmKeyId());
            //Collection<Building> userSecuredBuildings = userWithBuildings.getUserSecuredBuildings();
            // for (Building building : userSecuredBuildings) {
            //     if (building.getId().equals(securedBuilding.getId())) {
            //         log.info("User already assigned to this building: {}", securedBuilding.getTitleEn());
            //        // return; // User is already assigned to this building, no action needed
            //     }
                
            // }
            boolean alreadyAssigned = userWithBuildings.getUserSecuredBuildings()
                            .stream()
                            .anyMatch(b -> b.getId().equals(securedBuilding.getId()));

            if (!alreadyAssigned) {
                log.info("Assigning user in assignUserToBuilding {} to building {}", userWithBuildings.getEmail(), securedBuilding.getTitleEn());
                userWithBuildings.getUserSecuredBuildings().add(securedBuilding);
                userRepository.save(userWithBuildings);

            }
            sendEmailSecuredUserImport(userWithBuildings, Constants.SECURED_USER, securedBuilding.getTitleEn());
            // if (!userWithBuildings.getUserSecuredBuildings().contains(securedBuilding)) {
            //     log.info("Assigning user in assignUserToBuilding {} to building {}", userWithBuildings.getEmail(), securedBuilding.getTitleEn());
            //     userWithBuildings.getUserSecuredBuildings().add(securedBuilding);
            //     this.userRepository.save(userWithBuildings); // Correct the save to the entity with updated buildings
            // }
        } catch (DataIntegrityViolationException e) {
            if (e.getCause() instanceof ConstraintViolationException) {
                ConstraintViolationException constraintException = (ConstraintViolationException) e.getCause();
                // Handle specific duplicate key violations or constraint issues
                String message = "Duplicate entry or constraint violation detected: "
                        + constraintException.getConstraintName();
                log.warn(message); // Log the error
            }
        } catch (EntityNotFoundException e) {
            // Handle specific entity not found error
            log.error("User not found: ", e);
        } catch (Exception e) {
            // Catch any other exceptions
            log.error("An unexpected error occurred while assigning user to building: ", e);
            throw e; // Optionally, rethrow the exception if you want to propagate it further
        }
    }

    /**
     * Fetch all users with roles and location data, and prepare it for CSV export.
     */
    public List<List<String>> getExportAllUsers() {
        // Fetch data from the repository
        try {
            return userRepository.getExportAllUsers();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve users export data.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve users export data.");
        }
    }


    /**
     * Export user data as a CSV file.
     */
    public ResponseEntity<String> export(List<List<String>> data) {
        // CSV Header
        List<String> headers = Arrays.asList(
                "Name",
                "Email",
                "Role",
                "Location Access");

        // Add header to the data
        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();

        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=Users.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    /**
     * Fetch Secured users and location data, and prepare it for CSV export.
     */
    public List<List<String>> getExportSecuredAndBetaUsers() {
        // Fetch data from the repository
        try {
            return userRepository.getExportSecuredAndBetaUsers();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve secured and beta users export data.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to retrieve secured and beta users export data.");
        }
    }


    /**
     * Export only Secured User data as a CSV file
     */
    public ResponseEntity<String> securedUsersExport(List<List<String>> data) {
        // CSV Header
        List<String> headers = Arrays.asList("Name", "Email", "Role", "Location");

        // Add header to the data
        data.add(0, headers);

        ExportCsv exportCsv = new ExportCsv();

        // Add a BOM to the content to tell Excel that the file is in UTF-8
        String content = "\ufeff" + exportCsv.export(data);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=Users.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(content);
    }

    /**
     * Checks the format of the CSV file and returns any structural errors found.
     *
     * @param file The CSV file to be checked
     * @return A list of structural errors found during the check
     */
    public List<String> checkCSVFormat(MultipartFile file) {
        List<String> structuralErrors = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            final int maxLinesToRead = Constants.MAX_SECURED_USER_IMPORT_DATA_LINES + 1;
            while (lineNumber < maxLinesToRead && Objects.nonNull((line = br.readLine()))) {
                lineNumber++;
                line = line.trim();
                line = stripTrailingCommas(line);
                String[] infos = line.split(",");

                // Check if it's the header line and verify its format
                if (lineNumber == 1) {
                    if (checkHeader(infos)) {
                        continue;
                    } else {
                        structuralErrors.add("Incorrect header format. Please use the correct headers.");
                        return structuralErrors;
                    }
                }
                int length = infos.length;
                // Check the number of variables in each line
                if (length != Constants.SECURED_USER_COLUMN_COUNT) {
                    structuralErrors.add(
                            String.format(
                                    "Line %s: must contain %s variables - this line contains %s variables",
                                    lineNumber,
                                    Constants.SECURED_USER_COLUMN_COUNT,
                                    length));
                }
            }

            if (Objects.nonNull(br.readLine())) {
                structuralErrors.add(String.format(
                        "The file contains too many data lines. Maximum allowed is %s.",
                        Constants.MAX_SECURED_USER_IMPORT_DATA_LINES));
                return structuralErrors;
            }

            if (lineNumber == 0) {

                structuralErrors.add("The file is empty.");
            } else if (lineNumber == 1) {
                structuralErrors.add("No data present in the file.");
            }
        } catch (IOException e) {
            structuralErrors.add("Error while reading the file: " + e.getMessage() + ".");
        }
        return structuralErrors;
    }

    /**
     * Generates a ResponseSecuredUserImportDTO from the provided CSV file, adding
     * Users and errors as needed.
     *
     * @param file The CSV file from which to generate the response DTO
     * @return The ResponseSecuredUserImportDTO containing the imported securedusers
     *         and any errors encountered
     */
    public ResponseSecuredUserImportDTO generateResponseSecuredUserImportDTO(MultipartFile file) {
        ResponseSecuredUserImportDTO responseSecuredUserImportDTO = new ResponseSecuredUserImportDTO();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                lineNumber++;
                if (lineNumber > Constants.MAX_SECURED_USER_IMPORT_DATA_LINES + 1) {
                    responseSecuredUserImportDTO.addError(String.format(
                            "The file contains too many data lines. Maximum allowed is %s.",
                            Constants.MAX_SECURED_USER_IMPORT_DATA_LINES));
                    return responseSecuredUserImportDTO;
                }
                // Skip the header line
                if (lineNumber == 1) {
                    continue;
                }
                // Clean trailing commas
                line = line.trim();
                line = stripTrailingCommas(line);


                String[] securedUserFromCsv = line.split(",");
                int length = securedUserFromCsv.length;
                // Check the number of columns in each line
                if (length != Constants.SECURED_USER_COLUMN_COUNT) {
                    String error = String.format("Line %s: must contain %s columns - found %s", lineNumber,
                            Constants.SECURED_USER_COLUMN_COUNT, length);
                    responseSecuredUserImportDTO.addError(error);
                    continue; // Skip the rest of the processing for this line
                }

                if (Objects.isNull(securedUserFromCsv[Constants.IDX_NAME])
                        || securedUserFromCsv[Constants.IDX_NAME].isEmpty()) {
                    responseSecuredUserImportDTO
                            .addError(String.format("Line %s:  first_name column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(securedUserFromCsv[Constants.IDX_EMAIL_ID])
                        || securedUserFromCsv[Constants.IDX_EMAIL_ID].isEmpty()) {
                    responseSecuredUserImportDTO
                            .addError(String.format("Line %s:   email_Id column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(securedUserFromCsv[Constants.IDX_ROLE_NAME])
                        || securedUserFromCsv[Constants.IDX_ROLE_NAME].isEmpty()) {
                    responseSecuredUserImportDTO
                            .addError(String.format("Line %s: role_name column shouldn't be empty.", lineNumber));
                }
                if (Objects.isNull(securedUserFromCsv[Constants.IDX_BUILDING_TITLE])
                        || securedUserFromCsv[Constants.IDX_BUILDING_TITLE].isEmpty()) {
                    responseSecuredUserImportDTO
                            .addError(String.format("Line %s: BUILDING_TITLE column shouldn't be empty.", lineNumber));
                }

                if (Objects.isNull(responseSecuredUserImportDTO.getErrorsInFile())
                        || responseSecuredUserImportDTO.getErrorsInFile().isEmpty()) {
                    try {
                        // Create TabletImportDTO from the line
                        SecuredUserImportDTO securedUserImportDTO = createSecuredUserImportDTO(securedUserFromCsv);
                        responseSecuredUserImportDTO.addSecuredUser(securedUserImportDTO);
                    } catch (NumberFormatException e) {
                        log.error("Line {}: Error while parsing secured user import information", lineNumber, e);
                        responseSecuredUserImportDTO
                                .addError(String.format("Line %s: Error while parsing information.", lineNumber));
                    } catch (Exception e) {
                        log.error("Line {}: Error while importing secured user", lineNumber, e);
                        responseSecuredUserImportDTO
                                .addError(String.format("Line %s: Error while importing secured user.", lineNumber));
                    }

                }
            }
        } catch (IOException e) {
            log.error("Error while reading secured user import file", e);
            responseSecuredUserImportDTO.addError("Error while reading the file.");
        }

        return responseSecuredUserImportDTO;
    }

    /**
     * Checks if the provided line matches the expected header format.
     *
     * @param line The line to be checked
     * @return true if the line matches the expected header format, false otherwise
     */
    private boolean checkHeader(String[] line) {
        return (line.length == Constants.SECURED_USER_COLUMN_COUNT &&
                Constants.HEADER_NAME.equalsIgnoreCase(line[Constants.IDX_NAME]) && // Replace "FirstName" & "LastName"
                                                                                    // with "Name"
                Constants.HEADER_EMAIL_ID.equalsIgnoreCase(line[Constants.IDX_EMAIL_ID]) &&
                Constants.HEADER_ROLE_NAME.equalsIgnoreCase(line[Constants.IDX_ROLE_NAME]) &&
                Constants.HEADER_BUILDING_TITLE.equalsIgnoreCase(line[Constants.IDX_BUILDING_TITLE]));
    }

    /**
     * Creates a SecuredUserImportDTO object from the provided CSV data.
     *
     * @param securedUserFromCsv The array containing the CSV data for the tablet
     * @return The SecuredUserImportDTO object created from the CSV data
     */
    private SecuredUserImportDTO createSecuredUserImportDTO(String[] securedUserFromCsv) {
        SecuredUserImportDTO securedUserImportDTO = new SecuredUserImportDTO();

        // Split "Name" into First Name & Last Name
        String[] nameParts = securedUserFromCsv[Constants.IDX_NAME].trim().split(" ", 2);
        securedUserImportDTO.setFirstName(nameParts.length > 0 ? nameParts[0] : ""); // First name
        securedUserImportDTO.setLastName(nameParts.length > 1 ? nameParts[1] : ""); // Last name

        securedUserImportDTO.setEmailId(securedUserFromCsv[Constants.IDX_EMAIL_ID]);
        securedUserImportDTO.setRoleName(securedUserFromCsv[Constants.IDX_ROLE_NAME]);
        securedUserImportDTO.setBuildingTitleEn(securedUserFromCsv[Constants.IDX_BUILDING_TITLE]);

        return securedUserImportDTO;
    }

    /**
     * Removes any trailing ',' characters from the given line in a single pass.
     * Replaces attacker-driven per-character substring loops with a bounded scan.
     *
     * @param line the input line (must not be null)
     * @return the line with trailing commas removed
     */
    private static String stripTrailingCommas(String line) {
        int end = line.length();
        while (end > 0 && line.charAt(end - 1) == ',') {
            end--;
        }
        return end == line.length() ? line : line.substring(0, end);
    }

    @Transactional

    public List<LocationDTO> getUserLocationsById(Long userId) {
        List<UserRoleLocation> userRoleLocations = userRoleLocationRepository.findByUserId(userId);

        if (userRoleLocations == null || userRoleLocations.isEmpty()) {
            throw new ResourceNotFoundException("No locations found for user ID " + userId);
        }

        Role facilityManagerRole = roleRepository.findByName(Constants.FACILITY_MANAGER);
        Long facilityManagerRoleId = facilityManagerRole != null ? facilityManagerRole.getId() : null;

        if (facilityManagerRoleId == null) {
            log.warn("Facility Manager role not found. Returning empty location list.");
            return Collections.emptyList();
        }
        List<LocationDTO> locationList = userRoleLocations.stream()
                .filter(url -> url.getRole() != null && facilityManagerRoleId.equals(url.getRole().getId()))
                .map(this::createLocationDTO)
                .collect(Collectors.toList());

        return locationList;
    }

    /**
     * Updates the role-location mappings for a user with the "Facility Manager"
     * role.
     * Handles global and country-level assignments, alert status updates, and
     * validation.
     *
     * @param userId The ID of the user.
     * @param subscribeAlert The alert subscription flag.
     * @param locations The locations to update for the role.
     * @return A UserRoleLocationDTO containing the updated role and locations.

     * @throws ResourceNotFoundException if the user or role is not found.
     * @throws ResponseStatusException   if any validation or persistence error
     *                                   occurs.
     */
    @Transactional
    public UserRoleLocationDTO updateUserRoleLocations(Long userId, Boolean subscribeAlert, List<LocationDTO> locations) {
        Long sanitizedUserId = userId == null ? null : Long.valueOf(String.valueOf(userId));
        Boolean sanitizedSubscribeAlert = subscribeAlert == null
                ? null
                : Boolean.valueOf(String.valueOf(subscribeAlert));
        List<LocationDTO> sanitizedInputLocations = sanitizeRoleLocationUpdateLocations(locations);

        User user = validateUserForRoleLocationUpdate(sanitizedUserId);
        Long authorizedTargetUserId = Long.valueOf(String.valueOf(user.getId()));

        UserRoleLocationDTO sanitizedDto = new UserRoleLocationDTO();
        sanitizedDto.setUserId(authorizedTargetUserId);
        sanitizedDto.setSubscribeAlert(sanitizedSubscribeAlert);
        sanitizedDto.setLocations(sanitizedInputLocations);

        Role role = roleRepository.findByName(Constants.FACILITY_MANAGER);
        if (Objects.isNull(role) || Objects.isNull(role.getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role not found with this id.");
        }
        sanitizedDto.setRoleId(Long.valueOf(role.getId()));

        user.setSubscribeAlert(sanitizedDto.getSubscribeAlert() == null
                ? null
                : Boolean.valueOf(String.valueOf(sanitizedDto.getSubscribeAlert())));

        List<UserRoleLocation> existingLocations = userRoleLocationRepository.findByUserIdAndRoleId(authorizedTargetUserId,
                role.getId());


        List<UserRoleLocation> locationsToSave = new ArrayList<>();
        List<LocationDTO> responseLocations = new ArrayList<>();

        UserRoleLocation existingGlobalLocation = existingLocations.stream()
                .filter(loc -> loc.getLevel() == LevelEnum.GLOBAL)
                .findFirst()
                .orElse(null);

        if (sanitizedDto.getLocations().isEmpty()) {
            existingLocations.forEach(loc -> {
                loc.setAlertStatus(false);
                locationsToSave.add(loc);
            });
            userRoleLocationRepository.saveAll(locationsToSave);
            return buildResponseDTO(user, role, Collections.emptyList());
        }

        Map<Long, UserRoleLocation> cdmKeyIdToLocationMap = existingLocations.stream()
                .filter(loc -> loc.getCdmKeyId() != null)
                .collect(Collectors.toMap(UserRoleLocation::getCdmKeyId, Function.identity()));

        Set<Long> incomingCdmKeyIds = sanitizedDto.getLocations().stream()
                .map(LocationDTO::getCdmKeyId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        // for Global level
        Set<Long> incomingCdmKeyIdsNull = sanitizedDto.getLocations().stream()
                .map(LocationDTO::getCdmKeyId)
                .filter(Objects::isNull)
                .collect(Collectors.toSet());

        Set<Long> validCdmKeyIds = countryRepository.findByCdmKeyIdIn(incomingCdmKeyIds).stream()
                .map(Country::getCdmKeyId)
                .collect(Collectors.toSet());

        for (UserRoleLocation existing : existingLocations) {
            boolean isGlobal = existing.getLevel() == LevelEnum.GLOBAL;
            boolean hasGlobalInList = incomingCdmKeyIdsNull.contains(existing.getCdmKeyId());
            boolean isRemoved = existing.getCdmKeyId() != null && !incomingCdmKeyIds.contains(existing.getCdmKeyId());

            if ((isGlobal && !hasGlobalInList) || isRemoved) {
                existing.setAlertStatus(false);
                locationsToSave.add(existing);
            }

        }

        for (LocationDTO locationDTO : sanitizedDto.getLocations()) {
            LevelEnum level = locationDTO.getLevel();

            if (level == LevelEnum.GLOBAL) {
                UserRoleLocation globalLocation = existingGlobalLocation != null ? existingGlobalLocation
                        : new UserRoleLocation();
                globalLocation.setUser(user);
                globalLocation.setRole(role);
                globalLocation.setLevel(LevelEnum.GLOBAL);
                globalLocation.setCdmKeyId(null);
                globalLocation.setAlertStatus(sanitizedDto.getSubscribeAlert());
                locationsToSave.add(globalLocation);
                continue;
            }

            if (!validCdmKeyIds.contains(locationDTO.getCdmKeyId()))
                continue;

            UserRoleLocation location = cdmKeyIdToLocationMap.getOrDefault(locationDTO.getCdmKeyId(),
                    new UserRoleLocation());
            location.setUser(user);
            location.setRole(role);
            location.setLevel(level);
            location.setCdmKeyId(locationDTO.getCdmKeyId());
            location.setAlertStatus(sanitizedDto.getSubscribeAlert());
            locationsToSave.add(location);
        }

        List<UserRoleLocation> savedLocations = userRoleLocationRepository.saveAll(locationsToSave);

        savedLocations.stream()
                .filter(loc -> Boolean.TRUE.equals(loc.getAlertStatus()))
                .map(loc -> {
                    LocationDTO locationDTO = new LocationDTO();
                    locationDTO.setId(loc.getId());
                    locationDTO.setLevel(loc.getLevel());
                    locationDTO.setCdmKeyId(loc.getCdmKeyId());
                    locationDTO.setAlertStatus(sanitizedDto.getSubscribeAlert());
                    return locationDTO;
                })
                .forEach(responseLocations::add);

        return buildResponseDTO(user, role, responseLocations);
    }


    /**
     * Builds a {@link UserRoleLocationDTO} response object using the provided user,
     * role, and location list.
     *
     * @param user      The user entity.
     * @param role      The role entity.
     * @param locations The list of location DTOs.
     * @return A populated UserRoleLocationDTO.
     */
    private UserRoleLocationDTO buildResponseDTO(User user, Role role, List<LocationDTO> locations) {
        UserRoleLocationDTO responseDTO = new UserRoleLocationDTO();
        responseDTO.setUserId(user.getId());
        responseDTO.setSubscribeAlert(user.getSubscribeAlert());
        responseDTO.setRoleId(role.getId());
        responseDTO.setRoleName(role.getName());
        responseDTO.setLocations(locations);
        return responseDTO;
    }

    private List<LocationDTO> sanitizeRoleLocationUpdateLocations(List<LocationDTO> locations) {
        List<LocationDTO> sanitizedLocations = new ArrayList<>();
        if (Objects.nonNull(locations)) {
            for (LocationDTO incomingLocation : locations) {
                if (Objects.isNull(incomingLocation)) {
                    continue;
                }
                LocationDTO sanitizedLocation = new LocationDTO();
                sanitizedLocation.setLevel(incomingLocation.getLevel() == null
                        ? null
                        : LevelEnum.valueOf(String.valueOf(incomingLocation.getLevel().name())));
                sanitizedLocation.setCdmKeyId(incomingLocation.getCdmKeyId() == null
                        ? null
                        : Long.valueOf(incomingLocation.getCdmKeyId()));
                sanitizedLocations.add(sanitizedLocation);
            }
        }
        return sanitizedLocations;
    }



    private User validateUserForRoleLocationUpdate(Long requestedUserId) {
        Long sanitizedRequestedUserId = requestedUserId == null
                ? null
                : Long.valueOf(String.valueOf(requestedUserId));
        if (sanitizedRequestedUserId == null || sanitizedRequestedUserId <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User id is required.");
        }

        User authenticatedUser = getAuthenticatedActiveUser();
        boolean isAdminUser = Constants.ADMIN.equals(authenticatedUser.getUserType());

        String authenticatedEmail = authenticatedUser.getEmail() == null
                ? null
                : new String(authenticatedUser.getEmail().trim());
        if (authenticatedEmail == null || authenticatedEmail.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
        }

        Long authorizedTargetUserId = Long.valueOf(String.valueOf(sanitizedRequestedUserId));

        try {
            if (isAdminUser) {
                return userRepository.findByIdAndDeletedFalse(authorizedTargetUserId)
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "User not found with id " + String.valueOf(authorizedTargetUserId)));
            }

            Long authenticatedUserId = authenticatedUser.getId() == null
                    ? null
                    : Long.valueOf(String.valueOf(authenticatedUser.getId()));
            if (authenticatedUserId == null || authenticatedUserId <= 0) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
            }
            if (!authenticatedUserId.equals(authorizedTargetUserId)) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
            }

            return userRepository.findByIdAndEmail(authenticatedUserId,
                            new String(authenticatedEmail))
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user."));

        } catch (IllegalArgumentException ex) {
            String safeRequestedUserIdForLog = sanitizeForLog(String.valueOf(authorizedTargetUserId));
            String safeAuthenticatedEmailForLog = sanitizeForLog(authenticatedEmail);
            log.error("Invalid data while validating role-location update: requestedUserId={}, authenticatedEmail={}",
                    safeRequestedUserIdForLog, safeAuthenticatedEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user data.");
        } catch (DataAccessException ex) {
            String safeRequestedUserIdForLog = sanitizeForLog(String.valueOf(authorizedTargetUserId));
            String safeAuthenticatedEmailForLog = sanitizeForLog(authenticatedEmail);
            log.error("Failed to validate role-location update: requestedUserId={}, authenticatedEmail={}",
                    safeRequestedUserIdForLog, safeAuthenticatedEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to validate user.");
        }
    }




    private UserDTO sanitizeUserForUpdate(UserDTO input) {
        if (Objects.isNull(input)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user payload.");
        }

        UserDTO sanitizedUser = new UserDTO();
        sanitizedUser.setId(input.getId() == null ? null : Long.valueOf(input.getId()));
        sanitizedUser.setEmail(input.getEmail() == null ? null : new String(String.valueOf(input.getEmail()).trim()));
        sanitizedUser.setFirstName(input.getFirstName() == null
                ? null
                : new String(String.valueOf(input.getFirstName()).trim()));
        sanitizedUser.setLastName(input.getLastName() == null
                ? null
                : new String(String.valueOf(input.getLastName()).trim()));
        sanitizedUser.setCountry(input.getCountry() == null ? null : new String(String.valueOf(input.getCountry()).trim()));
        sanitizedUser.setSubscribeAlert(input.getSubscribeAlert() == null
                ? null
                : Boolean.valueOf(String.valueOf(input.getSubscribeAlert())));

        List<RoleLocationDTO> sanitizedRoleLocations = new ArrayList<>();
        if (Objects.nonNull(input.getRoleLocations())) {
            for (RoleLocationDTO incomingRoleLocation : input.getRoleLocations()) {
                if (Objects.isNull(incomingRoleLocation) || Objects.isNull(incomingRoleLocation.getRole())
                        || Objects.isNull(incomingRoleLocation.getRole().getId())) {
                    continue;
                }

                RoleLocationDTO sanitizedRoleLocation = new RoleLocationDTO();
                com.capgemini.admin.back.model.RoleDTO sanitizedRole = new com.capgemini.admin.back.model.RoleDTO();
                sanitizedRole.setId(Long.valueOf(incomingRoleLocation.getRole().getId()));
                sanitizedRole.setName(incomingRoleLocation.getRole().getName() == null
                        ? null
                        : new String(String.valueOf(incomingRoleLocation.getRole().getName())));
                sanitizedRoleLocation.setRole(sanitizedRole);

                List<LocationDTO> sanitizedLocations = new ArrayList<>();
                if (Objects.nonNull(incomingRoleLocation.getLocations())) {
                    for (LocationDTO incomingLocation : incomingRoleLocation.getLocations()) {
                        if (Objects.isNull(incomingLocation)) {
                            continue;
                        }

                        LocationDTO sanitizedLocation = new LocationDTO();
                        sanitizedLocation.setId(incomingLocation.getId() == null ? null : Long.valueOf(incomingLocation.getId()));
                        sanitizedLocation.setLevel(incomingLocation.getLevel() == null
                                ? null
                                : LevelEnum.valueOf(String.valueOf(incomingLocation.getLevel().name())));
                        sanitizedLocation.setCdmKeyId(incomingLocation.getCdmKeyId() == null
                                ? null
                                : Long.valueOf(incomingLocation.getCdmKeyId()));
                        sanitizedLocation.setAlertStatus(incomingLocation.getAlertStatus() == null
                                ? null
                                : Boolean.valueOf(String.valueOf(incomingLocation.getAlertStatus())));
                        sanitizedLocations.add(sanitizedLocation);
                    }
                }
                sanitizedRoleLocation.setLocations(sanitizedLocations);
                sanitizedRoleLocations.add(sanitizedRoleLocation);
            }
        }
        sanitizedUser.setRoleLocations(sanitizedRoleLocations);
        return sanitizedUser;
    }

    private User getAuthenticatedActiveUser() {

        UserInformation userInformation;
        try {
            userInformation = userInformationService.getCurrent();
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
        }

        if (Objects.isNull(userInformation) || Objects.isNull(userInformation.getEmail())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
        }

        String authenticatedEmail = new String(userInformation.getEmail().trim());
        User authenticatedUser = userRepository.findActiveUserByEmail(authenticatedEmail);
        if (Objects.isNull(authenticatedUser)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
        }

        return authenticatedUser;
    }

    private Long resolveAuthorizedRoleId(UserDTO userDTO) {
        if (Objects.isNull(userDTO) || Objects.isNull(userDTO.getRoleLocations()) || userDTO.getRoleLocations().isEmpty()
                || Objects.isNull(userDTO.getRoleLocations().get(0))
                || Objects.isNull(userDTO.getRoleLocations().get(0).getRole())
                || Objects.isNull(userDTO.getRoleLocations().get(0).getRole().getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role ID is required.");
        }

        return resolveAuthorizedRoleId(Long.valueOf(userDTO.getRoleLocations().get(0).getRole().getId()));
    }

    private Long resolveAuthorizedRoleId(Long requestedRoleId) {
        Long sanitizedRequestedRoleId = requestedRoleId == null ? null : Long.valueOf(requestedRoleId);
        if (sanitizedRequestedRoleId == null || sanitizedRequestedRoleId <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role ID is required.");
        }

        User authenticatedUser = getAuthenticatedActiveUser();
        if (!Constants.ADMIN.equals(authenticatedUser.getUserType())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
        }

        try {
            Role requestedRole = roleRepository.findById(sanitizedRequestedRoleId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,
                            "Role not found with id " + sanitizedRequestedRoleId));

            return Long.valueOf(requestedRole.getId());
        } catch (IllegalArgumentException ex) {
            String safeRoleIdForLog = sanitizeForLog(String.valueOf(sanitizedRequestedRoleId));
            log.error("Invalid role id provided for resolveAuthorizedRoleId: {}", safeRoleIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid role id.");
        } catch (DataAccessException ex) {
            String safeRoleIdForLog = sanitizeForLog(String.valueOf(sanitizedRequestedRoleId));
            log.error("Failed to resolve role id {} for authorized role lookup", safeRoleIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to resolve role.");
        }
    }




    /**
     * Validates and retrieves a user by ID.
     *
     * @param id The ID of the user.
     * @return The User entity.
     * @throws ResourceNotFoundException if the user is not found.
     */
    public User validateUser(Long id) {
        return getUserById(id);
    }


    /**
     * Validates and retrieves a role by ID and name.
     *
     * @param id       The ID of the role.
     * @param roleName The expected role name.
     * @return The Role entity, or null if not found.
     */
    public Role validateUserRole(Long id, String roleName) {
        Role role = roleRepository.findByIdAndRoleName(id, roleName);
        return role;
    }

    private void validateRoleLocations(UserDTO userDTO) {
        if (Objects.isNull(userDTO) || Objects.isNull(userDTO.getRoleLocations()) || userDTO.getRoleLocations().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one role is required.");
        }

        for (RoleLocationDTO roleLocationDTO : userDTO.getRoleLocations()) {
            if (Objects.isNull(roleLocationDTO) || Objects.isNull(roleLocationDTO.getRole())
                    || Objects.isNull(roleLocationDTO.getRole().getId())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role ID is required.");
            }

            Long roleId = roleLocationDTO.getRole().getId();
            if (!roleRepository.existsById(roleId)) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role not found with id " + roleId);
            }
        }
    }

    /**
     * Updates the user profile by saving role associations for the given user.

     *
     * @param userDTO Data Transfer Object containing role-location mappings.
     * @param user    The user entity for whom the profile is being updated.
     */
    private void updateUserProfile(UserDTO userDTO, User user) {
        if (Objects.nonNull(userDTO.getRoleLocations())) {
            userDTO.getRoleLocations()
                    .forEach(roleLocationDTO -> {
                        if (Objects.isNull(roleLocationDTO) || Objects.isNull(roleLocationDTO.getRole())
                                || Objects.isNull(roleLocationDTO.getRole().getId())) {
                            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Role ID is required.");
                        }
                        Long authorizedRoleId = resolveAuthorizedRoleId(Long.valueOf(roleLocationDTO.getRole().getId()));
                        userProfileService.saveUserProfile(Long.valueOf(user.getId()), authorizedRoleId);
                    });
        }
    }


    /**
     * Checks if the email ID already exists for a user based on their role and
     * profile.
     *
     * @param userDTO         Data Transfer Object containing role-location
     *                        mappings.
     * @param existingUser    The existing user entity (if any).
     * @param userProfileList List of user profiles associated with the user.
     * @return true if the email ID already exists for a non-web user profile; false
     *         otherwise.
     */
    private boolean emailIdAlreadyExist(UserDTO userDTO, User existingUser, List<UserProfile> userProfileList) {
        boolean isEmailAlreadyExist = false;

        List<UserRoleLocation> userRoleList = userRoleLocationRepository.findByUserId(existingUser.getId());

        if (Objects.nonNull(userProfileList) && !userProfileList.isEmpty()) {
            for (UserProfile profile : userProfileList) {
                Optional<Role> role = roleRepository.findById(profile.getRoleId());
                if (role.isPresent()) {
                    Boolean hasWebUserProfile = role.get().getIsWebUserProfile();
                    if (Boolean.FALSE.equals(hasWebUserProfile)
                            && (!userProfileList.isEmpty() && !userRoleList.isEmpty())) {
                        isEmailAlreadyExist = true;
                    }
                }
            }
        }
        return isEmailAlreadyExist;
    }

    /**
     * Updates the user's role-location mappings.
     *
     * For each role-location combination in the UserDTO, this method checks if a
     * UserRoleLocation exists. If not, it creates a new one; otherwise, it updates
     * the existing entry with the latest location details.
     *
     * @param userDTO    DTO containing role-location mappings.
     * @param user       The user entity to update.
     * @param userRoleId The role ID used to check for existing mappings.
     */
    private void updateUserRoleLocation(UserDTO userDTO, User user, Long userRoleId) {
        if (userDTO.getRoleLocations() == null)
            return;

        Role facilityManagerRole = roleRepository.findByName(Constants.FACILITY_MANAGER);
        Long facilityManagerRoleId = facilityManagerRole != null ? facilityManagerRole.getId() : null;

        for (RoleLocationDTO roleLocationDTO : userDTO.getRoleLocations()) {
            Long roleId = roleLocationDTO.getRole().getId();
            Optional<Role> roleOptional = roleRepository.findById(roleId);
            if (!roleOptional.isPresent())
                continue;

            for (LocationDTO locationDTO : roleLocationDTO.getLocations()) {
                List<UserRoleLocation> existingRoleLocations = userRoleLocationRepository
                        .findByIdAndLevel(user.getId(), roleId, locationDTO.getCdmKeyId(), locationDTO.getLevel());

                UserRoleLocation userRoleLocation = existingRoleLocations.isEmpty()
                        ? new UserRoleLocation()
                        : existingRoleLocations.get(0);

                if (existingRoleLocations.isEmpty()) {
                    userRoleLocation.setRole(roleOptional.get());
                } else {
                    String safeUserRoleLocationId = sanitizeForLog(String.valueOf(userRoleLocation.getId()));
                    log.info("Updating existing UserRoleLocation with ID: {}", safeUserRoleLocationId);
                }


                userRoleLocation.setUser(user);
                userRoleLocation.setLevel(locationDTO.getLevel());
                userRoleLocation.setCdmKeyId(locationDTO.getCdmKeyId());

                boolean isFacilityManager = facilityManagerRoleId != null &&
                        facilityManagerRoleId.equals(userRoleId);

                userRoleLocation.setAlertStatus(isFacilityManager ? user.getSubscribeAlert() : null);

                userRoleLocationRepository.save(userRoleLocation);
            }
        }
    }

    /**
     * Sets the alert status for a user based on their role and subscription status.
     * <p>
     * This method checks if the given user has the "Facility Manager" role for the
     * specified
     * {@link UserRoleLocation}. If the user is a Facility Manager and is subscribed
     * to alerts,
     * the current alert status is retained. If the user is not subscribed, the
     * alert status is set to {@code false}.
     * For users who do not have the Facility Manager role, the alert status is set
     * to {@code null}.
     * </p>
     *
     * @param user             The {@link User} whose alert status is to be checked
     *                         and updated.
     * @param userRoleLocation The {@link UserRoleLocation} representing the user's
     *                         role and location context.
     */
    private void setAlertStatusIfFacilityManager(User user, UserRoleLocation userRoleLocation) {

        String safeUserIdForLog = sanitizeForLog(String.valueOf(user.getId()));
        String safeRoleLocationIdForLog = sanitizeForLog(String.valueOf(userRoleLocation.getId()));
        log.info("Starting alert status check for user ID: {} and role location ID: {}", safeUserIdForLog,
                safeRoleLocationIdForLog);

        Role facilityManagerRole = roleRepository.findByName(Constants.FACILITY_MANAGER);

        Long facilityManagerRoleId = facilityManagerRole != null ? facilityManagerRole.getId() : null;

        if (facilityManagerRoleId != null && facilityManagerRoleId.equals(userRoleLocation.getRole().getId())) {
            boolean isSubscribed = Boolean.TRUE.equals(user.getSubscribeAlert());

            if (isSubscribed) {
                userRoleLocation.setAlertStatus(user.getSubscribeAlert());
            } else {
                userRoleLocation.setAlertStatus(user.getSubscribeAlert());
            }
        } else {
            userRoleLocation.setAlertStatus(null);
        }
    }

    /**
     * Assigns a profile to a user based on the provided UserDTO and role
     * information.
     * This method performs the following steps:
     * Checks if the user already exists and validates email uniqueness for the
     * role.
     * Saves a new user profile if none exists for the given role.
     * Updates the user entity and role-location mapping if needed.
     * Sends an email notification upon successful profile assignment.
     *
     * @param userDTO           The user data transfer object containing user and
     *                          role details.
     * @param hasWebUserProfile Flag indicating if the user has a web profile.
     * @return The updated User entity after profile assignment.
     * @throws UserAlreadyExistsException If the email is already associated with
     *                                    the role.
     * @throws ResponseStatusException    If any validation or update fails.
     */

    @Transactional
    public User assignProfile(UserDTO userDTO, Boolean hasWebUserProfile)
            throws UserAlreadyExistsException, ResponseStatusException {

        validateRoleLocations(userDTO);

        // Step 1: Check if user already exists and is not deleted

        User existingUser = userRepository.findByEmailEvenIfDeleted(userDTO.getEmail());

        // Step 2: Resolve authorized role ID server-side
        Long roleId = resolveAuthorizedRoleId(userDTO);

        List<UserProfile> userProfileList = null;
        List<UserRoleLocation> existingLocations = null;
        User updatedUser;

        // Step 3: Validate email uniqueness for the role
        if (existingUser != null) {
            userProfileList = userProfileService.findAllByUserIdAndRoleId(existingUser.getId(), roleId);

            existingLocations = userRoleLocationRepository.findByUserIdAndRoleId(existingUser.getId(),
                    roleId);

            if (emailIdAlreadyExist(userDTO, existingUser, userProfileList)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Email ID already exists.");
            }
            updatedUser = updateUserForNewProfile(existingUser, userDTO);

            // Step 4: Assign profile if no existing profile found
            if (userProfileList == null || userProfileList.isEmpty()) {
                // Save user profile for the given role
                userProfileService.saveUserProfile(updatedUser.getId(), roleId);
            }

            if (existingLocations == null || existingLocations.isEmpty()) {
                // Update role-location mapping
                updateUserRoleLocation(userDTO, updatedUser, roleId);
            }
        } else {
            updatedUser = createNewUser(userDTO, roleId);
        }

        List<Long> savedRoleId = userRoleLocationRepository.findByUserId(updatedUser.getId())
                .stream()
                // .peek(roleLocation -> log.info("roleLocation in PEEK >> "+
                // roleLocation.getRole().getId()))
                .map(roleLocation -> roleLocation.getRole().getId())
                .collect(Collectors.toList());

        String newRoleName = userDTO.getRoleLocations()
                .stream()
                .map(roleLocation -> roleLocation.getRole())
                // .filter(role -> !savedRoleId.contains(role.getId()))
                .map(role -> role.getName())
                .findFirst()
                .orElse(null);

        // Object[] emailContentArray = sendEmailContentDetails(updatedUser, newRoleName);       
        // sendEmailContentCreation(updatedUser, newRoleName, emailContentArray);
        Map<String, List<String>> emailContentMap = getEmailContentDetailsMap(updatedUser, newRoleName);
        // action -> assignProfile
        sendEmailContentForActions(updatedUser, newRoleName, emailContentMap,Constants.ASSIGNPROFILE);        
        return updatedUser;
    }

    /**
     * Updates the given User entity with profile details from the provided UserDTO.
     * Sets user type to ADMIN and updates basic fields like email, name, and alert
     * preference.
     *
     * @param user    The existing User entity to be updated.
     * @param userDTO The DTO containing updated user information.
     * @return The persisted User entity after applying updates.
     */
    private User updateUserForNewProfile(User user, UserDTO userDTO) {
        user.setSubscribeAlert(Boolean.valueOf(Boolean.TRUE.equals(userDTO.getSubscribeAlert())));
        user.setDeleted(false);
        user.setEnabled(true);
        user.setUserType(Constants.ADMIN);
        user.setEmail(sanitizeRequiredText(userDTO.getEmail(), "Email is required."));
        user.setFirstName(sanitizeOptionalText(userDTO.getFirstName()));
        user.setLastName(sanitizeOptionalText(userDTO.getLastName()));
        return userRepository.save(user);
    }

    /**
     * Creates a new user or restores an existing (possibly deleted) user based on
     * the provided UserDTO.
     * 
     * Logic:
     * - Checks if a user with the given email already exists (even if deleted).
     * - If the user exists and is not deleted:
     * - Validates if the email ID is already associated with another active user
     * profile.
     * - Throws a conflict exception if the email is already in use.
     * - If the user exists but is deleted, restores the user.
     * - If no user exists, creates a new user.
     * - Sends a creation email based on the user's role.
     *
     * @param userDTO           Data transfer object containing user details.
     * @param hasWebUserProfile Flag indicating if the user has a web profile.
     * @return The saved or restored User entity.
     * @throws UserAlreadyExistsException If the user already exists and cannot be
     *                                    recreated.
     * @throws ResponseStatusException    If the email ID is already in use.
     */
    @Transactional
    public User createUser(UserDTO userDTO, Boolean hasWebUserProfile)
            throws UserAlreadyExistsException, ResponseStatusException {

        validateRoleLocations(userDTO);

        User existingUser = userRepository.findByEmailEvenIfDeleted(userDTO.getEmail());

        Long roleId = resolveAuthorizedRoleId(userDTO);

    

        User savedUser;

        if (existingUser != null) {
            if (!existingUser.isDeleted()) {
                log.info("createUser: existing active user found id={}, roleId={}", existingUser.getId(), roleId);
                throw new ResponseStatusException(HttpStatus.CONFLICT, "User already exists");
            } else {
                log.info("createUser: existing deleted user found id={}, restoring with roleId={}", existingUser.getId(), roleId);
                savedUser = restoreDeletedUser(existingUser, userDTO, roleId);
            }
        } else {
            log.info("createUser: no existing user, creating new user with roleId={}", roleId);
            savedUser = createNewUser(userDTO, roleId);
        }

        String roleName = userDTO.getRoleLocations().stream()
            .map(rl -> rl.getRole().getName())
            .findFirst()
            .orElse(null);

        log.info("createUser savedUser id={} email={} roleName={}", savedUser != null ? savedUser.getId() : null,
            savedUser != null ? savedUser.getEmail() : null, roleName);

        if (roleName != null) {
            log.info("createUser preparing sendEmail for roleName={}", roleName);
            // To get role and roleLocation details for speicfic role
            // Object[] emailContentArray = sendEmailContentDetails(savedUser, roleName);
            // sendEmailContentCreation(savedUser, roleName, emailContentArray);
            Map<String, List<String>> emailContentMap = getEmailContentDetailsMap(savedUser, roleName);
            //action -> createUser
            sendEmailContentForActions(savedUser, roleName, emailContentMap,Constants.CREATEUSER);
            log.info("createUser sendEmailContentForActions completed for userId={} action={}", savedUser != null ? savedUser.getId() : null, Constants.CREATEUSER);
        }
        return savedUser;    
    }

    /**
     * Deletes all admin-related role-location mappings for the given user.
     * This is typically used during user deletion or role reassignment.
     *
     * @param userId The ID of the user.
     */
    @Transactional
    public void deleteFromUserRoleLocation(Long userId) {
        if (userId == null || userId <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User id is required.");
        }
        try {
            userRoleLocationRepository.adminProfileDeletedByUserId(userId);
        } catch (DataAccessException ex) {
            String safeUserIdForLog = sanitizeForLog(String.valueOf(userId));
            log.error("Failed deleting admin role-location mappings for userId={}", safeUserIdForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete user role locations.");
        }
    }


    public User getActiveUserByEmail(String email) {
        // return userRepository.findActiveUserByEmail(email);
        // Modified to get user using query which does not use flag deleted =1
        try {
            return userRepository.findByEmailEvenIfDeleted(email);
        } catch (IllegalArgumentException ex) {
            String safeEmailForLog = sanitizeForLog(email);
            log.error("Invalid user email provided for getActiveUserByEmail: {}", safeEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid user email.");
        } catch (DataAccessException ex) {
            String safeEmailForLog = sanitizeForLog(email);
            log.error("Failed to retrieve active user by email {}", safeEmailForLog, ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve user.");
        }
    }


    /**
     * Prepares email content details for a given user and role.
     *
     * <p>
     * This method fetches role-location mappings for the specified user and role,
     * then constructs an array containing:
     * <ul>
     * <li>[0] - Level (e.g., GLOBAL, COUNTRY, CITY, SITE, BUILDING)</li>
     * <li>[1] - Single level detail (e.g., building name) if only one record
     * exists; otherwise null</li>
     * <li>[2] - List of level details (e.g., multiple building names) if multiple
     * records exist; otherwise null</li>
     * </ul>
     *
     * <p>
     * Special cases:
     * <ul>
     * <li>If no roles/locations are found, all elements are null.</li>
     * <li>If level is GLOBAL, location details remain null (or can be set to
     * "GLOBAL" based on business rules).</li>
     * </ul>
     *
     * @param user        the user for whom email content is prepared; must not be
     *                    null
     * @param newRoleName the role name to filter user-role-location mappings; must
     *                    not be null
     * @return an Object[] of size 3: [level, levelDetails, levelDetailsList]
     */
    public Object[] sendEmailContentDetails(User user, String newRoleName) {
        Object[] emailContentArray = new Object[3];

        String level;
        String levelDetails = null;
        List<String> levelDetailsList = null;
        List<Object[]> emailContentObjectList = userRepository.fetchEmailContent(user.getId(), newRoleName);

        List<EmailContentDTO> emailContentDTOs = emailContentObjectList.stream()
                .map(row -> {
                    EmailContentDTO dto = new EmailContentDTO();
                    dto.setEmail((String) row[IDX_EMAIL]);
                    dto.setRoleName((String) row[IDX_ROLE_NAME]);
                    dto.setCdmKeyId(row[IDX_CDM_KEY_ID] == null ? null : ((Number) row[IDX_CDM_KEY_ID]).longValue());
                    dto.setLevel((String) row[IDX_LEVEL]);
                    dto.setRoleId(row[IDX_ROLE_ID] == null ? null : ((Number) row[IDX_ROLE_ID]).longValue());
                    dto.setUserId(row[IDX_USER_ID] == null ? null : ((Number) row[IDX_USER_ID]).longValue());
                    dto.setCountryId(row[IDX_COUNTRY_ID] == null ? null : ((Number) row[IDX_COUNTRY_ID]).longValue());
                    dto.setCountryName((String) row[IDX_COUNTRY_NAME]);
                    dto.setCityId(row[IDX_CITY_ID] == null ? null : ((Number) row[IDX_CITY_ID]).longValue());
                    dto.setCityName((String) row[IDX_CITY_NAME]);
                    dto.setSitId(row[IDX_SITE_ID] == null ? null : ((Number) row[IDX_SITE_ID]).longValue());
                    dto.setSiteName((String) row[IDX_SITE_NAME]);
                    dto.setBuildingId(
                            row[IDX_BUILDING_ID] == null ? null : ((Number) row[IDX_BUILDING_ID]).longValue());
                    dto.setBuildingName((String) row[IDX_BUILDING_NAME]);
                    return dto;
                })
                .collect(Collectors.toList());

        if (emailContentObjectList == null || emailContentObjectList.isEmpty()) {
            String safeUserIdForLog = sanitizeForLog(String.valueOf(user.getId()));
            log.info("No roles/locations found for userId={}", safeUserIdForLog);
            level = null;
            // levelDetails remains null
        } else {
            if (emailContentDTOs.size() > 1) {

                level = emailContentDTOs.get(0).getLevel();

                switch (level) {
                    case "BUILDING":
                        levelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("BUILDING"))
                                .map(building -> building.getBuildingName())
                                .collect(Collectors.toList());
                        break;
                    case "SITE":
                        levelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("SITE"))
                                .map(site -> site.getSiteName())
                                .collect(Collectors.toList());
                        break;
                    case "CITY":
                        levelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("CITY"))
                                .map(city -> city.getCityName())
                                .collect(Collectors.toList());
                        break;
                    case "COUNTRY":
                        levelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("COUNTRY"))
                                .map(country -> country.getCountryName())
                                .collect(Collectors.toList());
                        break;
                    default:
                        log.info("DEFAULT CASE levelDetailsList");
                        break;
                }

            } else {
                level = emailContentDTOs.get(0).getLevel();
                switch (level) {
                    case "BUILDING":
                        levelDetails = emailContentDTOs.get(0).getBuildingName();
                        break;
                    case "SITE":
                        levelDetails = emailContentDTOs.get(0).getSiteName();
                        break;
                    case "CITY":
                        levelDetails = emailContentDTOs.get(0).getCityName();
                        break;
                    case "COUNTRY":
                        levelDetails = emailContentDTOs.get(0).getCountryName();
                        break;
                    default:
                        levelDetails = "GLOBAL";
                        level = "COUNTRY";
                        log.info("DEFAULT CASE levelDetails");
                        break;
                }
            }

            emailContentArray[0] = level;
            emailContentArray[1] = levelDetails;
            emailContentArray[2] = levelDetailsList;

        }

        return emailContentArray;
    }

    /**
     * Computes role/location changes between DB and payload and prepares email
     * payloads for changed roles.
     * Only roles present in both payload and savedRoleIds are compared (countries +
     * global flag).
     * Location display names are resolved from payload order; "Global" is included
     * when applicable.
     * Returns an empty list if inputs are null or no payload roles exist in DB.
     * Role name is taken from payload, falling back to DB or "UNKNOWN_ROLE".
     */     
    private List<RoleEmailInfo> planExistingRoleLocationEmails(Long userId, UserDTO updatedUser, List<Long> savedRoleIds) {
        log.info("planExistingRoleLocationEmails: ENTER userId={}, savedRoleIds={}", userId, savedRoleIds);
    
        List<RoleEmailInfo> planned = new ArrayList<>();
        if (updatedUser == null || updatedUser.getRoleLocations() == null || savedRoleIds == null) return planned;
    
        Map<Long, RolePayloadAggregate> dbMap = buildRoleAggregatesFromDb(userId);
        Map<Long, RolePayloadAggregate> payloadMap = buildRoleAggregatesFromPayload(updatedUser);
    
        Set<Long> payloadExisting = payloadMap.keySet().stream()
                .filter(new LinkedHashSet<>(savedRoleIds)::contains)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    
        if (payloadExisting.isEmpty()) {
            log.info("planExistingRoleLocationEmails: no existing roles in payload to compare.");
            return planned;
        }
    
        for (Long roleId : payloadExisting) {
            RolePayloadAggregate dbAgg = dbMap.getOrDefault(roleId, new RolePayloadAggregate(null,
                    new LinkedHashSet<>(), new LinkedHashSet<>(), new LinkedHashSet<>(), new LinkedHashSet<>(), false));
            RolePayloadAggregate payloadAgg = payloadMap.get(roleId);
            String roleName = payloadAgg.getRoleName() != null ? payloadAgg.getRoleName() :
                    (dbAgg.getRoleName() != null ? dbAgg.getRoleName() : "UNKNOWN_ROLE");
    
            boolean globalChanged    = dbAgg.isHasGlobal() != payloadAgg.isHasGlobal();
            boolean countriesChanged = !Objects.equals(dbAgg.getCountryIds(), payloadAgg.getCountryIds());
            boolean citiesChanged    = !Objects.equals(dbAgg.getCityIds(), payloadAgg.getCityIds());
            boolean sitesChanged     = !Objects.equals(dbAgg.getSiteIds(), payloadAgg.getSiteIds());
            boolean buildingsChanged = !Objects.equals(dbAgg.getBuildingIds(), payloadAgg.getBuildingIds());
    
            log.info("DIFF role={} globalChanged={} countriesChanged={} citiesChanged={} sitesChanged={} buildingsChanged={}",
                    roleName, globalChanged, countriesChanged, citiesChanged, sitesChanged, buildingsChanged);
    
            if (globalChanged) planned.add(new RoleEmailInfo(roleName, toHeaderLabel("GLOBAL"), List.of("Global")));
            if (countriesChanged) planned.add(new RoleEmailInfo(roleName, toHeaderLabel("COUNTRY"),
                    resolveNamesByLevel("COUNTRY", payloadAgg.getCountryIds())));
            if (citiesChanged) planned.add(new RoleEmailInfo(roleName, toHeaderLabel("CITY"),
                    resolveNamesByLevel("CITY", payloadAgg.getCityIds())));
            if (sitesChanged) planned.add(new RoleEmailInfo(roleName, toHeaderLabel("SITE"),
                    resolveNamesByLevel("SITE", payloadAgg.getSiteIds())));
            if (buildingsChanged) planned.add(new RoleEmailInfo(roleName, toHeaderLabel("BUILDING"),
                    resolveNamesByLevel("BUILDING", payloadAgg.getBuildingIds())));
        }
        return planned;
    }
   
    /**
     * Applies a single (level, cdmKeyId) into the given RolePayloadAggregate.
     * Handles GLOBAL/COUNTRY/CITY/SITE/BUILDING in one place.
     */
    private void applyLocationToAggregate(RolePayloadAggregate agg, LevelEnum level, Long cdmKeyId) {
        if (agg == null || level == null) return;
    
        switch (level) {
            case GLOBAL:
                agg.setHasGlobal(true);
                break;
            case COUNTRY:
                if (cdmKeyId != null) agg.getCountryIds().add(cdmKeyId);
                break;
            case CITY:
                if (cdmKeyId != null) agg.getCityIds().add(cdmKeyId);
                break;
            case SITE:
                if (cdmKeyId != null) agg.getSiteIds().add(cdmKeyId);
                break;
            case BUILDING:
                if (cdmKeyId != null) agg.getBuildingIds().add(cdmKeyId);
                break;
            default:
                // no-op
                break;
        }
    }

    /**
     * Returns an existing RolePayloadAggregate for the roleId from the map, or creates
     * a new one with empty sets and puts it into the map.
     */
    private RolePayloadAggregate getOrCreateAggregate(Map<Long, RolePayloadAggregate> map,
                                                      Long roleId,
                                                      String roleNameIfNew) {
        RolePayloadAggregate agg = map.get(roleId);
        if (agg == null) {
            agg = new RolePayloadAggregate(
                roleNameIfNew,
                new LinkedHashSet<Long>(),
                new LinkedHashSet<Long>(),
                new LinkedHashSet<Long>(),
                new LinkedHashSet<Long>(),
                false
            );
            map.put(roleId, agg);
        }
        return agg;
    }
    
    /**
     * Builds a snapshot of the user's role-location assignments from the database.
     * Groups all UserRoleLocation rows by roleId and aggregates their countries,
     * cities, sites, buildings, and global flags into RolePayloadAggregate objects.
     * Used as the “before update” state to compare with the incoming payload.
     *
     * @param userId ID of the user whose role-location data is fetched
     * @return Map of roleId → aggregated DB state
     */
    private Map<Long, RolePayloadAggregate> buildRoleAggregatesFromDb(Long userId) {
        List<UserRoleLocation> urls = userRoleLocationRepository.findByUserId(userId);
        Map<Long, RolePayloadAggregate> map = new LinkedHashMap<>();
    
        log.info("buildRoleAggregatesFromDb: userId={}, rowCount={}", userId, urls.size());
    
        for (UserRoleLocation url : urls) {
            Long roleId = url.getRole().getId();
            String roleName = url.getRole().getName();
    
            RolePayloadAggregate agg = getOrCreateAggregate(map, roleId, roleName);
            applyLocationToAggregate(agg, url.getLevel(), url.getCdmKeyId());
        }
    
        map.forEach((roleId, agg) ->
            log.info("DB-SNAPSHOT roleId={}, roleName={}, global={}, countries={}, cities={}, sites={}, buildings={}",
                roleId, agg.getRoleName(), agg.isHasGlobal(), agg.getCountryIds(), agg.getCityIds(),
                agg.getSiteIds(), agg.getBuildingIds()));
    
        return map;
    }

    /**
     * Builds a snapshot of the incoming payload’s role-location structure.
     * Aggregates all locations (country/city/site/building/global) per role
     * into RolePayloadAggregate instances using the same model as the DB snapshot.
     * Used as the “after update” state for comparison and change detection.
     *
     * @param updatedUser DTO containing modified role-location data
     * @return Map of roleId → aggregated payload state
     */      
    private Map<Long, RolePayloadAggregate> buildRoleAggregatesFromPayload(UserDTO updatedUser) {
        Map<Long, RolePayloadAggregate> map = new LinkedHashMap<>();
        if (updatedUser == null || updatedUser.getRoleLocations() == null) return map;
    
        for (RoleLocationDTO rl : updatedUser.getRoleLocations()) {
            if (rl.getRole() == null || rl.getRole().getId() == null) continue;
            Long roleId = rl.getRole().getId();
            String roleName = rl.getRole().getName();
            RolePayloadAggregate agg = getOrCreateAggregate(map, roleId, roleName);
    
            if (rl.getLocations() == null) continue;
            for (LocationDTO loc : rl.getLocations()) {
                applyLocationToAggregate(agg, loc.getLevel(), loc.getCdmKeyId());
            }
        }
    
        return map;
    }

    /**
     * Lightweight value object carrying email content for a single role.
     * Contains role display name and ordered list of location names for rendering.
     * Location names reflect payload order and may include "Global" when
     * applicable.
     * Used by the email service to substitute placeholders into the HTML template.
     * Immutable fields with getters to ensure simple, predictable usage.
     */

    public class RoleEmailInfo {
        private final String roleName;
        private final String levelHeader; // e.g., "COUNTRY", "CITY", "SITE", "BUILDING", "GLOBAL"
        private final List<String> locationNames;
    
        public RoleEmailInfo(String roleName, String levelHeader, List<String> locationNames) {
            this.roleName = roleName;
            this.levelHeader = levelHeader;
            this.locationNames = locationNames;
        }
    
        public String getRoleName() { return roleName; }
        public String getLevelHeader() { return levelHeader; }
        public List<String> getLocationNames() { return locationNames; }
    }


    /**
     * Immutable aggregate representing a role’s location assignment snapshot.
     * Holds role name, ordered de-duplicated country IDs, and global flag.
     * Used both for DB and payload states to enable simple equality checks.
     * Facilitates change detection for countries/global without side effects.
     * Exposes read-only getters; construct new instances to represent updates.
     */      
    public static final class RolePayloadAggregate {
        private String roleName;
        private LinkedHashSet<Long> countryIds = new LinkedHashSet<>();
        private LinkedHashSet<Long> cityIds = new LinkedHashSet<>();
        private LinkedHashSet<Long> siteIds = new LinkedHashSet<>();
        private LinkedHashSet<Long> buildingIds = new LinkedHashSet<>();
        private boolean hasGlobal;
    
        public RolePayloadAggregate() {}
    
        public RolePayloadAggregate(String roleName) { this.roleName = roleName; }

        public RolePayloadAggregate(
                String roleName,
                LinkedHashSet<Long> countryIds,
                LinkedHashSet<Long> cityIds,
                LinkedHashSet<Long> siteIds,
                LinkedHashSet<Long> buildingIds,
                boolean hasGlobal
        ) {
            this.roleName = roleName;
            this.countryIds = (countryIds != null) ? countryIds : new LinkedHashSet<>();
            this.cityIds = (cityIds != null) ? cityIds : new LinkedHashSet<>();
            this.siteIds = (siteIds != null) ? siteIds : new LinkedHashSet<>();
            this.buildingIds = (buildingIds != null) ? buildingIds : new LinkedHashSet<>();
            this.hasGlobal = hasGlobal;
        }

        public String getRoleName() { return roleName; }
        public void setRoleName(String roleName) { this.roleName = roleName; }
    
        public LinkedHashSet<Long> getCountryIds() { return countryIds; }
        public void setCountryIds(LinkedHashSet<Long> countryIds) { this.countryIds = countryIds; }
    
        public LinkedHashSet<Long> getCityIds() { return cityIds; }
        public void setCityIds(LinkedHashSet<Long> cityIds) { this.cityIds = cityIds; }
    
        public LinkedHashSet<Long> getSiteIds() { return siteIds; }
        public void setSiteIds(LinkedHashSet<Long> siteIds) { this.siteIds = siteIds; }

        public LinkedHashSet<Long> getBuildingIds() { return buildingIds; }
        public void setBuildingIds(LinkedHashSet<Long> buildingIds) { this.buildingIds = buildingIds; }
    
        public boolean isHasGlobal() { return hasGlobal; }
        public void setHasGlobal(boolean hasGlobal) { this.hasGlobal = hasGlobal; }
    }

    /**
     * Renders and sends the “Location rights updated” HTML email to the user.
     * Joins location names with <br/>
     * so they stack within a single table cell.
     * Substitutes placeholders (name, role, locations, portal URL) into template.
     * Requires mail sender to set Content-Type: text/html; charset=UTF-8.
     * Sends to the user’s email address using the configured email service.
     */    
    public void sendEmailRoleLocationsUpdated(User user, String roleName, String locationHeader, List<String> locationNames) {        
        String roleLocationRows = buildRowsForUpdateUserLocations(roleName, locationNames);
   
        Map<String, Object> params = new HashMap<>();
        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);    
        params.put("ROLE_LOCATIONS_ROWS", roleLocationRows); 
        params.put("LOCATION_HEADER", locationHeader);
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");
    
        String subject = StringSubstitutor.replace(
                this.applicationProperties.getEmail().getUpdateUserLocations().getSubject(),
                params, "${", "}");
        String body = StringSubstitutor.replace(
                this.applicationProperties.getEmail().getUpdateUserLocations().getBody(),
                params, "${", "}").replaceAll("\\R+", " ").replace('\n', ' ');
        
        String safeEmailForLog = sanitizeForLog(user.getEmail());
        String safeRoleNameForLog = sanitizeForLog(roleName);
        String safeSubjectForLog = sanitizeForLog(subject);
        log.info("EMAIL[LocationUpdate SINGLE]: to={}, role={}, subject={}", safeEmailForLog, safeRoleNameForLog, safeSubjectForLog);
        log.debug("EMAIL BODY (truncated): {}", body.length() > 200 ? body.substring(0, 200) + "..." : body);

        
        this.sendEmail(subject, body, List.of(user.getEmail()));
    }

    /**
     * Resolves human‑readable location names (Country/City/Site/Building)
     * based on the provided level and CDM Key IDs.
     * Queries the appropriate repository and preserves payload order.
     * Returns a list of names or an empty list if none found.
     */
    private List<String> resolveNamesByLevel(String level, LinkedHashSet<Long> ids) {
        if (ids == null || ids.isEmpty()) return Collections.emptyList();
    
        Map<Long, String> idToName = new HashMap<>();
        List<Long> idList = new ArrayList<>(ids);
    
        switch (level) {
            case "COUNTRY": {
                List<Tuple> tuples = countryRepository.getNameByCmdKeyId(idList);
                for (Tuple t : tuples) {
                    Long id = t.get(0, Long.class);
                    String nm = t.get(1, String.class);
                    if (id != null && nm != null) idToName.put(id, nm);
                }
                break;
            }
            case "CITY": {
                List<Tuple> tuples = cityRepository.getNameByCmdKeyId(idList);
                for (Tuple t : tuples) {
                    Long id = t.get(0, Long.class);
                    String nm = t.get(1, String.class);
                    if (id != null && nm != null) idToName.put(id, nm);
                }
                break;
            }
            case "SITE": {
                List<Tuple> tuples = siteRepository.getNameByCmdKeyId(idList);
                for (Tuple t : tuples) {
                    Long id = t.get(0, Long.class);
                    String nm = t.get(1, String.class);
                    if (id != null && nm != null) idToName.put(id, nm);
                }
                break;
            }
            case "BUILDING": {
                List<Tuple> tuples = buildingRepository.getNameByCmdKeyId(idList);
                for (Tuple t : tuples) {
                    Long id = t.get(0, Long.class);
                    String nm = t.get(1, String.class);
                    if (id != null && nm != null) idToName.put(id, nm);
                }
                break;
            }
            default:
                return Collections.emptyList();
        }
    
        // Preserve input order
        List<String> names = new ArrayList<>(idList.size());
        for (Long id : idList) {
            names.add(idToName.getOrDefault(id, level + "_" + id));
        }
        return names;
    }
    
    /**
     * Converts an internal level key (COUNTRY, CITY, SITE, BUILDING, GLOBAL)
     * into the display label used as the email table header.
     * Global is shown as “Location”, all others mapped to title case.
     */
    private static String toHeaderLabel(String levelKey) {
        if ("COUNTRY".equals(levelKey)) {
            return "Country";
        } else if ("CITY".equals(levelKey)) {
            return "City";
        } else if ("SITE".equals(levelKey)) {
            return "Site";
        } else if ("BUILDING".equals(levelKey)) {
            return "Building";
        } else if ("GLOBAL".equals(levelKey)) {
            // show "Location" when Global changed
            return "Location";
        } else {
            return "Location";
        }
    }
    
    /**
     * Builds HTML <tr> rows for the UpdateUserLocations email table.
     * First row includes the role name with rowspan; subsequent rows list locations.
     * Each cell has borders to ensure proper rendering in Outlook.
     * Returns a multi‑row HTML string in the required table format.
     */   
    private String buildRowsForUpdateUserLocations(String roleName, List<String> locationNames) {
        final String safeRole = org.apache.commons.text.StringEscapeUtils.escapeHtml4(
                roleName == null ? "" : roleName);
    
        if (locationNames == null || locationNames.isEmpty()) {
            return new StringBuilder()
                    .append("<tr>")
                    .append("<td style=\"border:1px solid #999;\">").append(safeRole).append("</td>")
                    .append("<td style=\"border:1px solid #999;\">-</td>")
                    .append("</tr>")
                    .toString();
        }

        StringBuilder sb = new StringBuilder();
        int n = locationNames.size();
        for (int i = 0; i < n; i++) {
            String loc = locationNames.get(i) == null ? "" : locationNames.get(i);
            String safeLoc = org.apache.commons.text.StringEscapeUtils.escapeHtml4(loc);
    
            sb.append("<tr>");
            if (i == 0) {
                sb.append("<td style=\"border:1px solid #999;\" rowspan=\"")
                  .append(n)
                  .append("\">")
                  .append(safeRole)
                  .append("</td>");
            }
            sb.append("<td style=\"border:1px solid #999;\">").append(safeLoc).append("</td>");
            sb.append("</tr>");
        }
        return sb.toString();
    }
     /* Prepares email content details for a given user and role.
     * @param user  the user for whom email content is prepared; must not be null
     * @param newRoleName the role name to filter user-role-location mappings; must
     *                    not be null
     * @return an Map of Level and List of Locations.
     */
    public Map<String,List<String>> getEmailContentDetailsMap(User user, String newRoleName) {
        log.info("in  getEmailContentDetailsMap ");
        Map<String, List<String>> byLevel = new HashMap<>();
        List<Object[]> emailContentObjectList = userRepository.fetchEmailContent(user.getId(), newRoleName);
        log.info("in  emailContentObjectList size " + emailContentObjectList.size());
        List<EmailContentDTO> emailContentDTOs = emailContentObjectList.stream()
                .map(row -> {
                    EmailContentDTO dto = new EmailContentDTO();
                    dto.setEmail((String) row[IDX_EMAIL]);
                    dto.setRoleName((String) row[IDX_ROLE_NAME]);
                    dto.setCdmKeyId(row[IDX_CDM_KEY_ID] == null ? null : ((Number) row[IDX_CDM_KEY_ID]).longValue());
                    dto.setLevel((String) row[IDX_LEVEL]);
                    dto.setRoleId(row[IDX_ROLE_ID] == null ? null : ((Number) row[IDX_ROLE_ID]).longValue());
                    dto.setUserId(row[IDX_USER_ID] == null ? null : ((Number) row[IDX_USER_ID]).longValue());
                    dto.setCountryId(row[IDX_COUNTRY_ID] == null ? null : ((Number) row[IDX_COUNTRY_ID]).longValue());
                    dto.setCountryName((String) row[IDX_COUNTRY_NAME]);
                    dto.setCityId(row[IDX_CITY_ID] == null ? null : ((Number) row[IDX_CITY_ID]).longValue());
                    dto.setCityName((String) row[IDX_CITY_NAME]);
                    dto.setSitId(row[IDX_SITE_ID] == null ? null : ((Number) row[IDX_SITE_ID]).longValue());
                    dto.setSiteName((String) row[IDX_SITE_NAME]);
                    dto.setBuildingId(
                            row[IDX_BUILDING_ID] == null ? null : ((Number) row[IDX_BUILDING_ID]).longValue());
                    dto.setBuildingName((String) row[IDX_BUILDING_NAME]);
                    return dto;
                })
                .collect(Collectors.toList());        
   
        if (emailContentObjectList == null || emailContentObjectList.isEmpty()) {
            String safeUserIdForLog = sanitizeForLog(String.valueOf(user.getId()));
            log.info("No roles/locations found for userId={}", safeUserIdForLog);
            //level = null;
            // levelDetails remains null
        } else {
            log.info("emailContentObjectList size" + emailContentObjectList.size());
            List<String> distinctLevels = emailContentDTOs.stream()
                .map(EmailContentDTO::getLevel)          
                .filter(Objects::nonNull)                
                .map(String::trim)                       
                .map(String::toUpperCase)
                .collect(Collectors.toCollection(LinkedHashSet::new)) // dedupe, keep order
                .stream()
                .collect(Collectors.toList());
            
            distinctLevels.forEach(levelName -> {             

                switch (levelName) {
                    case "BUILDING":
                    List<String> bldgLevelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("BUILDING"))
                                .map(building -> building.getBuildingName())
                                .collect(Collectors.toList());
                        
                        byLevel.put("BUILDING", bldgLevelDetailsList);
                        break;
                    case "SITE":
                        List<String> siteLevelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("SITE"))
                                .map(site -> site.getSiteName())
                                .collect(Collectors.toList());
                        byLevel.put("SITE", siteLevelDetailsList);        
                        break;
                    case "CITY":
                        List<String> cityLevelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("CITY"))
                                .map(city -> city.getCityName())
                                .collect(Collectors.toList());
                        byLevel.put("CITY", cityLevelDetailsList);  
                        break;
                    case "COUNTRY":
                        List<String> countryLevelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("COUNTRY"))
                                .map(country -> country.getCountryName())
                                .collect(Collectors.toList());
                        byLevel.put("COUNTRY", countryLevelDetailsList);
                        break;
                    default:
                        log.info("DEFAULT CASE levelDetailsList");
                        List<String> globalLevelDetailsList = emailContentDTOs.stream()
                                .filter(urls -> urls.getUserId().equals(user.getId())
                                        && urls.getEmail().equals(user.getEmail())
                                        && urls.getLevel().equals("GLOBAL"))
                                .map(country -> "GLOBAL")
                                .collect(Collectors.toList());
                        byLevel.put("GLOBAL", globalLevelDetailsList);
                        break;
                }
            });            
                       
        }
        return byLevel;
    }

    /**
     * Prepares email content details for a given user and role and send email.
     * @param user  the user for whom email content is prepared; must not be null
     * @param roleName the role name to filter user-role-location mappings; must
     *                    not be null
     * @param levelDetailsMaps Map of Level and List of Locations.
     */
    public void sendEmailContentForActions(User user, String roleName, Map<String,List<String>> levelDetailsMaps, String action) {
        
        String roleLocationsHeadrAndRows = buildRoleHeaderAndLocationRows(roleName, levelDetailsMaps);
        Map<String, Object> params = new HashMap<>();
        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subjectTemplate = null;
        String initalBody = null;
        String footer = null;
        if(action.equalsIgnoreCase(Constants.CREATEUSER) || action.equalsIgnoreCase(Constants.ASSIGNPROFILE) ){
            subjectTemplate = applicationProperties.getEmail().getCreateUserNew().getSubject();
            initalBody = StringSubstitutor.replace(applicationProperties.getEmail().getCreateUserNew().getBody() , params, "${", "}");
            footer  = applicationProperties.getEmail().getUpdateUserNew().getFooter();
        }
        
        else if (action.equalsIgnoreCase(Constants.UPDATE_USER_LOCATIONS)) {
        subjectTemplate = applicationProperties.getEmail().getUpdateUserLocationsNew().getSubject(); 
        initalBody = StringSubstitutor.replace(
                applicationProperties.getEmail().getUpdateUserLocationsNew().getBody(), 
                params, "${", "}"
        );
        footer = applicationProperties.getEmail().getUpdateUserLocationsNew().getFooter(); 

        } else {
            // Fallback → Additional Role (UPDATEUSER etc.)
            subjectTemplate = applicationProperties.getEmail().getUpdateUserNew().getSubject();
            initalBody = StringSubstitutor.replace(
                    applicationProperties.getEmail().getUpdateUserNew().getBody(),
                    params, "${", "}"
            );
            footer = applicationProperties.getEmail().getUpdateUserNew().getFooter();
        }
        
        String subject = StringSubstitutor.replace(subjectTemplate, params, "${", "}");
        String substitutedBody = initalBody + roleLocationsHeadrAndRows + footer ;// StringSubstitutor.replace(roleLocationsRows, params, "${", "}");
        String body = substitutedBody.replaceAll("\\R+", " ").replace('\n', ' ');
             
        this.sendEmail(subject, body, List.of(user.getEmail()));
    }

    /**
     * Prepares email content details for a given user and role.
     * @param roleName the role name to filter user-role-location mappings; must
     *                    not be null
     * @param levelDetailsMaps Map of Level and List of Locations.
     */
    private String buildRoleHeaderAndLocationRows(String roleName, Map<String, List<String>> levelDetailsMap) {
        final String safeRole = StringEscapeUtils.escapeHtml4(roleName == null ? "" : roleName.trim());

        if (levelDetailsMap == null || levelDetailsMap.isEmpty()) {
            return buildSingleTableHtml(safeRole, "LOCATION", Collections.emptyList());
        }
        
        Map<String, String> actualKey = new HashMap<>();
        for (String k : levelDetailsMap.keySet()) {
            if (k != null) actualKey.put(k, k);
        }
      
        List<String> orderedKeys = new ArrayList<>();
        if (actualKey.containsKey("GLOBAL")) {
            orderedKeys.add(actualKey.get("GLOBAL"));
        } else if (actualKey.containsKey("COUNTRY")) {
            orderedKeys.add(actualKey.get("COUNTRY"));
        }
       
        for (String next : ORDER_AFTER_FIRST) {
            String actual = actualKey.get(next);
            if (actual != null) orderedKeys.add(actual);
        }
      
        Set<String> already = new HashSet<>(orderedKeys);
        List<String> extras = levelDetailsMap.keySet().stream()
                .filter(k -> k != null && !already.contains(k))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.toList());
        orderedKeys.addAll(extras);
        
        if (orderedKeys.isEmpty()) {
            return buildSingleTableHtml(safeRole, "LOCATION", Collections.emptyList());
        }
        
        List<String> tables = new ArrayList<>();
        for (String key : orderedKeys) {
            List<String> values = levelDetailsMap.getOrDefault(key, Collections.emptyList());
            tables.add(buildSingleTableHtml(safeRole, key, values));
        }
      
        return String.join("\n <P> and <P> \n", tables);
    }

    /**
     * Builds a single table for one header and its values.
     * LOCATION_HEADER is the header text (map key).
     * @param roleName the role name to filter user-role-location mappings; must
     *                    not be null
     * @param locationHeader the header for COUNTRY/CITY?SITE/BUILDING
     * @param valuesLList of COUNTRY/CITY?SITE/BUILDING
    */
    
    private String buildSingleTableHtml(String roleName, String locationHeader, List<String> values) {

        // Escape dynamic text only
        String safeRole = StringEscapeUtils.escapeHtml4(roleName == null ? "" : roleName);

        String headerText =
                (locationHeader == null || locationHeader.trim().isEmpty())
                        ? "LOCATION"
                        : (locationHeader.trim().equalsIgnoreCase("GLOBAL") ? "COUNTRY" : locationHeader.trim());

        String safeHeader = StringEscapeUtils.escapeHtml4(headerText);

        StringBuilder rows = new StringBuilder();

        if (values == null || values.isEmpty()) {
            // Single row when no locations
            rows.append("<tr>")
                .append("<td>").append(safeRole).append("</td>")
                .append("<td>N/A</td>")
                .append("</tr>");
        } else {

            int rowCount = values.size();

            // First row (with rowspan for role)
            String firstValue = StringEscapeUtils.escapeHtml4(values.get(0));

            rows.append("<tr>")
                .append("<td rowspan=\"").append(rowCount).append("\">")
                .append(safeRole)
                .append("</td>")
                .append("<td>").append(firstValue).append("</td>")
                .append("</tr>");

            // Remaining rows (location only)
            for (int i = 1; i < rowCount; i++) {
                String safeValue = StringEscapeUtils.escapeHtml4(values.get(i));
                rows.append("<tr>")
                    .append("<td>").append(safeValue).append("</td>")
                    .append("</tr>");
            }
        }

        return new StringBuilder()
            .append("<table border=\"1\" cellpadding=\"6\" cellspacing=\"0\" style=\"border-collapse:collapse;\">")
            .append("<thead>")
            .append("<tr>")
            .append("<th style=\"text-align:left;\">ROLE</th>")
            .append("<th style=\"text-align:left;\">").append(safeHeader).append("</th>")
            .append("</tr>")
            .append("</thead>")
            .append("<tbody>")
            .append(rows)
            .append("</tbody>")
            .append("</table>")
            .toString();
    }
   
    /**
     * Determines whether the email should be sent in SINGLE mode or COMBINED mode.
     * 
     * <p>This method checks how many levels (Country, Region, Location, etc.)
     * contain non-empty value lists. If only one level has data, a simple
     * single‑section email is sent. If multiple levels have data, a combined
     * email structure is more appropriate.</p>
     *
     * @param levelDetailsMap Map of level-name → list of values after update.
     * @return EmailMode.SINGLE if there is <= 1 non-empty level, otherwise EmailMode.COMBINED.
     */
    private EmailMode decideMode(Map<String, List<String>> levelDetailsMap) {
        // Count how many entries have non-null AND non-empty value lists
        long nonEmpty = levelDetailsMap.values().stream()
                .filter(v -> v != null && !v.isEmpty())
                .count();
        // If only 0 or 1 non-empty section → send a simple single-mode email
        return (nonEmpty <= 1) ? EmailMode.SINGLE : EmailMode.COMBINED;
    }
      
    /**
     * Sends location-update email(s) for existing roles based on the planned changes.
     *
     * <p>This method groups all changes by role name, then for each role it builds a
     * consolidated final view of location details using {@code getEmailContentDetailsMap()}.
     * Depending on how many location levels contain data, it decides whether to send:
     * <ul>
     *   <li>A SINGLE-mode email (when only one level changed)</li>
     *   <li>A COMBINED-mode email (when multiple levels changed)</li>
     * </ul>
     * 
     * <p>The email structure, subject, and body content differ between single and
     * combined modes, and this method routes to the correct email-builder method.</p>
     *
     * @param user The user whose roles are being updated.
     * @param planned List of role/location changes planned for this update cycle.
     */
    private void sendLocationUpdateEmailsForExistingRoles(User user, List<RoleEmailInfo> planned) {
        if (planned == null || planned.isEmpty())  return;
    
        Map<String, List<RoleEmailInfo>> byRole = planned.stream()
                .collect(Collectors.groupingBy(RoleEmailInfo::getRoleName, LinkedHashMap::new, Collectors.toList()));
    
        for (Map.Entry<String, List<RoleEmailInfo>> entry : byRole.entrySet()) {
            String roleName = entry.getKey();
    
            Map<String, List<String>> byLevel = getEmailContentDetailsMap(user, roleName);
            if (byLevel == null) byLevel = new LinkedHashMap<>();
    
            Map<String, List<String>> nonEmptyByLevel = byLevel.entrySet().stream()
                    .filter(e -> e.getValue() != null && !e.getValue().isEmpty())
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a,b)->a, LinkedHashMap::new));

            String safeRoleNameForLog = sanitizeForLog(roleName);
            String safeNonEmptyLevelsForLog = sanitizeForLog(String.valueOf(nonEmptyByLevel.keySet()));
            log.info("sendLocationUpdateEmailsForExistingRoles: role={}, nonEmptyLevels={}", safeRoleNameForLog, safeNonEmptyLevelsForLog);
            if (nonEmptyByLevel.isEmpty()) continue;

            EmailMode mode = decideMode(nonEmptyByLevel);
            log.info("sendLocationUpdateEmailsForExistingRoles: role={}, mode={}", safeRoleNameForLog, mode);
    
            if (mode == EmailMode.SINGLE) {
                Map.Entry<String, List<String>> only = nonEmptyByLevel.entrySet().iterator().next();
                String headerLabel = toHeaderLabel(only.getKey());
                String safeHeaderLabelForLog = sanitizeForLog(headerLabel);
                String safeValuesForLog = sanitizeForLog(String.valueOf(only.getValue()));
                log.info("sendLocationUpdateEmailsForExistingRoles: SINGLE → header={}, values={}", safeHeaderLabelForLog, safeValuesForLog);
                // Send and log inside method
                sendEmailRoleLocationsUpdated(user, roleName, headerLabel, only.getValue());
            } else {
                log.info("sendLocationUpdateEmailsForExistingRoles: COMBINED → passing action=UPDATE_USER_LOCATIONS");
                sendEmailContentForActions(user, roleName, nonEmptyByLevel, Constants.UPDATE_USER_LOCATIONS);
            }
        }

    }

    /**
    * Retrieves all users.
    * @return List of users with roles.
    */
    public List<User> getAllAdminUsers() {
        try {
            return userRepository.findAllAdminUsers();
        } catch (DataAccessException ex) {
            log.error("Failed to retrieve admin users.", ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to retrieve admin users.");
        }
    }


    /**
    * Retrieves the user’s country from LDAP using their email address.
    * Establishes an LDAP connection, performs a lookup, and extracts the "co" (country) attribute
    * from the first matching LDAP result. Returns null if no match is found or if an error occurs
    * during lookup.
    *
    * @param email the user’s corporate email used for LDAP search
    * @return the country value from LDAP, or null if unavailable
    */
    private String getCountryFromLDAP(String email) {
       try {
           // Initialize LDAP connection
            ldapData.getLdapData();

           // Fetch user details from LDAP using the provided email
           List<EmployeeDetailDTO> list = ldapData.getUserDetailsBySearch(email);
   
           if (list != null && !list.isEmpty()) {
               // Validate response and return first country found
               return list.get(0).getCountry();
           }
       } catch (Exception e) {
           String safeEmail = sanitizeForLog(email);
           log.error("Failed fetching country from LDAP for {}", safeEmail, e);
       }

       return null;
    }   

    public String getMappedCountryFromLDAP(String email) {

        try {
            log.info("LDAP_COUNTRY_FETCH_START | email={}", email);
    
            // ✅ STEP 1: Call LDAP
            String ldapCountry = getCountryFromLDAP(email); // your existing LDAP call
    
            log.info("LDAP_COUNTRY_RAW | email={} | ldapCountry='{}'", email, ldapCountry);
    
            if (ldapCountry == null || ldapCountry.trim().isBlank()) {
                log.warn("LDAP_COUNTRY_EMPTY | email={}", email);
                return null;
            }

            String inputCountry = ldapCountry.trim();
    
            // ✅ STEP 2: DIRECT COUNTRY TABLE CHECK
            Optional<Country> countryOpt =
                    countryRepository.findByTitleEnIgnoreCase(inputCountry);
    
            if (countryOpt.isPresent()) {
                String resolved = countryOpt.get().getTitleEn();
    
                log.info("COUNTRY_DIRECT_MATCH | email={} | input={} | resolved={}",
                        email, inputCountry, resolved);
    
                return resolved;
            }

            // ✅ STEP 3: MAPPING TABLE CHECK
            Optional<CountryMapping> mappingOpt =
                    countryMappingRepository
                            .findByGraphCountryNameIgnoreCaseAndIsActiveTrue(inputCountry);
    
            if (mappingOpt.isPresent()) {
    
                Country mappedCountry = mappingOpt.get().getCountry();
                String resolved = mappedCountry.getTitleEn();
    
                log.info("COUNTRY_MAPPING_MATCH | email={} | input={} | resolved={}",
                        email, inputCountry, resolved);
    
                return resolved;
            }

            // ✅ STEP 4: NOT FOUND
            log.warn("COUNTRY_NOT_FOUND | email={} | input={}", email, inputCountry);
    
            return null;
    
        } catch (Exception e) {
            log.error("LDAP_COUNTRY_ERROR | email={} | message={}", email, e.getMessage(), e);
            return null;
        }
    }

    public void sendEmailSecuredUserImport(User user, String roleName, String countryOrBuildingName) {
        // Build HTML rows with proper rowspan
        String roleCountryOrBuildingRows = buildSecureRoleBuildingRows(roleName, countryOrBuildingName);
        Map<String, Object> params = new HashMap<>();

        params.put("FIRST_NAME", user.getFirstName());
        params.put("LAST_NAME", user.getLastName());
        params.put("ROLE", roleName);
        params.put("ROLE_COUNTRY_OR_BUILDING_ROWS", roleCountryOrBuildingRows);
        params.put("APP_SMARTOFFICE_ADMIN_URL", "https://admin-smartoffice.capgemini.com/#/home/sitetree/welcome");

        String subjectTemplate = this.applicationProperties.getEmail().getSpecialUserImport().getSubject();
        String bodyTemplate = ""; // this.applicationProperties.getEmail().getSpecialUserImport().getBody();
        if(roleName.equalsIgnoreCase(Constants.SECURED_USER)) {
            bodyTemplate = this.applicationProperties.getEmail().getSpecialUserImport().getBodysecured();
        }
        else{
            bodyTemplate = this.applicationProperties.getEmail().getSpecialUserImport().getBodybeta();
        }

        String subject = StringSubstitutor.replace(subjectTemplate, params, "${", "}");
        String substitutedBody = StringSubstitutor.replace(bodyTemplate, params, "${", "}");

        // NOTE : Replace line feed (this is not underscore code ( _ _ ))
        String body = substitutedBody.replaceAll("\\R+", " ").replace('\n', ' ');
        log.info("EMAIL[SecuredUserImport]: to={}, role={}, subject={} , body={}", sanitizeForLog(user.getEmail()), sanitizeForLog(roleName), sanitizeForLog(subject), sanitizeForLog(body));
        sendEmail(subject, body, List.of(user.getEmail()));
       
    }

    private String buildSecureRoleBuildingRows(String roleName, String countryOrBuildingName) {
        final String safeRole = StringEscapeUtils.escapeHtml4(roleName == null ? "" : roleName);
        final String safeCountryOrBuilding = StringEscapeUtils.escapeHtml4(countryOrBuildingName == null ? "" : countryOrBuildingName);
        String rows = "";
        if (countryOrBuildingName != null) {
            rows = new StringBuilder()
                    .append("<tr>")
                    .append("<td>").append(safeRole).append("</td>")
                    .append("<td>").append(safeCountryOrBuilding).append("</td>")
                    .append("</tr>")
                    .toString();
        } 
        return rows;    
    }

}
