package com.capgemini.admin.back.model;

public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}