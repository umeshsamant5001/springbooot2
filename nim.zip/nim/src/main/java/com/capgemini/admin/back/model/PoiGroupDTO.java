package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PoiGroupDTO implements WithTitleDTO {

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long id;

	private String name;

	private List<String> attributeKeys;

	private Map<String, String> attributes = new HashMap<>();

	private String titleFr;

	private String titleEn;

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private String title;

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long poisCount;

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long spaceTypeCount;

	private Boolean isFromCdm;

	private List<SpaceTypeDTO> spaceTypes = new ArrayList<>();

	private Boolean isVisibleOnPWA;

	private String icon;

}