package com.capgemini.admin.back.repository;

import com.capgemini.admin.back.model.NotificationEmailSent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NotificationEmailSentRepository extends JpaRepository<NotificationEmailSent, Long> {
    /**
     * Return the last notificationSent for all the "running" notification
     * 
     * @return
     */
    @Query(value = "SELECT notification_email_sent.* FROM notification_email_sent INNER JOIN ( "
            + " SELECT notification_email_sent.notification_email_id AS notification_email_id, MAX(notification_email_sent.sent_at) AS sent_at "
            + " FROM notification_email_sent INNER JOIN notification_email ON (notification_email_sent.notification_email_id = notification_email.id) "
            + " WHERE notification_email.status = 'RUNNING' GROUP BY notification_email_sent.notification_email_id ) AS tmp "
            + " ON (notification_email_sent.notification_email_id = tmp.notification_email_id AND notification_email_sent.sent_at = tmp.sent_at) ", nativeQuery = true)
    List<NotificationEmailSent> findAllLast();
}