package com.capgemini.admin.back.model.procedure;

public interface EntityFieldIndexDTO {
    String getLnEntity();

    String getLnField();

    Long getLnIndex();
}