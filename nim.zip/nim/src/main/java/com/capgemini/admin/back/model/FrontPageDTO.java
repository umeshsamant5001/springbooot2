package com.capgemini.admin.back.model;

import lombok.Data;
import java.util.List;

@Data
public class FrontPageDTO {
	private Long id;
	private String title;
	private String path;
	private String icon;
	private String htmlclass;
	private Boolean isExternalLink;
	private Integer index;
	private Long parentId;
	private Integer isheadermenu;
	private List<EnumAccess> access;
}
