package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class EmailContentDTO {
    private String email;
    private String roleName;
    private Long cdmKeyId;
    private String level;
    private Long roleId;
    private Long userId;
    private Long countryId;
    private String countryName;
    private Long cityId;
    private String cityName;
    private Long sitId;
    private String siteName;
    private Long buildingId;
    private String buildingName;
}