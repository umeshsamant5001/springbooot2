package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.capgemini.admin.back.model.FrontPage;
import com.capgemini.admin.back.model.FrontPageDTO;

@Mapper(config = DtoMapperConfig.class)
public interface FrontPageMapper {

    FrontPageMapper INSTANCE = Mappers.getMapper(FrontPageMapper.class);

    FrontPageDTO frontPageToFrontPageDTO(FrontPage in);

    FrontPage frontPageDTOToFrontPage(FrontPageDTO in);

}