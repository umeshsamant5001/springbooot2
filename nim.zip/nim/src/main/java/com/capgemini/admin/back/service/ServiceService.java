package com.capgemini.admin.back.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;


import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.admin.back.model.Service;
import com.capgemini.admin.back.model.ServiceLocation;
import com.capgemini.admin.back.model.ServiceTranslation;
import com.capgemini.admin.back.repository.BuildingRepository;
import com.capgemini.admin.back.repository.CityRepository;
import com.capgemini.admin.back.repository.CountryRepository;
import com.capgemini.admin.back.repository.ServiceRepository;
import com.capgemini.admin.back.repository.SiteRepository;

@org.springframework.stereotype.Service
public class ServiceService {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";


    @Autowired
    private ServiceRepository serviceRepository;
    @Autowired
    private CountryRepository countryRepository;
    @Autowired
    private CityRepository cityRepository;
    @Autowired
    private SiteRepository siteRepository;
    @Autowired
    private BuildingRepository buildingRepository;

    /**
     * Retrieves all available services from the repository.
     *
     * @return A list of all Service entities.
     */
    public List<Service> findAll() {
        return this.serviceRepository.findAll();
    }

    /**
     * Finds a service by its unique ID.
     *
     * @param id The ID of the service.
     * @return The Service entity if found, otherwise null.
     */
    public Service findById(Long id) {
        return this.serviceRepository.findById(id).orElse(null);
    }

    /**
     * Finds a service by its name.
     *
     * @param name The name of the service.
     * @return The Service entity if found, otherwise null.
    */
    public Service findByName(String name) {
        return this.serviceRepository.findByName(name).orElse(null);
    }

    public Service save(Service service) {
        Service sanitizedService = this.toSanitizedServiceForSave(service);
        return this.serviceRepository.save(sanitizedService);
    }


    private Service toSanitizedServiceForSave(Service service) {
        Service sanitizedService = new Service();

        Long safeId = service.getId() == null ? null : Long.valueOf(service.getId());
        String safeName = validateAndSanitizeText(service.getName(), 255, "name");
        String safeImage = validateAndSanitizeText(service.getImage(), 255, "image");
        Integer safePriority = service.getPriority() == null ? null : Integer.valueOf(service.getPriority());
        Map<String, String> safeAttributes = this.sanitizeAttributes(service.getAttributes());

        sanitizedService.setId(safeId == null ? null : Long.valueOf(safeId));
        sanitizedService.setName(safeName == null ? null : new String(safeName));
        sanitizedService.setImage(safeImage == null ? null : new String(safeImage));
        sanitizedService.setPriority(safePriority == null ? null : Integer.valueOf(safePriority));
        sanitizedService.setAttributes(new HashMap<String, String>(safeAttributes));

        List<ServiceLocation> sanitizedLocations = new ArrayList<>();
        if (service.getLocations() != null) {
            for (ServiceLocation location : service.getLocations()) {
                if (location == null) {
                    continue;
                }
                ServiceLocation sanitizedLocation = new ServiceLocation();
                Long safeLocationId = location.getId() == null ? null : Long.valueOf(location.getId());
                com.capgemini.admin.back.model.LevelEnum safeLevel = location.getLevel() == null
                        ? null
                        : com.capgemini.admin.back.model.LevelEnum.valueOf(String.valueOf(location.getLevel().name()));
                Long safeCdmKeyId = location.getCdmKeyId() == null ? null : Long.valueOf(location.getCdmKeyId());
                String safeStatus = validateAndSanitizeText(location.getStatus(), 255, "status");

                sanitizedLocation.setId(safeLocationId == null ? null : Long.valueOf(safeLocationId));
                sanitizedLocation.setLevel(safeLevel == null
                        ? null
                        : com.capgemini.admin.back.model.LevelEnum.valueOf(String.valueOf(safeLevel.name())));
                sanitizedLocation.setCdmKeyId(safeCdmKeyId == null ? null : Long.valueOf(safeCdmKeyId));
                sanitizedLocation.setStatus(safeStatus == null ? null : new String(safeStatus));
                sanitizedLocation.setService(sanitizedService);
                sanitizedLocations.add(sanitizedLocation);
            }
        }
        sanitizedService.setLocations(sanitizedLocations);

        List<ServiceTranslation> sanitizedTranslations = new ArrayList<>();
        if (service.getTranslations() != null) {
            for (ServiceTranslation translation : service.getTranslations()) {
                if (translation == null) {
                    continue;
                }
                ServiceTranslation sanitizedTranslation = new ServiceTranslation();
                Long safeTranslationId = translation.getId() == null ? null : Long.valueOf(translation.getId());
                String safeKey = validateAndSanitizeText(translation.getKey(), 255, "key");
                String safeValue = validateAndSanitizeText(translation.getValue(), 10000, "value");
                String safeLocale = validateAndSanitizeText(translation.getLocale(), 255, "locale");

                sanitizedTranslation.setId(safeTranslationId == null ? null : Long.valueOf(safeTranslationId));
                sanitizedTranslation.setKey(safeKey == null ? null : new String(safeKey));
                sanitizedTranslation.setValue(safeValue == null ? null : new String(safeValue));
                sanitizedTranslation.setLocale(safeLocale == null ? null : new String(safeLocale));
                sanitizedTranslation.setService(sanitizedService);
                sanitizedTranslations.add(sanitizedTranslation);
            }
        }
        sanitizedService.setTranslations(sanitizedTranslations);

        return sanitizedService;
    }



    private Map<String, String> sanitizeAttributes(Map<String, String> attributes) {
        Map<String, String> sanitized = new HashMap<String, String>();

        if (attributes == null) {
            return sanitized;
        }

        attributes.forEach((key, value) -> {
            if (Objects.nonNull(key) && Objects.nonNull(value)) {
                String safeKey = new String(String.valueOf(key).trim());
                String safeValue = new String(String.valueOf(value).trim());
                if (safeKey.length() <= 255 && safeValue.length() <= 1000
                        && safeKey.matches(SAFE_TEXT_REGEX) && safeValue.matches(SAFE_TEXT_REGEX)) {
                    sanitized.put(safeKey, safeValue);
                }
            }
        });

        return sanitized;
    }

    private String validateAndSanitizeText(String value, int maxLength, String fieldName) {
        if (Objects.isNull(value)) {
            return null;
        }

        String validated = new String(String.valueOf(value).trim());
        if (validated.length() > maxLength || !Pattern.matches(SAFE_TEXT_REGEX, validated)) {
            throw new IllegalArgumentException("Invalid " + fieldName + ".");
        }

        return new String(validated);

    }

    /**
     * Validates the locations associated with a service.
     * Ensures that each location's CDM key ID exists in the corresponding repository.
     *
     * @param service The Service entity containing locations to validate.
     * @return true if all locations are valid, false otherwise.
     */
    public Boolean checkServiceLocation(Service service) {

        for (ServiceLocation serviceLocation : service.getLocations()) {
            serviceLocation.setService(service);
            switch (serviceLocation.getLevel()) {
                case COUNTRY:
                    if (Objects.isNull(this.countryRepository.findByCdmKeyId(serviceLocation.getCdmKeyId()))) {
                        return false;
                    }
                    break;
                case CITY:
                    if (Objects.isNull(this.cityRepository.findByCdmKeyId(serviceLocation.getCdmKeyId()))) {
                        return false;
                    }
                    break;
                case SITE:
                    if (Objects.isNull(this.siteRepository.findByCdmKeyId(serviceLocation.getCdmKeyId()))) {
                        return false;
                    }
                    break;
                case BUILDING:
                    if (Objects.isNull(this.buildingRepository.findByCdmKeyId(serviceLocation.getCdmKeyId()))) {
                        return false;
                    }
                    break;
                default:
                    break;

            }
        }
        return true;
    }

    /**
     * Associates each translation with its parent service.
     *
     * @param service The Service entity containing translations.
     */
    public void setServiceTranslation(Service service) {
        for (ServiceTranslation serviceTranslation : service.getTranslations()) {
            serviceTranslation.setService(service);
        }
    }

    /**
     * Deletes a Service entity from the repository.
     *
     * @param service The Service entity to delete.
     */
    public void delete(Service service) {
        this.serviceRepository.delete(service);
    }
}
