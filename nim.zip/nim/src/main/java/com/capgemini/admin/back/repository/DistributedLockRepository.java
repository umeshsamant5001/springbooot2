package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.admin.back.model.DistributedLock;

public interface DistributedLockRepository extends JpaRepository<DistributedLock, String> {

    // Query to find a lock by its name
    @Query("SELECT dl FROM DistributedLock dl WHERE dl.lockName = :lockName")
    DistributedLock findByLockName(@Param("lockName") String lockName);

    // Query to check if a lock exists by its name
    @Query("SELECT COUNT(dl) FROM DistributedLock dl WHERE dl.lockName = :lockName")
    Long countByLockName(@Param("lockName") String lockName);

    // Query to delete a lock by its name
    @Query("DELETE FROM DistributedLock dl WHERE dl.lockName = :lockName")
    void deleteByLockName(@Param("lockName") String lockName);
}
