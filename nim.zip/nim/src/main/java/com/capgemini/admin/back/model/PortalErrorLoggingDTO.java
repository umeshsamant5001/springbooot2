package com.capgemini.admin.back.model;
import lombok.Data;

@Data
public class PortalErrorLoggingDTO {
    private Long id;
    private String className;
    private String module;
    private Long lineNumber;
    private String description;
    private String state;
    private String errorType;
    private String data;
    private Long createdDate;
    private Long loggingDate;
    private String errorLoggingType;
    private String userEmail;
    private String httpMethod;
    private String requestUrl;
    private String requestPayload;
    private Long responseStatus;
    private String responseBody;
    private String stackTrace;
    private String browserInfo;
    private String applicationPortal;
}