package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.mapper.EquipmentMapper;
import com.capgemini.admin.back.model.Equipment;
import com.capgemini.admin.back.model.EquipmentDTO;

import com.capgemini.admin.back.service.EquipmentService;


import com.capgemini.admin.back.service.PoiService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;




@RestController
@Validated
@RequestMapping(value = EquipmentController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class EquipmentController {


    public static final String ROOT_API = "api/equipment";
    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    private static class EquipmentWriteRequest {
        @NotBlank
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String name;

        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;

        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getTitleEn() {
            return this.titleEn;
        }

        public void setTitleEn(String titleEn) {
            this.titleEn = titleEn;
        }

        public String getTitleFr() {
            return this.titleFr;
        }

        public void setTitleFr(String titleFr) {
            this.titleFr = titleFr;
        }

    }

    private static final class SafeEquipmentInput {
        private final String name;
        private final String titleEn;
        private final String titleFr;

        private SafeEquipmentInput(String name, String titleEn, String titleFr) {
            this.name = name == null ? null : new String(String.valueOf(name));
            this.titleEn = titleEn == null ? null : new String(String.valueOf(titleEn));
            this.titleFr = titleFr == null ? null : new String(String.valueOf(titleFr));
        }

        private String getName() {
            return this.name == null ? null : new String(String.valueOf(this.name));
        }

        private String getTitleEn() {
            return this.titleEn == null ? null : new String(String.valueOf(this.titleEn));
        }

        private String getTitleFr() {
            return this.titleFr == null ? null : new String(String.valueOf(this.titleFr));
        }
    }

    @Autowired
    private EquipmentService equipmentService;

    @Autowired
    private PoiService poiService;

    /**
     * Get Equipment
     *
     * @param language : language of Equipment
     * @return list of poi types
     *
     */
    @GetMapping
    public ResponseEntity<List<EquipmentDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        List<Equipment> equipments = this.equipmentService.getOrderedEquipments();
        if (Objects.isNull(equipments)) {
            return ResponseEntity.internalServerError().build();
        }

        Map<Long, Long> mapCountByEquipment = this.poiService.countByEquipment();

        List<EquipmentDTO> equipmentDTOs = equipments
                .stream()
                .map(equipment -> EquipmentMapper.INSTANCE.equipmentToEquipmentDTO(equipment, language))
                .peek(equipementDTO -> {
                    equipementDTO.setPoisCount(mapCountByEquipment.getOrDefault(equipementDTO.getId(), 0L));
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(equipmentDTOs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EquipmentDTO> getById(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable Long id) {

        Equipment equipment = this.equipmentService.getEquipmentById(id);
        if (Objects.isNull(equipment)) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(EquipmentMapper.INSTANCE.equipmentToEquipmentDTO(equipment, language));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EquipmentDTO> update(
            @Valid @RequestBody EquipmentWriteRequest newEquipment,
            @PathVariable Long id,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        Equipment equipment = this.equipmentService.getEquipmentById(id);
        if (Objects.isNull(equipment)) {
            return ResponseEntity.notFound().build();
        }

        SafeEquipmentInput safeEquipmentInput = this.toSafeEquipmentInput(newEquipment);
        if (Objects.isNull(safeEquipmentInput)) {
            return ResponseEntity.badRequest().build();
        }

        Equipment updateEquipment = this.equipmentService.updateEquipment(
                Long.valueOf(String.valueOf(equipment.getId())),
                safeEquipmentInput.getName() == null ? null : new String(String.valueOf(safeEquipmentInput.getName())),
                safeEquipmentInput.getTitleEn() == null ? null : new String(String.valueOf(safeEquipmentInput.getTitleEn())),
                safeEquipmentInput.getTitleFr() == null ? null : new String(String.valueOf(safeEquipmentInput.getTitleFr())));

        if (Objects.isNull(updateEquipment)) {
            return ResponseEntity.internalServerError().build();
        }

        return ResponseEntity.ok(EquipmentMapper.INSTANCE.equipmentToEquipmentDTO(updateEquipment, language));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        Equipment equipment = this.equipmentService.getEquipmentById(id);
        if (Objects.isNull(equipment)) {
            return ResponseEntity.notFound().build();
        }

        this.equipmentService.deleteEquipmentById(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Object> create(
            @Valid @RequestBody EquipmentWriteRequest newEquipment,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        SafeEquipmentInput safeEquipmentInput = this.toSafeEquipmentInput(newEquipment);
        if (Objects.isNull(safeEquipmentInput)) {
            return ResponseEntity.badRequest().build();
        }

        Equipment existingEquipment = this.equipmentService.getByName(
                safeEquipmentInput.getName() == null ? null : new String(String.valueOf(safeEquipmentInput.getName())));

        if (Objects.nonNull(existingEquipment)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Entity with same name already exists");
        }

        Equipment equipment = this.equipmentService.createEquipment(
                safeEquipmentInput.getName() == null ? null : new String(String.valueOf(safeEquipmentInput.getName())),
                safeEquipmentInput.getTitleEn() == null ? null : new String(String.valueOf(safeEquipmentInput.getTitleEn())),
                safeEquipmentInput.getTitleFr() == null ? null : new String(String.valueOf(safeEquipmentInput.getTitleFr())));

        if (Objects.isNull(equipment)) {
            return ResponseEntity.internalServerError().build();
        }


        return ResponseEntity.ok(EquipmentMapper.INSTANCE.equipmentToEquipmentDTO(equipment, language));
    }

    private SafeEquipmentInput toSafeEquipmentInput(EquipmentWriteRequest source) {
        if (Objects.isNull(source)) {
            return null;
        }

        try {
            String safeName = this.validateText(
                    source.getName() == null ? null : new String(String.valueOf(source.getName())),
                    255,
                    true);
            String safeTitleEn = this.validateText(
                    source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn())),
                    255,
                    false);
            String safeTitleFr = this.validateText(
                    source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr())),
                    255,
                    false);

            return new SafeEquipmentInput(
                    new String(String.valueOf(safeName)),
                    safeTitleEn == null ? null : new String(String.valueOf(safeTitleEn)),
                    safeTitleFr == null ? null : new String(String.valueOf(safeTitleFr)));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }


    private String validateText(String value, int maxLength, boolean required) {
        if (Objects.isNull(value)) {
            if (required) {
                throw new IllegalArgumentException("Required text input is missing");
            }
            return null;
        }

        String trimmed = new String(String.valueOf(value)).trim();
        if (trimmed.isEmpty()) {
            if (required) {
                throw new IllegalArgumentException("Required text input is blank");
            }
            return null;
        }

        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }

        return new String(trimmed);
    }

}
