package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SensorAppImport {
    private List<SensorAppImportDTO> sensorAppImportDTOs = new ArrayList<>();
    private List<String> errorsInFile = new ArrayList<>();

    public SensorAppImport() {
        this.sensorAppImportDTOs = new ArrayList<>();
        this.errorsInFile = new ArrayList<>();
    }

    public void addError(String error) {
        log.info("error SensorAppImportDTOResponse in dto >>> " + error);
        if (Objects.isNull(this.errorsInFile)) {
            this.errorsInFile = new ArrayList<>();
        }
        this.errorsInFile.add(error);
    }

    public void addSensorApp(SensorAppImportDTO sensorAppImportDTO) {
        this.sensorAppImportDTOs.add(sensorAppImportDTO);
    }
}
