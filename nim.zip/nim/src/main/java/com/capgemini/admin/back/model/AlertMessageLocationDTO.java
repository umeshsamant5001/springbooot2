package com.capgemini.admin.back.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class AlertMessageLocationDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;
    // private AlertMessageDTO alertMessageDTO; // not required
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long alertMessageId;

    private LevelEnum level;
    private Long cdmKeyId;
    private String status;
    private Long countryId;
    private String countryName;
}
