package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "notificationSent", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class NotificationSent implements ScheduledSent {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NotificationSent_Generator")
    @SequenceGenerator(name = "Notification_Sent_Generator", sequenceName = "Notification_Sent_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notification_id")
    private Notification notification;

    @Column(name = "notification_id", updatable = false, insertable = false)
    private Long notificationId;

    @Column(name = "sent_at")
    private Long sentAt;

    public void setScheduled(Scheduled scheduled) {
        this.setNotification((Notification) scheduled);
    }

    public Long getScheduledId() {
        return this.getNotificationId();
    }
}