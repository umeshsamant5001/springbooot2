/**
 * Spring MVC REST controllers.
 */
package com.capgemini.admin.back.web.rest;
