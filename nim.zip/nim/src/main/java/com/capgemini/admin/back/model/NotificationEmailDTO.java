package com.capgemini.admin.back.model;

import java.util.Map;

import lombok.Data;

@Data
public class NotificationEmailDTO {
    private Long id;
    private String title;
    private String message;
    private String messageType;
    private EnumPriorityType priorityType;
    private Long startDate;
    private Long endDate;
    private Long lastChange;
    private EnumStatusScheduled status;
    private Map<String, String> attributes;
}