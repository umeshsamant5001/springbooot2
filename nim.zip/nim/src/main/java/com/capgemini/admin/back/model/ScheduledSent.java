package com.capgemini.admin.back.model;

public interface ScheduledSent {
    public void setScheduled(Scheduled scheduled);

    public Long getSentAt();

    public void setSentAt(Long sentAt);

    public Long getScheduledId();
}
