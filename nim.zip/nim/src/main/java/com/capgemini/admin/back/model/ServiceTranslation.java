package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Table(name = "service_translation")
@Entity
@Data
@EqualsAndHashCode
public class ServiceTranslation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ServiceTranslation_Generator")
    @SequenceGenerator(name = "ServiceTranslation_Generator", sequenceName = "ServiceTranslation_Sequence")
    private Long id;

    @Column(name = "translation_key")
    public String key;

    @Column(name = "translation_value")
    public String value;

    @Column(name = "locale")
    public String locale;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "service_id")
    @JsonIgnore
    private Service service;

    @Column(name = "service_id", updatable = false, insertable = false)
    private Long serviceId;
}
