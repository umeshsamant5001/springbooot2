package com.capgemini.admin.back.model;

public enum TimeFormat {
    HOUR_12, HOUR_24;
}
