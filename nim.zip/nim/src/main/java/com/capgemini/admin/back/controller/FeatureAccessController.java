package com.capgemini.admin.back.controller;

import java.util.List;
import java.util.Objects;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.service.FeatureAccessService;
import com.capgemini.admin.back.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.admin.back.model.FeatureAccess;
import com.capgemini.admin.back.model.FeatureAccessDTO;

@RestController
@RequestMapping("api/feature")
public class FeatureAccessController {

    @Autowired
    private FeatureAccessService featureAccessService;

    @Autowired
    private RoleService roleService;

    /**
     * Retrieves a list of features based on the specified role ID.
     *
     * @param roleId The ID of the role for which features are requested.
     * @return ResponseEntity with a list of FeatureDTOs if successful, else
     *         appropriate error responses.
     */
    @GetMapping("/{roleId}")
    public ResponseEntity<List<FeatureAccessDTO>> getFeatureAccessesByRoleId(
            @PathVariable("roleId") Long roleId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Role role = this.roleService.getRoleById(roleId, false);
        if (Objects.isNull(role)) {
            return ResponseEntity.notFound().build();
        }

        List<FeatureAccess> featureAccesses = this.featureAccessService.getAllByRoleId(roleId);
        List<FeatureAccessDTO> featureAccessDTOs = this.featureAccessService
                .listFeatureAccessToFeatureAccessDTOList(featureAccesses, language);
        if (Objects.isNull(featureAccessDTOs)) {
            return ResponseEntity.internalServerError().build();
        }
        return ResponseEntity.ok(featureAccessDTOs);
    }

    /**
     * Retrieves a list of all features.
     *
     * @return ResponseEntity with a list of FeatureDTOs if successful, else
     *         appropriate error responses.
     */
    @GetMapping
    public ResponseEntity<List<FeatureAccessDTO>> getFeatureAccesses(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<FeatureAccess> featureAccesses = this.featureAccessService.getAll();
        List<FeatureAccessDTO> featureAccessDTOs = this.featureAccessService
                .listFeatureAccessToFeatureAccessDTOList(featureAccesses, language);
        if (Objects.isNull(featureAccessDTOs)) {
            return ResponseEntity.internalServerError().build();
        }
        return ResponseEntity.ok(featureAccessDTOs);
    }
}
