package com.capgemini.admin.back.service;

import java.util.Objects;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.admin.back.mapper.PortalErrorLoggingMapper;
import com.capgemini.admin.back.model.PortalErrorLogging;
import com.capgemini.admin.back.model.PortalErrorLoggingDTO;
import com.capgemini.admin.back.repository.PortalErrorLoggingRepository;


@Service
public class PortalErrorLoggingService {


    public static class PortalErrorLoggingUpsertInput {
        private final String className;
        private final String module;
        private final Long lineNumber;
        private final String description;
        private final String state;
        private final String errorType;
        private final String data;
        private final Long loggingDate;
        private final String errorLoggingType;
        private final String userEmail;
        private final String httpMethod;
        private final String requestUrl;
        private final String requestPayload;
        private final Long responseStatus;
        private final String responseBody;
        private final String stackTrace;
        private final String browserInfo;
        private final String applicationPortal;

        public PortalErrorLoggingUpsertInput(String className, String module, Long lineNumber,
                String description, String state, String errorType, String data, Long loggingDate,
                String errorLoggingType, String userEmail, String httpMethod, String requestUrl,
                String requestPayload, Long responseStatus, String responseBody, String stackTrace,
                String browserInfo, String applicationPortal) {
            this.className = className == null ? null : new String(String.valueOf(className));
            this.module = module == null ? null : new String(String.valueOf(module));
            this.lineNumber = lineNumber == null ? null : Long.valueOf(String.valueOf(lineNumber));
            this.description = description == null ? null : new String(String.valueOf(description));
            this.state = state == null ? null : new String(String.valueOf(state));
            this.errorType = errorType == null ? null : new String(String.valueOf(errorType));
            this.data = data == null ? null : new String(String.valueOf(data));
            this.loggingDate = loggingDate == null ? null : Long.valueOf(String.valueOf(loggingDate));
            this.errorLoggingType = errorLoggingType == null ? null : new String(String.valueOf(errorLoggingType));
            this.userEmail = userEmail == null ? null : new String(String.valueOf(userEmail));
            this.httpMethod = httpMethod == null ? null : new String(String.valueOf(httpMethod));
            this.requestUrl = requestUrl == null ? null : new String(String.valueOf(requestUrl));
            this.requestPayload = requestPayload == null ? null : new String(String.valueOf(requestPayload));
            this.responseStatus = responseStatus == null ? null : Long.valueOf(String.valueOf(responseStatus));
            this.responseBody = responseBody == null ? null : new String(String.valueOf(responseBody));
            this.stackTrace = stackTrace == null ? null : new String(String.valueOf(stackTrace));
            this.browserInfo = browserInfo == null ? null : new String(String.valueOf(browserInfo));
            this.applicationPortal = applicationPortal == null ? null : new String(String.valueOf(applicationPortal));
        }

        public String getClassName() {
            return className == null ? null : new String(String.valueOf(className));
        }

        public String getModule() {
            return module == null ? null : new String(String.valueOf(module));
        }

        public Long getLineNumber() {
            return lineNumber == null ? null : Long.valueOf(String.valueOf(lineNumber));
        }

        public String getDescription() {
            return description == null ? null : new String(String.valueOf(description));
        }

        public String getState() {
            return state == null ? null : new String(String.valueOf(state));
        }

        public String getErrorType() {
            return errorType == null ? null : new String(String.valueOf(errorType));
        }

        public String getData() {
            return data == null ? null : new String(String.valueOf(data));
        }

        public Long getLoggingDate() {
            return loggingDate == null ? null : Long.valueOf(String.valueOf(loggingDate));
        }

        public String getErrorLoggingType() {
            return errorLoggingType == null ? null : new String(String.valueOf(errorLoggingType));
        }

        public String getUserEmail() {
            return userEmail == null ? null : new String(String.valueOf(userEmail));
        }

        public String getHttpMethod() {
            return httpMethod == null ? null : new String(String.valueOf(httpMethod));
        }

        public String getRequestUrl() {
            return requestUrl == null ? null : new String(String.valueOf(requestUrl));
        }

        public String getRequestPayload() {
            return requestPayload == null ? null : new String(String.valueOf(requestPayload));
        }

        public Long getResponseStatus() {
            return responseStatus == null ? null : Long.valueOf(String.valueOf(responseStatus));
        }

        public String getResponseBody() {
            return responseBody == null ? null : new String(String.valueOf(responseBody));
        }

        public String getStackTrace() {
            return stackTrace == null ? null : new String(String.valueOf(stackTrace));
        }

        public String getBrowserInfo() {
            return browserInfo == null ? null : new String(String.valueOf(browserInfo));
        }

        public String getApplicationPortal() {
            return applicationPortal == null ? null : new String(String.valueOf(applicationPortal));
        }
    }

    private final PortalErrorLoggingRepository portalErrorLoggingRepository;


    public PortalErrorLoggingService(PortalErrorLoggingRepository portalErrorLoggingRepository) {
        this.portalErrorLoggingRepository = portalErrorLoggingRepository;
    }


    @Transactional
    public PortalErrorLoggingDTO createPortalErrorLogging(PortalErrorLoggingUpsertInput portalErrorLoggingInput) {

        PortalErrorLoggingUpsertInput scopedPortalErrorLoggingInput = sanitizePortalErrorLoggingUpsertInput(portalErrorLoggingInput);
        PortalErrorLogging entity = sanitizeForPersistence(scopedPortalErrorLoggingInput);
        PortalErrorLogging savedEntity = portalErrorLoggingRepository.save(entity);

        return PortalErrorLoggingMapper.INSTANCE.portalErrorLoggingToDTO(savedEntity);
    }

    private PortalErrorLogging sanitizeForPersistence(PortalErrorLoggingUpsertInput portalErrorLoggingInput) {


        PortalErrorLogging sanitizedEntity = new PortalErrorLogging();
        sanitizedEntity.setId(null);
        String validatedClassName = validateAndSanitizeText(portalErrorLoggingInput.getClassName(), 255, "className");
        String validatedModule = validateAndSanitizeText(portalErrorLoggingInput.getModule(), 255, "module");
        Long validatedLineNumber = portalErrorLoggingInput.getLineNumber() == null
                ? null
                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getLineNumber()));
        String validatedDescription = validateAndSanitizeText(portalErrorLoggingInput.getDescription(), 10000, "description");
        String validatedState = validateAndSanitizeText(portalErrorLoggingInput.getState(), 255, "state");
        String validatedErrorType = validateAndSanitizeText(portalErrorLoggingInput.getErrorType(), 255, "errorType");
        String validatedData = validateAndSanitizeText(portalErrorLoggingInput.getData(), 10000, "data");
        Long validatedLoggingDate = portalErrorLoggingInput.getLoggingDate() == null
                ? null
                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getLoggingDate()));
        String validatedErrorLoggingType = validateAndSanitizeText(portalErrorLoggingInput.getErrorLoggingType(), 255, "errorLoggingType");
        String validatedUserEmail = validateAndSanitizeText(portalErrorLoggingInput.getUserEmail(), 255, "userEmail");
        String validatedHttpMethod = validateAndSanitizeText(portalErrorLoggingInput.getHttpMethod(), 255, "httpMethod");
        String validatedRequestUrl = validateAndSanitizeText(portalErrorLoggingInput.getRequestUrl(), 2048, "requestUrl");
        String validatedRequestPayload = validateAndSanitizeText(portalErrorLoggingInput.getRequestPayload(), 10000, "requestPayload");
        Long validatedResponseStatus = portalErrorLoggingInput.getResponseStatus() == null
                ? null
                : Long.valueOf(String.valueOf(portalErrorLoggingInput.getResponseStatus()));
        String validatedResponseBody = validateAndSanitizeText(portalErrorLoggingInput.getResponseBody(), 10000, "responseBody");
        String validatedStackTrace = validateAndSanitizeText(portalErrorLoggingInput.getStackTrace(), 10000, "stackTrace");
        String validatedBrowserInfo = validateAndSanitizeText(portalErrorLoggingInput.getBrowserInfo(), 10000, "browserInfo");
        String validatedApplicationPortal = validateAndSanitizeText(portalErrorLoggingInput.getApplicationPortal(), 255, "applicationPortal");


        sanitizedEntity.setClassName(validatedClassName == null ? null : new String(validatedClassName));
        sanitizedEntity.setModule(validatedModule == null ? null : new String(validatedModule));
        sanitizedEntity.setLineNumber(validatedLineNumber == null ? null : Long.valueOf(String.valueOf(validatedLineNumber)));
        sanitizedEntity.setDescription(validatedDescription == null ? null : new String(validatedDescription));
        sanitizedEntity.setState(validatedState == null ? null : new String(validatedState));
        sanitizedEntity.setErrorType(validatedErrorType == null ? null : new String(validatedErrorType));
        sanitizedEntity.setData(validatedData == null ? null : new String(validatedData));
        sanitizedEntity.setLoggingDate(validatedLoggingDate == null ? null : Long.valueOf(String.valueOf(validatedLoggingDate)));
        sanitizedEntity.setErrorLoggingType(validatedErrorLoggingType == null ? null : new String(validatedErrorLoggingType));
        sanitizedEntity.setUserEmail(validatedUserEmail == null ? null : new String(validatedUserEmail));
        sanitizedEntity.setHttpMethod(validatedHttpMethod == null ? null : new String(validatedHttpMethod));
        sanitizedEntity.setRequestUrl(validatedRequestUrl == null ? null : new String(validatedRequestUrl));
        sanitizedEntity.setRequestPayload(validatedRequestPayload == null ? null : new String(validatedRequestPayload));
        sanitizedEntity.setResponseStatus(validatedResponseStatus == null ? null : Long.valueOf(String.valueOf(validatedResponseStatus)));
        sanitizedEntity.setResponseBody(validatedResponseBody == null ? null : new String(validatedResponseBody));
        sanitizedEntity.setStackTrace(validatedStackTrace == null ? null : new String(validatedStackTrace));
        sanitizedEntity.setBrowserInfo(validatedBrowserInfo == null ? null : new String(validatedBrowserInfo));
        sanitizedEntity.setApplicationPortal(validatedApplicationPortal == null ? null : new String(validatedApplicationPortal));
        sanitizedEntity.setCreatedDate(null);
        return sanitizedEntity;
    }


    private PortalErrorLoggingUpsertInput sanitizePortalErrorLoggingUpsertInput(PortalErrorLoggingUpsertInput source) {
        if (source == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid portal error logging payload.");
        }

        String safeClassName = source.getClassName() == null ? null : new String(String.valueOf(source.getClassName()));
        String safeModule = source.getModule() == null ? null : new String(String.valueOf(source.getModule()));
        Long safeLineNumber = source.getLineNumber() == null ? null : Long.valueOf(String.valueOf(source.getLineNumber()));
        String safeDescription = source.getDescription() == null ? null : new String(String.valueOf(source.getDescription()));
        String safeState = source.getState() == null ? null : new String(String.valueOf(source.getState()));
        String safeErrorType = source.getErrorType() == null ? null : new String(String.valueOf(source.getErrorType()));
        String safeData = source.getData() == null ? null : new String(String.valueOf(source.getData()));
        Long safeLoggingDate = source.getLoggingDate() == null ? null : Long.valueOf(String.valueOf(source.getLoggingDate()));
        String safeErrorLoggingType = source.getErrorLoggingType() == null ? null : new String(String.valueOf(source.getErrorLoggingType()));
        String safeUserEmail = source.getUserEmail() == null ? null : new String(String.valueOf(source.getUserEmail()));
        String safeHttpMethod = source.getHttpMethod() == null ? null : new String(String.valueOf(source.getHttpMethod()));
        String safeRequestUrl = source.getRequestUrl() == null ? null : new String(String.valueOf(source.getRequestUrl()));
        String safeRequestPayload = source.getRequestPayload() == null ? null : new String(String.valueOf(source.getRequestPayload()));
        Long safeResponseStatus = source.getResponseStatus() == null ? null : Long.valueOf(String.valueOf(source.getResponseStatus()));
        String safeResponseBody = source.getResponseBody() == null ? null : new String(String.valueOf(source.getResponseBody()));
        String safeStackTrace = source.getStackTrace() == null ? null : new String(String.valueOf(source.getStackTrace()));
        String safeBrowserInfo = source.getBrowserInfo() == null ? null : new String(String.valueOf(source.getBrowserInfo()));
        String safeApplicationPortal = source.getApplicationPortal() == null ? null : new String(String.valueOf(source.getApplicationPortal()));

        return new PortalErrorLoggingUpsertInput(safeClassName, safeModule, safeLineNumber,
                safeDescription, safeState, safeErrorType, safeData, safeLoggingDate,
                safeErrorLoggingType, safeUserEmail, safeHttpMethod, safeRequestUrl,
                safeRequestPayload, safeResponseStatus, safeResponseBody, safeStackTrace,
                safeBrowserInfo, safeApplicationPortal);
    }

    private String validateAndSanitizeText(String value, int maxLength, String fieldName) {

        if (Objects.isNull(value)) {
            return null;
        }
        String validated = value.trim();
        if (validated.length() > maxLength || containsUnsafeControlChars(validated)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid " + fieldName + " value.");
        }
        return new String(validated);
    }

    private boolean containsUnsafeControlChars(String value) {
        for (char currentChar : value.toCharArray()) {
            if (Character.isISOControl(currentChar)
                    && currentChar != '\n'
                    && currentChar != '\r'
                    && currentChar != '\t') {
                return true;
            }
        }
        return false;
    }

}