package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ThresholdConfigurationDTO {
    private Long id;
    private Long countryId;
    private Long spaceTypeId;
    private TemperatureUnit temperatureUnit;
    private List<ThresholdDTO> thresholds = new ArrayList<>();
    private List<AlertDTO> alerts = new ArrayList<>();
}
