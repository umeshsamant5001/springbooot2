package com.capgemini.admin.back.service;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.capgemini.admin.back.mapper.AuditLoggingMapper;
import com.capgemini.admin.back.model.AuditLogging;
import com.capgemini.admin.back.model.AuditLoggingDTO;
import com.capgemini.admin.back.model.EnumAuditType;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.repository.AuditLoggingRepository;
import com.capgemini.admin.back.repository.UserRepository;
import com.capgemini.admin.back.security.jwt.model.UserInformation;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class AuditLoggingService {

	private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

	public static class AuditLoggingUpsertInput {
		private final String moduleName;
		private final String activity;
		private final String previousData;
		private final String currentData;
		private final Long activityDate;
		private final String platform;
		private final EnumAuditType auditType;

		public AuditLoggingUpsertInput(String moduleName, String activity, String previousData, String currentData,
				Long activityDate, String platform, EnumAuditType auditType) {
			this.moduleName = moduleName == null ? null : new String(String.valueOf(moduleName));
			this.activity = activity == null ? null : new String(String.valueOf(activity));
			this.previousData = previousData == null ? null : new String(String.valueOf(previousData));
			this.currentData = currentData == null ? null : new String(String.valueOf(currentData));
			this.activityDate = activityDate == null ? null : Long.valueOf(String.valueOf(activityDate));
			this.platform = platform == null ? null : new String(String.valueOf(platform));
			this.auditType = auditType == null
					? null
					: EnumAuditType.valueOf(String.valueOf(auditType.name()));
		}

		public String getModuleName() {
			return moduleName == null ? null : new String(String.valueOf(moduleName));
		}

		public String getActivity() {
			return activity == null ? null : new String(String.valueOf(activity));
		}

		public String getPreviousData() {
			return previousData == null ? null : new String(String.valueOf(previousData));
		}

		public String getCurrentData() {
			return currentData == null ? null : new String(String.valueOf(currentData));
		}

		public Long getActivityDate() {
			return activityDate == null ? null : Long.valueOf(String.valueOf(activityDate));
		}

		public String getPlatform() {
			return platform == null ? null : new String(String.valueOf(platform));
		}

		public EnumAuditType getAuditType() {
			return auditType == null
					? null
					: EnumAuditType.valueOf(String.valueOf(auditType.name()));
		}
	}

	@Autowired

	private AuditLoggingRepository auditloggingRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserInformationService userInformationService;


	/**
     * Persists a new AuditLogging entity to the database.
     *
     * @return the saved AuditLogging entity, or null if an exception occurs
     */
	public AuditLogging createAuditLogging(AuditLoggingUpsertInput auditLoggingInput) {
		if (Objects.isNull(auditLoggingInput)) {
			return null;
		}

		AuditLogging save = null;
		try {
			AuditLoggingUpsertInput scopedAuditLoggingInput = sanitizeAuditLoggingUpsertInput(auditLoggingInput);
			AuditLogging sanitizedAuditLogging = sanitizeForPersistence(scopedAuditLoggingInput);
			save = auditloggingRepository.save(sanitizedAuditLogging);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return save;
	}

	private AuditLogging sanitizeForPersistence(AuditLoggingUpsertInput createInput) {

		User currentUser = getAuthenticatedActiveUser();

		AuditLogging sanitizedAuditLogging = new AuditLogging();
		sanitizedAuditLogging.setId(null);
		sanitizedAuditLogging.setUsername(currentUser.getEmail() == null
				? null
				: new String(currentUser.getEmail().trim()));
		sanitizedAuditLogging.setCountry(currentUser.getCountry() == null
				? null
				: new String(currentUser.getCountry().trim()));
		String validatedModuleName = validateAndSanitizeText(createInput.getModuleName(), 255, "moduleName");
		String validatedActivity = validateAndSanitizeText(createInput.getActivity(), 255, "activity");
		String validatedPreviousData = validateAndSanitizeText(createInput.getPreviousData(), 10000, "previousData");
		String validatedCurrentData = validateAndSanitizeText(createInput.getCurrentData(), 10000, "currentData");
		Long validatedActivityDate = createInput.getActivityDate() == null
				? null
				: Long.valueOf(createInput.getActivityDate());
		String validatedPlatform = validateAndSanitizeText(createInput.getPlatform(), 255, "platform");
		EnumAuditType validatedAuditType = createInput.getAuditType() == null
				? null
				: EnumAuditType.valueOf(String.valueOf(createInput.getAuditType().name()));


		sanitizedAuditLogging.setModuleName(validatedModuleName == null ? null : new String(validatedModuleName));
		sanitizedAuditLogging.setActivity(validatedActivity == null ? null : new String(validatedActivity));
		sanitizedAuditLogging.setPreviousData(validatedPreviousData == null ? null : new String(validatedPreviousData));
		sanitizedAuditLogging.setCurrentData(validatedCurrentData == null ? null : new String(validatedCurrentData));
		sanitizedAuditLogging.setActivityDate(validatedActivityDate == null
				? null
				: Long.valueOf(validatedActivityDate));
		sanitizedAuditLogging.setPlatform(validatedPlatform == null ? null : new String(validatedPlatform));
		sanitizedAuditLogging.setAuditType(validatedAuditType == null
				? null
				: EnumAuditType.valueOf(String.valueOf(validatedAuditType.name())));

		return sanitizedAuditLogging;
	}





	private AuditLoggingUpsertInput sanitizeAuditLoggingUpsertInput(AuditLoggingUpsertInput source) {
		if (source == null) {
			throw new IllegalArgumentException("Audit logging input must not be null");
		}

		String safeModuleName = source.getModuleName() == null ? null : new String(String.valueOf(source.getModuleName()));
		String safeActivity = source.getActivity() == null ? null : new String(String.valueOf(source.getActivity()));
		String safePreviousData = source.getPreviousData() == null ? null : new String(String.valueOf(source.getPreviousData()));
		String safeCurrentData = source.getCurrentData() == null ? null : new String(String.valueOf(source.getCurrentData()));
		Long safeActivityDate = source.getActivityDate() == null ? null : Long.valueOf(String.valueOf(source.getActivityDate()));
		String safePlatform = source.getPlatform() == null ? null : new String(String.valueOf(source.getPlatform()));
		EnumAuditType safeAuditType = source.getAuditType() == null
				? null
				: EnumAuditType.valueOf(String.valueOf(source.getAuditType().name()));

		return new AuditLoggingUpsertInput(
				safeModuleName,
				safeActivity,
				safePreviousData,
				safeCurrentData,
				safeActivityDate,
				safePlatform,
				safeAuditType);
	}

	private User getAuthenticatedActiveUser() {

		UserInformation userInformation;
		try {
			userInformation = userInformationService.getCurrent();
		} catch (Exception ex) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
		}

		if (Objects.isNull(userInformation) || Objects.isNull(userInformation.getEmail())) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
		}

		String authenticatedEmail = new String(userInformation.getEmail().trim());
		User authenticatedUser = userRepository.findActiveUserByEmail(authenticatedEmail);
		if (Objects.isNull(authenticatedUser)) {
			throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unauthorized user.");
		}
		return authenticatedUser;
	}

	private String validateAndSanitizeText(String value, int maxLength, String fieldName) {
		if (Objects.isNull(value)) {
			return null;
		}
		String trimmed = value.trim();
		if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {

			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid " + fieldName + " value.");
		}
		return new String(trimmed);
	}


  
    /**
    * Converts a list of AuditLogging entities to a list of AuditLoggingDTOs.
    *
    * @return a Function that maps List<AuditLogging> to List<AuditLoggingDTO>
    */
	public Function<List<AuditLogging>, List<AuditLoggingDTO>> auditloggingListToAuditLoggingDTOList() {
		return in -> in.stream().map(toAuditLoggingDTO()).collect(Collectors.toList());
	}
	
    /**
    * Provides a Function to convert a single AuditLogging entity to an AuditLoggingDTO.
    *
    * @return a Function that maps AuditLogging to AuditLoggingDTO
    */
	public Function<AuditLogging, AuditLoggingDTO> toAuditLoggingDTO() {
		return AuditLoggingMapper.INSTANCE::auditloggingToAuditLoggingDTO;
	}
	
    /**
    * Retrieves all AuditLogging records from the database.
    *
    * @return a list of all AuditLogging entities
    */
    public List<AuditLogging> getAll() {
        return auditloggingRepository.findAll();
    }
}