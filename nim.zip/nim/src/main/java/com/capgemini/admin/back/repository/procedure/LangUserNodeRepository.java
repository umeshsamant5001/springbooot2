package com.capgemini.admin.back.repository.procedure;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.procedure.LangUserNode;

@Repository
public interface LangUserNodeRepository extends JpaRepository<LangUserNode, Long> {

    @Procedure(name = "GetLangUserNodeMapping")
    List<LangUserNode> getLangUserNodeMapping();

}
