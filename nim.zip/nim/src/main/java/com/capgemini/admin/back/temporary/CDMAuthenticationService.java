package com.capgemini.admin.back.temporary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.capgemini.admin.back.config.ApplicationProperties;
import lombok.extern.slf4j.Slf4j;
import com.capgemini.admin.back.config.Constants;

/*
 * The service which manages the data obtained by authentication process
 *
 */
@Service
@Slf4j
public class CDMAuthenticationService {

	private static final String CDM_GRANT_TYPE = "client_credentials";

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private CDMRequestFactory factory;

	@Autowired
	private CDMResponseParser resParser;

	/**
	 * Get a CDM session for further api calls
	 *
	 * @return a Session object containing a sessionId and a token
	 */
	private Session authenticate() {
		Session session = new Session();
		Map<String, String> headers = new HashMap<>();

		headers.put(Constants.AUTHORIZATION_HEADER, this.applicationProperties.getCdm().getAuthorization());
		headers.put(Constants.COOKIE, this.applicationProperties.getCdm().getCookie());

		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair(CDM_GRANT_TYPE, Constants.AUTHORIZATION_HEADER));
		params.add(new BasicNameValuePair("client_id", this.applicationProperties.getCdm().getClientId()));
		params.add(new BasicNameValuePair("client_secret", this.applicationProperties.getCdm().getClientSecret()));
		params.add(new BasicNameValuePair("grant_type", CDM_GRANT_TYPE));

		session = factory.postFormUrlEncoded(this.applicationProperties.getCdm().getSsoUrl(), headers, params,
				resParser::readTokenRes);

		if (Objects.isNull(session.getToken()) || session.getToken().isEmpty()) {
			throw new CDMConnectorException("CDM authentication response - no token found");
		}
		log.info("cdm token {}", session.getToken());
		return session;
	}

	@Cacheable(value = "accessTokenCDM", key = "#root.method.name")
	public Map<String, String> getDefaultHeaders() {
		Map<String, String> headers = new HashMap<>();
		headers.put(Constants.AUTHORIZATION_HEADER, "Bearer " + this.authenticate().getToken());
		headers.put("cgAuth", this.applicationProperties.getCdm().getCgAuth());
		return headers;
	}

	@CacheEvict(allEntries = true, value = "accessTokenCDM")
	@Scheduled(fixedDelay = 3400 * 1000)
	public void cdmTokenCacheEvict() {
		log.info("Cdm token evicted");
	}
}
