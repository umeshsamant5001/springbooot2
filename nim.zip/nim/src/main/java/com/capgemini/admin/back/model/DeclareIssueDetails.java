package com.capgemini.admin.back.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "declare_issue_details")
public class DeclareIssueDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DeclareIssueDetails_Generator")
    @SequenceGenerator(name = "DeclareIssueDetails_Generator", sequenceName = "DeclareIssueDetails_Sequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "declare_issue_id")
    @JsonIgnore
    private DeclareIssue declareIssue;

    @Column(name = "declare_issue_id", updatable = false, insertable = false)
    private Long declareIssueId;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "country_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Country country;

    @Column(name = "country_id")
    private Long countryId;

    @Column(name = "email_id", length = 50)
    private String emailId;

    @Column(name = "modified_at", nullable = false)
    private Long modifiedAt = new Date().getTime() / 1000;

    @Column(name = "created_at", nullable = false)
    private Long createdAt = new Date().getTime() / 1000;

    // Add this method to get the declareIssueId without the separate column
    public Long getDeclareIssueId() {
        return declareIssue != null ? declareIssue.getId() : null;
    }
}