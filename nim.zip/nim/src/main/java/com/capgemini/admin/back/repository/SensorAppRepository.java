package com.capgemini.admin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.Device;

@Repository
public interface SensorAppRepository extends JpaRepository<Device, Long> {

    public Device findByUuid(@Param("uuid") String uuid);

}
