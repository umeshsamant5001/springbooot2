package com.capgemini.admin.back.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import com.capgemini.admin.back.config.Constants;
import javax.persistence.GenerationType;
import lombok.Data;

@Data
@Entity
@Table(name = "AppRegistrationManagement")
public class AppRegistrationManagement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "device_id")
    private String deviceId;

    @Enumerated(EnumType.STRING)
    @Column(name = "device_type")
    private EnumOsType deviceType;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "created_date_time", nullable = false, columnDefinition = Constants.BIGINT_DEFAULT_DEFINITION)
    private Long createdDateTime = (new Date()).getTime() / 1000;

    @Column(name = "updated_date_time", nullable = false, columnDefinition = Constants.BIGINT_DEFAULT_DEFINITION)
    private Long updatedDateTime = (new Date()).getTime() / 1000;

    @Column(name = "device_registration_token")
    private String deviceRegistrationToken;

}
