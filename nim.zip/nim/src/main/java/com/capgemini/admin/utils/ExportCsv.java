package com.capgemini.admin.utils;

import java.util.List;

public class ExportCsv {
    private String separator = ",";
    private String escape = "\"";


    public ExportCsv() {}

    public ExportCsv(String separator, String escape) {
        this.separator = separator;
        this.escape = escape;
    }

    public String export(List<List<String>> data) {

        StringBuilder builder = new StringBuilder();

        for (List<String> row : data) {
            for (String value : row) {
                builder.append(this.escapeValue(value));
                builder.append(this.separator);
            }

            // Remove the last separator
            builder.deleteCharAt(builder.length() - 1);
            builder.append("\n");
        }

        return builder.toString();
    }

  
    private String escapeValue(String value) {
        if (value == null)
            return "";
        // Wrap in quotes only if necessary
        String escapedValue = value.replace(escape, escape + escape);
        return (value.contains(separator) || value.contains(escape) || value.contains("\n"))
        ? escape + escapedValue + escape
        : escapedValue;
    }
}
