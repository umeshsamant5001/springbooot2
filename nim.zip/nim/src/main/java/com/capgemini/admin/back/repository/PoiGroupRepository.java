package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.PoiGroup;

@Repository
public interface PoiGroupRepository extends JpaRepository<PoiGroup, Long> {

	public Optional<PoiGroup> findByName(@Param("name") String name);

	public List<PoiGroup> findAllByOrderByNameAsc();

	@Query("SELECT p FROM PoiGroup p LEFT JOIN FETCH p.spaceTypes st WHERE p.id = :id")
	Optional<PoiGroup> findByIdWithSpaceTypes(@Param("id") Long id);

	@Query(value = "SELECT pg.name FROM poi_group as pg JOIN space_type as st ON pg.id = st.poi_group_id " +
			" WHERE st.id = :spaceTypeId ", nativeQuery = true)
	public Optional<String> findBySpaceTypeId(@Param("spaceTypeId") Long spaceTypeId);


	@Query(value = "SELECT pg.* FROM poi_group pg " +
			" WHERE pg.id = :poiGroupId " +
			" AND EXISTS (" +
			"   SELECT 1 FROM space_type st " +
			"   LEFT JOIN poi p ON p.space_type_id = st.id " +
			"   LEFT JOIN floor f ON f.id = p.floor_id " +
			"   LEFT JOIN building b ON b.id = f.building_id " +
			"   LEFT JOIN site s ON s.id = b.site_id " +
			"   LEFT JOIN city c ON c.id = s.city_id " +
			"   LEFT JOIN country co ON co.id = c.country_id " +
			"   WHERE st.poi_group_id = pg.id " +
			"   AND (co.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'COUNTRY' AND user_id = :userId) " +
			"   OR c.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'CITY' AND user_id = :userId) " +
			"   OR s.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'SITE' AND user_id = :userId) " +
			"   OR b.cdm_key_id in (SELECT cdm_key_id FROM user_role_location where level = 'BUILDING' AND user_id = :userId)))", nativeQuery = true)
	Optional<PoiGroup> findAuthorizedByIdForUser(@Param("poiGroupId") Long poiGroupId, @Param("userId") Long userId);


}
