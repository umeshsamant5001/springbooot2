package com.capgemini.admin.back.model;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.Data;

@Data
public class SensorAppImportDTO {
    private String uuid;
    @Enumerated(EnumType.STRING)
    private EnumDeviceType deviceType;
    private String poiName;
    private Long floorCdmKeyId;
}
