package com.capgemini.admin.back.temporary;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import io.jsonwebtoken.lang.Collections;

@Component
public class CDMRequestFactory {

	private static final Logger log = LoggerFactory.getLogger(CDMRequestFactory.class);

	private static final int DEFAULT_CONNECT_TIMEOUT = 180;// seconds
	private static final int DEFAULT_TIMEOUT = 180;// seconds
	private RequestConfig config;
	private CloseableHttpClient httpClient;

	@PostConstruct
	public void init() {
		config = RequestConfig.custom().setConnectTimeout(DEFAULT_CONNECT_TIMEOUT * 1000)
				.setSocketTimeout(DEFAULT_TIMEOUT * 1000).build();
		httpClient = HttpClientBuilder.create()
				.setDefaultRequestConfig(config).build();
	}

	/**
	 * POST api call with x-www-form-urlencoded query
	 *
	 * @param <T>
	 * @param endpoint
	 * @param headers
	 * @param queryParams
	 * @param urlEncodedParams
	 * @param responseParser
	 * @return
	 */
	public <T> T postFormUrlEncoded(String endpoint, Map<String, String> headers, List<NameValuePair> urlEncodedParams,
			Function<CloseableHttpResponse, T> responseParser) {
		try {
			URIBuilder builder = new URIBuilder(endpoint);

			HttpPost req = new HttpPost(builder.build());
			UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
			req.setEntity(urlEncoded);

			if (!CollectionUtils.isEmpty(headers)) {
				req.setHeaders(convertHeaders(headers));
			}
			return execute(req, responseParser);
		} catch (URISyntaxException | UnsupportedEncodingException e) {
			throw new CDMConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
		}
	}

	/**
	 * GET api call
	 *
	 * @param <T>
	 * @param endpoint
	 * @param headers
	 * @param queryParams
	 * @param responseParser the function to apply to read response
	 * @return T a custom object defined by function
	 */
	public <T> T get(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
			Function<CloseableHttpResponse, T> responseParser) {
		try {
			URIBuilder builder = new URIBuilder(endpoint);
			if (!CollectionUtils.isEmpty(queryParams)) {
				builder.setParameters(convertQueryParams(queryParams));
			}

			HttpGet req = new HttpGet(builder.build());

			if (!Collections.isEmpty(headers)) {
				req.setHeaders(convertHeaders(headers));
			}
			String safeRequestForLog = sanitizeForLog(req.toString());
			log.info("requete {}", safeRequestForLog);
			return execute(req, responseParser);

		} catch (URISyntaxException e) {
			log.error("ERROR", e);
			;
			throw new CDMConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
		}
	}

	/**
	 * Execute an http call and before closures, apply a function to manage response
	 *
	 * @param <T>
	 * @param req
	 * @param responseParserFunc the function to parse the HttpResponse
	 * @return an object defined by responseParserFunc
	 */
	private <T> T execute(HttpUriRequest req, Function<CloseableHttpResponse, T> responseParserFunc) {
		String safeUriForLog = sanitizeForLog(req.getURI().toString());
		log.info("executing req {}", safeUriForLog);
		try (CloseableHttpResponse res = httpClient.execute(req)) {

			return responseParserFunc.apply(res);
		} catch (IOException e) {
			String message = String.format("Impossible to access CDM API on endpoint:[%s], error:[%s]", req.getURI(),
					e.getMessage());
			String safeMessageForLog = sanitizeForLog(message);
			log.info("{}", safeMessageForLog);
			throw new CDMConnectorException(message);
		}

	}

	private String getUriBuilderErrorMessage(String endpoint, String message) {
		return String.format("Unable to build CDM URI - endpoint:[%s] - error:[%s]", endpoint, message);
	}

	private List<NameValuePair> convertQueryParams(final Map<String, String> mapParams) {
		return mapParams.entrySet().stream().map(e -> new BasicNameValuePair(e.getKey(), e.getValue()))
				.collect(Collectors.toList());
	}

	private String sanitizeForLog(String input) {
		if (input == null) {
			return "";
		}
		return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
	}


	private Header[] convertHeaders(final Map<String, String> mapHeaders) {
		return mapHeaders.entrySet().stream()
				.map(e -> new BasicHeader(e.getKey(), e.getValue()))
				.toArray(Header[]::new);
	}
}
