package com.capgemini.admin.back.model;

public enum ThresholdLevel {
    LOWEST, MEDIUM, HIGH, CRITICAL;
}
