package com.capgemini.admin.back.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.admin.back.model.NotificationSent;
import com.capgemini.admin.back.repository.NotificationSentRepository;

@Service
public class NotificationSentService {

    @Autowired
    private NotificationSentRepository notificationSentRepository;

    public List<NotificationSent> findAllLast() {
        return this.notificationSentRepository.findAllLast();
    }

    public NotificationSent save(NotificationSent notificationSent) {
        return this.notificationSentRepository.save(notificationSent);
    }
}