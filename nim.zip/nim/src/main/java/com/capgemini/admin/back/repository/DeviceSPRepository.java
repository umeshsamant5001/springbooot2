package com.capgemini.admin.back.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.admin.back.model.DeviceSP;

@Repository
public interface DeviceSPRepository extends JpaRepository<DeviceSP, Long> {

    @Procedure(name = "SO_GetDeviceInfo")
    List<DeviceSP> SO_GetDeviceInfo(
            @Param("searchString") String searchString,
            @Param("BuildingId") int buildingId,
            @Param("global") int global);

}
