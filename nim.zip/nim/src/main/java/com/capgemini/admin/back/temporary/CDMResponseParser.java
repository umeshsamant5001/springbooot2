package com.capgemini.admin.back.temporary;

import java.io.IOException;
import java.util.Objects;

import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hazelcast.org.json.JSONObject;

@Component
public class CDMResponseParser {

	private static final Logger log = LoggerFactory.getLogger(CDMResponseParser.class);

	private static final String DEFAULT_CHARSET = "UTF-8";
	private static final String AUTHENTICATE = "authenticate";
	static final String LOCATION_HEADER = "Location";

	public Session readTokenRes(CloseableHttpResponse res) {
		validateStatusCode(res, HttpStatus.SC_OK, AUTHENTICATE);
		Session session = new Session();
		String jsonString;
		String accessToken;
		try {
			jsonString = EntityUtils.toString(res.getEntity());
			JSONObject jsonObj = new JSONObject(jsonString);
			accessToken = jsonObj.getString("access_token");
			if (Objects.isNull(accessToken)) {
				throw new CDMConnectorException("CDM authentication response - no acces_token found");
			}
			// store token to be put as authorisation bearer on cdm request, token is valid
			// 3600 seconds (1hour)
			session.setToken(accessToken);
		} catch (Exception e) {
			// cdmBatchExceptionReport.writeCDMBatchExceptionReport(e.getMessage());
		}
		return session;
	}

	public String readGetListPoiByAssetIdAndFloorKeyId(CloseableHttpResponse res) {
		validateStatusCode(res, HttpStatus.SC_OK, "getPois");
		log.debug("Log_custom_2-After request");
		String jsonString = "";
		try {
			log.debug("Log_custom_3-Entity" + res.getEntity());
			jsonString = EntityUtils.toString(res.getEntity());
			if (Objects.isNull(jsonString)) {
				throw new CDMConnectorException("CDM get pois error");
			}
		} catch (Exception e) {

		}
		return jsonString;
	}

	/**
	 * Validate that a http response has the expected http code
	 *
	 * @param res
	 * @param expectedStatusCode
	 * @param apiName
	 */
	private void validateStatusCode(CloseableHttpResponse res, int expectedStatusCode, String apiName) {
		int statusCode = res.getStatusLine().getStatusCode();
		if (expectedStatusCode != statusCode) {
			readErrorBody(res, statusCode, apiName);
		}
	}

	private void readErrorBody(CloseableHttpResponse res, int statusCode, String apiName) {
		String body = null;
		if (Objects.nonNull(res.getEntity())) {
			try {
				body = EntityUtils.toString(res.getEntity(), DEFAULT_CHARSET);
			} catch (ParseException | IOException e) {
				body = "unreadable body";
			}
		}
		throw new CDMConnectorException(
				String.format("CDM [%s] ws unexpected status code:[%d] body:[%s]", apiName, statusCode, body));
	}

}
