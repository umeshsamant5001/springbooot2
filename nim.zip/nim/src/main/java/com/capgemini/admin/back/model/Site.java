package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.capgemini.admin.back.config.Constants;
import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "site", indexes = { @Index(name = "IDX_MODIFIED_SITE", columnList = "modified_at") })
@EqualsAndHashCode
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class Site implements WithTitle {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Site_Generator")
	@SequenceGenerator(name = "Site_Generator", sequenceName = "Site_Sequence")
	private Long id;

	@OneToMany(mappedBy = "site", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private List<Building> buildings = new ArrayList<>();

	@Column(name = "city_id", updatable = false, insertable = false)
	private Long cityId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "city_id")
	@JsonIgnore
	private City city;

	@Column(name = "title_fr")
	private String titleFr;

	@Column(name = "title_en")
	private String titleEn;

	@Column(name = "modified_at", nullable = false, columnDefinition = Constants.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime() / 1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;

	@CollectionTable(name = "site_attribute", joinColumns = @JoinColumn(name = "site_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

	@Override
	public String toString() {
		return "Site{" +
				"id=" + id +
				", titleFr='" + titleFr + '\'' +
				", titleEn='" + titleEn + '\'' +
				// Exclude lazy association
				'}';
	}

}
