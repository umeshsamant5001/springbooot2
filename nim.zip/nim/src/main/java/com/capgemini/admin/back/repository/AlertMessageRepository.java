package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.admin.back.model.AlertMessage;
import com.capgemini.admin.back.model.AlertType;
import com.capgemini.admin.back.model.ThresholdType;

@Repository
public interface AlertMessageRepository extends JpaRepository<AlertMessage, Long> {

        @Query(value = "SELECT am from AlertMessage am")
        public List<AlertMessage> getListOfAlertNotification();
        
        @Query(value = "SELECT am FROM AlertMessage am WHERE am.spaceTypeId = :spaceTypeId AND am.thresholdType = :thresholdType AND am.alertCategory = :alertType")
        AlertMessage findBySpaceTypeIdAndThresholdTypeAndAlertType(@Param("spaceTypeId") Long spaceTypeId,
                        @Param("thresholdType") ThresholdType thresholdType, @Param("alertType") AlertType alertType);

        @Modifying
        @Query(value = "UPDATE alert_message SET alert_sent_at = :alertSentAtTime WHERE id = :id", nativeQuery = true)
        void updateAlertStatus(@Param("id") Long id, @Param("alertSentAtTime") Long alertSentAtTime);

        @Query(value = "SELECT am.* , aml.country_name ,aml.level " +
                        "FROM alert_message am JOIN alert_message_location aml ON " +
                        "am.id = aml.alert_message_id WHERE am.space_type_id = :spaceTypeId " +
                        "AND am.space_type_name = :spaceTypeName " +
                        "AND am.threshold_type = :thresholdType " +
                        "AND am.alert_type = :alertCategory " +
                        "AND aml.level =  'GLOBAL' ", nativeQuery = true)
        List<Object[]> findAlertMessagesWithCountry(@Param("spaceTypeId") Long id,
                        @Param("spaceTypeName") String spaceTypeName, @Param("thresholdType") String thresholdType,
                        @Param("alertCategory") String alertCategory);

        @Query(value = "SELECT am.* , aml.country_name ,aml.level " +
                        "FROM alert_message am JOIN alert_message_location aml ON " +
                        "am.id = aml.alert_message_id WHERE am.space_type_id = :spaceTypeId " +
                        "AND am.space_type_name = :spaceTypeName " +
                        "AND am.threshold_type = :thresholdType " +
                        "AND am.alert_type = :alertCategory " +
                        "AND aml.level =  'COUNTRY' AND aml.country_name IN :countries", nativeQuery = true)

        List<Object[]> findAlertMessagesWithCountries(@Param("spaceTypeId") Long id,
                        @Param("spaceTypeName") String spaceTypeName, @Param("thresholdType") String thresholdType,
                        @Param("alertCategory") String alertCategory, @Param("countries") List<String> countries);
}
