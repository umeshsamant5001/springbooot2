package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class FeatureAccessDTO {
    private Long id;
    private FrontPageDTO frontPage;
    private EnumAccess access;
    private Boolean isActive;
}