package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;

import com.capgemini.admin.back.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

        @Override
        @Query("SELECT user FROM User user WHERE deleted != 1 ORDER BY email ASC")
        List<User> findAll();

        @Override
        @Query("SELECT user FROM User user WHERE user.id = :id AND deleted != 1")
        Optional<User> findById(@Param("id") Long id);

        @Query("SELECT user FROM User user WHERE user.id = :id AND user.email = :email AND deleted != 1")
        Optional<User> findByIdAndEmail(@Param("id") Long id, @Param("email") String email);

        @Query("SELECT user FROM User user WHERE user.id = :id AND deleted != 1")
        Optional<User> findByIdAndDeletedFalse(@Param("id") Long id);

        @Query("SELECT user FROM User user WHERE user.id = :id ")
        User findByIdEvenIfIsDeleted(@Param("id") Long id);



        @Query("SELECT user FROM User user WHERE user.email = :email AND deleted != 1")
        User findActiveUserByEmail(@Param("email") String email);

        @Query("SELECT user FROM User user WHERE user.email = :email")
        User findByEmailEvenIfDeleted(@Param("email") String email);

        @Query("SELECT DISTINCT r.name FROM User user JOIN UserRoleLocation url ON user.id = url.userId JOIN Role r ON r.id = url.roleId WHERE user.email = :email AND user.deleted = false")
        List<String> findRoleNamesByEmail(@Param("email") String email);

        @Query(value = "SELECT * " +
                        "FROM users " +
                        "WHERE id IN (SELECT users.id FROM users JOIN user_role_location ON users.id = user_role_location.user_id) "
                        +
                        "AND deleted != 1", nativeQuery = true)
        List<User> findAllWithRole();

        @Query(value = "SELECT DISTINCT u.* FROM users u " +
                        "LEFT JOIN user_role_location url ON u.id = url.user_id " +
                        "LEFT JOIN user_profile up ON u.id = up.user_id " +
                        "JOIN role r ON url.role_id = r.id " +
                        "WHERE r.is_web_user_profile = 1", nativeQuery = true)
        List<User> findUsersWithWebUserProfile();

        @Query(value = "SELECT DISTINCT u.* FROM users u " +
                        "LEFT JOIN user_role_location url ON u.id = url.user_id " +
                        "LEFT JOIN user_profile up ON u.id = up.user_id " +
                        "JOIN role r ON url.role_id = r.id " +
                        "WHERE (r.is_web_user_profile = 0 OR r.is_web_user_profile IS NULL) AND u.deleted != 1", nativeQuery = true)
        List<User> findUsersWithoutWebUserProfileOrWithAdminRole();

        @Query(value = "SELECT DISTINCT " +
                        "REPLACE(CONCAT(users.first_name, ' ', users.last_name), ',', ' ') AS name, " +
                        "REPLACE(users.email, ',', ' ') AS email, " +
                        "REPLACE(role.name, ',', ' ') AS role_assigned, " +
                        "CASE " +
                        "    WHEN user_role_location.level = 'building' THEN " +
                        "        (SELECT REPLACE(building.title_en, ',', ' ') " +
                        "         FROM building " +
                        "         WHERE building.cdm_key_id = user_role_location.cdm_key_id) " +
                        "    WHEN user_role_location.level = 'country' THEN " +
                        "        (SELECT REPLACE(country.title_en, ',', ' ') " +
                        "         FROM country " +
                        "         WHERE country.cdm_key_id = user_role_location.cdm_key_id) " +
                        "    ELSE " +
                        "        REPLACE(user_role_location.level, ',', ' ') " +
                        "END AS location_access " +
                        "FROM users " +
                        "INNER JOIN user_role_location ON users.id = user_role_location.user_id " +
                        "INNER JOIN role ON role.id = user_role_location.role_id " +
                        "WHERE role.name NOT IN ('Beta User', 'Secured User') " +
                        "ORDER BY REPLACE(CONCAT(users.first_name, ' ', users.last_name), ',', ' ')", nativeQuery = true)
        List<List<String>> getExportAllUsers();

        @Query(value = "SELECT CONCAT(users.first_name, ' ', users.last_name) AS Name, " +
                        "users.email AS Email, " +
                        "role.name AS Role_Assigned, " +
                        "CASE " +
                        "    WHEN ur.level = 'building' THEN building.title_en " +
                        "    ELSE 'Global Level' " +
                        "END AS Location_Name " +
                        "FROM users " +
                        "INNER JOIN user_role_location ur ON users.id = ur.user_id " +
                        "LEFT JOIN building ON ur.cdm_key_id = building.cdm_key_id AND ur.level = 'building' " +
                        "INNER JOIN role ON ur.role_id = role.id " +
                        "WHERE role.name IN ('Secured User', 'Beta User') " +
                        "GROUP BY users.first_name, users.last_name, users.email, role.name, building.title_en, ur.level", nativeQuery = true)
        List<List<String>> getExportSecuredAndBetaUsers();

        List<User> findAllByEmailIn(Set<String> emails);

        @Query("SELECT u FROM User u LEFT JOIN FETCH u.userSecuredBuildings WHERE u.id = :userId")
        Optional<User> findUserWithBuildings(@Param("userId") Long userId);

        @Query("SELECT DISTINCT u FROM User u JOIN UserRoleLocation url ON u.id = url.userId WHERE url.roleId = :roleId")
        List<User> findUsersWithRole(@Param("roleId") Long roleId);

        @Query(value = "SELECT u.email AS email, r.name AS roleName, urls.cdm_key_id AS cdmKeyId, urls.level AS level, "
                        +
                        " urls.role_id AS roleId, urls.user_id AS userId, c.id AS countryId, c.title_en AS countryName, "
                        +
                        " city.id AS cityId, city.title_en AS cityName, site.id AS siteId, site.title_en AS siteName, "
                        +
                        " b.id AS buildingId, b.title_en AS buildingName  FROM users AS u " +
                        " INNER JOIN user_role_location AS urls ON u.id = urls.user_id " +
                        " INNER JOIN role AS r ON urls.role_id = r.id " +
                        " LEFT JOIN country AS c ON (urls.level = 'COUNTRY' AND urls.cdm_key_id = c.cdm_key_id) " +
                        " LEFT JOIN city AS city ON (urls.level = 'CITY' AND urls.cdm_key_id = city.cdm_key_id) " +
                        " LEFT JOIN site AS site ON (urls.level = 'SITE' AND urls.cdm_key_id = site.cdm_key_id) " +
                        " LEFT JOIN building AS b ON (urls.level = 'BUILDING' AND urls.cdm_key_id = b.cdm_key_id) " +
                        " WHERE urls.user_id = :userId AND r.name = :roleName", nativeQuery = true)
        List<Object[]> fetchEmailContent(@Param("userId") Long userId, @Param("roleName") String roleName);

        @Query("SELECT user FROM User user WHERE userType = 2 ORDER BY email ASC")
        List<User> findAllAdminUsers();
        
}
