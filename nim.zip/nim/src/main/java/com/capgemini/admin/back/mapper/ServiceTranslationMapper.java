package com.capgemini.admin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.ServiceTranslation;
import com.capgemini.admin.back.model.ServiceTranslationDTO;

@Mapper(config = DtoMapperConfig.class)
public interface ServiceTranslationMapper {
    ServiceTranslationMapper INSTANCE = Mappers.getMapper(ServiceTranslationMapper.class);

    @Mapping(target = "service", ignore = true)
    ServiceTranslation serviceTranslationDTOToServiceTranslation(ServiceTranslationDTO in);

    @Mapping(target = "service", ignore = true)
    ServiceTranslationDTO serviceTranslationToServiceTranslationDTO(ServiceTranslation in);

}
