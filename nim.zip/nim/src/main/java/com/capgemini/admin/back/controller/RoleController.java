package com.capgemini.admin.back.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.admin.back.mapper.RoleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.model.EnumAccess;
import com.capgemini.admin.back.model.FeatureAccessDTO;
import com.capgemini.admin.back.model.FrontPageDTO;
import com.capgemini.admin.back.model.Role;
import com.capgemini.admin.back.model.RoleDTO;
import com.capgemini.admin.back.service.RoleService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;


@RestController
@RequestMapping("api/role")
public class RoleController {

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class RoleFeatureFrontPageInput {
        @NotNull
        @Min(1)
        private Long id;
    }

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class RoleFeatureAccessInput {
        @Min(1)
        private Long id;
        @NotNull
        @Valid
        private RoleFeatureFrontPageInput frontPage;
        @NotNull
        private EnumAccess access;
        private Boolean isActive;
    }


    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class RoleWriteInput {
        @NotNull
        @Size(max = 255)
        @Pattern(regexp = SAFE_TEXT_REGEX)
        private String name;

        @NotNull
        @Min(0)
        private Long precedence;
        private Boolean isActive;
        private Boolean isWebUserProfile;
        @Valid
        @Size(max = 1000)
        private List<RoleFeatureAccessInput> featureAccesses = new ArrayList<>();
    }

    @Autowired
    private RoleService roleService;


    /**
     * Retrieves a list of all roles.
     *
     * @param withFeature Flag to include features in the response (default is
     *                    false).
     * @return ResponseEntity with a list of RoleDTOs if successful, else
     *         appropriate error responses.
     */
    @GetMapping
    public ResponseEntity<List<RoleDTO>> getAllRoles(
            @RequestParam(required = false, defaultValue = "false") Boolean withFeature,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<Role> roles = this.roleService.getAllRole(withFeature);
        if (Objects.isNull(roles)) {
            return ResponseEntity.internalServerError().build();
        }

        return ResponseEntity.ok(this.roleService.listRoleToRoleDTOList(roles, language));
    }

    /**
     * Retrieves a role by its ID.
     *
     * @param id          The ID of the role to retrieve.
     * @param withFeature Flag to include features in the response (default is
     *                    false).
     * @return ResponseEntity with a RoleDTO if successful, else not found response.
     */
    @GetMapping("/{id}")
    public ResponseEntity<RoleDTO> getRoleById(
            @PathVariable Long id, @RequestParam(required = false, defaultValue = "false") Boolean withFeature,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        Role role = this.roleService.getRoleById(id, withFeature);
        if (Objects.isNull(role)) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(RoleMapper.INSTANCE.roleToRoleDTO(role, language));
    }

    /**
     * Creates a new role.
     *
     * @param roleDTO The RoleDTO representing the new role.
     * @return ResponseEntity with the created RoleDTO if successful, else bad
     *         request response.
     */
    @PostMapping
    public ResponseEntity<RoleDTO> createRole(
            @Valid @RequestBody RoleWriteInput roleDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        RoleDTO sanitizedRoleDTO = toSanitizedRoleDTO(roleDTO, null);
        Role savedRole = this.roleService.createRole(sanitizedRoleDTO);

        if (Objects.isNull(savedRole)) {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(RoleMapper.INSTANCE.roleToRoleDTO(savedRole, language));
    }

    /**
     * Updates an existing role by ID.
     *
     * @param id      The ID of the role to update.
     * @param roleDTO The updated RoleDTO.
     * @return ResponseEntity with the updated RoleDTO if successful, else not found
     *         or internal server error response.
     */
    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<RoleDTO> updateRole(
            @PathVariable Long id, @Valid @RequestBody RoleWriteInput roleDTO,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        RoleDTO sanitizedRoleDTO = toSanitizedRoleDTO(roleDTO, id);
        Role role = this.roleService.getRoleById(id, false);

        if (Objects.isNull(role)) {
            return ResponseEntity.notFound().build();
        }

        role.getFeatureAccesses();
        Role updatedRole = this.roleService.updateRole(role, sanitizedRoleDTO);

        if (Objects.isNull(updatedRole)) {
            return ResponseEntity.internalServerError().build();
        }
        return ResponseEntity.ok(RoleMapper.INSTANCE.roleToRoleDTO(updatedRole, language));
    }

    /**
     * Deletes a role by ID.
     *
     * @param id The ID of the role to delete.
     * @return ResponseEntity with no content if successful, else not found
     *         response.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRole(@PathVariable Long id) {
        this.roleService.deleteRole(id);
        return ResponseEntity.noContent().build();
    }

    private RoleDTO toSanitizedRoleDTO(RoleWriteInput input, Long pathId) {
        RoleDTO sanitizedRoleDTO = new RoleDTO();
        sanitizedRoleDTO.setId(pathId == null ? null : Long.valueOf(pathId));
        sanitizedRoleDTO.setName(input.getName() == null ? null : String.valueOf(input.getName()));
        sanitizedRoleDTO.setPrecedence(input.getPrecedence() == null ? null : Long.valueOf(input.getPrecedence()));
        sanitizedRoleDTO.setIsActive(input.getIsActive() == null
                ? null
                : Boolean.valueOf(String.valueOf(input.getIsActive())));
        sanitizedRoleDTO.setIsWebUserProfile(input.getIsWebUserProfile() == null
                ? null
                : Boolean.valueOf(String.valueOf(input.getIsWebUserProfile())));


        List<FeatureAccessDTO> sanitizedFeatureAccesses = new ArrayList<>();
        if (Objects.nonNull(input.getFeatureAccesses())) {
            for (RoleFeatureAccessInput featureInput : input.getFeatureAccesses()) {
                if (Objects.isNull(featureInput)
                        || Objects.isNull(featureInput.getFrontPage())
                        || Objects.isNull(featureInput.getFrontPage().getId())) {
                    continue;
                }
                FeatureAccessDTO featureAccessDTO = new FeatureAccessDTO();
                featureAccessDTO.setId(featureInput.getId() == null ? null : Long.valueOf(featureInput.getId()));

                FrontPageDTO frontPageDTO = new FrontPageDTO();
                frontPageDTO.setId(Long.valueOf(featureInput.getFrontPage().getId()));
                featureAccessDTO.setFrontPage(frontPageDTO);
                featureAccessDTO.setAccess(featureInput.getAccess() == null
                        ? null
                        : EnumAccess.valueOf(String.valueOf(featureInput.getAccess())));
                featureAccessDTO.setIsActive(featureInput.getIsActive() == null
                        ? null
                        : Boolean.valueOf(String.valueOf(featureInput.getIsActive())));

                sanitizedFeatureAccesses.add(featureAccessDTO);
            }
        }
        sanitizedRoleDTO.setFeatureAccesses(sanitizedFeatureAccesses);
        return sanitizedRoleDTO;
    }

}