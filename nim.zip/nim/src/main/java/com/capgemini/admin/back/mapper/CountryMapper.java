package com.capgemini.admin.back.mapper;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.admin.back.model.City;
import com.capgemini.admin.back.model.CityDTO;
import com.capgemini.admin.back.model.Country;
import com.capgemini.admin.back.model.CountryDTO;

@Named("CountryMapper")
@Mapper(config = DtoMapperConfig.class, uses = CdmAttributesMapper.class)
public interface CountryMapper {

    CountryMapper INSTANCE = Mappers.getMapper(CountryMapper.class);

    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(target = "cities", ignore = true),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    CountryDTO countryToCountryDTONoCities(Country in, @Context String language);

    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(source = "cities", target = "cities", qualifiedByName = { "cityToCityDTOWithoutParent" }),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    CountryDTO countryToCountryDTO(Country in, @Context String language);

    /**
     * <p>
     * <strong>Do not use directly</strong> : used for @Mapping() decorator.
     * </p>
     *
     * <p>
     * For more information, check BuildingMapper.
     * </p>
     */
    @Named("countryToCountryDTOWithoutChildren")
    @Mappings({
            @Mapping(source = "in", target = "title", qualifiedByName = "toTitle"),
            @Mapping(target = "cities", ignore = true),
            @Mapping(source = "attributes", target = "attributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapAttributesDTO" }),
            @Mapping(source = "attributes", target = "cdmAttributes", qualifiedByName = { "CdmAttributesMapper",
                    "mapCdmAttributesDTO" })
    })
    CountryDTO _countryToCountryDTOWithoutChildren(Country in, @Context String language);

    @Named("cityToCityDTOWithoutParent")
    default CityDTO _cityToCityDTOWithoutParent(City city, @Context String language) {
        return Mappers.getMapper(CityMapper.class)._cityToCityDTOWithoutParent(city, language);
    }

    @Mapping(source = "in", target = "attributes", qualifiedByName = { "CdmAttributesMapper", "mapAttributes" })
    Country countryDTOToCountry(CountryDTO in);

}
