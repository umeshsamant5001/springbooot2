package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;


import com.capgemini.admin.back.mapper.SpaceTypeMapper;
import com.capgemini.admin.back.model.PoiAttributeKeysDTO;
import com.capgemini.admin.back.model.SpaceType;
import com.capgemini.admin.back.model.SpaceTypeDTO;
import com.capgemini.admin.back.repository.PoiRepository;
import com.capgemini.admin.back.service.SpaceTypeService;

import com.capgemini.admin.back.service.PoiService;
import com.capgemini.admin.back.service.PoiGroupService;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;



@Slf4j
@RestController

@Validated
@RequestMapping(value = SpaceTypeController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class SpaceTypeController {


    public static final String ROOT_API = "/api/spacetype";

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    @JsonIgnoreProperties(ignoreUnknown = false)
    @Data
    private static class SpaceTypeWriteRequest {
        @Min(1)
        private Long poiGroupId;

        @Size(max = 255)
        @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX)
        private String spaceCategoryName;

        @Size(max = 255)
        @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX)
        private String spaceTypeName;

        @Size(max = 1000)
        private List<@Size(max = 255) @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX) String> attributeKeys;

        @Size(max = 255)
        @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleFr;

        @Size(max = 255)
        @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX)
        private String titleEn;

        private Boolean isFromCdm;

        private Map<@Size(max = 255) @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX) String, @Size(max = 1000) @javax.validation.constraints.Pattern(regexp = SAFE_TEXT_REGEX) String> attributes;
    }


    @Autowired
    private SpaceTypeService spaceTypeService;


    @Autowired
    private PoiService poiService;

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private PoiGroupService poiGroupService;

    /**
     * Get Space Types
     *
     * @param language : language of space types
     * @return list of space types
     */
    @GetMapping
    public ResponseEntity<List<SpaceTypeDTO>> getAllCdmSpaceTypes(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<SpaceType> spaceTypes = this.spaceTypeService.getOrderedSpaceTypes();

        if (Objects.isNull(spaceTypes)) {
            return ResponseEntity.internalServerError().build();
        }

        Map<Long, Long> poiCountByType = this.poiService.countByTypeCDM();

        List<SpaceTypeDTO> spaceTypeDTOs = spaceTypes
                .stream()
                .map(spaceType -> SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(spaceType))
                .peek(spaceTypeDto -> {
                    if (poiCountByType.containsKey(spaceTypeDto.getId())) {
                        spaceTypeDto.setPoisCount(poiCountByType.get(spaceTypeDto.getId()));

                        Optional<String> poiGroupName = poiGroupService.findBySpaceTypeId(spaceTypeDto.getId());
                        poiGroupName.ifPresent(spaceTypeDto::setPoiGroupName);

                    } else {
                        spaceTypeDto.setPoisCount(0L);
                    }
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(spaceTypeDTOs);
    }

    // GET SpaceType by ID
    @GetMapping("/{id}")
    public ResponseEntity<Object> getSpaceTypeById(@PathVariable Long id) {
        SpaceType spaceType = spaceTypeService.getSpaceTypeById(id);
        if (Objects.isNull(spaceType)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(spaceType));
    }

    private String sanitizeForLog(String input) {
        if (input == null) {
            return "";
        }
        return new String(input.replaceAll("[\\r\\n\\t]", "_").replaceAll("[^\\x20-\\x7E]", ""));
    }

    private SpaceType sanitizeSpaceTypeRequest(SpaceTypeWriteRequest spaceTypeRequest) {
        SpaceType sanitizedSpaceType = new SpaceType();

        sanitizedSpaceType.setPoiGroupId(spaceTypeRequest.getPoiGroupId() == null
                ? null
                : Long.valueOf(spaceTypeRequest.getPoiGroupId()));
        sanitizedSpaceType.setSpaceCategoryName(spaceTypeRequest.getSpaceCategoryName() == null
                ? null
                : String.valueOf(spaceTypeRequest.getSpaceCategoryName()));
        sanitizedSpaceType.setSpaceTypeName(spaceTypeRequest.getSpaceTypeName() == null
                ? null
                : String.valueOf(spaceTypeRequest.getSpaceTypeName()));

        List<String> sanitizedAttributeKeys = null;
        if (Objects.nonNull(spaceTypeRequest.getAttributeKeys())) {
            sanitizedAttributeKeys = new ArrayList<>();
            for (String attributeKey : spaceTypeRequest.getAttributeKeys()) {
                if (Objects.nonNull(attributeKey)) {
                    sanitizedAttributeKeys.add(new String(String.valueOf(attributeKey)));
                }
            }
        }
        sanitizedSpaceType.setAttributeKeys(sanitizedAttributeKeys);

        Map<String, String> sanitizedAttributes = null;
        if (Objects.nonNull(spaceTypeRequest.getAttributes())) {
            final Map<String, String> tempAttributes = new HashMap<>();
            spaceTypeRequest.getAttributes().forEach((key, value) -> {
                if (Objects.nonNull(key) && Objects.nonNull(value)) {
                    tempAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
                }
            });
            sanitizedAttributes = tempAttributes;
        }
        sanitizedSpaceType.setAttributes(sanitizedAttributes);

        sanitizedSpaceType.setTitleFr(spaceTypeRequest.getTitleFr() == null
                ? null
                : String.valueOf(spaceTypeRequest.getTitleFr()));
        sanitizedSpaceType.setTitleEn(spaceTypeRequest.getTitleEn() == null
                ? null
                : String.valueOf(spaceTypeRequest.getTitleEn()));
        sanitizedSpaceType.setIsFromCdm(spaceTypeRequest.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(spaceTypeRequest.getIsFromCdm())));
        return sanitizedSpaceType;
    }

    private Map<String, String> toAttributeTypeMap(List<String> attributeKeys, Pattern patternKeyType) {
        if (attributeKeys == null || attributeKeys.isEmpty()) {
            return new HashMap<>();
        }

        return attributeKeys
                .stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(
                        key -> {
                            Matcher matcher = patternKeyType.matcher(key);
                            return matcher.find() ? matcher.group(1) : key;
                        },
                        key -> {
                            Matcher matcher = patternKeyType.matcher(key);
                            return matcher.find() ? matcher.group(2) : "";
                        },
                        (existingValue, newValue) -> existingValue,
                        HashMap::new));
    }

    // POST create a new SpaceType
    @PostMapping
    public ResponseEntity<SpaceType> createSpaceType(@Valid @RequestBody SpaceTypeWriteRequest spaceTypeRequest) {
        if (Objects.isNull(spaceTypeRequest)) {
            return ResponseEntity.badRequest().build();
        }

        SpaceType sanitizedSpaceType = sanitizeSpaceTypeRequest(spaceTypeRequest);

        SpaceType createdSpaceType = spaceTypeService.createSpaceType(sanitizedSpaceType);
        return ResponseEntity.ok(createdSpaceType);
    }


    @PutMapping("/{spaceTypeId}")
    public ResponseEntity<Object> updateSpaceType(
            @Valid @RequestBody SpaceTypeWriteRequest newSpaceTypeRequest,
            @PathVariable @Min(1) Long spaceTypeId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        if (Objects.isNull(spaceTypeId) || spaceTypeId <= 0 || Objects.isNull(newSpaceTypeRequest)) {
            return ResponseEntity.badRequest().build();
        }

        Long scopedSpaceTypeId = Long.valueOf(spaceTypeId);
        SpaceType sanitizedSpaceType = sanitizeSpaceTypeRequest(newSpaceTypeRequest);

        if (Objects.isNull(sanitizedSpaceType.getAttributes()) || Objects.isNull(sanitizedSpaceType.getAttributeKeys())) {
            return ResponseEntity.badRequest().build();
        }

        SpaceType spaceType = this.spaceTypeService.getSpaceTypeById(scopedSpaceTypeId);


        if (Objects.isNull(spaceType)) {
            return ResponseEntity.notFound().build();
        }

        Pattern patternKeyType = Pattern.compile("^([a-zA-Z0-9_]+):(.*)$");

        Map<String, String> existingAttributes = spaceType.getAttributes() == null ? new HashMap<>() : spaceType.getAttributes();
        Map<String, String> incomingAttributes = sanitizedSpaceType.getAttributes() == null ? new HashMap<>() : sanitizedSpaceType.getAttributes();

        List<String> oldAttributeKeys = new ArrayList<>(existingAttributes.keySet());
        List<String> newAttributeKeys = new ArrayList<>(incomingAttributes.keySet());

        List<String> attributeKeysOnly = spaceType.getAttributeKeys() == null ? new ArrayList<>() : spaceType.getAttributeKeys();
        List<String> newAttributeKeysOnly = sanitizedSpaceType.getAttributeKeys() == null
            ? new ArrayList<>()
            : sanitizedSpaceType.getAttributeKeys();

        Map<String, String> oldAttributesMap = toAttributeTypeMap(oldAttributeKeys, patternKeyType);
        Map<String, String> newAttributesMap = toAttributeTypeMap(newAttributeKeys, patternKeyType);

        List<String> removedKeys = oldAttributesMap
                .keySet()
                .stream()
                .filter(key -> !newAttributesMap.containsKey(key))
                .collect(Collectors.toList());

        // Ensure all attributes from newSpaceType are present in each Space
        newAttributesMap
                .keySet()
                .forEach(key -> {
                    try {
                        String attValue = "";
                        String rawValue = newAttributesMap.get(key);
                        String value = rawValue == null ? "" : rawValue.toLowerCase(Locale.ROOT);

                        if (value.contains("false")) {
                            attValue = "false";
                        } else if (value.contains("true")) {
                            attValue = "true";
                        }
                        poiRepository.addAttributeToPoisWithoutItCDM(scopedSpaceTypeId, key, attValue);
                    } catch (DataAccessException ex) {
                        log.error("Failed adding missing POI attribute for spaceTypeId {} and key {}", scopedSpaceTypeId, key, ex);
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                                "Unable to update POI attributes.");
                    }

                });


        // Remove deleted attribute keys from Spaces
        removedKeys.forEach(key -> {
            try {
                poiRepository.deleteAttributeFromPoisCDM(scopedSpaceTypeId, key);
            } catch (DataAccessException ex) {
                String sanitizedKeyForLog = sanitizeForLog(String.valueOf(key));
                log.error("Failed deleting POI attribute for spaceTypeId {} and key {}", scopedSpaceTypeId,
                        sanitizedKeyForLog, ex);
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Unable to update POI attributes.");
            }

        });



        // To get and remove deleted attribute keys which are removed from master space.
        List<String> oldOnlyAttributeKeys = attributeKeysOnly.stream()
                .filter(key -> !newAttributeKeysOnly.contains(key))
                .collect(Collectors.toList());

        if (Objects.nonNull(oldOnlyAttributeKeys) && !oldOnlyAttributeKeys.isEmpty()) {
            oldOnlyAttributeKeys.forEach(key -> {
                if (Objects.nonNull(key) && !key.isEmpty()) {
                    int delimiterIndex = key.indexOf(":");
                    if (delimiterIndex <= 0) {
                        return;
                    }
                    String attributeKey = key.substring(0, delimiterIndex);
                    try {
                        poiRepository.deleteAttributeFromPoisCDM(scopedSpaceTypeId, attributeKey);
                    } catch (DataAccessException ex) {
                        String sanitizedAttributeKeyForLog = sanitizeForLog(String.valueOf(attributeKey));
                        log.error("Failed deleting POI legacy attribute for spaceTypeId {} and key {}", scopedSpaceTypeId,
                                sanitizedAttributeKeyForLog, ex);
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                                "Unable to update POI attributes.");
                    }


                }

            });
        }

        Optional<SpaceType> updatedSpaceTypeOptional = this.spaceTypeService.updateSpaceType(scopedSpaceTypeId,
                sanitizedSpaceType);
        if (updatedSpaceTypeOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        SpaceType updatedSpaceType = updatedSpaceTypeOptional.get();
        return ResponseEntity.ok(SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(updatedSpaceType));
    }

    // DELETE an existing SpaceType
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSpaceType(@PathVariable @Min(1) Long id) {
        if (Objects.isNull(id) || id <= 0) {
            return ResponseEntity.badRequest().build();
        }

        Long scopedSpaceTypeId = Long.valueOf(id);
        boolean deleted = spaceTypeService.deleteSpaceType(scopedSpaceTypeId);


        if (deleted) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<SpaceTypeDTO>> getAllByBuildingId(
            @PathVariable Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<SpaceType> spaceTypes = this.spaceTypeService.getOrderedSpaceTypes();
        if (spaceTypes == null || spaceTypes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Get the POI count for each PoiType and buildingId
        Map<Long, Long> poiCountByGroupAndBuilding = this.poiService.countByTypeAndBuildingCDM(buildingId);

        List<SpaceTypeDTO> spaceTypeDTOs = spaceTypes
                .stream()
                .map(poiGroup -> {
                    SpaceTypeDTO spaceTypeDTO = SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(poiGroup);
                    // Check if the PoiGroup has a POI count for the specific building
                    if (poiCountByGroupAndBuilding.containsKey(spaceTypeDTO.getId())) {
                        spaceTypeDTO.setPoisCount(poiCountByGroupAndBuilding.get(spaceTypeDTO.getId()));

                        Optional<String> poiGroupName = poiGroupService.findBySpaceTypeId(spaceTypeDTO.getId());
                        poiGroupName.ifPresent(spaceTypeDTO::setPoiGroupName);
                    } else {
                        spaceTypeDTO.setPoisCount(0L);
                    }
                    return spaceTypeDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(spaceTypeDTOs);
    }

    @GetMapping("/building/{buildingId}/floor/{floorId}")
    public ResponseEntity<List<SpaceTypeDTO>> getPoiCountsByBuildingAndFloor(
            @PathVariable Long buildingId,
            @PathVariable Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<SpaceType> spaceTypes = this.spaceTypeService.getOrderedSpaceTypes();
        if (spaceTypes == null || spaceTypes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Get the POI count for each PoiGroup, buildingId, and floorId
        Map<Long, Long> poiCountByGroupAndFloor = this.poiService.countByTypeAndFloorId(buildingId, floorId);

        List<SpaceTypeDTO> poiGroupDTOs = spaceTypes
                .stream()
                .map(poiGroup -> {
                    SpaceTypeDTO spaceTypeDTO = SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(poiGroup);
                    // Check if the PoiType has a POI count for the specific building and floor
                    if (poiCountByGroupAndFloor.containsKey(spaceTypeDTO.getId())) {
                        spaceTypeDTO.setPoisCount(poiCountByGroupAndFloor.get(spaceTypeDTO.getId()));

                        Optional<String> poiGroupName = poiGroupService.findBySpaceTypeId(spaceTypeDTO.getId());
                        poiGroupName.ifPresent(spaceTypeDTO::setPoiGroupName);
                    } else {
                        spaceTypeDTO.setPoisCount(0L);
                    }
                    return spaceTypeDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOs);
    }

    /* 
    * REST API endpoint to fetch all POI Attribute Keys from the master table.
    * 
    * This method handles GET requests at "/getPoiAttributeKeys" and returns a list of
    * PoiAttributeKeysDTO objects. The data is retrieved via the SpaceTypeService.
    *
    * @return ResponseEntity containing the list of POI Attribute Keys with HTTP status 200 (OK).
    */
    @GetMapping("/getPoiAttributeKeys")
    public ResponseEntity<List<PoiAttributeKeysDTO>> fetchPoiAttributeKeysFromMaster() {
        List<PoiAttributeKeysDTO> poiAttributeKeysDTOs = new ArrayList<>();
        poiAttributeKeysDTOs = spaceTypeService.fetchPoiAttributeKeysFromMaster();
        return ResponseEntity.status(HttpStatus.OK).body(poiAttributeKeysDTOs);
    }
}
