
package com.capgemini.admin.back.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.capgemini.admin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "error_logging", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class ErrorLogging {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ErrorLogging_Generator")
	@SequenceGenerator(name = "ErrorLogging_Generator", sequenceName = "ErrorLogging_Sequence")
	private Long id;

	@Column(name = "className")
	private String ClassName;

	@Column(name = "module")
	private String module;

	@Column(name = "lineNumber")
	private Integer lineNumber;

	@Column(name = "description")
	private String description;

	@Column(name = "state")
	private String state;

	@Column(name = "error_Type")
	private EnumErrorType errorType;

	@Column(name = "data")
	private String data;

	@Column(name = "logging_Date")
	private Long loggingDate;

	@Column(name = "errorlogging_type")
	private EnumErrorLoggingType errorLoggingType;

}
