package com.capgemini.admin.back.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiGroupUpsertInput {

    private String name;

    private List<String> attributeKeys = new ArrayList<>();

    private Map<String, String> attributes = new HashMap<>();

    private String titleFr;

    private String titleEn;

    private Boolean isFromCdm;

    private List<Long> spaceTypeIds = new ArrayList<>();

    private Boolean isVisibleOnPWA;

    private String icon;
}
