/**
 * Spring Security configuration.
 */
package com.capgemini.admin.back.security;
