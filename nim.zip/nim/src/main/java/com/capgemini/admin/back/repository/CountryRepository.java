package com.capgemini.admin.back.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.capgemini.admin.back.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

	Country findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	@Query("SELECT country.cdmKeyId, country.titleEn AS name FROM Country country WHERE country.cdmKeyId in (:cdmKeyIdList)")
	List<Tuple> getNameByCmdKeyId(@Param("cdmKeyIdList") List<Long> cdmKeyIdList);

	@Query("SELECT INDEX(attributes), attributes FROM Country country INNER JOIN country.attributes attributes WHERE country.id = :countryId")
	List<Tuple> getAttributesById(@Param("countryId") Long countryId);

	@Query(value = "SELECT distinct c.* FROM country c inner JOIN city ci ON ci.country_id=c.id inner JOIN site s ON s.city_id=ci.id inner JOIN building b ON b.site_id = s.id where c.id = :countryId", nativeQuery = true)
	Country findByCountryId(@Param("countryId") Long countryId);

	@Query(value = "SELECT * FROM country " +
			" WHERE id = :countryId AND cdm_key_id = :cdmKeyId AND title_en = :countryName", nativeQuery = true)
	Country existsByCountryIdAndCdmKeyIdAndCountryName(@Param("countryId") Long countryId,
			@Param("cdmKeyId") Long cdmKeyId, @Param("countryName") String countryName);

	List<Country> findByCdmKeyIdIn(Set<Long> cdmKeyIds);

	Optional<Country> findByTitleEnIgnoreCase(String titleEn);

	@Modifying
	@Transactional
	@Query(value = "UPDATE country SET cdm_key_id = :cdmKeyId, title_fr = :titleFr, title_en = :titleEn, modified_at = :modifiedAt WHERE id = :countryId", nativeQuery = true)
	int updateCountryCoreFields(
			@Param("countryId") Long countryId,
			@Param("cdmKeyId") Long cdmKeyId,
			@Param("titleFr") String titleFr,
			@Param("titleEn") String titleEn,
			@Param("modifiedAt") Long modifiedAt);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM country_attribute WHERE country_id = :countryId", nativeQuery = true)
	void deleteAttributesByCountryId(@Param("countryId") Long countryId);

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO country_attribute (country_id, att_key, att_value) VALUES (:countryId, :attKey, :attValue)", nativeQuery = true)
	void insertCountryAttribute(
			@Param("countryId") Long countryId,
			@Param("attKey") String attKey,
			@Param("attValue") String attValue);
}
