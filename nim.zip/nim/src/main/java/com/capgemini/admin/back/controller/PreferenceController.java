package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.model.Language;
import com.capgemini.admin.back.model.LanguageDTO;
import com.capgemini.admin.back.model.Preference;
import com.capgemini.admin.back.model.PreferenceDTO;
import com.capgemini.admin.back.model.User;
import com.capgemini.admin.back.service.LanguageService;
import com.capgemini.admin.back.service.PreferenceService;
import com.capgemini.admin.back.service.UserService;
import com.capgemini.admin.back.mapper.PreferenceMapper;

@RestController
@RequestMapping(value = PreferenceController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PreferenceController {

    static final String ROOT_API = "api/preference";

    @Autowired
    private PreferenceService preferenceService;

    @Autowired
    private UserService userService;

    @Autowired
    private LanguageService languageService;

    @GetMapping("/{userEmail}")
    public ResponseEntity<PreferenceDTO> getPreferencesByEmailId(
            @PathVariable("userEmail") String userEmail,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {

        PreferenceDTO preferenceDTO = this.preferenceService.getUserPreference(userEmail, language);

        return ResponseEntity.ok(preferenceDTO);
    }

    @PutMapping("/{userEmail}/language")
    public ResponseEntity<PreferenceDTO> saveSelectedLanguages(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable("userEmail") String userEmail,
            @RequestBody @NonNull List<LanguageDTO> selectedLanguagesDTO) {
        User user = this.userService.getUserByEmail(userEmail);
        // Check if the user exists
        if (Objects.isNull(user)) {
            return ResponseEntity.notFound().build();
        }

        Preference preference = this.preferenceService.getUserPreference(userEmail);
        if (Objects.isNull(preference)) {
            // Create the preference is it don't exists
            preference = new Preference();
            preference.setUserEmail(userEmail);
        }

        // Get the list of "locale" from the languages
        List<String> locales = selectedLanguagesDTO.stream()
                .map(languageDTO -> languageDTO.getLocale())
                .collect(Collectors.toList());

        // Get the language based on the "locale"
        List<Language> selectedLanguages = this.languageService.findAllByLocale(locales);
        // The the selected languages
        preference.setSelectedLanguages(selectedLanguages);

        Preference savedPreference = this.preferenceService.save(preference);

        PreferenceDTO preferenceDTO = PreferenceMapper.INSTANCE.preferenceToPreferenceDTO(savedPreference, language);

        return ResponseEntity.ok(preferenceDTO);
    }

}
