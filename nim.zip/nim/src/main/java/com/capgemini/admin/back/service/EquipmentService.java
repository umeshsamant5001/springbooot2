package com.capgemini.admin.back.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.capgemini.admin.back.model.Equipment;

import com.capgemini.admin.back.repository.EquipmentRepository;

@Service
public class EquipmentService {

    @Autowired
    private EquipmentRepository equipmentRepository;

    private static final String SAFE_TEXT_REGEX = "^[^\\r\\n\\t\\p{Cntrl}]*$";

    private static final class SafeEquipmentValues {
        private final String name;
        private final String titleEn;
        private final String titleFr;

        private SafeEquipmentValues(String name, String titleEn, String titleFr) {
            this.name = name;
            this.titleEn = titleEn;
            this.titleFr = titleFr;
        }
    }


   
    /**
     * Retrieves all equipment records from the database, ordered alphabetically by name.
     *
     * @return a list of Equipment objects sorted by name in ascending order
     */
    public List<Equipment> getOrderedEquipments() {
        return this.equipmentRepository.findAllByOrderByNameAsc();
    }
    
    /**
     * Retrieves a specific Equipment entity by its ID.
     *
     * @param id the ID of the equipment to retrieve
     * @return the Equipment object if found, otherwise null
     */
    public Equipment getEquipmentById(Long id) {
        return this.equipmentRepository.findById(id).orElse(null);
    }
    
    /**
     * Updates an existing Equipment entity with new values.
     *
     * @param equipmentId the existing Equipment id to update
     * @param name equipment name
     * @param titleEn equipment title in English
     * @param titleFr equipment title in French
     * @return the updated Equipment object
     */
    @Transactional
    public Equipment updateEquipment(Long equipmentId, String name, String titleEn, String titleFr) {


        if (Objects.isNull(equipmentId) || Objects.isNull(name)) {
            return null;
        }

        Equipment currentEquipment = this.equipmentRepository.findById(equipmentId).orElse(null);
        if (Objects.isNull(currentEquipment)) {
            return null;
        }

        SafeEquipmentValues safeValues = sanitizeEquipmentWriteInputForPersistence(name, titleEn, titleFr);

        int updatedRows = this.equipmentRepository.updateEquipmentCoreFields(
                Long.valueOf(String.valueOf(currentEquipment.getId())),
                new String(String.valueOf(safeValues.name)),
                safeValues.titleEn == null ? null : new String(String.valueOf(safeValues.titleEn)),
                safeValues.titleFr == null ? null : new String(String.valueOf(safeValues.titleFr)));

        if (updatedRows <= 0) {
            return null;
        }

        return this.equipmentRepository.findById(Long.valueOf(String.valueOf(currentEquipment.getId()))).orElse(null);

    }



    
    /**
     * Deletes an Equipment entity by its ID.
     *
     * @param id the ID of the equipment to delete
     */
    public void deleteEquipmentById(Long id) {
        this.equipmentRepository.deleteById(id);
    }
   
    /**
     * Retrieves an Equipment entity by its name.
     *
     * @param name the name of the equipment
     * @return the Equipment object if found, otherwise null
     */
    public Equipment getByName(String name) {
        return this.equipmentRepository.findByName(name).orElse(null);
    }
    
    /**
     * Creates and saves a new Equipment entity in the database.
     *
     * @param name equipment name
     * @param titleEn equipment title in English
     * @param titleFr equipment title in French
     * @return the saved Equipment object
     */
    @Transactional
    public Equipment createEquipment(String name, String titleEn, String titleFr) {

        if (Objects.isNull(name)) {
            return null;
        }

        SafeEquipmentValues safeValues = sanitizeEquipmentWriteInputForPersistence(name, titleEn, titleFr);

        Equipment equipment = new Equipment();
        equipment.setName(safeValues.name);
        equipment.setTitleEn(safeValues.titleEn);
        equipment.setTitleFr(safeValues.titleFr);

        return this.equipmentRepository.save(equipment);

    }




    private SafeEquipmentValues sanitizeEquipmentWriteInputForPersistence(String name, String titleEn, String titleFr) {
        String safeName = name == null
                ? null
                : new String(String.valueOf(name));
        String safeTitleEn = titleEn == null
                ? null
                : new String(String.valueOf(titleEn));
        String safeTitleFr = titleFr == null
                ? null
                : new String(String.valueOf(titleFr));


        String validatedName = sanitizeRequiredText(safeName, 255);
        String validatedTitleEn = sanitizeOptionalText(safeTitleEn, 255);
        String validatedTitleFr = sanitizeOptionalText(safeTitleFr, 255);

        return new SafeEquipmentValues(
                new String(String.valueOf(validatedName)),
                validatedTitleEn == null ? null : new String(String.valueOf(validatedTitleEn)),
                validatedTitleFr == null ? null : new String(String.valueOf(validatedTitleFr)));
    }

    private String sanitizeRequiredText(String value, int maxLength) {

        if (value == null) {
            throw new IllegalArgumentException("Required text input is missing");
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("Required text input is blank");
        }
        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(trimmed);
    }

    private String sanitizeOptionalText(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > maxLength || !trimmed.matches(SAFE_TEXT_REGEX)) {
            throw new IllegalArgumentException("Invalid text input");
        }
        return new String(trimmed);
    }



}
