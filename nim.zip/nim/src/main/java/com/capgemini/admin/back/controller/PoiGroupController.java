package com.capgemini.admin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.admin.back.mapper.PoiGroupMapper;
import com.capgemini.admin.back.mapper.SpaceTypeMapper;
import com.capgemini.admin.back.model.PoiGroup;
import com.capgemini.admin.back.model.PoiGroupDTO;
import com.capgemini.admin.back.model.PoiGroupUpsertInput;
import com.capgemini.admin.back.model.PoiGroupWriteRequest;

import com.capgemini.admin.back.service.PoiService;
import com.capgemini.admin.back.service.SpaceTypeService;
import com.capgemini.admin.back.service.PoiGroupService;

import lombok.extern.slf4j.Slf4j;


/**
 * Rest Controller for Poi Group
 *
 */
@RestController
@Slf4j
@RequestMapping(value = PoiGroupController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PoiGroupController {

    public static final String ROOT_API = "api/poigroup";

    @Autowired
    private PoiGroupService poiGroupService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private SpaceTypeService spaceTypeService;

    /**
     * Get Pois Groups
     *
     * @param language : language of poi groups
     * @return list of poi groups
     *
     */
    @GetMapping
    public ResponseEntity<List<PoiGroupDTO>> getAll(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<PoiGroup> poiGroups = this.poiGroupService.getOrderedPoiGroups();

        if (Objects.isNull(poiGroups)) {
            return ResponseEntity.internalServerError().build();
        }

        Map<Long, Long> spaceTypeCountByGroup = this.spaceTypeService.countByPoiGroup();
        Map<Long, Long> poisCountByGroup = this.poiService.countByGroup();

        List<PoiGroupDTO> poiGroupDTOs = poiGroups
                .stream()
                .map(poiGroup -> PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language))
                .peek(poiGroupDto -> {
                    if (spaceTypeCountByGroup.containsKey(poiGroupDto.getId())) {
                        poiGroupDto.setSpaceTypeCount(spaceTypeCountByGroup.get(poiGroupDto.getId()));
                    } else {
                        poiGroupDto.setSpaceTypeCount(0l);
                    }

                    if (poisCountByGroup.containsKey(poiGroupDto.getId())) {
                        poiGroupDto.setPoisCount(poisCountByGroup.get(poiGroupDto.getId()));
                    } else {
                        poiGroupDto.setPoisCount(0L);
                    }
                })

                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getById(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @PathVariable Long id) {
        PoiGroup poiGroup = this.poiGroupService.getPoiGroupById(id);
        if (Objects.isNull(poiGroup)) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updatePoiGroup(
            @PathVariable Long id,
            @Valid @RequestBody PoiGroupWriteRequest updatedPoiGroup,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        PoiGroupUpsertInput sanitizedUpdateInput = this.toSanitizedPoiGroupInput(updatedPoiGroup);
        PoiGroup updatedGroup = poiGroupService.updatePoiGroup(id, sanitizedUpdateInput);
        PoiGroupDTO responseDTO = PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(updatedGroup, language);


        responseDTO.setSpaceTypes(
                updatedGroup.getSpaceTypes().stream()
                        .map(spaceType -> SpaceTypeMapper.INSTANCE.spaceTypeToSpaceTypeDTO(spaceType))
                        .collect(Collectors.toList()));

        return ResponseEntity.ok(responseDTO);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePoiGroup(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return ResponseEntity.badRequest().build();
        }
        poiGroupService.deletePoiGroupById(id);
        return ResponseEntity.noContent().build();
    }


    @PostMapping
    public ResponseEntity<Object> create(
            @Valid @RequestBody PoiGroupWriteRequest newPoiGroup,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        PoiGroupUpsertInput sanitizedCreateInput = this.toSanitizedPoiGroupInput(newPoiGroup);
        PoiGroup existingGroup = this.poiGroupService.getByName(sanitizedCreateInput.getName());
        if (Objects.nonNull(existingGroup)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Entity with the same name already exists");
        }

        PoiGroup poiGroup = this.poiGroupService.createPoiGroup(sanitizedCreateInput);

        if (Objects.isNull(poiGroup)) {
            return ResponseEntity.internalServerError().build();
        }
        PoiGroup savedPoiGroup = this.poiGroupService.getPoiGroupById(poiGroup.getId());

        if (savedPoiGroup == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        PoiGroupDTO responseDTO = PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(savedPoiGroup, language);

        responseDTO.setSpaceTypes(
                savedPoiGroup.getSpaceTypes().stream()
                        .map(SpaceTypeMapper.INSTANCE::spaceTypeToSpaceTypeDTO) // Use the SpaceTypeMapper to convert
                                                                                // SpaceType to SpaceTypeDTO
                        .collect(Collectors.toList()));

        return ResponseEntity.ok(responseDTO);
    }

    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<PoiGroupDTO>> getAllByBuildingId(
            @PathVariable Long buildingId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<PoiGroup> poiGroups = this.poiGroupService.getOrderedPoiGroups();
        if (poiGroups == null || poiGroups.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Get the POI count for each PoiGroup and buildingId
        Map<Long, Long> poiCountByGroupAndBuilding = this.poiService.countByTypeAndBuilding(buildingId);

        List<PoiGroupDTO> poiGroupDTOs = poiGroups
                .stream()
                .map(poiGroup -> {
                    PoiGroupDTO poiGroupDTO = PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language);
                    // Check if the PoiGroup has a POI count for the specific building
                    if (poiCountByGroupAndBuilding.containsKey(poiGroupDTO.getId())) {
                        poiGroupDTO.setPoisCount(poiCountByGroupAndBuilding.get(poiGroupDTO.getId()));
                    } else {
                        poiGroupDTO.setPoisCount(0L);
                    }
                    return poiGroupDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOs);
    }

    @GetMapping("/building/{buildingId}/floor/{floorId}")
    public ResponseEntity<List<PoiGroupDTO>> getPoiCountsByBuildingAndFloor(
            @PathVariable Long buildingId,
            @PathVariable Long floorId,
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language) {
        List<PoiGroup> poiGroups = this.poiGroupService.getOrderedPoiGroups();
        if (poiGroups == null || poiGroups.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Get the POI count for each PoiGroup, buildingId, and floorId
        Map<Long, Long> poiCountByGroupAndFloor = this.poiService.countByTypeAndFloorId(buildingId, floorId);

        List<PoiGroupDTO> poiGroupDTOs = poiGroups
                .stream()
                .map(poiGroup -> {
                    PoiGroupDTO poiGroupDTO = PoiGroupMapper.INSTANCE.poiGroupToPoiGroupDTO(poiGroup, language);
                    // Check if the PoiGroup has a POI count for the specific building and floor
                    if (poiCountByGroupAndFloor.containsKey(poiGroupDTO.getId())) {
                        poiGroupDTO.setPoisCount(poiCountByGroupAndFloor.get(poiGroupDTO.getId()));
                    } else {
                        poiGroupDTO.setPoisCount(0L);
                    }
                    return poiGroupDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiGroupDTOs);
    }

    private PoiGroupUpsertInput toSanitizedPoiGroupInput(PoiGroupWriteRequest source) {
        PoiGroupUpsertInput sanitizedInput = new PoiGroupUpsertInput();
        if (source == null) {
            return sanitizedInput;
        }

        sanitizedInput.setName(source.getName() == null ? null : new String(String.valueOf(source.getName())));

        List<String> sanitizedAttributeKeys = new ArrayList<>();
        if (source.getAttributeKeys() != null) {
            source.getAttributeKeys().forEach(attributeKey -> {
                if (attributeKey != null) {
                    sanitizedAttributeKeys.add(new String(String.valueOf(attributeKey)));
                }
            });
        }
        sanitizedInput.setAttributeKeys(sanitizedAttributeKeys);

        Map<String, String> sanitizedAttributes = new HashMap<>();
        if (source.getAttributes() != null) {
            source.getAttributes().forEach((key, value) -> {
                if (Objects.nonNull(key) && Objects.nonNull(value)) {
                    sanitizedAttributes.put(new String(String.valueOf(key)), new String(String.valueOf(value)));
                }
            });
        }
        sanitizedInput.setAttributes(sanitizedAttributes);

        sanitizedInput.setTitleFr(source.getTitleFr() == null ? null : new String(String.valueOf(source.getTitleFr())));
        sanitizedInput.setTitleEn(source.getTitleEn() == null ? null : new String(String.valueOf(source.getTitleEn())));
        sanitizedInput.setIsFromCdm(source.getIsFromCdm() == null
                ? null
                : Boolean.valueOf(String.valueOf(source.getIsFromCdm())));
        sanitizedInput.setIsVisibleOnPWA(source.getIsVisibleOnPWA() == null
                ? null
                : Boolean.valueOf(String.valueOf(source.getIsVisibleOnPWA())));
        sanitizedInput.setIcon(source.getIcon() == null ? null : new String(String.valueOf(source.getIcon())));

        List<Long> sanitizedSpaceTypeIds = new ArrayList<>();
        if (source.getSpaceTypes() != null) {
            source.getSpaceTypes().forEach(spaceTypeInput -> {
                if (spaceTypeInput != null && spaceTypeInput.getId() != null) {
                    sanitizedSpaceTypeIds.add(Long.valueOf(String.valueOf(spaceTypeInput.getId())));
                }
            });
        }
        sanitizedInput.setSpaceTypeIds(sanitizedSpaceTypeIds);

        return sanitizedInput;
    }
}
