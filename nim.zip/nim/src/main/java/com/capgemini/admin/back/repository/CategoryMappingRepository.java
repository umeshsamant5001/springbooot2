package com.capgemini.admin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.admin.back.model.CategoryMapping;

public interface CategoryMappingRepository extends JpaRepository<CategoryMapping, Long> {
    @Query("SELECT DISTINCT cm.category FROM CategoryMapping cm")
    List<String> findDistinctCategories();
}
