package com.capgemini.admin.back.repository;

import com.capgemini.admin.back.model.NotificationSentDetails;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


@Repository
public interface NotificationSentDetailsRepository extends JpaRepository<NotificationSentDetails, Long> {

    boolean existsByNotificationIdAndTokenAndIsSentTrue(Long notificationId, String token);

    List<NotificationSentDetails>  findByNotificationId(Long notificationId);
}
