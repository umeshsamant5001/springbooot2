package com.capgemini.admin.back.model;

import lombok.Data;

@Data
public class CiscoDeviceSPDTO {
    private String deviceId;
    private String poiName;
    private String poiTitle;
    private String poiType;
    private String deviceType;
    private Long lastDataReceived;
    private CiscoDeviceSPAttributes ciscoDeviceAttributes;

    @Data
    public static class CiscoDeviceSPAttributes {
        private String ipAddress;
        private Integer peopleCount;
        private Double ambientNoiseDba;
        private Double soundLevelDba;
        private Double ambientTemperature;
        private Double relativeHumidity;
        private Double airQuality;
    }
}
