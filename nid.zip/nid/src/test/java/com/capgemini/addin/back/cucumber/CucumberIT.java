package com.capgemini.addin.back.cucumber;

import com.capgemini.addin.back.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
