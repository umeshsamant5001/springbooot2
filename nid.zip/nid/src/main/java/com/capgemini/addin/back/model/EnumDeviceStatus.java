/**
 *
 */
package com.capgemini.addin.back.model;

/**
 * Enum type use to represent the state of a device
 *
 * @author alcarpen
 *
 */
public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}
