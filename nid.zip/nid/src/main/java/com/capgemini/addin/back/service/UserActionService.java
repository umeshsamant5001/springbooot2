package com.capgemini.addin.back.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.addin.back.config.GraphHelper;
import com.capgemini.addin.back.model.UserAction;
import com.capgemini.addin.back.repository.CountryMappingProjection;
import com.capgemini.addin.back.repository.CountryMappingRepository;
import com.capgemini.addin.back.repository.UserActionRepository;
import com.microsoft.graph.requests.GraphServiceClient;
import com.capgemini.addin.back.model.CountryMapping;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import com.microsoft.graph.models.User;

@Service
@Slf4j
public class UserActionService {
    
    @Autowired

    private UserActionRepository userActionRepository;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private CountryMappingRepository countryMappingRepository;

    public UserAction saveAction(UserAction userAction) {
        return userActionRepository.save(userAction);
    }
    
    /**
	 * Return the value of an attribut as a String.
	 * @param userEmail	 
	 * @return String
	 */
    private String getUserCountryByEmail(String userEmail) {
        GraphServiceClient<?> client = graphHelper.getInstance();
        
        String select = "id,displayName,mail,userPrincipalName,country,usageLocation,officeLocation";

        try {
            User user = client.users(userEmail)
                    .buildRequest()
                    .select(select)
                    .get();

            if (user == null) return null;

            if (user.country != null && !user.country.isBlank()) {
                log.info("Graph user country for {}: {}", userEmail, user.country);
                return user.country; 
            }
           
            return null;
        } catch (com.microsoft.graph.core.ClientException ex) {
            // 404 if user not found, 403 if permissions missing, etc.
            log.error("Graph get user failed for {}: {}", userEmail, ex.getMessage(), ex);
            return null; // or rethrow a custom exception
        }
    }

    // public Long getCountryId(String countryName){
    //     if(countryName == null)
    //         return null;
    //     List<Object[]> countryObjList = userActionRepository.findCountryByName(countryName);        
    //     if (!countryObjList.isEmpty()) {
    //         Object[] row = countryObjList.get(0);
    //         Long id = ((Number) row[0]).longValue();    // column index 0 = id
    //         return id;
    //     }
    //     return null;   
    // }
    
    /**
	 * Return the value of an attribut as a String.
	 * @param userEmail	 
	 * @return Optional<Long> country ID
	 */
    private Optional<Long> getCountryId(String countryName) {
        log.info("Looking up country ID for country name: {}", countryName);
        if (countryName == null) {
            return Optional.empty();
        }

        List<Object[]> countryObjList =
            userActionRepository.findCountryByName(countryName);
            
        if (!countryObjList.isEmpty()) {
                Long id = ((Number) countryObjList.get(0)[0]).longValue();
                return Optional.of(id);
        }
        return Optional.empty();
    }

    private Optional<CountryMappingProjection> getCountryMapping(String countryName) {
        log.warn("Country '{}' not found in database, checking mapping...", countryName);
        return  countryMappingRepository.findCountryDetails(countryName);
    }

    /**
	 * Return the value of an attribut as a String.
	 * @param userEmail	 
	 * @return UserAction
	 */
    public UserAction createUserAction(String userEmail) {
        try {
            // Validate email
            if (userEmail == null || userEmail.trim().isEmpty()) {
                throw new IllegalArgumentException("User email is required");
            }

            String email = userEmail.trim();
            
            // Get country name by email
            String countryName = getUserCountryByEmail(email);
            if (countryName == null || countryName.trim().isEmpty()) {
                throw new IllegalArgumentException("No country found in MS Graph for email: " + email);
            }

            // Create and save user action
            UserAction userAction = new UserAction();
            // Get country ID
            Optional<Long> countryIdOpt = getCountryId(countryName);
            Long countryId = null;
            if(countryIdOpt.isPresent()) {
                log.info("Country '{}' found in country table.", countryName);
                countryId = countryIdOpt.get();
                userAction.setCountryId(countryId);
                userAction.setCountryName(countryName.trim());
            } else {
                // If country ID not found, check mapping
                log.info("Country '{}' not found in country table", countryName);
                Optional<CountryMappingProjection> countryMappingOpt = getCountryMapping(countryName);
                if (countryMappingOpt.isPresent()) {
                    countryId = countryMappingOpt.get().getCountryId();
                    userAction.setCountryId(countryId);
                    userAction.setCountryName(countryMappingOpt.get().getTitleEn().trim());
                } else {
                    throw new IllegalArgumentException("No country ID found for country in Mapping: " + countryName);
                }
            }
            
            userAction.setUserEmail(email);
            userAction.setLoggedInTime((new Date()).getTime() / 1000);

            return userActionRepository.save(userAction);

        } catch (IllegalArgumentException ex) {
            log.warn(ex.getMessage());
            throw ex;
        } catch (Exception e) {
            log.error("Error saving user action", e);
            throw new RuntimeException("Error saving user action", e);
        }
    }
    
}
