package com.capgemini.addin.back.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@ToString
public class Attendee implements Serializable {
    private String qualification;
    private Boolean isExternal;
    private Human participant;

    public void applyQualification(QualificationEnum value) {
        this.qualification = value.toString();
    }

    public QualificationEnum computeQualificationEnum() {
        return QualificationEnum.fromValue(qualification);
    }

    public static class AttendeeBuilder {
        public AttendeeBuilder withQualificationEnum(QualificationEnum value) {
            this.qualification = value.toString();
            return this;
        }
    }
}
