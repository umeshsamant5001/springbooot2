package com.capgemini.addin.back.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class SensorDataDTO implements Serializable {
	private String uuid;
	private String deviceType;
	private String poiName;
	private Long cdmKeyIdPoi;
	private Long cdmKeyIdFloor;
	private String lastChange;
	private Double battery;
	private String status;
	private Double tempC;
	private Double tempF;
	private Double co2;
	private Double humidity;
	private Double noise;
	private Double light;
	private String occupation;
    private Double apparentTemp;
}
