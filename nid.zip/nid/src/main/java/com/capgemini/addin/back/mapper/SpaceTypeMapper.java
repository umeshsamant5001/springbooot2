package com.capgemini.addin.back.mapper;

import java.util.List;

import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.capgemini.addin.back.model.SpaceType;
import com.capgemini.addin.back.model.SpaceTypeDTO;

@Named("SpaceTypeMapper")
public interface SpaceTypeMapper {

    SpaceTypeMapper INSTANCE = Mappers.getMapper(SpaceTypeMapper.class);

    @Mapping(source = "poiGroup.id", target = "poiGroupId") // Explicitly map poiGroupId
    SpaceTypeDTO spaceTypeToSpaceTypeDTO(SpaceType spaceType);

    @Mapping(target = "poiGroup", ignore = true) // Ignore full PoiGroup in the reverse mapping
    SpaceType spaceTypeDTOToSpaceType(SpaceTypeDTO spaceTypeDTO);



    List<SpaceTypeDTO> spaceTypesToSpaceTypeDTOs(List<SpaceType> spaceTypes);
}
