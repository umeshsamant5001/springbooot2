package com.capgemini.addin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.capgemini.addin.back.config.GraphHelper;
import com.capgemini.addin.back.mapper.PoiControllerMapper;
import com.capgemini.addin.back.mapper.PoiMapper;
import com.capgemini.addin.back.model.Poi;
import com.capgemini.addin.back.model.PoiDTO;
import com.capgemini.addin.back.model.PoiSensorDataDTO;
import com.capgemini.addin.back.model.RoomSearchParameters;
import com.capgemini.addin.back.model.SpaceType;
import com.capgemini.addin.back.repository.SpaceTypeRepository;
import com.capgemini.addin.back.service.GraphGetRoomsAvailableService;
import com.capgemini.addin.back.service.PoiService;
import com.capgemini.addin.back.model.Attendee;
import com.capgemini.addin.back.model.Human;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = PoiController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class PoiController {

    static final String ROOT_API = "api/poi";
    static final String ROOM_CONFERENCE = "room_conference";
    static final String ROOM_BUBBLE = "room_bubble";
    static final String CATEGORY_BOOKABLE = "bookable";
    static final String CATEGORY_ROOM_BOOKABLE = "room_bookable";
    public static final String CONF_ROOM_MAIL = "conf_room_mail";
	private final static Long NINETEEN_HOUR = 68_400L;
    private static final String CAPACITY = "capacity";

    @Autowired
    PoiService poiService;

    @Autowired
    SpaceTypeRepository spaceTypeRepository;

    @Autowired
    private GraphGetRoomsAvailableService graphGetRoomsAvailable;

    @Autowired
    private GraphHelper graphHelper;

    @Autowired
    private PoiControllerMapper poiControllerMapper;

    @PostMapping("/suggestions")
	public ResponseEntity<?> getSuggestions(
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
		    @RequestBody RoomSearchParameters searchParams) {
        
        Long startTime = System.currentTimeMillis();
        log.info("StartTime for /suggestions api >> " + startTime);

        Long floorId = null;
        List<String> categoryList = List.of(CATEGORY_ROOM_BOOKABLE);
        List<SpaceType> spaceTypeList = this.spaceTypeRepository.findByCategory(categoryList);
        List<String> spaceTypeNameList = spaceTypeList.stream().map(SpaceType::getSpaceTypeName).collect(Collectors.toList());

        List<PoiSensorDataDTO> confrooms = new ArrayList<PoiSensorDataDTO>();
        Integer minimumCapacity = searchParams.getMinimumCapacity();
        Integer maximumCapacity;
        if (Objects.isNull(searchParams.getMaximumCapacity()))
            maximumCapacity = 100;
        else {
            maximumCapacity = searchParams.getMaximumCapacity();
        }
        if (!Objects.isNull(searchParams.getFloorIndex())) {
            floorId = Long.valueOf(searchParams.getFloorIndex());
        }
		// Get list of Poi
		confrooms = poiService.getPoisAddIn(language, floorId,spaceTypeNameList,Long.valueOf(searchParams.getBuildingId()));
        confrooms = confrooms.stream()
        .filter(p -> {
            String capacityStr = p.getAttributes().get(PoiController.CAPACITY);
            if (capacityStr == null) {
                return false; // Skip if capacity is null
            }
            try {
                int capacity = Integer.parseInt(capacityStr);
                return minimumCapacity <= capacity && capacity <= maximumCapacity;
            } catch (NumberFormatException e) {
                return false; // Skip if capacity is not a valid number
            }
        })
        .collect(Collectors.toList());

        Long endTime = System.currentTimeMillis();
        log.info("EndTime for /suggestions api  " + endTime);
        Long acutalTime = (endTime - startTime);
        log.info("AcutalTime taken time for /suggestions api >>>  " + acutalTime);
		// Convert list of Poi to list of PoiMobileDTO
		return ResponseEntity.ok(graphGetRoomsAvailable.getListDaySuggestionsWindow(searchParams, confrooms));
	}

    @GetMapping("/suggestionsTest")
	public ResponseEntity<?> getSuggestionsTest(
			@RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language)
		{
        log.info("Inside /suggestionsTest api");
        RoomSearchParameters searchParamsTest = new RoomSearchParameters();
        searchParamsTest.setBuildingId("2701");
        searchParamsTest.setFloorIndex(null);
        searchParamsTest.setMinimumCapacity(2);
        searchParamsTest.setMaximumCapacity(100);
        BigDecimal startTimeForTest = new BigDecimal(1783359000);
        searchParamsTest.setStartTime(startTimeForTest);
        searchParamsTest.setDuration(new BigDecimal(0.5));
        searchParamsTest.setFloorIndex(8280);
        searchParamsTest.setBuildingJavaZone("Europe/Paris");
        searchParamsTest.setCheckDisponibility(false);
        Attendee attendee1 = new Attendee();
        Human human1 = new Human();
        human1.setEmail("umesh.samant.ext@capgemini.com");
        attendee1.setParticipant(human1);
        attendee1.setQualification("organizer");

        Attendee attendee2 = new Attendee();
        Human human2 = new Human();
        human2.setEmail("umesh.samant.ext@capgemini.com");
        attendee2.setParticipant(human2);
        attendee2.setQualification("organizer");
        List<Attendee> attendees = new ArrayList<>();
        attendees.add(attendee1);
        attendees.add(attendee2);
        searchParamsTest.setAttendees(attendees);

        Long startTime = System.currentTimeMillis();
        log.info("StartTime for /suggestions api >> " + startTime);
        

        Long floorId = null;
        List<String> categoryList = List.of(CATEGORY_ROOM_BOOKABLE);
        List<SpaceType> spaceTypeList = this.spaceTypeRepository.findByCategory(categoryList);
        List<String> spaceTypeNameList = spaceTypeList.stream().map(SpaceType::getSpaceTypeName).collect(Collectors.toList());

        List<PoiSensorDataDTO> confrooms = new ArrayList<PoiSensorDataDTO>();
        Integer minimumCapacity = searchParamsTest.getMinimumCapacity();
        Integer maximumCapacity;
        if (Objects.isNull(searchParamsTest.getMaximumCapacity()))
            maximumCapacity = 100;
        else {
            maximumCapacity = searchParamsTest.getMaximumCapacity();
        }
        if (!Objects.isNull(searchParamsTest.getFloorIndex())) {
            floorId = Long.valueOf(searchParamsTest.getFloorIndex());
        }
		// Get list of Poi
		confrooms = poiService.getPoisAddIn(language, floorId,spaceTypeNameList,Long.valueOf(searchParamsTest.getBuildingId()));
        confrooms = confrooms.stream()
        .filter(p -> {
            String capacityStr = p.getAttributes().get(PoiController.CAPACITY);
            if (capacityStr == null) {
                return false; // Skip if capacity is null
            }
            try {
                int capacity = Integer.parseInt(capacityStr);
                return minimumCapacity <= capacity && capacity <= maximumCapacity;
            } catch (NumberFormatException e) {
                return false; // Skip if capacity is not a valid number
            }
        })
        .collect(Collectors.toList());

        Long endTime = System.currentTimeMillis();
        log.info("EndTime for /suggestions api  " + endTime);
        Long acutalTime = (endTime - startTime);
        log.info("AcutalTime taken time for /suggestions api >>>  " + acutalTime);
		// Convert list of Poi to list of PoiMobileDTO
		return ResponseEntity.ok(graphGetRoomsAvailable.getListDaySuggestionsWindow(searchParamsTest, confrooms));
	}

    @GetMapping("meeting")
    public ResponseEntity<List<PoiDTO>> getMeetingRoom(
        @RequestParam(required = false) Long buildingId,
        @RequestParam(required = false) Long floorId,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        List<String> categoryList = List.of(CATEGORY_BOOKABLE);

        List<SpaceType> spaceTypeList;
        spaceTypeList = this.spaceTypeRepository.findByCategory(categoryList);
        List<String> spaceTypeNameList = spaceTypeList.stream().map(SpaceType::getSpaceTypeName).collect(Collectors.toList());

        // Define a function that return the list of Poi
        Supplier<List<Poi>> func;
        if (Objects.nonNull(floorId)) {
            func = () -> this.poiService.findAllByFloorIdAndSpaceType(floorId, spaceTypeNameList);
        } else if (Objects.nonNull(buildingId)) {
            func = () -> this.poiService.findAllByBuildingIdAndSpaceType(buildingId, spaceTypeNameList);
        } else {
            // Error, one of the parameters à required.
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "One of \"buildingId\" or \"floorId\" is required");
        }

        List<PoiDTO> poiDTOList = func.get().stream().map(poi -> PoiMapper.INSTANCE.poiToPoiDTONoJoin(poi)).collect(Collectors.toList());

        return ResponseEntity.ok(poiDTOList);
    }

    
/**
 * REST endpoint to fetch free POIs (Points of Interest) by building ID and optional POI groups.
 * Filters POIs based on sensor data and reservation status.
 *
 * @param buildingId   ID of the building to fetch POIs for.
 * @param poiGroups    Optional list of POI groups to filter.
 * @param language     Language preference from request header, defaults to "en".
 * @return             List of POI sensor data DTOs that are free and available.
 */
    @GetMapping("building/{buildingId}")
    @Transactional
    public ResponseEntity<List<PoiSensorDataDTO>> getPoiByFloor(
        @PathVariable Long buildingId,
        @RequestParam(required = false) List<String> poiGroups,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        List<String> categoryList = List.of(CATEGORY_BOOKABLE);
        List<SpaceType> spaceTypeList = spaceTypeRepository.findByCategory(categoryList);
        List<String> spaceTypeNameList = spaceTypeList.stream()
                .map(SpaceType::getSpaceTypeName)
                .collect(Collectors.toList());

        List<PoiSensorDataDTO> poiDTOList = poiService.getFreePois(buildingId, spaceTypeNameList)
                .stream()
                .map(poi -> poiControllerMapper.convertEntityToMobileDto(poi))
                .filter(poi -> {
                    boolean isFreeBySensor = "free".equalsIgnoreCase(poi.getSensorData().getOccupation());
                    if (!isFreeBySensor) {
                        log.info("POI [{}] is not free based on sensor data", poi.getId());
                        return false;
                    }

                    String category = poi.getSpaceType().getSpaceTypeName();
                    if ("phonebooth".equalsIgnoreCase(category) || "bubble".equalsIgnoreCase(category)) {
                        log.info("POI [{}] is a [{}] and free by sensor", poi.getId(), category);
                        return true;
                    }

                    String roomEmail = poi.getAttributes().get(CONF_ROOM_MAIL);
                    if (roomEmail == null || roomEmail.isBlank()) {
                        log.warn("POI [{}] with name [{}] has no room email configured. Category: [{}]",
                                poi.getId(),
                                poi.getName(),
                                category);
                        return false;
                    }

                    boolean isReserved = graphHelper.isRoomReservedNow(roomEmail);
                    if (isReserved) {
                        log.info("POI [{}] is free by sensor but reserved in Graph for room [{}]", poi.getId(),
                                roomEmail);
                        return false;
                    } else {
                        log.info("POI [{}] is free by sensor and not reserved in Graph for room [{}]", poi.getId(),
                                roomEmail);
                        return true;
                    }
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(poiDTOList);
    }
}
