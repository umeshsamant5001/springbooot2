package com.capgemini.addin.back.repository;

public interface CountryMappingProjection {

    Long getCountryId();
    String getTitleEn();

}
