package com.capgemini.addin.back.config;

import java.net.URL;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

import org.joda.time.DateTime;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.core.ClientException;
import com.microsoft.graph.http.GraphServiceException;
import com.microsoft.graph.models.CalendarGetScheduleParameterSet;
import com.microsoft.graph.models.DateTimeTimeZone;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.ScheduleInformation;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.options.Option;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.requests.CalendarGetScheduleCollectionPage;
import com.microsoft.graph.requests.CalendarGetScheduleCollectionRequestBuilder;
import com.microsoft.graph.requests.EventCollectionPage;
import com.microsoft.graph.requests.EventCollectionRequestBuilder;
import com.microsoft.graph.requests.GraphServiceClient;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class GraphHelper {

    @Autowired
    private ApplicationProperties applicationProperties;

    private GraphServiceClient mClient;

    public GraphServiceClient getInstance() {
		if (Objects.isNull(mClient)) {
			List<String> scopes = Arrays.asList(applicationProperties.getGraphApi().getScopeUrl());
			ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
					.tenantId(applicationProperties.getGraphApi().getTenantId())
                    .clientId(applicationProperties.getGraphApi().getClientId())
					.clientSecret(applicationProperties.getGraphApi().getClientSecret())
                    .build();
			TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(scopes, clientSecretCredential);

			try {
				URL meUrl = new URL(applicationProperties.getGraphApi().getUrl());
				log.info("Graph Token {}", authProvider.getAuthorizationTokenAsync(meUrl).get());
			} catch (Exception ex) {
                log.error("Graph error {}", ex);
			}
			mClient = GraphServiceClient.builder().authenticationProvider(authProvider).buildClient();
        }
        return mClient;
    }

    /**
     * Delete an event by id
     * 
     * @idEvent : id of event we need to delete
     * @return nothing if successful
    */
    public Event deleteEventById(String mail, String idEvent) throws ClientException {
        return this.getInstance().users(mail).calendar().events(idEvent).buildRequest().delete();
    }

	/**
     * Get a list of events between two ZonedDateTime
     * 
     * @param viewStart : start of DateTime
     * @param viewEnd : end of DateTime
     * @param timeZone : timezone
     * @param room : poi mail
     * @return list of events
    */
    public CompletableFuture<List<Event>> getCalendarView(long start, long end, String timeZone, String room) {
		final List<Option> options = new LinkedList<>();
        MutableDateTime dateTimeStart = new MutableDateTime(start * 1000);
		MutableDateTime dateTimeEnd = new MutableDateTime(end * 1000);

        log.info("date used for graph API : " + dateTimeStart.toString() + " | " + dateTimeEnd.toString());

        options.add(new QueryOption("startDateTime", dateTimeStart.toString()));
        options.add(new QueryOption("endDateTime", dateTimeEnd.toString()));
        // Start and end times adjusted to user's time zone
        options.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

        final List<Event> allEvents = new LinkedList<Event>();
        // Create a separate list of options for the paging requests
        // paging request should not include the query parameters from the initial
        // request, but should include the headers.
        final List<Option> pagingOptions = new LinkedList<Option>();
        pagingOptions.add(new HeaderOption("Prefer", "outlook.timezone=\"UTC\""));

        return this.getInstance()
            .users(room)
            .calendarView()
            .buildRequest(options)
            .getAsync()
            .thenCompose(eventPage -> processPageEvent(eventPage, allEvents, pagingOptions));
    }

    /**
     * Process each page and return a list of events
     * 
     * @param currentPage
     * @param eventList
     * @param options
     * @return CompletableFuture<List<Event>>
    */
    private CompletableFuture<List<Event>> processPageEvent(EventCollectionPage currentPage, List<Event> eventList, List<Option> options) {
        eventList.addAll(currentPage.getCurrentPage());
        // Check if there is another page of results
        EventCollectionRequestBuilder nextPage = currentPage.getNextPage();
        if (nextPage != null) {
            // Request the next page and repeat
            return nextPage.buildRequest(options)
                .getAsync()
                .thenCompose(eventPage -> processPageEvent(eventPage, eventList, options));
        } else {
            // No more pages, complete the future
            // with the complete list
            return CompletableFuture.completedFuture(eventList);
        }
    }
        /**
     * Retrieve the schedules of each email in the schedulesList
     * 
     * @param start
     * @param end
     * @param timezone
     * @param schedulesList
     * @param mail
     * @return list of ScheduleInformation
    */
    public CompletableFuture<List<ScheduleInformation>> getSchedule(DateTime start, DateTime end, List<String> schedulesList, String mail) {

        DateTimeTimeZone startTime = new DateTimeTimeZone();
        startTime.dateTime = start.toString().split("\\+")[0];
        startTime.timeZone = "UTC";

        DateTimeTimeZone endTime = new DateTimeTimeZone();
        endTime.dateTime = end.toString().split("\\+")[0];
        endTime.timeZone = "UTC";

        int availabilityViewInterval = 5;

        final List<ScheduleInformation> allScheduleInformation = new LinkedList<ScheduleInformation>();

        return this.getInstance().users(mail)
            .calendar()
            .getSchedule(CalendarGetScheduleParameterSet
                .newBuilder()
                .withSchedules(schedulesList)
                .withEndTime(endTime)
                .withStartTime(startTime)
                .withAvailabilityViewInterval(availabilityViewInterval)
                .build())
            .buildRequest()
            .postAsync()
            .thenCompose(schedulePage -> processPageSchedule(schedulePage, allScheduleInformation));
    }

    /**
     * Process each page and return a list of ScheduleInformation
     * 
     * @param currentPage
     * @param allScheduleInformation
     * @return list of ScheduleInformation
    */
    private CompletableFuture<List<ScheduleInformation>> processPageSchedule(CalendarGetScheduleCollectionPage currentPage, List<ScheduleInformation> allScheduleInformation) {
        allScheduleInformation.addAll(currentPage.getCurrentPage());
        // Check if there is another page of results
        CalendarGetScheduleCollectionRequestBuilder nextPage = currentPage.getNextPage();
        if (Objects.nonNull(nextPage)) {
            // Request the next page and repeat
            return nextPage.buildRequest()
                .postAsync()
                .thenCompose(schedulePage -> processPageSchedule(schedulePage, allScheduleInformation));
        } else {
            // No more pages, complete the future
            // with the complete list
            return CompletableFuture.completedFuture(allScheduleInformation);
        }
    }


/**
 * Checks if a room is currently reserved by querying calendar events via Graph API.
 * The check is performed for the next 2 minutes from the current UTC time.
 *
 * @param roomEmail The email address of the room to check reservation status for.
 * @return true if the room has any events scheduled in the next 2 minutes, false otherwise.
 */
    public boolean isRoomReservedNow(String roomEmail) {
        if (roomEmail == null || roomEmail.isBlank()) {
            log.warn("Graph reservation check skipped: room email is missing or blank.");
            return false; // or true, depending on your policy
        }
        // Check mail box exists.
        // if (!userExists(roomEmail)) {
        //     log.info("Room mailbox {} not found (users() 404/403).", roomEmail);
        //     return false;
        // }

        try {
            ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
            ZonedDateTime twoMinuteLater = now.plusMinutes(2);

            long startEpoch = now.toEpochSecond();
            long endEpoch = twoMinuteLater.toEpochSecond();

            log.info("Checking reservation for room [{}] between [{}] and [{}] (epoch)", roomEmail, startEpoch,
                    endEpoch);

            List<Event> events = getCalendarView(startEpoch, endEpoch, "UTC", roomEmail).get();

            if (events != null && !events.isEmpty()) {
                log.info("Room [{}] has {} event(s) scheduled in the next 2 minutes", roomEmail, events.size());
                return true;
            } else {
                log.info("Room [{}] has no events scheduled in the next 2 minutes", roomEmail);
                return false;
            }
        } catch (Exception e) {
            log.error("Graph reservation check failed for room [{}]: {}", roomEmail, e.getMessage(), e);
            return false; // fail-safe: assume not reserved to avoid false negatives
        }
    }

    /**
     * @param roomEmail email associated with meeting room
     * @return true if mail box exists.
    */
    public boolean userExists(String roomEmail) {
        try {
            getInstance().users(roomEmail).buildRequest().get();
            return true;
        } catch (GraphServiceException gse) {
            Integer status = gse.getResponseCode();
            // 404 - not found; 403 -caller not allowed to read user profile (rare in app perms)
            log.warn("users({}) probe failed: status={}, message={}", roomEmail, status, gse.getMessage());
            return false;
        } catch (Exception e) {
            log.error("users({}) probe unexpected error: {}", roomEmail, e.getMessage(), e);
            return false;
        }
    }


    

}
