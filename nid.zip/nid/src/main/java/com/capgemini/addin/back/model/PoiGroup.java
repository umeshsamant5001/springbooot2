package com.capgemini.addin.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MapKeyColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.capgemini.addin.utils.LazyFieldsFilter;
import com.capgemini.addin.utils.StringListConverter;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "poi_group")
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class PoiGroup implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "POIGroup_Generator")
	@SequenceGenerator(name = "POIGroup_Generator", sequenceName = "POIGroup_Sequence")
	private Long id;

	@Column(name = "name", nullable = false, unique = true)
	private String name;

	@Lob
	@Column @Convert(converter = StringListConverter.class)
	private List<String> attributeKeys;

	@CollectionTable(name = "poi_group_attribute")
	@ElementCollection(fetch=FetchType.EAGER)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<>();

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

    @Column(name = "is_cdm")
	private Boolean isFromCdm;

}
