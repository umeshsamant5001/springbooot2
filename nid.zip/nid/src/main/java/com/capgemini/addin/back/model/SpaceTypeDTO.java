package com.capgemini.addin.back.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class SpaceTypeDTO {

        private Long id;
        private Long poiGroupId;
        private String spaceCategoryName;
        private String spaceTypeName;
        private List<String> attributeKeys;
        private String titleFr;
        private String titleEn;
        private Long poisCount;
        private Boolean isFromCdm;
        private Map<String, String> attributes = new HashMap<>();
        private List<PoiDTO> pois;
        private String poiGroupName;
}
