package com.capgemini.addin.back.config;

public class DbConfig {

	public static final String BIGINT_DEFAULT_DEFINITION_H2 = "bigint default datediff('s', '1970-01-01', now())";
	private static final String BIGINT_DEFAULT_DEFINITION_POSTGRES = "bigint DEFAULT extract(epoch from now())";
	private static final String BIGINT_DEFAULT_DEFINITION_MSSQL= "bigint DEFAULT DATEDIFF_BIG(MILLISECOND, '1970-01-01', GETUTCDATE())";
    public static final String BIGINT_DEFAULT_DEFINITION = BIGINT_DEFAULT_DEFINITION_MSSQL;

}
