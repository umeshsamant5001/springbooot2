package com.capgemini.addin.back.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.addin.back.controller.PoiController;
import com.capgemini.addin.back.mapper.PoiControllerMapper;
import com.capgemini.addin.back.mapper.PoiMapper;
import com.capgemini.addin.back.model.Equipment;
import com.capgemini.addin.back.model.Poi;
import com.capgemini.addin.back.model.PoiDTO;
import com.capgemini.addin.back.model.PoiSensorDataDTO;
import com.capgemini.addin.back.repository.FloorRepository;
import com.capgemini.addin.back.repository.PoiGroupRepository;
import com.capgemini.addin.back.repository.PoiRepository;
import com.capgemini.addin.utils.Pair;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiService {

    public static final String POI_CACHE_NAME = "poiCache";
    private static final String URL_ARRAY_SEP = "%2C";

    @Autowired
    private PoiControllerMapper poiControllerMapper;
    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private FloorRepository floorRepository;

    @Autowired
    private PoiGroupRepository poiGroupRepository;

    @PersistenceContext
    private EntityManager em;

    /***
     * Create a poi
     * @param poi
     * @return
     */
    public Poi createPoi(Poi poi) {
        poi.setModifiedAt((new Date()).getTime() / 1000);
        Poi save = null;
        try {
            save = this.poiRepository.save(poi);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return save;
    }



    /**
     * Return all Poi of a Building
     * @param buildingId The id of the Building
     * @param poiGroupList A list of PoiGroup's name to filter.
     * @return All the Poi of the associated Building, filtered to the poiGroupList if present.
     */

    public List<Poi> findAllByBuildingIdAndSpaceType(Long buildingId, List<String> spaceTypeList) {
        List<Poi> pois = Objects.isNull(spaceTypeList) || spaceTypeList.isEmpty()
                         ? this.poiRepository.findAllByBuildingId(buildingId)
                         : this.poiRepository.findAllByBuildingIdAndSpaceTypeList(buildingId, spaceTypeList);

        // Filter out POIs without a valid conf_room_mail
        return pois.stream()
                   .filter(poi -> {
                       String email = poi.getAttributes().get(PoiController.CONF_ROOM_MAIL);
                       return email != null && !email.trim().isEmpty();
                   })
                   .collect(Collectors.toList());
    }

    /**
     * Return all Poi of a Floor
     * @param floorId The id of the Floorp
     * @param excludePoiGroup A list of PoiGroup's name to exclude
     * @return All the Poi of the associated Floor, except to the excludePoiGroup if present.
     */
    public List<Poi> findAllByFloorId(Long floorId, List<String> excludePoiGroup) {
        if (Objects.isNull(excludePoiGroup) || excludePoiGroup.isEmpty()) {
            return this.poiRepository.findAllByFloorId(floorId);
        }

        return this.poiRepository.findAllByFloorIdExcludePoiGroup(floorId, excludePoiGroup);
    }

    /**
     * Return all Poi of a Floor
     * @param floorId The id of the Floor
     * @param poiGroupList A list of PoiGroup's name to filter.
     * @return All the Poi of the associated Floor, filtered to the poiGroupList if present.
     */

    public List<Poi> findAllByFloorIdAndSpaceType(Long floorId, List<String> spaceType) {
        List<Poi> pois = Objects.isNull(spaceType) || spaceType.isEmpty()
                         ? this.poiRepository.findAllByFloorId(floorId)
                         : this.poiRepository.findAllByFloorIdAndSpaceTypeName(floorId, spaceType);

        // Filter out POIs without a valid conf_room_mail
        return pois.stream()
                   .filter(poi -> {
                       String email = poi.getAttributes().get(PoiController.CONF_ROOM_MAIL);
                       return email != null && !email.trim().isEmpty();
                   })
                   .collect(Collectors.toList());
    }

    public Poi getById(long poiId) {
        return this.poiRepository.findById(poiId).orElse(null);
    }

    public Function<List<Poi>, List<PoiDTO>> poiListToPoiDTOList() {
        return in -> in.stream().map(toPoiDTO()).collect(Collectors.toList());
    }

    public Function<Poi, PoiDTO> toPoiDTO() {
        return PoiMapper.INSTANCE::poiToPoiDTO;
    }
    
    //@Cacheable(value = "poisAddIns", key = "(#floorId != null ? #floorId : 'nullFloorId') + '_' + #buildingId")
    public List<PoiSensorDataDTO> getPoisAddIn( 
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
        @RequestParam(required = false) Long floorId, //
        @RequestParam(required = false) List<String> spaceTypeList, //
        @RequestParam(required = true) Long buildingId
    ) {
        //List<Poi> pois = new ArrayList<>();
        List<Object[]> pois = new ArrayList<>();
        if (Objects.isNull(floorId) && Objects.isNull(buildingId)) {
            // If none of Floor / Site / Building / Poi Ids are provided, return an empty
            // list
            // Avoid performance issue requesting entire database
            return  new ArrayList<>();
        }
        try {
            if (!Objects.isNull(floorId)) {
                log.info("getPoisAddIn: floorId = " + floorId + ", spaceTypeList = " + spaceTypeList);
                pois = poiRepository.findAllBySpaceTypeAndFloorId(spaceTypeList,floorId);
            } else {
                long startTime = new Date().getTime();
                //log.info("starttime "+ startTime);
                log.info("getPoisAddIn: buildingId = " + buildingId + ", spaceTypeList = " + spaceTypeList);
                pois = poiRepository.findAllBySpaceTypeAndFloorBuildingId(spaceTypeList,buildingId);
                log.info("duration "+ (new Date().getTime() - startTime));
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        List<PoiSensorDataDTO> confrooms = new ArrayList<PoiSensorDataDTO>();
		log.info("size of Poi list : " + pois.size());
		for(Object[] poiArray : pois) {

            Long poiId = ((Number) poiArray[0]).longValue();
            String deviceType = (String) poiArray[1];

			Poi poi = poiRepository.findById(poiId).orElse(null);
            if(poi == null) {
                log.warn("POI with ID {} not found in the database.", poiId);
                continue;
            }
            PoiSensorDataDTO dto =
                poiControllerMapper.convertEntityToMobileDtoNoSensor(poi);
            
            dto.setDeviceType(deviceType); // add field if needed

			//confrooms.add(poiControllerMapper.convertEntityToMobileDtoNoSensor(poi));
            confrooms.add(dto);

		}
        return confrooms;
    }

    public List<Poi> filterPoisByEquipmentAND(List<Poi> pois, @RequestParam(required = false) List<String> equipments) {
        pois =
            pois
                .stream() //
                .filter(i -> {
                    for (String expected : equipments) {
                        String expectedName = expected.toLowerCase();
                        boolean contains = false;
                        for (Equipment actual : i.getEquipments()) {
                            if (actual.getName() == null) break;
                            String actualName = (actual.getName() == null ? null : actual.getName().toLowerCase());
                            if (expectedName.equals(actualName)) contains = true;
                        }
                        if (!contains) return false;
                    }
                    return true;
                }) //
                .collect(Collectors.toList());
        return pois;
    }

    private List<Poi> filterPoisByAttribute(
        List<Poi> pois,
        @RequestParam(name = "attribute.key", required = false) String attributeKey,
        @RequestParam(name = "attribute.value", required = false) String attributeValue,
        @RequestParam(name = "attribute.value.greaterThanEqual", required = false) Double attributeValueGreaterThanEqual
    ) {
        if (Objects.isNull(attributeKey)) return pois;
        if (!Objects.isNull(attributeValue)) {
            Pair<String, String> criteria = new Pair<>(attributeKey, attributeValue);
            pois =
                pois
                    .stream() //
                    .filter(i -> {
                        for (Map.Entry<String, String> e : i.getAttributes().entrySet()) if (
                            criteria.getKey().equals(e.getKey()) && criteria.getValue().equals(e.getValue())
                        ) return true;
                        return false;
                    }) //
                    .collect(Collectors.toList());
        }
        if (null != attributeValueGreaterThanEqual) {
            Pair<String, Double> criteria = new Pair<>(attributeKey, attributeValueGreaterThanEqual);
            pois =
                pois
                    .stream() //
                    .filter(i -> {
                        for (Map.Entry<String, String> e : i.getAttributes().entrySet()) if (
                            criteria.getKey().equals(e.getKey()) && !Objects.isNull(criteria.getValue())
                        ) {
                            Double value = Double.valueOf(e.getValue());
                            if (value >= criteria.getValue()) return true;
                        }
                        return false;
                    }) //
                    .collect(Collectors.toList());
        }
        return pois;
    }

    public List<Poi> getFreePois(Long buildingId,List<String> spaceTypeNames) {
        return poiRepository.findAllFreePoisInType(buildingId,spaceTypeNames);
    }
}

