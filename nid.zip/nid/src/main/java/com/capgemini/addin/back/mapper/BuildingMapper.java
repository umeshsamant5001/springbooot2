package com.capgemini.addin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import java.util.Objects;
import org.mapstruct.factory.Mappers;
import com.capgemini.addin.back.model.Building;
import com.capgemini.addin.back.model.BuildingDTO;
import com.capgemini.addin.back.model.BuildingInformation;

@Mapper
public interface BuildingMapper {

	BuildingMapper INSTANCE = Mappers.getMapper(BuildingMapper.class);

    @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay")
	BuildingDTO buildingToBuildingDTO(Building in);

	Building buildingDTOToBuilding(BuildingDTO in);

    @Mappings({
        @Mapping(target = "floors", ignore = true),
        @Mapping(source = "information", target = "information", qualifiedByName = "limitInDay")
    })
    BuildingDTO buildingToBuildingDTONoFloors(Building in);

    @Named("limitInDay")
    public static BuildingInformation limitInDay(BuildingInformation information) {
        if(Objects.nonNull(information) && Objects.isNull(information.getLimitInDay())) {
            information.setLimitInDay(15L);
        }
        return information;
    }
}
