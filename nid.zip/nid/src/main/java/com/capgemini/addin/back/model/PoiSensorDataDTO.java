package com.capgemini.addin.back.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiSensorDataDTO implements Serializable {
    private Long id;
	private String name;
	private Floor floor;
	private Long floorId;
    private String titleFr;
    private String titleEn;
	private SpaceType spaceType;
	private Long modifiedAt = (new Date()).getTime() / 1000;
    private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();
	private List<Equipment> equipments = new ArrayList<>();
	private String description;
	private Integer floorIndex;
    private SensorDataDTO sensorData;
	private String deviceType; //  New field for device type
}

