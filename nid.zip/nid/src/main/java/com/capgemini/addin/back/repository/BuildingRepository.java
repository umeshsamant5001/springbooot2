package com.capgemini.addin.back.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.addin.back.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

    long countBySiteId(@Param("siteId") Long siteId);

	List<Building> findAllBySiteId(@Param("siteId") Long siteId);

    List<Building> findByIdIn(List<Long> buildingIdList);

    Building findByFloorsId(@Param("floorId") Long floorId);

	Building findByCdmKeyId(@Param("cdmKeyId")  Long cdmKeyId);

	@RestResource(exported = false)
	@Query(value = "select building.* from building building where id in"
			+ "(select building_id from building_attribute where att_value = :asset_id) limit 1", nativeQuery = true)
	Building findByAssetId(@Param("asset_id") String asset_id);

    @Query(value ="SELECT c.titleEn AS city_name FROM Building b JOIN Site s ON b.siteId = s.id JOIN City c ON s.cityId = c.id WHERE b.id = :buildingId")
    String getCityName(@Param("buildingId") Long buildingId);

    @Query(value ="SELECT t.titleEn AS country_name FROM Building b JOIN Site s ON b.siteId = s.id JOIN City c ON s.cityId = c.id JOIN Country t on c.countryId = t.id WHERE b.id = :buildingId")
    String getCountryName(@Param("buildingId") Long buildingId);

    List<Building> findAllBySecuredTrue();

	/** To optimize query, we force the use of a JOIN for the OpeningHours */
	@Query("SELECT building FROM Building building LEFT JOIN FETCH building.information.openingHours WHERE building.deployed = 1")
    List<Building> findAllByDeployedTrue();

	@RestResource(exported = false)
    @Query(value="SELECT limit_in_day FROM building WHERE id = :buildingId",nativeQuery=true)
    Long getBuildingLimitInDayById(@Param("buildingId") Long buildingId);

    List<Building> findAllBySecuredFalseAndDeployedTrue();

	@Query("SELECT building FROM Building building INNER JOIN FETCH building.site site INNER JOIN FETCH site.city city INNER JOIN FETCH city.country country "
	+ " WHERE building.id = :buildingId ")
	Building findByBuildingIdWithParent(@Param("buildingId") Long buildingId);
}
