/**
 *
 */
package com.capgemini.addin.back.model;

/**
 * Enum use to determine the type of the device (sensor officeSense, tablet,
 * ...)
 *
 * @author alcarpen
 *
 */
public enum EnumDeviceType {
	OFFICESENSE_PRESENCE, OFFICESENSE_COMFORT, OFFICESENSE_DESK, DELTADORE, TABLET, UNKNOWN;

	public static EnumDeviceType findByName(String name) {
		EnumDeviceType result = null;
		for (EnumDeviceType deviceType : values()) {
			if (deviceType.name().equalsIgnoreCase(name)) {
				result = deviceType;
				break;
			}
		}
		return result;
	}
}
