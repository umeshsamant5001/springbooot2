package com.capgemini.addin.back.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.addin.back.model.SpaceType;

@Repository
public interface SpaceTypeRepository extends JpaRepository<SpaceType, Long> {
    // Find all SpaceType IDs by a list of names
    @Query("SELECT c.id FROM SpaceType c WHERE c.spaceTypeName IN (:spaceTypeNames)")
    public List<Long> findAllIdByNameIn(@Param("spaceTypeNames") @RequestParam("spaceTypeNames") List<String> spaceTypeNames);

    // Find SpaceType by name
    public Optional<SpaceType> findBySpaceTypeName(@Param("spaceTypeName") String spaceTypeName);

    // Find all SpaceTypes ordered by name ascending
    public List<SpaceType> findAllByOrderBySpaceTypeNameAsc();

    // Query to get an existing SpaceType by ID and name using native SQL
    @Query(value = "SELECT * FROM space_type WHERE id = :spaceTypeId AND space_type_name = :spaceTypeName", nativeQuery = true)
    public Optional<SpaceType> getExistingIdAndName(@Param("spaceTypeId") Long spaceTypeId, @Param("spaceTypeName") String spaceTypeName);

    @Query(value = "SELECT * FROM space_type WHERE poi_group_id IN (:poiGroupId) ", nativeQuery = true)
    public List<SpaceType> findAllByPoiGroupId(@Param("poiGroupId") List<Long> poiGroupId);

    @Query(value = "SELECT * FROM space_type WHERE id = :id", nativeQuery = true)
    Optional<SpaceType> findById(@Param("id") Long id);

    @Query(
        "SELECT poiGroup.id as poiGroupId, COUNT(*) as nbSpaceTypes " +
        "FROM SpaceType spaceType " +
        "INNER JOIN spaceType.poiGroup poiGroup " +
        "GROUP BY poiGroup.id"
    )
    List<Tuple> countByPoiGroup();

    public List<SpaceType> findByPoiGroupIdIn(List<Long> poiGroupIds);

    @Query(
        value = "SELECT space_type.* " +
        "FROM space_type " +
        "INNER JOIN poi_group ON space_type.poi_group_id = poi_group.id " +
        "INNER JOIN category_mapping ON category_mapping.space_type_id = space_type.id " +
        "WHERE poi_group.id IN :poiGroupIds " +
        "AND category_mapping.category = 'bookable'",
        nativeQuery = true
    )
    List<SpaceType> findByPoiGroupIdInAndBookableCategory(List<Long> poiGroupIds);


    @Query(
        value = "SELECT st.* FROM space_type st " +
        "JOIN category_mapping cm ON st.id = cm.space_type_id " +
        "WHERE LOWER(cm.category) IN (:categories)",
        nativeQuery = true
    )
    List<SpaceType> findByCategory(
        @Param("categories") List<String> categories
    );

    List<SpaceType> findByPoiGroupId(Long poiGroupId);
}
