package com.capgemini.addin.back.model;

public interface WithTitle {
    String getTitleFr();

    String getTitleEn();
}
