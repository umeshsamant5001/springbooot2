package com.capgemini.addin.back.mapper;

import java.util.Objects;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.addin.back.model.Poi;
import com.capgemini.addin.back.model.PoiSensorDataDTO;
import com.capgemini.addin.back.model.SensorDataDTO;
import com.capgemini.addin.back.service.LiveDataService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PoiControllerMapper {

    @Autowired
    private LiveDataService liveDataService;

    @Autowired
    private ModelMapper modelMapperEntityToDto;

    @PostConstruct
    public void init() {
        this.modelMapperEntityToDto.addMappings(
                new PropertyMap<Poi, PoiSensorDataDTO>() {
                    @Override
                    protected void configure() {
                        map().setId(source.getId());
                        map().setName(source.getName());
                        map().setTitleEn(source.getTitleEn());
                        map().setTitleFr(source.getTitleFr());
                        map().setFloor(source.getFloor());
                        map().setFloorIndex(source.getFloorIndex());
                        map().setFloorId(source.getFloorId());
                        map().setSpaceType(source.getSpaceType());
                        map().setEquipments(source.getEquipments());
                        map().setAttributes(source.getAttributes());
                        map().setSensorData(null);
                        map().setCdmKeyId(source.getCdmKeyId());
                    }
                }
            );
    }

    public PoiSensorDataDTO convertEntityToMobileDto(Poi poi) {
        PoiSensorDataDTO poiMDTO = this.modelMapperEntityToDto.map(poi, PoiSensorDataDTO.class);

        SensorDataDTO sensorData = liveDataService.getPoiSensorData(poi.getName());

        if (!Objects.isNull(sensorData)) {
            poiMDTO.setSensorData(sensorData);
        }
        return poiMDTO;
    }
    public PoiSensorDataDTO convertEntityToMobileDtoNoSensor(Poi poi) {
        PoiSensorDataDTO poiMDTO = this.modelMapperEntityToDto.map(poi, PoiSensorDataDTO.class);
        return poiMDTO;
    }
}
