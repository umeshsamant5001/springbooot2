package com.capgemini.addin.back.repository;

import com.capgemini.addin.back.model.CountryMapping;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface CountryMappingRepository extends JpaRepository<CountryMapping, Long> {
    
    @Query(value = "SELECT c.id AS countryId, c.title_en AS titleEn "+
        "FROM graphapi_country_mapping cm "+
        "JOIN country c ON cm.country_id = c.id "+
        "WHERE LOWER(cm.graphapi_country_name) = LOWER(:graphCountryName) "+
        "AND cm.is_active = 1 " , nativeQuery = true)
    Optional<CountryMappingProjection> findCountryDetails(@Param("graphCountryName") String graphCountryName);

}
