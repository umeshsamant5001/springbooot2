package com.capgemini.addin.back.model;

public enum EnumDeviceAttribute {

	LAST_OCCUPIED_DATE("last_occupied_date"), HUMIDITY("humidity"), OCCUPATION("state"), TEMPC("tempC"), TEMPF("tempF"),
	CO2("co2"), LUX("lux"), SOUND("sound"), VDD("vdd"), VDD_PCT("vddPct"), CERTIFICATE("certificate");

	private final String text;

	EnumDeviceAttribute(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}

}
