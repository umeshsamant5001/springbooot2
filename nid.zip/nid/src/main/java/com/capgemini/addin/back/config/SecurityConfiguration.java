package com.capgemini.addin.back.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;

import com.capgemini.addin.back.security.jwt.JWTConfigurer;
import com.capgemini.addin.back.security.jwt.TokenProvider;

import tech.jhipster.config.JHipsterProperties;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Import(SecurityProblemSupport.class)
public class SecurityConfiguration {

    private final JHipsterProperties jHipsterProperties;

    private final TokenProvider tokenProvider;
    private final SecurityProblemSupport problemSupport;

    public SecurityConfiguration(
        TokenProvider tokenProvider,
        JHipsterProperties jHipsterProperties,
        SecurityProblemSupport problemSupport
    ) {
        this.tokenProvider = tokenProvider;
        this.problemSupport = problemSupport;
        this.jHipsterProperties = jHipsterProperties;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // @formatter:off
        //http // Removed VA fixes
        http.csrf().disable()
        .authorizeHttpRequests()
        .antMatchers("/api/credentials").permitAll()
        .anyRequest()
        .authenticated()
        .and()
        //.csrf()   // Removed VA fixes
        //.and()   // Removed VA fixes
        .httpBasic();

    return http.build();
        // @formatter:on
    }
    //TODO Get some info from a keyVault ? if possible at start
          @Bean
      public InMemoryUserDetailsManager userDetailsService() {
          UserDetails user = User.withDefaultPasswordEncoder()
                  .username("userOutlook")
                  .password("6xBQ8)8cL4+5k")
                  .roles("ADMIN")
                  .build();
          return new InMemoryUserDetailsManager(user);
      }

    private JWTConfigurer securityConfigurerAdapter() {
        return new JWTConfigurer(tokenProvider);
    }
}
