package com.capgemini.addin.back.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Credentials implements Serializable {
    //private String userName;
    //private String userPassword;
    private String userName = "userOutlook";
    private String userPassword = "6xBQ8)8cL4+5k";
}
