package com.capgemini.addin.back.model;

/**
 * Enum used for attendance requirement
 */
public enum QualificationEnum {
    ORGANIZER("organizer"),

    REQUIRED("required"),

    OPTIONAL("optional");

    QualificationEnum(String value) {
        this.value = value;
    }

    private String value;

    public static QualificationEnum fromValue(String text) {
        for (QualificationEnum b : QualificationEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
