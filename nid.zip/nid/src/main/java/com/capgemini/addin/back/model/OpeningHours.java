package com.capgemini.addin.back.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.capgemini.addin.utils.LazyFieldsFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "opening_hours")
@JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = LazyFieldsFilter.class)
public class OpeningHours implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Opening_Hours_Generator")
	@SequenceGenerator(name="Opening_Hours_Generator", sequenceName = "Opening_Hours_Sequence")
	@JsonIgnore
	private long id;

	@Column(name="opening")
	private Long  from;

	@Column(name="closing")
	private Long to;

}
