package com.capgemini.addin.back.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.addin.back.mapper.BuildingMapper;
import com.capgemini.addin.back.model.Building;
import com.capgemini.addin.back.model.BuildingDTO;
import com.capgemini.addin.back.repository.BuildingRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BuildingService {
	static final String API_TAG = "Building";

	@Autowired
	private BuildingRepository buildingRepository;

	@Transactional
	public Building getBuilding(Long buildingId) {
		Building building = buildingRepository.findById(buildingId).orElse(null);

		if (Objects.isNull(building)) {
			return null;
		}

		building.getFloors();

		return building;
	}
    @Transactional
	public Long getBuildingLimitInday(Long buildingId) {
		Long buildingLimitInDay = buildingRepository.getBuildingLimitInDayById(buildingId);

		if (Objects.isNull(buildingLimitInDay)) {
			return (long) 15;
		}
		return buildingLimitInDay;
	}

	@Transactional
	public List<Building> getDeployedBuilding(boolean withFloor) {
		List<Building> buildings = this.buildingRepository.findAllByDeployedTrue();

		if (withFloor) {
			for (Building building : buildings) {
				Hibernate.initialize(building.getFloors());
			}
		}

		return buildings;
	}

    @Transactional
    @Cacheable(value = "buildings")
	public List<BuildingDTO> getDeployedAndUnsecuredBuilding(boolean withFloor) {
		List<Building> buildings = this.buildingRepository.findAllBySecuredFalseAndDeployedTrue();

		if (withFloor) {
			for (Building building : buildings) {
				Hibernate.initialize(building.getFloors());
			}
		}

        List<BuildingDTO> buildingsDTOs = buildings.stream()
        .map(building -> {
            building.getFloors();
            String cityName = this.getCityName(building.getId());
            String countryName = this.getCountryName(building.getId());
            BuildingDTO buildingDTO = BuildingMapper.INSTANCE.buildingToBuildingDTO(building);
            buildingDTO.setCityName(cityName);
            buildingDTO.setCountryName(countryName);
            return buildingDTO;
        }).collect(Collectors.toList());

		return buildingsDTOs;
	}
	public List<Building> findAll() {
		return this.buildingRepository.findAll();
	}

    public String getCityName(Long buildingId) {
        return this.buildingRepository.getCityName(buildingId);
    }
    public String getCountryName(Long buildingId) {
        return this.buildingRepository.getCountryName(buildingId);
    }
	public Building findByBuildingIdWithParent(Long buildingId) {
		return this.buildingRepository.findByBuildingIdWithParent(buildingId);
	}
}
