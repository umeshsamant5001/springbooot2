package com.capgemini.addin.back.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.Data;

/**
 * RoomSearchParameters
*/
@Data
public class RoomSearchParameters {

  private String buildingId;

  private String buildingJavaZone;

  private Integer floorIndex;

  private Integer minimumCapacity;

  private Integer maximumCapacity;

  private BigDecimal startTime;

  private BigDecimal duration;

  private List<Attendee> attendees;

  private Boolean checkDisponibility;

  private static final int DEFAULT_MAXIMUM_CAPACITY = 100;

  public RoomSearchParameters() {
  }
  // Constructor
  public RoomSearchParameters(String buildingId, String buildingJavaZone, Integer floorIndex, Integer minimumCapacity,
                              Integer maximumCapacity, BigDecimal startTime, BigDecimal duration, List<Attendee> attendees,
                              Boolean checkDisponibility) {
      this.buildingId = buildingId;
      this.buildingJavaZone = buildingJavaZone;
      this.floorIndex = floorIndex;
      this.minimumCapacity = minimumCapacity;
      this.maximumCapacity = maximumCapacity != null ? maximumCapacity : DEFAULT_MAXIMUM_CAPACITY;
      this.startTime = startTime;
      this.duration = duration;
      this.attendees = attendees != null ? attendees : new ArrayList<>();
      this.checkDisponibility = checkDisponibility;
  }

  public RoomSearchParameters addAttendeesItem(Attendee attendeesItem) {
    if (this.attendees == null) {
      this.attendees = new ArrayList<Attendee>();
    }
    this.attendees.add(attendeesItem);
    return this;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RoomSearchParameters roomSearchParameters = (RoomSearchParameters) o;
    return Objects.equals(this.buildingId, roomSearchParameters.buildingId) &&
        Objects.equals(this.buildingJavaZone, roomSearchParameters.buildingJavaZone) &&
        Objects.equals(this.floorIndex, roomSearchParameters.floorIndex) &&
        Objects.equals(this.minimumCapacity, roomSearchParameters.minimumCapacity) &&
        Objects.equals(this.maximumCapacity, roomSearchParameters.maximumCapacity) &&
        Objects.equals(this.startTime, roomSearchParameters.startTime) &&
        Objects.equals(this.duration, roomSearchParameters.duration) &&
        Objects.equals(this.attendees, roomSearchParameters.attendees) &&
        Objects.equals(this.checkDisponibility, roomSearchParameters.checkDisponibility);
  }

  @Override
  public int hashCode() {
    return Objects.hash(buildingId, buildingJavaZone, floorIndex, minimumCapacity,maximumCapacity, startTime, duration, attendees, checkDisponibility);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RoomSearchParameters {\n");

    sb.append("    buildingId: ").append(toIndentedString(buildingId)).append("\n");
    sb.append("    buildingJavaZone: ").append(toIndentedString(buildingJavaZone)).append("\n");
    sb.append("    floorIndex: ").append(toIndentedString(floorIndex)).append("\n");
    sb.append("    minimumCapacity: ").append(toIndentedString(minimumCapacity)).append("\n");
    sb.append("    maximumCapacity: ").append(toIndentedString(maximumCapacity)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    duration: ").append(toIndentedString(duration)).append("\n");
    sb.append("    attendees: ").append(toIndentedString(attendees)).append("\n");
    sb.append("    checkDisponibility: ").append(toIndentedString(checkDisponibility)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
  */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
