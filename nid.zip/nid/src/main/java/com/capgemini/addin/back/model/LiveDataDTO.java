package com.capgemini.addin.back.model;

import lombok.Data;

@Data
public class LiveDataDTO {
	private String uuid;
	private String deviceType;
	private Long lastChange;
	private String poiName;
	private String status;
	private Long floorId;
	private String lastOccupiedDate;
	private String humidity;
	private String occupation;
	private String tempc;
	private String tempf;
	private String co2;
	private String lux;
	private String sound;
	private String vdd;
	private String vddPct;

}
