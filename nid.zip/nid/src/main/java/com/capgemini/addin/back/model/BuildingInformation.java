package com.capgemini.addin.back.model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import lombok.Data;

@Data
@Embeddable
public class BuildingInformation implements Serializable {

	@Column(name = "address")
	private String address;

	@Column(name = "city")
	private String city;
    
    @Column(name = "country")
    private String country;

	@Column(name = "phone")
	private String phone;

	@Column(name = "reception_mail")
	private String receptionMail;

	@Transient
	private String infoUrl;

	@Column(name = "ldap_name")
	private String ldapName;

	@Column(name = "capacity")
	private String capacity;

	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_opening_hours")
	private OpeningHours openingHours;

    @Column(name = "limit_in_day")
    private Long limitInDay = 15L;

	public void format() {
		this.phone = "".equals(this.phone) ? null : this.phone;
		this.receptionMail = "".equals(this.receptionMail) ? null : this.receptionMail;
	}

}
