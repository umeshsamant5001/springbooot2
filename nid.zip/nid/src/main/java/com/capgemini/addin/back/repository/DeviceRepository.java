package com.capgemini.addin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.capgemini.addin.back.model.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

    @RestResource(exported = false)
    public Device findByUuid(@Param("uuid") String uuid);

    @Query(value = "SELECT device.* "
            + " FROM device "
            + " WHERE device.floor_id = :floorId "
            + " AND device.device_type = 'OFFICESENSE_PRESENCE' "
            + " AND device.status = 'ACTIVE' ", nativeQuery = true)
    public List<Device> findAllActiveOfficePresenceByFloor(@Param("floorId") long floorId);

    @Query(value = "SELECT device.* "
            + " FROM device "
            + " JOIN floor ON floor.id = device.floor_id "
            + " WHERE floor.building_id= :buildingId "
            + " AND device.device_type = 'OFFICESENSE_PRESENCE' "
            + " AND device.status = 'ACTIVE' ", nativeQuery = true)
    public List<Device> findAllActiveOfficePresenceBuilding(@Param("buildingId") long buildingId);

    public List<Device> findAllByPoiName(@Param("poiName") String poiName);
}
