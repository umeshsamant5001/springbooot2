package com.capgemini.addin.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * Properties specific to Add In Back End.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
@Data
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class

    private final CORS cors = new CORS();
    private final GraphApi graphApi = new GraphApi();
    private final Credentials credentials = new Credentials();

    @Data
    public static class GraphApi {
        private String tenantId;
        private String clientSecret;
        private String clientId;
        private String scopeUrl;
        private String url;

    }

    @Data
    public static class CORS {
        private String origins;
    }

    @Data
    public static class Credentials {
        private String userName;
        private String userPassword;
    }
}
