package com.capgemini.addin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.addin.back.model.Floor;

@Repository
public interface FloorRepository extends JpaRepository<Floor, Long> {

	// Count Floors by building ID
	long countByBuildingId(@Param("buildingId") Long buildingId);

	// Find floors by building ID
	List<Floor> findAllByBuildingIdOrderByIndex(@Param("buildingId") Long buildingId);

	Floor findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);
	@Query(value = "select  sf.* from floor as sf left outer join building sb on sb.id = sf.building_id"
			+ " where sf.cdm_key_id =:cdmKeyId and building_id in"
			+ "(select building_id from building_attribute where att_value = :assetId) limit 1", nativeQuery = true)
	Floor findByCdmKeyIdAndAssetId(@Param("cdmKeyId") Long cdmKeyId,
			@Param("assetId") String assetId);

	List<Floor> findAllByBuildingIdAndIndex(Long buildingInd, Integer index);
}
