package com.capgemini.addin.back.controller;

import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.addin.back.service.UserActionService;
import com.capgemini.addin.back.model.UserAction;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Slf4j
@RestController
@RequestMapping(value = UserActionController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class UserActionController {
    
    static final String ROOT_API = "api/userAction";
       
    @Autowired
    UserActionService userActionService;
    
    // @PostMapping("/saveUserAction")
    // public ResponseEntity<Map<String, String>> saveUserAction(
    //         @RequestParam String userEmail) {
    //         Map<String, String> response = new HashMap<>();
    //         if (userEmail == null || userEmail.isEmpty()) {
    //             response.put("error", "userEmail is required.");
    //             return ResponseEntity.badRequest().body(response);
    //         }                        
    //         UserAction userAction = new UserAction();
    //         userAction.setUserEmail(userEmail);
    //         userAction.setLoggedInTime((new Date()).getTime() / 1000);
    //         String countryName = userActionService.getUserCountryByEmail(userEmail);
    //         Long countryId = userActionService.getCountryId(countryName);
    //         if(countryId!=null){
    //             userAction.setCountryId(countryId);
    //             userAction.setCountryName(countryName);
    //         }
            
    //         userActionRepository.save(userAction);
    //         response.put("message", "User Action saved successfully");
    //         return ResponseEntity.ok(response);

    // }
    @PostMapping("/saveUserAction")
    public ResponseEntity<Map<String, String>> saveUserAction(@RequestParam String userEmail) {
        Map<String, String> response = new HashMap<>();
        
        try {
            UserAction userAction = userActionService.createUserAction(userEmail);
            response.put("message", "User Action saved successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
            
        } catch (IllegalArgumentException ex) {
            log.warn("Invalid user action request: {}", ex.getMessage());
            response.put("error", ex.getMessage());
            return ResponseEntity.badRequest().body(response);
            
        } catch (RuntimeException ex) {
            log.error("Error saving user action", ex);
            response.put("error", "Error saving user action");
            return ResponseEntity.internalServerError().body(response);
        }
    }

}
