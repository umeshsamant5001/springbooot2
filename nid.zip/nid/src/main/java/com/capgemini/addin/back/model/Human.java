package com.capgemini.addin.back.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Data
@ToString
public class Human implements Serializable {
    private String firstName = null;

    private String lastName = null;

    private String email = null;

    private Boolean canBook = null;

    private String phone = null;

    private String siteId = null;

    private String encryptedPassword = null;

    private String notificationToken = null;

    private String mailboxName = null;
}
