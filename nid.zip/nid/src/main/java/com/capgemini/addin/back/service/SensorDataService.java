package com.capgemini.addin.back.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.capgemini.addin.back.model.Device;
import com.capgemini.addin.back.model.EnumDeviceAttribute;
import com.capgemini.addin.back.model.PoiDTO;
import com.capgemini.addin.back.model.SensorDataDTO;

@Service
public class SensorDataService {
    private static final int MILLIS_IN_SECOND = 1000;
	private static final String FREE_STATE = "free";
	private static final String BUSY_STATE = "busy";
	private static final String DEFAULT_STATE = "unknown";
	public static final Integer DESK_LOCKING_TIME_MINUTES = 60;

	public List<SensorDataDTO> convertToSensorDataDTO(List<PoiDTO> poiDTOs, List<Device> devices) {
		if (Objects.isNull(devices)) {
			return null;
		}

		return devices.stream()
			.map(device -> {
				SensorDataDTO sensorData = new SensorDataDTO();

				String poiName = device.getPoiName();

				// If link to a Poi, get the Poi
				if (Objects.nonNull(poiName)) {
					PoiDTO foundPoi = poiDTOs.stream()
						.filter(poi -> Objects.equals(poi.getName(), poiName))
						.findFirst()
						.orElse(null);

					if (Objects.nonNull(foundPoi)) {
						sensorData.setCdmKeyIdPoi(foundPoi.getCdmKeyId());
					}
				}

				// Basic fields
				sensorData.setUuid(device.getUuid());
				sensorData.setPoiName(device.getPoiName());

				if (Objects.nonNull(device.getFloor())) {
					sensorData.setCdmKeyIdFloor(device.getFloor().getCdmKeyId());
				}

				if (Objects.nonNull(device.getStatus())) {
					sensorData.setStatus(device.getStatus().toString());
				}

				if (Objects.nonNull(device.getDeviceType())) {
					sensorData.setDeviceType(device.getDeviceType().toString());
				}

				if (Objects.nonNull(device.getLastChange())) {
					sensorData.setLastChange(device.getLastChange().toString());
				}

				Map<String, String> attributes = device.getAttributes();

				sensorData.setBattery(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.VDD)
				);

				sensorData.setOccupation(
					this.getAttributeAsString(attributes, EnumDeviceAttribute.OCCUPATION)
				);

				sensorData.setCo2(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.CO2)
				);

				sensorData.setHumidity(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.HUMIDITY)
				);

				sensorData.setLight(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.LUX)
				);

				sensorData.setNoise(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.SOUND)
				);

				sensorData.setTempC(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPC)
				);

				sensorData.setTempF(
					this.getAttributeAsDouble(attributes, EnumDeviceAttribute.TEMPF)
				);

				return sensorData;
			})
			.collect(Collectors.toList());
	}

	public Map<String, SensorDataDTO> getPoiSensorData(List<PoiDTO> poiDTOs, List<Device> devices) {
		List<SensorDataDTO> sensorDataDTOs = this.convertToSensorDataDTO(poiDTOs, devices);

		Map<String, List<SensorDataDTO>> sensorDataMap =  sensorDataDTOs
			.stream()
			.collect(Collectors.toMap(
				SensorDataDTO::getPoiName,
				sensorData -> new ArrayList<>(Arrays.asList(sensorData)),
				(sensorData1, sensorData2) -> {
					sensorData1.addAll(sensorData2);
					return sensorData1;
				}
			));

		return sensorDataMap.keySet()
			.stream()
			.map(poiName -> {
				SensorDataDTO resultSensorDataDTO = new SensorDataDTO();
				resultSensorDataDTO.setOccupation(DEFAULT_STATE);

				sensorDataMap.get(poiName)
					.stream()
					.forEach(sensorDataDTO -> {
						if (Objects.nonNull(sensorDataDTO.getCdmKeyIdPoi())) {
							resultSensorDataDTO.setCdmKeyIdPoi(sensorDataDTO.getCdmKeyIdPoi());
						}
						if (Objects.nonNull(sensorDataDTO.getUuid())) {
							resultSensorDataDTO.setUuid(sensorDataDTO.getUuid());
						}
						if (Objects.nonNull(sensorDataDTO.getPoiName())) {
							resultSensorDataDTO.setPoiName(sensorDataDTO.getPoiName());
						}
						if (Objects.nonNull(sensorDataDTO.getUuid())) {
							resultSensorDataDTO.setCdmKeyIdFloor(sensorDataDTO.getCdmKeyIdFloor());
						}
						if (Objects.nonNull(sensorDataDTO.getStatus())) {
							resultSensorDataDTO.setStatus(sensorDataDTO.getStatus());
						}
						if (Objects.nonNull(sensorDataDTO.getDeviceType())) {
							resultSensorDataDTO.setDeviceType(sensorDataDTO.getDeviceType());
						}
						if (Objects.nonNull(sensorDataDTO.getLastChange())) {
							resultSensorDataDTO.setLastChange(sensorDataDTO.getLastChange());
						}
						if (Objects.nonNull(sensorDataDTO.getBattery())) {
							resultSensorDataDTO.setBattery(sensorDataDTO.getBattery());
						}
						if (Objects.nonNull(sensorDataDTO.getOccupation())) {
							String currentOccupancy = resultSensorDataDTO.getOccupation();

							if (Objects.equals(currentOccupancy, FREE_STATE)) {
								resultSensorDataDTO.setOccupation(sensorDataDTO.getOccupation());
							}
						}
						if (Objects.nonNull(sensorDataDTO.getCo2())) {
							resultSensorDataDTO.setCo2(sensorDataDTO.getCo2());
						}
						if (Objects.nonNull(sensorDataDTO.getHumidity())) {
							resultSensorDataDTO.setHumidity(sensorDataDTO.getHumidity());
						}
						if (Objects.nonNull(sensorDataDTO.getLight())) {
							resultSensorDataDTO.setLight(sensorDataDTO.getLight());
						}
						if (Objects.nonNull(sensorDataDTO.getNoise())) {
							resultSensorDataDTO.setNoise(sensorDataDTO.getNoise());
						}
						if (Objects.nonNull(sensorDataDTO.getTempC())) {
							resultSensorDataDTO.setTempC(sensorDataDTO.getTempC());
						}
						if (Objects.nonNull(sensorDataDTO.getTempF())) {
							resultSensorDataDTO.setTempF(sensorDataDTO.getTempF());
						}
					});

				return resultSensorDataDTO;
			})
			.collect(Collectors.toMap(
				SensorDataDTO::getPoiName,
				Function.identity()
			));
	}

	/**
	 * Return the value of an attribut as a String.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a String.
	 */
	private String getAttributeAsString(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();

		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
		}

		return attributes.get(keyString);
	}

	/**
	 * Return the value of an attribut as a Double.
	 * @param attributes The Map of attributes
	 * @param key The key
	 * @return The value as a Double.
	 */
	private Double getAttributeAsDouble(Map<String, String> attributes, EnumDeviceAttribute key) {
		String keyString = key.toString();

		if (Objects.isNull(attributes) || attributes.isEmpty() || !attributes.containsKey(keyString)) {
			return null;
		}

		return Double.parseDouble(attributes.get(keyString));
	}

	private String deskOccupancy(SensorDataDTO sensorDataDTO, Date now, Integer intevalToConsiderFree) {
		try {
			if (Objects.isNull(sensorDataDTO)) {
				return DEFAULT_STATE;
			}

			if (BUSY_STATE.equals(sensorDataDTO.getOccupation())) {
				return BUSY_STATE;
			}

			if (
				FREE_STATE.equals(sensorDataDTO.getOccupation())
				&& Objects.nonNull(sensorDataDTO.getLastChange())
			) {
				Long occupiedTs = Long.valueOf(sensorDataDTO.getLastChange());
				long nowSecond = now.getTime() / MILLIS_IN_SECOND;
				long lastOccupiedTimeInterval = nowSecond - occupiedTs;

				if (lastOccupiedTimeInterval < intevalToConsiderFree) {
					return BUSY_STATE;
				}

				return FREE_STATE;
			}
		} catch (Exception e) {
			return DEFAULT_STATE;
		}

		return DEFAULT_STATE;
	}
}
