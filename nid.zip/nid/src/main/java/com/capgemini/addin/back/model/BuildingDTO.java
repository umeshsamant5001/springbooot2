package com.capgemini.addin.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class BuildingDTO implements Serializable{

    private Long id;

    private Long siteId;

    private Boolean deployed;

    private Boolean secured;

    private Long defaultMapId;

    private Long imageId;

    private String timezoneWindows;

    private String timezoneJava;

    private Long modifiedAt;

    private List<Floor> floors;

    private String titleFr;

    private String cityName;

    private String countryName;

    private String titleEn;

    private BuildingInformation information;

    private String mailingList;

    private Long cdmKeyId;

    private Map<String, String> attributes = new HashMap<String, String>();
}
