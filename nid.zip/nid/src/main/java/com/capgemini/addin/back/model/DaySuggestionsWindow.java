package com.capgemini.addin.back.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.Data;

/**
 * DaySuggestionsWindow
*/
@Data
public class DaySuggestionsWindow {

  private BigDecimal time = null;

  private List<PoiSensorDataDTO> rooms = null;

  public DaySuggestionsWindow addRoomsItem(PoiSensorDataDTO roomsItem) {
    if (this.rooms == null) {
      this.rooms = new ArrayList<PoiSensorDataDTO>();
    }
    this.rooms.add(roomsItem);
    return this;
  }

  public DaySuggestionsWindow addRoomsItems(List<PoiSensorDataDTO> roomsItems) {
    if (this.rooms == null) {
      this.rooms = new ArrayList<PoiSensorDataDTO>();
    }
    this.rooms.addAll(roomsItems);
    return this;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DaySuggestionsWindow daySuggestionsWindow = (DaySuggestionsWindow) o;
    return Objects.equals(this.time, daySuggestionsWindow.time) &&
        Objects.equals(this.rooms, daySuggestionsWindow.rooms);
  }

  @Override
  public int hashCode() {
    return Objects.hash(time, rooms);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DaySuggestionsWindow {\n");

    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("    rooms: ").append(toIndentedString(rooms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
  */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
