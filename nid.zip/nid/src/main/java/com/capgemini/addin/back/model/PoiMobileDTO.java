package com.capgemini.addin.back.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiMobileDTO implements Serializable {

	private String id;
	private String name;
	private String title;
	private String description;
	private Integer floorIndex;
	private Integer floorId;
	private PoiGroup type;
	private List<Equipment> equipments;
    private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();
	private SensorDataDTO sensorData;
}
