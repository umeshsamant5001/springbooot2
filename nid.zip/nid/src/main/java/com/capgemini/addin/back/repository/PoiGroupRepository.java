package com.capgemini.addin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.addin.back.model.PoiGroup;

@Repository
public interface PoiGroupRepository extends JpaRepository<PoiGroup, Long> {

	@RestResource(exported = false)
	List<PoiGroup> findAllIdByNameIn(@Param("poiGroupsNames") @RequestParam("poiGroupsNames") List<String> poiGroupsNames);

    PoiGroup findByName(@Param("poiGroup") String poiGroup);
}
