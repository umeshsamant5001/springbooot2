package com.capgemini.addin.back.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;

import com.capgemini.addin.back.model.Poi;
import com.capgemini.addin.back.model.UserAction;

import java.util.List;
import java.util.Optional;

public interface UserActionRepository extends JpaRepository<UserAction, Long> {

    Optional<UserAction> findByUserEmail(String userEmail);

    @RestResource(exported = false)
    @Query(value = " SELECT * " + 
                " FROM country c " + 
                " WHERE c.title_en = :countryName "                
                , nativeQuery = true) 
    List<Object[]> findCountryByName(@Param("countryName") String  countryNamet);
    
}
