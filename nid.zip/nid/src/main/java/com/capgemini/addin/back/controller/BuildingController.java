package com.capgemini.addin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.addin.back.mapper.BuildingMapper;
import com.capgemini.addin.back.model.Building;
import com.capgemini.addin.back.model.BuildingDTO;
import com.capgemini.addin.back.service.BuildingService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = BuildingController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class BuildingController {

    static final String ROOT_API = "api/building";

    @Autowired
    private BuildingService buildingService;

    private final CacheManager cacheManager;

    public BuildingController(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }


    /**
     * Return a building, and its floor, by its id.
     */
    @GetMapping("/{buildingId}")
    @Transactional
    public ResponseEntity<BuildingDTO> getBuilding(
        @PathVariable Long buildingId,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        Building building = this.buildingService.getBuilding(buildingId);
        // if (!isValidPositiveLong(buildingId)) {
        //     log.info("Invalid building id {}", buildingId);
        //     return ResponseEntity.badRequest().build();
        // }

        // Long validatedBuildingId = Long.valueOf(buildingId);
        // Building building = this.buildingService.getBuilding(validatedBuildingId);

        if (Objects.isNull(building)) {
            //log.info("Building {} not found", validatedBuildingId);
            log.info("Building {} not found", buildingId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        BuildingDTO buildingDTO = BuildingMapper.INSTANCE.buildingToBuildingDTO(building);

        return ResponseEntity.ok(buildingDTO);
    }

    /**
     * Return a building, and its floor, by its id.
     */
    @GetMapping("/limit/{buildingId}")
    @Transactional
    public ResponseEntity<Long> getBuildingLimitInDay(
        @PathVariable Long buildingId,
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        if (Objects.isNull(buildingId) || buildingId <= 0) {
            log.info("Invalid building id {}", buildingId);
            return ResponseEntity.badRequest().build();
        }

        Long limitInDay = this.buildingService.getBuildingLimitInday(buildingId);

        if (Objects.isNull(limitInDay)) {
            log.info("Building {} not found", buildingId);

            // Part of the url is not found, we return a 404
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(limitInDay);
    }

    /***
     * Check String can be convert to double without exception
     *
     * @param str
     * @return
     */
    private boolean stringIsDouble(String str) {
        try {
            Double.valueOf(str);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private boolean isValidPositiveLong(String value) {
        if (Objects.isNull(value) || value.isBlank()) {
            return false;
        }

        try {
            return Long.parseLong(value) > 0;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /**
     * Return all deployed and unsecured buildings, handle user secured access
     */
    @GetMapping
    @Transactional
    @Cacheable(value = "buildings")
    ResponseEntity<List<BuildingDTO>> getBuildings(
        @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language
    ) {
        List<BuildingDTO> buildingsDTOs = this.buildingService.getDeployedAndUnsecuredBuilding(true);
        if (Objects.isNull(buildingsDTOs)) {
            return ResponseEntity.internalServerError().build();
        }

        return ResponseEntity.ok(buildingsDTOs);
    }

    @DeleteMapping("/cache/clear/buildings")
    public ResponseEntity<String> clearBuildingsCache() {
        if (cacheManager.getCache("buildings") != null) {
            cacheManager.getCache("buildings").clear();
            log.info("Cache for 'buildings' cleared successfully!");
            return ResponseEntity.ok("Cache for 'buildings' cleared successfully!");
        }
        return ResponseEntity.internalServerError().body("Failed to clear cache.");
    }
}
