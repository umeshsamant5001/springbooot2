package com.capgemini.addin.back.service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;

import javax.mail.internet.InternetAddress;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.capgemini.addin.back.model.PoiMobileDTO;
import com.capgemini.addin.back.model.PoiSensorDataDTO;
import com.microsoft.graph.models.DateTimeTimeZone;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.LocationConstraintItem;
import com.microsoft.graph.models.ScheduleInformation;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class GraphCommon {

    public static final ZoneId UTC_ZONE_ID = TimeZone.getTimeZone(ZoneId.of("UTC")).toZoneId();
	public final static String POI_MEETING_ROOM_EMAIL_ATTRIBUTE = "conf_room_mail";

	/**
	 * Convert epoch in give zone to UTC epoch
	 * @param timestampSeconds
	 * @param zone
	 * @return
	*/
	public static BigDecimal getUTCEpochFromZonedEpoch(BigDecimal timestampSeconds, String zone) {
		return new BigDecimal(getUTCEpochFromZonedEpoch(timestampSeconds.longValue(), zone));
	}

    /**
	 * Convert epoch in give zone to UTC epoch
	 * @param timestampSeconds
	 * @param zone
	 * @return
	*/
	public static long getUTCEpochFromZonedEpoch(long timestampSeconds, String zone) {
		ZonedDateTime zonedDatetime = GraphCommon.getZonedDateTime(timestampSeconds, zone);
		return zonedDatetime.toInstant().toEpochMilli() / 1000;
	}

    /**
	 * Add zone in the DateTime (not performing an offset addition, just add the timezone next to the date)
	 * @param timestampSeconds
	 * @param zone
	 * @return
	*/
	public static ZonedDateTime getZonedDateTime(long timestampSeconds, String zone) {
		if (zone == null) return getZonedDateTime(timestampSeconds, UTC_ZONE_ID.getId());
		else return getUTCDateTime(timestampSeconds).atZone(ZoneId.of(zone));
	}

    /**
	 * Get date in UTC (no offset)
	 * @param timestampSeconds
	 * @return
	*/
	public static LocalDateTime getUTCDateTime(long timestampSeconds) {
		return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), UTC_ZONE_ID);
	}

	/**
	 * Get date in string format
	 * @param timestampSeconds
	 * @return
	*/
	public static String formatToUTC(long timestampSeconds) {
		DateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		format.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));
		return format.format(new Date(timestampSeconds * 1000));
	}

	/**
	 * Get date in string format
	 * @param timestampSeconds
	 * @return
	*/
	public static String formatToUTC(BigDecimal timestampSeconds) {
		DateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		format.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));
		return format.format(new Date(timestampSeconds.longValue() * 1000));
	}

	/**
	 * Convert timestamp big decimal to Date
	 * @param bigDecimal
	 * @return
	*/
	public static Date timeConvert(BigDecimal bigDecimal) {
		long startTime = bigDecimal.longValue() * 1000;
		return new Date(startTime);
	}

	/**
	 * Encode an event
	 * @param event
	 * @return
	 * @throws UnsupportedEncodingException
	*/
	public static String encodeUniqueId(Event event) {
		return encode(event.id);
	}

	/**
	 * Encode an ID(String) in UTF-8 format
	 * @param id
	 * @return
	 * @throws UnsupportedEncodingException
	*/
	private static String encode(String id) {
		return URLEncoder.encode(id, StandardCharsets.UTF_8);
	}

	/**
	 * Convert given epoch to epoch in give zone
	 * @param timestampSeconds
	 * @param zone
	 * @return
	*/
	public static long getZonedEpochFromUTCEpoch(long timestampSeconds, String zone) {
		return LocalDateTime.ofInstant(Instant.ofEpochSecond(timestampSeconds), ZoneId.of(zone))
							.atZone(GraphCommon.UTC_ZONE_ID).toEpochSecond();
	}

	/**
	 * Convert given epoch to epoch in give zone
	 * @param timestampSeconds
	 * @param zone
	 * @return
	*/
	public static BigDecimal getZonedEpochFromUTCEpoch(BigDecimal timestampSeconds, String zone) {
		return new BigDecimal(getZonedEpochFromUTCEpoch(timestampSeconds.longValue(), zone));
	}

	/**
	 * Convert DateTimeTimezon to dateTime to create BigDecimal class
	 * @param time time represented by a DateTimeTimeZone
	 * @return time in milliseconds
	*/
	public static Long getTimeFromDateTimeTimeZone(DateTimeTimeZone time) {
		DateTime dateTime = new DateTime(time.dateTime);
		return dateTime.getMillis();
	}

	/**
	 * Check if the two emails are identical
	 * @param email1
	 * @param email2
	 * @return true if it's true
	*/
	public static Boolean areSameEmail(String email1, String email2) {
		return email1.toUpperCase().split("@")[0].equals(email2.toUpperCase().split("@")[0]);
	}

	/**
	 * Create a list of LocationConstraintItem
	 * @param confrooms list of PoiMobileDTO
	 * @return list of LocationConstraintItem
	*/
	public static List<LocationConstraintItem> extractEmailsIntoAttendees(List<PoiMobileDTO> confrooms) {

		List<LocationConstraintItem> siteRoomAttendees = new ArrayList<LocationConstraintItem>();

		for (PoiMobileDTO poi : confrooms) {
			// Get mail
			String email = poi.getAttributes().get(GraphCommon.POI_MEETING_ROOM_EMAIL_ATTRIBUTE);
			if (isValidEmailAddress(email)) {
				// Create LocationConstraintItem
				LocationConstraintItem locationConstraintItem = new LocationConstraintItem();
				locationConstraintItem.locationEmailAddress = email;
				locationConstraintItem.displayName = poi.getName();
				siteRoomAttendees.add(locationConstraintItem);
			}
		}

		return siteRoomAttendees;
	}

	/**
	 * Check if the email address is valid
	 * @param email : email of POI
	 * @return boolean
	*/
	public static boolean isValidEmailAddress(String email) {
		if (email != null) {
			try {
				InternetAddress emailAddr = new InternetAddress(email);
				emailAddr.validate();
				return true;
			} catch (Exception e) {
				log.error("Failed to validate email address: " + email);
			}
		}
		return false;
	}

	/**
	 * Check email and return PoiMobileDTO
	 * @param mail
	 * @param confrooms
	 * @return
	*/
	public static PoiSensorDataDTO isInTheList(String mail, List<PoiSensorDataDTO> confrooms) {
		for(PoiSensorDataDTO poi : confrooms) {
			if(Objects.nonNull(poi.getAttributes().get(GraphCommon.POI_MEETING_ROOM_EMAIL_ATTRIBUTE))) {
				String email = poi.getAttributes().get(GraphCommon.POI_MEETING_ROOM_EMAIL_ATTRIBUTE);
				if(email.equals(mail)) {
					return poi;
				}
			}
		}
		return null;
	}

	/**
	 * for each room see if we have a meeting
	 * @param rooms
	 * @return HashMap<String, Long> : <email, freeUntil>
	*/
	public static HashMap<String, Long> filterOutBusyRoomsUntil(List<ScheduleInformation> rooms, DateTime endTime, DateTime startTime) {
		HashMap<String, Long> availableRoomsEmails = new HashMap<String, Long>();
		for(ScheduleInformation scheduleInformation : rooms) {
			if(Objects.isNull(scheduleInformation.error)){
				if(scheduleInformation.scheduleItems.size() > 0) {
					DateTime firstMeetingStartTime = new DateTime(scheduleInformation.scheduleItems.get(0).start.dateTime.split("\\+")[0]);
					log.debug("start of the first meeting : {} ", firstMeetingStartTime);
					// startTime need to less than FirstMeetingStartTime
					if(startTime.compareTo(firstMeetingStartTime) == -1) {
						log.debug(scheduleInformation.scheduleId + " is free at this slot");
						availableRoomsEmails.put(scheduleInformation.scheduleId, firstMeetingStartTime.getMillis() - startTime.getMillis());
					} else {
						log.info(firstMeetingStartTime + " less than or equal to " + startTime);
					}
				} else {
					// If we don't have an appointment before the day
					log.debug(scheduleInformation.scheduleId + " is free at this slot");
					log.debug("zero meeting");
					availableRoomsEmails.put(scheduleInformation.scheduleId, endTime.getMillis() - startTime.getMillis());
				}
			} else {
				log.debug(scheduleInformation.scheduleId + " is invalid");
				availableRoomsEmails.put(scheduleInformation.scheduleId, null);
			}
		}
		return availableRoomsEmails;
	}

	/**
	 * Create an array of String and each array has chunkSize as size
	 * @param attendees : array of String
	 * @param chunkSize : size
	 * @return matrice
	*/
	public static String[][] splitArrayOfString(String[] emails, int chunkSize){
	    if(chunkSize<=0){
	        return null;  // just in case :)
	    }
	    // first we have to check if the array can be split in multiple
	    // arrays of equal 'chunk' size
	    int rest = emails.length % chunkSize;  // if rest>0 then our last array will have less elements than the others
	    // then we check in how many arrays we can split our input array
	    int chunks = emails.length / chunkSize + (rest > 0 ? 1 : 0); // we may have to add an additional array for the 'rest'
	    // now we know how many arrays we need and create our result array
	    String[][] arrays = new String[chunks][];
	    // we create our resulting arrays by copying the corresponding
	    // part from the input array. If we have a rest (rest>0), then
	    // the last array will have less elements than the others. This
	    // needs to be handled separately, so we iterate 1 times less.
	    for(int i = 0; i < (rest > 0 ? chunks - 1 : chunks); i++){
	        // this copies 'chunk' times 'chunkSize' elements into a new array
	        arrays[i] = Arrays.copyOfRange(emails, i * chunkSize, i * chunkSize + chunkSize);
	    }
	    if(rest > 0){ // only when we have a rest
	        // we copy the remaining elements into the last chunk
	        arrays[chunks - 1] = Arrays.copyOfRange(emails, (chunks - 1) * chunkSize, (chunks - 1) * chunkSize + rest);
	    }
	    return arrays; // that's it
	}

}
