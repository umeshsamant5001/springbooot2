package com.capgemini.addin.back.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.addin.back.config.ApplicationProperties;
import com.capgemini.addin.back.model.Credentials;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = CredentialsController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CredentialsController {

    //static final String ROOT_API = "/api/credentials";
    static final String ROOT_API = "api/credentials";
    
    private final ApplicationProperties applicationProperties;

    public CredentialsController(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }


    @GetMapping
    public ResponseEntity<Credentials> getCredentials(
            @RequestHeader(value = "Accept-Language", required = false, defaultValue = "en") String language,
            @RequestHeader(value = "Authorization", required = true) String jwtIdentityToken) {

            Credentials credentials = new Credentials();
            //credentials.setUserName(applicationProperties.getCredentials().getUserName());
            //credentials.setUserPassword(applicationProperties.getCredentials().getUserPassword());
        return ResponseEntity.ok(credentials);
    }
}
