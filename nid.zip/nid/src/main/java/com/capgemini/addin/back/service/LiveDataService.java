package com.capgemini.addin.back.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.addin.back.mapper.LiveDataMapper;
import com.capgemini.addin.back.model.Device;
import com.capgemini.addin.back.model.EnumDeviceType;
import com.capgemini.addin.back.model.LiveDataDTO;
import com.capgemini.addin.back.model.SensorDataDTO;
import com.capgemini.addin.back.repository.DeviceRepository;

@Service
public class LiveDataService {
    private static final int MILLIS_IN_SECOND = 1000;
	private static final int SECONDS_IN_MIN = 60;
	private static final String FREE_STATE = "free";
	private static final String BUSY_STATE = "busy";
	private static final String LOCKED_STATE = "locked";
	private static final String DEFAULT_STATE = "unknown";
	public static final Integer DESK_LOCKING_TIME_MINUTES = 60;

    @Autowired
    private DeviceRepository deviceRepo;


    public SensorDataDTO getPoiSensorData(String name) {
		SensorDataDTO data = new SensorDataDTO();
		data.setOccupation(DEFAULT_STATE);
		List<Device> devices = deviceRepo.findAllByPoiName(name);
		List<LiveDataDTO> sensorData = new ArrayList<>();
		if (!Objects.isNull(devices)) {
			for (Device device : devices) {
				if (!Objects.isNull(device.getAttributes()) && !Objects.isNull(device.getStatus())
						&& !device.getStatus().equals("inactive")) {
					sensorData.add(LiveDataMapper.INSTANCE.deviceToLiveDataDTO(device));
				}
			}
		}
		if (!Objects.isNull(sensorData)) {
			data = updateSensorData(sensorData, data, name);
		}
		return data;
	}

    private SensorDataDTO updateSensorData(List<LiveDataDTO> sensorData, SensorDataDTO data, String name) {
		int intevalToConsiderFree = DESK_LOCKING_TIME_MINUTES * SECONDS_IN_MIN;
		Date now = new Date();
		String poiOccupation = "";
		for (LiveDataDTO device : sensorData) {
			if(Objects.nonNull(device.getPoiName())){
				if (device.getPoiName().equals(name)) {
					// for desk sensors, we need to add an "intelligence"
					// time duration is configurable with local entries
					if (EnumDeviceType.OFFICESENSE_DESK.name().equals(device.getDeviceType())) {
						if (LOCKED_STATE.equals(device.getOccupation())) {
							data.setOccupation(device.getOccupation());
						} else if (isDeskConsideredBusy(device, now, intevalToConsiderFree)) {
							data.setOccupation(BUSY_STATE);
						} else
							data.setOccupation(FREE_STATE);

						// With a Poi Desk we only have one sensor, so we break
						// after the first sensor found
						break;
					} else {
						if (poiOccupation.equals("") || (FREE_STATE.equals(poiOccupation))
								|| (DEFAULT_STATE.equals(poiOccupation))) {
							poiOccupation = device.getOccupation() != null ? device.getOccupation() : poiOccupation;
						} else if (BUSY_STATE.equals(poiOccupation)) {
							// do nothing
						}
					}
					data.setOccupation(poiOccupation);
					if (device.getCo2() != null) {
						data.setCo2(Double.valueOf(device.getCo2()));
					}
					if (device.getLux() != null) {
						data.setLight(Double.valueOf(device.getLux()));
					}

					if (device.getSound() != null) {
						data.setNoise(Double.valueOf(device.getSound()));
					}

					if (device.getHumidity() != null) {
						data.setHumidity(Double.valueOf(device.getHumidity()));
					}

					if (device.getTempc() != null) {
						data.setTempC(Double.valueOf(device.getTempc()));
					}
				}
			}
		}
		return data;
	}

    private boolean isDeskConsideredBusy(LiveDataDTO device, Date now, Integer intevalToConsiderFree) {
		try {
			if (device != null && BUSY_STATE.equals(device.getOccupation())) {
				return true;
			}
			if (device != null && FREE_STATE.equals(device.getOccupation()) && device.getLastOccupiedDate() != null) {
				Long occupiedTs = Long.valueOf(device.getLastOccupiedDate());
				long nowSecond = now.getTime() / MILLIS_IN_SECOND;
				long lastOccupiedTimeInterval = nowSecond - occupiedTs;
				return lastOccupiedTimeInterval < intevalToConsiderFree;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}
}
