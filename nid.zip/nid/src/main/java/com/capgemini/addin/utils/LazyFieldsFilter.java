package com.capgemini.addin.utils;

import org.hibernate.Hibernate;

public class LazyFieldsFilter {
    @Override
    public boolean equals(Object obj) {
        return !Hibernate.isInitialized(obj);
    }
}
