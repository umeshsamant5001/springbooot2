package com.capgemini.addin.back.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.MutableDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.addin.back.config.GraphHelper;
import com.capgemini.addin.back.model.Attendee;
import com.capgemini.addin.back.model.DaySuggestionsWindow;
import com.capgemini.addin.back.model.Human;
import com.capgemini.addin.back.model.PoiSensorDataDTO;
import com.capgemini.addin.back.model.QualificationEnum;
import com.capgemini.addin.back.model.RoomSearchParameters;
import com.microsoft.graph.models.ScheduleInformation;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GraphGetRoomsAvailableService {

	private static final long MORE_OR_LESS = 7_200_000; // 2 hours in milliseconds
	private static final long FIVE_MINUTES = 300_000; // 5 minutes in milliseconds

	@Autowired
	GraphHelper graphHelper;

	/**
	 * Get list of DaySuggestionsWindow thanks to Graph API
	 *
	 * @param parameters : RoomSearchParameters
	 * @param confrooms  : list of PoiMobileDTO
	 * @return : list of DaySuggestionsWindow
	 */
	public List<DaySuggestionsWindow> getListDaySuggestionsWindow(RoomSearchParameters parameters,
			List<PoiSensorDataDTO> confrooms) {
		long start = java.lang.System.currentTimeMillis();

		HashMap<String, TreeMap<String, List<String>>> hashMapRoomsTimeSlot = new HashMap<>();
		List<String> schedulesList = getListRooms(parameters, confrooms, hashMapRoomsTimeSlot);
		List<DaySuggestionsWindow> daySuggestionsWindows = new ArrayList<>();

		// Get duration
		Double duree = parameters.getDuration().doubleValue() * 3600 * 1000;

		log.info("longStart : " + parameters.getStartTime() + " time zone : " + parameters.getBuildingJavaZone());

		// Set time
		MutableDateTime dateTimeStartUTC = new MutableDateTime(parameters.getStartTime().longValue() * 1000);
		dateTimeStartUTC.setZone(DateTimeZone.UTC);
		log.info("Start UTC : " + dateTimeStartUTC.toDateTime().toString());

		MutableDateTime dateTimeEndtUTC = new MutableDateTime(
				dateTimeStartUTC.getMillis() + duree.longValue() + MORE_OR_LESS);
		dateTimeEndtUTC.setZone(DateTimeZone.UTC);
		log.info("End UTC : " + dateTimeEndtUTC.toDateTime().toString());

		if (CollectionUtils.isNotEmpty(schedulesList)) {
			log.info("schedulesList size() >>> "+schedulesList.size());
			List<ScheduleInformation> scheduleInformations = new ArrayList<>();

			// commented on this date 12-March-2026 code for this Bug #1707887 

			// if (schedulesList.size() <= 20) {
			// 	try {
			// 		// Call graph api
			// 		scheduleInformations = graphHelper.getSchedule(dateTimeStartUTC.toDateTime(),
			// 				dateTimeEndtUTC.toDateTime(), schedulesList, schedulesList.get(0)).get();
			// 	} catch (InterruptedException | ExecutionException e) {
			// 		log.error(e.getMessage());
			// 	}
			// } else { // we need to split String array graph api limit 20 'attendees' in one request
			// 	String[][] attendeesSplits = splitArray(schedulesList.toArray(new String[0]), 4);
			// 	for (String[] attendeesInfoArray : attendeesSplits) {
			// 		try {
			// 			// Call graph api
			// 			List<ScheduleInformation> chunksuggestedTimeWindows = graphHelper
			// 					.getSchedule(dateTimeStartUTC.toDateTime(), dateTimeEndtUTC.toDateTime(),
			// 							Arrays.asList(attendeesInfoArray), schedulesList.get(0))
			// 					.get();
			// 			scheduleInformations.addAll(chunksuggestedTimeWindows);
			// 		} catch (Exception e) {
			// 			log.error(e.getMessage());
			// 		}
			// 	}
			// }

			// Added on 12-March-2026 Bug #1707887
            String requesterMail = getOrganizerEmail(parameters).get();
            log.info("if user " + requesterMail + " exists" +  graphHelper.userExists(requesterMail));
 
			// Graph API has limit of 20 shchdules so creating chunk of 20 sheddules
            List<List<String>> batches = schedulesList.size() <= 20
                    ? List.of(schedulesList)
                    : chunk(schedulesList, 20);
 
            for (List<String> batch : batches) {
                try {
                    List<ScheduleInformation> chunkResult =
                        graphHelper.getSchedule(
                            dateTimeStartUTC.toDateTime(),
                            dateTimeEndtUTC.toDateTime(),
                            batch,
                            requesterMail   // organizer or service mailbox, NOT a room
                        ).get();
 
                    scheduleInformations.addAll(chunkResult);
                } catch (Exception e) {
                    log.error("getSchedule failed for batch {}: {}", batch, e.getMessage(), e);
                }
            }

			log.info("Size of scheduleInformations : " + scheduleInformations.size());
			// Update hashmap with graph api result
			updateHashMapRoomsTimeSlot(hashMapRoomsTimeSlot, scheduleInformations, dateTimeStartUTC.toDateTime());
			// Sort the map
			sortTreeMap(hashMapRoomsTimeSlot);
			// Contains a list of 'DaySuggestionsWindow' some are duplicates
			List<DaySuggestionsWindow> suggestions = new ArrayList<>();

			hashMapRoomsTimeSlot.forEach((key, value) -> {

				List<String> listRequestAttendee = this.getListAttendeeRequired(parameters.getAttendees());
				listRequestAttendee.remove(this.findOrganizer(parameters.getAttendees()));
				long numberOfSlots = (long) Math.ceil(duree.longValue() / FIVE_MINUTES);
				log.info("mail : " + key);
				// Update Suggestions
				extractTimeslots(value, suggestions, numberOfSlots, key, confrooms, parameters.getCheckDisponibility(),
						listRequestAttendee);
			});

			// Remove duplicates day suggestions
			daySuggestionsWindows = removeDuplicates(suggestions);
		}

		long execTime = java.lang.System.currentTimeMillis() - start;
		log.debug(String.format("Execution time: %s ms", execTime));

		return daySuggestionsWindows;
	}

	// Added on 12-March-2026 Bug #1707887
	private Optional<String> getOrganizerEmail(RoomSearchParameters parameters) {
        if (parameters.getAttendees() == null) return Optional.empty();
        return parameters.getAttendees().stream()
            .filter(a -> "organizer".equalsIgnoreCase(a.getQualification()))
            .map(a -> a.getParticipant())
            //filter(Objects::nonNull);
            .map(Human ::getEmail)
            //.filter(StringUtils::isNotBlank)
            .findFirst();
    }
	// Added on 12-March-2026 Bug #1707887
	private static List<List<String>> chunk(List<String> source, int size) {
        List<List<String>> res = new ArrayList<>();
        for (int i = 0; i < source.size(); i += size) {
            res.add(source.subList(i, Math.min(i + size, source.size())));
        }
        return res;
    }

	/**
	 * Update hashMap
	 *
	 * @param hashMap
	 * @param scheduleInformations : result of graph api
	 * @param longStart            : start date represented by a long
	 */
	private void updateHashMapRoomsTimeSlot(HashMap<String, TreeMap<String, List<String>>> hashMap,
			List<ScheduleInformation> scheduleInformations, DateTime start) {
		for (ScheduleInformation scheduleInformation : scheduleInformations) {
			if (Objects.isNull(scheduleInformation.error)) {
				// If schedule is schedule of an room
				if (hashMap.containsKey(scheduleInformation.scheduleId)) {
					TreeMap<String, List<String>> treeMapTimeslot = updateTreeMapTimeSlot(
							hashMap.get(scheduleInformation.scheduleId), scheduleInformation.availabilityView, start,
							scheduleInformation.scheduleId);
					hashMap.put(scheduleInformation.scheduleId, treeMapTimeslot);
				} else {
					// Update all rooms(key)
					hashMap.forEach((key, value) -> {
						TreeMap<String, List<String>> treeMapTimeslot = updateTreeMapTimeSlot(hashMap.get(key),
								scheduleInformation.availabilityView, start, scheduleInformation.scheduleId);
						hashMap.put(key, treeMapTimeslot);
					});
				}
			} else {
				log.info(scheduleInformation.scheduleId + " is not valid");
				hashMap.remove(scheduleInformation.scheduleId);
			}
		}
	}

	/**
	 * return a treeMapTimeslot update
	 *
	 * @param treeMapTimeslot
	 * @param availabilityView : represent all five-minute time slots
	 * @param longStart        : start date represented by a long
	 * @param calendar         : mail
	 * @return treeMapTimeslot
	 */
	private TreeMap<String, List<String>> updateTreeMapTimeSlot(TreeMap<String, List<String>> treeMapTimeslot,
			String availabilityView, DateTime start, String calendar) {
		MutableDateTime newDateTime = new MutableDateTime(start.getMillis() - FIVE_MINUTES);
		newDateTime.setZone(DateTimeZone.UTC);

		for (String numero : availabilityView.split("")) {
			newDateTime = new MutableDateTime(newDateTime.getMillis() + FIVE_MINUTES);
			String stringNewDateTime = newDateTime.toDateTime().toString().split("\\+")[0];
			// User is free(0) or temporary(1)
			// Using contains because equal doesn't work
			if (numero.contains("0") || numero.contains("1")) {
				if (treeMapTimeslot.containsKey(stringNewDateTime)) {
					List<String> listCalendar = treeMapTimeslot.get(stringNewDateTime);
					listCalendar.add(calendar);
					treeMapTimeslot.put(stringNewDateTime, listCalendar);
				} else {
					List<String> listCalendar = new ArrayList<>();
					listCalendar.add(calendar);
					treeMapTimeslot.put(stringNewDateTime, listCalendar);
				}
			} else { // The user is busy, so we add the key and add an empty list
				if (!treeMapTimeslot.containsKey(stringNewDateTime)) {
					List<String> listCalendar = new ArrayList<>();
					treeMapTimeslot.put(stringNewDateTime, listCalendar);
				}
			}
		}
		return treeMapTimeslot;
	}

	/**
	 * Sort hashmap by date
	 *
	 * @param hashMapRoomsTimeSlot : hashmap
	 */
	private void sortTreeMap(HashMap<String, TreeMap<String, List<String>>> hashMapRoomsTimeSlot) {
		hashMapRoomsTimeSlot.forEach((key, value) -> {
			TreeMap<String, List<String>> sortedMap = new TreeMap<>(new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					DateTime debut = new DateTime(o1);
					DateTime fin = new DateTime(o2);
					return debut.compareTo(fin);
				}
			});

			sortedMap.putAll(value);
			hashMapRoomsTimeSlot.put(key, sortedMap);
		});
	}

	/**
	 * Get a list of rooms and attendees
	 *
	 * @param parameters
	 * @param confrooms
	 * @param hashMapRoomsTimeSlot
	 * @return
	 */
	private List<String> getListRooms(RoomSearchParameters parameters, List<PoiSensorDataDTO> confrooms,
			HashMap<String, TreeMap<String, List<String>>> hashMapRoomsTimeSlot) {
		List<String> schedulesList = new ArrayList<>();

		if (Boolean.TRUE.equals(parameters.getCheckDisponibility())) {
			String organizer = findOrganizer(parameters.getAttendees());
			// Add required people but not the organizer
			parameters.getAttendees().stream()
					.filter(attendee -> Objects.nonNull(attendee.getParticipant().getEmail())
							&& attendee.computeQualificationEnum() == QualificationEnum.REQUIRED
							&& !attendee.getParticipant().getEmail().equals(organizer))
					.allMatch(attendee -> schedulesList.add(attendee.getParticipant().getEmail()));
		}

		// Add confrooms
		for (PoiSensorDataDTO poiMobileDTO : confrooms) {
			if (Objects
					.nonNull(poiMobileDTO.getAttributes().containsKey(GraphCommon.POI_MEETING_ROOM_EMAIL_ATTRIBUTE))) {
				String email = poiMobileDTO.getAttributes().get(GraphCommon.POI_MEETING_ROOM_EMAIL_ATTRIBUTE);
				if (Objects.nonNull(email) && GraphCommon.isValidEmailAddress(email)) {
					schedulesList.add(email);
					hashMapRoomsTimeSlot.put(email, new TreeMap<>());
				}
			}
		}
		return schedulesList;
	}

	/**
	 * find the organizer
	 *
	 * @param attendees
	 * @return
	 */
	private String findOrganizer(List<Attendee> attendees) {
		Optional<Attendee> value = attendees.stream()
				.filter(attendee -> Objects.nonNull(attendee.getParticipant().getEmail())
						&& (attendee.computeQualificationEnum() == QualificationEnum.ORGANIZER))
				.findFirst();
		if (Boolean.TRUE.equals(value.isPresent())) {
			return value.get().getParticipant().getEmail();
		} else {
			return "";
		}
	}

	/**
	 * Create a time slot
	 *
	 * @param treeMapTimeslot
	 * @param daySuggestionsWindows
	 * @param size
	 * @param numberOfSlots
	 * @param room
	 * @param confrooms
	 */
	private void extractTimeslots(TreeMap<String, List<String>> treeMapTimeslot,
			List<DaySuggestionsWindow> daySuggestionsWindows, long numberOfSlots, String room,
			List<PoiSensorDataDTO> confrooms, boolean checkAttendee, List<String> listRequestAttendee) {
		int counter = 0;
		String start = "";
		for (Entry<String, List<String>> entry : treeMapTimeslot.entrySet()) {

			if ((entry.getValue().contains(room) && Boolean.FALSE.equals(checkAttendee))
					|| (entry.getValue().containsAll(listRequestAttendee) && entry.getValue().contains(room)
							&& Boolean.TRUE.equals(checkAttendee))) {
				if (counter == 0)
					start = entry.getKey();
				counter = counter + 1;
			} else {
				counter = 0;
			}

			if (counter == numberOfSlots) {
				DaySuggestionsWindow daySuggestionsWindow = createDaySuggestion(start, room, confrooms);
				daySuggestionsWindows.add(daySuggestionsWindow);
				counter = 0;
			}
		}
	}

	/**
	 * Create list of DaySuggestionsWindow
	 *
	 * @param meetings  contains the list of time slots and associated locations
	 * @param confrooms list of PoiMbileDTO
	 * @return list of DaySuggestionsWindow
	 */
	private DaySuggestionsWindow createDaySuggestion(String start, String room, List<PoiSensorDataDTO> confrooms) {
		// Create a DaySuggestionsWindow
		DaySuggestionsWindow daySuggestionsWindow = new DaySuggestionsWindow();

		MutableDateTime dateTime = new MutableDateTime(start);
		dateTime.setZone(DateTimeZone.UTC);
		// Set Time
		BigDecimal time = new BigDecimal(dateTime.getMillis() / 1000);
		daySuggestionsWindow.setTime(time);
		log.info("DateTime : " + dateTime.toString() + " Long value : " + dateTime.getMillis() / 1000);

		List<PoiSensorDataDTO> poiMobileDTOsList = new ArrayList<>();
		// look if room is in confrooms and if true return it
		PoiSensorDataDTO poiMobileDTO = GraphCommon.isInTheList(room, confrooms);
		if (Objects.nonNull(poiMobileDTO)) {
			// Add poiMobileDTO to the list
			poiMobileDTOsList.add(poiMobileDTO);
		}
		// Set rooms
		daySuggestionsWindow.setRooms(poiMobileDTOsList);

		return daySuggestionsWindow;
	}

	/**
	 * Merge duplicates
	 *
	 * @param daySuggestionsWindows
	 * @return : list of DaySuggestionsWindow
	 */
	private List<DaySuggestionsWindow> removeDuplicates(List<DaySuggestionsWindow> daySuggestionsWindows) {
		List<DaySuggestionsWindow> newList = new ArrayList<>();
		for (DaySuggestionsWindow daySuggestionsWindow : daySuggestionsWindows) {
			DaySuggestionsWindow day = alreadyExist(newList, daySuggestionsWindow.getTime());
			if (Objects.isNull(day)) {
				newList.add(daySuggestionsWindow);
			} else {
				day.addRoomsItems(daySuggestionsWindow.getRooms());
			}
		}
		return newList;
	}

	/**
	 * See if the time slot already exists
	 *
	 * @param daySuggestionsWindows
	 * @param timeslot
	 * @return
	 */
	private DaySuggestionsWindow alreadyExist(List<DaySuggestionsWindow> daySuggestionsWindows, BigDecimal timeslot) {
		Optional<DaySuggestionsWindow> value = daySuggestionsWindows.stream()
				.filter(daySuggestionsWindow -> daySuggestionsWindow.getTime().equals(timeslot)).findFirst();
		if (Boolean.TRUE.equals(value.isPresent())) {
			return value.get();
		} else {
			return null;
		}
	}

	/**
	 * Create an array of String and each array has chunkSize as size
	 *
	 * @param attendees : array of String
	 * @param chunkSize : size
	 * @return matrice
	 */
	private static String[][] splitArray(String[] attendees, int chunkSize) {
		if (chunkSize <= 0) {
			return new String[0][0]; // just in case :)
		}
		// first we have to check if the array can be split in multiple
		// arrays of equal 'chunk' size
		int rest = attendees.length % chunkSize; // if rest>0 then our last array will have less elements than the
													// others
		// then we check in how many arrays we can split our input array
		int chunks = attendees.length / chunkSize + (rest > 0 ? 1 : 0); // we may have to add an additional array for
																		// the 'rest'
		// now we know how many arrays we need and create our result array
		String[][] arrays = new String[chunks][];
		// we create our resulting arrays by copying the corresponding
		// part from the input array. If we have a rest (rest>0), then
		// the last array will have less elements than the others. This
		// needs to be handled separately, so we iterate 1 times less.
		for (int i = 0; i < (rest > 0 ? chunks - 1 : chunks); i++) {
			// this copies 'chunk' times 'chunkSize' elements into a new array
			arrays[i] = Arrays.copyOfRange(attendees, i * chunkSize, i * chunkSize + chunkSize);
		}
		if (rest > 0) { // only when we have a rest
			// we copy the remaining elements into the last chunk
			arrays[chunks - 1] = Arrays.copyOfRange(attendees, (chunks - 1) * chunkSize,
					(chunks - 1) * chunkSize + rest);
		}
		return arrays; // that's it
	}

	/**
	 *
	 * @param attendees
	 * @return
	 */
	private List<String> getListAttendeeRequired(List<Attendee> attendees) {
		return attendees.stream()
				.filter(attendee -> Objects.nonNull(attendee.getParticipant().getEmail())
						&& attendee.computeQualificationEnum() == QualificationEnum.REQUIRED)
				.map(mail -> mail.getParticipant().getEmail()).collect(Collectors.toList());
	}
}
