package com.capgemini.addin.back.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.capgemini.addin.back.model.Poi;
import com.capgemini.addin.back.model.PoiDTO;

@Mapper
public interface PoiMapper {

    PoiMapper INSTANCE = Mappers.getMapper(PoiMapper.class);

    PoiDTO poiToPoiDTO(Poi in);

    Poi poiDTOToPoi(PoiDTO in);

    /**
     * Map the Poi to PoiDTO without any joined data.
     */
    @Mapping(target="poiGroup.attributeKeys", ignore=true)
    @Mapping(target="poiGroup.attributes", ignore=true)
    PoiDTO poiToPoiDTONoJoin(Poi in);
}

