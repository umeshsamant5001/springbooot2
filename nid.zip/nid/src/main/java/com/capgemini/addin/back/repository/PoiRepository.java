package com.capgemini.addin.back.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.addin.back.model.Building;
import com.capgemini.addin.back.model.Floor;
import com.capgemini.addin.back.model.Poi;

@Repository
public interface PoiRepository extends JpaRepository<Poi, Long> {
    static final String JOIN_POI_ATTRI = "left outer join poi_attributes att on poi.id = att.poi_id and att.att_key = :attKeyWanted ";
    static final String JOIN_POI_VISIBILITY =
        "left outer join poi_attributes att_poiVisibility on poi.id = att_poiVisibility.poi_id and att_poiVisibility.att_key = 'poiVisibility'";
    static final String WHERE_POI_VISIBILITY = "and (att_poiVisibility.att_value not like 'false' or att_poiVisibility.att_value is null )";

    @RestResource(exported = false)
    @Query(value = " SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id " + 
                " INNER JOIN floor f ON p.floor_id = f.id " + 
                " INNER JOIN building b ON f.building_id = b.id " + 
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi'  " + 
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " + 
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
                " WHERE b.id = :buildingId  AND st.space_type_name IN (:spaceTypeList) " + 
                " AND (fa.att_key IS NULL OR fa.att_value != 'true')  " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '')  " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true) 
    List<Poi> findAllBySpaceTypeAndFloorBuildingIdOld(@Param("spaceTypeList") List<String> spaceTypeList, @Param("buildingId") Long buildingId);

    @RestResource(exported = false)
    @Query(value = "SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id" + 
                " INNER JOIN floor f ON p.floor_id = f.id " + 
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true'  " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi'  " + 
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " + 
                " WHERE f.id = :floorId " + 
                " AND st.space_type_name IN (:spaceTypeList) " + 
                " AND (fa.att_key IS NULL OR fa.att_value != 'true')  " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '')   " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true)
    List<Poi> findAllBySpaceTypeAndFloorIdOld(@Param("spaceTypeList") List<String> spaceTypeList, @Param("floorId") Long floorId);


    //@RestResource(exported = false)
    @Query(value = "SELECT " + 
                "    p.id, " + 
                "    CASE" + 
                "        WHEN c.poi_id IS NOT NULL THEN 'cisco' " + 
                "        ELSE ''" + 
                "    END AS device_type " + 
                "FROM poi p " + 
                "INNER JOIN space_type st " + 
                "    ON p.space_type_id = st.id " + 
                "INNER JOIN floor f " + 
                "    ON p.floor_id = f.id " + 
                " INNER JOIN building b " + 
                "ON f.building_id = b.id " +
                "LEFT JOIN floor_attribute fa " + 
                "    ON fa.floor_id = p.floor_id " + 
                "   AND fa.att_key = 'hidden' " + 
                "   AND fa.att_value = 'true' " + 
                "LEFT JOIN poi_attributes pa_hide_poi " + 
                "    ON p.id = pa_hide_poi.poi_id " + 
                "   AND pa_hide_poi.att_key = 'hidePoi' " + 
                "LEFT JOIN poi_attributes pa_conf_room_mail " + 
                "    ON p.id = pa_conf_room_mail.poi_id " + 
                "   AND pa_conf_room_mail.att_key = 'conf_room_mail' " + 
                "LEFT JOIN (" + 
                "    SELECT DISTINCT " + 
                "        pa.poi_id " + 
                "    FROM cisco_device cd " + 
                "    INNER JOIN poi_attributes pa" + 
                "        ON pa.att_key = 'conf_room_mail' " + 
                "       AND pa.att_value = cd.email_id " + 
                ") c" + 
                "    ON c.poi_id = p.id " + 
                "" + 
                "INNER JOIN category_mapping cm " + 
                "    ON cm.space_type_id = st.id " + 
                "" + 
                "WHERE st.space_type_name IN (:spaceTypeList) " + 
                "  AND b.id = :buildingId " + 
                "  AND (fa.att_key IS NULL OR fa.att_value <> 'true') " + 
                "  AND (" + 
                "        pa_hide_poi.att_value IS NULL " + 
                "        OR pa_hide_poi.att_value = 'false' " + 
                "        OR pa_hide_poi.att_value = '' " + 
                "      ) " + 
                "  AND pa_conf_room_mail.att_value IS NOT NULL " + 
                "  AND pa_conf_room_mail.att_value <> '' " + 
                "  AND cm.category = 'bookable' "  // Check for 'bookable' category
                , nativeQuery = true)
    List<Object[]> findAllBySpaceTypeAndFloorBuildingId(@Param("spaceTypeList") List<String> spaceTypeList, @Param("buildingId") Long buildingId);

    //@RestResource(exported = false)
    @Query(value = "SELECT " + 
                "    p.id, " + 
                "    CASE" + 
                "        WHEN c.poi_id IS NOT NULL THEN 'cisco' " + 
                "        ELSE ''" + 
                "    END AS device_type " + 
                "FROM poi p " + 
                "INNER JOIN space_type st " + 
                "    ON p.space_type_id = st.id " + 
                "INNER JOIN floor f " + 
                "    ON p.floor_id = f.id " + 
                "LEFT JOIN floor_attribute fa " + 
                "    ON fa.floor_id = p.floor_id " + 
                "   AND fa.att_key = 'hidden' " + 
                "   AND fa.att_value = 'true' " + 
                "LEFT JOIN poi_attributes pa_hide_poi " + 
                "    ON p.id = pa_hide_poi.poi_id " + 
                "   AND pa_hide_poi.att_key = 'hidePoi' " + 
                "LEFT JOIN poi_attributes pa_conf_room_mail " + 
                "    ON p.id = pa_conf_room_mail.poi_id " + 
                "   AND pa_conf_room_mail.att_key = 'conf_room_mail' " + 
                "LEFT JOIN (" + 
                "    SELECT DISTINCT " + 
                "        pa.poi_id " + 
                "    FROM cisco_device cd " + 
                "    INNER JOIN poi_attributes pa" + 
                "        ON pa.att_key = 'conf_room_mail' " + 
                "       AND pa.att_value = cd.email_id " + 
                ") c" + 
                "    ON c.poi_id = p.id " + 
                "" + 
                "INNER JOIN category_mapping cm " + 
                "    ON cm.space_type_id = st.id " + 
                "" + 
                "WHERE st.space_type_name IN (:spaceTypeList) " + 
                "  AND p.floor_id = :floorId " + 
                "  AND (fa.att_key IS NULL OR fa.att_value <> 'true') " + 
                "  AND (" + 
                "        pa_hide_poi.att_value IS NULL " + 
                "        OR pa_hide_poi.att_value = 'false' " + 
                "        OR pa_hide_poi.att_value = '' " + 
                "      ) " + 
                "  AND pa_conf_room_mail.att_value IS NOT NULL " + 
                "  AND pa_conf_room_mail.att_value <> '' " + 
                "  AND cm.category = 'bookable' " // Check for 'bookable' category
                , nativeQuery = true)
    List<Object[]> findAllBySpaceTypeAndFloorId(@Param("spaceTypeList") List<String> spaceTypeList, @Param("floorId") Long floorId);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    List<Poi> findAllByFloorIdOrderByName(@Param("floorId") Long floorId);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    Poi findByName(@Param("name") String name);

    // Don't seem to be used, to delete in that case
    @RestResource(exported = false)
    Poi findByFloorIdAndName(@Param("floorId") Long floorId, @Param("name") String name);

    /**
     * Return all Poi of a {@link Building}
     *
     * @param buildingId Id of the {@link Building}
     * @return
     */
    @RestResource(exported = false)
    @Query(value = "SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id " +  
                " INNER JOIN poi_group pg ON st.poi_group_id = pg.id " +  
                " INNER JOIN floor f ON p.floor_id = f.id " +  
                " INNER JOIN building b ON f.building_id = b.id " +  
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi' " +  
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
                " WHERE b.id = :buildingId " +  
                " AND (fa.att_key IS NULL OR fa.att_value != 'true') " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '') " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true) 
    List<Poi> findAllByBuildingId(@Param("buildingId") Long buildingId);

    /**
     * Return all {@link Poi} of a {@link Building} and of certains poiGroups
     *
     * @param buildingId  Id of the {@link Building}
     * @param poiGroupList List of Poi poiGroup
     * @return
     */
    @RestResource(exported = false)
    @Query(value = " SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id " + 
                " INNER JOIN floor f ON p.floor_id = f.id " + 
                " INNER JOIN building b ON f.building_id = b.id " + 
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true' " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi'  " + 
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " + 
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
                " WHERE b.id = :buildingId  AND st.space_type_name IN (:spaceTypeList) " + 
                " AND (fa.att_key IS NULL OR fa.att_value != 'true')  " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '')  " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true) 
    List<Poi> findAllByBuildingIdAndSpaceTypeList(@Param("buildingId") Long buildingId, @Param("spaceTypeList") List<String> poiGroupList);

    /**
     * Return all {@link Poi} of a {@link Building} excepts those of certains poiGroups
     *
     * @param buildingId     Id of the {@link Building}
     * @param excludePoiGroup List of Poi poiGroup to exclude
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi " +
        "FROM Poi poi " +
        "INNER JOIN FETCH poi.spaceType spaceType " +
        "INNER JOIN FETCH spaceType.poiGroup poiGroup " +
        "INNER JOIN FETCH poi.floor floor " +
        "INNER JOIN floor.building building " +
        "WHERE building.id = :buildingId " +
        "AND poiGroup.name NOT IN (:excludePoiGroup)"
    )
    List<Poi> findAllByBuildingIdExcludePoiGroup(
        @Param("buildingId") Long buildingId,
        @Param("excludePoiGroup") List<String> excludePoiGroup
    );

    /**
     * Return all {@link Poi} of a {@link Floor}
     *
     * @param floorId Id of the {@link Floor}
     * @return List of Pois
     */
    @RestResource(exported = false)
    @Query(value = "SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id " + 
                " INNER JOIN poi_group pg ON st.poi_group_id = pg.id " + 
                " INNER JOIN floor f ON p.floor_id = f.id " + 
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true'  " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi'  " + 
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail'" + 
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " +
                " WHERE f.id = :floorId " + 
                " AND (fa.att_key IS NULL OR fa.att_value != 'true')  " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '')  " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true)
    List<Poi> findAllByFloorId(@Param("floorId") Long floorId);

    /**
     * Return all {@link Poi} of a {@link Floor} and specific poiGroups
     *
     * @param floorId     Id of the {@link Floor}
     * @param poiGroupList List of PoiGroup names
     * @return List of Pois
     */
    @RestResource(exported = false)
    @Query(value = "SELECT p.* " + 
                " FROM poi p " + 
                " INNER JOIN space_type st ON p.space_type_id = st.id" + 
                " INNER JOIN floor f ON p.floor_id = f.id " + 
                " LEFT JOIN floor_attribute fa ON fa.floor_id = p.id AND fa.att_key = 'hidden' AND fa.att_value = 'true'  " + 
                " LEFT JOIN poi_attributes pa_hide_poi ON p.id = pa_hide_poi.poi_id AND pa_hide_poi.att_key = 'hidePoi'  " + 
                " LEFT JOIN poi_attributes pa_conf_room_mail ON p.id = pa_conf_room_mail.poi_id AND pa_conf_room_mail.att_key = 'conf_room_mail' " +
                " INNER JOIN category_mapping cm ON cm.space_type_id = st.id " + 
                " WHERE f.id = :floorId " + 
                " AND st.space_type_name IN (:spaceTypeList) " + 
                " AND (fa.att_key IS NULL OR fa.att_value != 'true')  " + 
                " AND (pa_hide_poi.att_value IS NULL OR pa_hide_poi.att_value = 'false' OR pa_hide_poi.att_value = '')   " + 
                " AND pa_conf_room_mail.att_value IS NOT NULL AND pa_conf_room_mail.att_value <> ''" +
                " AND cm.category = 'bookable'" // Check for 'bookable' category
                , nativeQuery = true)
    List<Poi> findAllByFloorIdAndSpaceTypeName(@Param("floorId") Long floorId, @Param("spaceTypeList") List<String> poiGroupList);

    /**
     * Return all {@link Poi} of a {@link Floor} excepts those of certains poiGroups
     *
     * @param floorId        Id of the {@link Floor}
     * @param excludePoiGroup List of Poi poiGroup to exclude
     * @return
     */
    @RestResource(exported = false)
    @Query(
        "SELECT poi " +
        "FROM Poi poi " +
        "INNER JOIN FETCH poi.spaceType spaceType " +
        "INNER JOIN FETCH spaceType.poiGroup poiGroup " +
        "INNER JOIN FETCH poi.floor floor " +
        "WHERE floor.id = :floorId " +
        "AND poiGroup.name NOT IN (:excludePoiGroup)"
    )
    List<Poi> findAllByFloorIdExcludePoiGroup(@Param("floorId") Long floorId, @Param("excludePoiGroup") List<String> excludePoiGroup);

    List<Poi> findAllByNameIn(@Param("name") List<String> name);

    @Query(
        "SELECT poi FROM Poi poi " +
        "INNER JOIN Device device ON poi.name = device.poiName " +
        "INNER JOIN device.attributes attribute " +
        "INNER JOIN FETCH poi.spaceType spaceType " +
        "INNER JOIN poi.floor floor " +
        "INNER JOIN floor.building building " +
        "WHERE building.id = :buildingId " +
        "AND spaceType.spaceTypeName IN (:spaceTypeNames) " +
        "AND index(attribute) = 'state' " +
        "AND attribute = 'free'"
    )
    List<Poi> findAllFreePoisInType(@Param("buildingId") Long buildingId, @Param("spaceTypeNames") List<String> spaceTypeNames);

    // Controller only
    // Query use for the order by on floor index and on capacity value
    @RestResource(exported = false)
    @Query(
        value = "select poi.* from sw_pois poi left join sw_floors flo on poi.floor_id = flo.id " +
        JOIN_POI_ATTRI +
        JOIN_POI_VISIBILITY +
        "where poi.id in ( :poiId ) poi.poi_group_id  in ( :groupsId ) " +
        WHERE_POI_VISIBILITY +
        "order by flo.floor_index, att.att_value;",
        nativeQuery = true
    )
    List<Poi> findAllByIdInAndTypeInOrderByFloorIndexAndAttribute(
        @Param("poiId") @RequestParam("poiId") List<Long> poiId,
        @Param("groupsId") @RequestParam("groupsId") List<Long> groupsId,
        @Param("attKeyWanted") @RequestParam("attKeyWanted") String attKeyWanted
    );

    // Controller only
    // Query use for the order by on floor index and on capacity value
    @RestResource(exported = false)
    @Query(
        value = "select poi.* from sw_pois poi left join sw_floors flo on poi.floor_id = flo.id " +
        JOIN_POI_ATTRI +
        JOIN_POI_VISIBILITY +
        "where poi.poi_group_id  in ( :groupsId ) " +
        WHERE_POI_VISIBILITY +
        " order by flo.floor_index, att.att_value;",
        nativeQuery = true
    )
    List<Poi> findAllByTypeIdInOrderByFloorIndex(
        @Param("groupsId") @RequestParam("groupsId") List<Long> groupsId,
        @Param("attKeyWanted") @RequestParam("attKeyWanted") String attKeyWanted
    );

    // Controller only
    // Query use for the order by on capacity value
    @RestResource(exported = false)
    @Query(
        value = "select poi.* from sw_pois poi " +
        JOIN_POI_ATTRI +
        JOIN_POI_VISIBILITY +
        "where poi.floor_id = :floorId AND poi.poi_group_id  in ( :groupsId ) " +
        WHERE_POI_VISIBILITY +
        "order by att.att_value;",
        nativeQuery = true
    )
    List<Poi> findAllByFloorIdAndInTypeIdOrderByAttribute(
        @Param("floorId") @RequestParam("floorId") Long floorId,
        @Param("groupsId") @RequestParam("groupsId") List<Long> groupsId,
        @Param("attKeyWanted") @RequestParam("attKeyWanted") String attKeyWanted
    );

    // Controller only
    // Query use for the order by on floor index and the order on capacity value
    @RestResource(exported = false)
    @Query(
        value = "select poi.* from sw_pois poi left join sw_floors flo on poi.floor_id = flo.id " +
        "inner join sw_buildings bui on flo.building_id = bui.id " +
        JOIN_POI_ATTRI +
        JOIN_POI_VISIBILITY +
        "where bui.site_id = :siteId AND poi.poi_group_id in(:groupsId) " +
        WHERE_POI_VISIBILITY +
        "order by flo.floor_index, att.att_value;",
        nativeQuery = true
    )
    List<Poi> findAllByFloorBuildingSiteIdAndInTypeIdOrderByFloorIndexAndAttribute(
        @Param("siteId") @RequestParam("siteId") Long siteId,
        @Param("groupsId") @RequestParam("groupsId") List<Long> groupsId,
        @Param("attKeyWanted") @RequestParam("attKeyWanted") String attKeyWanted
    );

    // Controller only
    // Query use for the order by on floor index and the order on capacity value
    @RestResource(exported = false) // with att.att_key = 'capacity'
    @Query(
        value = "select poi.* from sw_pois poi left join sw_floors flo on poi.floor_id = flo.id " +
        JOIN_POI_ATTRI +
        JOIN_POI_VISIBILITY +
        "where flo.building_id = :buildingId AND poi.poi_group_id in(:groupsId) and att_vis.att_value not like 'false' or flo.building_id = :buildingId AND poi.poi_group_id in(:groupsId) and att_vis.att_value is null" +
        "order by flo.floor_index, att.att_value;",
        nativeQuery = true
    )
    List<Poi> findAllByFloorBuildingIdAndInTypeIdOrderByFloorIndexAndAttribute(
        @Param("buildingId") @RequestParam("buildingId") Long buildingId,
        @Param("groupsId") @RequestParam("groupsId") List<Long> groupsId,
        @Param("attKeyWanted") @RequestParam("attKeyWanted") String attKeyWanted
    );    
}
