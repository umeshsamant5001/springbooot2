package com.capgemini.cdm.batch.cucumber;

import com.capgemini.cdm.batch.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
