package com.capgemini.cdm.batch.cucumber.stepdefs;

import org.springframework.test.web.servlet.ResultActions;

public abstract class StepDefs {

    protected ResultActions actions;
}
