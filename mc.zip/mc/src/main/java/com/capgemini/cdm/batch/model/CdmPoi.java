package com.capgemini.cdm.batch.model;

import java.util.Objects;

import lombok.Data;

@Data
public class CdmPoi {
	private Long keyId;
	private Long floorKeyId;
	private String spaceCode;
	private Long poiSpaceTypeKeyId;
	private String poiSpaceTypeName;
	private Long poiSpaceCategoryKeyId;
	private String poiSpaceCategoryName;
	private String specialSecuredNonSecured;
	private String hotelingSpace;
	private String areaName;
	private String operation;
	private String remarks;
	private Double xCoordinate;
	private Double yCoordinate;
	private String modifiedDate;
	private String spaceName;

	public String getLabel() {

		if (Objects.nonNull(this.getSpaceName())) {

			return this.getSpaceName();

		} else {

			return this.getSpaceCode();

		}

	}

}
