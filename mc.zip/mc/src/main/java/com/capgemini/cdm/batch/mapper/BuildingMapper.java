package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.BuildingDTO;

@Mapper
public interface BuildingMapper {

	BuildingMapper INSTANCE = Mappers.getMapper(BuildingMapper.class);

	BuildingDTO buildingToBuildingDTO(Building in);
	
	Building buildingDTOToBuilding(BuildingDTO in);
}
