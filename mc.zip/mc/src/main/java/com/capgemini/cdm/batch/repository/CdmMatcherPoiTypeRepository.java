package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.cdm.batch.model.CdmMatcherPoiType;

@Repository
public interface CdmMatcherPoiTypeRepository extends JpaRepository<CdmMatcherPoiType, Long> {

	CdmMatcherPoiType findByCdmLabel(String cdmLabel);

	List<CdmMatcherPoiType> findByPoiTypeId(Long poiTypeId);

	List<CdmMatcherPoiType> findAll();
}