package com.capgemini.cdm.batch.model;

import lombok.Data;

@Data
public class CdmCity {
	private Long keyId;
	private Long stateKeyId;
	private Long countryKeyID;
	private String name;
	private String active;
	private String unLocode;
	private String capgeminiCity;
	private String countryIsoAlpha2;
}
