package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.CdmAsset;
import com.capgemini.cdm.batch.service.BuildingService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchBuildingsDelete extends CdmBatchBuildingsAction {
    @Autowired
    private BuildingService buildingService;

    @Override
    public boolean shouldProcess(Building buildingCSO, CdmAsset asssetCDM) {
        return Objects.isNull(asssetCDM) && Objects.nonNull(buildingCSO);
    }

    @Override
    public void process(Building buildingCSO, CdmAsset asssetCDM) {
        buildingService.deleteBuilding(buildingCSO);
    }
}