package com.capgemini.cdm.batch.client.common;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.capgemini.cdm.batch.client.Session;
import com.capgemini.cdm.batch.exception.ExternalConnectorException;
import com.google.gson.JsonElement;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RequestFactory {

    private static final int DEFAULT_CONNECT_TIMEOUT = 180;// seconds
    private static final int DEFAULT_TIMEOUT = 180;// seconds
    private static final int MAX_RETRY_ONTIMEOUT = 5;

    private RequestConfig config;
    private CloseableHttpClient httpClient;

    @PostConstruct
    public void init() {
        config = RequestConfig.custom().setConnectTimeout(DEFAULT_CONNECT_TIMEOUT * 1000)
                .setSocketTimeout(DEFAULT_TIMEOUT * 1000).build();
        httpClient = HttpClientBuilder.create()
                .setDefaultRequestConfig(config).build();
    }

    /**
     * GET api call
     *
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param responseParser the function to apply to read response
     * @return T a custom object defined by function
     */
    public <T> T get(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            Function<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }

            HttpGet req = new HttpGet(builder.build());

            if (!headers.isEmpty()) {
                req.setHeaders(convertHeaders(headers));
            }
            log.info("request %s", req.toString());
            return execute(req, responseParser);
        } catch (URISyntaxException e) {
            log.error(e.getMessage());
            throw new ExternalConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * POST api call
     *
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param jsonBody       or null
     * @param responseParser the function to apply to read response
     * @return T a custom object defined by responseParser function
     */
    public <T> T post(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            JsonElement jsonBody, Function<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }
            HttpPost req = new HttpPost(builder.build());
            if (Objects.nonNull(jsonBody)) {
                HttpEntity stringEntity = new StringEntity(jsonBody.toString(), ContentType.APPLICATION_JSON);
                req.setEntity(stringEntity);
            }

            if (!headers.isEmpty()) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException e) {
            throw new ExternalConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * POST api call with x-www-form-urlencoded query
     *
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param urlEncodedParams
     * @param responseParser
     * @return
     */
    public <T> T postFormUrlEncoded(String endpoint, Map<String, String> headers, List<NameValuePair> urlEncodedParams,
            Function<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);

            HttpPost req = new HttpPost(builder.build());
            UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
            req.setEntity(urlEncoded);

            if (!headers.isEmpty()) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException | UnsupportedEncodingException e) {
            throw new ExternalConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * PUT api call with x-www-form-urlencoded query
     *
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param urlEncodedParams
     * @param responseParser
     * @return
     */
    public <T> T putFormUrlEncoded(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            List<NameValuePair> urlEncodedParams, Function<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }

            HttpPut req = new HttpPut(builder.build());
            UrlEncodedFormEntity urlEncoded = new UrlEncodedFormEntity(urlEncodedParams, "UTF-8");
            req.setEntity(urlEncoded);

            if (!headers.isEmpty()) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException | UnsupportedEncodingException e) {
            throw new ExternalConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * DELETE api call
     *
     * @param <T>
     * @param endpoint
     * @param headers
     * @param queryParams
     * @param responseParser the function to apply to read response
     * @return T a custom object defined by function
     */
    public <T> T delete(String endpoint, Map<String, String> headers, Map<String, String> queryParams,
            Function<CloseableHttpResponse, T> responseParser) {
        try {
            URIBuilder builder = new URIBuilder(endpoint);
            if (!CollectionUtils.isEmpty(queryParams)) {
                builder.setParameters(convertQueryParams(queryParams));
            }

            HttpDelete req = new HttpDelete(builder.build());

            if (!headers.isEmpty()) {
                req.setHeaders(convertHeaders(headers));
            }
            return execute(req, responseParser);
        } catch (URISyntaxException e) {
            throw new ExternalConnectorException(getUriBuilderErrorMessage(endpoint, e.getMessage()));
        }
    }

    /**
     * Execute an http call and before closures, apply a function to manage response
     *
     * @param <T>
     * @param req
     * @param responseParserFunc the function to parse the HttpResponse
     * @return an object defined by responseParserFunc
     */
    private <T> T execute(HttpUriRequest req, Function<CloseableHttpResponse, T> responseParserFunc) {
        log.info("executing req " + req.getURI().toString());
        try (CloseableHttpResponse res = httpClient.execute(req)) {
            return responseParserFunc.apply(res);
        } catch (IOException e) {
            String message = String.format("Impossible to access API on endpoint:[%s], error:[%s]", req.getURI(),
                    e.getMessage());
            log.error(message);
            throw new ExternalConnectorException(message);
        }
    }

    /**
     * Execute an http call and before closures, apply a function to manage response
     *
     * @param <T>
     * @param req
     * @param responseParserFunc the function to parse the HttpResponse
     * @return an object defined by responseParserFunc
     */
    private <T> T execute2args(HttpUriRequest req, BiFunction<CloseableHttpResponse, Session, T> responseParserFunc,
            Session session) {
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
                CloseableHttpResponse res = httpClient.execute(req)) {
            return responseParserFunc.apply(res, session);
        } catch (IOException e) {
            String message = String.format("Impossible to access API on endpoint:[%s], error:[%s]", req.getURI(),
                    e.getMessage());
            log.info(message);
            throw new ExternalConnectorException(message);
        }
    }

    private Header[] convertHeaders(final Map<String, String> mapHeaders) {
        return mapHeaders.entrySet().stream().map(e -> new BasicHeader(e.getKey(), e.getValue()))
                .toArray(Header[]::new);
    }

    private List<NameValuePair> convertQueryParams(final Map<String, String> mapParams) {
        return mapParams.entrySet().stream().map(e -> new BasicNameValuePair(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    private String getUriBuilderErrorMessage(String endpoint, String message) {
        return String.format("Unable to build URI - endpoint:[%s] - error:[%s]", endpoint, message);
    }

    private static HttpRequestRetryHandler retryHandler() {
        return (exception, executionCount, context) -> {

            log.info("try request: " + executionCount);
            if (exception instanceof InterruptedIOException && executionCount <= MAX_RETRY_ONTIMEOUT) {
                // Timeout
                return true;
            }
            return false;
        };
    }

}
