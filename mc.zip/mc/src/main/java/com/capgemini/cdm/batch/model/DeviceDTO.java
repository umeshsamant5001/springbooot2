package com.capgemini.cdm.batch.model;

import java.util.Map;
import lombok.Data;

@Data
public class DeviceDTO {

	private String uuid;
	private String poiName;
	private Map<String, String> attributes;
	private Long lastChange;
	private EnumDeviceStatus status;
	private EnumDeviceType deviceType;
    private FloorDTO floor;
}
