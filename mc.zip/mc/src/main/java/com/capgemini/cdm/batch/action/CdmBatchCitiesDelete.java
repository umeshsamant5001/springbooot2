package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmCity;
import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.service.CityService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchCitiesDelete extends CdmBatchCitiesAction {
    @Autowired
    private CityService cityService;

    @Override
    public boolean shouldProcess(City cityCSO, CdmCity cityCDM) {
        return Objects.isNull(cityCDM) && Objects.nonNull(cityCSO);
    }

    @Override
    public void process(City cityCSO, CdmCity cityCDM) {

        cityService.deleteCity(cityCSO);
    }
}