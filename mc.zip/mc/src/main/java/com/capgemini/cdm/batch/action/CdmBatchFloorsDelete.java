package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.service.FloorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchFloorsDelete extends CdmBatchFloorsAction {
    @Autowired
    private FloorService floorService;

    @Override
    public boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM) {
        return Objects.isNull(floorCDM) && Objects.nonNull(floorCSO);
    }

    @Override
    public void process(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM) {
        floorService.deleteFloor(floorCSO);
    }
}