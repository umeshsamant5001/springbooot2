package com.capgemini.cdm.batch.exception;

public class ExternalConnectorException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 7748650921857496286L;

	public ExternalConnectorException(String message) {
		super(500, ErrorCodes.EXTERNAL_CONNECTOR_UNEXPECTED_ERROR, message);
	}

}
