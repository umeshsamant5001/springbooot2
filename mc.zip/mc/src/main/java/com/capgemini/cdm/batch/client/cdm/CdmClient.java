package com.capgemini.cdm.batch.client.cdm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.capgemini.cdm.batch.client.common.RequestFactory;
import com.capgemini.cdm.batch.model.CdmAsset;
import com.capgemini.cdm.batch.model.CdmCity;
import com.capgemini.cdm.batch.model.CdmCountry;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmSite;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.service.CdmAuthenticationService;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CdmClient {

	@Value("${application.cdm.url}")
	private String cdmURL;

	private static final String COUNTRIES_ENDPOINT = "/cdm/tree?externalCall=Y";
	private static final String POIS_ENDPOINT = "/cdm/floorpois?";
	private static final String COUNTRY_BY_CDM_KEY_ID_ENDPOINT = "/cdm/country/";
	private static final String CITY_BY_CDM_KEY_ID_ENDPOINT = "/cdm/city/";
	private static final String SITE_BY_CDM_KEY_ID_ENDPOINT = "/cdm/site/";
	private static final String ASSET_BY_CDM_KEY_ID_ENDPOINT = "/cdm/asset/";

	@Autowired
	private RequestFactory factory;

	@Autowired
	private CdmResponseParser resParser;

	@Autowired
	private CdmAuthenticationService cdmAuthenticateService;

	/**
	 * Get a Pois details from assetId and FloorCdmKey
	 * 
	 * @param session
	 * @param assetId
	 * @param keyId
	 * @return List of Pois for corresponding Floor
	 */
	public String getPoiByAssetIdAndFloorCdmKey(String assetId, Long keyId) {
		Map<String, String> params = new HashMap<>();
		params.put("assetId", assetId.toString());
		params.put("floorID", keyId.toString());
		log.debug("Log_custom_1-Before request %s", POIS_ENDPOINT);
		String result = "";
		try {
			result = factory.get(getUri(POIS_ENDPOINT), cdmAuthenticateService.getDefaultHeaders(), params,
					resParser::readGetListPoiByAssetIdAndFloorKeyId);
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return result;
	}

	/**
	 * Get Country CDM by cdmKeyId
	 * 
	 * @param keyId
	 * @return Country CDM
	 */
	public CdmCountry getCountryByCdmKey(Long keyId) {
		CdmCountry result = null;

		try {
			result = new Gson()
					.fromJson(factory.get(getUri(String.format("%s%s", COUNTRY_BY_CDM_KEY_ID_ENDPOINT, keyId)),
							cdmAuthenticateService.getDefaultHeaders(), Collections.emptyMap(),
							resParser::readGetEntityByCDMKey), CdmCountry.class);
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	/**
	 * Get City CDM by cdmKeyId
	 * 
	 * @param keyId
	 * @return City CDM
	 */
	public CdmCity getCityByCdmKey(Long keyId) {
		CdmCity result = null;
		try {
			result = new Gson().fromJson(factory.get(getUri(String.format("%s%s", CITY_BY_CDM_KEY_ID_ENDPOINT, keyId)),
					cdmAuthenticateService.getDefaultHeaders(), Collections.emptyMap(),
					resParser::readGetEntityByCDMKey), CdmCity.class);
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	/**
	 * Get Site CDM by cdmKeyId
	 * 
	 * @param keyId
	 * @return Site CDM
	 */
	public CdmSite getSiteByCdmKey(Long keyId) {
		CdmSite result = null;
		try {
			result = new Gson().fromJson(factory.get(getUri(String.format("%s%s", SITE_BY_CDM_KEY_ID_ENDPOINT, keyId)),
					cdmAuthenticateService.getDefaultHeaders(), Collections.emptyMap(),
					resParser::readGetEntityByCDMKey), CdmSite.class);
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	/**
	 * Get Asset CDM by cdmKeyId
	 * 
	 * @param keyId
	 * @return Asset CDM
	 */
	public CdmAsset getAssetByCdmKey(Long keyId) {
		CdmAsset result = null;
		try {
			result = new Gson().fromJson(factory.get(getUri(String.format("%s%s", ASSET_BY_CDM_KEY_ID_ENDPOINT, keyId)),
					cdmAuthenticateService.getDefaultHeaders(), Collections.emptyMap(),
					resParser::readGetEntityByCDMKey), CdmAsset.class);
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	/**
	 * Get all Countries from CDM endpoint
	 *
	 * @param session
	 * @param keyId
	 * @return List of Countries from CDM
	 */
	public String getCountries() {
		String result = "";
		try {
			result = factory.get(getUri(COUNTRIES_ENDPOINT), cdmAuthenticateService.getDefaultHeaders(),
					Collections.emptyMap(), resParser::readGetListCountriesRes);
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	public List<CdmTreeElement> getTreeCDM() {

		List<CdmTreeElement> result = new ArrayList<>();
		try {
			result = Arrays
					.asList((new Gson()).fromJson(getCountries(), CdmTreeElement[].class));
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		return result;
	}

	public List<CdmFloor> getPoiFloorCDM(String assetId, Long keyId) {
		List<CdmFloor> result = null;

		try {
			log.info(String.format("calling CDM with assetId %s and floorId %s", assetId, String.valueOf(keyId)));
			result = Arrays
					.asList((new Gson()).fromJson(
							getPoiByAssetIdAndFloorCdmKey(assetId, keyId), CdmFloor[].class));
		} catch (Exception e) {
			log.error(e.getMessage());

		}

		if (Objects.isNull(result)) {
			// TO be sure to always return a List
			return new ArrayList<>();
		}

		return result;
	}

	private String getUri(String endpoint) {
		return cdmURL + endpoint;
	}

}
