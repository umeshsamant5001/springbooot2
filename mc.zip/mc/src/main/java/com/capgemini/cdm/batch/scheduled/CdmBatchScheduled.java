package com.capgemini.cdm.batch.scheduled;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.scheduling.annotation.Scheduled;

import com.capgemini.cdm.batch.service.CdmBatchService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CdmBatchScheduled {
    @Autowired
    CdmBatchService batchService;

    private static final String CONFIG_PATH = "application.cdm.tasks";

    @Scheduled(cron = "${" + CONFIG_PATH + ".cron}", zone = "${" + CONFIG_PATH + ".tz}")
    private void execCDMBatch() {
        log.info("Scheduled Task : CDM Batch");
        this.batchService.execBatch();
        log.info("Scheduled Task : CDM Batch end");
    }

}