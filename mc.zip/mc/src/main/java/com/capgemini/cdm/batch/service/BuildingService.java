package com.capgemini.cdm.batch.service;

import java.time.ZoneId;
import java.util.Date;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cdm.batch.helper.DateTimeUtils;
import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.repository.BuildingRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BuildingService {
	static final String API_TAG = "Building";

	@Autowired
	private BuildingRepository buildingRepository;

	public Building createBuilding(Building building) {

		ZoneId zone = Objects.isNull(building.getAttributes()) ? DateTimeUtils.UTC_ZONE_ID
				: DateTimeUtils.getZone(Double.parseDouble(building.getAttributes().get("lat")),
						Double.parseDouble(building.getAttributes().get("lon")));

		building.setTimezoneWindows(calculateTimezone(zone));
		building.setTimezoneJava(zone.getId());
		building.setModifiedAt(new Date().getTime() / 1000);

		Building postedBuilding = null;
		try {
			postedBuilding = this.buildingRepository.save(building);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return postedBuilding;

	}

	public Building updateBuilding(Building building) {

		ZoneId zone = Objects.isNull(building.getAttributes()) ? DateTimeUtils.UTC_ZONE_ID
				: DateTimeUtils.getZone(Double.parseDouble(building.getAttributes().get("lat")),
						Double.parseDouble(building.getAttributes().get("lon")));

		building.setTimezoneWindows(calculateTimezone(zone));
		building.setTimezoneJava(zone.getId());
		building.setModifiedAt(new Date().getTime() / 1000);
		Building newBuilding = null;
		try {
			newBuilding = buildingRepository.saveAndFlush(building);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newBuilding;

	}

	private String calculateTimezone(ZoneId zone) {
		return DateTimeUtils.getWindowsTimezoneFromZoneId(zone);
	}

    @Modifying
    @Transactional(noRollbackFor = Exception.class)
    public void deleteBuilding(Building building) {

        try {
            buildingRepository.deleteById(building.getId());
            buildingRepository.flush();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }
}
