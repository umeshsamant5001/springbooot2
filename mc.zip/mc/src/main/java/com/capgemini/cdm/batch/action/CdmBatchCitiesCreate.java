package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmCity;
import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.repository.CountryRepository;
import com.capgemini.cdm.batch.service.CityService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchCitiesCreate extends CdmBatchCitiesAction {
    @Autowired
    private CityService cityService;
    @Autowired
    private CountryRepository countryRepository;

    @Override
    public boolean shouldProcess(City cityCSO, CdmCity cityCDM) {
        return Objects.nonNull(cityCDM) && Objects.isNull(cityCSO);
    }

    @Override
    public void process(City cityCSO, CdmCity cityCDM) {
        cityCSO = new City();
        cityCSO.setTitleEn(cityCDM.getName());
        cityCSO.setTitleFr(cityCDM.getName());
        cityCSO.setCdmKeyId(cityCDM.getKeyId());
        cityCSO.setCdmStateId(cityCDM.getStateKeyId());
        Country country = countryRepository.findByCdmKeyId(cityCDM.getCountryKeyID());
        if (Objects.nonNull(country)) {
            cityCSO.setCountry(country);
            cityCSO.setCountryId(country.getId());

            cityService.createCity(cityCSO);
        }
    }

}
