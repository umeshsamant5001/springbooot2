/**
 * Spring Framework configuration files.
 */
package com.capgemini.cdm.batch.config;
