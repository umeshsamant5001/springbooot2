package com.capgemini.cdm.batch.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.capgemini.cdm.batch.config.DbConfig;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "city", indexes = { @Index(name = "IDX_MODIFIED_CITY", columnList = "modified_at") })
@EqualsAndHashCode
public class City {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "City_Generator")
    @SequenceGenerator(name="City_Generator", sequenceName = "City_Sequence")
    private Long id;

    @OneToMany(mappedBy = "city",
    		cascade=CascadeType.ALL,
			orphanRemoval=true,
			fetch = FetchType.EAGER)
    private List<Site> sites = new ArrayList<>();

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="country_id")
    @JsonIgnore
    private Country country;

    @Column(name="country_id", updatable=false,insertable=false)
    private Long countryId;

    @Column(name = "modified_at", nullable = false, columnDefinition = DbConfig.BIGINT_DEFAULT_DEFINITION)
	private Long modifiedAt = (new Date()).getTime()/1000;

	@Column(name = "cdm_key_id", unique = true)
	private Long cdmKeyId;


    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

	@Column(name = "cdm_state_id")
	private Long cdmStateId;

	@CollectionTable(name = "city_attribute", joinColumns = @JoinColumn(name = "city_id", referencedColumnName = "id"))
	@ElementCollection(fetch = FetchType.EAGER)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<String, String>();

}

