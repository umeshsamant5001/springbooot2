package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.model.SiteDTO;

@Mapper
public interface SiteMapper {

	SiteMapper INSTANCE = Mappers.getMapper(SiteMapper.class);

	SiteDTO siteToSiteDTO(Site in);
	
	Site siteDTOToSite(SiteDTO in);
}
