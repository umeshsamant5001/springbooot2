package com.capgemini.cdm.batch.model;

import lombok.Data;

@Data
public class CdmSite {

	private Long keyId;
	private Long cityKeyId;
	private Long siteTypeKeyId;
	private String sietTypeDescription;
	private String siteId;
	private String siteCommonName;
	private String active;
	private Long capacity;
	private Double latitude;
	private Double longitude;
	private String address;
	private Double sizeLocal;
	private Double sizeStandard;
	private String sizeLocalFormated;
	private String sizeStandardFormated;
	private String siteCode;
	private Long countryKeyID;
	private String countryName;
	private Long unitOfMeasurementKeyId;
	private String unitOfMeasurementValue;
	private String countryIsoAlpha2;
	private String mainAssetId;
	private String sizeSQFTFormated;
	private String cityName;
	private String state;
	private Long stateKeyID;
}
