package com.capgemini.cdm.batch.model.projection;

import java.util.Map;
import org.springframework.data.rest.core.config.Projection;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;

@Projection(name = "PoiListItem", types = {Poi.class})
public interface PoiListItem {
	String getId();
	String getName();
	int getFloorIndex();
	Floor getFloor();
	Long getFloorId();
	Long getTypeId();
	Map<String, String> getAttributes();
}
