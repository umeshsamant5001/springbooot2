package com.capgemini.cdm.batch.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.capgemini.cdm.utils.StringListConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "poi_type")
public class PoiType {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "POIType_Generator")
	@SequenceGenerator(name = "POIType_Generator", sequenceName = "POIType_Sequence")
	private Long id;

	@Column(name = "name", nullable = false, unique = true)
	private String name;

	@Column @Convert(converter = StringListConverter.class)
	private List<String> attributeKeys;

	@CollectionTable(name = "poi_type_attribute")
	@ElementCollection(fetch=FetchType.EAGER)
	@MapKeyColumn(name = "att_key")
	@Column(name = "att_value")
	private Map<String, String> attributes = new HashMap<>();

    @Column(name = "title_fr")
	private String titleFr;

    @Column(name = "title_en")
	private String titleEn;

}
