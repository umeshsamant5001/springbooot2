package com.capgemini.cdm.batch.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.cache.CacheManager;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.client.Session;
import com.capgemini.cdm.batch.client.cdm.CdmResponseParser;
import com.capgemini.cdm.batch.client.common.RequestFactory;
import com.capgemini.cdm.batch.exception.ExternalConnectorException;

import lombok.extern.slf4j.Slf4j;

/*
 * The service which manages the data obtained by authentication process
 *
 */
@Slf4j
@Service
public class CdmAuthenticationService {
	@Value("${application.cdm.ssoUrl}")
	private String cdmSsoURL;
	@Value("${application.cdm.clientId}")
	private String cdmClientId;
	@Value("${application.cdm.clientSecret}")
	private String cdmClientSecret;
	@Value("${application.cdm.cgAuth}")
	private String cdmCgAuth;
	@Value("${application.cdm.authorization}")
	private String cdmAuthorization;
	@Value("${application.cdm.cookie}")
	private String cdmCookie;

	static final String AUTHORIZATION_HEADER = "Authorization";
	static final String COOKIE = "Cookie";
	static final String TOKEN_PARAM = "token";

	private static final String CDM_GRANT_TYPE = "client_credentials";

	@Autowired
	private RequestFactory factory;

	@Autowired
	private CdmResponseParser resParser;

	/**
	 * Get a CDM session for further api calls
	 *
	 * @return a Session object containing a sessionId and a token
	 */
	private Session authenticate() {
		Session session = new Session();
		Map<String, String> headers = new HashMap<>();

		headers.put(AUTHORIZATION_HEADER, cdmAuthorization);
		headers.put(COOKIE, cdmCookie);

		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair(CDM_GRANT_TYPE, AUTHORIZATION_HEADER));
		params.add(new BasicNameValuePair("client_id", cdmClientId));
		params.add(new BasicNameValuePair("client_secret", cdmClientSecret));
		params.add(new BasicNameValuePair("grant_type", CDM_GRANT_TYPE));

		session = factory.postFormUrlEncoded(cdmSsoURL, headers, params, resParser::readTokenRes);

		if (Objects.isNull(session.getToken()) || session.getToken().isEmpty()) {
			throw new ExternalConnectorException("CDM authentication response - no token found");
		}
		return session;
	}

	@Cacheable(value = "accessTokenCDM", key = "#root.method.name")
	public Map<String, String> getDefaultHeaders() {
		Map<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION_HEADER, "Bearer " + this.authenticate().getToken());
		headers.put("cgAuth", cdmCgAuth);
		log.info("Cdm token cache");
		return headers;
	}

	@CacheEvict(allEntries = true, value = "accessTokenCDM")
	@Scheduled(fixedDelay = 3400*1000)
	public void cdmTokenCacheEvict() {
		log.info("Cdm token evicted");

	}

	private String getSSOUri(String endpoint) {
		return cdmSsoURL + endpoint;
	}
}
