package com.capgemini.cdm.batch.action;

import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.model.Floor;

public abstract class CdmBatchFloorsAction {

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM);

    /**
     * Launch the process
     * 
     * @param floorCSO
     * @param floorCDM
     * @param officeCDM
     * @return
     */
    public abstract void process(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM);

}
