package com.capgemini.cdm.batch.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * Properties specific to CDM Batch.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 * See {@link tech.jhipster.config.JHipsterProperties} for a good example.
 */
@Configuration
@EnableConfigurationProperties
@Data
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
    // jhipster-needle-application-properties-property
    // jhipster-needle-application-properties-property-getter
    // jhipster-needle-application-properties-property-class

    private final Cdm cdm = new Cdm();

    @Data
    public static class Cdm {

        private String url;
        private String clientId;
        private String clientSecret;
        private String ssoUrl;
        private String cgAuth;
        private String authorization;
        private String cookie;

        private final Tasks tasks = new Tasks();

        @Data
        public static class Tasks {
            private String cron;
            private String tz;
        }

    }
}
