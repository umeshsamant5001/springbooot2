package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import com.capgemini.cdm.batch.model.Device;
import com.capgemini.cdm.batch.model.DeviceDTO;
import com.capgemini.cdm.batch.model.Floor;

@Mapper
public interface DeviceMapper {
	
	DeviceMapper INSTANCE = Mappers.getMapper(DeviceMapper.class);

	//@Mapping(target = "floor", ignore = true)
	Device deviceDTOToDevice(DeviceDTO in);

	DeviceDTO deviceToDeviceDTO(Device in);

}