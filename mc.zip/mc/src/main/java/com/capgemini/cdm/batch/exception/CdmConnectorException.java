package com.capgemini.cdm.batch.exception;

public class CdmConnectorException extends SmartWorkPlaceException {

	private static final long serialVersionUID = 7748650921857496286L;

	public CdmConnectorException(String message) {
		super(500, ErrorCodes.EXTERNAL_CONNECTOR_UNEXPECTED_ERROR, message);
	}

}
