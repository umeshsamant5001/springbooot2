package com.capgemini.cdm.batch.model;

import lombok.Data;

@Data
public class CdmAsset {
	private Long keyId;
	private Long siteKeyId;
	private String active;
	private Long assetTypeKeyId;
	private String assetTypeDescription;
	private String mainAsset;
	private String assetId;
	private String assetCommonName;
	private String address;
	private String city;
	private String postalCode;
	private Double latitude;
	private Double longitude;
	private Double sizeLocal;
	private Double sizeStandard;
	private String sizeLocalFormated;
	private String sizeStandardFormated;
	private Long unitOfMeasurementKeyId;
	private String unitOfMeasurementValue;
	private String countryIsoAlpha2;
	private String mainAssetId;
	private String sizeSQFTFormated;
	private String assetCode;
	private String comment;
	private Long countryKeyId;
	private Long stateKeyId;
	private Long cityKeyId;
	private String canReadBusinessStrategy;
	private Long assetCapacity;
	private Long seatCapacity;
}
