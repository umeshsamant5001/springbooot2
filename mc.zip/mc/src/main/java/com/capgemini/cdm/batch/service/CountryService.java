package com.capgemini.cdm.batch.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.repository.CountryRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CountryService {
	static final String API_TAG = "Country";

    @Autowired
    private EntityManager entityManager;

	@Autowired
	private CountryRepository countryRepository;

	public Country createCountry(Country countryRequest) {
		countryRequest.setModifiedAt((new Date()).getTime() / 1000);
		Country country = null;
		try {
			country = countryRepository.save(countryRequest);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return country;
    }

    public Country findByEntityGraph(Long id) {
        EntityGraph entityGraph = entityManager.getEntityGraph("country-entity-graph");
        Map<String, Object> properties = new HashMap<>();
        properties.put("javax.persistence.fetchgraph", entityGraph);
        return entityManager.find(Country.class, id, properties);
    }

	public Country updateCountry(Country updatedCountry) {
		updatedCountry.setModifiedAt((new Date()).getTime() / 1000);
		Country newCountry = null;
		try {
			newCountry = countryRepository.saveAndFlush(updatedCountry);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newCountry;

	}

    @Modifying
    @Transactional(noRollbackFor = Exception.class)
    public void deleteCountry(Country country) {

        try {
            countryRepository.deleteById(country.getId());
            countryRepository.flush();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }
}
