package com.capgemini.cdm.batch.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.cdm.batch.model.Building;

@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

    long countBySiteId(@Param("siteId") Long siteId);

	List<Building> findAllBySiteId(@Param("siteId") Long siteId);

    Building findByFloorsId(@Param("floorId") Long floorId);

	Building findByCdmKeyId(@Param("cdmKeyId")  Long cdmKeyId);

	@Query(value = "select building.* from building building where id in"
			+ "(select building_id from building_attribute where att_value = :asset_id) limit 1", nativeQuery = true)
	Building findByAssetId(@Param("asset_id") String asset_id);

    List<Building> findAllBySecuredTrue();

}
