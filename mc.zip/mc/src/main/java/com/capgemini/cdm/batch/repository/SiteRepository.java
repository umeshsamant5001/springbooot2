package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.cdm.batch.model.Site;

@Repository()
public interface SiteRepository extends JpaRepository<Site, Long> {

    long countByCityId(@Param("cityId") Long cityId);

    List<Site> findAllByCityId(@Param("cityId") Long cityId);

	Site findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

	/*// Controller only
	@RestResource(exported = false)
	@Transactional
	@Modifying
	@Query(value = "delete from site_attributes ssa  where ssa.site_id=:siteId", nativeQuery = true)
	void deleteAttributeById(@Param("siteId") @RequestParam("siteId") Long siteId);

	// Controller only
	@RestResource(exported = false)
	@Transactional
	@Modifying
	@Query(value = "delete from site ss where ss.id=:siteId", nativeQuery = true)
	void deleteById(@Param("siteId") @RequestParam("siteId") Long siteId);*/
}
