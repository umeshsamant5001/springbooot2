package com.capgemini.cdm.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Component;
import com.capgemini.cdm.batch.model.Device;
import org.springframework.data.rest.core.annotation.RestResource;

@Component
@RepositoryRestResource(path = "devices", collectionResourceRel = "devices")
public interface DeviceRepository extends JpaRepository<Device, Long>, JpaSpecificationExecutor<Device> {

    @RestResource(exported = false)
	public Device findByUuid(@Param("uuid") String uuid);

}
