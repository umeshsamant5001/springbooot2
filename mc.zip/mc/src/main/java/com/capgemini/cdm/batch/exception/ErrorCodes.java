package com.capgemini.cdm.batch.exception;

public final class ErrorCodes {

	public static final Integer POI_NOT_FOUND = 11;

	public static final Integer POI_CONFLICT = 12;

	public static final Integer EXTERNAL_CONNECTOR_UNEXPECTED_ERROR = 500;

	public static final Integer AUTHENTICATION_FAILED = 1000;

	// Prevent instantiation
	private ErrorCodes() {
		throw new IllegalAccessError();
	}
}
