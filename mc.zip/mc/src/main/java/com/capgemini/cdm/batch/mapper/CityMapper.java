package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.model.CityDTO;

@Mapper
public interface CityMapper {

	CityMapper INSTANCE = Mappers.getMapper(CityMapper.class);

	CityDTO cityToCityDTO(City in);
	
	City cityDTOToCity(CityDTO in);
}
