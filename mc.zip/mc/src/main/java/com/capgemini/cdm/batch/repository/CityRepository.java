package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.cdm.batch.model.City;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

	long countByCountryId(@Param("countryId") Long countryId);

	List<City> findAllByCountryId(@Param("countryId") Long countryId);
	
	City findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);
}
