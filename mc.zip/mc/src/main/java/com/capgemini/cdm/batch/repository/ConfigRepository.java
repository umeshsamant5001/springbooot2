package com.capgemini.cdm.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.cdm.batch.model.ConfigValue;

@Repository
public interface ConfigRepository extends JpaRepository<ConfigValue, Long> {

    public ConfigValue findByKeyName(@Param("keyName") String keyName);
}
