package com.capgemini.cdm.batch.model;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class CdmTreeElement {

	private static final String ASSET_OFFICE = "office";
	private static final String ASSET_FLOOR = "";
	private static final String STATUS_ACTIVE = "active";
	private static final String NODE_TYPE_COUNTRY = "country";
	private static final String NODE_TYPE_STATE = "state";
	private static final String NODE_TYPE_CITY = "city";
	private static final String NODE_TYPE_SITE = "site";
	private static final String NODE_TYPE_ASSET = "asset";
	private static final String ASSET_CODE_SEPARATOR = ".";

	protected Long id;
	protected String name;
	protected String code;
	protected String status;
	protected String asset;
	protected String nodeType;
	protected String siteID;
	protected String countryIsoAlpha2;
	protected String searchFieldSite;
	protected String searchFieldAsset;
	protected String assetID;
	protected String floorAssetId;
	protected String cityKeyId;
	protected String unLocode;

	private List<CdmTreeElement> childs = new ArrayList<>();

	public Boolean isCountry() {
		return NODE_TYPE_COUNTRY.equals(nodeType);
	}

	public Boolean isState() {
		return NODE_TYPE_STATE.equals(nodeType);
	}

	public Boolean isCity() {
		return NODE_TYPE_CITY.equals(nodeType);
	}

	public Boolean isSite() {
		return NODE_TYPE_SITE.equals(nodeType);
	}

	public Boolean isAsset() {
		return NODE_TYPE_ASSET.equals(nodeType);
	}

	public Boolean isOffice() {
		return isAsset() && asset.toLowerCase().contains(ASSET_OFFICE);
	}

	public Boolean isFloor() {
		return isAsset() && asset.equalsIgnoreCase(ASSET_FLOOR);
	}

	public Boolean isActive() {
		return STATUS_ACTIVE.equalsIgnoreCase(status);
	}

	public void addChildElement(CdmTreeElement el) {
		childs.add(el);
	}

	public List<CdmTreeElement> getChilds() {
		return childs;
	}

	@Transient
	public String getParentCode() {
		return Objects.isNull(code) ? null : code.substring(0, code.lastIndexOf(ASSET_CODE_SEPARATOR));
	}

}
