package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.cdm.batch.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

	@Query(value = "SELECT distinct c.* FROM country c JOIN city ci ON ci.country_id=c.id JOIN site s ON s.city_id=ci.id JOIN building b ON b.site_id = s.id WHERE b.deployed=true", nativeQuery = true)
	List<Country> findAllDeployed();

	@Query(value = "SELECT distinct c.* FROM country c JOIN city ci ON ci.country_id=c.id JOIN site s ON s.city_id=ci.id JOIN building b ON b.site_id = s.id WHERE b.deployed=true AND b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUnsecured();

	@Query(value = "SELECT distinct c.* FROM country c LEFT JOIN city ci ON ci.country_id=c.id LEFT JOIN site s ON s.city_id=ci.id LEFT JOIN building b ON b.site_id = s.id", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployed();

	@Query(value = "SELECT distinct c.* FROM country c LEFT JOIN city ci ON ci.country_id=c.id LEFT JOIN site s ON s.city_id=ci.id LEFT JOIN building b ON b.site_id = s.id WHERE b.secured=false", nativeQuery = true)
	List<Country> findAllDeployedAndUndeployedAndUnsecured();

	Country findByCdmKeyId(@Param("cdmKeyId") Long cdmKeyId);

}
