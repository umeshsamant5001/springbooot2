package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmSite;
import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.service.SiteService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchSitesDelete extends CdmBatchSitesAction {
    @Autowired
    private SiteService siteService;

    @Override
    public boolean shouldProcess(Site siteCSO, CdmSite siteCDM) {
        return Objects.isNull(siteCDM) && Objects.nonNull(siteCSO);
    }

    @Override
    public void process(Site siteCSO, CdmSite siteCDM) {
        siteService.deleteSite(siteCSO);
    }
}