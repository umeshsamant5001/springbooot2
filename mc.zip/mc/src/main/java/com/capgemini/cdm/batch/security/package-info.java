/**
 * Spring Security configuration.
 */
package com.capgemini.cdm.batch.security;
