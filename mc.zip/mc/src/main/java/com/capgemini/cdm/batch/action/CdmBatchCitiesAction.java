package com.capgemini.cdm.batch.action;

import com.capgemini.cdm.batch.model.CdmCity;
import com.capgemini.cdm.batch.model.City;

public abstract class CdmBatchCitiesAction {

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(City cityCSO, CdmCity cityCDM);

    /**
     * Launch the process
     * 
     * @param cityCSO
     * @param cityCDM
     * @return
     */
    public abstract void process(City cityCSO, CdmCity cityCDM);

}
