package com.capgemini.cdm.batch.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class PoiDTO {

	private Long id;
	private String name;
	private Floor floor;
	private Long floorId;
    private String titleFr;
    private String titleEn;
	private PoiType type;
	private Long typeId;
	private Long modifiedAt = (new Date()).getTime() / 1000;
    private Long cdmKeyId;
	private Map<String, String> attributes = new HashMap<String, String>();
	private List<Equipment> equipments = new ArrayList<>();
	private String description;
	private Integer floorIndex;
}
