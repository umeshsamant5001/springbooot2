package com.capgemini.cdm.batch.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CdmFloor {
	private String name;
	private Long keyId;
	private String assetId;
	private Integer totalSpaceArea;
	private String unitOfMeasurementCode;
	private String productionUnit;
	private String type;
	private Boolean securedFloor;
	private String mapId;
	private String base64Map;
	private List<CdmPoi> poiInterfaceDTOs = new ArrayList<>();
	private Long floorIndex;
}
