package com.capgemini.cdm.batch.model;

import lombok.Data;

@Data
public class CdmBatchResp implements CdmResp {

	private Integer nbCountryDelete;
	private Integer nbCountryUpdate;
	private Integer nbCountryCreate;
	private Integer nbCityDelete;
	private Integer nbCityUpdate;
	private Integer nbCityCreate;
	private Integer nbSiteDelete;
	private Integer nbSiteUpdate;
	private Integer nbSiteCreate;
	private Integer nbBuildingDelete;
	private Integer nbBuildingUpdate;
	private Integer nbBuildingCreate;
	private Integer nbFloorDelete;
	private Integer nbFloorUpdate;
	private Integer nbFloorCreate;
	private Integer nbPoiDelete;
	private Integer nbPoiUpdate;
	private Integer nbPoiCreate;

	@Override
	public String formatBody() {

		StringBuilder sb = new StringBuilder();
		sb.append("<p>").append(String.format("Nb Country Delete %d", getNbCountryDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb Country Update %d", getNbCountryUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb Country Create %d", getNbCountryCreate())).append("</p>");

		sb.append("<p>").append(String.format("Nb City Delete %d", getNbCityDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb City Update %d", getNbCityUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb City Create %d", getNbCityCreate())).append("</p>");

		sb.append("<p>").append(String.format("Nb Site Delete %d", getNbSiteDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb Site Update %d", getNbSiteUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb Site Create %d", getNbSiteCreate())).append("</p>");

		sb.append("<p>").append(String.format("Nb Building Delete %d", getNbBuildingDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb Building Update %d", getNbBuildingUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb Building Create %d", getNbBuildingCreate())).append("</p>");

		sb.append("<p>").append(String.format("Nb Floor Delete %d", getNbFloorDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb Floor Update %d", getNbFloorUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb Floor Create %d", getNbFloorCreate())).append("</p>");

		sb.append("<p>").append(String.format("Nb Poi Delete %d", getNbPoiDelete())).append("</p>");
		sb.append("<p>").append(String.format("Nb Poi Update %d", getNbPoiUpdate())).append("</p>");
		sb.append("<p>").append(String.format("Nb Poi Create %d", getNbPoiCreate())).append("</p>");

		return sb.toString();
	}

}
