package com.capgemini.cdm.batch.action;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.enumeration.EnumCdmAttributes;
import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.model.BuildingInformation;
import com.capgemini.cdm.batch.model.CdmAsset;
import com.capgemini.cdm.batch.repository.SiteRepository;
import com.capgemini.cdm.batch.service.BuildingService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchBuildingsCreate extends CdmBatchBuildingsAction {
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private SiteRepository siteRepository;

    @Override
    public boolean shouldProcess(Building buildingCSO, CdmAsset asssetCDM) {
        return Objects.isNull(buildingCSO) && Objects.nonNull(asssetCDM) && Objects.nonNull(asssetCDM.getActive())
                && "Y".equalsIgnoreCase(asssetCDM.getActive());
    }

    @Override
    public void process(Building buildingCSO, CdmAsset asssetCDM) {
        buildingCSO = new Building();
        buildingCSO.setCdmKeyId(asssetCDM.getKeyId());
        buildingCSO.setTitleFr(asssetCDM.getAssetCommonName());
        buildingCSO.setTitleEn(asssetCDM.getAssetCommonName());
        Map<String, String> attributes = new HashMap<>();
        attributes.put(EnumCdmAttributes.ACTIVE.toString(), asssetCDM.getActive());
        attributes.put(EnumCdmAttributes.ASSET_ID.toString(), asssetCDM.getAssetId());

        attributes.put("lat", asssetCDM.getLatitude().toString());
        attributes.put("lon", asssetCDM.getLongitude().toString());

        buildingCSO.setAttributes(attributes);
        BuildingInformation buildingInfo = new BuildingInformation();
        buildingInfo.setAddress(asssetCDM.getAddress());
        buildingInfo.setCapacity(String.format("%s", asssetCDM.getAssetCapacity()));
        buildingInfo.setCity(asssetCDM.getCity());
        buildingCSO.setInformation(buildingInfo);

        Site site = siteRepository.findByCdmKeyId(Long.valueOf(asssetCDM.getSiteKeyId()));
        if (Objects.nonNull(site)) {
            buildingCSO.setSite(site);
            buildingCSO.setSiteId(site.getId());

            buildingService.createBuilding(buildingCSO);
        }
    }

}
