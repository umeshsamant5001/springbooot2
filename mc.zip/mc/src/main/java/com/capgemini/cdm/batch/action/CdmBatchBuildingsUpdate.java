package com.capgemini.cdm.batch.action;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.enumeration.EnumCdmAttributes;
import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.CdmAsset;
import com.capgemini.cdm.batch.repository.SiteRepository;
import com.capgemini.cdm.batch.service.BuildingService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchBuildingsUpdate extends CdmBatchBuildingsAction {
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private SiteRepository siteRepository;

    @Override
    public boolean shouldProcess(Building buildingCSO, CdmAsset asssetCDM) {
        return Objects.nonNull(buildingCSO) && Objects.nonNull(asssetCDM) && Objects.nonNull(asssetCDM.getActive())
                && "Y".equalsIgnoreCase(asssetCDM.getActive());
    }

    @Override
    public void process(Building buildingCSO, CdmAsset asssetCDM) {
        buildingCSO.setTitleFr(asssetCDM.getAssetCommonName());
        buildingCSO.setTitleEn(asssetCDM.getAssetCommonName());
        buildingCSO.getInformation().setAddress(asssetCDM.getAddress());
        buildingCSO.getInformation().setCapacity(String.format("%s", asssetCDM.getAssetCapacity()));
        buildingCSO.getInformation().setCity(asssetCDM.getCity());
        buildingCSO.getAttributes().put(EnumCdmAttributes.ACTIVE.toString(), asssetCDM.getActive());
        buildingCSO.getAttributes().put(EnumCdmAttributes.ASSET_ID.toString(), asssetCDM.getAssetId());

        buildingCSO.getAttributes().put("lon", asssetCDM.getLongitude().toString());
        buildingCSO.getAttributes().put("lat", asssetCDM.getLatitude().toString());
        Site site = siteRepository.findByCdmKeyId(Long.valueOf(asssetCDM.getSiteKeyId()));
        if (Objects.nonNull(site)) {
            buildingCSO.setSite(site);
            buildingCSO.setSiteId(site.getId());
            buildingService.updateBuilding(buildingCSO);
        }
    }

}