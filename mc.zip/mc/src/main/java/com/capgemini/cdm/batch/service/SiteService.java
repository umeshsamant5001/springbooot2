package com.capgemini.cdm.batch.service;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.repository.SiteRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SiteService {
	static final String API_TAG = "Site";

	@Autowired
	private SiteRepository siteRepository;

	public Site createSite(Site site) {
		site.setModifiedAt((new Date()).getTime() / 1000);
		Site postedSite = null;
		try {
			postedSite = this.siteRepository.save(site);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return postedSite;

	}

	public Site updateSite(Site site) {

		site.setModifiedAt((new Date()).getTime() / 1000);
		Site newSite = null;
		try {
			newSite = siteRepository.saveAndFlush(site);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newSite;

	}

	@Modifying
	@Transactional(noRollbackFor = Exception.class)
	public void deleteSite(Site site) {

		try {
			siteRepository.deleteById(site.getId());
			siteRepository.flush();
		} catch (Exception e) {
			log.error(e.getMessage());
		}

	}
}
