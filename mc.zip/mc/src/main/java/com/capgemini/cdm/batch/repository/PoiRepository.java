package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Component;

import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.projection.PoiListItem;

@Component
@RepositoryRestResource(path = "pois", collectionResourceRel = "pois", excerptProjection = PoiListItem.class)
public interface PoiRepository extends JpaRepository<Poi, Long> {

	@RestResource(exported = false)
	List<Poi> findAllByTypeIdAndFloorBuildingId(
			@Param("typeId") Long typeId,
			@Param("buildingId") Long buildingId);

	@RestResource(exported = false)
	List<Poi> findAllByTypeIdAndFloorId(
			@Param("typeId") Long typeId,
			@Param("floorId") Long floorId);

	@RestResource(exported = false)
	List<Poi> findAllByFloorIdOrderByName(@Param("floorId") Long floorId);

	@RestResource(exported = false)
	Poi findByName(@Param("name") String name);

    @RestResource(exported = false)
	Poi findByFloorIdAndName(@Param("floorId") Long floorId,@Param("name") String name);
}
