package com.capgemini.cdm.batch.enumeration;

public class ConfigValueEnum {
	public static final String KEY_CDM_BATCH_ACTIVE = "cdm_batch_active";
	public static final String KEY_CDM_BATCH_ADRESSE = "cdm_batch_adresse";
	public static final String KEY_CDM_BATCH_SENDER = "cdm_batch_sender";
	public static final String KEY_CDM_BATCH_POI_UPDATED_SINCE_N_HOURS = "cdm_batch_poi_updated_since_n_hours";
	public static final String KEY_CDM_BATCH_UPDATE_ONLY_ACTIVE_BUILDING = "cdm_batch_update_only_active_building";
}