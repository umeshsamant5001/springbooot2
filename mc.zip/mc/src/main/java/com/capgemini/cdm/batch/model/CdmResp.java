package com.capgemini.cdm.batch.model;

public interface CdmResp {

	String formatBody();

}
