package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.PoiDTO;

@Mapper
public interface PoiMapper {
    
    PoiMapper INSTANCE = Mappers.getMapper(PoiMapper.class);

    PoiDTO poiToPoiDTO(Poi in);

    Poi poiDTOToPoi(PoiDTO in);

}

