package com.capgemini.cdm.batch.action;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.commons.collections4.CollectionUtils;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.CdmPoi;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.service.PoiService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchPoisDelete extends CdmBatchPoisAction {
    @Autowired
    private PoiService poiService;

    // Number of deleted POIs for the current process
    private Integer nbDeleted;

    @Override
    public boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM) {
        List<CdmPoi> floorPoisCDMkeys = floorCDM.getPoiInterfaceDTOs();
        return CollectionUtils.isNotEmpty(floorPoisCDMkeys);
    }

    @Override
    public Integer process(Floor floorCSO, CdmFloor floorCDM, List<Poi> listPois,
            List<CdmMatcherPoiType> matcherPoiType) {
        this.nbDeleted = 0;

        List<Long> floorPoisCDMkeys = floorCDM.getPoiInterfaceDTOs()
                .stream()
                .map(cdmPoi -> cdmPoi.getKeyId())
                .collect(Collectors.toList());

        if (Objects.nonNull(floorPoisCDMkeys) && !floorPoisCDMkeys.isEmpty()) {
            List<Poi> listPoisFiltered = listPois
                    .stream()
                    .filter(poiCSO -> this.isPoiTypeManagedByCDM(poiCSO.getTypeId(), matcherPoiType)
                            && (Objects.isNull(poiCSO.getCdmKeyId())
                                    || !floorPoisCDMkeys.contains(poiCSO.getCdmKeyId())))
                    .collect(Collectors.toList());

            // Remove poiCSO without cdmKeyId or with outdated ones
            listPoisFiltered.forEach(poiCSO -> {
                this.nbDeleted++;

                try {
                    poiService.deletePoi(poiCSO);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
            });
        }

        return this.nbDeleted;
    }
}
