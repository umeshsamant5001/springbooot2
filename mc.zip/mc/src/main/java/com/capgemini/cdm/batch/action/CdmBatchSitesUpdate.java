package com.capgemini.cdm.batch.action;

import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmSite;
import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.repository.CityRepository;
import com.capgemini.cdm.batch.service.SiteService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchSitesUpdate extends CdmBatchSitesAction {
    @Autowired
    private SiteService siteService;
    @Autowired
    private CityRepository cityRepository;

    @Override
    public boolean shouldProcess(Site siteCSO, CdmSite siteCDM) {
        return Objects.nonNull(siteCSO) && Objects.nonNull(siteCDM);
    }

    @Override
    public void process(Site siteCSO, CdmSite siteCDM) {
        siteCSO.setTitleEn(siteCDM.getSiteCommonName());
        siteCSO.setTitleFr(siteCDM.getSiteCommonName());
        siteCSO.getAttributes().put("lat", Double.toString(siteCDM.getLatitude()));
        siteCSO.getAttributes().put("lon", Double.toString(siteCDM.getLongitude()));
        City city = cityRepository.findByCdmKeyId(Long.valueOf(siteCDM.getCityKeyId()));
        if (Objects.nonNull(city)) {
            siteCSO.setCity(city);
            siteCSO.setCityId(city.getId());
            siteService.updateSite(siteCSO);
        }
    }

}