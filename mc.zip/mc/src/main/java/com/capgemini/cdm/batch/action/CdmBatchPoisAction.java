package com.capgemini.cdm.batch.action;

import java.io.ByteArrayInputStream;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.ConfigValue;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.PoiType;
import com.capgemini.cdm.batch.repository.ConfigRepository;
import com.capgemini.cdm.batch.repository.PoiTypeRepository;

public abstract class CdmBatchPoisAction {
    @Autowired
    private PoiTypeRepository poiTypeRepository;
    @Autowired
    private ConfigRepository configRepository;

    private List<ConfigValue> lConfigValue;
    // Preload of all Poi Types
    private Map<Long, PoiType> poiTypeMap;

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM);

    /**
     * Launch the process
     * 
     * @param floorCSO
     * @param floorCDM
     * @param listPois
     * @param matcherPoiType
     * @return
     */
    public abstract Integer process(Floor floorCSO, CdmFloor floorCDM, List<Poi> listPois,
            List<CdmMatcherPoiType> matcherPoiType);

    protected boolean isPoiTypeManagedByCDM(Long poiTypeId, List<CdmMatcherPoiType> matcherPoiType) {
        return matcherPoiType
                .stream()
                .anyMatch(matcher -> matcher.getPoiTypeId().equals(poiTypeId));
    }

    protected String getConfigStringValue(String key) {
        if (Objects.isNull(lConfigValue)) {
            lConfigValue = configRepository.findAll();
        }

        List<ConfigValue> lFilteredConfig = lConfigValue
                .stream()
                .filter(configValue -> configValue.getKeyName().equalsIgnoreCase(key))
                .collect(Collectors.toList());

        return CollectionUtils.isNotEmpty(lFilteredConfig)
                ? lFilteredConfig.get(0).getValue()
                : new String();
    }

    protected boolean getConfigBooleanValue(String key) {
        if (Objects.isNull(lConfigValue)) {
            lConfigValue = configRepository.findAll();
        }

        List<ConfigValue> lFilteredConfig = lConfigValue
                .stream()
                .filter(configValue -> configValue.getKeyName().equalsIgnoreCase(key))
                .collect(Collectors.toList());

        return Objects.nonNull(lFilteredConfig) && lFilteredConfig.size() == 1
                ? Boolean.parseBoolean(lFilteredConfig.get(0).getValue())
                : Boolean.FALSE;
    }

    protected boolean cdmNameIsInMatcher(String cdmLabel, List<CdmMatcherPoiType> matcherPoiType) {
        return matcherPoiType
                .stream()
                .anyMatch(matcher -> matcher.getCdmLabel().equalsIgnoreCase(cdmLabel));
    }

    // calculate the scaling ration to apply to cdm coordinates to place them on cdm
    // floor maps
    protected float getImageCDMScalingRatio(String base64) {
        float ratio;

        byte[] data = Base64.getMimeDecoder().decode(base64);
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        BufferedImage i;
        float width = -1f;
        float height = -1f;
        try {
            i = ImageIO.read(bis);
            width = (float) i.getWidth();
            height = (float) i.getHeight();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (width / (height / 500f) <= 800f) {
            ratio = height / 500f;
        } else {
            ratio = width / 800f;
        }

        if (width < 800f && height < 500f) {
            ratio = 1f;
        }

        return ratio;
    }

    protected Long getCSOPoiTypeId(String cdmLabel, List<CdmMatcherPoiType> matcherPoiType) {
        return matcherPoiType.stream()
                .filter(matcher -> matcher.getCdmLabel().equalsIgnoreCase(cdmLabel))
                .map(matcher -> matcher.getPoiTypeId())
                .collect(Collectors.toList())
                .get(0);
    }

    /**
     * Get a Poi Type by its id
     */
    protected PoiType getPoiTypeById(Long poiTypeId) {
        Map<Long, PoiType> poiTypeMap = this.getAllPoiType();

        if (Objects.isNull(poiTypeId) || !poiTypeMap.containsKey(poiTypeId)) {
            return null;
        }

        return poiTypeMap.get(poiTypeId);
    }

    /**
     * Get all Poi map by they id
     */
    private Map<Long, PoiType> getAllPoiType() {
        if (Objects.isNull(this.poiTypeMap)) {
            this.poiTypeMap = this.poiTypeRepository.findAll()
                    .stream()
                    .collect(Collectors.toMap(PoiType::getId, Function.identity()));
            ;
        }
        return this.poiTypeMap;
    }

}
