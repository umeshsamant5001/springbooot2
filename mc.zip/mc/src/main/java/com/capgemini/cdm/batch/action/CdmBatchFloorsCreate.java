package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.repository.BuildingRepository;
import com.capgemini.cdm.batch.service.FloorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchFloorsCreate extends CdmBatchFloorsAction {
    @Autowired
    private FloorService floorService;
    @Autowired
    private BuildingRepository buildingRepository;

    @Override
    public boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM) {
        return Objects.nonNull(floorCDM) && Objects.isNull(floorCSO) && Objects.nonNull(officeCDM)
                && Objects.nonNull(officeCDM.getStatus())
                && "active".equalsIgnoreCase(officeCDM.getStatus());
    }

    @Override
    public void process(Floor floorCSO, CdmFloor floorCDM, CdmTreeElement officeCDM) {
        floorCSO = new Floor();
        floorCSO.setCdmKeyId(floorCDM.getKeyId());
        floorCSO.setTitleEn(floorCDM.getName());
        floorCSO.setTitleFr(floorCDM.getName());
        floorCSO.setIndex(floorCDM.getFloorIndex().intValue());
        Building building = buildingRepository.findByCdmKeyId(officeCDM.getId());
        if (Objects.nonNull(building)) {
            floorCSO.setBuilding(building);
            floorCSO.setBuildingId(building.getId());
            floorService.createFloor(floorCSO);
        }
    }

}
