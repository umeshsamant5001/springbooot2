package com.capgemini.cdm.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.capgemini.cdm.batch.model.Equipment;

@RepositoryRestResource(path = "equipments")
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {
}
