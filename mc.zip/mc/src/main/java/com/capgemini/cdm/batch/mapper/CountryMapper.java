package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.model.CountryDTO;

@Mapper
public interface CountryMapper {
	

	CountryMapper INSTANCE = Mappers.getMapper(CountryMapper.class);

	CountryDTO countryToCountryDTO(Country in);
	
	Country countryDTOToCountry(CountryDTO in);


}
