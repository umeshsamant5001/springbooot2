package com.capgemini.cdm.batch.model;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class FloorDTO {

    private Long id;

    private Integer index;

    private Long buildingId;

    private String titleFr;

    private String titleEn;

    private Long modifiedAt;

    private Long cdmKeyId;

    private Map<String, String> attributes = new HashMap<>();
}
