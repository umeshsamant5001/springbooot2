package com.capgemini.cdm.batch.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "config_values")
public class ConfigValue implements Serializable {
    @Id
    @Column(name = "key_name", unique = true)
    private String keyName;

    @Column(name = "value")
    private String value;

}
