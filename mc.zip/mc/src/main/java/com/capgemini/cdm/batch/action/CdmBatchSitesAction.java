package com.capgemini.cdm.batch.action;

import com.capgemini.cdm.batch.model.CdmSite;
import com.capgemini.cdm.batch.model.Site;

public abstract class CdmBatchSitesAction {

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(Site siteCSO, CdmSite siteCDM);

    /**
     * Launch the process
     * 
     * @param siteCSO
     * @param siteCDM
     * @return
     */
    public abstract void process(Site siteCSO, CdmSite siteCDM);

}
