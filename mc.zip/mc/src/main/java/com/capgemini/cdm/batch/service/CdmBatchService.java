package com.capgemini.cdm.batch.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.action.CdmBatchBuildingsCreate;
import com.capgemini.cdm.batch.action.CdmBatchBuildingsDelete;
import com.capgemini.cdm.batch.action.CdmBatchBuildingsUpdate;
import com.capgemini.cdm.batch.action.CdmBatchCitiesCreate;
import com.capgemini.cdm.batch.action.CdmBatchCitiesDelete;
import com.capgemini.cdm.batch.action.CdmBatchCitiesUpdate;
import com.capgemini.cdm.batch.action.CdmBatchCountriesCreate;
import com.capgemini.cdm.batch.action.CdmBatchCountriesDelete;
import com.capgemini.cdm.batch.action.CdmBatchCountriesUpdate;
import com.capgemini.cdm.batch.action.CdmBatchFloorsCreate;
import com.capgemini.cdm.batch.action.CdmBatchFloorsDelete;
import com.capgemini.cdm.batch.action.CdmBatchFloorsUpdate;
import com.capgemini.cdm.batch.action.CdmBatchPoisCreate;
import com.capgemini.cdm.batch.action.CdmBatchPoisDelete;
import com.capgemini.cdm.batch.action.CdmBatchPoisUpdate;
import com.capgemini.cdm.batch.action.CdmBatchSitesCreate;
import com.capgemini.cdm.batch.action.CdmBatchSitesDelete;
import com.capgemini.cdm.batch.action.CdmBatchSitesUpdate;
import com.capgemini.cdm.batch.client.cdm.CdmClient;
import com.capgemini.cdm.batch.enumeration.EnumCdmAttributes;
import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.CdmAsset;
import com.capgemini.cdm.batch.model.CdmBatchResp;
import com.capgemini.cdm.batch.model.CdmCity;
import com.capgemini.cdm.batch.model.CdmCountry;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.CdmSite;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.Site;
import com.capgemini.cdm.batch.repository.BuildingRepository;
import com.capgemini.cdm.batch.repository.CdmMatcherPoiTypeRepository;
import com.capgemini.cdm.batch.repository.CityRepository;
import com.capgemini.cdm.batch.repository.ConfigRepository;
import com.capgemini.cdm.batch.repository.CountryRepository;
import com.capgemini.cdm.batch.repository.FloorRepository;
import com.capgemini.cdm.batch.repository.PoiRepository;
import com.capgemini.cdm.batch.repository.SiteRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CdmBatchService {

	@Autowired
	private CdmClient cdmClient;
	@Autowired
	private CdmMatcherPoiTypeRepository matcherPoiTypeRepo;
	@Autowired
	private CountryRepository countryRepo;
	@Autowired
	private CityRepository cityRepo;
	@Autowired
	private SiteRepository siteRepo;
	@Autowired
	private BuildingRepository buildingRepo;
	@Autowired
	private FloorRepository floorRepo;
	@Autowired
	private PoiRepository poiRepo;
	@Autowired
	private CdmBatchPoisDelete deletePoisAction;
	@Autowired
	private CdmBatchPoisCreate createPoisAction;
	@Autowired
	private CdmBatchPoisUpdate updatePoisAction;
	@Autowired
	private CdmBatchCountriesDelete deleteCountriesAction;
	@Autowired
	private CdmBatchCountriesCreate createCountriesAction;
	@Autowired
	private CdmBatchCountriesUpdate updateCountriesAction;
	@Autowired
	private CdmBatchCitiesDelete deleteCitiesAction;
	@Autowired
	private CdmBatchCitiesCreate createCitiesAction;
	@Autowired
	private CdmBatchCitiesUpdate updateCitiesAction;
	@Autowired
	private CdmBatchSitesDelete deleteSitesAction;
	@Autowired
	private CdmBatchSitesCreate createSitesAction;
	@Autowired
	private CdmBatchSitesUpdate updateSitesAction;
	@Autowired
	private CdmBatchBuildingsDelete deleteBuildingsAction;
	@Autowired
	private CdmBatchBuildingsCreate createBuildingsAction;
	@Autowired
	private CdmBatchBuildingsUpdate updateBuildingsAction;
	@Autowired
	private CdmBatchFloorsDelete deleteFloorsAction;
	@Autowired
	private CdmBatchFloorsCreate createFloorsAction;
	@Autowired
	private CdmBatchFloorsUpdate updateFloorsAction;

	/**
	 * Launch CdmBatch
	 * 
	 * @return
	 */
	public CdmBatchResp execBatch() {
		CdmBatchResp cdmBatchResp = new CdmBatchResp();

		List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
		if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

			List<CdmMatcherPoiType> listMatcherPoiTypeRepo = matcherPoiTypeRepo.findAll();

			log.info("Process Countries");
			Map<String, Integer> nProcessedCountry = doProcessCountries(listCDMTreeElement);

			cdmBatchResp.setNbCountryDelete(nProcessedCountry.get("deleted"));
			cdmBatchResp.setNbCountryUpdate(nProcessedCountry.get("updated"));
			cdmBatchResp.setNbCountryCreate(nProcessedCountry.get("created"));

			log.info("Process Cities");
			Map<String, Integer> nProcessedCity = doProcessCities(listCDMTreeElement);

			cdmBatchResp.setNbCityDelete(nProcessedCity.get("deleted"));
			cdmBatchResp.setNbCityUpdate(nProcessedCity.get("updated"));
			cdmBatchResp.setNbCityCreate(nProcessedCity.get("created"));

			log.info("Process Sites");
			Map<String, Integer> nProcessedSite = doProcessSites(listCDMTreeElement);

			cdmBatchResp.setNbSiteDelete(nProcessedSite.get("deleted"));
			cdmBatchResp.setNbSiteUpdate(nProcessedSite.get("updated"));
			cdmBatchResp.setNbSiteCreate(nProcessedSite.get("created"));

			log.info("Process Buildings");
			Map<String, Integer> nProcessedBuilding = doProcessBuildings(listCDMTreeElement);

			cdmBatchResp.setNbBuildingDelete(nProcessedBuilding.get("deleted"));
			cdmBatchResp.setNbBuildingUpdate(nProcessedBuilding.get("updated"));
			cdmBatchResp.setNbBuildingCreate(nProcessedBuilding.get("created"));

			log.info("Process Floors");
			Map<String, Integer> nProcessedFloor = doProcessFloors(listCDMTreeElement);

			cdmBatchResp.setNbFloorDelete(nProcessedFloor.get("deleted"));
			cdmBatchResp.setNbFloorUpdate(nProcessedFloor.get("updated"));
			cdmBatchResp.setNbFloorCreate(nProcessedFloor.get("created"));

			log.info("Process POIs");
			Map<String, Integer> nProcessedPoi = doProcessPois(listMatcherPoiTypeRepo);

			cdmBatchResp.setNbPoiDelete(nProcessedPoi.get("deleted"));
			cdmBatchResp.setNbPoiUpdate(nProcessedPoi.get("updated"));
			cdmBatchResp.setNbPoiCreate(nProcessedPoi.get("created"));
		}

		return cdmBatchResp;
	}

	/**
	 * Cdm Batch Process for Countries (Delete/Update/Create)
	 * 
	 * @param lCDMTreeElement
	 * @return
	 */
	public Map<String, Integer> doProcessCountries(List<CdmTreeElement> lCDMTreeElement) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		// Get Countries CdmKeyId from CdmTree
		List<Long> lCountriesIdCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isCountry())
				.map(elem -> elem.getId())
				.collect(Collectors.toList());

		// Get Countries form SmartOffice Database
		List<Country> lCountriesCSO = countryRepo.findAll()
				.stream()
				.filter(countryCSO -> Objects.nonNull(countryCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		// Keep only CdmKeyId from SmartOffice Database Countries
		List<Long> lCountriesCSOIdCDM = lCountriesCSO.stream().map(elem -> elem.getCdmKeyId())
				.collect(Collectors.toList());

		// Remove duplicate CdmKeyId
		List<Long> lCountriesMergeWithoutDuplicate = new ArrayList<>(lCountriesCSOIdCDM);
		lCountriesMergeWithoutDuplicate.removeAll(lCountriesIdCDM);
		lCountriesMergeWithoutDuplicate.addAll(lCountriesIdCDM);

		if (CollectionUtils.isEmpty(lCountriesMergeWithoutDuplicate)) {
			return result;
		}

		// Initialisation of the counter of processed Countries
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each country
		lCountriesMergeWithoutDuplicate.forEach(cdmKeyId -> {
			CdmCountry countryCDM = cdmClient.getCountryByCdmKey(cdmKeyId);
			Country countryCSO = lCountriesCSO.stream().filter(country -> cdmKeyId.equals(country.getCdmKeyId()))
					.findAny().orElse(null);

			// Check if action can be process
			boolean canDelete = deleteCountriesAction.shouldProcess(countryCSO, countryCDM);
			boolean canUpdate = updateCountriesAction.shouldProcess(countryCSO, countryCDM);
			boolean canCreate = createCountriesAction.shouldProcess(countryCSO, countryCDM);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			// Process deletion for Countries
			if (Boolean.TRUE.equals(canDelete)) {
				deleteCountriesAction.process(countryCSO, countryCDM);
				nbDeleted.addAndGet(1);
			}

			// Process update for Countries
			if (Boolean.TRUE.equals(canUpdate)) {
				updateCountriesAction.process(countryCSO, countryCDM);
				nbUpdated.addAndGet(1);
			}

			// Process create for Countries
			if (Boolean.TRUE.equals(canCreate)) {
				createCountriesAction.process(countryCSO, countryCDM);
				nbCreated.addAndGet(1);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

	/**
	 * Cdm Batch Process for Cities (Delete/Update/Create)
	 * 
	 * @param lCDMTreeElement
	 * @return
	 */
	public Map<String, Integer> doProcessCities(List<CdmTreeElement> lCDMTreeElement) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		// Get Cities CdmKeyId from CdmTree
		List<Long> lCitiesIdCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isCity())
				.map(elem -> elem.getId())
				.collect(Collectors.toList());

		// Get Cities from SmartOffice Database
		List<City> lCitiesCSO = cityRepo.findAll()
				.stream()
				.filter(cityCSO -> Objects.nonNull(cityCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		// Keep only CdmKeyId from SmartOffice Database Cities
		List<Long> lCitiesCSOIdCDM = lCitiesCSO.stream().map(elem -> elem.getCdmKeyId())
				.collect(Collectors.toList());

		// Remove duplicate CdmKeyId
		List<Long> lCitiesMergeWithoutDuplicate = new ArrayList<>(lCitiesCSOIdCDM);
		lCitiesMergeWithoutDuplicate.removeAll(lCitiesIdCDM);
		lCitiesMergeWithoutDuplicate.addAll(lCitiesIdCDM);

		if (CollectionUtils.isEmpty(lCitiesMergeWithoutDuplicate)) {
			return result;
		}

		// Initialisation of the counter of processed Cities
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each city
		lCitiesMergeWithoutDuplicate.forEach(cdmKeyId -> {
			CdmCity cityCDM = cdmClient.getCityByCdmKey(cdmKeyId);
			City cityCSO = lCitiesCSO.stream().filter(city -> cdmKeyId.equals(city.getCdmKeyId()))
					.findAny().orElse(null);

			// Check if action can be process
			boolean canDelete = deleteCitiesAction.shouldProcess(cityCSO, cityCDM);
			boolean canUpdate = updateCitiesAction.shouldProcess(cityCSO, cityCDM);
			boolean canCreate = createCitiesAction.shouldProcess(cityCSO, cityCDM);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			// Process deletion for Cities
			if (Boolean.TRUE.equals(canDelete)) {
				deleteCitiesAction.process(cityCSO, cityCDM);
				nbDeleted.addAndGet(1);
			}

			// Process update for Cities
			if (Boolean.TRUE.equals(canUpdate)) {
				updateCitiesAction.process(cityCSO, cityCDM);
				nbUpdated.addAndGet(1);
			}

			// Process create for Cities
			if (Boolean.TRUE.equals(canCreate)) {
				createCitiesAction.process(cityCSO, cityCDM);
				nbCreated.addAndGet(1);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

	/**
	 * Cdm Batch Process for Sites (Delete/Update/Create)
	 * 
	 * @param lCDMTreeElement
	 * @return
	 */
	public Map<String, Integer> doProcessSites(List<CdmTreeElement> lCDMTreeElement) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		// Get Sites CdmKeyId from cdmTree
		List<Long> lSitesIdCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isSite())
				.map(elem -> elem.getId())
				.collect(Collectors.toList());

		// Get Sites from SmartOffice Database
		List<Site> lSitesCSO = siteRepo.findAll()
				.stream()
				.filter(siteCSO -> Objects.nonNull(siteCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		// Keep only CdmKeyId from SmartOffice Database Sites
		List<Long> lSitesCSOIdCDM = lSitesCSO.stream().map(elem -> elem.getCdmKeyId())
				.collect(Collectors.toList());

		// Remove duplicate CdmKeyId
		List<Long> lSitesMergeWithoutDuplicate = new ArrayList<>(lSitesCSOIdCDM);
		lSitesMergeWithoutDuplicate.removeAll(lSitesIdCDM);
		lSitesMergeWithoutDuplicate.addAll(lSitesIdCDM);

		if (CollectionUtils.isEmpty(lSitesMergeWithoutDuplicate)) {
			return result;
		}

		// Initialisation of the counter of processed Sites
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each site
		lSitesMergeWithoutDuplicate.forEach(cdmKeyId -> {
			CdmSite siteCDM = cdmClient.getSiteByCdmKey(cdmKeyId);
			Site siteCSO = lSitesCSO.stream().filter(site -> cdmKeyId.equals(site.getCdmKeyId()))
					.findAny().orElse(null);

			// Check if action can be process
			boolean canDelete = deleteSitesAction.shouldProcess(siteCSO, siteCDM);
			boolean canUpdate = updateSitesAction.shouldProcess(siteCSO, siteCDM);
			boolean canCreate = createSitesAction.shouldProcess(siteCSO, siteCDM);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			// Process deletion for Sites
			if (Boolean.TRUE.equals(canDelete)) {
				deleteSitesAction.process(siteCSO, siteCDM);
				nbDeleted.addAndGet(1);
			}

			// Process update for Sites
			if (Boolean.TRUE.equals(canUpdate)) {
				updateSitesAction.process(siteCSO, siteCDM);
				nbUpdated.addAndGet(1);
			}

			// Process create for Sites
			if (Boolean.TRUE.equals(canCreate)) {
				createSitesAction.process(siteCSO, siteCDM);
				nbCreated.addAndGet(1);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

	/**
	 * Cdm Batch Process for Buildings (Delete/Update/Create)
	 * 
	 * @param lCDMTreeElement
	 * @return
	 */
	public Map<String, Integer> doProcessBuildings(List<CdmTreeElement> lCDMTreeElement) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		// Get Buildings CdmKeyId from CdmTree
		List<Long> lBuildingsIdCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isOffice())
				.map(elem -> elem.getId())
				.collect(Collectors.toList());

		// Get Buildings from SmartOffice Database
		List<Building> lBuildingsCSO = buildingRepo.findAll()
				.stream()
				.filter(buildingCSO -> Objects.nonNull(buildingCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		// Keep only CdmKeyId from SmartOffice Database Buildings
		List<Long> lBuildingsCSOIdCDM = lBuildingsCSO.stream().map(elem -> elem.getCdmKeyId())
				.collect(Collectors.toList());

		// Remove deuplicate CdmKeyId
		List<Long> lBuildingsMergeWithoutDuplicate = new ArrayList<>(lBuildingsIdCDM);
		lBuildingsMergeWithoutDuplicate.removeAll(lBuildingsCSOIdCDM);
		lBuildingsMergeWithoutDuplicate.addAll(lBuildingsCSOIdCDM);

		if (CollectionUtils.isEmpty(lBuildingsMergeWithoutDuplicate)) {
			return result;
		}

		// Initialisation of the counter of processed Cities
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each building
		lBuildingsMergeWithoutDuplicate.forEach(cdmKeyId -> {
			CdmAsset assetCDM = cdmClient.getAssetByCdmKey(cdmKeyId);
			Building buildingCSO = lBuildingsCSO.stream().filter(building -> cdmKeyId.equals(building.getCdmKeyId()))
					.findAny().orElse(null);

			// Check if action can be process
			boolean canDelete = deleteBuildingsAction.shouldProcess(buildingCSO, assetCDM);
			boolean canUpdate = updateBuildingsAction.shouldProcess(buildingCSO, assetCDM);
			boolean canCreate = createBuildingsAction.shouldProcess(buildingCSO, assetCDM);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			// Process deletion for buildings
			if (Boolean.TRUE.equals(canDelete)) {
				deleteBuildingsAction.process(buildingCSO, assetCDM);
				nbDeleted.addAndGet(1);
			}

			// Process update for buildings
			if (Boolean.TRUE.equals(canUpdate)) {
				updateBuildingsAction.process(buildingCSO, assetCDM);
				nbUpdated.addAndGet(1);
			}

			// Process create for buildings
			if (Boolean.TRUE.equals(canCreate)) {
				createBuildingsAction.process(buildingCSO, assetCDM);
				nbCreated.addAndGet(1);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

	/**
	 * Cdm Batch Process for Floors (Delete/Update/Create)
	 * 
	 * @param lCDMTreeElement
	 * @return
	 */
	public Map<String, Integer> doProcessFloors(List<CdmTreeElement> lCDMTreeElement) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		// Get Floors from CdmTree
		List<CdmTreeElement> lFloorsCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isFloor())
				.collect(Collectors.toList());

		// Get Floors CdmKeyId from CdmTree
		List<Long> lFloorsIdCDM = lFloorsCDM
				.stream()
				.map(elem -> elem.getId())
				.collect(Collectors.toList());

		// Get Office from CdmTree
		List<CdmTreeElement> lBuildingsCDM = lCDMTreeElement
				.stream()
				.filter(cdmElement -> cdmElement.isOffice() && Objects.nonNull(cdmElement.getAssetID()))
				.collect(Collectors.toList());

		// Get Floors from SmartOffice Database
		List<Floor> lFloorsCSO = floorRepo.findAll()
				.stream()
				.filter(floorCSO -> Objects.nonNull(floorCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		// Keep only CdmKeyId from SmartOffice Database Floors
		List<Long> lFloorCSOIdCDM = lFloorsCSO.stream().map(elem -> elem.getCdmKeyId())
				.collect(Collectors.toList());

		// Remove duplicate CdmKeyId
		List<Long> lFloorsMergeWithoutDuplicate = new ArrayList<>(lFloorCSOIdCDM);
		lFloorsMergeWithoutDuplicate.removeAll(lFloorsIdCDM);
		lFloorsMergeWithoutDuplicate.addAll(lFloorsIdCDM);

		if (CollectionUtils.isEmpty(lFloorsMergeWithoutDuplicate)) {
			return result;
		}

		// Initialisation of the counter of processed Floors
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each floor
		lFloorsMergeWithoutDuplicate.forEach(cdmKeyId -> {
			CdmTreeElement floorTreeCdm = lFloorsCDM.stream()
					.filter(element -> cdmKeyId.equals(element.getId()))
					.findAny().orElse(null);

			CdmTreeElement officeTreeCdm = null;
			if (Objects.nonNull(floorTreeCdm)) {
				officeTreeCdm = lBuildingsCDM.stream()
						.filter(offTree -> floorTreeCdm.getAssetID().equals(offTree.getAssetID()))
						.findAny().orElse(null);
			}

			CdmFloor floorCDM = null;
			if (Objects.nonNull(officeTreeCdm)) {
				floorCDM = cdmClient.getPoiFloorCDM(officeTreeCdm.getAssetID(), cdmKeyId).get(0);
			}
			Floor floorCSO = lFloorsCSO.stream().filter(floor -> cdmKeyId.equals(floor.getCdmKeyId()))
					.findAny().orElse(null);

			// Check if action can be process
			boolean canDelete = deleteFloorsAction.shouldProcess(floorCSO, floorCDM, officeTreeCdm);
			boolean canUpdate = updateFloorsAction.shouldProcess(floorCSO, floorCDM, officeTreeCdm);
			boolean canCreate = createFloorsAction.shouldProcess(floorCSO, floorCDM, officeTreeCdm);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			// Process deletion Floors
			if (Boolean.TRUE.equals(canDelete)) {
				deleteFloorsAction.process(floorCSO, floorCDM, officeTreeCdm);
				nbDeleted.addAndGet(1);
			}

			// Process update Floors
			if (Boolean.TRUE.equals(canUpdate)) {
				updateFloorsAction.process(floorCSO, floorCDM, officeTreeCdm);
				nbUpdated.addAndGet(1);
			}

			// Process creat Floors
			if (Boolean.TRUE.equals(canCreate)) {
				createFloorsAction.process(floorCSO, floorCDM, officeTreeCdm);
				nbCreated.addAndGet(1);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

	/**
	 * CdmBatch process for POIs (Delete/Update/Create)
	 * 
	 * @param matcherPoiType
	 * @return
	 */
	public Map<String, Integer> doProcessPois(
			List<CdmMatcherPoiType> matcherPoiType) {
		Map<String, Integer> result = new HashMap<>();

		// Default values for the result
		result.put("created", 0);
		result.put("updated", 0);
		result.put("deleted", 0);

		List<Floor> listFloorsCSOWithCDMKey = floorRepo.findAll()
				.stream()
				.filter(floorCSO -> Objects.nonNull(floorCSO.getCdmKeyId()))
				.collect(Collectors.toList());

		if (Objects.isNull(listFloorsCSOWithCDMKey) || listFloorsCSOWithCDMKey.isEmpty()) {
			return result;
		}

		// Initialisation of the counter of processed POIs
		AtomicInteger nbCreated = new AtomicInteger(0);
		AtomicInteger nbUpdated = new AtomicInteger(0);
		AtomicInteger nbDeleted = new AtomicInteger(0);

		// For each floor
		listFloorsCSOWithCDMKey.forEach(floorCSO -> {
			CdmFloor floorCDM = cdmClient
					.getPoiFloorCDM(
							floorCSO.getBuilding().getAttributes().get(EnumCdmAttributes.ASSET_ID.toString()),
							floorCSO.getCdmKeyId())
					.get(0);

			// Check if action can be process
			boolean canDelete = deletePoisAction.shouldProcess(floorCSO, floorCDM);
			boolean canUpdate = updatePoisAction.shouldProcess(floorCSO, floorCDM);
			boolean canCreate = createPoisAction.shouldProcess(floorCSO, floorCDM);

			if (Boolean.FALSE.equals(canDelete) && Boolean.FALSE.equals(canUpdate) && Boolean.FALSE.equals(canCreate)) {
				return;
			}

			List<Poi> listPois = poiRepo.findAllByFloorIdOrderByName(floorCSO.getId());

			// Process deletion for POIs on this Floor
			if (Boolean.TRUE.equals(canDelete)) {
				Integer nbDeletedPOIs = deletePoisAction.process(floorCSO, floorCDM, listPois, matcherPoiType);
				nbDeleted.addAndGet(nbDeletedPOIs);
			}

			// Process update for POIs on this Floor
			if (Boolean.TRUE.equals(canUpdate)) {
				Integer nbUpdatedPOIs = updatePoisAction.process(floorCSO, floorCDM, listPois, matcherPoiType);
				nbUpdated.addAndGet(nbUpdatedPOIs);
			}

			// Process create for POIs on this Floor
			if (Boolean.TRUE.equals(canCreate)) {
				Integer nbCreatedPOIs = createPoisAction.process(floorCSO, floorCDM, listPois, matcherPoiType);
				nbCreated.addAndGet(nbCreatedPOIs);
			}
		});

		result.put("created", nbCreated.get());
		result.put("updated", nbUpdated.get());
		result.put("deleted", nbDeleted.get());

		return result;
	}

}
