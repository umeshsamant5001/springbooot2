package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmCountry;
import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.service.CountryService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchCountriesCreate extends CdmBatchCountriesAction {
    @Autowired
    private CountryService countryService;

    @Override
    public boolean shouldProcess(Country countryCSO, CdmCountry countryCDM) {
        return Objects.nonNull(countryCDM) && Objects.isNull(countryCSO);
    }

    @Override
    public void process(Country countryCSO, CdmCountry countryCDM) {
        countryCSO = new Country();
        countryCSO.setTitleEn(countryCDM.getName());
        countryCSO.setTitleFr(countryCDM.getName());
        countryCSO.setCdmKeyId(countryCDM.getKeyID());
        countryCSO.setCountryIsoAlpha2(countryCDM.getIso31661Alpha2());

        countryService.createCountry(countryCSO);
    }

}
