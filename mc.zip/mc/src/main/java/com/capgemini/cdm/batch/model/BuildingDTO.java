package com.capgemini.cdm.batch.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class BuildingDTO {

    private Long id;


    private Long siteId;

    private Boolean deployed;

    private Boolean secured;

    private Long defaultMapId;

    private Long imageId;

    private String timezoneWindows;

    private String timezoneJava;

    private Long modifiedAt;

    private List<Floor> floors;

    private String titleFr;

    private String titleEn;

    private BuildingInformation information;

    private String mailingList;

    private Long cdmKeyId;

    private Map<String, String> attributes = new HashMap<String, String>();
}
