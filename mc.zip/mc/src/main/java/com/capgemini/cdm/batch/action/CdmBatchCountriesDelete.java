package com.capgemini.cdm.batch.action;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.model.CdmCountry;
import com.capgemini.cdm.batch.model.Country;
import com.capgemini.cdm.batch.service.CountryService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchCountriesDelete extends CdmBatchCountriesAction {
    @Autowired
    private CountryService countryService;

    @Override
    public boolean shouldProcess(Country countryCSO, CdmCountry countryCDM) {
        return Objects.isNull(countryCDM) && Objects.nonNull(countryCSO);
    }

    @Override
    public void process(Country countryCSO, CdmCountry countryCDM) {
        countryService.deleteCountry(countryCSO);
    }
}