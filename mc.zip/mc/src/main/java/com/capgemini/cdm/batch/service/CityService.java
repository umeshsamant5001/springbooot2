package com.capgemini.cdm.batch.service;

import java.util.Date;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import com.capgemini.cdm.batch.model.City;
import com.capgemini.cdm.batch.repository.CityRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CityService {
	static final String API_TAG = "City";

	@Autowired
	private CityRepository cityRepository;

	public City createCity(City city) {
		city.setModifiedAt(new Date().getTime() / 1000);

		City postedCity = null;
		try {
			postedCity = this.cityRepository.save(city);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return postedCity;

	}

	public City updateCity(City city) {
		city.setModifiedAt(new Date().getTime() / 1000);
		City newCity = null;
		try {
			newCity = cityRepository.saveAndFlush(city);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newCity;

	}

    @Modifying
    @Transactional(noRollbackFor = Exception.class)
    public void deleteCity(City city) {

        try {
            cityRepository.deleteById(city.getId());
            cityRepository.flush();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }
}
