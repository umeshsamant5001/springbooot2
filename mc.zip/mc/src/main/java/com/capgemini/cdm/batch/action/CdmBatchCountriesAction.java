package com.capgemini.cdm.batch.action;

import com.capgemini.cdm.batch.model.CdmCountry;
import com.capgemini.cdm.batch.model.Country;

public abstract class CdmBatchCountriesAction {

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(Country countryCSO, CdmCountry countryCDM);

    /**
     * Launch the process
     * 
     * @param countryCSO
     * @param countryCDM
     * @return
     */
    public abstract void process(Country countryCSO, CdmCountry countryCDM);

}
