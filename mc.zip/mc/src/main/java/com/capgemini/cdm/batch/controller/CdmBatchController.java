package com.capgemini.cdm.batch.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.cdm.batch.client.cdm.CdmClient;
import com.capgemini.cdm.batch.model.CdmBatchResp;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.CdmTreeElement;
import com.capgemini.cdm.batch.repository.CdmMatcherPoiTypeRepository;
import com.capgemini.cdm.batch.service.CdmBatchService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = CdmBatchController.ROOT_API, produces = APPLICATION_JSON_VALUE)
public class CdmBatchController {

    static final String ROOT_API = "api/batch";

    static final String API_TAG = "Batch";

    @Autowired
    private CdmBatchService cdmBatchService;
    @Autowired
    private CdmMatcherPoiTypeRepository matcherPoiTypeRepo;
    @Autowired
    private CdmClient cdmClient;

    @PutMapping()
    public ResponseEntity<CdmBatchResp> putBatchUpdateCreateCSOFromCDM() {

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchService.execBatch());

    }

    @PutMapping("countries")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeleteCountries() {

        List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbCountryDelete(0);
        cdmBatchResp.setNbCountryUpdate(0);
        cdmBatchResp.setNbCountryCreate(0);

        if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

            log.info("Process Countries API");
            Map<String, Integer> nProcessedCountry = cdmBatchService.doProcessCountries(listCDMTreeElement);

            cdmBatchResp.setNbCountryDelete(nProcessedCountry.get("deleted"));
            cdmBatchResp.setNbCountryUpdate(nProcessedCountry.get("updated"));
            cdmBatchResp.setNbCountryCreate(nProcessedCountry.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

    @PutMapping("cities")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeleteCities() {

        List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbCityDelete(0);
        cdmBatchResp.setNbCityUpdate(0);
        cdmBatchResp.setNbCityCreate(0);

        if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

            log.info("Process Cities API");
            Map<String, Integer> nProcessedCity = cdmBatchService.doProcessCities(listCDMTreeElement);

            cdmBatchResp.setNbCityDelete(nProcessedCity.get("deleted"));
            cdmBatchResp.setNbCityUpdate(nProcessedCity.get("updated"));
            cdmBatchResp.setNbCityCreate(nProcessedCity.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

    @PutMapping("sites")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeleteSites() {

        List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbSiteDelete(0);
        cdmBatchResp.setNbSiteUpdate(0);
        cdmBatchResp.setNbSiteCreate(0);

        if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

            log.info("Process Sites API");
            Map<String, Integer> nProcessedSite = cdmBatchService.doProcessSites(listCDMTreeElement);

            cdmBatchResp.setNbSiteDelete(nProcessedSite.get("deleted"));
            cdmBatchResp.setNbSiteUpdate(nProcessedSite.get("updated"));
            cdmBatchResp.setNbSiteCreate(nProcessedSite.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

    @PutMapping("buildings")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeleteBuildings() {

        List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbBuildingDelete(0);
        cdmBatchResp.setNbBuildingUpdate(0);
        cdmBatchResp.setNbBuildingCreate(0);

        if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

            log.info("Process Buildings API");
            Map<String, Integer> nProcessedBuilding = cdmBatchService.doProcessBuildings(listCDMTreeElement);

            cdmBatchResp.setNbBuildingDelete(nProcessedBuilding.get("deleted"));
            cdmBatchResp.setNbBuildingUpdate(nProcessedBuilding.get("updated"));
            cdmBatchResp.setNbBuildingCreate(nProcessedBuilding.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

    @PutMapping("floors")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeleteFloors() {

        List<CdmTreeElement> listCDMTreeElement = cdmClient.getTreeCDM();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbFloorDelete(0);
        cdmBatchResp.setNbFloorUpdate(0);
        cdmBatchResp.setNbFloorCreate(0);

        if (CollectionUtils.isNotEmpty(listCDMTreeElement)) {

            log.info("Process Floors API");
            Map<String, Integer> nProcessedFloor = cdmBatchService.doProcessFloors(listCDMTreeElement);

            cdmBatchResp.setNbFloorDelete(nProcessedFloor.get("deleted"));
            cdmBatchResp.setNbFloorUpdate(nProcessedFloor.get("updated"));
            cdmBatchResp.setNbFloorCreate(nProcessedFloor.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

    @PutMapping("pois")
    public ResponseEntity<CdmBatchResp> batchCreateUpdateDeletePois() {

        List<CdmMatcherPoiType> listMatcherPoiTypeRepo = matcherPoiTypeRepo.findAll();
        CdmBatchResp cdmBatchResp = new CdmBatchResp();
        cdmBatchResp.setNbPoiDelete(0);
        cdmBatchResp.setNbPoiUpdate(0);
        cdmBatchResp.setNbPoiCreate(0);

        if (CollectionUtils.isNotEmpty(listMatcherPoiTypeRepo)) {

            log.info("Process POIs API");
            Map<String, Integer> nProcessedPoi = cdmBatchService.doProcessPois(listMatcherPoiTypeRepo);

            cdmBatchResp.setNbPoiDelete(nProcessedPoi.get("deleted"));
            cdmBatchResp.setNbPoiUpdate(nProcessedPoi.get("updated"));
            cdmBatchResp.setNbPoiCreate(nProcessedPoi.get("created"));
        }

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(cdmBatchResp);

    }

}
