package com.capgemini.cdm.batch.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CdmState {

	List<CdmCity> cities = new ArrayList<>();

}
