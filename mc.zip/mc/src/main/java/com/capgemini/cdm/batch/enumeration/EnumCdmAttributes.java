package com.capgemini.cdm.batch.enumeration;

public enum EnumCdmAttributes {
	UNKNOWN("cdm.unknown"), ASSET_ID("cdm.asset_id") // only used on floors (needed for matching pois and getting base64 maps)
	, ACTIVE("cdm.active"), ADDRESS("cdm.address"), SITE_CODE("cdm.site_code"), TYPE("cdm.type"), SECURED_FLOOR("cdm.secured_floor"),
	POI_SPACE_TYPE_NAME("cdm.poi_space_type_name"), POI_SPACE_CATEGORY_NAME("cdm.poi_space_category_name"),
	HOTELING_SPACE("cdm.hoteling_space"), SPECIAL_SECURED_NON_SECURED("cdm.special_secured_non_secured"),
	OPERATION("cdm.operation"), AREA_NAME("cdm.area_name");

	private final String text;

	EnumCdmAttributes(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}
