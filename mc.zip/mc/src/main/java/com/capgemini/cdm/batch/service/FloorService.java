package com.capgemini.cdm.batch.service;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.repository.BuildingRepository;
import com.capgemini.cdm.batch.repository.FloorRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FloorService {
	static final String API_TAG = "Floor";

	@Autowired
	private FloorRepository floorRepository;
	public Floor createFloor(Floor floorRequest) {
		// Geometry is always null for floor
		floorRequest.setModifiedAt(new Date().getTime() / 1000);

		Floor newFloor = null;
		try {
			newFloor = floorRepository.save(floorRequest);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newFloor;

	}

	public Floor updateFloor(Floor floor) {
		floor.setModifiedAt(new Date().getTime() / 1000);

		Floor newFloor = null;
		try {
			newFloor = floorRepository.saveAndFlush(floor);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return newFloor;
	}

	@Modifying
	@Transactional(noRollbackFor = Exception.class)
	public void deleteFloor(Floor floor) {

		try {
			floorRepository.deleteById(floor.getId());
			floorRepository.flush();
		} catch (Exception e) {
			log.error(e.getMessage());
		}

	}
}
