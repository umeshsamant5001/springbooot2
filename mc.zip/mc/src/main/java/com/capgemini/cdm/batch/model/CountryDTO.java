package com.capgemini.cdm.batch.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class CountryDTO {

    private Long id;

    private Long modifiedAt;

    private Long cdmKeyId;

    private String countryIsoAlpha2;

    private Map<String, String> attributes = new HashMap<String, String>();

    private List<City> cities;

    private String titleFr;

    private String titleEn;
}
