package com.capgemini.cdm.batch.service;

import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.cdm.batch.mapper.PoiMapper;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.PoiDTO;
import com.capgemini.cdm.batch.repository.FloorRepository;
import com.capgemini.cdm.batch.repository.PoiRepository;
import com.capgemini.cdm.batch.repository.PoiTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PoiService {

    @Autowired
    private PoiRepository poiRepository;

    @Autowired
    private FloorRepository floorRepository;

    @Autowired
    private PoiTypeRepository poiTypeRepository;

    /***
     * Create a poi
     * 
     * @param poi
     * @return
     */
    public Poi createPoi(Poi poi) {
        poi.setModifiedAt((new Date()).getTime() / 1000);
        Poi save = null;
        try {
            save = this.poiRepository.save(poi);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return save;
    }

    /***
     * Update a poi
     * 
     * @param newPoi
     * @return
     */
    public Poi updatePoi(Poi newPoi) {
        newPoi.setModifiedAt((new Date()).getTime() / 1000);
        Poi poiSave = null;
        try {
            poiSave = this.poiRepository.saveAndFlush(newPoi);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return poiSave;
    }

    @Modifying
    @Transactional(noRollbackFor = Exception.class)
    public void deletePoi(Poi poi) {

        try {
            poiRepository.deleteById(poi.getId());
            poiRepository.flush();
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }

    public Function<List<Poi>, List<PoiDTO>> poiListToPoiDTOList() {
        return in -> in.stream().map(toPoiDTO()).collect(Collectors.toList());
    }

    public Function<Poi, PoiDTO> toPoiDTO() {
        return PoiMapper.INSTANCE::poiToPoiDTO;
    }
}