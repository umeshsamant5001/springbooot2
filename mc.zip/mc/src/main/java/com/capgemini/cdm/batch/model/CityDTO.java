package com.capgemini.cdm.batch.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class CityDTO {

    private Long id;

    private Long modifiedAt;

    private String titleFr;

    private String titleEn;

    private List<Site> sites;

    private Long cdmKeyId;

    private Long cdmStateId;

    private Map<String, String> attributes = new HashMap<String, String>();
}
