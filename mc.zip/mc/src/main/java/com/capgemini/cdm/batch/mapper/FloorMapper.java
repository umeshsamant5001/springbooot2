package com.capgemini.cdm.batch.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.capgemini.cdm.batch.model.FloorDTO;
import com.capgemini.cdm.batch.model.Floor;

@Mapper
public interface FloorMapper {
	FloorMapper INSTANCE = Mappers.getMapper(FloorMapper.class);

	FloorDTO floorToFloorDTO(Floor in);
	
	Floor floorDTOToFloor(FloorDTO in);

}
