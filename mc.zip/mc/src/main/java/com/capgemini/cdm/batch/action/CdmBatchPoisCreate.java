package com.capgemini.cdm.batch.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.enumeration.EnumCdmAttributes;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.CdmPoi;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.service.PoiService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchPoisCreate extends CdmBatchPoisAction {
    @Autowired
    private PoiService poiService;
    // Number of updated POIs for the current process
    private Integer nbCreated;

    @Override
    public boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM) {
        return (Objects.nonNull(floorCSO.getBuilding()) && Objects.nonNull(floorCSO.getBuilding().getAttributes())
                && floorCSO.getBuilding().getAttributes().containsKey(EnumCdmAttributes.ACTIVE.toString())
                && floorCSO.getBuilding().getAttributes().get(EnumCdmAttributes.ACTIVE.toString())
                        .equalsIgnoreCase("Y"));
    }

    @Override
    public Integer process(Floor floorCSO, CdmFloor floorCDM, List<Poi> listPois,
            List<CdmMatcherPoiType> matcherPoiType) {
        this.nbCreated = 0;

        List<Poi> listPoisCSOSelectFloor = listPois.stream().filter(poiCSO -> Objects.nonNull(poiCSO.getCdmKeyId()))
                .collect(Collectors.toList());

        List<CdmPoi> listPoiCDM = floorCDM.getPoiInterfaceDTOs().stream()
                .filter(poiVerifCDM -> cdmNameIsInMatcher(poiVerifCDM.getPoiSpaceTypeName(), matcherPoiType))
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(listPoisCSOSelectFloor)) {
            // Remove poiCSO with cdmKeyID in poiCDM list
            listPoiCDM.removeIf(poiCDM -> listPoisCSOSelectFloor.stream()
                    .anyMatch(poiCSO -> (poiCDM.getKeyId().equals(poiCSO.getCdmKeyId()))));
        }

        float coordinatesScalingRatio = getImageCDMScalingRatio(floorCDM.getBase64Map());

        log.info("Size Pois to create " + listPoiCDM.size() + " For floorId " + floorCSO.getId());

        // To each poiCSO, create poiCSO with poiCDM attribute
        listPoiCDM.forEach(poiCDM -> {
            Poi poiCSO = new Poi();

            Long poiTypeId = this.getCSOPoiTypeId(poiCDM.getPoiSpaceTypeName(), matcherPoiType);

            poiCSO.setCdmKeyId(poiCDM.getKeyId());
            poiCSO.setName(poiCDM.getSpaceCode());
            poiCSO.setTitleEn(poiCDM.getLabel());
            poiCSO.setTitleFr(poiCDM.getLabel());
            poiCSO.setType(this.getPoiTypeById(poiTypeId));
            poiCSO.setFloor(floorCSO);
            poiCSO.setFloorId(floorCSO.getId());

            Map<String, String> attributes = new HashMap<>();
            attributes.put(EnumCdmAttributes.POI_SPACE_TYPE_NAME.toString(), poiCDM.getPoiSpaceTypeName());
            attributes.put(EnumCdmAttributes.POI_SPACE_CATEGORY_NAME.toString(), poiCDM.getPoiSpaceCategoryName());
            attributes.put(EnumCdmAttributes.HOTELING_SPACE.toString(), poiCDM.getHotelingSpace());

            // Some Poi from CDM haven't coordinate
            if (Objects.nonNull(poiCDM.getYCoordinate()) && Objects.nonNull(poiCDM.getXCoordinate())) {
                attributes.put("x", Double.toString(poiCDM.getXCoordinate() * coordinatesScalingRatio));
                attributes.put("y", Double.toString(poiCDM.getYCoordinate() * coordinatesScalingRatio));
            } else {
                attributes.put("x", "0");
                attributes.put("y", "0");
            }

            poiCSO.setAttributes(attributes);

            poiService.createPoi(poiCSO);

            this.nbCreated++;
        });

        return this.nbCreated;
    }

}
