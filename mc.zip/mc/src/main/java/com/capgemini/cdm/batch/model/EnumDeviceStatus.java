package com.capgemini.cdm.batch.model;

public enum EnumDeviceStatus {
	ACTIVE, INACTIVE;
}