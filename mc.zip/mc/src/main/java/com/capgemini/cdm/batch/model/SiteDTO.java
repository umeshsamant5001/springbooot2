package com.capgemini.cdm.batch.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class SiteDTO {

    private Long id;

	private Long cityId;

	private Long modifiedAt;

    private Long cdmKeyId;

    private List<Building> buildings;

    private String titleFr;

    private String titleEn;

    private Map<String, String> attributes = new HashMap<String, String>();
}
