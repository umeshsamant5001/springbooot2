package com.capgemini.cdm.batch.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "cdm_matcher_poi_type")
@EqualsAndHashCode
public class CdmMatcherPoiType {

    @Id
    @Column(name = "cdm_label", nullable = false, unique = true)
	private String cdmLabel;

    @Column(name="poi_type_id", nullable = false)
    private Long poiTypeId;
    
}
