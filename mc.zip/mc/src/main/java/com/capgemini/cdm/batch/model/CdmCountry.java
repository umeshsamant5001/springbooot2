package com.capgemini.cdm.batch.model;

import lombok.Data;

@Data
public class CdmCountry {

	private String name;
	private Long keyID;
	private String iso31661Alpha2;

}
