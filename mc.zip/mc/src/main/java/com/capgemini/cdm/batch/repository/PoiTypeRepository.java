package com.capgemini.cdm.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.cdm.batch.model.PoiType;

@Component
@RepositoryRestResource(path = "poitypes", collectionResourceRel = "poitypes")
public interface PoiTypeRepository extends JpaRepository<PoiType, Long> {

	@RestResource(exported = false)
	List<PoiType> findAllIdByNameIn(@Param("poiTypesNames") @RequestParam("poiTypesNames") List<String> poiTypesNames);
}
