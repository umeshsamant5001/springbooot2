package com.capgemini.cdm.batch.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cdm.batch.enumeration.ConfigValueEnum;
import com.capgemini.cdm.batch.enumeration.EnumCdmAttributes;
import com.capgemini.cdm.batch.model.CdmFloor;
import com.capgemini.cdm.batch.model.CdmMatcherPoiType;
import com.capgemini.cdm.batch.model.CdmPoi;
import com.capgemini.cdm.batch.model.Floor;
import com.capgemini.cdm.batch.model.Poi;
import com.capgemini.cdm.batch.model.PoiType;
import com.capgemini.cdm.batch.service.PoiService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdmBatchPoisUpdate extends CdmBatchPoisAction {
        private static final String FORMAT_DATE = "yyyy-MM-dd'T'HH:mm:ss";
        private static final String TIMEZONE_DATE = "UTC";

        @Autowired
        private PoiService poiService;
        // Number of updated POIs for the current process
        private Integer nbUpdated;

        public boolean shouldProcess(Floor floorCSO, CdmFloor floorCDM) {
                return (Objects.nonNull(floorCSO.getBuilding())
                                && Objects.nonNull(floorCSO.getBuilding().getAttributes())
                                && floorCSO.getBuilding().getAttributes()
                                                .containsKey(EnumCdmAttributes.ACTIVE.toString())
                                && floorCSO.getBuilding().getAttributes().get(EnumCdmAttributes.ACTIVE.toString())
                                                .equalsIgnoreCase("Y"));
        }

        public Integer process(Floor floorCSO, CdmFloor floorCDM, List<Poi> listPois,
                        List<CdmMatcherPoiType> matcherPoiType) {

                Long dateTimestampMillis = System.currentTimeMillis();
                this.nbUpdated = 0;

                List<Poi> listPoisCSOToUpdate = listPois
                                .stream()
                                .filter(poiCSO -> Objects.nonNull(poiCSO.getCdmKeyId())
                                                && this.isPoiTypeManagedByCDM(poiCSO.getTypeId(), matcherPoiType))
                                .collect(Collectors.toList());

                float coordinatesScalingRatio = getImageCDMScalingRatio(floorCDM.getBase64Map());

                log.info("Size Pois to update " + listPoisCSOToUpdate.size() + " For floorId "
                                + floorCSO.getId());
                // To each floorCSO, get poiCSO to update them with poiCDM attribute
                String poiUpdateSinceYesterday = getConfigStringValue(
                                ConfigValueEnum.KEY_CDM_BATCH_POI_UPDATED_SINCE_N_HOURS);

                listPoisCSOToUpdate.forEach(poiCSO -> {
                        // Get poi cdm corresponding to correct cso poi
                        List<CdmPoi> listPoiCDM = floorCDM.getPoiInterfaceDTOs()
                                        .stream()
                                        .filter(poiVerifCDM -> cdmNameIsInMatcher(poiVerifCDM.getPoiSpaceTypeName(),
                                                        matcherPoiType)
                                                        && poiVerifCDM.getKeyId().equals(poiCSO.getCdmKeyId())
                        // if cdm modified date < yesterday
                                                        && (this.isCDMModifiedDateAfterYesterday(
                                                                        poiVerifCDM.getModifiedDate(),
                                                                        dateTimestampMillis, poiUpdateSinceYesterday)))
                                        .collect(Collectors.toList());

                        CdmPoi poiCDM = null;
                        if (CollectionUtils.isNotEmpty(listPoiCDM)) {
                                poiCDM = listPoiCDM.get(0);
                        }

                        if (Objects.isNull(poiCDM)) {
                                return;
                        }

                        Long poiTypeId = this.getCSOPoiTypeId(poiCDM.getPoiSpaceTypeName(), matcherPoiType);
                        PoiType poiType = this.getPoiTypeById(poiTypeId);

                        poiCSO.setName(poiCDM.getSpaceCode());
                        poiCSO.setTitleEn(poiCDM.getLabel());
                        poiCSO.setTitleFr(poiCDM.getLabel());
                        poiCSO.setType(poiType);
                        poiCSO.setTypeId(poiType.getId());
                        poiCSO.setFloor(floorCSO);
                        poiCSO.setFloorId(floorCSO.getId());
                        poiCSO.getAttributes().put(
                                        EnumCdmAttributes.POI_SPACE_TYPE_NAME.toString(),
                                        poiCDM.getPoiSpaceTypeName());
                        poiCSO.getAttributes().put(
                                        EnumCdmAttributes.POI_SPACE_CATEGORY_NAME.toString(),
                                        poiCDM.getPoiSpaceCategoryName());
                        poiCSO.getAttributes().put(
                                        EnumCdmAttributes.HOTELING_SPACE.toString(),
                                        poiCDM.getHotelingSpace());

                        // Some Poi from CDM haven't coordinate
                        if (Objects.nonNull(poiCDM.getYCoordinate())
                                        && Objects.nonNull(poiCDM.getXCoordinate())) {
                                poiCSO.getAttributes().put(
                                                "y",
                                                Double.toString(poiCDM.getYCoordinate() * coordinatesScalingRatio));
                                poiCSO.getAttributes().put(
                                                "x",
                                                Double.toString(poiCDM.getXCoordinate() * coordinatesScalingRatio));
                        } else {
                                poiCSO.getAttributes().put("y", "0");
                                poiCSO.getAttributes().put("x", "0");
                        }

                        poiService.updatePoi(poiCSO);

                        this.nbUpdated++;
                });

                return this.nbUpdated;
        }

        private boolean isCDMModifiedDateAfterYesterday(
                        String dateCdm,
                        Long dateYesterdayTimestampMillis, String nbHoursToUpdate) {
                Boolean isDateAfter = false;

                try {
                        SimpleDateFormat isoFormat = new SimpleDateFormat(FORMAT_DATE);
                        isoFormat.setTimeZone(TimeZone.getTimeZone(TIMEZONE_DATE));

                        if (nbHoursToUpdate.isEmpty()) {
                                return isDateAfter;
                        }

                        int modifiedDate = Integer.valueOf(nbHoursToUpdate) * 3600;
                        Date dateYesterday = new Date(dateYesterdayTimestampMillis - modifiedDate * 1000);
                        isDateAfter = isoFormat.parse(dateCdm).after(dateYesterday);

                } catch (ParseException e) {
                        log.error(e.getMessage());
                }

                return isDateAfter;
        }
}
