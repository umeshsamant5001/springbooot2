package com.capgemini.cdm.batch.action;

import com.capgemini.cdm.batch.model.Building;
import com.capgemini.cdm.batch.model.CdmAsset;

public abstract class CdmBatchBuildingsAction {

    /**
     * Check if the process function should be launch.
     */
    public abstract boolean shouldProcess(Building buildingCSO, CdmAsset asssetCDM);

    /**
     * Launch the process
     * 
     * @param buildingCSO
     * @param asssetCDM
     * @return
     */
    public abstract void process(Building buildingCSO, CdmAsset asssetCDM);

}
